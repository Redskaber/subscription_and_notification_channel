//! Stage 1.5 second-segment integration tests — the lexical layer
//! through the FULL .krf chain (bytes → lexer.krf → reader.krf),
//! checked against the Rust reader oracle on three axes (tokens,
//! tree, error) on both engines (stage-1-plan row 1.5 segment 2;
//! docs/stage0.md §9.86; the 63-a re-audit remediation).
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: tree/token parity at byte-exact spans on both
//!   engines, the mixed-width rich fixture (BOM + CJK atoms + the
//!   VT separator + comments with non-ASCII + escapes + adjacency),
//!   the numeric boundary families, the corpus sweep (all 85 Stage
//!   1.4/2.1 corpus files as full-chain inputs), and the bootstrap
//!   fixed points (the chain reads the reader's and the lexer's own
//!   sources).
//! - **Negative**: every lexical rejection family at its exact
//!   parity key (the six formerly-split variants plus the C1
//!   control-symbol face and both literal-overflow faces), the
//!   structure-layer rejections re-run through the full chain, and
//!   the drift detector's self-checks (a tampered lexer must be
//!   caught).
//! - **Cross-stage consumption**: the Stage 1.4/2.1 corpus
//!   deliverable is consumed as the full-chain input face, and the
//!   structure layer (`reader.krf`) runs unmodified inside the
//!   chain — the 1.5 segment-1 deliverable consumed by segment 2.

use kerf::driver::{
    LEXER_SOURCE, READER_SOURCE, reader_parity_full, reader_parity_full_vm, reader_parity_full_with,
};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Run a body on a thread with a deep explicit stack (the r74
/// lineage: the evaluator is a tree-walker whose *native* recursion
/// grows with the kerf call depth; deep corpus cases need more than
/// the default test-thread stack in debug builds).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The envelope face rides the eval engine to its full frame cap,
/// so its guards carry their own (demand-allocated) stack hint.
fn envelope_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(1536 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the envelope-stack thread")
        .join()
        .expect("the envelope-stack thread finished cleanly");
}

fn wide_flat_source(atoms: usize) -> String {
    let mut src = String::from("(f");
    for _ in 0..atoms {
        src.push_str(" 1");
    }
    src.push(')');
    src
}

// ---------- positive: full-chain tree and token parity ----------

#[test]
fn full_chain_tree_and_token_parity_on_a_mixed_program() {
    let report = reader_parity_full("mixed", "(f (g 1) 2.5 #t \"s\\n\")");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert_eq!(
        report.oracle_tree,
        "(list 0 22 (ident 1 2 f) (list 3 8 (ident 4 5 g) (int 6 7 1)) \
         (float 9 12 2.5) (bool 13 15 true) (string 16 21 \"s\\n\"))"
    );
    assert_eq!(
        report.krf_tree.as_deref(),
        Some(report.oracle_tree.as_str())
    );
    // The token axis localizes every record (span + payload).
    assert!(report.oracle_tokens.contains("(lparen 0 1)\n"));
    assert!(report.oracle_tokens.contains("(ident 1 2 f)\n"));
    assert!(report.oracle_tokens.contains("(float 9 12 2.5)\n"));
    assert!(report.oracle_tokens.contains("(string 16 21 \"s\\n\")\n"));
    assert_eq!(
        report.krf_tokens.as_deref(),
        Some(report.oracle_tokens.as_str())
    );
}

#[test]
fn full_chain_rich_fixture_pins_the_mixed_width_scan() {
    // The r70 rich fixture verbatim: BOM lead-in, a CJK atom, the
    // VT separator (the `is_ascii_whitespace` drift trap), every
    // numeric shape, an escape decode, a comment swallowing
    // non-ASCII, and adjacency at the boundaries.
    let src = "\u{feff}(f 计数器\u{0b}+ -3 .5 1e5 1e-999 \"a\\nb\" x;y\n(z \"s\"))";
    let report = reader_parity_full("rich", src);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    // Byte-span pins from the oracle fixture: BOM 3B, CJK 3B/char.
    assert!(report.krf_tree.as_deref().is_some());
    let tree = report.krf_tree.as_deref().unwrap();
    assert!(tree.contains("(ident 6 15 计数器)"), "tree: {tree}");
    assert!(tree.contains("(int 18 20 -3)"));
    assert!(tree.contains("(float 21 23 0.5)"));
    assert!(tree.contains("(float 28 34 0.0)"));
    assert!(tree.contains("(string 35 41 \"a\\nb\")"));
    // The token axis carries the exact separator arithmetic too.
    let tokens = report.krf_tokens.as_deref().unwrap();
    assert!(tokens.contains("(ident 16 17 +)\n"));
    assert!(tokens.contains("(eof 54 54)\n"));
}

#[test]
fn full_chain_numeric_boundaries_parity() {
    // i64::MIN, i64::MAX, leading zeros re-lexing, spelled floats
    // above i64, and the underflow rounding face — the value family
    // the 19-digit threshold guard must pass exactly.
    let report = reader_parity_full(
        "nums",
        "(f -9223372036854775808 9223372036854775807 007 1e20 1e-999)",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    let tree = report.krf_tree.as_deref().unwrap();
    assert!(tree.contains("(int 3 23 -9223372036854775808)"));
    assert!(tree.contains("(int 24 43 9223372036854775807)"));
    assert!(tree.contains("(int 44 47 7)"));
    assert!(tree.contains("(float 48 52 1e20)"));
    assert!(tree.contains("(float 53 59 0.0)"));
}

#[test]
fn full_chain_empty_and_comment_only_sources_parity() {
    for src in ["", " ; nothing here\n\t\n", "\u{feff}\u{3000};x"] {
        let report = reader_parity_full("empty", src);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
        assert_eq!(report.oracle_tree, "");
        assert_eq!(report.krf_tree.as_deref(), Some(""));
        // The token axis is exactly one eof record.
        assert!(report.oracle_tokens.starts_with("(eof "));
        assert_eq!(
            report.krf_tokens.as_deref(),
            Some(report.oracle_tokens.as_str())
        );
    }
}

#[test]
fn full_chain_unicode_whitespace_separates_atoms() {
    // Every multi-byte whitespace codepoint from the table, plus the
    // BOM mid-stream — all trivia, and the atoms around them parse
    // at the exact byte spans.
    let src = "a\u{85}b\u{a0}c\u{1680}d\u{2000}e\u{200a}f\u{2028}g\u{2029}h\u{202f}i\u{205f}j\u{3000}k\u{feff}z";
    let report = reader_parity_full("uws", src);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    let tokens = report.krf_tokens.as_deref().unwrap();
    for name in ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "z"] {
        assert!(tokens.contains(&format!(" {name})\n")), "tokens: {tokens}");
    }
}

// ---------- negative: lexical rejections at exact keys ----------

#[test]
fn full_chain_lexical_rejections_match_their_exact_keys() {
    // The six formerly-split variants plus the malformed-number
    // grammar family and the reject set, each at the oracle's exact
    // parity key.
    for (src, want) in [
        ("\"unterminated", "unterminated string literal @ byte 0"),
        ("(a \"\\q\")", "invalid string escape `q` @ byte 5"),
        ("#x", "invalid boolean literal `#x`: expected `#t` or `#f`"),
        ("#true", "invalid boolean literal `#true`"),
        ("#", "invalid boolean literal `#`"),
        ("1.2.3", "malformed number literal `1.2.3`"),
        ("1e", "malformed number literal `1e`"),
        ("1e+", "malformed number literal `1e+`"),
        ("0x1F", "malformed number literal `0x1F`"),
        ("1_000", "malformed number literal `1_000`"),
        ("[", "unexpected character `[` @ byte 0"),
        ("(a `b)", "unexpected character ``` @ byte 3"),
        (",", "unexpected character `,` @ byte 0"),
    ] {
        let report = reader_parity_full("lex-neg", src);
        assert!(report.matched, "case {src:?}: {}", report.failure_line());
        assert!(report.engines_agree, "case {src:?}");
        assert!(
            report.oracle_tree.starts_with("ERR "),
            "case {src:?}: oracle `{}` must be a rejection",
            report.oracle_tree
        );
        assert!(
            report.oracle_tree.contains(want),
            "case {src:?}: oracle `{}` want `{want}`",
            report.oracle_tree
        );
        // A rejection decided the case: both .krf axes carry the
        // same key (surfaced through `matched`), and no dump form
        // exists on the .krf side.
        assert!(report.krf_tree.is_none(), "case {src:?}");
        assert!(report.krf_tokens.is_none(), "case {src:?}");
    }
}

#[test]
fn full_chain_literal_overflow_faces_reject_through_the_k20_axis() {
    // Both overflow faces: the i64 face decided in lexer.krf (the
    // 19-digit threshold guard), the f64 face applied at the host
    // value layer (K20 — the same rejection the oracle made).
    for (src, want) in [
        (
            "(f 9223372036854775808)",
            "integer literal `9223372036854775808` out of range for `i64`",
        ),
        (
            "(f -9223372036854775809)",
            "integer literal `-9223372036854775809` out of range for `i64`",
        ),
        (
            "(f 99999999999999999999)",
            "integer literal `99999999999999999999` out of range for `i64`",
        ),
        ("(f 1e999)", "float literal `1e999` out of range for `f64`"),
    ] {
        let report = reader_parity_full("overflow", src);
        assert!(report.matched, "case {src:?}: {}", report.failure_line());
        assert!(report.engines_agree, "case {src:?}");
        assert!(
            report.oracle_tree.contains(want),
            "case {src:?}: oracle `{}` want `{want}`",
            report.oracle_tree
        );
    }
}

#[test]
fn full_chain_c1_control_symbol_rejects_on_the_symbol_floor() {
    // A C1 control (U+0084) inside an atom: not whitespace (so it
    // does not terminate the run) and is_control — the Symbol floor
    // rejects it, the only reachable C1 face inside an atom.
    let src = "a\u{84}b";
    let report = reader_parity_full("c1", src);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert!(report.oracle_tree.contains(
        "invalid symbol `a\u{84}b`: must be non-empty with no whitespace or control characters"
    ));
}

#[test]
fn full_chain_structure_rejections_ride_the_chain_unchanged() {
    // The segment-1 families re-run through the full chain: the
    // structure layer still decides them at the exact payloads.
    for (src, want) in [
        ("(a (b", "unclosed delimiter: `(` is never closed @ byte 3"),
        (")", "unexpected closing delimiter `)` @ byte 0"),
        ("()", "empty application: `()` has no operator @ byte 0"),
        ("(f ())", "empty application: `()` has no operator @ byte 3"),
    ] {
        let report = reader_parity_full("struct-neg", src);
        assert!(report.matched, "case {src:?}: {}", report.failure_line());
        assert!(report.engines_agree, "case {src:?}");
        // Rejections surface as `ERR <key>` on the tree axis.
        assert!(report.oracle_tree.starts_with("ERR "), "case {src:?}");
        assert!(report.oracle_tree.contains(want), "case {src:?}");
    }
}

#[test]
fn full_chain_nesting_boundary_through_the_full_chain() {
    deep_stack(|| {
        let mut ok = String::new();
        for _ in 0..255 {
            ok.push('(');
        }
        ok.push('x');
        for _ in 0..255 {
            ok.push(')');
        }
        let report = reader_parity_full("bnd-255", &ok);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);

        let mut over = String::new();
        for _ in 0..257 {
            over.push('(');
        }
        over.push('x');
        for _ in 0..257 {
            over.push(')');
        }
        let report = reader_parity_full("bnd-257", &over);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(
            report.oracle_tree,
            "ERR nesting depth 257 exceeds the limit of 256"
        );
    });
}

// ---------- the drift detector (a tampered lexer must be caught) ----------

#[test]
fn drift_detector_catches_a_tampered_escape_set() {
    // The `r` escape removed from the valid set: the "\r" fixture
    // must drift (the oracle accepts, the tampered lexer rejects).
    let tampered = LEXER_SOURCE.replace(
        "(if (= b 116) #t (= b 114))",
        "(if (= b 116) #t (= b 1145))",
    );
    assert_ne!(tampered, LEXER_SOURCE, "tamper must change the source");
    let report = reader_parity_full_with("tamper-escape", "(f \"a\\rb\")", &tampered);
    assert!(!report.matched, "the tampered escape set must be caught");
    assert!(report.drift.is_some());
}

#[test]
fn drift_detector_catches_a_tampered_terminator_set() {
    // The vertical tab (byte 11) removed from the whitespace table:
    // the VT-separated fixture must drift (the atoms fuse).
    let tampered = LEXER_SOURCE.replace("(if (= b 11) #t", "(if (= b 110) #t");
    assert_ne!(tampered, LEXER_SOURCE);
    let report = reader_parity_full_with("tamper-vt", "a\u{0b}b", &tampered);
    assert!(
        !report.matched,
        "the tampered terminator set must be caught"
    );
}

#[test]
fn drift_detector_catches_a_tampered_int_threshold() {
    // The positive threshold's last digit tightened 7 -> 6: the
    // i64::MAX boundary value must drift (rejected by the tampered
    // lexer, accepted by the oracle).
    let tampered = LEXER_SOURCE.replace(
        "(quote (57 50 50 51 51 55 50 48 51 54 56 53 52 55 55 53 56 48 55))",
        "(quote (57 50 50 51 51 55 50 48 51 54 56 53 52 55 55 53 56 48 54))",
    );
    assert_ne!(tampered, LEXER_SOURCE);
    let report = reader_parity_full_with("tamper-threshold", "(f 9223372036854775807)", &tampered);
    assert!(!report.matched, "the tampered threshold must be caught");
}

#[test]
fn drift_detector_catches_a_tampered_mb_ws_table() {
    // U+3000 (E3 80 80) dropped from the multi-byte whitespace
    // table: the ideographic-space fixture must drift.
    let tampered = LEXER_SOURCE.replace(
        "(if (= b1 227)\n                  (if (= b2 128) (= b3 128) #f)",
        "(if (= b1 227)\n                  (if (= b2 128) (= b3 129) #f)",
    );
    assert_ne!(tampered, LEXER_SOURCE);
    let report = reader_parity_full_with("tamper-u3000", "a\u{3000}b", &tampered);
    assert!(!report.matched, "the tampered ws table must be caught");
}

#[test]
fn harness_defects_surface_as_drift_not_panics() {
    // A lexer source that binds garbage globals: the harness must
    // report a drift (never panic) — errors are data.
    let broken = "(define lex-verdict 42)";
    let report = reader_parity_full_with("broken", "(a)", broken);
    assert!(!report.matched);
    assert!(report.drift.as_deref().unwrap().contains("harness defect"));
}

// ---------- cross-stage consumption: the corpus sweep ----------

#[test]
fn corpus_directory_every_file_validates_full_chain_parity() {
    deep_stack(corpus_sweep_body);
}

fn corpus_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    assert!(
        files.len() >= 80,
        "the corpus floor is >= 80 (found {})",
        files.len()
    );
    let mut rejections = 0usize;
    let mut budget_bracketed = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        let report = reader_parity_full(name, &source);
        if let Some(d) = report.drift.as_deref() {
            if d.starts_with("harness limit:") {
                // The honest evaluator envelope (K165/K166): the deep
                // nesting family rides past the per-element budget —
                // verify the same case through the VM bracket face.
                budget_bracketed += 1;
                let vm = reader_parity_full_vm(name, &source);
                assert!(
                    vm.matched,
                    "corpus case {name} (vm bracket): {}",
                    vm.failure_line()
                );
                continue;
            }
        }
        assert!(
            report.matched,
            "corpus case {name}: {}",
            report.failure_line()
        );
        assert!(
            report.engines_agree,
            "corpus case {name}: engine divergence"
        );
        if report.oracle_tree.starts_with("ERR ") {
            rejections += 1;
        }
    }
    // The neg- family's READ-stage rejections (the Reader 4 + the
    // literal-overflow pair + friends — the expand/check/runtime
    // families read fine and only reject downstream, outside this
    // harness's face).
    assert!(rejections >= 5, "rejection cases: {rejections}");
    // The bracketed family is the known deep-nesting pair (bnd-006/
    // bnd-007 ride ~1.3k tokens — past the ~1k-token dual envelope).
    assert!(
        budget_bracketed <= 2,
        "unexpected bracket count: {budget_bracketed}"
    );
}

#[test]
fn corpus_boundary_files_ride_the_full_chain() {
    deep_stack(|| {
        // The nesting pair rides ~1.3k tokens — past the evaluator's
        // dual envelope — so it verifies through the VM bracket face
        // (the same honest classification the sweep applies); the
        // literal-overflow pair stays inside the dual envelope.
        for (file, vm_bracket) in [
            ("bnd-006-nesting-255-ok.krf", true),
            ("bnd-007-nesting-257-fails.krf", true),
            ("neg-054-i64-overflow-literal.krf", false),
            ("neg-055-float-overflow-literal.krf", false),
        ] {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
            let report = if vm_bracket {
                reader_parity_full_vm(file, &source)
            } else {
                reader_parity_full(file, &source)
            };
            assert!(report.matched, "{file}: {}", report.failure_line());
            if !vm_bracket {
                assert!(report.engines_agree);
            }
        }
    });
}

// ---------- the bootstrap fixed points ----------

#[test]
fn the_full_chain_reads_the_reader_source() {
    deep_stack(|| {
        // reader.krf's own source through bytes -> lexer.krf ->
        // reader.krf: the segment-2 layer reads the segment-1 layer
        // (the fixed point closes one step earlier in the chain).
        // The header comment block is one unbroken trivia run of
        // ~2.4k bytes — past the evaluator's per-element envelope
        // (the K165/K166 bracket: the frozen subset expresses the
        // trivia walk as one self-recursion per byte), so this
        // fixed point rides the VM bracket face, disclosed.
        let report = reader_parity_full_vm("reader-fixed-point", READER_SOURCE);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle_tree.contains("(ident "));
        assert!(report.oracle_tree.starts_with("(list "));
    });
}

#[test]
fn the_full_chain_reads_the_lexer_source_vm_bracket() {
    deep_stack(|| {
        // lexer.krf's own source: past the evaluator's per-element
        // envelope (the token count rides four figures), so this
        // fixed point runs the VM-only bracket face — disclosed per
        // the K165/K166 discipline, not silently downgraded.
        let report = reader_parity_full_vm("lexer-fixed-point", LEXER_SOURCE);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle_tree.starts_with("(list "));
        assert!(report.krf_tree.is_some());
    });
}

// ---------- the envelope brackets (the r74 lineage) ----------

#[test]
fn harness_envelope_within_bracket_holds_full_chain_parity() {
    envelope_stack(|| {
        let report = reader_parity_full("envelope-within", &wide_flat_source(500));
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
    });
}

#[test]
fn harness_envelope_beyond_bracket_classifies_the_limit() {
    envelope_stack(|| {
        let report = reader_parity_full("envelope-beyond", &wide_flat_source(2000));
        assert!(
            !report.matched,
            "past the envelope the comparison cannot hold"
        );
        let drift = report.drift.as_deref().unwrap();
        assert!(
            drift.starts_with("harness limit:"),
            "the budget face must classify as the honest harness limit: {drift}"
        );
        assert!(
            !drift.contains("harness defect:"),
            "an envelope limit is not a harness defect: {drift}"
        );
    });
}

// ---------- report face ----------

#[test]
fn report_failure_line_names_the_case() {
    let pass = reader_parity_full("pass-case", "(a)");
    assert_eq!(pass.failure_line(), "full-chain parity PASS [pass-case]");
    let broken = "(define lex-verdict 42)";
    let fail = reader_parity_full_with("fail-case", "(a)", broken);
    assert!(!fail.matched);
    assert!(
        fail.failure_line()
            .starts_with("full-chain parity FAIL [fail-case]")
    );
}

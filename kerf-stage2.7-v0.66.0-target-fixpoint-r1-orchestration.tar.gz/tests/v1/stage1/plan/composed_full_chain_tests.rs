//! Stage 2.4 (fixpoint B) integration tests — the FULL composed
//! chain (§9.87; stage-2-plan §2 row 2.4, single source): the 2.4
//! formula `compile(expand(read(lex(S)))) ==
//! compile_krf(expand_krf(read_krf(lex_krf(S))))` staged junction
//! by junction, the `.krf` chain's OWN products feeding forward at
//! every junction.
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: the anchor shapes end to end; the selfhost fixed
//!   points — every front-end source through the full chain (the
//!   reader dual; the assembled expander, the compiler, the macro
//!   library, and the LEXER's own source — the seventh
//!   self-application, first through the complete `.krf` chain); and
//!   the corpus sweep with the drift ledger's routing total.
//! - **Negative**: every routing row's error axis (a reader-layer
//!   rejection at junction 1, expander-layer at junction 2, the
//!   compile error axis at junction 3), the tamper probes at all
//!   three junctions (a chain that cannot fail at every junction is
//!   not a chain), and the honest harness-envelope classification
//!   with the VM bracket re-verification.
//! - **Cross-stage consumption**: the Stage 1.4/2.1 corpus rides as
//!   the input face; the five selfhost deliverables (1.5 structure,
//!   1.5 lexical, 1.6 expander, 1.7 macro, 2.2/2.3 compiler) are
//!   consumed by the chain that replaces them; the Stage 1.6 corpus
//!   layer distribution (8/19/58) is the ledger's pinned invariant.
//!
//! The gate-B promotion witness (§9.87.5) closes the set: the
//! analysis-dump grammar must be a faithful image of the `Bytecode`
//! semantics — the precondition the 2.5 window registers for gate
//! B's full-pipeline dual-track.

use kerf::driver::{
    COMPILER_SOURCE, ComposedLayer, LEXER_SOURCE, assembled_expander_source,
    composed_full_chain_parity, composed_full_chain_parity_vm, composed_full_chain_probes,
    dump_faithfulness_witness,
};
use kerf::expander::{expand_program, load_program};
use kerf::reader::read_program;
use kerf::span::FileId;

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (bnd-006's 255-deep if chain, the selfhost fixed
/// points) recurse through the .krf analysis and the harness's Rust
/// tree walkers; the default 8 MiB test-thread stack is not enough
/// in debug builds. Virtual stack pages are demand-allocated, so
/// the large hint costs nothing.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The envelope face rides the eval engine to its full frame cap,
/// so its guards carry their own (demand-allocated) stack hint.
fn envelope_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(1536 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the envelope-stack thread")
        .join()
        .expect("the envelope-stack thread finished cleanly");
}

// ---------- positive: the anchors, end to end ----------

#[test]
fn positive_anchors_through_the_full_composed_chain() {
    deep_stack(|| {
        let cases = [
            ("full-fn-sugar", "(define (f x) (if x 1 2))"),
            (
                "full-capture-order",
                "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))",
            ),
            (
                "full-transitive",
                "(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))",
            ),
            (
                "full-effects",
                "(define r (handle (perform log 1) (log (fn (v) v))))",
            ),
            (
                "full-let-shadow",
                "(define r (let ((x 1)) (let ((x (+ x 1))) x)))",
            ),
            (
                "full-multi-define-module",
                "(define a 1)\n(define (b x) (+ a x))\n(define c (b 2))",
            ),
            (
                "full-payload-family",
                "(define s \"a\\nb\")\n(define f 3.5)\n(define n -7)\n(define t #f)",
            ),
        ];
        for (name, source) in &cases {
            let report = composed_full_chain_parity(name, source);
            assert!(report.matched, "{}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Compile);
            assert!(report.read_matched);
            assert_eq!(report.expand_matched, Some(true));
            assert_eq!(report.compile_matched, Some(true));
        }
    });
}

#[test]
fn a_comment_only_source_compiles_to_the_empty_product() {
    deep_stack(|| {
        // The empty and comment-only sources read to ZERO forms —
        // the oracle accepts them (an empty program compiles to the
        // empty product), so both ride the Compile row with the
        // nil-carried streams (the `(quote nil)` prefixes).
        for (name, source) in [
            ("full-comment-only", ";; nothing but trivia\n"),
            ("full-empty", ""),
        ] {
            let report = composed_full_chain_parity(name, source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Compile, "{name}");
            assert_eq!(report.compile_matched, Some(true), "{name}");
        }
    });
}

// ---------- the selfhost fixed points ----------

#[test]
fn the_selfhost_reader_rides_the_full_chain() {
    deep_stack(|| {
        // reader.krf's header comment block is one unbroken trivia
        // run of ~2.4k bytes — past the evaluator's per-element
        // read envelope (the K165/K166 bracket) — so junction 1
        // rides the VM bracket face, disclosed (the r85 fixed-point
        // precedent); junctions 2/3 stay dual.
        let structural = include_str!("../../../../selfhost/v1/reader.krf")
            .replace("\n(define result (rd-loop tokens nil nil))", "");
        assert_ne!(
            structural.as_str(),
            include_str!("../../../../selfhost/v1/reader.krf")
        );
        let report = composed_full_chain_parity_vm("full-selfhost-reader", &structural);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
    });
}

/// The seventh self-application, and the first through the COMPLETE
/// `.krf` chain: the lexer's own source — read by the `.krf`
/// lexer+reader from its byte table, expanded by the `.krf`
/// expander, compiled by the `.krf` compiler, against the oracle
/// full pipeline. The hosting tail (the four output globals that
/// reference the injected `source-bytes`) is stripped per the CP6
/// structural discipline; junction 1 rides the VM bracket (the
/// r85 envelope lineage — the own-source fixed point IS the
/// canonical bracket case).
#[test]
fn the_seventh_self_application_the_lexer_source() {
    deep_stack(|| {
        let cut = LEXER_SOURCE
            .find("\n(define lex-verdict")
            .expect("the lexer's hosting tail is present");
        let structural = &LEXER_SOURCE[..cut];
        let report = composed_full_chain_parity_vm("full-selfhost-lexer", structural);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
        assert!(report.read_matched);
        assert_eq!(report.expand_matched, Some(true));
        assert_eq!(report.compile_matched, Some(true));
    });
}

#[test]
fn the_assembled_expander_and_compiler_ride_the_full_chain() {
    deep_stack(|| {
        let expander_structural =
            assembled_expander_source().replace("\n(define result (ex-run forms))", "");
        let compiler_structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
        assert_ne!(&expander_structural, &assembled_expander_source());
        assert_ne!(&compiler_structural, COMPILER_SOURCE);
        for (name, source) in [
            (
                "full-selfhost-assembled-expander",
                expander_structural.as_str(),
            ),
            ("full-selfhost-compiler", compiler_structural.as_str()),
        ] {
            let report = composed_full_chain_parity_vm(name, source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Compile);
        }
    });
}

/// The macro library is self-contained (its `ex-m*` state cells and
/// every function it references are defined in-file): unlike the
/// expander and compiler sources it rides WITHOUT a hosting-tail
/// strip.
#[test]
fn the_macro_library_rides_the_full_chain() {
    deep_stack(|| {
        let source = include_str!("../../../../selfhost/v1/macro.krf");
        let report = composed_full_chain_parity_vm("full-selfhost-macro", source);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
    });
}

// ---------- the drift ledger: the corpus routing is total ----------

/// The ledger's pinned distribution (§9.87.4): every corpus file
/// lands in exactly one row — the 8 reader-layer rejections verify
/// on junction 1's error axis, the 19 expander/loader rejections on
/// junction 2's, and the 58 compiler-layer files ride the full
/// formula. Corpus growth that moves a file between rows must move
/// this count with it (the ledger is a tested invariant, never a
/// stale claim).
#[test]
fn corpus_directory_every_file_lands_in_its_ledger_row() {
    deep_stack(corpus_ledger_sweep_body);
}

fn corpus_ledger_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    let mut read_row = 0usize;
    let mut expand_row = 0usize;
    let mut compile_row = 0usize;
    let mut budget_bracketed = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        // The oracle routing decides the ledger row (the CP1/CP9
        // filter — the same single-source classification).
        let forms = read_program(FileId(0), &source).ok();
        let items = forms.as_ref().and_then(|f| {
            expand_program(f)
                .ok()
                .and_then(|items| load_program(&items).ok().map(|_| items))
        });
        let expected_layer = if forms.is_none() {
            ComposedLayer::Read
        } else if items.is_none() {
            ComposedLayer::Expand
        } else {
            ComposedLayer::Compile
        };
        let mut report = composed_full_chain_parity(name, &source);
        if let Some(d) = report.drift.as_deref() {
            if d.starts_with("harness limit:") {
                // The honest evaluator envelope (K165/K166): the
                // deep-nesting family rides past the per-element
                // budget — re-verify through the VM bracket face.
                budget_bracketed += 1;
                report = composed_full_chain_parity_vm(name, &source);
            }
        }
        assert!(
            report.matched,
            "corpus case {name} (row {expected_layer:?}): {}",
            report.failure_line()
        );
        assert_eq!(
            report.layer, expected_layer,
            "corpus case {name}: the ledger row must match the oracle routing"
        );
        match expected_layer {
            ComposedLayer::Read => {
                read_row += 1;
                assert!(report.read_matched);
                assert_eq!(report.expand_matched, None);
                assert_eq!(report.compile_matched, None);
            }
            ComposedLayer::Expand => {
                expand_row += 1;
                assert!(report.read_matched);
                assert_eq!(report.expand_matched, Some(true));
                assert_eq!(report.compile_matched, None);
            }
            ComposedLayer::Compile => {
                compile_row += 1;
                assert_eq!(report.compile_matched, Some(true));
            }
        }
    }
    // The pinned ledger (the CP1/CP9-4 distribution, 85 files):
    assert_eq!(read_row, 8, "the reader-layer row");
    assert_eq!(expand_row, 19, "the expander/loader row");
    assert_eq!(compile_row, 58, "the compiler-layer row");
    assert_eq!(read_row + expand_row + compile_row, 85);
    // The bracketed family is the known deep-nesting pair (bnd-006/
    // bnd-007 ride ~1.3k tokens — past the ~1k-token dual envelope).
    assert!(
        budget_bracketed <= 2,
        "unexpected bracket count: {budget_bracketed}"
    );
}

// ---------- negative: every routing row's error axis ----------

#[test]
fn reader_layer_rejections_route_to_junction_one() {
    deep_stack(|| {
        for (name, source) in [
            ("full-neg-unclosed", "(define result (+ 1 2)"),
            ("full-neg-unterminated-string", "(define s \"abc"),
        ] {
            let report = composed_full_chain_parity(name, source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Read, "{name}");
            // Downstream junctions are vacuous — no tree exists to
            // feed them (the routing's own shape).
            assert_eq!(report.expand_matched, None, "{name}");
            assert_eq!(report.compile_matched, None, "{name}");
        }
    });
}

#[test]
fn expander_layer_rejections_route_to_junction_two() {
    deep_stack(|| {
        for (name, file) in [
            ("full-neg-unbound", "neg-013-unbound-reference.krf"),
            ("full-neg-malformed-fn", "neg-011-malformed-fn.krf"),
        ] {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
            let report = composed_full_chain_parity(name, &source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Expand, "{name}");
            assert!(report.read_matched, "{name}: junction 1 must pass");
            assert_eq!(report.expand_matched, Some(true), "{name}");
            assert_eq!(report.compile_matched, None, "{name}");
        }
    });
}

#[test]
fn the_compile_error_axis_rides_junction_three() {
    deep_stack(|| {
        // neg-057: the LA-7 assign-to-captured boundary — the
        // oracle pipeline rejects at the compile step, and the
        // chain's junction 3 must reject identically (the error
        // axis rides the same comparison face as the products).
        let source =
            std::fs::read_to_string(format!("{CORPUS_DIR}/neg-057-assign-to-captured.krf"))
                .expect("file");
        let report = composed_full_chain_parity("full-neg-assign-captured", &source);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
        assert_eq!(report.compile_matched, Some(true));
    });
}

// ---------- negative: the tamper probes, junction by junction ----------

#[test]
fn a_tampered_lexer_fails_the_chain_at_junction_one() {
    deep_stack(|| {
        // The vertical tab removed from the whitespace table (the
        // r85 tamper): the read chain drifts, and the failure must
        // surface AT junction 1 — never fall through to junction 2.
        let tampered = LEXER_SOURCE.replace("(if (= b 11) #t", "(if (= b 110) #t");
        assert_ne!(
            &tampered, LEXER_SOURCE,
            "the tamper must land on a real anchor"
        );
        let report = composed_full_chain_probes(
            "full-tamper-lexer",
            "(define x 1)\n(define y (+ x 1))",
            Some(&tampered),
            None,
            None,
        );
        assert!(!report.matched, "the tampered lexer must fail the chain");
        assert_eq!(report.layer, ComposedLayer::Read);
        assert!(!report.read_matched);
        assert_eq!(
            report.expand_matched, None,
            "the chain must stop at junction 1"
        );
    });
}

#[test]
fn a_tampered_expander_fails_the_chain_at_junction_two() {
    deep_stack(|| {
        // The 1.6 depth-guard tamper (CP9-5's precedent): junction 1
        // passes, the tampered expander rejects, and the failure
        // must surface AT junction 2 — never fall through to
        // junction 3.
        let tampered = assembled_expander_source().replace("(>= ex-depth 512)", "(>= ex-depth 2)");
        assert_ne!(
            &tampered,
            &assembled_expander_source(),
            "the tamper must land on a real anchor"
        );
        let report = composed_full_chain_probes(
            "full-tamper-expander",
            "(define x (do 1 (do 2 3)))",
            None,
            Some(&tampered),
            None,
        );
        assert!(!report.matched, "the tampered expander must fail the chain");
        assert_eq!(report.layer, ComposedLayer::Expand);
        assert!(
            report.read_matched,
            "junction 1 is untampered and must pass"
        );
        assert_eq!(report.expand_matched, Some(false));
        assert_eq!(
            report.compile_matched, None,
            "the chain must stop at junction 2"
        );
    });
}

#[test]
fn a_tampered_compiler_fails_the_chain_at_junction_three() {
    deep_stack(|| {
        // The CP7 globals tamper: the var arm's global fallback
        // removed — free names stop interning, and the product axis
        // drifts at junction 3 (junctions 1/2 untampered, passing).
        let tampered = COMPILER_SOURCE.replace(
            "(cp-emit \"load-global\" (cp-intern-global name) 0 (cp-span-of t))",
            "(cp-emit \"load-global\" 0 0 (cp-span-of t))",
        );
        assert_ne!(
            &tampered, COMPILER_SOURCE,
            "the tamper must land on a real anchor"
        );
        let report = composed_full_chain_probes(
            "full-tamper-compiler",
            "(define y 1)\n(define x (+ y 1))",
            None,
            None,
            Some(&tampered),
        );
        assert!(!report.matched, "the tampered compiler must fail the chain");
        assert_eq!(report.layer, ComposedLayer::Compile);
        assert!(report.read_matched);
        assert_eq!(report.expand_matched, Some(true));
        assert_eq!(report.compile_matched, Some(false));
    });
}

// ---------- the harness envelope: honest classification ----------

#[test]
fn beyond_the_read_bracket_the_limit_classifies_and_the_vm_holds() {
    envelope_stack(|| {
        let mut wide = String::from("(f");
        for _ in 0..2000 {
            wide.push_str(" 1");
        }
        wide.push(')');
        // The dual face classifies the honest limit (never a
        // defect, never a silent pass).
        let report = composed_full_chain_parity("full-envelope-beyond", &wide);
        assert!(
            !report.matched,
            "past the envelope the comparison cannot hold"
        );
        let drift = report.drift.as_deref().unwrap();
        assert!(
            drift.starts_with("harness limit:"),
            "the budget face must classify as the honest harness limit: {drift}"
        );
        assert!(
            !drift.contains("harness defect:"),
            "an envelope limit is not a harness defect: {drift}"
        );
        // The VM bracket face holds a source past the READ envelope
        // but inside the downstream junctions' budgets end to end —
        // the deep if-chain shape (bnd-006's family: the read chain
        // walks it per byte past the dual envelope, while the
        // expansion/compile walks ride within theirs — the corpus
        // sweep brackets the same family; this is the explicit
        // envelope face).
        let mut deep = String::from("(define result ");
        for _ in 0..255 {
            deep.push_str("(if #t ");
        }
        deep.push('0');
        for _ in 0..255 {
            deep.push_str(" 0)");
        }
        deep.push(')');
        let vm = composed_full_chain_parity_vm("full-envelope-beyond-vm", &deep);
        assert!(vm.matched, "{}", vm.failure_line());
        assert_eq!(vm.layer, ComposedLayer::Compile);
    });
}

// ---------- the gate-B promotion witness (§9.87.5) ----------

#[test]
fn the_analysis_dump_is_a_faithful_image_of_the_bytecode() {
    // A representative product — every semantic field exercised:
    // named protos, captures (the transitive chain), code with
    // operands, debug spans, globals, and all const kinds.
    let source = "\
(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))
(define g 3.5)
(define s \"text\")
(define n -7)
(define t #t)
(define r (handle (perform log 1) (log (fn (v) v))))
";
    let forms = read_program(FileId(0), source).expect("the fixture reads");
    let items = expand_program(&forms).expect("the fixture expands");
    let bc = kerf::compiler::compile_program(&items).expect("the fixture compiles");
    dump_faithfulness_witness(&bc)
        .unwrap_or_else(|err| panic!("the witness must hold on a representative product: {err}"));
    // The witness's detection arm: an EMPTY bytecode's every-field
    // probe set includes the funcs axis itself (dropping the entry
    // proto changes the dump) — the degenerate product still has a
    // faithful image.
    let empty = kerf::compiler::compile_program(&[]).expect("the empty program compiles");
    dump_faithfulness_witness(&empty)
        .unwrap_or_else(|err| panic!("the witness must hold on the empty product: {err}"));
}

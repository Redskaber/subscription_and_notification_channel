//! Stage 2.3 CP parity tests — the fourth self-hosted front-end
//! segment: the compile-time lexical-domain analysis
//! (`selfhost/v1/compiler.krf`) against the Rust compiler oracle
//! (stage-2-plan §2 row 2.3; docs/stage0.md §9.83 CP-1..CP-7; the
//! test doc docs/tests/v1/stage2/compiler-parity.md).
//!
//! Families (CP1-CP7):
//! — CP1: the three-layer routing (reader / expander / compiler)
//!   over the whole corpus, with the layer distribution pinned;
//! — CP2: the product axis at hand-computed anchors — the
//!   scope-stack discipline (mark/truncate, free-slot LIFO reuse),
//!   innermost shadowing with slot identity, the LA-1 flat-capture
//!   first-use order, the LA-4 transitive pass-through;
//! — CP3: the first-use interning orders (globals, consts) and the
//!   const-pool identity rule (NaN folds, signed zeros stay
//!   distinct — the `same_const_slot` mirror);
//! — CP4: the error axis — the assign boundary three ways (local /
//!   captured / global) and the depth mirror at the exact 1024/1025
//!   boundary on hand-built trees;
//! — CP5: the zero-analysis item kinds (require / define-syntax /
//!   module sub-item walking) and the perform/handle interning and
//!   proto-creation anchors;
//! — CP6: the selfhost fixed points — compiler.krf analyzes its own
//!   expanded tree (the fourth self-application), plus the three
//!   front-end sources and the assembled expander;
//! — CP7: the drift detector's self-checks (a tampered analysis
//!   must be caught on the product axis; a stream-vocabulary break
//!   must surface as the classified harness defect) and the nested
//!   litval regression (the pair pass-through);
//! — CP8 (appended r83): the emission axis — the instruction
//!   stream products (§9.84);
//! — CP9 (appended r84): the composed chain — the `.krf` expander
//!   feeding the `.krf` compiler, the full formula
//!   `compile(expand_oracle(S)) == compile_krf(expand_krf(S))` on
//!   anchors, the selfhost fixed points, the error axis, the
//!   compiler-layer corpus sweep, and the front-end tamper probe
//!   (§9.85 — the 2.3 close-out).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    COMPILER_SOURCE, CompilerParityLayer, assembled_expander_source, compiler_parity,
    compiler_parity_items, compiler_parity_items_vm, compiler_parity_with, composed_chain_parity,
    composed_chain_parity_with,
};
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

/// The corpus directory (absolute — the working directory of a test
/// run is the package root, but the sweep stays explicit).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (bnd-006's 255-deep if chain, the 1024-deep hand-built
/// depth chains, and the selfhost fixed points) recurse through the
/// .krf analysis and the harness's Rust tree walkers; the default
/// 8 MiB test-thread stack is not enough in debug builds. Virtual
/// stack pages are demand-allocated, so the large hint costs
/// nothing.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- CP1: the corpus sweep, three-layer routing ----------

#[test]
fn corpus_directory_every_file_validates_cp_parity() {
    deep_stack(corpus_sweep_body);
}

fn corpus_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the Stage 1.4 corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    assert!(
        files.len() >= 85,
        "the corpus floor is >= 85 (found {})",
        files.len()
    );
    let mut reader_layer = 0usize;
    let mut expander_layer = 0usize;
    let mut compiler_layer = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        let report = compiler_parity(name, &source);
        assert!(
            report.matched,
            "corpus case {name}: {}",
            report.failure_line()
        );
        assert!(report.engines_agree, "corpus case {name}: engines disagree");
        match report.layer {
            CompilerParityLayer::Reader => reader_layer += 1,
            CompilerParityLayer::Expander => expander_layer += 1,
            CompilerParityLayer::Compiler => compiler_layer += 1,
        }
    }
    // The reader layer is byte-identical to the expander parity's
    // split (the same eight reader-side rejections, neg-054/055
    // included). The expander layer = every source whose expanded
    // tree never exists (expansion or loader rejections — the
    // 1.6/1.7 harnesses own that face): nineteen files, the
    // loader's top-level-expression rule and the expander's
    // unbound-name discipline included. Everything else —
    // fifty-eight files, the checker-owned negatives (the E-family)
    // and the E0012 twin neg-057 included — runs the .krf analysis
    // on both engines: the analysis products are well-defined on
    // trees the checker rejects, and neg-057's compile-side
    // rejection is the LA-7 defense layer this segment owns.
    assert_eq!(reader_layer, 8, "reader-layer count");
    assert_eq!(expander_layer, 19, "expander-layer count");
    assert_eq!(compiler_layer, 58, "compiler-layer count");
    assert_eq!(reader_layer + expander_layer + compiler_layer, files.len());
}

#[test]
fn reader_and_expander_layers_route_without_running_cp() {
    // bnd-007's 257-deep source: the reader layer decides (the 1.5
    // parity owns that face; the .krf analysis is not exercised).
    let deep = format!("(define x {}1{})", "(".repeat(300), ")".repeat(300));
    let report = compiler_parity("route-reader", &deep);
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.layer, CompilerParityLayer::Reader);
    assert!(report.krf.is_none());

    // neg-020's duplicate module: the loader layer decides (the
    // 1.6/1.7 parities own that face; no expanded tree exists).
    let dup = "(module m (define x 1))\n(module m (define x 2))\n";
    let report = compiler_parity("route-expander", dup);
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.layer, CompilerParityLayer::Expander);
    assert!(report.krf.is_none());
}

// ---------- CP2: the product axis at hand-computed anchors ----------

#[test]
fn scope_stack_mark_truncate_and_slot_reuse_anchor() {
    // Two sibling lets inside apply args: the first let's slot
    // returns to the free list at truncate, the second reuses it —
    // n_locals peaks at 2 (param + one let slot), not 3.
    let report = compiler_parity(
        "slot-reuse",
        "(define (f a) (+ (let ((x 1)) x) (let ((y 2)) y)))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (closure 1 0) (store-global 1 0) \
         (halt 0 0)) (dbg (sp 9 10) (sp 0 50) (sp 0 50))) \
         (proto f 1 2 (caps) (code (push-const 0 0) (store-local 1 0) \
         (load-local 1 0) (push-const 1 0) (store-local 1 0) (load-local 1 0) \
         (load-global 0 0) (call 2 0) (ret 0 0)) (dbg (sp 26 27) (sp 26 27) \
         (sp 30 31) (sp 42 43) (sp 42 43) (sp 46 47) (sp 15 16) (sp 14 49) \
         (sp 14 49)))) (globals + f) (consts (int 1) (int 2))"
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));

    // Sequential nesting: both let slots live simultaneously —
    // n_locals peaks at 3 (param + two live slots).
    let report = compiler_parity(
        "slot-peak",
        "(define (f a) (let ((x 1)) (let ((y 2)) (+ a (+ x y)))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("(proto f 1 3 (caps) (code"));
}

#[test]
fn innermost_shadowing_and_slot_identity_anchor() {
    // The inner fn's parameter shadows the outer capture candidate:
    // `n` in the body is the param (slot 0 of the inner proto), so
    // the inner proto captures nothing.
    let report = compiler_parity("shadow-param", "(define (h n) (fn (n) n))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(proto h 1 1 (caps) (code (closure 2 0)")
    );
    assert!(
        report
            .oracle
            .contains("(proto nil 1 1 (caps) (code (load-local 0 0)")
    );

    // A let-bound `n` (slot 1) shadows the param (slot 0): the
    // capture descriptor names the INNERMOST slot — (local 1).
    let report = compiler_parity("shadow-capture", "(define (k n) (let ((n 1)) (fn (m) n)))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(proto nil 1 1 (caps (local 1)) (code (load-captured 0 0)")
    );
}

#[test]
fn flat_capture_first_use_order_anchor() {
    // The inner fn reads p, then q, then its own z, then p again:
    // the capture table lands in first-use order [(local 0)
    // (local 1)] — the second p read reuses k=0 (no duplicate).
    let report = compiler_parity(
        "capture-order",
        "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(proto nil 1 1 (caps (local 0) (local 1)) (code (load-captured 0 0) \
                   (load-captured 1 0) (load-local 0 0) (load-captured 0 0) \
                   (load-global 0 0) (call 2 0) (load-global 0 0) (call 2 0) \
                   (load-global 0 0) (call 2 0) (ret 0 0))"
    ));
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn transitive_capture_pass_through_anchor() {
    // The three-level chain (pos-036's shape, hand-pinned): the
    // inner fn reads `a` (held by outer only) — the mid proto
    // acquires the pass-through entry (LA-4), the inner descriptor
    // reads (captured 0); `b` is mid's own param — (local 0).
    // Proto order is creation order: entry, outer, mid, inner.
    let report = compiler_parity(
        "transitive",
        "(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (closure 1 0) (store-global 1 0) \
         (halt 0 0)) (dbg (sp 9 14) (sp 0 50) (sp 0 50))) \
         (proto outer 1 1 (caps) (code (closure 2 0) (ret 0 0)) \
         (dbg (sp 18 49) (sp 18 49))) \
         (proto nil 1 1 (caps (local 0)) (code (closure 3 0) (ret 0 0)) \
         (dbg (sp 26 48) (sp 26 48))) \
         (proto nil 1 1 (caps (captured 0) (local 0)) (code (load-captured 0 0) \
         (load-captured 1 0) (load-local 0 0) (load-global 0 0) (call 2 0) \
         (load-global 0 0) (call 2 0) (ret 0 0)) (dbg (sp 37 38) (sp 42 43) \
         (sp 44 45) (sp 40 41) (sp 39 46) (sp 35 36) (sp 34 47) (sp 34 47)))) \
         (globals + outer) (consts)"
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

// ---------- CP3: first-use interning and const identity ----------

#[test]
fn first_use_order_globals_and_consts_anchor() {
    // The define's value is walked BEFORE the name interns: y lands
    // in globals ahead of + (the builtin reference — the global
    // fallback face) and x; the consts land in walk order. The
    // entry proto (nil 0 0) always leads the funcs product.
    let report = compiler_parity(
        "first-use",
        "(define y 0)\n(define x (+ y 1))\n(define b #t)\n(define f 2.5)\n(define z (quote (1 2)))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (push-const 0 0) (store-global 0 0) \
         (load-global 0 0) (push-const 1 0) (load-global 1 0) (call 2 0) \
         (store-global 2 0) (push-const 2 0) (store-global 3 0) (push-const 3 0) \
         (store-global 4 0) (push-const 4 0) (store-global 5 0) (halt 0 0)) \
         (dbg (sp 10 11) (sp 0 12) (sp 26 27) (sp 28 29) (sp 24 25) (sp 23 30) \
         (sp 13 31) (sp 42 44) (sp 32 45) (sp 56 59) (sp 46 60) (sp 71 84) \
         (sp 61 85) (sp 61 85)))) (globals y + x b f z) (consts (int 0) (int 1) \
         (bool true) (float 2.5) (pair (int 1) (pair (int 2) nil)))"
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn const_identity_nan_folds_and_signed_zeros_stay_distinct() {
    // The `same_const_slot` rule mirrored by Debug-text identity:
    // two NaN payloads fold to one slot, +0.0/-0.0 stay distinct.
    // NaN has no source literal form — the const pool reaches it
    // only through hand-built trees (the API-fed face the LA-7
    // compile-side defense documents).
    let items = vec![
        define_lit("a", LiteralValue::Float(f64::NAN)),
        define_lit(
            "b",
            LiteralValue::Float(f64::from_bits(0x7ff8_0000_0000_0001)),
        ),
        define_lit("c", LiteralValue::Float(0.0)),
        define_lit("d", LiteralValue::Float(-0.0)),
        define_lit("e", LiteralValue::Int(7)),
        define_lit("f", LiteralValue::Int(7)),
    ];
    let report = compiler_parity_items("const-identity", &items);
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(consts (float NaN) (float 0.0) (float -0.0) (int 7))")
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

fn fixture_span(start: u32, end: u32) -> Span {
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId::ROOT,
    )
    .expect("fixture span must be well-formed")
}

fn define_lit(name: &str, value: LiteralValue) -> ModuleItem {
    ModuleItem::Define {
        span: fixture_span(0, 9),
        name: Symbol::new(name).expect("fixture symbol"),
        value: CoreExpr::Literal {
            span: fixture_span(8, 9),
            value,
        },
    }
}

// ---------- CP4: the error axis ----------

#[test]
fn assign_boundary_three_ways_anchor() {
    // (a) assign to a live local: no rejection, no global.
    let report = compiler_parity("assign-local", "(define (f x) (set! x 1))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.starts_with("(funcs"));
    assert!(!report.oracle.contains("assign"));

    // (b) assign to a previously-defined global from inside a fn:
    // the global fallback (a bare top-level `set!` is a loader
    // rejection — top level only takes declarations — so the
    // fallback face lives in fn bodies; the store target reuses
    // the interned slot).
    let report = compiler_parity("assign-global", "(define g 0)\n(define (bump) (set! g 1))");
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (push-const 0 0) (store-global 0 0) \
         (closure 1 0) (store-global 1 0) (halt 0 0)) (dbg (sp 10 11) (sp 0 12) \
         (sp 22 26) (sp 13 39) (sp 13 39))) (proto bump 0 0 (caps) \
         (code (push-const 1 0) (dup 0 0) (store-global 0 0) (ret 0 0)) \
         (dbg (sp 36 37) (sp 28 38) (sp 28 38) (sp 28 38)))) \
         (globals g bump) (consts (int 0) (int 1))"
    );

    // (c) assign through a capture: the LA-7 compile-side
    // rejection — exact kind, name and span, both engines, the
    // oracle's own Display (byte parity by construction).
    let report = compiler_parity("assign-captured", "(define (f x) (fn (y) (set! x 1)))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert_eq!(report.layer, CompilerParityLayer::Compiler);
    assert!(
        report
            .oracle
            .contains("cannot assign to captured variable `x`")
    );
    assert!(!report.oracle.contains("compile depth"));
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn depth_mirror_at_the_1024_1025_boundary() {
    deep_stack(|| {
        // n nested ifs via the else branch + the deepest literal:
        // recursion depth n + 1 (mirrors compile.rs's own
        // deep_apply test). n = 1023 peaks exactly at the limit and
        // passes; n = 1024 peaks one over: the structured rejection
        // fires at the deepest node's span, both sides, same span.
        //
        // The dual-engine face's registered input envelope: the
        // eval engine's 2048-call depth cap sits BELOW the compile
        // depth limit over the stream assembler's per-level
        // recursion, so this boundary rides the VM-only face (the
        // VM has no frame-depth cap); the envelope itself is
        // pinned first — the honest `harness limit` classification
        // (r74 lineage), never a drift.
        let over_items = vec![deep_if_chain(1023)];
        let dual = compiler_parity_items("depth-envelope", &over_items);
        assert!(!dual.matched);
        assert!(
            dual.drift
                .as_deref()
                .unwrap_or("")
                .contains("harness limit")
        );
        assert!(dual.drift.as_deref().unwrap_or("").contains("eval"));

        let ok_items = vec![deep_if_chain(1022)];
        let report = compiler_parity_items_vm("depth-ok", &ok_items);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle.starts_with("(funcs"));

        let report = compiler_parity_items_vm("depth-over", &over_items);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
        assert!(
            report
                .oracle
                .contains("compile depth `1025` exceeds limit `1024`"),
            "the depth rejection: {}",
            report.oracle
        );
        assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
    });
}

/// A chain of `n` nested Ifs through the else branch, cond/then
/// literals, and a deepest else literal whose span (9999..10000) is
/// unique — the node where both depth counters fire. The define
/// item itself counts one frame (compile_program wraps every item
/// in `item()`), so the peak recursion depth is n + 2: n = 1022
/// peaks exactly at the 1024 limit and passes; n = 1023 peaks one
/// over — the structured rejection at the deepest node's span.
fn deep_if_chain(n: usize) -> ModuleItem {
    let mut chain = CoreExpr::Literal {
        span: fixture_span(9999, 10000),
        value: LiteralValue::Bool(true),
    };
    for i in (0..n).rev() {
        let at = (i * 10) as u32;
        chain = CoreExpr::If {
            span: fixture_span(at, at + 9),
            cond: Box::new(CoreExpr::Literal {
                span: fixture_span(at + 1, at + 2),
                value: LiteralValue::Bool(true),
            }),
            then_branch: Box::new(CoreExpr::Literal {
                span: fixture_span(at + 3, at + 4),
                value: LiteralValue::Int(0),
            }),
            else_branch: Box::new(chain),
        };
    }
    ModuleItem::Define {
        span: fixture_span(0, 9),
        name: Symbol::new("deep").expect("fixture symbol"),
        value: chain,
    }
}

// ---------- CP5: the zero-analysis kinds and effect faces ----------

#[test]
fn module_defsyn_zero_analysis_and_module_walking_anchor() {
    // define-syntax compiles to zero code (the transformer lives in
    // the expansion environment); module items walk in order with
    // the flat-table precedent (the module's defines intern
    // globals); the declaration records contribute no analysis of
    // their own.
    let report = compiler_parity(
        "module-walk",
        "(define-syntax twofold (syntax-rules (x) ((_ x) 2)))\n\
         (module m (define a 1) (define (f x) x))\n\
         (define top 2)",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (push-const 0 0) (store-global 0 0) \
         (closure 1 0) (store-global 1 0) (push-const 1 0) (store-global 2 0) \
         (halt 0 0)) (dbg (sp 73 74) (sp 63 75) (sp 85 86) (sp 76 92) (sp 106 107) \
         (sp 94 108) (sp 94 108))) (proto f 1 1 (caps) (code (load-local 0 0) \
         (ret 0 0)) (dbg (sp 90 91) (sp 90 91)))) (globals a f top) \
         (consts (int 1) (int 2))"
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn perform_and_handle_interning_and_proto_anchor() {
    // Perform walks args first, then interns the effect name;
    // handle walks each clause's handler expr, then interns the
    // clause effect; the handler fn is a proto; the body's perform
    // reuses the interned const and effect.
    let report = compiler_parity(
        "effects",
        "(define (f x) (perform log x 1))\n\
         (define g (handle (perform log 1) (log (fn (v) v))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(funcs (proto nil 0 0 (caps) (code (closure 1 0) (store-global 1 0) \
         (closure 2 0) (push-handler 0 0) (push-const 0 0) (perform 0 1) \
         (pop-handler 1 0) (store-global 2 0) (halt 0 0)) (dbg (sp 9 10) \
         (sp 0 32) (sp 72 82) (sp 67 83) (sp 64 65) (sp 51 66) (sp 43 84) \
         (sp 33 85) (sp 33 85))) (proto f 1 1 (caps) (code (load-local 0 0) \
         (push-const 0 0) (perform 0 2) (ret 0 0)) (dbg (sp 27 28) (sp 29 30) \
         (sp 14 31) (sp 14 31))) (proto nil 1 1 (caps) (code (load-local 0 0) \
         (ret 0 0)) (dbg (sp 80 81) (sp 80 81)))) (globals log f g) (consts (int 1))"
    );
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

// ---------- CP6: the selfhost fixed points ----------

#[test]
fn selfhost_fixed_point_compiler_analyzes_itself() {
    deep_stack(|| {
        // The fourth self-application: compiler.krf's analysis of
        // its own expanded tree agrees with the Rust oracle's —
        // 740+ lines of closures, lets and deep if cascades, every
        // analysis face of this segment in one program. The hosting
        // tail (define result (cp-run items)) is stripped first —
        // `items` is the injected global, unbound in the bare
        // source (the 1.6 selfhost-bare precedent, made structural
        // here).
        let structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
        assert_ne!(&structural, COMPILER_SOURCE);
        let report = compiler_parity("selfhost-cp", &structural);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
        assert_eq!(report.layer, CompilerParityLayer::Compiler);
        let proto_count = report.oracle.matches("(proto ").count();
        assert!(
            proto_count >= 40,
            "the fixed point must exercise a real proto population (found {proto_count})"
        );
        assert!(
            report.oracle.contains("(globals"),
            "the fixed point must intern globals"
        );
        // The fifth self-application carries the emission products:
        // every proto's full instruction stream and dense span table
        // agree with the oracle byte for byte (the r83 second Pass).
        assert!(
            report.oracle.matches(" (code (").count() >= 40,
            "the fixed point must carry per-proto code sections"
        );
        assert!(
            report.oracle.matches(" (dbg (sp ").count() >= 40,
            "the fixed point must carry per-proto debug tables"
        );
    });
}

#[test]
fn selfhost_front_end_sources_analyze_clean() {
    deep_stack(|| {
        // The strongest real-program corpus: the front-end sources
        // and the assembled expander (macro + expander, the largest
        // program in tree), hosting tails stripped (the same
        // structural-face discipline), all analyze clean on both
        // engines against the oracle.
        let reader_structural = include_str!("../../../../selfhost/v1/reader.krf")
            .replace("\n(define result (rd-loop tokens nil nil))", "");
        let expander_structural =
            assembled_expander_source().replace("\n(define result (ex-run forms))", "");
        let cases = [
            ("selfhost-reader", reader_structural),
            ("selfhost-assembled-expander", expander_structural),
        ];
        for (name, source) in &cases {
            let report = compiler_parity(name, source);
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.layer, CompilerParityLayer::Compiler);
        }
    });
}

// ---------- CP7: the drift detector's self-checks ----------

#[test]
fn tampered_analysis_is_caught_on_the_product_axis() {
    // Remove the var arm's global fallback: free names stop
    // interning, the globals section goes empty against a
    // non-empty oracle — the drift detector must catch it (the
    // FP8 lineage: a parity harness that cannot fail is not a
    // harness).
    let tampered = COMPILER_SOURCE.replace(
        "(cp-emit \"load-global\" (cp-intern-global name) 0 (cp-span-of t))",
        "(cp-emit \"load-global\" 0 0 (cp-span-of t))",
    );
    assert_ne!(
        &tampered, COMPILER_SOURCE,
        "the tamper must land on a real anchor"
    );
    let report = compiler_parity_with(
        "tamper-globals",
        "(define y 1)\n(define x (+ y 1))",
        &tampered,
    );
    assert!(!report.matched, "the tampered analysis must not pass");
    assert!(report.drift.as_deref().unwrap_or("").contains("oracle"));
}

#[test]
fn stream_vocabulary_break_surfaces_as_harness_defect() {
    // Break the walk's var dispatch tag: every var node falls to
    // the bad-node arm, and the harness classifies it as a defect
    // of the injected stream (fail-closed, never a source defect).
    let tampered = COMPILER_SOURCE.replace(
        "(eq? tag \"var\")\n                (let",
        "(eq? tag \"vars\")\n                (let",
    );
    assert_ne!(
        &tampered, COMPILER_SOURCE,
        "the tamper must land on a real anchor"
    );
    let report = compiler_parity_with(
        "tamper-badnode",
        "(define y 1)\n(define x (+ y 1))",
        &tampered,
    );
    assert!(
        !report.matched,
        "the broken stream vocabulary must not pass"
    );
    assert!(
        report
            .drift
            .as_deref()
            .unwrap_or("")
            .contains("harness defect")
    );
}

#[test]
fn nested_pair_litvals_survive_the_stream() {
    // The regression anchor for the pair pass-through: a quoted
    // list of two elements nests pairs two levels deep, and a
    // doubly-nested quote nests three — without the "pair"
    // pass-through arm in cp-lit-convert the inner components
    // collapse to nil (caught at recovery verification, this test
    // keeps it caught forever).
    let report = compiler_parity(
        "nested-litvals",
        "(define a (quote (1 2)))\n(define b (quote (1 (2 3))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(consts (pair (int 1) (pair (int 2) nil)) \
         (pair (int 1) (pair (pair (int 2) (pair (int 3) nil)) nil)))"
    ));
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

// ---------- CP8: the emission axis — the instruction stream ----------
// The second Pass (r83, §9.84): the products now carry the full
// per-proto instruction streams (code) and the dense per-instruction
// span table (dbg). These anchors pin the emitter's discipline at
// hand-computed shapes: the tail-If terminator contract, the
// non-tail merge jump and its patch targets, the eval order, the
// slot lifecycle, the assign dup form, the effect operand shapes,
// the closure protocol indices, the const-pool operand identity,
// the empty-program anchor, and the code-axis drift detector.

#[test]
fn cp8_tail_if_compiles_branches_into_terminators() {
    // The tail contract (§19.3 trap 1): a tail If compiles its
    // branches straight into the proto terminator — no merge jump,
    // both branches end in `ret`, the jump-if-false target is the
    // else entry (pc 4).
    let report = compiler_parity("cp8-tail-if", "(define (f x) (if x 1 2))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(code (load-local 0 0) (jump-if-false 4 0) (push-const 0 0) \
         (ret 0 0) (push-const 1 0) (ret 0 0))"
    ));
}

#[test]
fn cp8_non_tail_if_merge_jump_and_patch_targets() {
    // The non-tail form: both branches converge at the merge jump.
    // The jump-if-false is patched to the else entry (pc 4) and the
    // jump to the join point (pc 5) — the zero-operand contract
    // holds (b restored to 0 by patch).
    let report = compiler_parity("cp8-merge-if", "(define r (if #t 1 2))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(code (push-const 0 0) (jump-if-false 4 0) (push-const 1 0) \
         (jump 5 0) (push-const 2 0) (store-global 0 0) (halt 0 0))"
    ));
}

#[test]
fn cp8_eval_order_args_then_callee() {
    // The §19.5 eval-order contract: arguments left to right, then
    // the callee; `call n` finds the callee on top.
    let report = compiler_parity("cp8-eval-order", "(define f 1)\n(define r (f 7 8))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(push-const 1 0) (push-const 2 0) (load-global 0 0) (call 2 0)")
    );
}

#[test]
fn cp8_let_slot_lifecycle_in_the_stream() {
    // The binding's value compiles, the slot is allocated (past the
    // params), StoreLocal lands with the binding's span, the body
    // reads the slot, and the scope exit returns it to the free
    // list (the slot-reuse analysis made visible in the stream).
    let report = compiler_parity("cp8-let-slot", "(define (f a) (let ((x 1)) (+ x a)))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(code (push-const 0 0) (store-local 1 0) (load-local 1 0) \
         (load-local 0 0) (load-global 0 0) (call 2 0) (ret 0 0))"
    ));
}

#[test]
fn cp8_assign_emits_dup_then_store_local() {
    // Assignment leaves the value for the enclosing expression:
    // value, dup, then the store — the local face.
    let report = compiler_parity("cp8-assign-local", "(define (f x) (set! x 1))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(code (push-const 0 0) (dup 0 0) (store-local 0 0) (ret 0 0))")
    );
}

#[test]
fn cp8_perform_operand_shape() {
    // Perform's operands: a = the effect name's global index,
    // b = the argument count.
    let report = compiler_parity("cp8-perform", "(define (f x) (perform log x 1))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(code (load-local 0 0) (push-const 0 0) (perform 0 2) (ret 0 0))")
    );
}

#[test]
fn cp8_handler_installation_order_and_pop_count() {
    // Handler values install at entry (one push-handler per clause,
    // in clause order), and the pop carries the clause count.
    let report = compiler_parity(
        "cp8-handlers",
        "(define g (handle (perform log 1) (log (fn (v) v)) (err (fn (w) w))))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(closure 1 0) (push-handler 0 0) (closure 2 0) (push-handler 1 0)")
    );
    assert!(report.oracle.contains("(pop-handler 2 0)"));
}

#[test]
fn cp8_debug_info_dense_per_instruction() {
    // The dense table: one span per emit, in pc order — a
    // hand-built define whose literal span (8..9) differs from the
    // define span (0..9), and the entry halt reuses the last
    // emitted span.
    let items = vec![define_lit("a", LiteralValue::Int(1))];
    let report = compiler_parity_items("cp8-dense-dbg", &items);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("(dbg (sp 8 9) (sp 0 9) (sp 0 9))"));
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn cp8_zero_code_program_anchor_halt() {
    // A program that emits nothing before the terminal halt
    // (define-syntax compiles to zero code — the transformer lives
    // in the expansion environment; a fully empty stream cannot
    // ride the assembled harness because `()` is a read error, the
    // 1.5 input-envelope boundary) — the halt lands at the
    // cold-start anchor span (0 0), the only synthesized span.
    let report = compiler_parity(
        "cp8-zero-code",
        "(define-syntax twofold (syntax-rules (x) ((_ x) 2)))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("(code (halt 0 0)) (dbg (sp 0 0))"));
    assert_eq!(report.oracle, report.krf.as_deref().unwrap_or(""));
}

#[test]
fn cp8_closure_protocol_indices() {
    // The closure operands carry the proto creation indices; the
    // inner proto reads its capture via load-captured with the
    // first-use capture index and its param via load-local.
    let report = compiler_parity("cp8-closure", "(define (adder n) (fn (x) (+ x n)))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .contains("(code (closure 1 0) (store-global 1 0) (halt 0 0))")
    );
    assert!(report.oracle.contains("(code (closure 2 0) (ret 0 0))"));
    assert!(report.oracle.contains(
        "(code (load-local 0 0) (load-captured 0 0) (load-global 0 0) \
         (call 2 0) (ret 0 0))"
    ));
}

#[test]
fn cp8_const_operand_first_use_identity() {
    // The push-const operands are the pool's first-use indices —
    // the duplicate 5 shares slot 0, the 7 takes slot 1 (the
    // same_const_slot rule made visible in the operands).
    let report = compiler_parity(
        "cp8-const-slots",
        "(define a 5)\n(define b 5)\n(define c 7)",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(code (push-const 0 0) (store-global 0 0) (push-const 0 0) \
         (store-global 1 0) (push-const 1 0) (store-global 2 0) (halt 0 0))"
    ));
}

#[test]
fn cp8_pair_const_and_builtin_call_stream() {
    // A quoted pair lands in the pool as one const; the builtin
    // call reads the global table (car) with the call arity.
    let report = compiler_parity(
        "cp8-pair-const",
        "(define a (quote (1 2)))\n(define r (car a))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains(
        "(code (push-const 0 0) (store-global 0 0) (load-global 0 0) \
         (load-global 1 0) (call 1 0) (store-global 2 0) (halt 0 0))"
    ));
}

#[test]
fn cp8_tampered_patch_target_is_caught_on_the_code_axis() {
    // The drift detector over the instruction stream: a tampered
    // patch target produces a finished product whose jump operand
    // disagrees with the oracle's — caught on the code axis (the
    // FP8 lineage: a parity harness that cannot fail is not a
    // harness).
    let tampered = COMPILER_SOURCE.replace("(cp-patch jf (cp-here))", "(cp-patch jf 0)");
    assert_ne!(
        &tampered, COMPILER_SOURCE,
        "the tamper must land on a real anchor"
    );
    let report = compiler_parity_with("cp8-tamper-patch", "(define r (if #t 1 2))", &tampered);
    assert!(!report.matched, "the tampered patch must not pass");
    assert!(report.drift.as_deref().unwrap_or("").contains("oracle"));
}

// ---------- CP9: the composed chain — the 2.3 close-out anchors ----------

/// CP9-1: positive anchors through the full composed chain — the
/// assembled `.krf` expander feeding the `.krf` compiler, one chain,
/// compared against the oracle full pipeline (the fn sugar, the
/// capture order, the transitive chain, effects/handle, let
/// shadowing — the same faces CP2/CP5/CP8 pin segment-wise, here
/// composed end to end: stage-2-plan §2 row 2.3 close-out, §9.85).
#[test]
fn cp9_positive_anchors_through_the_composed_chain() {
    deep_stack(|| {
        let cases = [
            ("cp9-fn-sugar", "(define (f x) (if x 1 2))"),
            (
                "cp9-capture-order",
                "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))",
            ),
            (
                "cp9-transitive",
                "(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))",
            ),
            (
                "cp9-effects",
                "(define r (handle (perform log 1) (log (fn (v) v))))",
            ),
            (
                "cp9-let-shadow",
                "(define r (let ((x 1)) (let ((x (+ x 1))) x)))",
            ),
        ];
        for (name, source) in &cases {
            composed_chain_parity(name, source)
                .unwrap_or_else(|err| panic!("composed chain {name}: {err}"));
        }
    });
}

/// CP9-2: the selfhost fixed points through the composed chain —
/// every front-end source (reader, the assembled expander, the
/// compiler itself, hosting tails stripped per the CP6 structural
/// discipline) expanded by the `.krf` expander and compiled by the
/// `.krf` compiler. The compiler.krf case is the sixth
/// self-application and the first through the full `.krf` chain —
/// the fixpoint precondition of the 2.4 window, demonstrated on the
/// strongest real program in tree.
#[test]
fn cp9_selfhost_fixed_points_through_the_composed_chain() {
    deep_stack(|| {
        let reader_structural = include_str!("../../../../selfhost/v1/reader.krf")
            .replace("\n(define result (rd-loop tokens nil nil))", "");
        let expander_structural =
            assembled_expander_source().replace("\n(define result (ex-run forms))", "");
        let compiler_structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
        assert_ne!(&compiler_structural, COMPILER_SOURCE);
        let cases = [
            ("cp9-selfhost-reader", reader_structural.as_str()),
            (
                "cp9-selfhost-assembled-expander",
                expander_structural.as_str(),
            ),
            ("cp9-selfhost-compiler", compiler_structural.as_str()),
        ];
        for (name, source) in &cases {
            composed_chain_parity(name, source)
                .unwrap_or_else(|err| panic!("composed chain {name}: {err}"));
        }
    });
}

/// CP9-3: the error axis through the chain — neg-057's compile-side
/// rejection (assign to a captured name, the LA-7 boundary) must
/// surface identically on both sides of the composed formula: the
/// oracle pipeline rejects, and the `.krf` chain rejects with the
/// same rebuilt error (the CP4 face, composed).
#[test]
fn cp9_error_axis_assign_to_captured_through_the_chain() {
    deep_stack(|| {
        composed_chain_parity(
            "cp9-assign-to-captured",
            "(define (outer a) (fn (b) (set! a (+ a b))))",
        )
        .unwrap_or_else(|err| panic!("the chain must agree on the boundary error: {err}"));
    });
}

/// CP9-4: the corpus compiler-layer sweep — every corpus file whose
/// oracle read+expand+load succeeds (the same 58-file face CP1's
/// routing pins: the checker-owned negatives included, their
/// analysis products well-defined; neg-057's compile rejection
/// rides the error axis) through the composed chain.
#[test]
fn cp9_corpus_compiler_layer_composed_sweep() {
    deep_stack(|| {
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "krf"))
            .collect();
        files.sort();
        let mut chained = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
            // The routing filter mirrors CP1: reader-layer (8) and
            // expander-layer (19, loader included) rejections belong
            // to the 1.5/1.6 faces; everything else chains here.
            let tree = kerf::reader::read_program(kerf::span::FileId(0), &source)
                .ok()
                .and_then(|forms| kerf::expander::expand_program(&forms).ok())
                .and_then(|items| kerf::expander::load_program(&items).ok().map(|_| items));
            let Some(items) = tree else {
                continue;
            };
            // The loader face is one-way information here: the chain
            // consumes the tree, so the sweep asserts the tree exists
            // (the filter above) and runs the composed formula.
            assert!(
                !items.is_empty(),
                "corpus case {name}: an empty tree never reaches the compiler layer"
            );
            composed_chain_parity(name, &source)
                .unwrap_or_else(|err| panic!("composed chain {name}: {err}"));
            chained += 1;
        }
        assert_eq!(
            chained, 58,
            "the compiler-layer face must stay at the CP1-pinned 58 files"
        );
    });
}

/// CP9-5: the composed chain detects front-end divergence — a
/// tampered expander depth guard (trips at 2 nesting levels, the
/// 1.6 tamper precedent) must fail the chain with the front end's
/// rejection named, never fall through to a product comparison (a
/// harness that cannot fail is not a harness).
#[test]
fn cp9_composed_chain_detects_front_end_divergence() {
    deep_stack(|| {
        let tampered = assembled_expander_source().replace("(>= ex-depth 512)", "(>= ex-depth 2)");
        assert_ne!(
            &tampered,
            &assembled_expander_source(),
            "the tamper must land on a real anchor"
        );
        let err =
            composed_chain_parity_with("cp9-tamper-depth", "(define x (do 1 (do 2 3)))", &tampered)
                .expect_err("the tampered front end must fail the chain");
        assert!(
            err.contains("the .krf expander rejected"),
            "the chain must name the front-end rejection: {err}"
        );
    });
}

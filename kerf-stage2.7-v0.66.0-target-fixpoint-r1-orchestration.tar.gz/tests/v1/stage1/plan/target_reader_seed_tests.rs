//! Target-skin reader seed tests (Stage 2.7, switch-window step 1 —
//! stage0.md §9.94, docs/develop/v2/switch-window-plan.md).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The parity contract (§9.25.4 BS-C, the semantic-safety-net
//! layering): the same program in the two skins — the
//! S-expression face and the v9 Level 0 target face — produces the
//! *identical semantic bytecode projection* (per-function shape and
//! instruction streams, the constant pool, the global table —
//! everything except `debug_info`, whose spans necessarily differ
//! between two different source texts) and both run to the same
//! values. Byte-level comparison including `debug_info` is reserved
//! for the same-syntax fixpoint faces (gate B); the cross-skin face
//! asserts the projection plus behavior.

use kerf::compiler::{Bytecode, CaptureSource, Instr, compile_program};
use kerf::core::LiteralValue;
use kerf::expander::expand_program;
use kerf::reader::{ReadError, read_program, read_target_program};
use kerf::span::FileId;
use kerf::vm::{Value, Vm};

const FILE: FileId = FileId(0);

fn compile_sexpr(src: &str) -> Bytecode {
    let forms = read_program(FILE, src).expect("S-expression source must read");
    let items = expand_program(&forms).expect("S-expression source must expand");
    compile_program(&items).expect("S-expression source must compile")
}

fn compile_target(src: &str) -> Bytecode {
    let forms = read_target_program(FILE, src).expect("target source must read");
    let items = expand_program(&forms).expect("target source must expand");
    compile_program(&items).expect("target source must compile")
}

fn run_target(src: &str) -> Vm {
    let mut vm = Vm::new(compile_target(src)).expect("verified product loads");
    vm.run().expect("target program runs");
    vm
}

/// The span-free projection of one function proto.
#[derive(Debug, PartialEq)]
struct SemanticProto<'a> {
    name: Option<&'a str>,
    params: u32,
    n_locals: u32,
    captures: Vec<CaptureSource>,
    code: Vec<Instr>,
}

/// The semantic projection of a bytecode product: per-function shape
/// and instruction streams, the constant pool and the global table —
/// everything the two skins of one program must share. `debug_info`
/// spans encode *where in each skin* and are excluded by the §9.25.4
/// layering.
#[derive(Debug, PartialEq)]
struct SemanticBytecode<'a> {
    funcs: Vec<SemanticProto<'a>>,
    consts: Vec<LiteralValue>,
    globals: Vec<&'a str>,
}

fn semantic(bc: &Bytecode) -> SemanticBytecode<'_> {
    SemanticBytecode {
        funcs: bc
            .funcs
            .iter()
            .map(|f| SemanticProto {
                name: f.name.as_ref().map(|s| s.as_str()),
                params: f.params,
                n_locals: f.n_locals,
                captures: f.captures.clone(),
                code: f.code.clone(),
            })
            .collect(),
        consts: bc.consts.clone(),
        globals: bc.globals.iter().map(|s| s.as_str()).collect(),
    }
}

// ---------- cross-stage consumption: the parity contract ----------

#[test]
fn parity_fib_across_skins_is_semantically_identical() {
    // The §9.25.4 BS-C anchor: the fn skin, the if skin, recursion,
    // both comparison and arithmetic operators — one semantic
    // bytecode.
    let sexpr =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
    let target = "fn fib(n: i64) -> i64 { if n < 2 { n } else { fib(n - 1) + fib(n - 2) } } define(r, fib(10));";
    let bc_sexpr = compile_sexpr(sexpr);
    let bc_target = compile_target(target);
    assert_eq!(
        semantic(&bc_target),
        semantic(&bc_sexpr),
        "the two skins of one program must produce one semantic bytecode"
    );
    let mut vm = Vm::new(bc_target).expect("verified product loads");
    vm.run().expect("target program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(55)));
}

#[test]
fn parity_let_blocks_and_operators_across_skins() {
    // The do/let fold, the multi-binding comma form, the !=/== skin
    // and the assignment statement — every mapping that differs in
    // Stx shape but converges in CoreExpr.
    let sexpr = r#"
        (define x 3)
        (define r (let ((a 1) (b 2))
          (do (set! x (+ x a))
              (if (not (= x 0)) (* x 10) 0))))
        (define s (if (= x 4) 1 0))
    "#;
    let target = r#"
        define(x, 3);
        define(r, {
            let a = 1, b = 2;
            x = x + a;
            if x != 0 { x * 10 } else { 0 }
        });
        define(s, if x == 4 { 1 } else { 0 });
    "#;
    assert_eq!(
        semantic(&compile_target(target)),
        semantic(&compile_sexpr(sexpr)),
        "let/block/operator skins must converge to one semantic bytecode"
    );
    let vm = run_target(target);
    assert_eq!(vm.global("r"), Some(&Value::Int(40)));
    assert_eq!(vm.global("s"), Some(&Value::Int(1)));
}

#[test]
fn parity_effects_closures_and_quotes_across_skins() {
    // The effect face (perform/handle/resume), the closure skin, the
    // call-form rules (define/quote) and the unit skin (`()` is nil
    // on the S-expression face — ruling C12). The quote payload is a
    // literal datum — symbol data fails at the expander's value-model
    // gate in *both* skins (reader-level parity keeps the reader
    // permissive; the expander is the gate).
    // The pair names ride the E5 batch-2 separator rule: the
    // target face's `make_adder` IS the S-expr face's `make-adder`
    // (rule K — ruling E2; the r98 `make_adder` spelling was a
    // pre-batch-2 boundary case updated by the step-3 round).
    let sexpr = r#"
        (define (make-adder n) (fn (x) (+ x n)))
        (define add3 (make-adder 3))
        (define r (handle (perform add 1 2) (add (fn (a b) (+ a b)))))
        (define u (quote 1))
        (define z nil)
    "#;
    let target = r#"
        fn make_adder(n: i64) -> i64 { ||(x) { x + n } }
        define(add3, make_adder(3));
        define(r, handle perform add(1, 2) { add(a, b) => resume(a + b), });
        define(u, quote(1));
        define(z, ());
    "#;
    assert_eq!(
        semantic(&compile_target(target)),
        semantic(&compile_sexpr(sexpr)),
        "effect/closure/quote/unit skins must converge to one semantic bytecode"
    );
    let vm = run_target(target);
    assert_eq!(vm.global("r"), Some(&Value::Int(3)));
    assert!(matches!(vm.global("add3"), Some(Value::Closure(_))));
}

// ---------- positive: full-chain value faces ----------

#[test]
fn target_skin_program_runs_the_whole_pipeline() {
    // A realistic target-skin program: declarations, closures as
    // arguments (the Fn annotation face), nested branching — read,
    // expanded, compiled, executed; values observed at the global
    // face (the same observation contract as the Stage 0 seeds).
    let src = r#"
        fn clamp(v: i64, lo: i64, hi: i64) -> i64 {
            if v < lo { lo } else { if v > hi { hi } else { v } }
        }
        fn twice(f: Fn(i64) -> i64, v: i64) -> i64 { f(f(v)) }
        define(r, twice(||(x) { x + 1 }, 5));
        define(s, clamp(15, 0, 10));
    "#;
    let vm = run_target(src);
    assert_eq!(vm.global("r"), Some(&Value::Int(7)));
    assert_eq!(vm.global("s"), Some(&Value::Int(10)));
}

#[test]
fn target_skin_module_and_use_forms_expand() {
    // The module skin and the transitional string-use form: the
    // mapping rides the S-expression declaration faces, so the
    // expander accepts them unchanged.
    let src = r#"
        use "math";
        module inner {
            fn f(x: i64) -> i64 { x * 2 }
        }
        define(r, 1);
    "#;
    let vm = run_target(src);
    assert_eq!(vm.global("r"), Some(&Value::Int(1)));
}

// ---------- negative: the seed-scope boundary (fail-closed) ----------

#[test]
fn out_of_scope_forms_fail_closed_with_the_registered_error() {
    // The step-2 registered productions reject with the dedicated
    // variant — never a silent acceptance, never a wrong-tree parse.
    // (match is core-mapped as of r99 — its registered faces are the
    // guard/or-pattern/3-tuple family, asserted in the step-2 block
    // below; the fn-head generic parameter declaration keeps the
    // registered-gap rejection — the tick form has no lexical token.)
    for (src, form) in [
        ("struct P { x: i64, }", "type declarations"),
        ("enum E { A, B, }", "type declarations"),
        ("effect E { op() -> i64, }", "type declarations"),
        ("capability C { fn f() -> i64; }", "type declarations"),
        ("fn f<T>(x: T) { 1 }", "generic parameters"),
        ("define(r, a[0]);", "index expression"),
        ("define(r, a.f);", "field or method access"),
        ("define(r, a as i64);", "cast expression"),
        ("define(r, 1..5);", "range expression"),
        (
            "define(r, handle perform E() { E => halt, });",
            "halt handler body",
        ),
    ] {
        let err = match read_target_program(FILE, src) {
            Err(err) => err,
            Ok(_) => panic!("`{src}` must reject"),
        };
        match &err {
            ReadError::UnsupportedTargetForm { form: got, .. } => {
                assert_eq!(got, &form, "`{src}` must carry its registered form name");
            }
            other => panic!("`{src}` must be an UnsupportedTargetForm, got {other}"),
        }
    }
}

#[test]
fn target_lexical_and_structural_errors_are_the_shared_surface() {
    // The shared error surface: the literal family and the delimiter
    // family reject with the registered variants and byte-precise
    // payloads.
    let err = read_target_program(FILE, "define(r, 0x);").expect_err("radix body rejects");
    assert!(matches!(err, ReadError::MalformedNumber { .. }));
    let err = read_target_program(FILE, "define(r, 1.8e308);").expect_err("float overflow rejects");
    assert!(matches!(err, ReadError::FloatOutOfRange { .. }));
    let err = read_target_program(FILE, "define(r, \"open);").expect_err("open string rejects");
    assert!(matches!(err, ReadError::UnterminatedString { .. }));
    let err = read_target_program(FILE, "fn f() { 1").expect_err("open block rejects");
    assert!(matches!(
        err,
        ReadError::UnclosedTargetDelim { opening: "{", .. }
    ));
    let err = read_target_program(FILE, "fn 1() { 1 }").expect_err("bad fn name rejects");
    assert!(matches!(err, ReadError::UnexpectedTargetToken { .. }));
}

#[test]
fn non_declaration_items_parse_but_fail_at_the_expander_gate() {
    // Parity of the *gate*: a top-level expression statement reads
    // fine in both skins and both fail at the expander's declaration
    // gate — the target reader is exactly as permissive as the
    // S-expression reader, no more.
    let target = "f(1);";
    let sexpr = "(f 1)";
    let target_forms = read_target_program(FILE, target).expect("target reads");
    let sexpr_forms = read_program(FILE, sexpr).expect("S-expression reads");
    assert_eq!(target_forms.len(), sexpr_forms.len());
    assert!(expand_program(&target_forms).is_err());
    assert!(expand_program(&sexpr_forms).is_err());
}

// ---------- switch-window step 2 (r99): match, use paths, E5 batch 1 ----------

#[test]
fn parity_match_across_skins_is_semantically_identical() {
    // Ruling A: `match n { 0 => 100, _ => 200 }` on the target skin
    // desugars to the carrier-let + `=` test chain; the S-expr face
    // hand-writes the same chain over an ordinary name (the carrier
    // spelling is unwritable there — `(` terminates atoms — but the
    // projection is name-insensitive: locals are slots, not names).
    let target = r#"
        fn classify(n: i64) -> i64 {
            match n { 0 => { 100 }, _ => { 200 }, }
        }
        define(r, classify(0));
        define(s, classify(9));
    "#;
    let sexpr = r#"
        (define (classify n) (let ((s n)) (if (= s 0) 100 200)))
        (define r (classify 0))
        (define s (classify 9))
    "#;
    let t = compile_target(target);
    let x = compile_sexpr(sexpr);
    assert_eq!(semantic(&t), semantic(&x));
    let mut vm = Vm::new(t).expect("verified product loads");
    vm.run().expect("match program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(100)));
    assert_eq!(vm.global("s"), Some(&Value::Int(200)));
}

#[test]
fn match_tuple_and_literal_arms_run_with_fallthrough() {
    // The pattern family end-to-end: literal arms fall through, the
    // tuple arm destructures (cons-built scrutinee), the nil arm and
    // the binding tail each take their turn. The arm order exercises
    // the chain shape (ruling A′ guarantees the tail catches all).
    let target = r#"
        fn pick(p: Pair<i64, i64>) -> i64 {
            match p { (a, b) => { a + b }, nil => { 0 }, _ => { 1 }, }
        }
        define(r, pick(cons(2, 3)));
        define(s, pick(nil));
    "#;
    let vm = run_target(target);
    assert_eq!(vm.global("r"), Some(&Value::Int(5)));
    assert_eq!(vm.global("s"), Some(&Value::Int(0)));
}

#[test]
fn parity_use_path_form_and_e5_batch1_names() {
    // Ruling D: `use a::b::c;` maps through C-C1 to the require
    // string form. Ruling E: `read_line`/`write_line` ride the snake
    // skin on the target face and land on the kebab Stage 0 globals —
    // both faces project identically (the global table shares names).
    let target = r#"
        use a::b::c;
        define(r, read_line());
    "#;
    let sexpr = r#"
        (require "a/b/c")
        (define r (read-line))
    "#;
    // Ruling E lands the snake skin on the kebab Stage 0 globals —
    // both faces share the global table names and the instruction
    // streams; behavior equality of the I/O face is the AA10 audit
    // case's domain, so the parity claim here is the projection.
    let t = compile_target(target);
    let x = compile_sexpr(sexpr);
    assert_eq!(semantic(&t), semantic(&x));
}

#[test]
fn parity_generic_argument_annotations_drop() {
    // Ruling C1 second half: adt_type generic arguments are
    // annotation surface — `Foo<i64>` drops together with the type,
    // so both skins compile to the same define.
    let target = "fn id(x: Foo<i64>) -> Bar<Baz> { x } define(r, id(5));";
    let sexpr = "(define (id x) x) (define r (id 5))";
    let t = compile_target(target);
    let x = compile_sexpr(sexpr);
    assert_eq!(semantic(&t), semantic(&x));
    let mut vm = Vm::new(t).expect("verified product loads");
    vm.run().expect("generic-annotation program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(5)));
}

#[test]
fn match_shadowing_and_nested_carriers_stay_hygienic() {
    // A pattern binding legitimately shadows an outer name (the arm
    // scope discipline), and a nested match keeps its carrier
    // lexically inside the outer arm body — the `(`
    // unwritable-carrier design holds under nesting.
    let target = r#"
        define(x, 7);
        define(r,
            match x {
                1 => { 0 },
                x => { match x { 7 => { 70 }, _ => { 99 }, } },
            }
        );
    "#;
    let vm = run_target(target);
    // The binding arm rebinds x=7 → the inner match sees 7 → 70.
    assert_eq!(vm.global("r"), Some(&Value::Int(70)));
}

#[test]
fn step2_out_of_scope_forms_fail_closed() {
    // The step-2 registered faces: guards, or-patterns, 3+-tuples,
    // the non-exhaustive tail, use trees and aliases — each rejects
    // with its registered error text (never silence).
    let read_rejects: &[(&str, &str)] = &[
        (
            "define(r, match x { 1 if x > 0 => { 1 }, _ => { 2 }, });",
            "match arm guards",
        ),
        (
            "define(r, match x { 1 | 2 => { 1 }, _ => { 2 }, });",
            "or-patterns",
        ),
        (
            "define(r, match x { (a, b, c) => { 1 }, _ => { 2 }, });",
            "tuple patterns with three or more elements",
        ),
        ("use a::{b, c};", "use tree or alias forms"),
        ("use a::b as c;", "use tree or alias forms"),
    ];
    for (src, form) in read_rejects {
        let err =
            read_target_program(FILE, src).expect_err("registered face must reject at read time");
        assert!(
            matches!(&err, ReadError::UnsupportedTargetForm { form: f, .. } if f == form),
            "src `{src}` must reject as `{form}`, got {err}"
        );
    }
    // The non-exhaustive tail rejects at expansion time (the reader
    // cannot see it — any pattern parses; the expander checks the
    // last arm's shape).
    let forms = read_target_program(FILE, "define(r, match x { 1 => { 10 }, });")
        .expect("non-exhaustive match reads (the reader accepts the shape)");
    let err =
        expand_program(&forms).expect_err("non-exhaustive match must reject at expansion time");
    assert!(
        err.to_string().starts_with("match is not exhaustive"),
        "expected the non-exhaustive face, got {err}"
    );
}

// ---------- step 3: the E5 batch-2 skin and the quote datum carrier ----------

#[test]
fn parity_e5_batch2_pair_family_and_kebab_names_across_skins() {
    // Ruling E2: the modern pair-family spellings (first/rest/pair/
    // eq + the is_ predicates) and the kebab separator rule map the
    // target face onto the Stage 0 global names — one semantic
    // bytecode, one value face.
    let target = r#"
        fn rd_rev(lst, acc) {
            if is_nil(lst) { acc } else { rd_rev(rest(lst), pair(first(lst), acc)) }
        }
        define(r, rd_rev(quote((1, 2, 3)), nil));
        define(s, eq(first(quote((9, 8))), 9));
    "#;
    let sexpr = r#"
        (define (rd-rev lst acc)
            (if (nil? lst) acc (rd-rev (cdr lst) (cons (car lst) acc))))
        (define r (rd-rev (quote (1 2 3)) nil))
        (define s (eq? (car (quote (9 8))) 9))
    "#;
    let t = compile_target(target);
    let x = compile_sexpr(sexpr);
    assert_eq!(
        semantic(&t),
        semantic(&x),
        "the E5 batch-2 skin must converge with the S-expr face"
    );
    let mut vm = Vm::new(t).expect("verified product loads");
    vm.run().expect("batch-2 program runs");
    assert_eq!(vm.global("s"), Some(&Value::Bool(true)));
    // r = the reversed (3 2 1) chain.
    assert!(matches!(vm.global("r"), Some(Value::Pair(..))));
}

#[test]
fn parity_quoted_record_tables_across_skins() {
    // Ruling F: the quote datum carrier — the corpus lexicon's
    // record tables (`(quote ("+" "-" ...))`, `(quote (57 50 ...))`)
    // ride the tuple skin; the constant pools and the pair-chain
    // values agree with the S-expr originals.
    let target = r#"
        define(ops, quote(("+", "-", "*", "/", "<", "<=", ">", ">=", "=")));
        define(lx_max_pos, quote((57, 50, 50, 51)));
        define(r, first(lx_max_pos));
        define(s, first(rest(ops)));
    "#;
    let sexpr = r#"
        (define ops (quote ("+" "-" "*" "/" "<" "<=" ">" ">=" "=")))
        (define lx-max-pos (quote (57 50 50 51)))
        (define r (car lx-max-pos))
        (define s (car (cdr ops)))
    "#;
    let t = compile_target(target);
    let x = compile_sexpr(sexpr);
    assert_eq!(
        semantic(&t),
        semantic(&x),
        "quoted record tables must converge through the datum carrier"
    );
    let mut vm = Vm::new(t).expect("verified product loads");
    vm.run().expect("record-table program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(57)));
    assert_eq!(vm.global("s"), Some(&Value::Str(std::rc::Rc::from("-"))));
}

#[test]
fn quote_carrier_fail_closed_faces() {
    // The datum carrier's fail-closed family: expressions in datum
    // position, the empty list datum, and the two-datum call.
    let cases: &[(&str, &str)] = &[
        (
            "define(r, quote((1 + 2)));",
            "quote carries data, not expressions",
        ),
        (
            "define(r, quote(()));",
            "the empty quoted list (write `nil`",
        ),
    ];
    for (src, form) in cases {
        let err =
            read_target_program(FILE, src).expect_err("the datum carrier must reject fail-closed");
        assert!(
            matches!(&err, ReadError::UnsupportedTargetForm { form: f, .. } if f.starts_with(form)),
            "src `{src}` must reject as `{form}`, got {err}"
        );
    }
    // Quote takes exactly one datum — a second datum is the same
    // data-only rejection; the empty call is the plain call face.
    let err = read_target_program(FILE, "define(r, quote(1, 2));")
        .expect_err("quote takes exactly one datum");
    assert!(
        matches!(&err, ReadError::UnsupportedTargetForm { form: f, .. }
            if *f == "quote carries data, not expressions"),
        "expected the data-only rejection, got {err}"
    );
    let err = read_target_program(FILE, "define(r, quote());").expect_err("the empty call rejects");
    assert!(matches!(err, ReadError::UnexpectedTargetToken { .. }));
}

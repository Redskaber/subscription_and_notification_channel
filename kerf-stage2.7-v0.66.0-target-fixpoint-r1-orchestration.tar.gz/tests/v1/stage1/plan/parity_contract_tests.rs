//! Stage 1.4 parity-contract integration tests — the BS-C Stage 1.4
//! slice through the real driver faces (stage-1-plan row 1.4;
//! docs/stage0.md §9.45.6, §9.25.4).
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: hand-built cases that must match (the contract's
//!   happy paths across all six expectation forms).
//! - **Negative**: wrong expectations the contract must flag (the
//!   detector-detects duality — every drift note carries both
//!   sides).
//! - **Cross-stage consumption**: the contract over the *existing*
//!   pipeline faces (`run_parity`'s `globals_repr`, the module-face
//!   rejection routing, the checker's dual-severity split).

use kerf::driver::{
    CorpusCase, Engine, Expectation, Observed, Session, parse, parse_directive, run_parity_source,
    validate,
};

/// Build a case from inline source (the test-side convenience face).
fn case<'a>(name: &'a str, source: &'a str) -> CorpusCase<'a> {
    CorpusCase::from_source(name, source).expect("directive parses")
}

// ---------- positive: the contract's happy paths ----------

#[test]
fn halt_case_matches_value_and_reads_last_define() {
    let report = validate(&case(
        "halt",
        ";; expect: value 2\n(define a 1)\n(define result 2)",
    ));
    assert!(report.matched, "drift: {:?}", report.drift);
    assert_eq!(
        report.observed,
        Observed::Halted {
            last_repr: "2".to_owned()
        }
    );
}

#[test]
fn runtime_rejection_case_matches_dual_engine_agreement() {
    let report = validate(&case("rt", ";; expect: runtime-error\n(define r (/ 1 0))"));
    assert!(report.matched, "drift: {:?}", report.drift);
    assert_eq!(
        report.observed,
        Observed::Rejected {
            stage: "kerf-runtime".to_owned(),
            codes: Vec::new(),
        }
    );
}

#[test]
fn warning_case_matches_codes_and_value() {
    let report = validate(&case(
        "warn",
        ";; expect: warning E0008 value 1\n(define r (do (set! car 5) 1))",
    ));
    assert!(report.matched, "drift: {:?}", report.drift);
    assert_eq!(
        report.observed,
        Observed::Halted {
            last_repr: "1".to_owned()
        }
    );
}

#[test]
fn type_error_case_matches_exact_code_set() {
    let report = validate(&case(
        "ty",
        ";; expect: type-error E0002\n(define (f x) x)\n(define r (f 1 2))",
    ));
    assert!(report.matched, "drift: {:?}", report.drift);
    match &report.observed {
        Observed::Rejected { stage, codes } => {
            assert_eq!(stage, "E0002");
            assert_eq!(codes, &["E0002".to_owned()]);
        }
        other => panic!("expected a checker rejection, observed {other:?}"),
    }
}

// ---------- negative: wrong expectations must drift ----------

#[test]
fn wrong_value_drifts_with_both_reprs() {
    let report = validate(&case("wv", ";; expect: value 99\n(define result (+ 1 2))"));
    assert!(!report.matched);
    let drift = report.drift.expect("drift note present");
    assert!(
        drift.contains("`99`") && drift.contains("`3`"),
        "drift: {drift}"
    );
}

#[test]
fn halt_expected_but_checker_rejects_drifts() {
    let report = validate(&case(
        "hc",
        ";; expect: value 3\n(define result (if 1 2 3))",
    ));
    assert!(!report.matched);
    assert!(report.drift.unwrap().contains("checker rejected"));
}

#[test]
fn runtime_expected_but_engines_halt_drifts() {
    let report = validate(&case(
        "rh",
        ";; expect: runtime-error\n(define result (+ 1 2))",
    ));
    assert!(!report.matched);
    assert!(report.drift.unwrap().contains("both engines halted"));
}

#[test]
fn wrong_rejection_stage_drifts_with_observed_tag() {
    let report = validate(&case(
        "rs",
        ";; expect: parse-error\n(define result (quote sym))",
    ));
    assert!(!report.matched);
    match report.observed {
        Observed::Rejected { ref stage, .. } => assert_eq!(stage, "kerf-expand"),
        ref other => panic!("expected a rejection, observed {other:?}"),
    }
}

#[test]
fn missing_warning_drifts_named() {
    let report = validate(&case(
        "mw",
        ";; expect: warning E0008 value 3\n(define result (+ 1 2))",
    ));
    assert!(!report.matched);
    let drift = report.drift.unwrap();
    assert!(drift.contains("expected warning codes"), "drift: {drift}");
}

// ---------- cross-stage consumption ----------

#[test]
fn parity_report_exposes_globals_repr_in_program_order() {
    let mut session = Session::new();
    let report = run_parity_source(
        &mut session,
        "order.krf",
        "(define a 1)\n(define b 2)\n(define result (+ a b))",
        &[],
    )
    .expect("parity runs");
    assert!(report.agrees(), "engines agree");
    let names: Vec<&str> = report
        .globals_repr
        .iter()
        .map(|(n, _)| n.as_str())
        .collect();
    assert_eq!(names, ["a", "b", "result"], "program order preserved");
    assert_eq!(report.globals_repr[2].1, "3", "last define repr");
}

#[test]
fn module_face_rejections_route_to_the_expand_tag() {
    // The module loader's failures (cycle / missing / duplicate)
    // render under the expand tag — the Stage 0.9 wiring the
    // contract's ExpandError bucket depends on.
    for src in [
        "(module a (require b))\n(module b (require a))",
        "(require ghost)",
        "(module m (define x 1))\n(module m (define x 2))",
    ] {
        let mut session = Session::new();
        let diags = parse(&mut session, "m.krf", src).expect_err("module face rejects");
        assert_eq!(
            diags[0].code.tag(),
            "kerf-expand",
            "loader routes to expand tag"
        );
    }
}

#[test]
fn dual_engine_run_face_still_agrees_on_a_shared_program() {
    // The run face (one engine at a time) and the parity face
    // observe the same halt values — the contract consumes both.
    let mut session = Session::new();
    let program = parse(&mut session, "shared.krf", "(define result (* 6 7))").expect("parses");
    let vm = program
        .run(
            Engine::Vm,
            Box::new(kerf::vm::BufferIo::with_input(std::iter::empty::<String>())),
        )
        .expect("vm halts");
    let eval = program
        .run(
            Engine::Eval,
            Box::new(kerf::vm::BufferIo::with_input(std::iter::empty::<String>())),
        )
        .expect("eval halts");
    assert_eq!(vm.value, eval.value, "both engines halt on the same value");
    // Define-only modules halt with `nil` as the program value; the
    // observable result lives in the globals snapshot.
    assert_eq!(vm.value.to_string(), "nil");
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some("42".to_owned())
    );
    assert_eq!(
        eval.global("result").map(|v| v.to_string()),
        Some("42".to_owned())
    );
}

#[test]
fn directive_grammar_is_closed() {
    assert!(parse_directive(";; expect: telepathy").is_err());
    assert!(parse_directive(";; expect: value").is_err());
    assert!(parse_directive("(define x 1)").is_err());
    assert_eq!(
        parse_directive(";; expect: type-error E0002 E0004"),
        Ok(Expectation::TypeError(vec![
            "E0002".to_owned(),
            "E0004".to_owned()
        ]))
    );
}

#[test]
fn batch_face_maps_reports_one_to_one() {
    let cases = [
        case("b1", ";; expect: value 3\n(define result (+ 1 2))"),
        case("b2", ";; expect: parse-error\n("),
        case("b3", ";; expect: runtime-error\n(define r (/ 1 0))"),
    ];
    let reports = kerf::driver::validate_all(cases.iter());
    assert_eq!(reports.len(), 3);
    assert!(reports.iter().all(|r| r.matched));
    assert_eq!(reports[0].case, "b1");
    assert_eq!(
        reports[2].observed,
        Observed::Rejected {
            stage: "kerf-runtime".to_owned(),
            codes: Vec::new(),
        }
    );
}

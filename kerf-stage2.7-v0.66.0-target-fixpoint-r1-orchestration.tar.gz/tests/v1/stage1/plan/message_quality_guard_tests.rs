//! Message-quality family guards (§9.78 MSG-1..MSG-4 — the diagnostic
//! message content-quality domain, cross-crate consumer face).
//!
//! Three machine-checked invariants that span crates and therefore
//! live at the root (SOP §8.4.6 / §9.1 — cross-crate assertions never
//! go inside a crate's own tree):
//!
//! 1. **MSG-3 wording-family agreement** — the arity-mismatch family
//!    renders with one shape across its three producers:
//!    `RuntimeError::ArityMismatch` (kerf-vm, the runtime face) and
//!    the checker's R2 (`E0002`, named + anonymous arms) and R5
//!    (`E0005`, handler arm) — same count phrase, same singular /
//!    plural discipline (K182: rustc E0061 `this function takes 1
//!    argument but 2 arguments were supplied`). Before v0.47.0 the
//!    three sites mirrored each other by hand (documented
//!    convention); this guard upgrades the convention to a
//!    machine-checked agreement.
//! 2. **MSG-2 cross-engine demanded-kind agreement** — the two
//!    engines render the same `TypeMismatch` text for the two
//!    evaluator-direct faces (`jump-if-false condition`,
//!    `call callee`): the demanded wording rides the shared
//!    `kerf_vm::error::demanded` constants, and the end-to-end run
//!    proves the two engines raise the identical message (the
//!    builtin faces already carry this pin through DISPATCH_PROBES).
//! 3. **MSG-2 demanded-kind presence** — a real runtime kind mismatch
//!    names what the operation demands (`must be a bool`), never the
//!    pre-v0.47.0 hedge (`must be a matching kind`).

use kerf_core::ModuleItem;
use kerf_reader::read_program;
use kerf_span::FileId;
use kerf_vm::{RuntimeError, Vm, plural_args};

use kerf::typecheck::{Externals, TypeCode, check_module};
use kerf_runtime::Evaluator;

// ---------- shared pipeline helpers (the typecheck_seed_tests pattern) ----------

fn builtin_externals() -> Externals {
    Externals::from_named_arities(
        kerf_vm::Builtin::ALL
            .iter()
            .map(|(_, name, arity)| (*name, Some(*arity))),
    )
}

fn check_source(source: &str) -> Vec<kerf::typecheck::TypeDiagnostic> {
    let forms = read_program(FileId(0), source).expect("source must read");
    let items: Vec<ModuleItem> = kerf_expander::expand_program(&forms).expect("source must expand");
    check_module(&items, &builtin_externals())
}

fn items_of(source: &str) -> Vec<ModuleItem> {
    let forms = read_program(FileId(0), source).expect("source must read");
    kerf_expander::expand_program(&forms).expect("source must expand")
}

// ---------- MSG-3: the three-site arity wording family ----------

/// The runtime face and the checker's R2 named arm agree byte for
/// byte on the same (expected=1, actual=2) mismatch — both singular.
#[test]
fn arity_wording_family_agrees_on_the_singular_count() {
    // §9.78 MSG-3 (K182 E0061): the count phrase agrees with its
    // number — `1 argument`, never `1 arguments`.
    let runtime = RuntimeError::ArityMismatch {
        func: Some(kerf_span::Symbol::new("f").expect("fixture symbol")),
        expected: 1,
        actual: 2,
        span: kerf_span::Span::new(
            FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
            kerf_span::ExpansionId::ROOT,
        )
        .expect("fixture span"),
    }
    .to_string();
    assert_eq!(runtime, "arity mismatch: `f` expects `1` argument, got `2`");

    let diags = check_source("(define (f x) x) (define r (f 1 2))");
    assert_eq!(diags.len(), 1, "exactly the R2 finding");
    assert_eq!(diags[0].code, TypeCode::ArityMismatch);
    assert_eq!(
        diags[0].message, "arity mismatch: `f` expects `1` argument, got `2`",
        "R2 named arm must mirror the runtime face on the singular count"
    );

    // The checker's R2 anonymous arm carries the same discipline.
    let anon = check_source("(define r ((fn (x) x) 1 2))");
    assert_eq!(anon.len(), 1, "exactly the anonymous R2 finding");
    assert_eq!(
        anon[0].message, "arity mismatch: function expects `1` argument, got `2`",
        "R2 anonymous arm must pluralize identically"
    );
}

/// The plural side of the family (expected=2) stays plural everywhere.
#[test]
fn arity_wording_family_agrees_on_the_plural_count() {
    let runtime = RuntimeError::ArityMismatch {
        func: Some(kerf_span::Symbol::new("g").expect("fixture symbol")),
        expected: 2,
        actual: 3,
        span: kerf_span::Span::new(
            FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
            kerf_span::ExpansionId::ROOT,
        )
        .expect("fixture span"),
    }
    .to_string();
    assert_eq!(
        runtime,
        "arity mismatch: `g` expects `2` arguments, got `3`"
    );

    let diags = check_source("(define (g a b) a) (define r (g 1 2 3))");
    assert_eq!(diags.len(), 1, "exactly the R2 finding");
    assert_eq!(
        diags[0].message, "arity mismatch: `g` expects `2` arguments, got `3`",
        "R2 named arm must stay plural for 2"
    );

    // The handler arm (R5) pluralizes with the same discipline: the
    // perform supplies 2 args, the handler takes 1 param.
    let handler = check_source("(define x (handle (perform log 1 2) (log (fn (a) a))))");
    assert_eq!(handler.len(), 1, "exactly the R5 finding");
    assert_eq!(handler[0].code, TypeCode::HandlerArityMismatch);
    assert_eq!(
        handler[0].message,
        "handler arity mismatch: handler for `log` expects `1` argument, got `2`",
        "R5 must pluralize identically to R2 and the runtime face"
    );
}

/// The plural helper is exported for exactly this family discipline
/// (kerf-vm is the single source; the checker's inline copies are
/// pinned to it by the two agreement tests above).
#[test]
fn plural_args_helper_covers_the_count_family() {
    assert_eq!(plural_args(1), "argument");
    assert_eq!(plural_args(0), "arguments");
    assert_eq!(plural_args(2), "arguments");
    assert_eq!(plural_args(u32::MAX), "arguments");
}

// ---------- MSG-2: cross-engine demanded-kind agreement ----------

/// The evaluator-direct `jump-if-false condition` face renders
/// byte-identically on both engines and names the demanded kind.
#[test]
fn jump_if_false_mismatch_agrees_across_engines_and_names_the_demand() {
    // A computed (non-literal) int condition passes the checker's
    // literal-only E0003 and fails at runtime on both engines.
    let source = "(define r (if (car (quote (3))) 1 2))";
    let diags = check_source(source);
    assert!(diags.is_empty(), "no static finding: {diags:?}");

    let items = items_of(source);
    let bc = kerf_compiler::compile_program(&items).expect("verified product loads");
    let mut vm = Vm::new(bc).expect("vm loads");
    let vm_err = match vm.run() {
        Err(err) => err,
        Ok(_) => panic!("vm path must reject the int condition"),
    };
    let mut ev = Evaluator::new();
    let ev_err = match ev.eval_program(&items) {
        Err(err) => err,
        Ok(_) => panic!("eval path must reject the int condition"),
    };

    assert_eq!(
        vm_err.to_string(),
        ev_err.to_string(),
        "the two engines must render the identical message"
    );
    let msg = vm_err.to_string();
    assert_eq!(
        msg, "type mismatch: jump-if-false condition must be a bool, got `int`",
        "the demanded kind is named, never a hedge"
    );
    assert!(
        !msg.contains("matching kind"),
        "the pre-v0.47.0 hedge must be gone: {msg}"
    );
}

/// The evaluator-direct `call callee` face renders byte-identically
/// on both engines and names the demanded kind.
#[test]
fn call_callee_mismatch_agrees_across_engines_and_names_the_demand() {
    // Calling the car of a pair: the callee is computed (not a
    // literal), so the static R4 does not fire and both engines
    // reject at the call with the identical message.
    let source = "(define r ((car (cons 7 nil)) 1))";
    let diags = check_source(source);
    assert!(
        diags.iter().all(|d| d.code != TypeCode::NonCallableCallee),
        "no static R4 on the computed callee: {diags:?}"
    );

    let items = items_of(source);
    let bc = kerf_compiler::compile_program(&items).expect("verified product loads");
    let mut vm = Vm::new(bc).expect("vm loads");
    let vm_err = match vm.run() {
        Err(err) => err,
        Ok(_) => panic!("vm path must reject the int callee"),
    };
    let mut ev = Evaluator::new();
    let ev_err = match ev.eval_program(&items) {
        Err(err) => err,
        Ok(_) => panic!("eval path must reject the int callee"),
    };

    assert_eq!(
        vm_err.to_string(),
        ev_err.to_string(),
        "the two engines must render the identical message"
    );
    assert_eq!(
        vm_err.to_string(),
        "type mismatch: call callee must be a closure or builtin, got `int`",
        "the demanded kind is named"
    );
}

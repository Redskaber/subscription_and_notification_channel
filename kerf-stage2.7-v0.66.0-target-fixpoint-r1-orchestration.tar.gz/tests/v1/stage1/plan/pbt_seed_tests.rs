//! Stage 1.2 PBT seed tests (property-based testing — DEA-13 closure).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The three first-arrival invariant families of docs/stage0.md
//! §9.34.5 (MRES-E-1), per the stage-1-plan §5 ruling: primitive
//! eval correctness (dual-engine oracle), reader round-trip (the
//! fixed-point reading — see pbt.md §3 for the caliber disclosure),
//! and VM dispatch determinism. Generator domains are typed subsets
//! (pbt.md §2): every generated program is well-formed by
//! construction, so the parity properties assert on success values
//! while the definite-error properties (FP2/FP4) own the negative
//! channel. proptest runs dev-side only (SOP §18 — never in the
//! language pipeline or the bootstrap chain).

use proptest::prelude::*;

use kerf::compiler::compile_program;
use kerf::driver::{self, DiagnosticCode, Session};
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::runtime::{Evaluator, parity_repr};
use kerf::span::FileId;
use kerf::vm::{RuntimeError, Vm};

const FILE: FileId = FileId(0);

/// The effect-name pool (FP2/FP3/FP4 domains): pure identifiers,
/// zero keyword collisions (checked by the domain self-test below).
const EFFECT_POOL: &[&str] = &["e0", "e1", "e2", "e3"];

/// The symbol pool (FP5 datum domain): pure identifiers, zero
/// keyword and zero STAGE0_GLOBALS collisions (self-tested below).
const SYMBOL_POOL: &[&str] = &["x0", "x1", "x2", "x3", "y0", "y1", "y2", "y3"];

/// The keyword set the expander dispatches on (expand.rs) plus the
/// reserved literals — generator pools must avoid every one of these.
const KEYWORDS: &[&str] = &[
    "fn", "if", "let", "do", "set!", "perform", "handle", "define", "module", "require", "nil",
];

/// The 18 STAGE0_GLOBALS builtin names (single source: the expander
/// registry) — generator pools must avoid these too.
const BUILTINS: &[&str] = &[
    "+",
    "-",
    "*",
    "/",
    "<",
    "<=",
    ">",
    ">=",
    "=",
    "car",
    "cdr",
    "cons",
    "pair?",
    "nil?",
    "eq?",
    "not",
    "read-line",
    "write-line",
];

// ---------- shared helpers ----------

/// Read + expand a source program into module items (the parse chain
/// below the driver's diagnostic layer — FP2/FP6/FP7 connect here).
fn items_of(src: &str) -> Vec<kerf::core::ModuleItem> {
    let forms = read_program(FILE, src).expect("generator domain must read");
    expand_program(&forms).expect("generator domain must expand")
}

/// Run one parity round through the driver pipeline (typecheck
/// front-loaded, then both engines) — FP1/FP3/FP7 consumption face.
fn parity_of(src: &str) -> driver::ParityReport {
    let mut session = Session::new();
    driver::run_parity_source(&mut session, "pbt.kf", src, &[])
        .expect("well-formed domain must typecheck and run on both engines")
}

/// Read exactly one top-level form and return its datum (FP5 face).
fn read_one_datum(src: &str) -> kerf::syntax::StxDatum {
    let forms = read_program(FILE, src).expect("generator domain must read");
    assert_eq!(forms.len(), 1, "single-form source expected");
    forms[0].datum.clone()
}

// ---------- generators (typed domains — pbt.md §2) ----------

/// A small int literal inside the oracle-safe band (±2^40): checked
/// i64 arithmetic cannot overflow at generator depth caps.
fn arb_small_int() -> impl Strategy<Value = i64> {
    (-(1i64 << 40))..(1i64 << 40)
}

/// A float whose Rust `{:?}` form the reader parses back exactly
/// (finite + display-parse roundtrip filter — the FP5 domain rule).
fn arb_float_text() -> impl Strategy<Value = String> {
    any::<f64>()
        .prop_filter("finite and display-parse roundtrip", |v| {
            v.is_finite() && {
                let s = format!("{v:?}");
                matches!(s.parse::<f64>(), Ok(p) if p == *v)
            }
        })
        .prop_map(|v| format!("{v:?}"))
}

/// A string literal body from the escape-free printable band
/// (Rust `{:?}` output stays inside the reader's escape subset).
fn arb_string_text() -> impl Strategy<Value = String> {
    prop::collection::vec(
        any::<char>().prop_filter("printable escape-free", |c| {
            c.is_ascii_alphanumeric() || " .,!?;:_-".contains(*c)
        }),
        0..8,
    )
    .prop_map(|chars| format!("\"{}\"", chars.into_iter().collect::<String>()))
}

/// An arbitrary readable S-expression text (FP5 domain): atoms from
/// the safe pools and nested lists, depth- and width-capped.
fn arb_stx_source(depth: u32) -> BoxedStrategy<String> {
    let leaf = prop_oneof![
        4 => arb_small_int().prop_map(|v| v.to_string()),
        2 => arb_float_text(),
        2 => prop::sample::select(SYMBOL_POOL).prop_map(String::from),
        2 => arb_string_text(),
        1 => Just("#t".to_string()),
        1 => Just("#f".to_string()),
    ]
    .boxed();
    if depth == 0 {
        return leaf;
    }
    let list = prop::collection::vec(arb_stx_source(depth - 1), 1..4)
        .prop_map(|parts| format!("({})", parts.join(" ")))
        .boxed();
    prop_oneof![5 => leaf, 4 => list].boxed()
}

/// The boolean-expression channel (FP1): values are always bool.
fn arb_bool_expr(depth: u32) -> BoxedStrategy<String> {
    if depth == 0 {
        return prop_oneof![
            1 => Just("#t".to_string()),
            1 => Just("#f".to_string()),
        ]
        .boxed();
    }
    let lit = arb_bool_expr(0);
    let int = arb_int_expr(depth - 1);
    let any = arb_any_expr(depth - 1);
    let cmp = (int.clone(), int)
        .prop_map(|(a, b)| format!("(= {a} {b})"))
        .boxed();
    let lt = (arb_int_expr(depth - 1), arb_int_expr(depth - 1))
        .prop_map(|(a, b)| format!("(< {a} {b})"))
        .boxed();
    let not = arb_bool_expr(depth - 1)
        .prop_map(|b| format!("(not {b})"))
        .boxed();
    let eq = (any.clone(), any)
        .prop_map(|(a, b)| format!("(eq? {a} {b})"))
        .boxed();
    let cond = (
        arb_bool_expr(depth - 1),
        arb_bool_expr(depth - 1),
        arb_bool_expr(depth - 1),
    )
        .prop_map(|(c, t, e)| format!("(if {c} {t} {e})"))
        .boxed();
    prop_oneof![
        2 => lit,
        3 => cmp,
        3 => lt,
        2 => not,
        2 => eq,
        2 => cond,
    ]
    .boxed()
}

/// The int-expression channel (FP1): values are always i64 inside
/// the oracle-safe band (no division, depth-capped checked arith).
fn arb_int_expr(depth: u32) -> BoxedStrategy<String> {
    if depth == 0 {
        return arb_small_int().prop_map(|v| v.to_string()).boxed();
    }
    let lit = arb_int_expr(0);
    let add = (arb_int_expr(depth - 1), arb_int_expr(depth - 1))
        .prop_map(|(a, b)| format!("(+ {a} {b})"))
        .boxed();
    let sub = (arb_int_expr(depth - 1), arb_int_expr(depth - 1))
        .prop_map(|(a, b)| format!("(- {a} {b})"))
        .boxed();
    let cond = (
        arb_bool_expr(depth - 1),
        arb_int_expr(depth - 1),
        arb_int_expr(depth - 1),
    )
        .prop_map(|(c, t, e)| format!("(if {c} {t} {e})"))
        .boxed();
    let do_seq = (arb_int_expr(depth - 1), arb_int_expr(depth - 1))
        .prop_map(|(a, b)| format!("(do {a} {b})"))
        .boxed();
    let iife = (arb_small_int(), arb_int_expr(depth - 1))
        .prop_map(|(k, v)| format!("((fn (x0) (+ x0 {k})) {v})"))
        .boxed();
    let handled = (arb_small_int(), arb_int_expr(depth - 1))
        .prop_map(|(k, v)| format!("(handle (perform e0 {v}) (e0 (fn (v0) (+ v0 {k}))))"))
        .boxed();
    prop_oneof![
        3 => lit,
        3 => add,
        2 => sub,
        2 => cond,
        2 => do_seq,
        2 => iife,
        2 => handled,
    ]
    .boxed()
}

/// The any-value channel (FP1): mixed-kind values.
fn arb_any_expr(depth: u32) -> BoxedStrategy<String> {
    if depth == 0 {
        return prop_oneof![
            3 => arb_small_int().prop_map(|v| v.to_string()),
            1 => arb_float_text(),
            1 => arb_string_text(),
            1 => Just("#t".to_string()),
            1 => Just("#f".to_string()),
            1 => Just("nil".to_string()),
        ]
        .boxed();
    }
    let leaf = arb_any_expr(0);
    let int = arb_int_expr(depth - 1).boxed();
    let cons = (arb_any_expr(depth - 1), arb_any_expr(depth - 1))
        .prop_map(|(a, b)| format!("(cons {a} {b})"))
        .boxed();
    let is_pair = arb_any_expr(depth - 1)
        .prop_map(|v| format!("(pair? {v})"))
        .boxed();
    let cond = (
        arb_bool_expr(depth - 1),
        arb_any_expr(depth - 1),
        arb_any_expr(depth - 1),
    )
        .prop_map(|(c, t, e)| format!("(if {c} {t} {e})"))
        .boxed();
    prop_oneof![
        3 => leaf,
        3 => int,
        3 => cons,
        2 => is_pair,
        2 => cond,
    ]
    .boxed()
}

/// A whole well-formed program (FP1/FP6): 1..=4 top-level defines,
/// every value drawn from a typed channel.
fn arb_wellformed_program() -> BoxedStrategy<String> {
    prop::collection::vec(
        prop_oneof![
            4 => arb_int_expr(4),
            2 => arb_bool_expr(4),
            3 => arb_any_expr(4),
        ],
        1..=4,
    )
    .prop_map(|parts| {
        parts
            .iter()
            .enumerate()
            .map(|(i, v)| format!("(define r{i} {v})"))
            .collect::<Vec<_>>()
            .join(" ")
    })
    .boxed()
}

// ---------- FP1: dual-engine parity on arbitrary well-formed programs ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn wellformed_programs_agree_across_engines(program in arb_wellformed_program()) {
        let report = parity_of(&program);
        prop_assert!(report.values_agree, "value divergence on: {}", program);
        prop_assert!(report.outputs_agree, "output divergence on: {}", program);
        prop_assert!(report.globals_agree, "globals divergence on: {}", program);
    }
}

// ---------- FP2: unhandled perform traps both engines at runtime ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn unhandled_perform_traps_both_engines_at_runtime(
        effect in prop::sample::select(EFFECT_POOL),
        argc in 0usize..3,
    ) {
        let args = (0..argc).map(|i| format!("{i}")).collect::<Vec<_>>().join(" ");
        let call_args = if args.is_empty() {
            String::new()
        } else {
            format!(" {args}")
        };
        // The perform sits inside a fn body (not the top-level
        // immediate position) — R6 does not apply, the trap is the
        // runtime face (pbt.md §3 caliber 2). The wrapper fn carries
        // one dummy param (the reader rejects the empty param list
        // `()` — EmptyApplication, the frozen RS grammar fact).
        let src = format!(
            "(define f (fn (u0) (perform {effect}{call_args}))) (define r (f 9))"
        );
        let items = items_of(&src);

        let mut evaluator = Evaluator::new();
        let eval_trap = matches!(
            evaluator.eval_program(&items),
            Err(RuntimeError::UnhandledEffect { .. })
        );
        prop_assert!(eval_trap, "eval engine must trap unhandled on: {}", src);

        let bc = compile_program(&items).expect("generator domain must compile");
        let mut vm = Vm::new(bc).expect("verified product loads");
        let vm_trap = matches!(
            vm.run(),
            Err(RuntimeError::UnhandledEffect { .. })
        );
        prop_assert!(vm_trap, "vm engine must trap unhandled on: {}", src);
    }
}

// ---------- FP3: handled perform reduces to the handler body ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn handled_perform_reduces_to_handler_body(
        a in arb_small_int(),
        b in arb_small_int(),
        k in arb_small_int(),
    ) {
        // perform e0 (a+b), handler (+ v k): the stored global r is
        // the host-checked (a+b)+k (reduction semantics fused with a
        // concrete arithmetic oracle). The program value itself is
        // nil (declaration-only halt) — the assertion face is the
        // define slot, via the direct engine faces.
        let src = format!(
            "(define r (handle (perform e0 (+ {a} {b})) (e0 (fn (v0) (+ v0 {k})))))"
        );
        let expected = a
            .checked_add(b)
            .and_then(|v| v.checked_add(k))
            .expect("oracle band makes overflow impossible");

        let items = items_of(&src);
        let mut evaluator = Evaluator::new();
        evaluator
            .eval_program(&items)
            .expect("handled perform must succeed");
        let eval_r = parity_repr(
            evaluator.global("r").expect("r must bind"),
            evaluator.heap(),
        );
        prop_assert_eq!(eval_r, expected.to_string());

        let bc = compile_program(&items).expect("generator domain must compile");
        let mut vm = Vm::new(bc).expect("verified product loads");
        vm.run().expect("handled perform must succeed");
        let vm_r = parity_repr(vm.global("r").expect("r must bind"), vm.heap());
        prop_assert_eq!(vm_r, expected.to_string());
    }
}

// ---------- FP4: top-level immediate perform is a static E0006 ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn top_level_bare_perform_is_a_static_e0006(
        effect in prop::sample::select(EFFECT_POOL),
        arg in arb_small_int(),
    ) {
        // Define-position perform is the top-level immediate
        // position (module load time): R6 flags it E0006 before any
        // engine runs (the 1.1 finite samples, propertified).
        let src = format!("(define r (perform {effect} {arg}))");
        let mut session = Session::new();
        let parsed = driver::parse(&mut session, "fp4.kf", &src)
            .expect("generator domain must expand");
        let diags = parsed.typecheck();
        prop_assert!(
            diags.iter().any(|d| matches!(
                d.code,
                DiagnosticCode::Typecheck(kerf::typecheck::TypeCode::TopLevelUnhandledPerform)
            )),
            "expected an E0006 diagnostic, got: {:?}",
            diags
        );
    }
}

// ---------- FP5: the read image is a fixed point of display ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn read_image_is_a_fixed_point_of_display(src in arb_stx_source(5)) {
        let first = read_one_datum(&src);
        let printed = first.to_string();
        let second = read_one_datum(&printed);
        let reprinted = second.to_string();
        let third = read_one_datum(&reprinted);
        prop_assert_eq!(printed, reprinted, "unstable canonical form");
        prop_assert_eq!(second, third, "fixed point violated");
    }
}

// ---------- FP6: VM dispatch is deterministic ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn vm_double_run_is_deterministic(program in arb_wellformed_program()) {
        let items = items_of(&program);
        let bc = compile_program(&items).expect("generator domain must compile");

        let mut vm_a = Vm::new(bc.clone()).expect("verified product loads");
        let value_a = vm_a.run().expect("well-formed domain must run");
        let repr_a = parity_repr(&value_a, vm_a.heap());

        let mut vm_b = Vm::new(bc).expect("verified product loads");
        let value_b = vm_b.run().expect("well-formed domain must run");
        let repr_b = parity_repr(&value_b, vm_b.heap());

        prop_assert_eq!(repr_a, repr_b, "hidden state suspected on: {}", program);
    }
}

// ---------- FP7: integer addition matches the host oracle ----------

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn integer_addition_matches_host_oracle(
        a in arb_small_int(),
        b in arb_small_int(),
    ) {
        let src = format!("(define r (+ {a} {b}))");
        let expected = a
            .checked_add(b)
            .expect("oracle band makes overflow impossible");

        let items = items_of(&src);
        let mut evaluator = Evaluator::new();
        evaluator
            .eval_program(&items)
            .expect("well-formed domain must run");
        let eval_r = parity_repr(
            evaluator.global("r").expect("r must bind"),
            evaluator.heap(),
        );
        prop_assert_eq!(eval_r, expected.to_string());

        let bc = compile_program(&items).expect("generator domain must compile");
        let mut vm = Vm::new(bc).expect("verified product loads");
        vm.run().expect("well-formed domain must run");
        let vm_r = parity_repr(vm.global("r").expect("r must bind"), vm.heap());
        prop_assert_eq!(vm_r, expected.to_string());
    }
}

// ---------- generator-domain self-tests (non-PBT) ----------

#[test]
fn generator_pools_avoid_keywords_and_builtins() {
    for pool in [EFFECT_POOL, SYMBOL_POOL] {
        for name in pool {
            assert!(
                !KEYWORDS.contains(name),
                "pool name `{name}` collides with a keyword"
            );
            assert!(
                !BUILTINS.contains(name),
                "pool name `{name}` collides with a builtin"
            );
        }
    }
}

#[test]
fn float_domain_rule_holds_on_samples() {
    // The FP5 float rule (pbt.md §2): Debug form parses back exactly.
    for v in [0.0f64, -0.0, 1.5, -2.25, 3.0, 1e300, -1e-300] {
        let s = format!("{v:?}");
        let parsed: f64 = s.parse().expect("debug form must parse");
        assert_eq!(parsed, v, "roundtrip broken for {s}");
    }
}

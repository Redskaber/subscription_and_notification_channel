//! The C transpilation backend e2e (Stage 2.6, stage0.md §9.92) —
//! the cc-gated verification face of the chain-external backend.
//!
//! Constitutional gate: cc is a HOST tool, never a build dependency
//! of the kerf compiler — every test here checks `cc` availability
//! first and skips WITH DISCLOSURE when absent (the r90 adjudication
//! II basis: skip-with-disclosure, not failure). In a cc-present
//! environment every test runs for real: emit → cc → execute.
//!
//! Two verification channels:
//! - **hand-built bytecode** (direct `emit_c` on constructed
//!   products): the value-display parity face — the C binary's halt
//!   value must byte-match the Rust `Value` Display form, including
//!   the shortest-round-trip float battery (the hardest parity face
//!   in the backend);
//! - **source programs** (the real pipeline): stdout byte-parity
//!   between the VM engine (in-process) and the C-transpiled binary
//!   — declaration-only programs expose `write-line` outputs, so the
//!   value channel rides a check-wrapped epilogue (`= <global>
//!   <literal>` → PASS/FAIL write-line) derived from each case.
//!
//! The full-corpus C replay is the `#[ignore]`d sweep at the bottom
//! (heavy: one cc invocation per corpus case; run explicitly:
//! `cargo test --release --test runner c_backend -- --ignored`).

use std::io::Write as _;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::sync::OnceLock;

use kerf::cbackend::emit_c;
use kerf::compiler::{Bytecode, FuncProto, Instr, Opcode};
use kerf::core::LiteralValue;
use kerf::driver::{Engine, Expectation, Session, run_source};
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
use kerf::vm::Value;

const WORK_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/target/cbackend-e2e");

/// The chain-external gate: is a host cc reachable?
fn cc_available() -> bool {
    static AVAIL: OnceLock<bool> = OnceLock::new();
    *AVAIL.get_or_init(|| {
        Command::new("cc")
            .arg("--version")
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .is_ok_and(|s| s.success())
    })
}

/// The disclosure line for a skipped case (the gate text is pinned:
/// the same sentence every skip prints, so absence in a log is a
/// signal, not silence).
fn skip_disclosure(name: &str) -> String {
    format!(
        "skip: `{name}` — cc unavailable (the chain-external gate: skip with disclosure, not failure)"
    )
}

/// Gate one test; prints the disclosure and returns false when the
/// host lacks cc.
fn gate(name: &str) -> bool {
    if cc_available() {
        true
    } else {
        eprintln!("{}", skip_disclosure(name));
        false
    }
}

fn work_dir() -> PathBuf {
    let dir = PathBuf::from(WORK_DIR);
    std::fs::create_dir_all(&dir).expect("create the e2e work dir");
    dir
}

/// Compile one C translation unit with the host cc; panics with the
/// compiler's stderr on failure (an emitter bug must fail loudly
/// here, never pass a broken product through).
fn cc_build(name: &str, c_source: &str, extra: &[&str]) -> PathBuf {
    let dir = work_dir();
    let cpath = dir.join(format!("{name}.c"));
    std::fs::write(&cpath, c_source).expect("write the C source");
    let bin = dir.join(name);
    let out = Command::new("cc")
        .arg(&cpath)
        .args(extra)
        .arg("-o")
        .arg(&bin)
        .output()
        .expect("spawn cc");
    assert!(
        out.status.success(),
        "cc rejected `{name}` (an emitter bug):\n{}",
        String::from_utf8_lossy(&out.stderr)
    );
    bin
}

/// Run a built binary with piped stdin; returns (code, stdout, stderr).
fn run_bin(bin: &PathBuf, stdin_lines: &[&str]) -> (i32, String, String) {
    let mut child = Command::new(bin)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("spawn the transpiled binary");
    {
        let stdin = child.stdin.as_mut().expect("stdin pipe");
        for line in stdin_lines {
            writeln!(stdin, "{line}").expect("feed stdin");
        }
    }
    let out = child.wait_with_output().expect("collect the binary's exit");
    (
        out.status.code().unwrap_or(-1),
        String::from_utf8_lossy(&out.stdout).into_owned(),
        String::from_utf8_lossy(&out.stderr).into_owned(),
    )
}

/// The VM engine's observable contract for a source program
/// (outputs + the halt value's display line, exit code) — the exact
/// face `kerf run` prints.
fn vm_run(source: &str, stdin_lines: &[&str]) -> (i32, String) {
    let mut session = Session::new();
    let input: Vec<String> = stdin_lines.iter().map(|s| s.to_string()).collect();
    match run_source(&mut session, "e2e.krf", source, Engine::Vm, &input) {
        Ok(outcome) => {
            let mut text = String::new();
            for line in &outcome.outputs {
                text.push_str(line);
                text.push('\n');
            }
            if outcome.value != Value::Nil {
                text.push_str(&outcome.value_display());
                text.push('\n');
            }
            (0, text)
        }
        Err(_) => (1, String::new()),
    }
}

fn compile_source(source: &str) -> Bytecode {
    let forms = kerf::reader::read_program(FileId(0), source).expect("read");
    let items = kerf::expander::expand_program(&forms).expect("expand");
    kerf::compiler::compile_program(&items).expect("compile")
}

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

/// A hand-built entry proto that pushes one constant and halts — the
/// direct value-display probe (the halt pops it; `kerf run` prints
/// it because the depth is 1).
fn display_probe(lit: LiteralValue) -> Bytecode {
    let mut proto = FuncProto::new(None, 0, 0);
    proto.code = vec![
        Instr::with_a(Opcode::PushConst, 0),
        Instr::new(Opcode::Halt),
    ];
    proto.debug_info = vec![fix_span(); 2];
    Bytecode {
        consts: vec![lit],
        funcs: vec![proto],
        ..Default::default()
    }
}

/// One display-parity case: the C binary's stdout must equal what
/// `kerf run` would print — the value's Display line, or nothing at
/// all for a nil halt (the driver's nil-silence contract).
fn assert_display_parity(name: &str, lit: LiteralValue) {
    let value = Value::from_literal(&lit, &mut kerf::vm::Heap::default());
    let expected = if value == Value::Nil {
        String::new()
    } else {
        format!("{value}\n")
    };
    let bin = cc_build(name, &emit_c(&display_probe(lit)).expect("emit"), &[]);
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, expected, "display parity for {name}");
}

// ---------- the cc gate itself ----------

#[test]
fn gate_disclosure_text_is_pinned_and_gate_probes_cleanly() {
    // Pure face: the disclosure sentence is fixed (report over
    // silence), and the probe itself never panics with or without
    // cc. In a cc-present environment the gate simply opens.
    let text = skip_disclosure("probe-case");
    assert!(text.starts_with("skip: `probe-case`"));
    assert!(text.contains("cc unavailable"));
    assert!(text.contains("skip with disclosure, not failure"));
    let _ = cc_available();
}

// ---------- hand-built display parity ----------

#[test]
fn display_parity_immediates() {
    if !gate("display-parity-immediates") {
        return;
    }
    assert_display_parity("dp-int-42", LiteralValue::Int(42));
    assert_display_parity("dp-int-min", LiteralValue::Int(i64::MIN));
    assert_display_parity("dp-int-max", LiteralValue::Int(i64::MAX));
    assert_display_parity("dp-bool", LiteralValue::Bool(true));
    assert_display_parity("dp-bool-f", LiteralValue::Bool(false));
    assert_display_parity("dp-nil", LiteralValue::Nil);
    assert_display_parity("dp-str", LiteralValue::String("hello \"quoted\" \\".into()));
    assert_display_parity("dp-empty-str", LiteralValue::String("".into()));
    // A nested pair literal materializes through the KLit tree and
    // displays opaquely.
    assert_display_parity(
        "dp-pair",
        LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(LiteralValue::Nil)),
    );
}

#[test]
fn display_parity_float_battery() {
    if !gate("display-parity-float-battery") {
        return;
    }
    // The shortest-round-trip battery: the hardest cases for the
    // %.*e-search + plain-decimal render, checked against Rust's
    // Grisu/dragon shortest Display.
    let vals: [f64; 12] = [
        0.1,
        0.30000000000000004,
        1e21,
        1e-7,
        -0.0,
        f64::INFINITY,
        f64::NEG_INFINITY,
        f64::NAN,
        1.0 / 3.0,
        5e-324, // the minimum positive subnormal
        f64::MAX,
        -2.75,
    ];
    for (i, v) in vals.iter().enumerate() {
        assert_display_parity(&format!("dp-float-{i}"), LiteralValue::Float(*v));
    }
}

// ---------- source-level parity (check-wrapped) ----------

/// The check form for one expected repr (callers pre-classify):
/// numeric reprs compare with `=`; bool reprs map to the `#t`/`#f`
/// literals (the Rust Display forms `true`/`false` are not kerf
/// source); everything else compares with `eq?` verbatim.
fn check_form(global: &str, repr: &str) -> String {
    if repr == "true" {
        format!("(eq? {global} #t)")
    } else if repr == "false" {
        format!("(eq? {global} #f)")
    } else if repr == "nil" || repr.starts_with('"') {
        format!("(eq? {global} {repr})")
    } else {
        format!("(= {global} {repr})")
    }
}

/// Append the value-check epilogue: `PASS` prints iff the last
/// define's global equals the expected repr.
fn check_wrapped(source: &str, global: &str, repr: &str) -> String {
    let check = check_form(global, repr);
    format!(
        "{source}\n(define c-backend-value-check (if {check} (write-line \"PASS\") (write-line \"FAIL\")))"
    )
}

#[test]
fn source_fib_passes_through_the_c_backend() {
    if !gate("source-fib") {
        return;
    }
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";
    let wrapped = check_wrapped(source, "result", "75025");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-fib",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "PASS\n",
        "the C-transpiled fib(25) agrees with the VM"
    );
}

#[test]
fn source_transitive_captures_pass() {
    if !gate("source-captures") {
        return;
    }
    // Two-level capture: the innermost closure re-captures through
    // its enclosing closure's capture area (LA-4 pass-through).
    let source = concat!(
        "(define (f x) (fn (y) (fn (z) (+ x (+ y z)))))\n",
        "(define g (f 10))\n",
        "(define h (g 20))\n",
        "(define result (h 12))\n",
    );
    let wrapped = check_wrapped(source, "result", "42");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-captures",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "flat captures survive the transpilation");
}

#[test]
fn source_effects_handle_perform_pass() {
    if !gate("source-effects") {
        return;
    }
    // pos-021 shape: a handler answers a perform; its return value
    // is the perform's value.
    let source = "(define result (handle (perform add 1 2) (add (fn (a b) (+ a b)))))";
    let wrapped = check_wrapped(source, "result", "3");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-effects",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "the handler stack rides the shim");
}

#[test]
fn source_read_line_stdin_passes() {
    if !gate("source-read-line") {
        return;
    }
    let source = concat!(
        "(define a (read-line))\n",
        "(define b (read-line))\n",
        "(define result (if (eq? a \"one\") (eq? b \"two\") #f))\n",
    );
    let wrapped = check_wrapped(source, "result", "true");
    let (vm_code, vm_out) = vm_run(&wrapped, &["one", "two"]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-read-line",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &["one", "two"]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "getline feeds read-line identically");
}

#[test]
fn source_multi_output_sequence_matches() {
    if !gate("source-outputs") {
        return;
    }
    let source = concat!(
        "(define a (write-line \"first\"))\n",
        "(define b (write-line \"second\"))\n",
        "(define c (write-line \"third\"))\n",
    );
    let (vm_code, vm_out) = vm_run(source, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "first\nsecond\nthird\n"));
    let bin = cc_build(
        "src-outputs",
        &emit_c(&compile_source(source)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "first\nsecond\nthird\n",
        "byte parity on the output channel"
    );
}

// ---------- runtime fail-closed families (hand-built) ----------

#[test]
fn runtime_errors_fail_closed_with_engine_level_text() {
    if !gate("runtime-errors") {
        return;
    }
    // Integer division by zero (hand-built: the checker would catch
    // the literal source form statically).
    let div_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Div),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 5];
        Bytecode {
            consts: vec![LiteralValue::Int(1), LiteralValue::Int(0)],
            funcs: vec![proto],
            ..Default::default()
        }
    };
    let bin = cc_build("err-div", &emit_c(&div_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("kerf: runtime error: division by zero"),
        "{stderr}"
    );

    // Checked add overflow at the i64 boundary.
    let ovf_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Add),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 5];
        Bytecode {
            consts: vec![LiteralValue::Int(i64::MAX), LiteralValue::Int(1)],
            funcs: vec![proto],
            ..Default::default()
        }
    };
    let bin = cc_build("err-ovf", &emit_c(&ovf_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(stderr.contains("add overflow"), "{stderr}");

    // An unbound global read (LoadGlobal on a never-stored,
    // non-builtin slot).
    let unb_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 3];
        Bytecode {
            consts: Vec::new(),
            globals: vec![kerf::span::Symbol::new("missing").expect("symbol")],
            funcs: vec![proto],
        }
    };
    let bin = cc_build("err-unbound", &emit_c(&unb_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(stderr.contains("unbound global `missing`"), "{stderr}");
}

#[test]
fn builtin_arity_mismatches_fail_closed_representatives() {
    if !gate("arity-representatives") {
        return;
    }
    // Hand-built calls with wrong argc on three representative
    // builtins (the full 18-name mapping guard is unit-level in the
    // emitter; this pins the runtime behavior end to end).
    for (name, global, argc, expect) in [
        ("arity-add", "+", 1u32, "`+` expects `2` arguments"),
        ("arity-cons", "cons", 3, "`cons` expects `2` arguments"),
        (
            "arity-write",
            "write-line",
            0,
            "`write-line` expects `1` argument",
        ),
    ] {
        // Stack order (§19.3): args left-to-right FIRST, the callee
        // ON TOP.
        let mut proto = FuncProto::new(None, 0, 0);
        let mut code = Vec::new();
        for _ in 0..argc {
            code.push(Instr::with_a(Opcode::PushConst, 0));
        }
        code.push(Instr::with_a(Opcode::LoadGlobal, 0));
        code.push(Instr::with_a(Opcode::Call, argc));
        code.push(Instr::new(Opcode::Pop));
        code.push(Instr::new(Opcode::Halt));
        proto.code = code;
        proto.debug_info = vec![fix_span(); proto.code.len()];
        let bc = Bytecode {
            consts: vec![LiteralValue::Int(1)],
            globals: vec![kerf::span::Symbol::new(global).expect("builtin name is a valid symbol")],
            funcs: vec![proto],
        };
        let bin = cc_build(name, &emit_c(&bc).expect("emit"), &[]);
        let (code, _, stderr) = run_bin(&bin, &[]);
        assert_eq!(code, 1, "{name} must fail closed");
        assert!(stderr.contains(expect), "{name}: {stderr}");
    }
}

// ---------- override faces (the fail-closed guards) ----------

#[test]
fn budget_override_fails_closed() {
    if !gate("budget-override") {
        return;
    }
    // A chain of 40 cons cells against -DK_BUDGET=24: the §19.4
    // safety point fires before the arena satisfies the chain.
    let mut source = String::from("(define chain ");
    for _ in 0..40 {
        source.push_str("(cons 1 ");
    }
    source.push_str("nil");
    for _ in 0..40 {
        source.push(')');
    }
    source.push_str(")\n");
    let bin = cc_build(
        "budget-override",
        &emit_c(&compile_source(&source)).expect("emit"),
        &["-DK_BUDGET=24"],
    );
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("allocation budget of `24` exhausted"),
        "{stderr}"
    );
}

#[test]
fn depth_override_fails_closed() {
    if !gate("depth-override") {
        return;
    }
    // Recursion depth 40 against -DK_DEPTH_CAP=8: the host-stack
    // guard fires cleanly instead of a segfault.
    let source = concat!(
        "(define (cd n) (if (= n 0) 0 (cd (- n 1))))\n",
        "(define result (cd 40))\n",
    );
    let bin = cc_build(
        "depth-override",
        &emit_c(&compile_source(source)).expect("emit"),
        &["-DK_DEPTH_CAP=8"],
    );
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("recursion depth of `8` exceeded"),
        "{stderr}"
    );
}

// ---------- emission determinism (no cc needed) ----------

#[test]
fn emission_determinism_at_the_source_level() {
    let bc = compile_source("(define (f x) (+ x 1)) (define result (f 41)) (define s \"payload\")");
    assert_eq!(
        emit_c(&bc).expect("emit"),
        emit_c(&bc).expect("emit again"),
        "identical product, byte-identical C"
    );
}

// ---------- the full-corpus C replay (heavy, explicit) ----------

/// The corpus directory (shared with subset_corpus_tests).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// One replay outcome for the sweep's disclosure report.
struct ReplayLine {
    case: String,
    verdict: &'static str,
}

#[test]
#[ignore = "heavy: one cc invocation per corpus case (run explicitly: cargo test --release --test runner c_backend -- --ignored)"]
fn corpus_c_replay_full_sweep() {
    if !gate("corpus-c-replay") {
        return;
    }
    let dir = std::fs::read_dir(CORPUS_DIR).expect("corpus dir");
    let mut executed = 0usize;
    let mut passed = 0usize;
    let mut skipped_compile_stage = 0usize;
    let mut skipped_repr_kind = 0usize;
    let mut lines: Vec<ReplayLine> = Vec::new();

    for entry in dir {
        let path = entry.expect("dir entry").path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if !name.ends_with(".krf") {
            continue;
        }
        let case_name = name.trim_end_matches(".krf").to_owned();
        let source = std::fs::read_to_string(&path).expect("read corpus file");
        let case = kerf::driver::CorpusCase::from_source(&case_name, &source)
            .expect("corpus directive parses");
        match &case.expectation {
            Expectation::Value(repr) | Expectation::Warning { value: repr, .. } => {
                // Locate the last top-level define through the real
                // expansion (the parity convention's global).
                let forms = kerf::reader::read_program(FileId(0), &source).expect("read");
                let items = kerf::expander::expand_program(&forms).expect("expand");
                let last_global = items.iter().rev().find_map(|item| match item {
                    kerf::core::ModuleItem::Define { name, .. } => Some(name.as_str().to_owned()),
                    _ => None,
                });
                let Some(global) = last_global else {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: no define",
                    });
                    continue;
                };
                // Pair/closure/builtin reprs have no printable
                // channel (eq? is identity) — disclose and skip.
                let simple = repr.parse::<i64>().is_ok()
                    || repr == "nil"
                    || repr == "true"
                    || repr == "false"
                    || repr.starts_with('"')
                    || repr.parse::<f64>().is_ok();
                if !simple {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: repr kind",
                    });
                    continue;
                }
                let wrapped = check_wrapped(&source, &global, repr);
                let (vm_code, vm_out) = vm_run(&wrapped, &[]);
                assert_eq!(vm_code, 0, "vm side of {case_name}");
                assert!(
                    vm_out.ends_with("PASS\n"),
                    "vm side of {case_name} must verify its own value (got {vm_out:?})"
                );
                let bc = compile_source(&wrapped);
                let bin = cc_build(
                    &format!("corpus-{case_name}"),
                    &emit_c(&bc).expect("emit"),
                    &[],
                );
                let (code, stdout, stderr) = run_bin(&bin, &[]);
                executed += 1;
                if code == 0 && stdout == vm_out {
                    passed += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "pass",
                    });
                } else {
                    lines.push(ReplayLine {
                        case: case_name.clone(),
                        verdict: "FAIL",
                    });
                    panic!(
                        "corpus case `{case_name}` diverged through the C backend: code={code} stdout={stdout:?} (vm={vm_out:?}) stderr={stderr}"
                    );
                }
            }
            kerf::driver::Expectation::RuntimeError => {
                // Both engines must fail closed on the untransformed
                // source.
                let (vm_code, _) = vm_run(&source, &[]);
                assert_eq!(vm_code, 1, "vm side of {case_name} must error");
                let bc = compile_source(&source);
                let bin = cc_build(
                    &format!("corpus-{case_name}"),
                    &emit_c(&bc).expect("emit"),
                    &[],
                );
                let (code, _, stderr) = run_bin(&bin, &[]);
                executed += 1;
                if code != 0 && stderr.contains("kerf: runtime error") {
                    passed += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "pass (error parity)",
                    });
                } else {
                    lines.push(ReplayLine {
                        case: case_name.clone(),
                        verdict: "FAIL",
                    });
                    panic!(
                        "corpus case `{case_name}` runtime error diverged: code={code} stderr={stderr}"
                    );
                }
            }
            // parse/expand/type errors never reach the backend.
            _ => {
                skipped_compile_stage += 1;
            }
        }
    }
    for line in &lines {
        eprintln!("corpus-c-replay: {} — {}", line.case, line.verdict);
    }
    eprintln!(
        "corpus-c-replay SUMMARY: {passed}/{executed} executed cases agree; {skipped_compile_stage} pre-backend skips (parse/expand/type); {skipped_repr_kind} repr-kind skips"
    );
    // The sweep must be non-trivial: the corpus reaches the backend
    // through dozens of cases.
    assert!(
        executed >= 30,
        "the corpus replay must exercise at least 30 execution cases (got {executed})"
    );
}

#[test]
#[ignore = "measurement: the Stage 2.6 B-face numbers (emit cost + C fib vs VM)"]
fn b_face_measurement_c_vs_vm() {
    if !gate("b-face-measurement") {
        return;
    }
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";
    let bc = compile_source(source);

    // Emit cost: 2000 iterations, report mean/median.
    let mut samples: Vec<f64> = Vec::with_capacity(2000);
    for _ in 0..2000 {
        let t = std::time::Instant::now();
        let c = emit_c(&bc).expect("emit");
        let _ = std::hint::black_box(&c);
        samples.push(t.elapsed().as_secs_f64() * 1e6);
    }
    samples.sort_by(|a, b| a.total_cmp(b));
    let mean: f64 = samples.iter().sum::<f64>() / samples.len() as f64;
    let median = samples[samples.len() / 2];
    eprintln!("B9c emit-c fib: 2000 iters, mean {mean:.1}µs, median {median:.1}µs");

    // cc -O0 build time (one shot).
    let c = emit_c(&bc).expect("emit");
    let t = std::time::Instant::now();
    let bin = cc_build("b-face-fib", &c, &[]);
    eprintln!("B9c cc -O0 build: {:.1}ms", t.elapsed().as_secs_f64() * 1e3);

    // The C binary vs the VM engine on fib(25): 10 runs each, median.
    let mut c_times: Vec<f64> = Vec::with_capacity(10);
    for _ in 0..10 {
        let t = std::time::Instant::now();
        let (code, stdout, _) = run_bin(&bin, &[]);
        assert_eq!(
            (code, stdout.as_str()),
            (0, ""),
            "the declaration-only program prints nothing"
        );
        c_times.push(t.elapsed().as_secs_f64() * 1e3);
    }
    c_times.sort_by(|a, b| a.total_cmp(b));
    eprintln!(
        "B9c cc-binary fib(25): 10 runs, median {:.3}ms (B2 vm median ~79ms for the comparison)",
        c_times[5]
    );
}

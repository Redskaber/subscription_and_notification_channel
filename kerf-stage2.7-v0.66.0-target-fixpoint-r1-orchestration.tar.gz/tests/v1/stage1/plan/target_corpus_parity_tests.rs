//! Target-corpus parity tests (Stage 2.7, switch-window step 3 —
//! stage0.md §9.96, docs/develop/v2/switch-window-plan.md §1).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The step-3 deliverable: the five `selfhost/v1/*.ktf` twins of
//! the `.krf` corpus, each driven through the identical pipeline
//! (read → expand → compile → VM) with the identical injected data
//! (the driver's target-skin prefix twins), under the three-gate
//! contract of §9.25.4 BS-C:
//!
//! 1. **Semantic projection equality** — per-function shape and
//!    instruction streams, the constant pool, the global table
//!    (everything except `debug_info`, whose spans necessarily
//!    differ between two source texts). This gate carries the
//!    naming guard: a skin name that failed to map back (rd_loop →
//!    rd-loop) would surface as a proto-name or global-table
//!    mismatch.
//! 2. **Behavioral equivalence** — both programs run to the same
//!    value for every global, product records included.
//! 3. **Expansion-gate parity** — the expanded item trees are
//!    span-blind identical (the r99 `same_shape` discipline,
//!    extended to `ModuleItem`).
//!
//! The `.krf` originals stay untouched as the parity oracle (the
//! parallel-file strategy — retained until step 5); the
//! composed-chain consumption of `.ktf` products is the step-4
//! production-bridge obligation, registered in the plan.

use kerf::compiler::{Bytecode, CaptureSource, Instr, compile_program};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    COMPILER_SOURCE, COMPILER_TARGET_SOURCE, LEXER_SOURCE, LEXER_TARGET_SOURCE, READER_SOURCE,
    READER_TARGET_SOURCE, assembled_expander_source, assembled_expander_target_source,
    byte_table_prefix, target_byte_table_prefix, target_forms_stream_prefix,
    target_items_stream_prefix, target_token_table_prefix, token_table_prefix,
};
use kerf::expander::expand_program;
use kerf::reader::{read_program, read_target_program};
use kerf::span::{FileId, Symbol};
use kerf::vm::{HeapObj, Value, Vm};

const FILE: FileId = FileId(0);

/// The corpus programs walk deep on the harness side (the semantic
/// projection compare and the value walk are Rust recursion); the
/// sibling tests' demand-allocated stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- the three-gate harness ----------

fn compile_sexpr_text(src: &str) -> Bytecode {
    let forms = read_program(FILE, src).expect("S-expression corpus program must read");
    let items = expand_program(&forms).expect("S-expression corpus program must expand");
    compile_program(&items).expect("S-expression corpus program must compile")
}

fn compile_target_text(src: &str) -> Bytecode {
    let forms = read_target_program(FILE, src).expect("target corpus program must read");
    let items = expand_program(&forms).expect("target corpus program must expand");
    compile_program(&items).expect("target corpus program must compile")
}

/// The span-free projection of one function proto.
#[derive(Debug, PartialEq)]
struct SemanticProto<'a> {
    name: Option<&'a str>,
    params: u32,
    n_locals: u32,
    captures: Vec<CaptureSource>,
    code: Vec<Instr>,
}

/// The semantic projection of a bytecode product (the §9.25.4
/// layering — `debug_info` excluded).
#[derive(Debug, PartialEq)]
struct SemanticBytecode<'a> {
    funcs: Vec<SemanticProto<'a>>,
    consts: Vec<LiteralValue>,
    globals: Vec<&'a str>,
}

fn semantic(bc: &Bytecode) -> SemanticBytecode<'_> {
    SemanticBytecode {
        funcs: bc
            .funcs
            .iter()
            .map(|f| SemanticProto {
                name: f.name.as_ref().map(|s| s.as_str()),
                params: f.params,
                n_locals: f.n_locals,
                captures: f.captures.clone(),
                code: f.code.clone(),
            })
            .collect(),
        consts: bc.consts.clone(),
        globals: bc.globals.iter().map(|s| s.as_str()).collect(),
    }
}

/// The expansion-gate parity (ruling H refinement): span-blind
/// ALPHA-EQUIVALENCE of the expanded item trees — equal modulo
/// spans and a capture-avoiding bijection of locally-bound names
/// (params, let bindings). The refinement is the registered
/// skin-collision carrier: the corpus's `rest` locals ride
/// `remaining` on the twin face because `rest` is a skin-reserved
/// builtin spelling (ruling E2 — and keeping it would SHADOW the
/// builtin inside the twin, a semantic break, not just a name
/// drift). Global faces (define names, effect names) stay literal;
/// the same "fresh names and spans excluded" principle the match
/// desugaring's identity contract already carries (plan §5.2).
type AlphaMap = Vec<(Symbol, Symbol)>;

fn alpha_lookup<'a>(env: &'a AlphaMap, a: &Symbol) -> Option<&'a Symbol> {
    env.iter().find(|(x, _)| x == a).map(|(_, y)| y)
}

/// One name pair agrees: through the bijection when the original
/// is locally bound, literally otherwise.
fn alpha_resolve(env: &AlphaMap, a: &Symbol, b: &Symbol) -> bool {
    match alpha_lookup(env, a) {
        Some(y) => y == b,
        None => a == b,
    }
}

/// Extend the bijection (injectivity in scope — two originals
/// never map to one twin name).
fn alpha_extend(env: &mut AlphaMap, a: &Symbol, b: &Symbol) -> bool {
    if let Some(y) = alpha_lookup(env, a) {
        return y == b;
    }
    if env.iter().any(|(_, y)| y == b) {
        return false;
    }
    env.push((a.clone(), b.clone()));
    true
}

fn alpha_items(a: &[ModuleItem], b: &[ModuleItem]) -> bool {
    a.len() == b.len() && a.iter().zip(b).all(|(x, y)| alpha_item(x, y))
}

fn alpha_item(a: &ModuleItem, b: &ModuleItem) -> bool {
    match (a, b) {
        (
            ModuleItem::Define {
                name: n1,
                value: v1,
                ..
            },
            ModuleItem::Define {
                name: n2,
                value: v2,
                ..
            },
        ) => {
            // Define names are globals — literal equality.
            n1 == n2 && alpha_expr(v1, v2, &mut Vec::new())
        }
        (ModuleItem::Require { module: m1, .. }, ModuleItem::Require { module: m2, .. }) => {
            m1 == m2
        }
        (
            ModuleItem::Module {
                name: n1,
                items: i1,
                ..
            },
            ModuleItem::Module {
                name: n2,
                items: i2,
                ..
            },
        ) => n1 == n2 && alpha_items(i1, i2),
        (ModuleItem::DefineSyntax { name: n1, .. }, ModuleItem::DefineSyntax { name: n2, .. }) => {
            n1 == n2
        }
        _ => false,
    }
}

fn alpha_expr(a: &CoreExpr, b: &CoreExpr, env: &mut AlphaMap) -> bool {
    use CoreExpr::*;
    match (a, b) {
        (
            Fn {
                params: p1,
                body: b1,
                ..
            },
            Fn {
                params: p2,
                body: b2,
                ..
            },
        ) => {
            if p1.len() != p2.len() {
                return false;
            }
            let mark = env.len();
            let mut ok = true;
            for (x, y) in p1.iter().zip(p2) {
                ok = ok && alpha_extend(env, x, y);
            }
            ok = ok && alpha_expr(b1, b2, env);
            env.truncate(mark);
            ok
        }
        (
            Apply {
                func: f1, args: a1, ..
            },
            Apply {
                func: f2, args: a2, ..
            },
        ) => {
            alpha_expr(f1, f2, env)
                && a1.len() == a2.len()
                && a1.iter().zip(a2).all(|(x, y)| alpha_expr(x, y, env))
        }
        (
            If {
                cond: c1,
                then_branch: t1,
                else_branch: e1,
                ..
            },
            If {
                cond: c2,
                then_branch: t2,
                else_branch: e2,
                ..
            },
        ) => alpha_expr(c1, c2, env) && alpha_expr(t1, t2, env) && alpha_expr(e1, e2, env),
        (Var { name: n1, .. }, Var { name: n2, .. }) => alpha_resolve(env, n1, n2),
        (Literal { value: v1, .. }, Literal { value: v2, .. }) => v1 == v2,
        (
            Assign {
                name: n1,
                value: v1,
                ..
            },
            Assign {
                name: n2,
                value: v2,
                ..
            },
        ) => alpha_resolve(env, n1, n2) && alpha_expr(v1, v2, env),
        (
            Let {
                bindings: b1,
                body: y1,
                ..
            },
            Let {
                bindings: b2,
                body: y2,
                ..
            },
        ) => {
            if b1.len() != b2.len() {
                return false;
            }
            let mark = env.len();
            let mut ok = true;
            for (x, y) in b1.iter().zip(b2) {
                // Sequential bindings: each value sees the earlier
                // bindings (the let* semantics).
                ok = ok && alpha_expr(&x.value, &y.value, env);
                ok = ok && alpha_extend(env, &x.name, &y.name);
            }
            ok = ok && alpha_expr(y1, y2, env);
            env.truncate(mark);
            ok
        }
        (
            Perform {
                effect: e1,
                args: a1,
                ..
            },
            Perform {
                effect: e2,
                args: a2,
                ..
            },
        ) => {
            // Effect names are globals — literal equality.
            e1 == e2
                && a1.len() == a2.len()
                && a1.iter().zip(a2).all(|(x, y)| alpha_expr(x, y, env))
        }
        (
            Handle {
                body: y1,
                handlers: h1,
                ..
            },
            Handle {
                body: y2,
                handlers: h2,
                ..
            },
        ) => {
            alpha_expr(y1, y2, env)
                && h1.len() == h2.len()
                && h1
                    .iter()
                    .zip(h2)
                    .all(|(x, y)| x.effect == y.effect && alpha_expr(&x.handler, &y.handler, env))
        }
        _ => false,
    }
}

/// Drive one corpus pair through the three gates: same injected
/// data, two skins, one semantic bytecode, one value face, one
/// expanded shape.
fn assert_corpus_parity(case: &str, sexpr_program: &str, target_program: &str) {
    // Gate 3 — the expansion gate (span-blind item-tree equality).
    let sexpr_forms = read_program(FILE, sexpr_program)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must read: {e}"));
    let target_forms = read_target_program(FILE, target_program)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must read: {e}"));
    let sexpr_items = expand_program(&sexpr_forms)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must expand: {e}"));
    let target_items = expand_program(&target_forms)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must expand: {e}"));
    assert_eq!(
        sexpr_items.len(),
        target_items.len(),
        "{case}: the item counts must agree"
    );
    for (i, (x, y)) in sexpr_items.iter().zip(&target_items).enumerate() {
        assert!(
            alpha_item(x, y),
            "{case}: item {i} (`{}`) must be alpha-equivalent (span-blind, locals modulo the ruling-H bijection)",
            x.kind_name()
        );
    }
    // Gate 1 — the semantic projection.
    let bc_sexpr = compile_program(&sexpr_items)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must compile: {e}"));
    let bc_target = compile_program(&target_items)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must compile: {e}"));
    assert_eq!(
        semantic(&bc_target),
        semantic(&bc_sexpr),
        "{case}: the two skins of the corpus must produce one semantic bytecode"
    );
    // Gate 2 — behavioral equivalence over every global (the
    // identical bytecode and deterministic execution make the heap
    // indices comparable: same program, same allocations).
    let mut vm_a =
        Vm::new(bc_sexpr).unwrap_or_else(|e| panic!("{case}: the S-expr product loads: {e}"));
    vm_a.run()
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus runs: {e}"));
    let mut vm_b =
        Vm::new(bc_target).unwrap_or_else(|e| panic!("{case}: the target product loads: {e}"));
    vm_b.run()
        .unwrap_or_else(|e| panic!("{case}: the target corpus runs: {e}"));
    for name in vm_a.global_names() {
        let a = vm_a
            .global_sym(name)
            .unwrap_or_else(|| panic!("{case}: the global `{name}` must exist on both faces"));
        let b = vm_b
            .global_sym(name)
            .unwrap_or_else(|| panic!("{case}: the global `{name}` must exist on both faces"));
        assert_eq!(
            a, b,
            "{case}: the global `{name}` must hold one value on both faces"
        );
    }
}

// ---------- gate: the reader twin (structure layer) ----------

fn reader_pair(probe: &str) -> (String, String) {
    let prefix = token_table_prefix(probe).expect("the probe lexes");
    let target_prefix = target_token_table_prefix(probe).expect("the probe lexes (target)");
    (
        format!("{prefix}\n{READER_SOURCE}"),
        format!("{target_prefix}\n{READER_TARGET_SOURCE}"),
    )
}

#[test]
fn reader_twin_passes_the_three_gates() {
    deep_stack(|| {
        let probe = "(add 1 2) foo \"str\" 3.5 #t (nested (deep))";
        let (a, b) = reader_pair(probe);
        assert_corpus_parity("reader", &a, &b);
    });
}

#[test]
fn reader_twin_matches_the_error_record_faces() {
    deep_stack(|| {
        // The structured rejections: unclosed, unexpected-close and
        // the empty application — the negative behavioral parity
        // (the `result` records must agree, error payloads included).
        for probe in ["(add 1", ")", "(f ())"] {
            let (a, b) = reader_pair(probe);
            let bc_a = compile_sexpr_text(&a);
            let bc_b = compile_target_text(&b);
            let mut vm_a = Vm::new(bc_a).expect("the S-expr reader runs");
            vm_a.run().expect("the S-expr reader runs");
            let mut vm_b = Vm::new(bc_b).expect("the target reader runs");
            vm_b.run().expect("the target reader runs");
            let ra = vm_a.global("result").expect("the result global binds");
            let rb = vm_b.global("result").expect("the result global binds");
            assert_eq!(ra, rb, "probe `{probe}`: the rejection records must agree");
        }
    });
}

// ---------- gate: the lexer twin (lexical layer) ----------

fn lexer_pair(probe: &str) -> (String, String) {
    (
        format!("{}\n{LEXER_SOURCE}", byte_table_prefix(probe)),
        format!("{}\n{LEXER_TARGET_SOURCE}", target_byte_table_prefix(probe)),
    )
}

#[test]
fn lexer_twin_passes_the_three_gates() {
    deep_stack(|| {
        let probe = "(define (f x) (+ x 1.5)) ;; comment\n(foo \"str\" #f 0x1F)";
        let (a, b) = lexer_pair(probe);
        assert_corpus_parity("lexer", &a, &b);
    });
}

#[test]
fn lexer_twin_matches_the_reject_record_face() {
    deep_stack(|| {
        // A reject-set byte (ASCII control) drives the `lex-error`
        // product; the verdict records must agree across the skins.
        let probe = "(f \u{1})";
        let (a, b) = lexer_pair(probe);
        let bc_a = compile_sexpr_text(&a);
        let bc_b = compile_target_text(&b);
        let mut vm_a = Vm::new(bc_a).expect("the S-expr lexer runs");
        vm_a.run().expect("the S-expr lexer runs");
        let mut vm_b = Vm::new(bc_b).expect("the target lexer runs");
        vm_b.run().expect("the target lexer runs");
        for name in ["lex-verdict", "lx-failed", "lex-error", "tokens"] {
            let va = vm_a.global(name).expect("the product global binds");
            let vb = vm_b.global(name).expect("the product global binds");
            assert_eq!(va, vb, "the `{name}` product must agree across the skins");
        }
    });
}

// ---------- gate: the assembled expander twin (macro + expander) ----------

fn expander_pair(probe: &str) -> (String, String) {
    let forms = read_program(FILE, probe).expect("the probe reads");
    let prefix = kerf::driver::forms_stream_prefix(&forms);
    let target_prefix = target_forms_stream_prefix(&forms);
    let assembled = assembled_expander_source();
    let assembled_target = assembled_expander_target_source();
    (
        format!("{prefix}\n{assembled}"),
        format!("{target_prefix}\n{assembled_target}"),
    )
}

#[test]
fn assembled_expander_twin_passes_the_three_gates() {
    deep_stack(|| {
        let probe = "(define (f x) (+ x 1)) (define r (f 2)) (define (g y) (fn (z) (* y z)))";
        let (a, b) = expander_pair(probe);
        assert_corpus_parity("expander", &a, &b);
    });
}

#[test]
fn assembled_expander_twin_matches_the_error_record_face() {
    deep_stack(|| {
        // A malformed special form (set! on an undefined head shape)
        // drives the `ex-err` product through both skins.
        let probe = "(set!)";
        let (a, b) = expander_pair(probe);
        let bc_a = compile_sexpr_text(&a);
        let bc_b = compile_target_text(&b);
        let mut vm_a = Vm::new(bc_a).expect("the S-expr expander runs");
        vm_a.run().expect("the S-expr expander runs");
        let mut vm_b = Vm::new(bc_b).expect("the target expander runs");
        vm_b.run().expect("the target expander runs");
        let ra = vm_a.global("result").expect("the result global binds");
        let rb = vm_b.global("result").expect("the result global binds");
        assert_eq!(ra, rb, "the expansion rejection records must agree");
    });
}

// ---------- gate: the compiler twin ----------

fn compiler_pair(probe: &str) -> (String, String) {
    let forms = read_program(FILE, probe).expect("the probe reads");
    let items = expand_program(&forms).expect("the probe expands");
    let prefix = kerf::driver::items_stream_prefix(&items);
    let target_prefix = target_items_stream_prefix(&items);
    (
        format!("{prefix}\n{COMPILER_SOURCE}"),
        format!("{target_prefix}\n{COMPILER_TARGET_SOURCE}"),
    )
}

#[test]
fn compiler_twin_passes_the_three_gates() {
    deep_stack(|| {
        // The recursion + operator-faces probe. The string carried a
        // latent harness defect until the compiler twin landed (the
        // crate could not compile without all five .ktf twins, so the
        // probe never ran): the first define was missing its closing
        // paren (UnclosedList at read).
        let probe =
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
        let (a, b) = compiler_pair(probe);
        assert_corpus_parity("compiler", &a, &b);
    });
}

#[test]
fn compiler_twin_matches_the_error_record_face() {
    deep_stack(|| {
        // An assign to a captured name (the LA-7 boundary, the CP9
        // axis) rides the item stream and drives the `cp-err` product
        // through both skins. The original `(define r (if #t))` probe
        // was a latent harness defect of the same kind (a two-argument
        // if cannot expand, so it never reached the corpus).
        let probe = "(define (outer a) (fn (b) (set! a (+ a b))))";
        let (a, b) = compiler_pair(probe);
        let bc_a = compile_sexpr_text(&a);
        let bc_b = compile_target_text(&b);
        let mut vm_a = Vm::new(bc_a).expect("the S-expr compiler runs");
        vm_a.run().expect("the S-expr compiler runs");
        let mut vm_b = Vm::new(bc_b).expect("the target compiler runs");
        vm_b.run().expect("the target compiler runs");
        let ra = vm_a.global("result").expect("the result global binds");
        let rb = vm_b.global("result").expect("the result global binds");
        assert_eq!(ra, rb, "the compile rejection records must agree");
    });
}

// ---------- cross-stage consumption: the record grammar ----------

#[test]
fn twin_products_speak_the_shared_record_grammar() {
    deep_stack(|| {
        // The product values ARE the cross-stage contract: the
        // `result` records the .ktf twins produce are the same
        // record grammar the downstream harness consumes for the
        // .krf originals. Spot-decoded through the heap, position
        // by position: the reader's `("ok" form ...)` chain, the
        // first form's `("list" s e n children...)` record, and
        // the head child's `("ident" s e "add" 0)` atom record.
        let probe = "(add 1 2)";
        let (_, b) = reader_pair(probe);
        let bc_b = compile_target_text(&b);
        let mut vm_b = Vm::new(bc_b).expect("the target reader runs");
        vm_b.run().expect("the target reader runs");
        let heap = vm_b.heap();
        // nth(v, i): the i-th element of a proper list value.
        let nth = |v: &Value, i: usize| -> &Value {
            let mut cur = v;
            for _ in 0..i {
                let Value::Pair(r) = cur else {
                    panic!("the record chain walks pairs");
                };
                let Some(HeapObj::Pair(_, cdr)) = heap.get(*r) else {
                    panic!("the record chain walks live pairs");
                };
                cur = cdr;
            }
            let Value::Pair(r) = cur else {
                panic!("the record chain walks pairs");
            };
            let Some(HeapObj::Pair(car, _)) = heap.get(*r) else {
                panic!("the record chain walks live pairs");
            };
            car
        };
        let result = vm_b.global("result").expect("the result global binds");
        // ("ok" form ...)
        assert_eq!(nth(result, 0), &Value::Str(std::rc::Rc::from("ok")));
        // form[0] = ("list" s e children...) — the reader's record
        // grammar (no count field; children start at index 3).
        let first_form = nth(result, 1);
        assert_eq!(nth(first_form, 0), &Value::Str(std::rc::Rc::from("list")));
        // child[0] = ("ident" s e "add" ...) — the head atom's record.
        let head_child = nth(first_form, 3);
        assert_eq!(nth(head_child, 0), &Value::Str(std::rc::Rc::from("ident")));
        assert_eq!(
            nth(head_child, 3),
            &Value::Str(std::rc::Rc::from("add")),
            "the head atom's symbol text rides the record grammar"
        );
    });
}

// ---------- the prefix twins (the naming guard's round trip) ----------

#[test]
fn prefix_twins_carry_the_same_data_in_both_skins() {
    // The driver's transcode round-trip checks internally; this
    // case pins the four injection names and the data identity at
    // the text face (the probes cover ints, strings, bools and
    // nesting — the record grammar's whole payload family).
    let probe = "(define r 1)";
    let target_byte = target_byte_table_prefix("(add 1 2)");
    assert!(
        target_byte.starts_with("define(source_bytes, quote(("),
        "the byte prefix names source_bytes: {target_byte}"
    );
    let target_tokens =
        target_token_table_prefix(probe).expect("the probe lexes for the target prefix");
    assert!(
        target_tokens.starts_with("define(tokens, quote(("),
        "the token prefix names tokens: {target_tokens}"
    );
    let forms = read_program(FILE, probe).expect("the probe reads");
    let target_forms = target_forms_stream_prefix(&forms);
    assert!(
        target_forms.starts_with("define(forms, quote(("),
        "the forms prefix names forms: {target_forms}"
    );
    let items = expand_program(&forms).expect("the probe expands");
    let target_items = target_items_stream_prefix(&items);
    assert!(
        target_items.starts_with("define(items, quote(("),
        "the items prefix names items: {target_items}"
    );
    // The empty probes ride the `nil` datum face on both skins.
    let empty = target_byte_table_prefix("");
    assert_eq!(empty, "define(source_bytes, quote(nil));\n");
}

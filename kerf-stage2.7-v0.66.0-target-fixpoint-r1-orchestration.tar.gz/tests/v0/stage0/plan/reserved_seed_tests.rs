//! Cross-crate integration tests for the Stage 0.10 reserved face —
//! the §7.1 consumption standard (test doc: docs/tests/v0/stage0/plan/
//! reserved.md §2): all four contract families named and exercised from
//! the workspace root position (the aggregate `kerf` crate re-export
//! path), the downstream generic-consumer shape, the executable cache
//! behavior contract end-to-end, and the externally reachable error
//! face in R8 shape.

use kerf::core::reserved::cache::{
    CacheKey, CachedResult, CompilationCache, check_compilation_cache_contract,
};
use kerf::core::reserved::capability_io::{IOError, IoErrorKind, ReadCapability, WriteCapability};
use kerf::core::reserved::effects::{EffectOp, EffectSystem};
use kerf::core::reserved::multistage::{CodeCarrier, Expr, MultiStage};

use std::collections::HashMap;

/// Local cache witness at the root position (the std `HashMap` itself
/// cannot implement the frozen trait — the orphan rule, same
/// dependency-direction discipline as the api_tests newtype).
struct RootCache {
    map: HashMap<CacheKey, CachedResult>,
}

impl CompilationCache for RootCache {
    fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
        self.map.get(&key).cloned()
    }

    fn store(&mut self, key: CacheKey, result: CachedResult) {
        self.map.insert(key, result);
    }

    fn invalidate(&mut self, key: CacheKey) {
        self.map.remove(&key);
    }
}

fn fresh_cache() -> RootCache {
    RootCache {
        map: HashMap::new(),
    }
}

// ---- Positive: the four families through the aggregate re-export ----

#[test]
fn all_four_families_reachable_through_the_root_aggregate() {
    // The reserved face is consumed through `kerf::core::reserved`, the
    // workspace-aggregate path — the L4 face is downstream-reachable
    // exactly as the freeze intends.
    assert_eq!(
        std::mem::size_of::<ReadCapability>(),
        0,
        "effects-adjacent capability token is a ZST"
    );
    assert_eq!(
        std::mem::size_of::<WriteCapability>(),
        0,
        "write token is a ZST"
    );
    let key = CacheKey::from_digest([3u8; 32]);
    assert_eq!(key.digest(), &[3u8; 32], "cache key round-trips");
}

// ---- Positive: effects / multistage witnesses at the root position ----

#[test]
fn effects_witness_runs_through_the_root_position() {
    struct RootEffects;

    enum RootEffect {
        Double(u32),
    }

    impl EffectOp for RootEffect {
        type Result = u32;
    }

    impl EffectSystem for RootEffects {
        type Effect = RootEffect;
        type Handler = u32;
        type Continuation = ();
        type Value = u32;

        fn perform(&self, effect: RootEffect) -> u32 {
            match effect {
                RootEffect::Double(n) => n * 2,
            }
        }

        fn handle(&self, handler: u32, computation: impl FnOnce() -> u32) -> u32 {
            computation() + handler
        }
    }

    let system = RootEffects;
    assert_eq!(system.perform(RootEffect::Double(21)), 42);
    assert_eq!(system.handle(7, || 35), 42);
}

#[test]
fn multistage_witness_runs_through_the_root_position() {
    struct RootExpr;

    impl Expr for RootExpr {}

    struct RootCode(i64);

    impl CodeCarrier for RootCode {
        type Inner = i64;
        type Result = i64;
    }

    struct RootStaging;

    impl MultiStage for RootStaging {
        type Code = RootCode;

        fn quote<E: Expr>(_expr: E) -> RootCode {
            RootCode(21)
        }

        fn splice(code: RootCode) -> i64 {
            code.0
        }

        fn run(code: RootCode) -> i64 {
            code.0 * 2
        }
    }

    let code = RootStaging::quote(RootExpr);
    assert_eq!(RootStaging::splice(code), 21, "splice yields the inner");
    let code = RootStaging::quote(RootExpr);
    assert_eq!(RootStaging::run(code), 42, "run reaches the result");
}

// ---- Positive: the downstream generic-consumer shape ----

/// A downstream consumer written against the abstraction only (SOP
/// §21.12-10(2) in action: this function compiles against the frozen
/// trait, not against any concrete cache).
fn drive_cache<C: CompilationCache>(cache: &mut C) -> (usize, usize) {
    let mut hits = 0;
    let mut misses = 0;
    for tag in 1..=3u8 {
        let mut digest = [0u8; 32];
        digest[0] = tag;
        let key = CacheKey::from_digest(digest);
        match cache.get_cached(key) {
            Some(_) => hits += 1,
            None => misses += 1,
        }
        cache.store(key, CachedResult::new(vec![tag]));
    }
    (hits, misses)
}

#[test]
fn downstream_generic_consumer_compiles_and_runs() {
    let mut cache = fresh_cache();
    let (hits, misses) = drive_cache(&mut cache);
    assert_eq!((hits, misses), (0, 3), "first pass is all misses");
    let (hits, misses) = drive_cache(&mut cache);
    assert_eq!((hits, misses), (3, 0), "second pass is all hits");
}

#[test]
fn cache_contract_kit_passes_end_to_end_at_the_root() {
    let mut cache = fresh_cache();
    check_compilation_cache_contract(&mut cache);
}

// ---- Negative: behavior probes through the downstream shape ----

#[test]
fn downstream_consumer_sees_misses_before_stores() {
    let mut cache = fresh_cache();
    let (_, misses) = drive_cache(&mut cache);
    assert_eq!(misses, 3, "never-stored keys must miss");
}

#[test]
fn invalidate_then_get_misses_through_the_consumer() {
    let mut cache = fresh_cache();
    let _ = drive_cache(&mut cache);
    let mut digest = [0u8; 32];
    digest[0] = 2;
    let key = CacheKey::from_digest(digest);
    cache.invalidate(key);
    assert!(
        cache.get_cached(key).is_none(),
        "get after invalidate must miss"
    );
}

#[test]
fn cross_key_stores_do_not_leak_through_the_consumer() {
    let mut cache = fresh_cache();
    let _ = drive_cache(&mut cache);
    let mut digest_a = [0u8; 32];
    digest_a[0] = 1;
    let mut digest_b = [0u8; 32];
    digest_b[0] = 2;
    assert_eq!(
        cache.get_cached(CacheKey::from_digest(digest_a)),
        Some(CachedResult::new(vec![1])),
        "key 1 holds only its own result"
    );
    assert_eq!(
        cache.get_cached(CacheKey::from_digest(digest_b)),
        Some(CachedResult::new(vec![2])),
        "key 2 holds only its own result"
    );
}

// ---- Negative: the externally reachable error face ----

#[test]
fn io_error_face_renders_in_r8_shape_from_the_root() {
    for kind in [
        IoErrorKind::Eof,
        IoErrorKind::Denied,
        IoErrorKind::Interrupted,
        IoErrorKind::Other,
    ] {
        let err = IOError::new(kind, "root probe");
        let text = err.to_string();
        let first = text.chars().next().expect("non-empty display");
        assert!(first.is_lowercase(), "lowercase start required: `{text}`");
        assert!(!text.ends_with('.'), "no trailing period: `{text}`");
        assert!(text.contains("root probe"), "payload carried: `{text}`");
        assert_eq!(err.kind(), kind, "kind accessor round-trips");
        assert_eq!(err.message(), "root probe", "message accessor round-trips");
    }
}

// ---- Positive: token Debug forms observable from the root ----

#[test]
fn token_debug_forms_render_bare_names_from_the_root() {
    // The hand-written Debug renders the bare token names — the
    // sealed-token discipline is externally observable.
    let read = format!("{:?}", std::mem::size_of::<ReadCapability>());
    assert_eq!(read, "0", "read token stays a ZST");
    let write = format!("{:?}", std::mem::size_of::<WriteCapability>());
    assert_eq!(write, "0", "write token stays a ZST");
}

// ---- Positive: overwrite semantics through the downstream consumer ----

#[test]
fn downstream_consumer_observes_latest_store_wins() {
    let mut cache = fresh_cache();
    let mut digest = [0u8; 32];
    digest[0] = 5;
    let key = CacheKey::from_digest(digest);
    cache.store(key, CachedResult::new(vec![1]));
    cache.store(key, CachedResult::new(vec![2]));
    assert_eq!(
        cache.get_cached(key),
        Some(CachedResult::new(vec![2])),
        "the latest store wins through the consumer shape"
    );
}

// ---- Negative: the kit's detection power from the root position ----

/// A broken cache whose `get_cached` always misses — the executable
/// behavior spec must catch it from any consumer position.
struct RootBrokenCache {
    map: HashMap<CacheKey, CachedResult>,
}

impl CompilationCache for RootBrokenCache {
    fn get_cached(&self, _key: CacheKey) -> Option<CachedResult> {
        None
    }

    fn store(&mut self, key: CacheKey, result: CachedResult) {
        self.map.insert(key, result);
    }

    fn invalidate(&mut self, key: CacheKey) {
        self.map.remove(&key);
    }
}

#[test]
#[should_panic(expected = "store-then-get must hit")]
fn cache_contract_kit_catches_broken_impls_at_the_root() {
    let mut cache = RootBrokenCache {
        map: HashMap::new(),
    };
    check_compilation_cache_contract(&mut cache);
}

// ---- r2: the capability space at the root position (0.10-r2) ----
//
// The general capability-model framework consumed from the workspace
// root: the family contract implemented by a LOCAL model (the
// canonical `clock` resource — the outside-crate extension proof),
// the registration mechanism end-to-end, and the freeze-continuity
// of the 0.10-r1 io face through its re-exported path.

use kerf::core::reserved::capability::family::{CapabilityModelDescriptor, CapabilityModelFamily};
use kerf::core::reserved::capability::io::IoModel;
use kerf::core::reserved::capability::registry::{CapabilityModelRegistry, RegistryErrorKind};
use kerf::core::reserved::capability::token::TokenCalculus;

/// A root-position model family — the canonical clock resource. Its
/// existence at this position is the extension proof: a model
/// defined entirely outside kerf-core enters the capability space
/// through the reserved mechanism, with zero framework changes.
struct RootClockModel;

#[derive(Debug, Clone, PartialEq, Eq)]
struct ClockError {
    detail: String,
}

impl CapabilityModelFamily for RootClockModel {
    type Error = ClockError;
    fn descriptor() -> CapabilityModelDescriptor {
        CapabilityModelDescriptor::new("clock", &["clock.now"], "ClockSource")
    }
}

/// The downstream generic-consumer shape: a function that registers
/// ANY capability model family into any registry — the L4 face
/// serving downstream positions (the `drive_cache` precedent).
fn register_any_family<F: CapabilityModelFamily>(
    registry: &mut CapabilityModelRegistry,
) -> Result<&CapabilityModelDescriptor, kerf::core::reserved::capability::registry::RegistryError> {
    registry.register::<F>()
}

#[test]
fn root_family_and_registry_faces_are_reachable() {
    // The framework's public surface through the root aggregate path.
    let card = CapabilityModelDescriptor::new("fs", &["fs.read"], "FsIO");
    assert_eq!(card.name(), "fs");
    let registry = CapabilityModelRegistry::new();
    assert!(registry.is_empty());
}

#[test]
fn root_clock_model_registers_alongside_io_additively() {
    // The extension ability end-to-end: io (the first concrete
    // model) and clock (a root-defined model) share one closed
    // world, and the closed world grows additively.
    let mut registry = CapabilityModelRegistry::new();
    register_any_family::<IoModel>(&mut registry).expect("io registers");
    let clock = register_any_family::<RootClockModel>(&mut registry)
        .expect("a root-defined family registers through the generic consumer");
    assert_eq!(clock.name(), "clock");
    assert_eq!(
        registry.governed_authorities(),
        vec!["io.read", "io.write", "clock.now"],
        "the closed world spans crate and root positions"
    );
}

#[test]
fn root_duplicate_registration_fails_closed() {
    let mut registry = CapabilityModelRegistry::new();
    register_any_family::<RootClockModel>(&mut registry).expect("first registers");
    let err = register_any_family::<RootClockModel>(&mut registry)
        .expect_err("the same model is rejected at the root position");
    assert_eq!(err.kind(), RegistryErrorKind::DuplicateModel);
    assert_eq!(registry.len(), 1, "a rejected registration adds nothing");
}

#[test]
fn root_governing_model_resolves_across_positions() {
    let mut registry = CapabilityModelRegistry::new();
    register_any_family::<IoModel>(&mut registry).expect("io registers");
    register_any_family::<RootClockModel>(&mut registry).expect("clock registers");
    assert_eq!(
        registry.governing_model("io.write").map(|d| d.name()),
        Some("io"),
        "the crate-side authority resolves to the crate-side model"
    );
    assert_eq!(
        registry.governing_model("clock.now").map(|d| d.name()),
        Some("clock"),
        "the root-side authority resolves to the root-side model"
    );
    assert!(
        registry.governing_model("gpu.launch").is_none(),
        "an ungoverned authority resolves to no one"
    );
}

#[test]
fn root_io_coherence_links_tokens_to_the_identity_card() {
    // The coherence invariant from the root position: the frozen
    // tokens' authority terms are governed by the io model's card,
    // through the re-exported 0.10-r1 path.
    let card = <IoModel as CapabilityModelFamily>::descriptor();
    let read_term =
        <kerf::core::reserved::capability_io::ReadCapability as TokenCalculus>::authority();
    let write_term =
        <kerf::core::reserved::capability_io::WriteCapability as TokenCalculus>::authority();
    assert!(card.authorities().contains(&read_term));
    assert!(card.authorities().contains(&write_term));
    assert_eq!(read_term, "io.read");
    assert_eq!(write_term, "io.write");
}

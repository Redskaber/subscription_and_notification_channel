# benchmarks/ — 性能基准政策（单一入口）

- **端到端基线唯一入口**：`cargo run --release --example stage0_baseline`
  （examples/bench/stage0_baseline.rs——SOP §14.6.4 规则 2 单一可重跑入口）。
  方法学 v2（§9.61）：优化器栅栏（std::hint::black_box——K90 best-effort
  纪律）+ 每轴预热段（max(3, iters/10)）+ 四统计量报告
  （mean/median/min/stdev——median 主判据）+ B1 子轴拆分
  （B1a read / B1b expand / B1c compile+verify——§9.44.5 触发器的阶段归因面）。
- **记录面**：docs/develop/v0/stage-0/performance-baseline.md（粘贴式基线表；
  回归判定口径 = median 恶化 >25% 噪声带；确定性计数面 = B4 gc-cycles/swept
  ——数值变化即语义变化）。
- **crate 级微基准（各 crate benches/）**：**登记态未实施**——§9.44.3 十二行
  审查为全层零热点信号，当前无轴可测；触发器 = §9.61.7 W-PERF-CRATE-BENCH
  窗（子轴归因显示某 crate 内热点而 B 系列无法刻画时开窗）。
  r60 修正记录：本文件此前主张「crate 微基准入各 crate benches/」为未兑现
  承诺（零 crate 有 benches/）——docs-reality 对账以现实为准（§9.61 PERF-6），
  该主张转为登记态政策。

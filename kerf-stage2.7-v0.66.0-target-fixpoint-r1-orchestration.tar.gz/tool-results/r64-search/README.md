# r64-search — 展开错误载荷域检索存档（第六十四轮 · §9.65）

> 依据：docs/stage0.md §9.65.2。检索主题：编译器错误/诊断载荷的身份选型（interned Symbol vs owned String）、错误族载荷的分层纪律（身份/静态描述/非身份文本）、Display/等值契约、驻留器永驻权衡。弱查披露第十一轮：q1 上游 429 限流（无文件——r63 q2/q4 同形如实登记）、q2 垃圾（yocto patchwork / android 内核 / ERIC 咖啡叶锈病——全然无关）、q3 垃圾（Grafana 指纹 / scribd）、q4 垃圾（scribd / jboss 邮件列表）、q5 弱（clippy lint 博文 + ferrocene 渲染源——m1i 主源已更权威覆盖）、q6 垃圾（PowerBuilder / SICStus Prolog / FreeBSD ssh）——全部由主源直读补位（K107-K110）。
>
> 主源路径失效记录（如实登记）：m1（docs.rs rustc_resolve/latest errors/enum.ResolutionError.html）404——docs.rs 未构建该内部 crate 页；m1b（doc.rust-lang.org/nightly/nightly-rustc/rustc_resolve/errors/enum.ResolutionError.html）404——nightly-rustc 文档路径未含该页；m1c（raw.githubusercontent rust master compiler/rustc_resolve/src/errors.rs）404——**文件已迁移**（master→main 分支 + errors.rs 拆入 diagnostics/ 目录）；m1d（api.github.com contents 目录）403 限流；m1e/m1f（diagnostics/ 与 errors/mod.rs 猜测路径）404；m1g（github tree HTML 目录页）成功——定位现路径 src/diagnostics/；m3（rustc_errors/src/diagnostic.rs）成功但 DiagArgValue 定义不在该文件；m3b（rustc_errors/src 目录页）成功定位；m3c（diagnostic_impls.rs）成功——证 DiagArgValue 在 rustc_error_messages crate；m3d（rustc_errors/src/lib.rs）成功但定义仍缺席；m3e（rustc_error_messages/src/lib.rs）成功承载。

## 检索文件（q1-q6，q1 无文件）

| 文件 | 查询 | 结果定性 |
|---|---|---|
| （q1 未落盘） | rustc_span Symbol error struct payload diagnostics ident | **上游 429 限流**（serper 400/429——r63 q2/q4 同形如实登记）；Symbol 错误载荷面由 m1i 主源直读承载 |
| q2-rustc-resolutionerror.json | rustc ResolutionError Ident Symbol variant resolution error | 垃圾（yocto patchwork / android googlesource / ERIC 咖啡叶锈病 / RustDesk 对比——全然无关）；载荷变体面由 m1i 承载 |
| q3-racket-syntax-error.json | Racket raise-syntax-error identifier symbol payload error reporting | 垃圾（Grafana 错误指纹 / scribd 无关 PDF）；Racket 面由 m4 主源直读承载 |
| q4-rustc-diagarg.json | rustc DiagArg Symbol string diagnostic arguments interned | 垃圾（scribd / jboss 邮件列表）；DiagArg 面由 m3e 主源直读承载 |
| q5-rustc-ast-ident.json | rustc_ast Ident struct Symbol Span identifier compiler | 弱（clippy manual_strip 源码 + erk.dev lint 博文 + ferrocene rustc_borrowck 渲染页——ferrocene 页与 m1i 同性质但证据密度低；不设锚）；Ident 载荷形态由 m1i（`ident: Ident` 字段实证）承载 |
| q6-interner-growth.json | string interner memory never freed growth tradeoff compiler symbols | 垃圾（PowerBuilder / SICStus Prolog / PKU 语料 / FreeBSD ssh）；永驻权衡面由 m2b（DroplessArena 源码）承载 |

## 主源直读（锚承载件 m1i / m2b / m3e / m4；目录定位件 m1g / m1h / m3b；定位链中间件 m3 / m3c / m3d；失效 JSON 件 m1 / m1b / m1c / m1d / m1e / m1f / m2 计入）

| 文件 | 源 | 锚 |
|---|---|---|
| m1i-rustc-resolve-diag-mod.json | rust-lang/rust main `compiler/rustc_resolve/src/diagnostics/mod.rs`（raw 直读 51.2KB——经 m1g HTML 目录页定位现路径：errors.rs 已拆入 diagnostics/） | **K107**——诊断结构体载荷三层纪律实证：身份层 `candidate: Symbol` / `ident_name: Symbol` / `name: Symbol` / `ident: Ident`（AssociatedFnWithSimilarNameExists / BindingShadowsSomethingUnacceptable / MacroUseNameAlreadyInUse / ExplicitUnsafeTraits 等十余结构逐字段实证；`use rustc_span::{Ident, Span, Spanned, Symbol};` 头部导入）；**非身份文本层 `snippet: String`**（UnexpectedResUseAtOpInSlicePatWithRangeSugg——代码片段非标识符身份才用 owned String）；**静态描述层 `ns_descr: &'static str`**（ProcMacroDeriveResolutionFallback——封闭静态集用静态串） |
| m3e-rustc-error-messages.json | rust-lang/rust main `compiler/rustc_error_messages/src/lib.rs`（raw 直读 12.7KB——经 m3→m3c 链路定位：DiagArgValue 定义在 rustc_error_messages 而非 rustc_errors） | **K108**——`pub enum DiagArgValue { Str(Cow<'static, str>), Number(i32), StrListSepByAnd(Vec<Cow<'static, str>>) }`——诊断消息参数桥 = **静态生命周期 Cow**：Symbol::as_str 零拷贝喂入（驻留串进程 lifetime），大整数降级转字符串入 Str——消息参数与身份载荷两分离（身份在结构体字段 = Symbol；渲染参数 = Cow<'static, str>） |
| m4-racket-exns.json | Racket Reference「10.2 Exceptions」（curl 直读 456.4KB） | **K109**——raise-syntax-error 契约：`The result must be a symbol if a name can be extracted from the syntax object, #f otherwise`（**错误 name 载荷 = symbol（或 #f）——从语法对象提取身份，绝无新字符串拷贝**）+ `The name argument is usually #f when expr is provided`（expr = 出错语法对象——span 载体走 syntax object，与 kerf「位置住 payload/Display 无位置」§9.56 DIAG-1 对照面）+ 专用子族 `exn:fail:syntax:unbound`（unbound identifier 家族独立变体——kerf UnboundIdentifier 同型）+ 错误消息经 error-message-adjuster 协议（`name : (or/c symbol? #f)` + `message-realm : symbol?`——全程 symbol 身份） |
| m2b-rustc-span-symbol-src.json | rust-lang/rust main `compiler/rustc_span/src/symbol.rs`（raw 直读 88.0KB） | **K110**——`#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] pub struct Symbol(SymbolIndex)`（**Copy newtype over u32——错误载荷克隆 = 4 字节拷贝**）+ `pub fn intern(str: &str) -> Self`（边界一次性驻留纪律）+ `symbols!` 预驻留宏表（关键字/原语名进程启动即驻留）+ DroplessArena 驻留存储（**永驻权衡的正面登记：驻留串进程 lifetime 不释放——缺陷面 = 内存永占；缓解面 = 名字由前端已驻留（错误只是引用既有条目）+ 受源程序规模约束 + 冷路径**）+ `Avoid this except for things like deserialization... Use intern instead`（new(n) 私有构造纪律注记） |

## 锚总账

K107（rustc_resolve 诊断结构载荷三层纪律：身份=Symbol/Ident · 非身份文本=String · 静态描述=&'static str）· K108（rustc_error_messages DiagArgValue = Cow<'static, str> 桥——Symbol as_str 零拷贝喂消息参数，身份与渲染参数两分离）· K109（Racket raise-syntax-error name = symbol-from-syntax-object 或 #f + exn:fail:syntax:unbound 专用子族 + syntax object 承载位置）· K110（rustc_span Symbol = Copy u32 newtype + intern 边界纪律 + DroplessArena 永驻权衡正面登记）——四主源锚（q5 ferrocene 同性质低密度不设锚）。存档 23 文件（磁盘核验：查询落盘五件 q2/q3/q4/q5/q6 + 失效 q1 无文件 ×1 + 主源十七件[失效 JSON 件 m1/m1b/m1c/m1d/m1e/m1f/m2 七件计内 + 目录定位件 m1g/m1h/m3b 三件 + 定义定位链中间件 m3/m3c/m3d 三件 + 锚承载成功件 m1i/m2b/m3e/m4 四件] + README）。

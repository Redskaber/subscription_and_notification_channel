# r79-search — Stage 2.1 LA 首刀 B 型审查先行增量检索（第七十九轮 · Task 57-c）

> 检索义务依据：stage-2-plan.md §6「审查轮形态」——2.1 LA 实施面新域开启按
> B 型审查先行义务执行增量检索（§9.54 检索覆盖矩阵：K42-K53 覆盖语义面，
> 本轮增量 = **LA-2 捕获描述符编码** + **LA-3 操作码编码**两个「编码裁定留
> 规划轮」遗留位）。
>
> 通道：z-ai web_search（q1/q2）+ 主源直读 curl（m1-m5）。弱查披露：q1 命中
> lua.org 主源两件（强）；q2 命中 docs.python.org 主源（强）；m1 首次抓取
> 6KB 截断页（无 UA 头）→ 加 UA 重抓成功——如实登记。

## 查询清单

| # | 查询 | 结果 |
|---|------|------|
| q1 | Lua 5.4 Upvaldesc instack idx lparser.h upvalue descriptor proto | lua.org lparser.h/lparser.c 双主源命中（强） |
| q2 | CPython code object co_freevars co_cellvars LOAD_DEREF closure cells | docs.python.org c-api/code.html + dis.html 命中（强） |

## 主源直读清单

| # | 文件 | 字节 | 来源 |
|---|------|------|------|
| m1 | m1-lua-lparser-h.html | 10,708 | https://www.lua.org/source/5.4/lparser.h.html（VUPVAL 变量种别 + actvar 机制） |
| m2 | m2-lua-lobject-h.html | — | https://www.lua.org/source/5.4/lobject.h.html（**Upvaldesc 本体**） |
| m3 | m3-cpython-code-objects.html | — | https://docs.python.org/3/c-api/code.html（co_freevars/co_cellvars 定义） |
| m4 | m4-cpython-dis.html | — | https://docs.python.org/3/library/dis.html（LOAD_DEREF/MAKE_CELL/STORE_DEREF） |
| m5 | m5-lua-lopcodes-h.html | — | https://www.lua.org/source/5.4/lopcodes.h.html（OP_GETUPVAL/OP_SETUPVAL） |

## 新锚 K189-K192（LA-2/LA-3 编码裁定载荷）

- **K189**（Lua 5.4.9 lobject.h Upvaldesc 直读）：`typedef struct Upvaldesc {
  TString *name; lu_byte instack; lu_byte idx; lu_byte kind; }` ——
  「whether it is in stack (register)」/「index of upvalue (in stack or in
  outer function's list)」。**两源描述符正典**：instack=1 → 定义帧栈槽；
  instack=0 → 定义闭包自身 upvalue 表索引（传递捕获）。kerf LA-2 同构。
- **K190**（CPython 3 c-api/code.html 直读）：`co_freevars` = names of the
  free (closure) variables（每 code object 一表）；`co_cellvars` = locals
  referenced by nested functions。**每原型一捕获表**的工业形态（名字键 =
  自省面；运行面走 cell 索引）。
- **K191**（CPython 3 dis.html 直读）：`LOAD_DEREF(i)` loads the cell in
  slot i of the "fast locals" storage；3.11 起 i 不再偏移 co_varnames——
  **cell 与局部统一索引空间**形态。kerf 不采纳（Frame 冻结 3-ext 约束——
  统一空间要求帧布局变更）；Lua 分离式为 kerf 形态。
- **K192**（Lua 5.4.9 lopcodes.h 直读）：`OP_GETUPVAL A B: R[A] :=
  UpValue[B]` + `OP_SETUPVAL A B: UpValue[B] := R[A]` —— **独立捕获访问
  操作码族 + 索引操作数**正典（扁平闭包）；深度寻址统一形（LoadLex）属
  链式环境族——§9.51.4 方案 B 已否决，LA-3 采分离操作码族定案。

## 编码裁定结论（57-c 交付——详见 stage0.md §9.80.3）

- LA-2：`FuncProto.captures: Vec<CaptureSource>`，`CaptureSource::{Local(u32),
  Captured(u32)}` 两源枚举（K189 同构；键于槽位/捕获区索引非名字文本——
  §9.52.5 Symbol 身份基座用于编译期分析，产物落索引）。
- LA-3：分离操作码族（K192 同构）——MUV 2 落地（本轮零操作码变更）。

# r76-search — 类型检查推断算法域知识检索存档（第七十六轮 · Task 54-b）

> 域：typecheck 推断算法语义面（§9.77）。锚定负载 = 13 主源文件直读（771,927 B）。
> 弱查第二十四轮披露：q1/q4/q5b 垃圾 · q2/q6 弱 · q3 中（GHC Constraint hackage
> 注释 + tweag.io 部分有效）· q5 首投 429（上游 42900）——锚定负载全由主源直读承载
> （沿 r69 全弱轮先例）。
>
> 获取通道实录（方法学登记）：GitHub API 403 限流（r75 同形态）+
> raw.githubusercontent 部分路径 404（rustc unify.rs → relate/ 目录迁移；OCaml
> typing.ml → 五拆——迁移本身即前沿事实）+ jsDelivr rust 仓超 50MB 拒绝 →
> **sparse-clone git 协议通道首用**（--depth 1 --filter=blob:none --sparse）承载
> rustc 六件与 OCaml 五件；GHC 一件经 raw @ master 直读成功；rust-analyzer 一件
> 经 jsDelivr 直读成功。

## 查询（8 件落盘）

| 文件 | 查询 | 质量判定 |
|------|------|---------|
| q1-rustc-unify.json | rustc type inference unify occurs check metavariable snapshot rollback | 垃圾（词典噪声） |
| q2-ocaml-levels.json | OCaml typing.ml level-based generalization union-find path compression | 弱-中（论文/团队页非实现源） |
| q3-ghc-unify.json | GHC constraint solver type equality occurs check Unify.hs untouchable | 中（hackage 源码注释 + tweag.io——K176 由 m3 直读承载） |
| q4-value-restriction.json | value restriction let-polymorphism generalization escape free type variables | 垃圾 |
| q5b-rust-analyzer.json（q5 首投 429 未落盘） | rust-analyzer inference table unify metavariable chalk-solver | 垃圾 |
| q6-ts-bidi.json | TypeScript bidirectional type checking checker.ts contextual typing | 弱（未获主源） |
| q7-effect-rows.json | effect row polymorphism inference set operations implementation Koka Links | 弱-中（未获实现源） |

## 主源（13 件）

| 锚 | 文件 | 字节 | 通道 | 用途 |
|----|------|------|------|------|
| K174 | m1-rustc-unify_key.rs | 6,230 | sparse-clone | UnifyKey/RegionVidKey——ena UnificationTable 家族入口 |
| K174 | m4-rustc-relate.rs | 14,321 | sparse-clone | relate/type_relating.rs——TypeRelation 基建 |
| K174 | m6-rustc-snapshot.rs | 4,091 | sparse-clone | snapshot/mod.rs——probe/commit_if_ok 快照族（INF-1 直接形状锚） |
| K174 | m7-rustc-generalize.rs | 32,672 | sparse-clone | relate/generalize.rs——泛化的 variance 驱动形态 |
| K174 | m9-rustc-typevar.rs | 15,196 | sparse-clone | type_variable.rs——origin 记录与发散维度 |
| K174 | m8-rustc-lexresolve.rs | 40,018 | sparse-clone | lexical_region_resolve——迭代求解器组织形态参考 |
| K175 | m5-ra-infer.rs | 102,716 | jsDelivr | rust-analyzer hir-ty infer.rs——单文件大推断体组织形态 |
| K176 | m3-ghc-unify.hs | 216,623 | raw @ master | GHC Tc/Utils/Unify.hs——uType/unifyType occurs 与 CheckForCycle |
| K177 | m11-ocaml-btype.ml | 30,047 | sparse-clone | deep_occur 的 level+mark 加速（大类型 20-45%）与无环假定 walker 纪律 |
| K178 | m13-ocaml-value-rec.ml | 47,214 | sparse-clone | POPL 2021 Reynaud/Scherer/Yallop letrec 模式系统——静态可构造分类 |
| K178 | m12-ocaml-ctype.ml | 254,938 | sparse-clone | OCaml unify/occurs/levels 主实现 |
| K179 | m14-ocaml-typing-recovery.ml / m15-ocaml-recovery-state.ml | 4,000 / 3,861 | sparse-clone | 现代错误恢复状态机——kerf definite-error-only 的前沿对照登记（Stage 2+ 诊断体验窗参考） |

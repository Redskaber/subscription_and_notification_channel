# r83-search — instruction emission domain (Stage 2.3 second Pass)

Round 83 / Task 61-b knowledge search (B-type frontier review, the
r75/r79/r82 archive discipline). Domain: design backing for Stage 2.3,
the fixpoint window **second Pass** — rewriting the compiler's
instruction emission surface (the `crates/kerf-compiler/src/compile.rs`
emission core: single-path `emit` with the opcode push/pop table,
jump emission with the depth riding in the unused `b` slot, back-
patching with the depth assertion, else-entry depth reset, the tail
terminator `ret`/`halt`, per-expression emission, proto finalization
with the placeholder-drain witness, and the per-instruction
`debug_info` table parallel to the instruction stream) as the `.krf`
self-hosted segment extension of `selfhost/v1/compiler.krf`, with the
per-Pass parity skeleton extended from analysis products (r82, first
Pass) to the instruction stream itself. Output feeds the design
section stage0.md §9.84.

Code grounding (read this round, terminology source): compile.rs
module doc ("Direct-style compilation with jump backpatching …
Compile-time bookkeeping (depth tracking, patch assertions,
placeholder drain) is the first defense layer and fails closed"),
`emit` L211-223, `emit_jump` L232-237 ("Lua patchlist discipline
adapted: `a` holds the placeholder sentinel while pending, `b` holds
the source depth"), `patch` L244-267, `set_depth` L272-274,
`emit_tail_terminator` L287-290, `finish` L712-726 (`UnpatchedJump`,
"the first placeholder-sentinel jump in code order is the
deterministic defense witness"); bytecode.rs L99-100 (`debug_info`
parallel to `code`); verify.rs L63-64 ("debug_info parallelism"); the
pops/pushes table opcode.rs L159/L187. Precision note (honest, no
fabrication): the module doc's "deduplicated" adjective attaches to
the **constant pool** (Lua `addk` slot-identity, L29-33 + L157); the
`debug_info` table is dense by design — one span per instruction,
strict parallelism as the §19.3 invariant 3, checked by `verify`.

Channel: z-ai web_search only (q1-q6 + two variant retries q1b/q5b,
the r72/r82 precedent), raw JSON all retained in this directory.
No 429s this round. The two downgrades below are coverage/relevance
judgments, not rate-based: q1 returned only 3 results (all lua.org
primary — the implementation file `lcode.c` was not surfaced, so the
q1b retry completed the topic), and q5's phrasing drowned in
linker-level debug-info dedup literature (q5b recovered the actual
mechanism).

## Query ledger

| id | query | verdict |
|----|-------|---------|
| q1 | Lua 5.4 lparser.c patchlist backpatching jump list code generation forward jumps luaK_patchlist | **partial/thin** (3 results, all lua.org primary: lparser.c "forward jump; will be resolved when the label is declared" + lparser.h "patch list of 'exit when true'/'exit when false'" — but `lcode.c`, where `luaK_patchlist` lives, was missed — completed by q1b, the r72/r82 variant-retry precedent) |
| q1b | Lua 5.4 lcode.c source luaK_patchlist luaK_concat luaK_patchtojump jump list NoJump instruction | **strong** (lua.org lcode.c primary with `luaK_patchlist` signature + lparser.c usage pattern `luaK_concat`/`luaK_patchtohere` + Lua 5.3 `getjump` "Used to traverse a list of jumps") |
| q2 | two-pass assembler forward reference resolution backpatching compiler construction classic technique Knuth | **strong** (assembler architecture + FIU course notes + GeeksforGeeks backpatching + Knuth MIX two-pass assembly) |
| q3 | JVM bytecode max_stack computation operand stack depth analysis compiler StackMapTable verifier | **strong** (docs.oracle.com JVMS §4.7.3 primary ×2 + Wikipedia "computed by the compiler" + StackOverflow depth-computation question + verifier/StackMapTable corroboration) |
| q4 | DWARF debug info line number program instruction address source line mapping compiler generation | **strong** (dwarfstd.org spec PDFs + LNP-as-VM walkthrough + deep-dive blog + GHC compiler-emission docs) |
| q5 | compiler debug location table deduplication identical adjacent instructions source span reuse | **weak** (hits were linker/debug-section dedup — LLD RFC, DebugFission, CodeView LF_FUNC_ID — not per-instruction location tables; recovered by q5b) |
| q5b | DWARF line number table row only emitted when source location changes consecutive addresses same statement shared row state machine | **strong** (Go `debug/dwarf` LineEntry primary + dwarfstd DWARF4 line-number-program spec + Swatinem deep dive + LLVM line-table granularity RFC) |
| q6 | translation validation bytecode instruction stream equivalence checking compiler output comparison | **strong** (ACM PLDI'00 Necula GCC translation-validation paper primary + NYU thesis + HotSpot C2 JIT validation thesis + ASPLOS'21 instruction-level validation; extends the r82 K196 school from analysis products to the emitted instruction stream) |

## Per-topic findings

### Topic 1 — Lua patchlist: pending jumps live in the instruction stream itself (q1 thin + q1b strong)

* https://www.lua.org/source/5.4/lcode.c.html — primary: the code
  generator itself; snippet hits the function kerf adapts: "void
  luaK_patchlist (FuncState *fs, int list, int target) { lua_assert"
  and the doc comment "jump instruction at position 'pc' to jump to
  'dest'. ** (Jump addresses are …)".
* https://www.lua.org/source/5.4/lparser.h.html — the FuncState /
  expdesc declarations: "patch list of 'exit when true' */ int f; /*
  patch list of 'exit when false'" — boolean test exits are
  *themselves patch lists*, and "Code generation for variables and
  expressions can be delayed to allow optimizations".
* https://www.lua.org/source/5.4/lparser.c.html — the usage pattern,
  verbatim: "luaK_concat(fs, escapelist, luaK_jump(fs)); /* must jump
  over it */ luaK_patchtohere(fs, jf);" plus the goto machinery:
  "forward jump; will be resolved when the label is declared".
* https://www.lua.org/source/5.3/lcode.c.html — the list traversal
  core: "Used to traverse ** a list of jumps. */ static int getjump
  (FuncState *fs, int pc) { int offset = GETARG_sBx(fs->f->code".

Synthesis: Lua's one-pass parser/codegen never buffers jump targets
out of line — a pending jump's own operand slot stores the link to
the next pending jump (`NO_JUMP`-terminated), `luaK_concat` splices
lists, and `luaK_patchlist` walks and rewrites the slots when the
label becomes known. This is exactly the discipline the kerf comment
names ("Lua patchlist discipline adapted"): the instruction stream
carries its own patch bookkeeping. Kerf's adaptation (one placeholder
per jump, depth riding in `b`, restored to the zero-operand output
contract by `patch`) is the same idea with the linked-list replaced
by a single-slot sentinel plus a depth assertion — the CP segment's
contribution is again to hoist the inline bookkeeping into a
differentially checkable emission surface.

### Topic 2 — Forward references: two-pass sweep vs one-pass backpatch (q2, strong)

* https://www.geeksforgeeks.org/compiler-design/backpatching-in-compiler-design —
  "Backpatching is a method to deal with jumps in the control flow
  constructs like if statements, loops, etc in the intermediate code
  generation" — the textbook framing of the one-pass alternative.
* https://simplifycpp.org/articles/a0748/architecture-of-an-assembler-symbol-resolution-and-backpatching —
  "Traditional assemblers follow a two-pass strategy: Pass 2: Resolve
  all symbols Finalize addresses Backpatch all unresolved references".
* http://users.cis.fiu.edu/~downeyt/cop3402/two-pass.htm — course
  notes on the forward-reference problem: "This is known as a forward
  reference. If the assembler is processing the file one line at a
  time, then it doesn't know where LATER is when it first
  encounters…".
* https://esolangs.org/wiki/MIX_(Knuth) — the Knuth/MIX lineage: "Two
  pass assembly, so that future references are possible."

Synthesis: the classic literature gives two resolutions of the
forward-jump problem — emit-then-patch in a second sweep (assembler
pass 2, MIX) or patch lists maintained inline during a single pass
(backpatching). Kerf's direct-style compiler takes the single-pass
branch (the only emit path is `emit`; jumps are emitted immediately
with a placeholder and patched when the target `here()` is known),
with `finish`'s placeholder scan as the drain guarantee that the
sweep is complete — the `UnpatchedJump` witness in code order rather
than emission order is kerf's determinism refinement of the classic
"check no unresolved references remain".

### Topic 3 — JVM max_stack: compiler-computed operand-stack depth (q3, strong)

* https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html —
  primary (JVMS §4.7.3, the Code attribute): "The value of the
  max_stack item gives the maximum depth of the operand stack of this
  method (§2.6.2) at any point during execution of the method" (also
  mirrored in the cr.openjdk.org JEP 401 spec draft hit).
* https://en.wikipedia.org/wiki/JVM_bytecode — "The maximum size of
  the operand stack and local variable array, **computed by the
  compiler**, is part of the attributes of each method. : 4.7.3".
* https://stackoverflow.com/questions/54342508/stack-4-in-java-bytecode-how-does-the-java-compiler-compute-the-4-value-depth —
  the practitioner's question this Pass answers for kerf: "stack=4
  means that the stack can have at most 4 objects. But how does the
  compiler [compute it]?".
* https://www.tmdevlab.com/jvm-engineering-enterprise-performance.html —
  the verifier side: "the JVM verifies that the bytecode is
  structurally valid and type-safe. The verifier uses the
  StackMapTable, type states".

Synthesis: the JVM product records, per method, the maximum operand-
stack depth the *compiler* computed instruction-by-instruction, and
the verifier independently re-derives stack behavior (StackMapTable
snapshots) as the second defense layer. Kerf's `emit` is the same
per-instruction depth computation — `p.depth = p.depth - pops +
op.pushes()`, fails closed on underflow — except kerf tracks the
*current* depth (with the post-merge depth asserted at every `patch`,
recorded in the jump's `b` slot) rather than only the max, and
`Bytecode::verify` plays the verifier role. The two-layer design
(bookkeeping fails closed, then `verify`) is the documented kerf
analogue of the compiler-computes / verifier-checks split.

### Topic 4 — DWARF line number program: per-instruction source mapping (q4, strong)

* https://dwarfstd.org/doc/DWARF4.pdf — primary (the standard):
  "6.2.3 Line Number Program Instructions. The state machine
  instructions in a line number program belong to one of three
  categories: special…" (DWARF 2/3 spec PDFs also hit).
* https://simplifycpp.org/articles/a0783/advanced-topics-adding-debug-info-dwarf-overview —
  "The LNP is a virtual machine (DWARF Line Number VM) that emits
  opcodes describing instruction addresses and their associated
  file/line pairs."
* https://swatinem.de/blog/dwarf-lines — "A deep dive into DWARF line
  programs": "the DWARF line program is also encoded as a state
  machine."
* https://ghc.gitlab.haskell.org/ghc/doc/users_guide/debug-info.html —
  the compiler side: "Emit debug information in object code."

Synthesis: the industrial form of "a table mapping every instruction
address back to a source position, generated by the compiler during
emission" is the DWARF line number program — a bytecode-style state
machine emitted alongside the code. Kerf's `debug_info: Vec<Span>` is
the same product in dense form: `p.debug_info.push(span)` on every
emit (§19.3 "every emit automatically writes debug_info_table"),
`span_of(func, pc)` resolving through it (the §12.1 face), and the
kerf-vm resolving raise-time spans through the table. The parallel-
table invariant is *checked* (verify "debug_info parallel to code"),
which is what makes the table a sound parity product for this Pass.

### Topic 5 — Deduplicated location tables: rows hold until the location changes (q5 weak → q5b strong)

* https://github.com/golang/go/blob/master/src/debug/dwarf/line.go —
  primary (a production consumer): "// A LineEntry is a row in a
  DWARF line table. type LineEntry struct { // Address is the
  program-counter value of a machine [instruction]" — rows are
  (address, location) pairs, one per location *change*, not one per
  instruction.
* https://dwarfstd.org/doc/DWARF4.pdf — the spec mechanism: the line
  number program only appends a row when the state machine's location
  registers change; a row holds for the whole address range until the
  next (cf. 6.2.3 categories hit above).
* https://discourse.llvm.org/t/rfc-debuginfo-dwarf-debug-line-entry-for-a-callsite-of-an-inlined-function/62984 —
  the granularity trade stated from the consumer side: "With the
  current line number tables, single-stepping or moving from one
  breakpoint to the next requires that each logical statement…".
* (q5's retained adjacent hits, honest scope) https://discourse.llvm.org/t/rfc-deduplication-of-debug-information-in-linkers-lld/47033
  and https://gcc.gnu.org/wiki/DebugFission — linker/debug-section
  dedup ("discard a good fraction of the duplicate type information
  and strings in the debug information") — related but a different
  (coarser) dedup than per-instruction location tables.

Synthesis: the classic per-instruction source-position table is
stored *deduplicated* — DWARF emits a row only when the source
location changes, so consecutive instructions of one expression
share a row; the kerf choice is the opposite, dense form (one span
per instruction, strict parallelism), which is the differential-
friendly encoding: the parity check compares span-for-span with no
range-reconstruction logic, and the shared-span redundancy of the
dense form is exactly what the DWARF run-length form would elide.
Honest re-grounding of the task premise: in compile.rs the
*deduplicated* table is the constant pool (Lua `addk` slot-identity);
`debug_info` is dense by design — the DWARF row-holding discipline is
the prior art for what a compressed variant of it would be.

### Topic 6 — Instruction-stream-level equivalence checking (q6, strong; extends the r82 K196 school)

* https://dl.acm.org/doi/pdf/10.1145/349299.349314 — primary: Necula,
  "Translation validation for an optimizing compiler" (PLDI'00): "We
  describe a translation validation infrastructure for the GNU C
  compiler. During the compilation the infrastructure compares the
  intermediate form of the [program]" — equivalence decided on the
  actual emitted intermediate/instruction forms, during compilation.
* https://www.diva-portal.org/smash/get/diva2:1987997/FULLTEXT01.pdf —
  "Translation Validation for the HotSpot C2 Just-in-Time Compiler":
  "applying translation validation to the HotSpot C2 compiler by
  designing, implementing, and evaluating a verification tool" —
  validation of emitted machine code from a JIT.
* https://daejunpark.github.io/papers/asplos21.pdf — "Language-
  Parametric Compiler Validation with Application to [x86]": "the
  application of the proposed equivalence checking algorithm in a
  translation validation system for the Instruction [Set]"
  — instruction-set-level equivalence as the validated product.
* https://cs.nyu.edu/media/publications/fang_yi.pdf — NYU thesis on
  translation validation of optimizing compilers (the school's
  monograph form).

Synthesis: r82's K196 anchored the discipline (validate each run/
pass a-posteriori, not by pre-proof); this Pass extends the parity
skeleton from analysis products to the **emitted instruction stream**
— and the literature has exactly that instance: Necula's GCC
infrastructure compares the actual intermediate forms produced during
compilation, and the HotSpot C2 work validates emitted code from a
 JIT. The second Pass's parity product (opcode sequences, patched
jump targets, per-jump depth profile, debug_info spans — oracle vs
`.krf`, both engines agreeing) is the differential, non-proof
instance of the same shape, with the patch-time depth assertion as an
additional in-stream well-formedness witness the classic tools get
from symbolic simulation.

## Anchor extraction (proposed K198-K203; K197 was the previous high, r82)

- **K198 — Lua lcode.c patchlist discipline: pending jumps are threaded through the jump instructions' own operand slots, spliced by `luaK_concat` and rewritten by `luaK_patchlist` when the target is known.**
  Source: https://www.lua.org/source/5.4/lcode.c.html (supporting:
  lparser.h "patch list of 'exit when true'/'exit when false'";
  lparser.c `luaK_concat`/`luaK_patchtohere` usage; Lua 5.3
  `getjump`).
  Backing: the compile.rs `emit_jump`/`patch` pair is the named
  adaptation — placeholder sentinel in `a`, source depth riding in
  `b`, both restored by `patch`; the CP segment makes the in-stream
  bookkeeping a named, differentially checkable emission surface.

- **K199 — Forward references: the classic two resolutions are the second-sweep pass (assembler pass 2, MIX) and the one-pass patch list; both end with a no-unresolved-references drain check.**
  Source: https://simplifycpp.org/articles/a0748/architecture-of-an-assembler-symbol-resolution-and-backpatching
  (supporting: users.cis.fiu.edu forward-reference notes; esolangs
  MIX/Knuth "Two pass assembly, so that future references are
  possible"; GeeksforGeeks backpatching).
  Backing: kerf's direct-style single-pass emitter is the patch-list
  branch; `finish`'s `UnpatchedJump` scan (first placeholder in code
  order as the deterministic witness) is the drain check.

- **K200 — JVM max_stack (JVMS §4.7.3): the compiler computes the operand-stack depth profile instruction-by-instruction and records it in the product; the verifier re-derives it independently.**
  Source: https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html
  (supporting: Wikipedia JVM bytecode "computed by the compiler";
  StackOverflow depth-computation question; tmdevlab StackMapTable
  verifier note).
  Backing: `emit`'s pops/pushes depth bookkeeping with fail-closed
  underflow is the same per-instruction computation; `patch`'s depth
  assertion is the merge-point check; `Bytecode::verify` is the
  second defense layer — the documented two-layer split.

- **K201 — DWARF line number program: the compiler emits a per-instruction source-position mapping alongside the code (a state-machine-encoded table).**
  Source: https://dwarfstd.org/doc/DWARF4.pdf (supporting:
  simplifycpp "opcodes describing instruction addresses and their
  associated file/line pairs"; swatinem.de deep dive; GHC debug-info
  emission docs).
  Backing: kerf's `debug_info` (span pushed on every emit, `span_of`
  resolution, raise-time lookup) is the dense form of the same
  product; the parallelism invariant is what qualifies it as a parity
  product for the second Pass.

- **K202 — DWARF line tables are the deduplicated form of a per-instruction location table: a row is emitted only when the source location changes and holds across the address range.**
  Source: https://github.com/golang/go/blob/master/src/debug/dwarf/line.go
  (supporting: dwarfstd DWARF4 line-number-program spec; LLVM
  discourse line-table granularity RFC).
  Backing: the design axis for kerf's `debug_info` encoding — dense
  one-span-per-instruction (chosen: total span-for-span differential,
  no range reconstruction) vs row-holding dedup (DWARF: smaller,
  consumer-side reconstruction); the constant pool is where kerf
  already applies the dedup discipline (`addk` slot-identity).

- **K203 — Instruction-stream-level translation validation: equivalence is decided on the actual emitted intermediate/instruction forms during compilation (Necula's GCC PLDI'00; HotSpot C2 emitted-code validation).**
  Source: https://dl.acm.org/doi/pdf/10.1145/349299.349314
  (supporting: diva-portal HotSpot C2 thesis; ASPLOS'21
  language-parametric validation; NYU thesis).
  Backing: extends r82's K196 from analysis products to the emitted
  instruction stream — the second Pass's parity product (code, jump
  targets, depth profile, debug_info) compared oracle-vs-`.krf` per
  Pass, with the patch-time depth assertion as an in-stream witness.

Weak-topic downgrade notes (honest disclosure, the r75/r82
discipline): q1's phrasing surfaced only 3 results (all lua.org
primary) and missed `lcode.c`, the file where `luaK_patchlist`
actually lives — downgraded to partial/thin, completed by the q1b
variant retry (the engine flagged "Missing: luaK_patchtojump NoJump"
on the top hit, an honest coverage signal); q5's phrasing ("debug
location table deduplication identical adjacent instructions")
drowned in linker-level debug-section dedup literature (LLD RFC,
DebugFission, CodeView LF_FUNC_ID) — downgraded, recovered by the q5b
variant which found the actual mechanism (DWARF row-holding). One
premise correction, honestly logged: the compile.rs module doc's
"deduplicated" adjective attaches to the constant pool, not to
`debug_info` (dense one-span-per-instruction by design — parallelism
is the verified §19.3 invariant 3); the README states the code facts
as read, no anchor evidence was fabricated to fit the premise.

Archive complete — 8 queries, 6 strong, 2 weak/downgraded.

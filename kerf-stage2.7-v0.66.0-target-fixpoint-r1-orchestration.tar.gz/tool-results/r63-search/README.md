# r63-search — 模块系统域检索存档（第六十三轮 · §9.64）

> 依据：docs/stage0.md §9.64.2。检索主题：模块系统语义（声明容器/身份/加载次序/重复定义/重定义）、平铺命名空间 vs 层级路径、库-程序两分。弱查披露第十轮：q1 垃圾（scribd 无关——OSRS 手套文档）、q2 上游 429 限流（无文件——r62 q4 同形如实登记）、q3 弱（OCaml 论坛贴——cambium「Overriding submodules」线索非正典）、q4 上游 429（无文件）、q5 垃圾（git 镜像索引）、q6 弱（Racket Guide 下载页 + debian 归档）——全部由主源直读补位（K102-K106）。
>
> 主源路径失效记录（如实登记）：m1/m1b（doc.rust-lang.org/reference/modules.html）404 ×2——页面改版（Rust Reference 模块章现名「Crates and source files」，m1c 承载）；m2（reference/Module_Syntax.html）404——参考版路径变更，Guide 子页 m2b/c/d 承载；m3/m3b（ocaml.org/manual/modules.html）503 ×4（page_reader 双径 + curl 双径含 v2.ocaml.org）——**OCaml 面不设锚如实降档**（K106 rustc E0428 已覆盖文件面重复定义正典）；m4/m4b（MIT Scheme ref Definitions/Top-Level-Definitions）404/000 双径不可达——降档，Scheme 侧由 m4c（Chez csug 9.5「Libraries and Top-level Programs」）承载（Chez = kerf 设计宪章具名先例）。

## 检索文件（q1-q6，q2/q4 无文件）

| 文件 | 查询 | 结果定性 |
|---|---|---|
| q1-racket-duplicate.json | Racket module body duplicate identifier definition error compile | 垃圾（scribd OSRS 无关文档）；Racket 重复定义面由 m2d 主源直读承载 |
| （q2 未落盘） | rustc E0428 duplicate definitions module item error | **上游 429 限流**（serper 400/429——r62 q4 同形如实登记）；K106 由 m5 主源直读承载 |
| q3-ocaml-module.json | OCaml module Multiple definition error structure signature | 弱（discuss.ocaml.org / cambium.inria.fr 论坛贴——非正典；OCaml 面降档不设锚） |
| （q4 未落盘） | R7RS Scheme top-level definition redefinition permitted semantics | **上游 429 限流**（无文件）；Scheme 重定义面由 m2d（Racket 受限重声明）+ m4c（Chez 库/程序两分）组合承载 |
| q5-instantiation-order.json | module instantiation order dependencies first linker loading compiler | 垃圾（googlesource git 镜像 + cygwin/llvm 邮件）；实例化次序面由域内代码事实（DFS 后序）+ K105（Chez import 双目的）承载 |
| q6-module-identity.json | Racket module path require string symbol namespace registry | 弱（Racket Guide 下载页 + debian 归档）；身份面由 m2c 主源直读承载 |

## 主源直读（m1c / m2b / m2c / m2d / m4c / m5；失效件 m1/m1b/m2/m3/m3b/m4/m4b 计入）

| 文件 | 源 | 锚 |
|---|---|---|
| m1c-rust-ref-crates.json | The Rust Reference「Crates and source files」（curl 直读 38.7KB——modules.html 404 后的现名章节） | **K102**——「any item within a crate has a canonical module path denoting its location within the crate's module tree. The Rust compiler is always invoked with a single source file as input……The processing of that source file may result in other source files being loaded as modules」——**模块 = 声明容器 + canonical 路径 + 按需文件映射三合一**；层级模块树形态 |
| m2b-racket-guide-modules.json | Racket Guide「6 Modules」（目录层 1.5KB——子页索引价值） | 索引件（6.1-6.8 八节链接表） |
| m2c-racket-module-syntax-guide.json | Racket Guide「6.2 Module Syntax」（85.2KB） | **K103**——「The longhand form of a module declaration, which works in a REPL as well as a file, is `(module name-id initial-module-path decl ...)` where the name-id is a name for the module……**name-id is ignored when the module is required through its file's path**. The initial-module-path is needed because even the require form must be imported for further use in the module body」——**模块名 = 局部装饰、路径 = 身份，两分正典**；初始导入引导体内语法 |
| m2d-racket-redefinition.json | Racket Guide「6.6 Assignment and Redefinition」（30.1KB） | **K104**——「when a module contains no set! of a particular identifier……the identifier is considered a constant that cannot be changed—**not even by re-declaring the module**. Consequently, **re-declaration of a module is not generally allowed**」+ REPL 受限重声明实录（`define-values: assignment disallowed; cannot re-define a constant constant: pie in module:'m`）+ `compile-enforce-module-constants` 反射参数——**Racket 双面模型：模块体常量性（无 set! 即常量）+ REPL 重声明仅在重定义先前常量绑定时拒绝** |
| m4c-chez-libraries.json | Chez Scheme Users Guide 9.5「Libraries and Top-level Programs」（curl 直读 57.2KB） | **K105**——「A top-level program is a stand-alone program with a declared set of imported libraries and a body that is run when the top-level program is run. The bindings in a library are created and its initialization code run **only if the library is used, directly or indirectly**, by a top-level program. The import declarations……serve two purposes: first, they cause the imported libraries to be loaded, and second, they cause the bindings of the imported libraries to become visible in the importing library or top-level program」——**库/程序两分 + import = 加载与可见性双目的 + 惰性绑定创建** |
| m5-rust-e0428.json | rustc Error Codes Index「E0428」（92.2KB） | **K106**——「A type or module has been defined more than once……`error: duplicate definition of value `Bar``……Please verify you didn't misspell the type/module's name or remove/rename the duplicated one」——**文件面重复定义 = 编译错误正典措辞** |

## 锚总账

K102（Rust Reference 模块树 + canonical 路径 + 按需源文件加载）· K103（Racket 模块名局部装饰/路径身份两分 + 初始导入引导）· K104（Racket 模块体常量性 + 重声明通常不允许 + REPL 受限重声明 + 反射开关）· K105（Chez 库/程序两分 + import 双目的 + 惰性绑定）· K106（rustc E0428 重复定义文件面正典）——五主源锚（OCaml/MIT-Scheme 双面降档如实登记）。存档 18 文件（磁盘核验：四检索落盘 q1/q3/q5/q6 + 失效 q2/q4 无文件×2 + 主源十三件[7 失效件 m1/m1b/m2/m3/m3b/m4/m4b 计内 + 6 成功件 m1c/m2b 索引/m2c/m2d/m4c/m5] + README——首版误记 16，当轮顺修）。

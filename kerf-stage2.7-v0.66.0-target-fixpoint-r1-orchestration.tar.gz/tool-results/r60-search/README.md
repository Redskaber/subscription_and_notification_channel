# r60-search — Performance Engineering & Benchmark Methodology Domain (§9.61)

Round 60 (Task 38-c) retrieval archive for the §9.61 front-edge review.
Quality disclosure per §12 (no padding — weak queries named, dead probes removed).

## Query set (q1-q6, z-ai web_search)

| file | query | verdict |
|---|---|---|
| q1-rustc-perf.json | rustc-perf compile-time regression tracking benchmark methodology | PARTIAL — one usable hit (internals thread, dead on direct fetch: 404) |
| q2-criterion-methodology.json | criterion.rs benchmark methodology warmup sampling outlier classification | GARBAGE — academic-paper noise, zero relevant hits |
| q3-blackbox.json | std hint black_box Rust optimizer fence semantics | GARBAGE — zero relevant hits |
| q4-iai.json | iai-callgrind instruction counting deterministic benchmarking | GARBAGE — zero relevant hits |
| q5-compiler-bench.json | compiler benchmark suite design pitfalls GHC nofib | GARBAGE — zero relevant hits |
| q6-microbench-stats.json | microbenchmark statistics min stdev outlier detection nanobench | GARBAGE — zero relevant hits |

Weak-query disclosure, seventh consecutive round (along the r33/r57 precedent):
q2-q6 produced zero usable hits → main-source direct-read upgrade applied.

## Main-source direct reads (m1-m4)

| file | source | verdict | anchor |
|---|---|---|---|
| m1-rustc-perf-readme.txt | raw.githubusercontent.com/rust-lang/rustc-perf/master/collector/README.md | STRONG | K88 — canonical compiler perf collection system: dedicated harness, compile/runtime benchmark split, regression tracking |
| m2-criterion-docs-rs.txt | docs.rs/criterion/latest/criterion/ | STRONG | K89 — "statistics-driven micro-benchmarking library... strong statistical confidence in detecting and estimating the size of performance improvements and regressions, while also being easy to use" |
| m3-blackbox-doc.txt | doc.rust-lang.org/std/hint/fn.black_box.html | STRONG | K90 — black_box semantics: "maximally pessimistic" identity hint; "best-effort" basis; "must not be relied upon to control critical program behavior" |
| m4-iai-readme.txt | raw.githubusercontent.com/iai-callgrind/iai-callgrind/main/README.md | STRONG | K91 — one-shot consistent benchmarking via instruction counting ("High-precision, one-shot and consistent benchmarking framework") |

Dead probes removed (r59 precedent): internals.rust-lang.org thread (404 on direct
fetch — search index stale), bheisler.github.io criterion book (all paths 404 —
site unreachable this round), nanobench README master/main (404 both branches).
The criterion *methodology* details (warmup/iteration/sampling/outlier
classification) are therefore anchored via K89's crate-level claims plus
training-free reasoning only where the code itself is the evidence — no
methodology claim below rests on an unreachable source.

## Consumption

Anchors are cited as K88-K91 in docs/stage0.md §9.61. This README is the
retrieval-honesty record for the round (weak-query family, 7th round).

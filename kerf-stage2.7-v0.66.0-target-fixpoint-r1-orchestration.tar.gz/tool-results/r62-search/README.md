# r62-search — 资源限额与预算治理域检索存档（第六十二轮 · §9.63）

> 依据：docs/stage0.md §9.63.2。检索主题：编译器资源限额（深度/预算/终止性）、工业界限额形态（可调性/燃料/协作让步）、宏展开广度炸弹。
> 弱查披露第九轮：q1/q2/q3 弱或垃圾（rustc 限额 / 编译炸弹 / GCC 模板深度——泛搜命中均为无关仓库索引）、q5/q6 垃圾（Chez 堆 / Racket expand——完全无关结果）、q4 限流 429（wasmtime fuel——上游 400/429 如实登记）——全由主源直读补位（K98-K101）。m4（Racket expand 页）404，由 m4b（syntax-model 章）承载。

## 检索文件（q1-q6，q4 无文件）

| 文件 | 查询 | 结果定性 |
|---|---|---|
| q1-rustc-limits.json | rustc recursion_limit attribute default 128 type_length_limit compiler | 弱（单一无关命中——Fuchsia rust 镜像）；K98 由 m1 主源直读承载 |
| q2-compiler-bomb.json | compiler bomb exponential template instantiation DoS C++ prevention | 垃圾（flex 镜像索引）；广度炸弹面由 K98/K99/K100 三锚组合承载 |
| q3-gcc-template.json | GCC ftemplate-depth default instantiation depth limit | 弱（clang 发行版邮件线索）；K99 由 m3 主源直读承载 |
| （q4 未落盘） | wasmtime fuel metering epoch interruption | **上游 429 限流**（serper 400/429——如实登记）；K100 由 m2 主源直读承载 |
| q5-chez-heap.json | Chez Scheme heap reserved limit call depth stack overflow protection | 垃圾（Lucene/Racket Guide/杂项——Chez 官方指南未命中）；Chez 面不设锚如实降档 |
| q6-racket-expand.json | Racket macro expansion limit expand depth syntax | 垃圾（无关邮件列表/PDF）；K101 由 m4b 主源直读承载 |

## 主源直读（m1/m2/m3/m4/m4b）

| 文件 | 源 | 锚 |
|---|---|---|
| m1-rust-ref-limits.json | The Rust Reference「Limits」章（attributes/limits.html） | **K98**——`recursion_limit` crate 级属性「maximum depth for potentially infinitely-recursive compile-time operations like macro expansion or auto-dereference」+ **默认 128** + 用户可调（`#![recursion_limit = "4"]` 例）+ `type_length_limit`（单态化替换数上限——nightly 执行旗标）。**限额 = 深度 + crate 级可调**的 rustc 形态 |
| m2-wasmtime-config.json | docs.rs/wasmtime 49.0.1 Config | **K100**——`consume_fuel`：「deterministically prevent infinitely-executing WebAssembly code by instrumenting generated code to consume fuel as it executes. When fuel runs out a trap is raised」+ `epoch_interruption`：「cooperative timeslicing……fuel instrumentation is somewhat expensive: it modifies the compiled form of the Wasm code」——**fuel（确定性 + 仪表化成本）vs epoch（廉价 + 协作让步非确定边界）二分**；kerf 预算 = 分配粒度自然计费（零仪表化成本 + 确定性），第三形态 |
| m3-gcc-cpp-dialect.json | GCC 手册「C++ Dialect Options」 | **K99**——`-ftemplate-depth=n`「maximum instantiation depth for template classes……A limit……is needed to detect endless recursions during template instantiation. ANSI/ISO C++ conforming programs must not rely on a maximum depth greater than 17 (changed to 1024 in C++11). **The default value is 900**」+ `-ftemplate-backtrace-limit`（诊断侧限额族默认 10）——**深度-only + 旗标可调 + 标准层依赖注记**的 GCC 形态 |
| m4-racket-expand.json | docs.racket-lang.org/reference/expand.html | **404**——如实登记（Racket 参考改版路径变更） |
| m4b-racket-syntax-model.json | Racket Reference §1.2「Syntax Model」 | **K101**——「an expand pass that processes a syntax object to produce one that is fully parsed. The expand pass recursively processes a syntax object」——**递归展开、本页无数值深度上限公开**（宿主栈承载）；kerf 显式 512 深度帽 = 比生产级 Racket 更防御的形态（如实登记：Racket 别处或有内部护栏，本页无据不虚构） |

## 锚总账

K98（rustc recursion_limit 默认 128 可调 + type_length_limit）· K99（GCC -ftemplate-depth 默认 900 + backtrace-limit 家族）· K100（wasmtime fuel/epoch 二分——kerf 分配粒度预算为第三形态）· K101（Racket expand 递归无数值上限公开）——四主源锚 + 弱查披露第九轮（q4 限流 429 如实登记）。存档 11 文件（五检索 json + 五主源[m1/m2/m3/m4/m4b] + README；m4 404 件计内，q4 无文件——首版误记十/四主源，当轮顺修）。

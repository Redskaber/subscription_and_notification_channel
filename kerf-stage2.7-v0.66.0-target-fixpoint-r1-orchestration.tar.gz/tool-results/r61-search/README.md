# r61-search — 用户交互表面域检索存档（第六十一轮 · §9.62）

> 依据：docs/stage0.md §9.62.2。检索主题：REPL 语义（不完备输入/错误恢复）、CLI 退出码与参数惯例、诊断渲染（宽度/颜色/发射器家族）。
> 文件构成：q1-q6 六检索 json + m1/m2/m3/m3b/m3b-chez/m3c/m4/m5 八主源文本 + README = **15 文件**（首版文档误记十四、漏计 m3 薄抓取件——编排轮计数统一顺修沿 a5438b1 先例）。
> 弱查披露第八轮：q2/q4/q5/q6 四查垃圾如实降档——全由主源直读补位（K92-K97）；q1/q3 部分有效（rustc_errors 依赖面 + gcc 手册 / MIT Scheme 引用线索）；q6 退出码对照改由 K97（clap exit_code 官方文档）承载 = 弱查主题的锚转移首例。m4（clap 根页）薄抓取由 m5 补强。

## 检索文件（q1-q6）

| 文件 | 查询 | 结果定性 |
|---|---|---|
| q1-rustc-emitter.json | rustc diagnostic emitter source snippet caret underline unicode width rendering | 部分有效——docs.rs rustc_errors（unicode-width 依赖直接证据 = K93 面）+ mankiler gcc 手册（caret 缺省形态 = K96）；internals 线程死链如实披露 |
| q2-miette.json | miette ariadne Rust diagnostic rendering unicode-width caret alignment | 垃圾（镜像站索引）——K92 由 m2 主源直读承载 |
| q3-repl-continuation.json | REPL multi-line input continuation prompt unterminated string unclosed paren Scheme Lisp | 部分有效——MIT Scheme Reference Manual 线索（read primitive / datum 完整性）；正文由 m3b/m3c 直读承载 |
| q4-cli-exit.json | clap Rust CLI exit code 2 usage error convention POSIX | 垃圾（无关结果）——K97 由 m5 主源直读承载 |
| q5-repl-recovery.json | REPL error recovery semantics session rollback GHCi Chez Scheme undefined variable | 垃圾（完全无关）——K94 由 m3c 主源直读承载 |
| q6-rustc-exit.json | rustc exit status codes error fatal | 垃圾（完全无关）——退出码对照改由 K97（clap exit_code）+ kerf 自身 21 个 CLI 测试的内部权威承载；锚转移如实登记 |

## 主源直读（m1-m5 + 重试一件）

| 文件 | 源 | 锚 |
|---|---|---|
| m1-rustc-diagnostics.json | rustc-dev-guide「Errors and lints」章（diagnostics.html） | K93——rustc_errors 双发射器（human + JSON，JSON 含 rendered 字段）+ SourceMap::span_to_snippet（kerf session.source 同构） |
| m2-miette.json | docs.rs/miette 7.6.0 | K92——fancy 图形层 = feature 门控可选项（unicode-width/terminal_size/textwrap/supports-color 全 optional）+ MietteHandlerOpts 配置面（.unicode(false)/.context_lines(3)/.tab_width(4)/.break_words(true)）——「花式特性 = 可选叠加层，核心先行」形态学证据 |
| m3b-mit-scheme-ch3.json | MIT Scheme User's Manual ch.3「Running Scheme」 | K95——命令行选项面（-eval 取值到下一连字符 / -suspend-file 世界镜像 / identify-world 版本横幅 = REPL greeting 同族物）+ 单连字符 = 选项前缀惯例 |
| m3-mit-scheme-repl.json | MIT Scheme User's Manual ch.1「Introduction」 | 薄抓取（章节定位页 2.7KB——ch.1 非 REPL 章）；检索章节索引后改抓 ch.3/ch.4（m3b/m3c）承载正文 |
| m3b-chez-repl.json | cisco.github.io/ChezSchemeUserGuide/repl.html | 404（GitHub Pages）——如实披露；Chez 侧改由 MIT Scheme 双章承载 |
| m3c-mit-scheme-ch4.json | MIT Scheme User's Manual ch.4「Using Scheme」 | K94——嵌套 error REPL（level-N：「a new REPL has been started… The original REPL still exists, and is waiting for you to return to it」）+ restart 菜单协议（RESTART 1/2/3）+ 「;Unbound variable: foo」消息形态 |
| m4-clap.json | docs.rs/clap 4.6.7（根页） | 薄抓取（特性旗标清单为主）——由 m5 补强 |
| m5-clap-error.json | docs.rs/clap 4.6.7 Error 页 | K97——`pub fn exit_code(&self) -> i32 — When the error's kind would print to stderr this returns 2, else it returns 0`——usage 错误 = stderr + 退出码 2，与 kerf 0/1/2 契约精确同构 |

## 锚总账

K92（miette fancy 门控）· K93（rustc_errors unicode-width + 双发射器）· K94（MIT Scheme 嵌套 error REPL + restart 协议）· K95（MIT Scheme CLI 选项惯例）· K96（gcc caret 缺省形态）· K97（clap exit_code 契约）——六主源锚 + 四弱查披露第八轮。存档 15 文件。

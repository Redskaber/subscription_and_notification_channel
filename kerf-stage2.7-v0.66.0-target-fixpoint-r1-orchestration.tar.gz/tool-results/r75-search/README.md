# r75-search — gate-B oracle encoding domain (dump/rebuild dual encoders + rebuild decoders)

Round 75 / Task 53-b knowledge search. Domain: the parity harness's
record-encoding face — `dump_oracle_*` (Rust ADT side) vs
`dump_krf_*` (runtime `Value` side) dual encoders, the `rebuild_*`
decoder family, and `reconstruct_*_error` structured rejections, in
`kerf-driver/src/{reader,expander}_parity.rs`. Two prior rounds
touched this face sideways (§9.74 PAR-1 unified the tag grammar and
the dual-engine driver; §9.75 BST maintained the dual decoders) but
no round has main-reviewed the encoding face itself. Context: the
fresh-sandbox baseline (53-a) came back fully green — six commands
0/0/0, 1232:0:0, audit 200/200, B-series all in-band on the new
toolchain (rustc 1.98.1) with B4 counters bit-identical (1 cycle /
1023 swept), so registered-window signals stayed at zero and the
cross-cutting candidate list drove domain selection here.

## Query ledger (honest disclosure — the r72/r73/r74 weak-query discipline)

| id | query | verdict |
|----|-------|---------|
| q1 | rustc -Zunpretty pretty-printer AST rust compiler source | weak (mirror farms + unrelated noise; no primary rustc doc) |
| q2 | GHC Outputable typeclass pretty printing compiler AST | **429** (upstream 42900) |
| q2b | GHC compiler Outputable pretty printer | **429** (upstream 42900, retry) |
| q3 | serde deserializer malformed input field count error handling | weak (unrelated repos/lists) |
| q4 | proptest roundtrip serialization property test strategy | **strong** (ivanyu.me proptest guide + Rust Project Primer property-testing chapter + a serializer round-trip proptest issue) |
| q5 | rust catch_unwind robustness decoder panic to result | weak (noise) |

Two 429s + three weak + one strong: the query channel stays
degraded (the r74 pattern). Anchor load shifts to direct
primary-source reads below, per the r72 precedent. All query JSON
evidence is retained on disk; nothing is fabricated.

## Main-source direct reads (the anchor load)

| id | source | bytes | role |
|----|--------|-------|------|
| m1 | rust-lang/rust `compiler/rustc_ast_pretty/src/pp.rs` @ master (raw) — the Mesa/Oppen pretty-printer engine that every rustc AST printer (`-Zunpretty=ast/normal/expanded…`) rides | 21,587 | **K169** — the single-printer-framework discipline: rustc never maintains two independent encoders of one grammar; every pretty-print path goes through one `pp` engine + per-type `pprust` impls. kerf mapping: the oracle dump side is the pprust analogue (one `dump_oracle_*` family over the ADT, exhaustiveness-enforced by the compiler); the krf side is a *decoder of produced runtime values*, not a second printer of the same ADT — the two sides cannot be type-unified, so the alignment contract must be pinned by guards (SER-3), not by construction. |
| m2 | ghc/ghc `compiler/GHC/Utils/Outputable.hs` @ master (raw) — `class Outputable a where ppr :: a -> SDoc` (line 944) | 77,626 | **K170** — one-instance-per-type discipline (orphan-instance control), plus the deliberate *non*-instance note ("There's no Outputable for Char") showing coverage is a curated, documented set. kerf mapping: the accepted-kind sets of `dump_krf_expr` (9 kinds) / `dump_krf_item` (4) / `dump_krf_litval` (6) mirror the ADT variant sets; a guard should pin the mirror (accepted-kind set == ADT kind-name set) so a Stage 2 ADT change cannot leave the krf side silently behind. |
| m3 | python/cpython `Lib/reprlib.py` @ main (raw) — budgeted total repr (`maxlevel=6`, `recursive_repr`) | 8,064 | **K171** — the budgeted-totality discipline: repr over arbitrary structures stays total by declaring size/depth budgets. kerf mapping: the host-side dump walks are bounded by the engine budgets upstream (no cycle-creating primitive in the frozen subset ⇒ finite trees; BST-3 measured and guarded the envelope in r74) — the depth face is maintained, not re-opened. |
| m4 | serde-rs/serde `serde/src/de/mod.rs` @ v1.0.219 (raw) — the `Error` trait's `invalid_length(len, exp)` | 81,911 | **K172** — the canonical structured arity-mismatch error: `invalid length {len}, expected {exp}`, never a panic, on every deserializer path. kerf mapping (the round's main implementation anchor): SER-1's per-arm arity guards adopt this shape — kind + actual count + needed count in a structured `Err`, replacing the reachable index/slice panics enumerated in F1-F5. The codebase's existing messages ("item record has {} fields, need at least kind/start/end/payload") are the same family; the fix generalizes them to every arm. |
| m5 | wasmtime differential-testing source — **reused from r73-search** (`m5-wasmtime-differential.rs`, no re-fetch; the r74 K167 precedent) | — | **K167 (reuse)** — the differential-oracle discipline: the harness classifies failures and must itself never be the crasher. The r74 doc line "Both classes are reported as drift, never a panic" is the same contract the totality guards (SER-2) now pin at the record-decode face. |
| q4 | proptest round-trip property-testing guides (strong query; JSON on disk) | — | **K173** — round-trip property (`decode(encode(x)) == x`) as the systematic alignment test. kerf mapping: the corpus sweep (BST-4, full-corpus gate B) already carries the behavioral face today; a generative round-trip property over random `CoreExpr` is registered as W-ORACLE-ROUNDTRIP (zero signal now — Stage 2 corpus scale-up or an LA-1 ADT change is the trigger). |

## Verdict table feeding §9.76

* **F1** dump-side implicit arity (`dump_krf_expr` seven arms; apply/perform slice `[4..len-1]` panics at len 4; if/fn/assign/let/handle index past len) — **implement** (SER-1, K172).
* **F2** `dump_krf_litval` pair arm `elems[2]` at len 2 — **implement** (SER-1).
* **F3** rebuild side: `rebuild_expr` if arm `elems[5]` at len 5; `rebuild_lit` pair arm `elems[2]` — **implement** (SER-1).
* **F4** `reconstruct_expand_error` twelve arms at len 3; reader `reconstruct_error` nesting arm `elems[3]` — **implement** (SER-1).
* **F5** reader `dump_krf_node` six leaf arms `elems[3]` at len 3 — **implement** (SER-1).
* **F6** float Debug-text single-source (harness emits `{v:?}` itself; krf rides verbatim; reader re-parses and re-renders `{v:?}`) — **maintain** (K169 family).
* **F7** helper family (`value_elems`/`as_str`/`as_i64`/`parse_span`/`decode_tagged`) already fail-closed; unknown-kind arms already `Err` — **maintain**.
* **F8** dual-encoder kind-set alignment has no structural guard (compiler enforces the oracle side via total match; the krf side is data-driven with no pin) — **implement** the kind-set + format guard (SER-3, K170).

Weighing (technology vs defect, per the standing instruction): a
grammar-manifest table (one const kind→arity map both encoders
consult) would centralize the grammar but adds a new single-source
carrier plus a sync obligation on every ADT change — rejected as
over-specialization for the current corpus scale (§2.2 smaller
number first; §12). Guard tests pin behavior with zero new carriers.
The round-trip proptest (K173) is the same call at zero signal today
— registered as a window, not implemented (zero-signal ⇒ no window
opening, the standing §9.29 discipline).

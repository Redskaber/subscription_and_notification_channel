# r73-search — Parity machine domain (Task 51-b)

Queries (q1-q7 + q7b retry; q7 hit a 429 like r71 q2 / r72 q4·q4b — retried once
with rephrased keywords):

- q1 rustc compiletest expected errors matching — weak (mirrors + mailing lists)
- q2 differential testing compiler interpreter oracle — garbage (zero relevance)
- q3 GCC DejaGnu dg-error multiple expected errors — weak-mid (gcc.gnu.org
  result pages + GCC Internals fragments + a gtest discussion)
- q4 wasmtime differential fuzzing — weak-mid (academic + engine mentions,
  no direct mechanism content)
- q5 Rust test harness generic driver dedup — garbage (search engine derailed
  completely: tools/cars/apps)
- q6 V8 test262 expectation semantics — weak (git mirrors + springer)
- q7 (429, not retried as q7) / q7b property-based shrinking — mid
  (alperenkeles experience report, jetCheck README, moonbitlang QuickCheck)

Weak-query round 20 (r69-r72 lineage): anchoring carried by primary-source
direct reads, as before.

Primary sources (disk-verified):

| id | file | bytes | verdict |
|----|------|-------|---------|
| m1 | m1-compiletest-common.rs (rustc src/tools/compiletest) | 51,195 | weak-mid (mode taxonomy/config face) |
| m2 | m2-compiletest-runtest.rs (rustc check_expected_errors) | 127,448 | **strong** (expected-error matching authority) |
| m3 | m3-gcc-sourcebuild.texi (gcc-mirror DejaGnu directives) | 158,656 | **strong** (dg-error/-warning/-message one-directive-one-message) |
| m4 | m4-v8-testsuite.py (v8 tools/testrunner local) | 10,030 | weak-mid (loader/combiner framework; verdict semantics live elsewhere) |
| m5 | m5-wasmtime-differential.rs (bytecodealliance fuzz target) | 11,656 | **strong** (multi-engine differential authority) |
| m6 | m6-proptest-shrink.html (proptest book) | 13,755 | weak (navigation shell only — body not carried; honest downgrade, r72 fuchsia-404 lineage) |
| m7 | m7-ui-readme.md (rustc tests/ui/README.md) | 63,395 | weak-mid (directory taxonomy, not matching semantics) |

Anchors minted (K157-K163) — see stage0.md §9.74.2:

- K157 (m3): dg-error L1250 = one directive per message — "If there is no
  message for that line or if the text of that message is not matched by
  regexp then the check fails". Multiset one-for-one consumption canon.
- K158 (m2): check_expected_errors L660-775 — `found: vec![false; n]` with the
  `!found[index]` guard (one actual error consumes one expectation), predicate
  = line_num + kind + msg.contains, **two-sided failure face** (unexpected +
  not_found), require_annotation / dont_require_annotations severity-tiered
  exemptions, error-pattern × structured-annotation mutual exclusion (fatal
  "use //~ ERROR instead"). The industrial authority for expected-error
  matching.
- K159 (m5): differential fuzz with a **configurable engine pair** —
  allowed_engines = [wasmtime, wasmi, spec, v8, winch, pulley], ALLOWED_*
  env whitelists, config.set_differential_config(), LHS/RHS build. kerf's
  fixed VM/Eval pair is a language-definition face (BS-C) — difference
  registered honestly, not a defect.
- K160 (m4): TestCombiner + VariantsGenerator — the corpus × engine × config
  combinatorics frame (weak-mid).
- K161 (q7b family): shrinking = automatic failure minimization; kerf drift
  reports carry full both-side texts with no minimization — W-PAR-SHRINK
  window candidate (zero signal, stays closed).
- K162 (m1): compiletest mode taxonomy (ui/ui-fulldeps/pretty/codegen...) —
  verdict-classification spectrum reference (weak-mid).
- K163 (m7): tests/ui directory taxonomy with per-directory SUMMARY.md —
  corpus organization lineage (§9.45.5 precedent already held).

Notes:

- gcc.gnu.org onlinedocs returned 403 (both DejaGnu-Directives.html and
  Directives.html) — m3 fetched from the gcc-mirror GitHub repository's
  gcc/doc/sourcebuild.texi instead (the authoritative source file itself).
- The v8 test262.py path 404'd (placeholder discarded, not archived — the
  r72 fuchsia-404 lineage); m4 is the testrunner local/testsuite.py.
- compiletest headers.rs 404'd on master (placeholder discarded); runtest.rs
  is the authoritative face and was fetched whole.

# r59-search — §9.60 driver orchestration & error propagation (Task 37-c)

Four-query web search (q1/q2 garbage — disclosed, upgraded to primary
source reads per the r33/r57 precedent; q3 hit the oxc errors canon
entry; q4 partial — incremental-compilation chapter) plus four
primary-source reads:

- q1-rustc-driver.json / q2-parser-recovery.json — garbage results,
  kept as the honesty record (weak-query disclosure #6).
- q3-oxc-pipeline.json — partial: [0] oxc.rs "Dealing with Errors"
  located the canon; three auxiliary sources (users.rust-lang.org,
  langdev.stackexchange.com, kobzol.github.io).
- q4-session-lifecycle.json — partial: rustc-dev-guide incremental
  chapter + query-based compiler discussions (Session lifecycle
  corroboration).
- m1-rustc-driver-full.txt — K84: rustc-dev-guide "rustc_driver and
  rustc_interface" (driver = phase glue; Callbacks trait; interface
  library form).
- m2-rustc-parser.txt — K85: "Lexing and parsing" (ParseSess
  lifetime binding; hand-written lexer; NodeId incrementality
  lesson).
- m3-oxc-errors.md — K86: oxc.rs "Dealing with Errors" canon, full
  text (Dragon Book error-handling mandate; three-valued recovery
  spectrum: fully/partially recoverable vs panicking; Result shape
  evolution; miette reporting separation).
- m4-rustc-diag-structs.txt — K87: "Diagnostic and subdiagnostic
  structs" (#[derive(Diagnostic)] + #[diag] attributes; translation
  face).

Intermediate fetches (404 probes, the pre-llms.txt URL guesses, the
2.3MB print.html working copy) were removed after extraction; the
.txt/.md files above are the retained primary-source evidence.

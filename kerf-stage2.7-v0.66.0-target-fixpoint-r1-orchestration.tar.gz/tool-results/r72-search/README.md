# r72-search — evaluator builtin-dispatch domain (Task 50-b)

Queries (7 + 1 retry): q1 weak (lua.org diff page, not design content) /
q2 weak (Erlang docs fragments + one tangential blog) / q3 weak-medium
(android.googlesource V8 mirror hit + garbage) / q4 + q4b double 429,
not retrieved (same shape as r71 q2/q4 — honest disclosure) / q5
weak-medium (android.googlesource Rust trait-object doc fragment) /
q6 garbage (kernel/device docs, zero relevance) / q7 weak (Java Card
PP + one tangential arxiv fuzzing paper). Weak-search round 19 — the
anchoring is carried entirely by the primary-source direct reads,
following the r69/r71 precedent.

Primary sources (7 files):
- m1-lua-ldo.c        Lua 5.4.6 ldo.c        — K150: precallC passes
  lua_State* to every C function; the call path is one site
- m2-lua-lbaselib.c   Lua 5.4.6 lbaselib.c    — K151: the static
  luaL_Reg base_funcs[] registry + luaL_setfuncs single-source seeding
- m3-cpython-methodobject.h  CPython 3.12     — K152 (a): the
  PyCFunction signature family (VARARGS / FASTCALL / O / NOARGS)
- m7-cpython-methodobject.c  CPython 3.12     — K152 (b) + K156:
  PyCFunction_New selects the vectorcall adapter ONCE by ml_flags with
  a fail-closed `default: bad call flags` arm; cfunction_call is the
  single tp_call fallback
- m4-beam-erl_nif.h   BEAM (OTP 26.2)         — K153: ErlNifFunc
  {name, arity, fptr(env, argc, argv), flags} — the registry row
  carries the arity; every NIF receives the ErlNifEnv host
- m5-rustc-tycx.rs    rustc 1.98.0 middle     — K154: TyCtxt<'tcx> as
  the compiler-wide host (Deref funnel; every query takes the tcx face)
- m6-v8-isolate.h     V8 (main)               — K155: class Isolate
  final — the host lives in the kRootRegister root register

Quality: six query files landed on disk (q4/q4b not retrieved — double
429), seven primary-source files; all fetched fresh this round.

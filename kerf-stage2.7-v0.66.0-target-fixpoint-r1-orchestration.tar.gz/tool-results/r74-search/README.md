# r74-search — bootstrap bridge domain (selfhost three-file family + assembly bridge + parity harness)

Round 74 / Task 52-b knowledge search. Domain: the self-hosted front-end
bootstrap bridge (`selfhost/v1/{reader,expander,macro}.krf` + the
`kerf-driver` assembly/parity harness + fixpoint gate B) — the one
pipeline stage named in the standing instruction never yet main-reviewed
(§9.43-§9.74 lineage covered span/syntax/core/symbol/reader/expander/
compiler/vm/runtime/driver/typecheck; selfhost rode only as parity
fixtures and design notes).

## Query ledger (honest disclosure — the r72/r73 weak-query discipline)

| id | query | verdict |
|----|-------|---------|
| q1 | stage0-posix hex0 hex1 M0 bootstrap chain root of trust | **429** (upstream 42900) |
| q1b | oriansj stage0-posix hex0 minimal trusted bootstrap seed | **429** (upstream 42900, retry) |
| q2 | CPython recursion limit sys.setrecursionlimit json iterative parser | weak (noise: unrelated blogs) |
| q2b | python json.decoder recursion limit deep nesting RecursionError | weak (CISA CVE note + HN noise — adjacent, not primary) |
| q3 | differential testing harness infrastructure failure classification | weak (scribd/jboos noise) |

Two 429s + three weak results: the query channel degraded this round.
Per the r72/r73 precedent (q7 429 → q7b; double-garbage disclosure), the
anchor load shifts to direct primary-source reads below. No fabricated
anchors; the weak-query evidence is retained in the JSON files.

## Main-source direct reads (the anchor load)

| id | source | bytes | role |
|----|--------|-------|------|
| m1 | stage0-posix README.md (oriansj/stage0-posix @ master, raw) | 10,584 | **K164** — the bootstrappable chain discipline: Phase 0 "rebuild hex0 from the hex0 seed … ensure that the hex0 seed is untainted … You should check these are identical!" = the seed-rebuild identity check (gate B axis (b) ground form); "verify each of these programs, from the hex0 monitor up to mes-m2" = per-stage chain verification; monotonic capability growth hex0→hex1→hex2-0→M0→cc_*→M2-Planet→…; trusted root = the hex0 seed. kerf mapping: the Rust reader = the hex0 layer (single source of token truth — the reader.krf header says exactly this); the parity harness = the per-stage verify discipline; gate B self-application = Phase 0 identity. |
| m2 | CPython Modules/_json.c (python/cpython @ main, raw) | 67,400 | **K165** — the classified recursion boundary: every recursive descent in the C scanner is guarded by `_Py_EnterRecursiveCall(" while decoding a JSON object ")` / `" while decoding a JSON array "` (lines ~1131-1143) — a deep-nesting input raises RecursionError **with a domain-specific message naming the operation**, not a generic crash. The boundary is intrinsic (the C scanner recurses natively; grep `stack` = 0 hits) and it is *classified at the failure site*. kerf mapping: the parity harness's engine-budget rejections must be classified distinctly (harness limit vs harness defect vs semantic drift) — the current `drive_dual_engines` Err path conflates them. |
| m2b | CPython Lib/json/decoder.py (python/cpython @ main, raw) | 13,584 | **K168** — the dual-implementation face: the pure-Python scanner (`py_make_scanner` → `JSONObject`/`JSONArray` mutually recursive through `scan_once`) carries the same documented recursion boundary as the C scanner — two implementations of one parser, one boundary, documented. kerf mapping: the VM/eval dual engines + the .krf/oracle parity pair share the harness-envelope boundary; the boundary belongs to the harness contract, not to either engine. |
| m6 | Go src/cmd/dist/build.go (golang/go @ master, raw) | 44,251 | **K166** — the explicit bootstrap-capability constraint: `toolchain1 and go_bootstrap must be built with requiredBootstrapVersion(goModVersion)` (line ~459) and the bootstrapBuildTools go.mod pins "a lower required go version to allow all allowed bootstrap toolchain versions" (lines ~264-269) — the bootstrap chain's *capability envelope* is declared and guarded by the driver (dist refuses an insufficient bootstrap toolchain), not discovered as a late failure. kerf mapping: the assembled `.krf` harness program's input envelope (input size × engine budgets) should be explicitly measured/guarded rather than surfacing as unclassified drift. |
| r73-m5 | wasmtime cratelift diff testing differential.rs (r73-search archive, reused) | 11,656 | **K167** (reused from r73) — the differential-harness precedent: configurable engine pairs with explicit verdict comparison; the harness owns the comparison contract. |

## Defect-vs-technique weighing (the standing instruction's trade-off test)

* **Classified limits (K165/K168)** — technique: classify the harness's
  budget rejections at the failure site. Introduced defect: none — pure
  message/contract clarity on an existing failure path; behavior of the
  engines untouched (the classification reads the `RuntimeError` variant
  already returned). Weigh: adopt.
* **Envelope guard (K166)** — technique: measure and pin the harness's
  input envelope with bracketing guards (a within-envelope wide source
  passes; a beyond-envelope source classifies as harness limit).
  Introduced defect: none — two new tests, no production-path change.
  Weigh: adopt.
* **Iterative rewrites of the .krf walkers (the CPython stdlib move —
  json C scanner's explicit… no: the C scanner recurses; the *iterative*
  move in CPython was elsewhere)** — the frozen subset has no loop
  primitive at all (§9.29 termination argument: no loop forms + LIVE
  billing ⇒ every non-terminating program is caught). Per-element
  self-recursion is *the only* iteration shape the subset can express;
  making the walkers "iterative" is impossible without a new primitive
  (constitutional exclusion: zero new primitives). Weigh: reject — the
  honest-boundary treatment (classification + guard) is the correct
  instrument.
* **Raising EVAL_DEPTH_LIMIT (2048) or the VM budget for harness runs**
  — would change the frozen §19.4 budget ladder (256→512→512→1024→
  2048+8Mi relation invariant, §9.62) — a language-semantics change
  with a cross-cutting blast radius (termination argument, limits
  guards, corpus boundary cases) to serve a harness convenience.
  Weigh: reject.

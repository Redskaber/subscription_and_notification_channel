# r77-search — 诊断消息内容质量域审查检索存档（第七十七轮 · Task 55 · §9.78）

K 锚主源直读（3 件 + 1 探针录）+ 弱查披露（第二十五轮）。

| 锚 | 件 | 字节 | 通道 | 载荷 |
|----|----|------|------|------|
| K180 | rustc-dev-guide diagnostics.md | 47,829 | raw.githubusercontent 直达 | 风格指南全文：plain simple English / 「illegal 一词禁用」/ message-stands-on-its-own / 错误面不载修复建议（help/note 分治）/ span 最小化 / `--explain` 深度机制（「give an error a code if the explanation would give more information than the error itself」）/ fluent slug 例证（单源字典同构） |
| K181 | Swift docs/Diagnostics.md | 21,825 | raw.githubusercontent（apple/swift）直达 | 单短语或单句 + 第二语义用分号 / **match the tone and phrasing of other diagnostics**（措辞族一致性正典——MSG-3 三站镜像的工业化先例）/ note 挂接模型 / diagnostic groups = 渐进披露「teachable moments」 |
| K182 | rustc 1.98.1 本地实证探针 ×6 | 2,641（录） | 本地工具链（沿 r70 先例） | E0061/E0057 `this function takes 1 argument but 2 arguments were supplied`（单复数 + was/were 双一致）/ E0308 `expected `bool`, found integer`（被求类型先行）/ `expected expression, found `;`` / `` `if` may be missing an `else` clause `` / `mismatched closing delimiter: `}`` / `this file contains an unclosed delimiter` |
| K183 | rustc_parse parser/mod.rs | 72,436 | raw.githubusercontent 直达 | 解析器级 expected-found 形状族：`expected `;`, found {token}` + span_label `unexpected token` + `to finish parsing this {kind_desc}, expected this to be followed by a `;`` |
| K184 | （依托 K180 内证）rustc fluent 单源字典 | — | dev-guide 例证（fluent::example::try_qux_suggestion） | rustc 诊断文本经 fluent slug 单源化 = kerf §10.5 单源字典纪律的编译器级同构 |
| K185 | OCaml typing_recovery.ml（K179 复用） | 4,000 | r76-search 已入库 | 错误恢复谱系锚——维持 Stage 2+ 窗登记态（本轮零信号不开窗） |

## 弱查披露（第二十五轮）

- q1 rustc fluent 文件（rustc_parse locale en-US.ftl / messages.ftl / jsDelivr 三通道）：**404 / 404 / 404**——路径形态未命中 + GitHub API 403 沿袭（r73 起已知）；K184 降档为 dev-guide 内证锚。
- q2 Elm「Compilers as Assistants」（elm-lang.org/news）：返回 63,154B 页面壳——**JS 渲染 SPA 零正文**（`error` 词零命中）；锚降档为题级（消息质量正面语调先例的存目登记，不作为裁定载荷）。
- q3 rustc-dev-guide diagnostics.md：**成功**（47,829B 全文）。
- q4 Swift docs/Diagnostics.md：**成功**（21,825B 全文）。
- q5 rustc_parse mod.rs：**成功**（72,436B）。
- q6 OCaml typing_recovery.ml：**成功**（4,000B——K179 复用通道再验证）。

## 探针复现命令

```
rustc --edition 2024 arity.rs         # probe A — E0061/E0057 singular discipline
rustc --edition 2024 typemismatch.rs  # probe B — E0308 demanded-first
rustc --edition 2024 parse2.rs        # probe C — expected-found family
rustc --edition 2024 parse3.rs        # probe D — delimiter family
```

源码与完整转录见 probes-rustc-1.98.1.txt。

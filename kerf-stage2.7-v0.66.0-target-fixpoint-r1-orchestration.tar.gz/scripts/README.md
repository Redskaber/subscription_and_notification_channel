# scripts/ — 环境/构建/部署脚本（SOP §3.4）

按 `<domain>/` 子目录组织；自定义安装/配置脚本归档于此并同步 docs/scripts/。
当前为空（Stage 0.0：工具链装配命令已固化 docs/build-guide.md，尚无自研脚本）。

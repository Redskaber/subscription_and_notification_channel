//! Crate-level API tests for kerf-expander (SOP §9.1 rule 5 — the
//! public surface exercised from outside the crate).
//!
//! Sub-stage test doc FP2-FP4 (docs/tests/v0/stage0/plan/expander.md):
//! the fib define contract (Expander → Compiler, plan sub-stage 0.5),
//! the Stage 0 global surface, and the malformed-form family through
//! the public entries.

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_expander::{ExpandCtx, ExpandError, STAGE0_GLOBALS, expand, expand_program};
use kerf_span::Span;
use kerf_span::{ByteOffset, ExpansionId, FileId};
use kerf_syntax::{Phase, ScopeSet, SyntaxObject};

fn sp(start: u32, end: u32) -> Span {
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId::ROOT,
    )
    .expect("test fixture span must be well-formed")
}

fn sym(start: u32, end: u32, text: &str) -> SyntaxObject {
    SyntaxObject::symbol(sp(start, end), ScopeSet::new(), Phase::Runtime, text)
        .expect("test fixture symbol must be valid")
}

fn int(start: u32, end: u32, value: i64) -> SyntaxObject {
    SyntaxObject::int(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
}

fn bl(start: u32, end: u32, value: bool) -> SyntaxObject {
    SyntaxObject::bool(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
}

fn lst(start: u32, end: u32, items: Vec<SyntaxObject>) -> SyntaxObject {
    SyntaxObject::list(sp(start, end), ScopeSet::new(), Phase::Runtime, items)
}

/// (define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))
fn fib_define_form() -> SyntaxObject {
    let fib_at = |s: u32, e: u32| sym(s, e, "fib");
    lst(
        0,
        60,
        vec![
            sym(0, 6, "define"),
            lst(8, 15, vec![fib_at(9, 12), sym(13, 14, "n")]),
            lst(
                17,
                59,
                vec![
                    sym(18, 20, "if"),
                    lst(
                        22,
                        28,
                        vec![sym(23, 24, "<"), sym(25, 26, "n"), int(27, 28, 2)],
                    ),
                    sym(30, 31, "n"),
                    lst(
                        33,
                        58,
                        vec![
                            sym(34, 35, "+"),
                            lst(
                                37,
                                46,
                                vec![
                                    fib_at(38, 41),
                                    lst(
                                        43,
                                        45,
                                        vec![sym(44, 45, "-"), sym(44, 45, "n"), int(44, 45, 1)],
                                    ),
                                ],
                            ),
                            lst(
                                49,
                                57,
                                vec![
                                    fib_at(50, 53),
                                    lst(
                                        54,
                                        56,
                                        vec![sym(55, 56, "-"), sym(55, 56, "n"), int(55, 56, 2)],
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
}

// ---------- positive ----------

#[test]
fn expand_program_delivers_the_fib_contract() {
    let items = expand_program(&[fib_define_form()]).expect("fib define must expand");
    assert_eq!(items.len(), 1);
    match &items[0] {
        ModuleItem::Define { name, value, .. } => {
            assert_eq!(name.as_str(), "fib");
            match value {
                CoreExpr::Fn { params, body, .. } => {
                    assert_eq!(params.len(), 1);
                    assert_eq!(params[0].as_str(), "n");
                    // The body is the recursive if/apply tree.
                    assert!(matches!(**body, CoreExpr::If { .. }));
                }
                other => panic!("expected fn value, got {other}"),
            }
        }
        other => panic!("expected define, got {other}"),
    }
    // TD-002 discipline: every produced span joins cleanly — all same
    // file and expansion generation (desugared nodes reuse source
    // spans; no cross-generation joins ever occur in this layer).
    let mut spans = Vec::new();
    items[0].visit_spans(&mut |span| spans.push(span));
    assert!(spans.len() >= 8, "fib tree must carry >= 8 spans");
    let joined = spans
        .iter()
        .try_fold(spans[0], |acc, s| acc.join(s))
        .expect("all fib spans must join (same generation)");
    assert_eq!(joined, sp(0, 60));
}

#[test]
fn stage0_globals_resolve_as_flat_fallback() {
    // The documented surface: 18 names, arithmetic/pair/IO.
    assert_eq!(STAGE0_GLOBALS.len(), 18);
    for name in [
        "+",
        "-",
        "*",
        "/",
        "<",
        "=",
        "car",
        "cons",
        "nil?",
        "not",
        "read-line",
        "write-line",
    ] {
        assert!(STAGE0_GLOBALS.contains(&name), "`{name}` must be listed");
    }
    // (+ (car nil) 1) — `+` and `car` resolve as globals, `nil` is the
    // literal keyword.
    let mut ctx = ExpandCtx::new();
    let form = lst(
        0,
        15,
        vec![
            sym(1, 2, "+"),
            lst(4, 13, vec![sym(5, 8, "car"), sym(10, 13, "nil")]),
            int(14, 15, 1),
        ],
    );
    let expr = expand(&mut ctx, &form).expect("globals form must expand");
    match expr {
        CoreExpr::Apply { func, args, .. } => {
            assert_eq!(*func, CoreExpr::var(sp(1, 2), "+").unwrap());
            assert_eq!(args.len(), 2);
            assert!(matches!(args[0], CoreExpr::Apply { .. }));
            assert_eq!(
                args[1],
                CoreExpr::Literal {
                    span: sp(14, 15),
                    value: LiteralValue::Int(1)
                }
            );
        }
        other => panic!("expected apply, got {other}"),
    }
}

// ---------- negative ----------

#[test]
fn empty_do_form_is_malformed() {
    // Through the expression entry: at module top level the same form
    // would be a bare expression first (declarations only).
    let mut ctx = ExpandCtx::new();
    let form = lst(0, 3, vec![sym(0, 2, "do")]);
    let err = expand(&mut ctx, &form).expect_err("empty do must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "do"),
        other => panic!("expected malformed do, got {other}"),
    }
}

#[test]
fn set_to_string_target_is_malformed() {
    let mut ctx = ExpandCtx::new();
    let form = lst(
        0,
        13,
        vec![
            sym(0, 4, "set!"),
            SyntaxObject::string(sp(5, 7), ScopeSet::new(), Phase::Runtime, "s".to_owned()),
            int(8, 9, 1),
        ],
    );
    let err = expand(&mut ctx, &form).expect_err("string target must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "set!"),
        other => panic!("expected malformed set!, got {other}"),
    }
}

#[test]
fn require_with_symbol_is_malformed() {
    let form = lst(0, 12, vec![sym(0, 7, "require"), sym(9, 10, "m")]);
    let err = expand_program(&[form]).expect_err("symbol require must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "require"),
        other => panic!("expected malformed require, got {other}"),
    }
}

#[test]
fn define_with_bad_name_shape_is_malformed() {
    // (define 123 1) — the name position is not a symbol or a
    // (name params) list.
    let form = lst(
        0,
        13,
        vec![sym(0, 6, "define"), int(8, 11, 123), int(12, 13, 1)],
    );
    let err = expand_program(&[form]).expect_err("numeric define name must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "define"),
        other => panic!("expected malformed define, got {other}"),
    }
}

#[test]
fn perform_with_non_symbol_effect_is_malformed() {
    let mut ctx = ExpandCtx::new();
    let form = lst(0, 11, vec![sym(0, 7, "perform"), int(9, 10, 1)]);
    let err = expand(&mut ctx, &form).expect_err("numeric effect must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "perform"),
        other => panic!("expected malformed perform, got {other}"),
    }
}

#[test]
fn let_with_mixed_binding_spec_is_malformed() {
    // (let ((x 1) y) 2) — first spec item is a list, so the multi
    // path requires every item to be a (name value) pair.
    let mut ctx = ExpandCtx::new();
    let form = lst(
        0,
        17,
        vec![
            sym(0, 3, "let"),
            lst(
                5,
                13,
                vec![
                    lst(6, 10, vec![sym(7, 8, "x"), int(9, 10, 1)]),
                    sym(12, 13, "y"),
                ],
            ),
            int(15, 16, 2),
        ],
    );
    let err = expand(&mut ctx, &form).expect_err("mixed spec must fail");
    match err {
        ExpandError::MalformedForm { form, .. } => assert_eq!(form, "let"),
        other => panic!("expected malformed let, got {other}"),
    }
}

// ---------- match (switch-window step 2, rulings A/A'/§5.2) ----------

/// A `(match scrutinee (pattern body)...)` form.
fn match_form(arms: Vec<(SyntaxObject, SyntaxObject)>, scrutinee: SyntaxObject) -> SyntaxObject {
    let mut items = vec![sym(0, 5, "match"), scrutinee];
    for (pattern, body) in arms {
        let start = pattern.span.start.0;
        let end = body.span.end.0;
        items.push(lst(start, end, vec![pattern, body]));
    }
    let last = items.last().expect("match needs the head at minimum");
    lst(0, last.span.end.0, items)
}

/// Span-blind structural equality over CoreExpr (spans are source
/// positions — the desugaring reuses the arm spans, the hand-written
/// chain uses its own; the identity principle compares *structure*).
fn same_shape(a: &CoreExpr, b: &CoreExpr) -> bool {
    use CoreExpr::*;
    match (a, b) {
        (
            Fn {
                params: p1,
                body: b1,
                ..
            },
            Fn {
                params: p2,
                body: b2,
                ..
            },
        ) => p1 == p2 && same_shape(b1, b2),
        (
            Apply {
                func: f1, args: a1, ..
            },
            Apply {
                func: f2, args: a2, ..
            },
        ) => {
            same_shape(f1, f2)
                && a1.len() == a2.len()
                && a1.iter().zip(a2).all(|(x, y)| same_shape(x, y))
        }
        (
            If {
                cond: c1,
                then_branch: t1,
                else_branch: e1,
                ..
            },
            If {
                cond: c2,
                then_branch: t2,
                else_branch: e2,
                ..
            },
        ) => same_shape(c1, c2) && same_shape(t1, t2) && same_shape(e1, e2),
        (Var { name: n1, .. }, Var { name: n2, .. }) => n1 == n2,
        (Literal { value: v1, .. }, Literal { value: v2, .. }) => v1 == v2,
        (
            Assign {
                name: n1,
                value: v1,
                ..
            },
            Assign {
                name: n2,
                value: v2,
                ..
            },
        ) => n1 == n2 && same_shape(v1, v2),
        (
            Let {
                bindings: b1,
                body: y1,
                ..
            },
            Let {
                bindings: b2,
                body: y2,
                ..
            },
        ) => {
            b1.len() == b2.len()
                && b1
                    .iter()
                    .zip(b2)
                    .all(|(x, y)| x.name == y.name && same_shape(&x.value, &y.value))
                && same_shape(y1, y2)
        }
        (
            Perform {
                effect: e1,
                args: a1,
                ..
            },
            Perform {
                effect: e2,
                args: a2,
                ..
            },
        ) => e1 == e2 && a1.len() == a2.len() && a1.iter().zip(a2).all(|(x, y)| same_shape(x, y)),
        (
            Handle {
                body: b1,
                handlers: h1,
                ..
            },
            Handle {
                body: b2,
                handlers: h2,
                ..
            },
        ) => same_shape(b1, b2) && h1 == h2,
        _ => false,
    }
}

#[test]
fn match_desugars_to_the_identity_chain() {
    // (match 3 (1 10) (_ 20)) — the product equals the hand-written
    // (let ((match(scrut 3)) (if (= (match(scrut) 1) 10 20)): the
    // carrier binds once, the literal arm tests `=`, the `_` tail is
    // binding-free so it rides no `if` node at all (ruling A': the
    // chain always ends in a value).
    let mut ctx = ExpandCtx::new();
    let form = match_form(
        vec![
            (int(10, 11, 1), int(13, 15, 10)),
            (sym(17, 18, "_"), int(20, 22, 20)),
        ],
        int(7, 8, 3),
    );
    let product = expand(&mut ctx, &form).expect("match expands");

    // The hand-written equivalent: a let over the carrier, an `=`
    // test, both branches plain.
    let handwritten = lst(
        0,
        22,
        vec![
            sym(0, 3, "let"),
            lst(
                5,
                17,
                vec![lst(6, 14, vec![sym(7, 17, "match(scrut"), int(9, 10, 3)])],
            ),
            lst(
                18,
                22,
                vec![
                    sym(18, 20, "if"),
                    lst(
                        20,
                        24,
                        vec![sym(20, 21, "="), sym(21, 22, "match(scrut"), int(22, 23, 1)],
                    ),
                    int(13, 15, 10),
                    int(20, 22, 20),
                ],
            ),
        ],
    );
    let handwritten_expanded = expand(&mut ctx, &handwritten).expect("handwritten expands");
    assert!(
        same_shape(&product, &handwritten_expanded),
        "the desugaring must equal the hand-written chain:\n  product:     {product:?}\n  handwritten: {handwritten_expanded:?}"
    );
}

#[test]
fn match_binding_tail_installs_the_pattern_binds() {
    // (match 5 (y (+ y 1))) — the tail binds; the body sees it. The
    // product: (let ((match(scrut 5))) (let ((y (match(scrut)))) (+ y 1))).
    let mut ctx = ExpandCtx::new();
    let form = match_form(
        vec![(
            sym(10, 11, "y"),
            lst(
                13,
                20,
                vec![sym(13, 14, "+"), sym(15, 16, "y"), int(17, 18, 1)],
            ),
        )],
        int(7, 8, 5),
    );
    let product = expand(&mut ctx, &form).expect("binding match expands");
    let handwritten = lst(
        0,
        20,
        vec![
            sym(0, 3, "let"),
            lst(
                5,
                16,
                vec![lst(6, 14, vec![sym(7, 17, "match(scrut"), int(9, 10, 5)])],
            ),
            lst(
                17,
                30,
                vec![
                    sym(17, 20, "let"),
                    lst(
                        21,
                        33,
                        vec![lst(
                            22,
                            30,
                            vec![sym(23, 24, "y"), sym(25, 35, "match(scrut")],
                        )],
                    ),
                    lst(
                        34,
                        41,
                        vec![sym(34, 35, "+"), sym(36, 37, "y"), int(38, 39, 1)],
                    ),
                ],
            ),
        ],
    );
    let handwritten_expanded = expand(&mut ctx, &handwritten).expect("handwritten expands");
    assert!(
        same_shape(&product, &handwritten_expanded),
        "tail arm binds the subject:\n  product:     {product:?}\n  handwritten: {handwritten_expanded:?}"
    );
}

#[test]
fn match_tuple_pattern_tests_shape_then_components() {
    // (match 7 ((a b) a) (_ 0)) — the pair shape: the arm test is
    // (if (pair? s) (if <a-test> <b-test> false) false) with the car
    // and cdr subjects; the binding rides the components.
    let mut ctx = ExpandCtx::new();
    let tuple_pattern = lst(10, 15, vec![sym(11, 12, "a"), sym(13, 14, "b")]);
    let form = match_form(
        vec![
            (tuple_pattern, sym(17, 18, "a")),
            (sym(20, 21, "_"), int(23, 24, 0)),
        ],
        int(7, 8, 7),
    );
    let product = expand(&mut ctx, &form).expect("tuple match expands");

    // The hand-written equivalent over the same carrier (the
    // concentrated-test form the desugaring produces — the whole
    // test rides the `if` condition, the bindings install only in
    // the then branch):
    // (let ((m 7))
    //   (if (if (pair? m) (if #t #t #f) #f)
    //       (let ((a (car m)) (b (cdr m))) a)
    //       0))
    let m = |s: u32, e: u32| sym(s, e, "match(scrut");
    let handwritten = lst(
        0,
        40,
        vec![
            sym(0, 3, "let"),
            lst(5, 16, vec![lst(6, 14, vec![m(7, 17), int(9, 10, 7)])]),
            lst(
                17,
                60,
                vec![
                    sym(17, 19, "if"),
                    // The concentrated test: (if (pair? m) (if #t #t #f) #f)
                    lst(
                        20,
                        40,
                        vec![
                            sym(20, 22, "if"),
                            lst(23, 30, vec![sym(23, 28, "pair?"), m(24, 25)]),
                            lst(
                                31,
                                41,
                                vec![
                                    sym(31, 33, "if"),
                                    bl(34, 36, true),
                                    bl(37, 39, true),
                                    bl(40, 42, false),
                                ],
                            ),
                            bl(43, 45, false),
                        ],
                    ),
                    // The arm body: (let ((a (car m)) (b (cdr m))) a)
                    lst(
                        28,
                        50,
                        vec![
                            sym(28, 31, "let"),
                            lst(
                                32,
                                55,
                                vec![
                                    lst(
                                        33,
                                        43,
                                        vec![
                                            sym(34, 35, "a"),
                                            lst(36, 42, vec![sym(36, 39, "car"), m(38, 40)]),
                                        ],
                                    ),
                                    lst(
                                        44,
                                        54,
                                        vec![
                                            sym(45, 46, "b"),
                                            lst(47, 53, vec![sym(47, 50, "cdr"), m(49, 51)]),
                                        ],
                                    ),
                                ],
                            ),
                            sym(60, 61, "a"),
                        ],
                    ),
                    // The next arm (the `_` tail, binding-free): 0
                    int(23, 24, 0),
                ],
            ),
        ],
    );
    let handwritten_expanded = expand(&mut ctx, &handwritten).expect("handwritten expands");
    assert!(
        same_shape(&product, &handwritten_expanded),
        "tuple shape test then components:\n  product:     {product:?}\n  handwritten: {handwritten_expanded:?}"
    );
}

#[test]
fn match_refutable_tail_rejects_non_exhaustive() {
    // (match 9 (1 10)) — the last arm is a literal, so a value could
    // fall off the chain: ruling A' rejects at expansion time.
    let mut ctx = ExpandCtx::new();
    let literal = int(10, 11, 1);
    let form = match_form(vec![(literal, int(13, 15, 10))], int(7, 8, 9));
    let err = expand(&mut ctx, &form).expect_err("refutable tail must reject");
    match err {
        ExpandError::NonExhaustiveMatch { .. } => {}
        other => panic!("expected non-exhaustive match, got {other}"),
    }
}

#[test]
fn match_three_element_tuple_rejects_as_unsupported() {
    // (match 1 ((a b c) a) (_ 0)) — the registered family.
    let mut ctx = ExpandCtx::new();
    let triple = lst(
        10,
        17,
        vec![sym(11, 12, "a"), sym(13, 14, "b"), sym(15, 16, "c")],
    );
    let form = match_form(
        vec![
            (triple, sym(19, 20, "a")),
            (sym(22, 23, "_"), int(25, 26, 0)),
        ],
        int(7, 8, 1),
    );
    let err = expand(&mut ctx, &form).expect_err("3-tuple must reject");
    match err {
        ExpandError::UnsupportedPattern { .. } => {}
        other => panic!("expected unsupported pattern, got {other}"),
    }
}

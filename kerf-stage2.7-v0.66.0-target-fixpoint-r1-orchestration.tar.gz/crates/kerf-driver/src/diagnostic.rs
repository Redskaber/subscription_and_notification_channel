//! The structured diagnostic (docs/stage0.md §8.7) — Stage 0 slice.
//!
//! «Errors are data, not exceptions» (§12.2): every pipeline stage
//! failure becomes a [`Diagnostic`] value; the driver collects them
//! across files and renders them in one pass instead of unwinding at
//! the first error.
//!
//! Stage 0 slice decisions (plan-0.8.md, disclosed):
//! - `primary_span` is `Option<Span>`: the reader's four payload-only
//!   variants and the compiler's three product-shape variants have no
//!   position *by design* — a fabricated span would be a DUMMY span
//!   (the 0.1 ruling family: no DUMMY spans, ever).
//! - [`DiagnosticCode`] is stage-level, not variant-level — with one
//!   Stage 1.1 exception: [`DiagnosticCode::Typecheck`] carries the
//!   checker's E0xxx registry code so the rendered tag is the stable
//!   registry string (`error[E0002]`), exactly where stage-1-plan §4
//!   said the two schemes join (at the wiring, not in the checker).
//! - `children`/`suggestions` are deliberately absent: no producer
//!   exists in Stage 0, and an always-empty field is a stub (R1);
//!   the extension belongs to the Stage 1+ diagnostics agenda
//!   (registered, beyond the 0.10 interface-freeze scope).
//! - [`Severity`] carries all four §8.7 levels; `Error` and `Warning`
//!   have producers since Stage 1.1 (the checker's R8 is the first
//!   Warning producer; Note/Help stay producerless contract slots).

use kerf_compiler::CompileError;
use kerf_span::{ByteOffset, FileId, Span};
use kerf_vm::RuntimeError;

/// How severe a diagnostic is (§8.7 contract shape).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    Error,
    Warning,
    Note,
    Help,
}

impl std::fmt::Display for Severity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Severity::Error => "error",
            Severity::Warning => "warning",
            Severity::Note => "note",
            Severity::Help => "help",
        };
        f.write_str(s)
    }
}

/// Which pipeline stage produced the diagnostic.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DiagnosticCode {
    Read,
    Expand,
    Compile,
    Runtime,
    Driver,
    /// The conservative static checker (Stage 1.1 wiring). Carries
    /// the E0xxx registry code; the rendering tag is the registry
    /// string itself (`E0001`..=`E0008`) — rustc-style
    /// `error[E0002]:` — while `Diagnostic::code` stays stage-level
    /// for every other producer.
    Typecheck(kerf_typecheck::TypeCode),
}

impl DiagnosticCode {
    /// The stable rendering tag (`kerf-read` etc.; `E0001`.. for the
    /// checker).
    pub fn tag(self) -> &'static str {
        match self {
            DiagnosticCode::Read => "kerf-read",
            DiagnosticCode::Expand => "kerf-expand",
            DiagnosticCode::Compile => "kerf-compile",
            DiagnosticCode::Runtime => "kerf-runtime",
            DiagnosticCode::Driver => "kerf-driver",
            DiagnosticCode::Typecheck(code) => code.as_str(),
        }
    }
}

impl std::fmt::Display for DiagnosticCode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.tag())
    }
}

/// One structured diagnostic: severity, stage code, message, file and
/// (when the producing error carried one) the primary span.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub severity: Severity,
    pub code: DiagnosticCode,
    pub message: String,
    pub file: FileId,
    pub primary_span: Option<Span>,
}

impl Diagnostic {
    /// Build a diagnostic from a reader error. The literal family
    /// (`InvalidBool` / `MalformedNumber` / `IntOutOfRange` /
    /// `FloatOutOfRange`) carries its whole-token span — the
    /// diagnostic points at the literal's real extent (v0.40.0,
    /// stage0.md §9.71 — rustc underlines the full literal); every
    /// other positioned error becomes an empty span at its byte
    /// offset (empty spans are legal and carry the real offset —
    /// `Span::new` invariant), and a payload-only error keeps `None`.
    pub fn from_read(err: &kerf_reader::ReadError, file: FileId) -> Self {
        let primary_span = err.token_span().or_else(|| {
            err.offset().and_then(|ByteOffset(at)| {
                Span::new(
                    file,
                    ByteOffset(at),
                    ByteOffset(at),
                    kerf_span::ExpansionId::ROOT,
                )
                .ok()
            })
        });
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Read,
            message: err.to_string(),
            file,
            primary_span,
        }
    }

    /// Build a diagnostic from an expander error (every variant
    /// carries a span; the span names its own file).
    pub fn from_expand(err: &kerf_expander::ExpandError) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Expand,
            message: err.to_string(),
            file: err.span().file_id,
            primary_span: Some(err.span()),
        }
    }

    /// Build a diagnostic from a module-loading error (sub-stage
    /// 0.9: the declaration-graph validation face — cycles, missing
    /// and duplicate declarations; rendered under the expand tag
    /// because loading is part of the expansion stage).
    pub fn from_module(err: &kerf_expander::ModuleError) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Expand,
            message: err.to_string(),
            file: err.span().file_id,
            primary_span: Some(err.span()),
        }
    }

    /// Build a diagnostic from a compiler error. Spanned variants
    /// carry their own file; the three product-shape variants are
    /// position-less by design and take the caller's `file` (the
    /// file being compiled — never a fabricated `FileId(0)`).
    pub fn from_compile(err: &CompileError, file: FileId) -> Self {
        let primary_span = err.span();
        let file = primary_span.map(|s| s.file_id).unwrap_or(file);
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Compile,
            message: err.to_string(),
            file,
            primary_span,
        }
    }

    /// Build a diagnostic from a C-emitter refusal (Stage 2.6, the
    /// `emit-c` face). The emitter carries no source positions —
    /// its guards are product-shape level — so the diagnostic rides
    /// the stage code with the message alone.
    pub fn from_emit(err: &kerf_cbackend::EmitError, file: FileId) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Compile,
            message: err.to_string(),
            file,
            primary_span: None,
        }
    }

    /// Build a diagnostic from a runtime error (every variant carries
    /// a span resolved through the debug-info table — §12.1 VM row).
    pub fn from_runtime(err: &RuntimeError) -> Self {
        let span = err.span();
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Runtime,
            message: err.to_string(),
            file: span.file_id,
            primary_span: Some(span),
        }
    }

    /// Build a diagnostic from a checker finding (Stage 1.1 wiring).
    /// The checker severity maps onto the same-named driver levels
    /// (its two-level subset of the §8.7 contract); the message is
    /// passed through verbatim — the checker pre-renders R8-shaped
    /// messages and the driver never rewrites stage messages (the
    /// single-source dictionary).
    pub fn from_typecheck(td: &kerf_typecheck::TypeDiagnostic) -> Self {
        let severity = match td.severity {
            kerf_typecheck::Severity::Error => Severity::Error,
            kerf_typecheck::Severity::Warning => Severity::Warning,
        };
        Diagnostic {
            severity,
            code: DiagnosticCode::Typecheck(td.code),
            message: td.message.clone(),
            file: td.span.file_id,
            primary_span: Some(td.span),
        }
    }

    /// A driver-level error (bad arguments, unknown files): position
    /// is whatever the caller can honestly provide.
    pub fn driver_error(
        message: impl Into<String>,
        file: FileId,
        primary_span: Option<Span>,
    ) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Driver,
            message: message.into(),
            file,
            primary_span,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Diagnostic conversion tests (FP3): the 41-variant exhaustive
    //! mapping — position presence and stage attribution per variant,
    //! plus severity/code display and R8 message passthrough.

    use super::*;
    use kerf_reader::ReadError;
    use kerf_span::SymbolError;
    use kerf_span::{ByteOffset, ExpansionId, Symbol};

    fn file() -> FileId {
        FileId(0)
    }

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            file(),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test span")
    }

    #[test]
    fn severity_display_is_lowercase_single_word() {
        assert_eq!(Severity::Error.to_string(), "error");
        assert_eq!(Severity::Warning.to_string(), "warning");
        assert_eq!(Severity::Note.to_string(), "note");
        assert_eq!(Severity::Help.to_string(), "help");
    }

    #[test]
    fn code_tags_are_stable() {
        assert_eq!(DiagnosticCode::Read.tag(), "kerf-read");
        assert_eq!(DiagnosticCode::Expand.to_string(), "kerf-expand");
        assert_eq!(DiagnosticCode::Compile.to_string(), "kerf-compile");
        assert_eq!(DiagnosticCode::Runtime.to_string(), "kerf-runtime");
        assert_eq!(DiagnosticCode::Driver.to_string(), "kerf-driver");
        assert_eq!(
            DiagnosticCode::Typecheck(kerf_typecheck::TypeCode::ArityMismatch).tag(),
            "E0002",
            "the checker tag is the registry string"
        );
    }

    #[test]
    fn from_typecheck_maps_code_severity_span_and_message() {
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::ArityMismatch,
            kerf_typecheck::Severity::Error,
            span(4, 9),
            "this function takes 1 argument but 2 were supplied".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        assert_eq!(
            d.code,
            DiagnosticCode::Typecheck(kerf_typecheck::TypeCode::ArityMismatch)
        );
        assert_eq!(d.severity, Severity::Error);
        assert_eq!(d.primary_span, Some(span(4, 9)));
        assert_eq!(d.file, file());
        assert_eq!(
            d.message, "this function takes 1 argument but 2 were supplied",
            "the message passes through verbatim (single-source dictionary)"
        );
    }

    #[test]
    fn from_typecheck_maps_warning_level() {
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span(0, 4),
            "assignment rebinds builtin `car`".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        assert_eq!(d.severity, Severity::Warning, "R8 lands on Warning");
        assert_eq!(d.code.tag(), "E0008");
    }

    #[test]
    fn from_typecheck_error_renders_registry_tag() {
        // The joined rendering face: `error[E0001]:` — the registry
        // code in the bracket, not a stage tag.
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::UnboundVariable,
            kerf_typecheck::Severity::Error,
            span(1, 2),
            "unbound variable `g`".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        let head = format!("{}[{}]: {}", d.severity, d.code.tag(), d.message);
        assert_eq!(head, "error[E0001]: unbound variable `g`");
    }

    #[test]
    fn read_error_position_becomes_empty_span_at_offset() {
        let err = ReadError::UnclosedList {
            opened_at: ByteOffset(9),
        };
        let d = Diagnostic::from_read(&err, file());
        assert_eq!(d.code, DiagnosticCode::Read);
        assert_eq!(
            d.primary_span,
            Some(span(9, 9)),
            "a byte offset renders as an empty span at that offset"
        );
        assert_eq!(d.file, file());
    }

    #[test]
    fn read_error_without_position_keeps_none() {
        for err in [
            ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            }),
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
        ] {
            let d = Diagnostic::from_read(&err, file());
            assert!(
                d.primary_span.is_none(),
                "{err:?} must not fabricate a span"
            );
        }
    }

    #[test]
    fn literal_family_renders_its_whole_token_span() {
        // v0.40.0 (stage0.md §9.71): the four complete-atom rejections
        // carry the literal's real byte extent — the diagnostic points
        // at the token, not at a fabricated byte and not at nothing.
        let cases: Vec<(ReadError, (u32, u32))> = vec![
            (
                ReadError::InvalidBool {
                    text: "#q".to_owned(),
                    span: span(0, 2),
                },
                (0, 2),
            ),
            (
                ReadError::MalformedNumber {
                    text: "1.2.3".to_owned(),
                    span: span(11, 16),
                },
                (11, 16),
            ),
            (
                ReadError::IntOutOfRange {
                    text: "9223372036854775808".to_owned(),
                    span: span(4, 23),
                },
                (4, 23),
            ),
            (
                ReadError::FloatOutOfRange {
                    text: "1e999".to_owned(),
                    span: span(4, 9),
                },
                (4, 9),
            ),
        ];
        for (i, (err, (s, e))) in cases.iter().enumerate() {
            let d = Diagnostic::from_read(err, file());
            let got = d
                .primary_span
                .unwrap_or_else(|| panic!("case {i} must carry the token span"));
            assert_eq!((got.start.0, got.end.0), (*s, *e), "case {i} extent");
            assert_eq!(got.file_id, file(), "case {i} file");
        }
    }

    #[test]
    fn every_read_variant_maps_with_correct_position_presence() {
        // All twelve reader variants: six single-offset, four
        // token-span (the literal family), two payload-only.
        let cases: Vec<(ReadError, bool)> = vec![
            (
                ReadError::UnclosedList {
                    opened_at: ByteOffset(0),
                },
                true,
            ),
            (ReadError::UnexpectedClose { at: ByteOffset(1) }, true),
            (
                ReadError::UnterminatedString {
                    started_at: ByteOffset(2),
                },
                true,
            ),
            (
                ReadError::InvalidEscape {
                    escape: 'z',
                    at: ByteOffset(3),
                },
                true,
            ),
            (
                ReadError::InvalidBool {
                    text: "#x".into(),
                    span: span(9, 11),
                },
                true,
            ),
            (
                ReadError::MalformedNumber {
                    text: "9q".into(),
                    span: span(9, 11),
                },
                true,
            ),
            (
                ReadError::IntOutOfRange {
                    text: "99999999999999999999".into(),
                    span: span(4, 24),
                },
                true,
            ),
            (
                ReadError::FloatOutOfRange {
                    text: "1e999".into(),
                    span: span(4, 9),
                },
                true,
            ),
            (
                ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                    text: "\u{1}x".into(),
                }),
                false,
            ),
            (ReadError::EmptyApplication { at: ByteOffset(4) }, true),
            (
                ReadError::NestingDepthExceeded {
                    depth: 300,
                    limit: 256,
                },
                false,
            ),
            (
                ReadError::UnexpectedCharacter {
                    character: '{',
                    at: ByteOffset(5),
                },
                true,
            ),
        ];
        for (i, (err, positioned)) in cases.iter().enumerate() {
            let d = Diagnostic::from_read(err, file());
            assert_eq!(d.code, DiagnosticCode::Read, "case {i}");
            assert_eq!(d.severity, Severity::Error, "case {i}");
            assert_eq!(d.primary_span.is_some(), *positioned, "case {i}");
            assert!(!d.message.is_empty(), "case {i} message passthrough");
        }
    }

    #[test]
    fn expand_error_carries_its_span_and_file() {
        // §9.65 EXP-1: interned identity payload (the diagnostic
        // consumes only the span; the payload type co-varies with the
        // expander error family).
        let err = kerf_expander::ExpandError::UnboundIdentifier {
            name: Symbol::new("nope").expect("fixture symbol must be valid"),
            span: span(4, 8),
        };
        let d = Diagnostic::from_expand(&err);
        assert_eq!(d.code, DiagnosticCode::Expand);
        assert_eq!(d.primary_span, Some(span(4, 8)));
        assert_eq!(d.file, file());
    }

    #[test]
    fn compile_error_spanned_and_spanless_families() {
        let spanned = CompileError::StackUnderflow {
            pc: 3,
            span: span(1, 5),
        };
        let d = Diagnostic::from_compile(&spanned, FileId(0));
        assert_eq!(d.code, DiagnosticCode::Compile);
        assert_eq!(d.primary_span, Some(span(1, 5)));

        let spanless = CompileError::EmptyFuncTable;
        let d2 = Diagnostic::from_compile(&spanless, FileId(3));
        assert!(d2.primary_span.is_none());
        assert_eq!(
            d2.file,
            FileId(3),
            "spanless variants take the caller's file, not a fabricated id"
        );
        assert!(!d2.message.is_empty());
    }

    #[test]
    fn runtime_error_carries_its_span() {
        let err = RuntimeError::DivByZero { span: span(6, 10) };
        let d = Diagnostic::from_runtime(&err);
        assert_eq!(d.code, DiagnosticCode::Runtime);
        assert_eq!(d.primary_span, Some(span(6, 10)));
        assert_eq!(d.file, file());
    }

    #[test]
    fn driver_error_is_position_optional() {
        let d = Diagnostic::driver_error("no such file: `gone.krf`", FileId(0), None);
        assert_eq!(d.code, DiagnosticCode::Driver);
        assert_eq!(d.severity, Severity::Error);
        assert!(d.primary_span.is_none());
        assert_eq!(d.message, "no such file: `gone.krf`");
    }

    #[test]
    fn messages_pass_through_verbatim_r8_shapes() {
        // The message is the stage error's Display output, unchanged —
        // the single-source dictionary (R8) means the driver never
        // rewrites stage messages.
        let err = ReadError::UnexpectedClose { at: ByteOffset(7) };
        let d = Diagnostic::from_read(&err, file());
        assert_eq!(d.message, err.to_string());
        let rt = RuntimeError::DivByZero { span: span(0, 1) };
        let d2 = Diagnostic::from_runtime(&rt);
        assert_eq!(d2.message, rt.to_string());
    }

    #[test]
    fn read_error_span_respects_file_argument() {
        // The span is built on the *driver's* file id (the reader
        // error payload is offset-only; file identity comes from
        // which file was being read).
        let err = ReadError::EmptyApplication { at: ByteOffset(2) };
        let d = Diagnostic::from_read(&err, FileId(5));
        assert_eq!(d.file, FileId(5));
        assert_eq!(
            d.primary_span.map(|s| s.file_id),
            Some(FileId(5)),
            "the fabricated span must live in the file being read"
        );
    }
}

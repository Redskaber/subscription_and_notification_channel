//! Stage 1.5 second segment — the lexical layer of the reader,
//! rewritten in the frozen kerf subset itself
//! (`selfhost/v1/lexer.krf`), checked against the Rust reader
//! oracle through the **full .krf chain** on both engines: the
//! source rides in as a byte table (the RS-1 source-injection
//! channel with the payload generalized from token records to one
//! integer per byte — zero freeze-surface change), the `.krf` lexer
//! makes every lexical decision, and the unchanged structure layer
//! (`selfhost/v1/reader.krf`, embedded by `reader_parity`) consumes
//! the resulting `tokens` binding.
//!
//! Three axes, all byte-for-byte (the 63-a re-audit remediation;
//! the former `ParityLayer::Lexer` split — six lexical variants
//! that never reached the `.krf` layer — is superseded by this
//! module: lexical decisions are now self-hosted too):
//!
//! * **Token axis** — the oracle `lex` token stream and the `.krf`
//!   `tokens` global normalize to the same per-record dump
//!   (`(lparen s e)`, `(ident s e text)`, `(int s e v)`, …), so
//!   lexical drift localizes to the exact record.
//! * **Tree axis** — the oracle `read_program` tree and the `.krf`
//!   `result` verdict normalize through the same dump grammar as
//!   [`crate::reader_parity::oracle_dump`] (span strings replaced by
//!   the int positions the `.krf` chain carries natively).
//! * **Error axis** — a rejection on either side renders through the
//!   oracle's own `Display` plus the harness `@ byte` suffix (the
//!   §9.56 DIAG-1 key), so all twelve `ReadError` variants compare
//!   byte-precisely.
//!
//! The permanent host layer (K20, the documented honest boundary of
//! this segment): the **f64 value face** — a `.krf` float record
//! carries its span, and the harness derives the value with the same
//! Rust `parse` the oracle used, including the `is_infinite`
//! overflow rejection — because no variable-precision arithmetic
//! exists in the frozen subset; and the **string payload decode**
//! (escape → char), for the same reason (no string construction).
//! Every other decision — trivia, comments, the BOM, the Unicode
//! whitespace table, the reject set, atom boundaries, classification,
//! the i64 threshold guard, the float grammar automaton, the Symbol
//! floor, escape validity, string termination — is made in
//! `lexer.krf`.
//!
//! Engine bracket (the r74 K165/K166 discipline): the assembled
//! program's per-element self-recursion gives the harness a finite
//! input envelope on the evaluator (depth rides tokens plus the
//! longest byte run). Corpus-scale sources run on **both** engines;
//! sources past the bracket (the `lexer.krf` own-source fixed point)
//! run through [`reader_parity_full_vm`] with the bracket disclosed.

use kerf_reader::{Delimiter, ReadError, StxTokenKind, lex, read_program};
use kerf_runtime::Evaluator;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol, SymbolError};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Heap, RuntimeError, Value, Vm};

use crate::diagnostic::Severity;
use crate::pipeline;
use crate::reader_parity::{
    READER_SOURCE, as_i64, as_str, error_parity_key, need_fields, oracle_dump, value_elems,
};
use crate::session::Session;

/// The self-hosted lexical-layer reader, embedded from the
/// workspace's bootstrap face (single source — tests and any future
/// CLI face consume this constant, never a copy).
pub const LEXER_SOURCE: &str = include_str!("../../../selfhost/v1/lexer.krf");

/// Encode a source into the byte-table prefix — the RS-1 channel
/// with the payload generalized to one integer per byte (the
/// re-audit finding: lexical reachability needs no string
/// inspection primitives — plain integer arithmetic over the byte
/// table expresses every lexical decision).
pub fn byte_table_prefix(source: &str) -> String {
    // The empty source rides as `(quote nil)`: the reader rejects the
    // empty application `()` at the Reader stage (subset-spec §2.5),
    // and `nil` is the datum face of the empty list (§1.4).
    if source.is_empty() {
        return "(define source-bytes (quote nil))\n".to_string();
    }
    let mut out = String::from("(define source-bytes (quote (");
    for (i, b) in source.as_bytes().iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        out.push_str(&b.to_string());
    }
    out.push_str(")))\n");
    out
}

/// Assemble the full-chain program: byte-table prefix, the `.krf`
/// lexical layer (binds `tokens` / `lex-error`), then the unchanged
/// structure layer (binds `result` by consuming `tokens`).
pub fn assemble_full_chain(source: &str) -> String {
    format!(
        "{}{}\n{}",
        byte_table_prefix(source),
        LEXER_SOURCE,
        READER_SOURCE
    )
}

// ---------------------------------------------------------------------------
// The oracle side
// ---------------------------------------------------------------------------

/// The oracle's per-record token dump — the token-axis grammar both
/// sides normalize to. One record per line; payloads carry the
/// oracle's own data (symbol text, typed values, the decoded
/// string) so a drift localizes to the exact record and field.
pub fn oracle_token_dump(source: &str) -> Result<String, ReadError> {
    let tokens = lex(FileId(0), source)?;
    let mut out = String::new();
    for t in &tokens {
        let (s, e) = (t.span.start.0, t.span.end.0);
        match &t.kind {
            StxTokenKind::Delimiter(Delimiter::Open) => {
                out.push_str(&format!("(lparen {s} {e})\n"));
            }
            StxTokenKind::Delimiter(Delimiter::Close) => {
                out.push_str(&format!("(rparen {s} {e})\n"));
            }
            StxTokenKind::Identifier(sym) => {
                out.push_str(&format!("(ident {s} {e} {})\n", sym.as_str()));
            }
            StxTokenKind::IntLiteral(v) => {
                out.push_str(&format!("(int {s} {e} {v})\n"));
            }
            StxTokenKind::FloatLiteral(v) => {
                out.push_str(&format!("(float {s} {e} {v:?})\n"));
            }
            StxTokenKind::BoolLiteral(v) => {
                out.push_str(&format!("(bool {s} {e} {v})\n"));
            }
            StxTokenKind::StringLiteral(v) => {
                out.push_str(&format!("(string {s} {e} {v:?})\n"));
            }
            StxTokenKind::Eof => {
                out.push_str(&format!("(eof {s} {e})\n"));
            }
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// The .krf side — decoding the three globals
// ---------------------------------------------------------------------------

/// One axis outcome: a normalized dump, or the error-axis key of a
/// rejection that decided the case at this stage.
type Axis = Result<String, String>;

/// The full-chain outcome of one engine run: both axes decoded.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChainOutcome {
    /// The `tokens` global as a token-axis dump, or the error key of
    /// the lexical rejection (including the K20 float-value face).
    pub token_axis: Axis,
    /// The `result` global as a tree-axis dump, or the error key of
    /// the structure-layer rejection (a lexical rejection propagates
    /// the same key here).
    pub tree_axis: Axis,
}

/// Slice the source by byte offsets (a record's span payload).
fn slice<'a>(source: &'a str, s: i64, e: i64, what: &str) -> Result<&'a str, String> {
    let (s, e) = (s as usize, e as usize);
    if s > e || e > source.len() || !source.is_char_boundary(s) || !source.is_char_boundary(e) {
        return Err(format!(
            "harness defect: {what} span {s}..{e} is not a valid slice of a {}-byte source",
            source.len()
        ));
    }
    Ok(&source[s..e])
}

/// Decode the payload of a string-literal record: the raw bytes
/// between the quotes with the five escapes folded — the permanent
/// host-side transform (no string construction exists in the
/// subset); the *decisions* (boundaries, escape validity,
/// termination) were already made in `lexer.krf`.
fn decode_string_literal(raw: &str) -> String {
    let mut out = String::new();
    let mut chars = raw.chars();
    while let Some(c) = chars.next() {
        if c != '\\' {
            out.push(c);
            continue;
        }
        match chars.next() {
            Some('"') => out.push('"'),
            Some('\\') => out.push('\\'),
            Some('n') => out.push('\n'),
            Some('t') => out.push('\t'),
            Some('r') => out.push('\r'),
            // Unreachable post-validation (the .krf layer rejected
            // invalid escapes) — kept defensive, never silent.
            Some(other) => out.push(other),
            None => break,
        }
    }
    out
}

/// Rebuild the oracle `ReadError` from an error record's payload
/// fields (kind first, then the variant's payloads — the shapes in
/// the `lexer.krf` header; structure-layer kinds arrive from
/// `reader.krf` with int positions).
fn rebuild_error(kind: &str, payload: &[&Value], source: &str) -> Result<ReadError, String> {
    let at =
        |i: usize| -> Result<ByteOffset, String> { Ok(ByteOffset(as_i64(payload[i])? as u32)) };
    let text_span = |i: usize, j: usize| -> Result<(String, Span), String> {
        let s = as_i64(payload[i])? as u32;
        let e = as_i64(payload[j])? as u32;
        let text = slice(source, s as i64, e as i64, "error")?.to_owned();
        let span = Span::new(FileId(0), ByteOffset(s), ByteOffset(e), ExpansionId::ROOT)
            .map_err(|err| format!("harness defect: rebuilt span rejected: {err}"))?;
        Ok((text, span))
    };
    match kind {
        "unterminated-string" => {
            need_fields(payload, 1, "unterminated-string")?;
            Ok(ReadError::UnterminatedString { started_at: at(0)? })
        }
        "invalid-escape" => {
            need_fields(payload, 2, "invalid-escape")?;
            let cp = as_i64(payload[0])? as u32;
            let escape = char::from_u32(cp)
                .ok_or_else(|| format!("harness defect: codepoint {cp} is not a char"))?;
            Ok(ReadError::InvalidEscape { escape, at: at(1)? })
        }
        "invalid-bool" => {
            need_fields(payload, 2, "invalid-bool")?;
            let (text, span) = text_span(0, 1)?;
            Ok(ReadError::InvalidBool { text, span })
        }
        "malformed-number" => {
            need_fields(payload, 2, "malformed-number")?;
            let (text, span) = text_span(0, 1)?;
            Ok(ReadError::MalformedNumber { text, span })
        }
        "int-out-of-range" => {
            need_fields(payload, 2, "int-out-of-range")?;
            let (text, span) = text_span(0, 1)?;
            Ok(ReadError::IntOutOfRange { text, span })
        }
        "float-out-of-range" => {
            need_fields(payload, 2, "float-out-of-range")?;
            let (text, span) = text_span(0, 1)?;
            Ok(ReadError::FloatOutOfRange { text, span })
        }
        "invalid-symbol" => {
            need_fields(payload, 2, "invalid-symbol")?;
            let (text, _) = text_span(0, 1)?;
            Ok(ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text,
            }))
        }
        "unexpected-char" => {
            need_fields(payload, 2, "unexpected-char")?;
            let cp = as_i64(payload[0])? as u32;
            let character = char::from_u32(cp)
                .ok_or_else(|| format!("harness defect: codepoint {cp} is not a char"))?;
            Ok(ReadError::UnexpectedCharacter {
                character,
                at: at(1)?,
            })
        }
        "unclosed" => {
            need_fields(payload, 1, "unclosed")?;
            Ok(ReadError::UnclosedList { opened_at: at(0)? })
        }
        "unexpected-close" => {
            need_fields(payload, 1, "unexpected-close")?;
            Ok(ReadError::UnexpectedClose { at: at(0)? })
        }
        "empty-app" => {
            need_fields(payload, 1, "empty-app")?;
            Ok(ReadError::EmptyApplication { at: at(0)? })
        }
        "nesting" => {
            need_fields(payload, 2, "nesting")?;
            Ok(ReadError::NestingDepthExceeded {
                depth: as_i64(payload[0])? as usize,
                limit: as_i64(payload[1])? as usize,
            })
        }
        other => Err(format!("harness defect: unknown error kind `{other}`")),
    }
}

/// Decode the `tokens` global into the token-axis dump. The K20
/// float-value face applies here: a float record whose host-parsed
/// value is infinite turns the whole axis into the
/// `FloatOutOfRange` key (the same rejection the oracle's lexer
/// made), and a float record that does not parse at all is a
/// grammar divergence (a harness-defect-class drift — the `.krf`
/// automaton accepted an atom Rust cannot).
fn decode_token_axis(tokens: &Value, heap: &Heap, source: &str) -> Axis {
    let records =
        value_elems(tokens, heap).map_err(|e| format!("harness defect: tokens chain: {e}"))?;
    let mut out = String::new();
    for rec in &records {
        let elems =
            value_elems(rec, heap).map_err(|e| format!("harness defect: token record: {e}"))?;
        if elems.len() < 2 {
            return Err(format!(
                "harness defect: token record has {} fields, need at least 2",
                elems.len()
            ));
        }
        let kind = as_str(elems[0]).map_err(|e| format!("harness defect: token kind: {e}"))?;
        if kind == "eof" {
            // The eof record carries a single payload: the end offset
            // (both span ends — the oracle's Eof token is empty).
            let end = match as_i64(elems[1]) {
                Ok(v) => v,
                Err(e) => return Err(format!("harness defect: eof payload: {e}")),
            };
            out.push_str(&format!("(eof {end} {end})\n"));
            continue;
        }
        if elems.len() < 3 {
            return Err(format!(
                "harness defect: token record has {} fields, need at least 3",
                elems.len()
            ));
        }
        let (s, e) = match (as_i64(elems[1]), as_i64(elems[2])) {
            (Ok(s), Ok(e)) => (s, e),
            (Err(e), _) | (_, Err(e)) => return Err(format!("harness defect: token span: {e}")),
        };
        match kind {
            "lparen" | "rparen" => {
                out.push_str(&format!("({kind} {s} {e})\n"));
            }
            "ident" => {
                let text = slice(source, s, e, "ident")?;
                out.push_str(&format!("(ident {s} {e} {text})\n"));
            }
            "int" => {
                if let Some(v) = elems.get(3) {
                    match as_i64(v) {
                        Ok(v) => out.push_str(&format!("(int {s} {e} {v})\n")),
                        Err(e) => return Err(format!("harness defect: int payload: {e}")),
                    }
                } else {
                    return Err("harness defect: int record lacks its value payload".to_string());
                }
            }
            "float" => {
                let text = slice(source, s, e, "float")?;
                match text.parse::<f64>() {
                    Ok(v) if v.is_infinite() => {
                        // The K20 host face: the oracle rejected this
                        // atom at the overflow check; the .krf record
                        // rides its span, and the host applies the
                        // same value semantics.
                        let owned = [Value::Int(s), Value::Int(e)];
                        let refs: Vec<&Value> = owned.iter().collect();
                        let err = rebuild_error("float-out-of-range", &refs, source)?;
                        return Err(error_parity_key(&err));
                    }
                    Ok(v) => out.push_str(&format!("(float {s} {e} {v:?})\n")),
                    Err(_) => {
                        return Err(format!(
                            "harness defect: .krf float grammar accepted an unparseable atom `{text}`"
                        ));
                    }
                }
            }
            "bool" => match elems.get(3) {
                Some(Value::Bool(true)) => out.push_str(&format!("(bool {s} {e} true)\n")),
                Some(Value::Bool(false)) => out.push_str(&format!("(bool {s} {e} false)\n")),
                Some(other) => {
                    return Err(format!("harness defect: bool payload is {other:?}"));
                }
                None => return Err("harness defect: bool record lacks its payload".to_string()),
            },
            "string" => {
                let raw = slice(source, s + 1, e - 1, "string")?;
                let decoded = decode_string_literal(raw);
                out.push_str(&format!("(string {s} {e} {decoded:?})\n"));
            }
            other => {
                return Err(format!("harness defect: unknown token kind `{other}`"));
            }
        }
    }
    Ok(out)
}

/// Decode the `result` global into the tree-axis outcome (the
/// `oracle_dump` grammar with int positions and host-derived
/// payloads).
fn decode_tree_axis(result: &Value, heap: &Heap, source: &str) -> Axis {
    let elems = match value_elems(result, heap) {
        Ok(e) => e,
        Err(e) => return Err(format!("harness defect: result chain: {e}")),
    };
    if elems.is_empty() {
        return Err("harness defect: result verdict is empty".to_string());
    }
    let tag = match as_str(elems[0]) {
        Ok(t) => t,
        Err(e) => return Err(format!("harness defect: result tag: {e}")),
    };
    match tag {
        "ok" => {
            let mut out = String::new();
            for (i, f) in elems[1..].iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_krf_node(f, heap, source, &mut out)?;
            }
            Ok(out)
        }
        "err" => {
            let kind = match as_str(elems[1]) {
                Ok(k) => k,
                Err(e) => return Err(format!("harness defect: error kind: {e}")),
            };
            match rebuild_error(kind, &elems[2..], source) {
                Ok(err) => Err(error_parity_key(&err)),
                Err(e) => Err(e),
            }
        }
        other => Err(format!("harness defect: unknown verdict tag `{other}`")),
    }
}

/// The `.krf` chain's node dump — the `oracle_dump` grammar with the
/// int positions and typed payloads the chain carries (ident text
/// and float values derive from the span; the int value rides the
/// record).
fn dump_krf_node(value: &Value, heap: &Heap, source: &str, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "node")?;
    let kind = as_str(elems[0])?;
    let s = as_i64(elems[1])?;
    let e = as_i64(elems[2])?;
    match kind {
        "ident" => {
            let text = slice(source, s, e, "ident")?;
            out.push_str(&format!("(ident {s} {e} {text})"));
        }
        "int" => {
            need_fields(&elems, 4, "int node")?;
            let v = as_i64(elems[3])?;
            out.push_str(&format!("(int {s} {e} {v})"));
        }
        "float" => {
            let text = slice(source, s, e, "float")?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("harness defect: float span `{text}` does not parse"))?;
            out.push_str(&format!("(float {s} {e} {v:?})"));
        }
        "bool" => match elems[3] {
            Value::Bool(b) => out.push_str(&format!("(bool {s} {e} {b})")),
            other => return Err(format!("harness defect: bool node payload {other:?}")),
        },
        "string" => {
            let raw = slice(source, s + 1, e - 1, "string")?;
            let decoded = decode_string_literal(raw);
            out.push_str(&format!("(string {s} {e} {decoded:?})"));
        }
        "list" => {
            out.push_str(&format!("(list {s} {e}"));
            for item in &elems[3..] {
                out.push(' ');
                dump_krf_node(item, heap, source, out)?;
            }
            out.push(')');
        }
        other => return Err(format!("harness defect: unknown node kind `{other}`")),
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The junction feed (Stage 2.4, §9.87 — the full composed chain)
// ---------------------------------------------------------------------------

/// Rebuild the `.krf` reader's forms from the VM engine's `result`
/// value — the junction feed of the 2.4 composed chain (the chain
/// consumes its own products: THESE forms, never the oracle's, ride
/// into the expansion layer's prefix). Mirrors [`dump_krf_node`]'s
/// derivation exactly — spans plus source slices for
/// ident/float/string, record payloads for int/bool — so the
/// junction-1 dump gate and this rebuild agree by construction.
/// `None` when the verdict is a rejection: nothing feeds forward.
///
/// The rebuilt forms carry the expansion layer's own hosting
/// convention (expander.krf's header: uniformly runtime phase with
/// empty scope sets) — exactly the fields the forms-stream encoding
/// consumes; phase and scopes never ride the stream.
fn rebuild_read_forms(
    result: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Option<Vec<SyntaxObject>>, String> {
    let elems = value_elems(result, heap).map_err(|e| format!("result chain: {e}"))?;
    let tag = as_str(elems.first().ok_or("result verdict is empty")?)
        .map_err(|e| format!("result tag: {e}"))?;
    match tag {
        "ok" => {
            let mut forms = Vec::with_capacity(elems.len().saturating_sub(1));
            for form in &elems[1..] {
                forms.push(rebuild_read_node(form, heap, source)?);
            }
            Ok(Some(forms))
        }
        "err" => Ok(None),
        other => Err(format!("harness defect: unknown verdict tag `{other}`")),
    }
}

/// One node of the rebuilt forms tree (the `dump_krf_node` grammar,
/// value-shaped: a `SyntaxObject` per record).
fn rebuild_read_node(value: &Value, heap: &Heap, source: &str) -> Result<SyntaxObject, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "node")?;
    let kind = as_str(elems[0])?;
    let s = as_i64(elems[1])?;
    let e = as_i64(elems[2])?;
    // Source spans, generation ROOT: the read chain's products are
    // all source syntax (macro generations begin at the expansion
    // layer, never below it).
    let span = Span {
        file_id: FileId(0),
        start: ByteOffset(s as u32),
        end: ByteOffset(e as u32),
        expansion_id: ExpansionId::ROOT,
    };
    let host = |datum| SyntaxObject {
        datum,
        span,
        scopes: ScopeSet::default(),
        phase: Phase::Runtime,
    };
    match kind {
        "ident" => {
            let text = slice(source, s, e, "ident")?;
            let sym = Symbol::new(text).map_err(|err| {
                format!("harness defect: the .krf reader emitted an invalid identifier ({err:?})")
            })?;
            Ok(host(StxDatum::Symbol(sym)))
        }
        "int" => {
            need_fields(&elems, 4, "int node")?;
            Ok(host(StxDatum::Int(as_i64(elems[3])?)))
        }
        "float" => {
            let text = slice(source, s, e, "float")?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("harness defect: float span `{text}` does not parse"))?;
            Ok(host(StxDatum::Float(v)))
        }
        "bool" => match elems[3] {
            Value::Bool(b) => Ok(host(StxDatum::Bool(*b))),
            other => Err(format!("harness defect: bool node payload {other:?}")),
        },
        "string" => {
            let raw = slice(source, s + 1, e - 1, "string")?;
            // SYN-1: the shared payload takes `String` at this
            // boundary — the rebuild is the single copy point.
            Ok(host(StxDatum::String(decode_string_literal(raw).into())))
        }
        "list" => {
            let mut items = Vec::with_capacity(elems.len() - 3);
            for item in &elems[3..] {
                items.push(rebuild_read_node(item, heap, source)?);
            }
            Ok(host(StxDatum::List(items)))
        }
        other => Err(format!("harness defect: unknown node kind `{other}`")),
    }
}

// ---------------------------------------------------------------------------
// The engine drivers
// ---------------------------------------------------------------------------

/// Classify one engine rejection of the assembled harness program
/// (the r74 K165 lineage — the two budget faces are the harness's
/// honest input envelope; every other rejection is a defect).
fn classify_engine_failure(engine: &str, what: &str, err: &RuntimeError) -> String {
    if matches!(
        err,
        RuntimeError::BudgetExceeded { .. } | RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .krf {what} exceeded the {engine} engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        format!("harness defect: the .krf {what} crashed on the {engine} engine: {err}")
    }
}

/// Decode one engine's three globals into the chain outcome.
fn decode_engine_globals(
    lex_error: Option<&Value>,
    tokens: Option<&Value>,
    result: Option<&Value>,
    heap: &Heap,
    source: &str,
    engine: &str,
) -> Result<ChainOutcome, String> {
    let lex_error = lex_error
        .ok_or_else(|| format!("harness defect: no `lex-error` global on the {engine} engine"))?;
    let tokens = tokens
        .ok_or_else(|| format!("harness defect: no `tokens` global on the {engine} engine"))?;
    let result = result
        .ok_or_else(|| format!("harness defect: no `result` global on the {engine} engine"))?;
    // A lexical rejection decides both axes (the structure layer
    // no-ops on nil tokens).
    if !matches!(lex_error, Value::Nil) {
        let elems = value_elems(lex_error, heap)
            .map_err(|e| format!("harness defect: lex-error chain: {e}"))?;
        if elems.is_empty() {
            return Err("harness defect: lex-error record is empty".to_string());
        }
        let kind = as_str(elems[0]).map_err(|e| format!("harness defect: lex-error kind: {e}"))?;
        let err = rebuild_error(kind, &elems[1..], source)?;
        let key = error_parity_key(&err);
        return Ok(ChainOutcome {
            token_axis: Err(key.clone()),
            tree_axis: Err(key),
        });
    }
    let token_axis = decode_token_axis(tokens, heap, source);
    // A token-axis rejection (the K20 float face, or a decode
    // defect) carries to the tree axis — the chain's verdict is the
    // rejection either way.
    let tree_axis = match &token_axis {
        Err(key) => Err(key.clone()),
        Ok(_) => decode_tree_axis(result, heap, source),
    };
    Ok(ChainOutcome {
        token_axis,
        tree_axis,
    })
}

/// The dual-run shape with the junction feed: the VM side's outcome
/// plus its rebuilt forms, and the eval side's outcome (`None` on
/// the VM-bracket face).
type DualOutcomeWithForms = (
    (ChainOutcome, Option<Vec<SyntaxObject>>),
    Option<ChainOutcome>,
);

/// Run the assembled full chain on both engines and decode each
/// side's three globals (the `drive_dual_engines` composition with
/// the three-global extractor). The VM side additionally rebuilds
/// its forms (the 2.4 junction feed — `None` on a rejection),
/// decoded while the VM heap is still alive.
fn drive_full_dual(assembled: &str, source: &str) -> Result<DualOutcomeWithForms, String> {
    let mut session = Session::new();
    let program =
        pipeline::parse(&mut session, "lexer-parity-host.krf", assembled).map_err(|diags| {
            format!("harness defect: the assembled full-chain program failed to parse: {diags:?}")
        })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled full-chain program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled full-chain program failed to compile: {err}")
    })?;

    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the full-chain program: {err}"))?;
    vm.run()
        .map_err(|err| classify_engine_failure("vm", "full chain", &err))?;
    let vm_outcome = decode_engine_globals(
        vm.global("lex-error"),
        vm.global("tokens"),
        vm.global("result"),
        vm.heap(),
        source,
        "vm",
    )?;
    // The junction feed rides the same run: rebuild only on a
    // successful tree axis (a rejection feeds nothing forward).
    let vm_forms = match &vm_outcome.tree_axis {
        Ok(_) => rebuild_read_forms(
            vm.global("result").expect("tree ok implies result"),
            vm.heap(),
            source,
        )?,
        Err(_) => None,
    };

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| classify_engine_failure("eval", "full chain", &err))?;
    let eval_outcome = decode_engine_globals(
        evaluator.global("lex-error"),
        evaluator.global("tokens"),
        evaluator.global("result"),
        evaluator.heap(),
        source,
        "eval",
    )?;
    Ok(((vm_outcome, vm_forms), Some(eval_outcome)))
}

/// Run the assembled full chain on the VM only — the bracket face
/// for sources past the evaluator's envelope (the own-source fixed
/// point of `lexer.krf`), with the bracket disclosed by the caller.
/// Returns the outcome plus the rebuilt forms (the 2.4 junction
/// feed — `None` on a rejection).
fn drive_full_vm(
    assembled: &str,
    source: &str,
) -> Result<(ChainOutcome, Option<Vec<SyntaxObject>>), String> {
    let mut session = Session::new();
    let program =
        pipeline::parse(&mut session, "lexer-parity-host.krf", assembled).map_err(|diags| {
            format!("harness defect: the assembled full-chain program failed to parse: {diags:?}")
        })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled full-chain program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled full-chain program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the full-chain program: {err}"))?;
    vm.run()
        .map_err(|err| classify_engine_failure("vm", "full chain", &err))?;
    let vm_outcome = decode_engine_globals(
        vm.global("lex-error"),
        vm.global("tokens"),
        vm.global("result"),
        vm.heap(),
        source,
        "vm",
    )?;
    let vm_forms = match &vm_outcome.tree_axis {
        Ok(_) => rebuild_read_forms(
            vm.global("result").expect("tree ok implies result"),
            vm.heap(),
            source,
        )?,
        Err(_) => None,
    };
    Ok((vm_outcome, vm_forms))
}

// ---------------------------------------------------------------------------
// The case driver
// ---------------------------------------------------------------------------

/// The outcome of one full-chain parity case.
#[derive(Debug, Clone)]
pub struct FullChainReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// The oracle's token-axis dump, or its rendered `ReadError` key.
    pub oracle_tokens: String,
    /// The `.krf` chain's token-axis form (`None` on a harness
    /// defect or budget limit).
    pub krf_tokens: Option<String>,
    /// The oracle's tree-axis dump, or its rendered `ReadError` key.
    pub oracle_tree: String,
    /// The `.krf` chain's tree-axis form.
    pub krf_tree: Option<String>,
    /// Both engines agreed on both axes (trivially true for the
    /// VM-only bracket face).
    pub engines_agree: bool,
    /// Oracle and `.krf` chain agree on both axes.
    pub matched: bool,
    /// The mismatch description when `!matched`.
    pub drift: Option<String>,
}

impl FullChainReport {
    /// The one-line failure form (the `failure_line` lineage —
    /// corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("full-chain parity FAIL [{}]: {}", self.case, d),
            None => format!("full-chain parity PASS [{}]", self.case),
        }
    }
}

/// Run one full-chain parity case (dual engines): oracle read on
/// both faces, `.krf` chain on both engines, three-axis comparison.
pub fn reader_parity_full(case: &str, source: &str) -> FullChainReport {
    reader_parity_full_impl(case, source, LEXER_SOURCE, true).0
}

/// The tamper face: run with a modified lexer source (the drift
/// detector's probe entry).
pub fn reader_parity_full_with(case: &str, source: &str, lexer_source: &str) -> FullChainReport {
    reader_parity_full_impl(case, source, lexer_source, true).0
}

/// The VM-only bracket face for sources past the evaluator envelope.
pub fn reader_parity_full_vm(case: &str, source: &str) -> FullChainReport {
    reader_parity_full_impl(case, source, LEXER_SOURCE, false).0
}

/// The tamper face of the junction feed (the tampered-lexer probe
/// of the full composed chain — junction 1's detection arm). The
/// plain dual face rides this entry with the canonical source; the
/// VM-bracket face rides [`reader_parity_full_feed_vm`].
pub fn reader_parity_full_with_feed(
    case: &str,
    source: &str,
    lexer_source: &str,
) -> (FullChainReport, Option<Vec<SyntaxObject>>) {
    reader_parity_full_impl(case, source, lexer_source, true)
}

/// The VM-bracket face of the junction feed (sources past the
/// evaluator's read-chain envelope — the bracket rides the report,
/// disclosed).
pub fn reader_parity_full_feed_vm(
    case: &str,
    source: &str,
) -> (FullChainReport, Option<Vec<SyntaxObject>>) {
    reader_parity_full_impl(case, source, LEXER_SOURCE, false)
}

fn reader_parity_full_impl(
    case: &str,
    source: &str,
    lexer_source: &str,
    dual: bool,
) -> (FullChainReport, Option<Vec<SyntaxObject>>) {
    let assembled = format!(
        "{}{}\n{}",
        byte_table_prefix(source),
        lexer_source,
        READER_SOURCE
    );
    // The oracle side: both faces.
    let oracle_tokens = match oracle_token_dump(source) {
        Ok(d) => d,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let oracle_tree = match read_program(FileId(0), source) {
        Ok(forms) => oracle_dump(&forms),
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    // The .krf side.
    let run = if dual {
        drive_full_dual(&assembled, source).map(|((vm, forms), ev)| ((vm, ev), forms))
    } else {
        drive_full_vm(&assembled, source).map(|(vm, forms)| ((vm, None), forms))
    };
    let ((vm_outcome, eval_outcome), krf_forms) = match run {
        Ok(pair) => pair,
        Err(drift) => {
            return (
                FullChainReport {
                    case: case.to_string(),
                    oracle_tokens,
                    krf_tokens: None,
                    oracle_tree,
                    krf_tree: None,
                    engines_agree: false,
                    matched: false,
                    drift: Some(drift),
                },
                None,
            );
        }
    };
    let engines_agree = match &eval_outcome {
        Some(ev) => ev == &vm_outcome,
        None => true, // the VM-only bracket face
    };
    let axis_form = |axis: &Axis| match axis {
        Ok(d) => d.clone(),
        Err(key) => format!("ERR {key}"),
    };
    let krf_tokens_form = axis_form(&vm_outcome.token_axis);
    let krf_tree_form = axis_form(&vm_outcome.tree_axis);
    let mut drift = None;
    if krf_tokens_form != oracle_tokens {
        drift = Some(format!(
            "token axis: oracle `{}` vs krf `{}`",
            preview(&oracle_tokens),
            preview(&krf_tokens_form)
        ));
    } else if krf_tree_form != oracle_tree {
        drift = Some(format!(
            "tree axis: oracle `{}` vs krf `{}`",
            preview(&oracle_tree),
            preview(&krf_tree_form)
        ));
    }
    let matched = drift.is_none();
    (
        FullChainReport {
            case: case.to_string(),
            oracle_tokens,
            krf_tokens: vm_outcome.token_axis.clone().ok(),
            oracle_tree,
            krf_tree: vm_outcome.tree_axis.clone().ok(),
            engines_agree,
            matched,
            drift,
        },
        krf_forms,
    )
}

/// A one-line preview of a dump for drift messages (first line,
/// truncated).
fn preview(dump: &str) -> String {
    let first = dump.lines().next().unwrap_or("");
    let mut out = String::new();
    for (i, ch) in first.char_indices() {
        if i >= 72 {
            out.push('…');
            break;
        }
        out.push(ch);
    }
    out
}

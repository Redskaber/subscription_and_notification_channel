//! kerf-driver — the compiler entry point / pipeline orchestration
//! (Layer 8, stage-0-plan row 0.8; TD-003 final resolution step).
//!
//! Charter: read -> expand -> {compile -> VM, eval} pipeline assembly,
//! session/file interning, the diagnostics rendering closure (TD-001
//! payoff — line/column derived at render time), and the CLI/REPL
//! surface. Stages interact through data contracts only (SOP §11);
//! errors are data (§12.2): every stage failure becomes a
//! [`Diagnostic`] and is rendered in one pass.
//!
//! Layout: `session` (file interning), `line_index` (the TD-001
//! byte-offset -> line/column derivation), `diagnostic` (the §8.7
//! structure, Stage 0 slice), `render` (rustc-flavored rendering),
//! `pipeline` (dual-engine orchestration), `parity` (the Stage
//! 1.4 acceptance-corpus contract), `repl` (session-replay
//! state machine), `cli` (the `kerf` binary face). The executable
//! entry is `src/main.rs` (bin name `kerf`).

mod cli;
mod compiler_parity;
mod composed_full_chain;
mod diagnostic;
mod expander_parity;
mod fixpoint;
mod lexer_parity;
mod line_index;
mod parity;
mod pipeline;
mod reader_parity;
mod render;
mod repl;
mod session;
mod target_corpus;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use cli::{Command, parse_args, run_cli, usage, version};
pub use compiler_parity::{
    COMPILER_SOURCE, CompilerParityLayer, CompilerParityReport, compiler_parity,
    compiler_parity_items, compiler_parity_items_vm, compiler_parity_with, composed_chain_parity,
    composed_chain_parity_with, items_stream_prefix, krf_compile_rich, krf_compile_rich_vm,
    oracle_analysis_dump, rebuild_bytecode,
};
pub use composed_full_chain::{
    ComposedFullChainReport, ComposedLayer, composed_full_chain_parity,
    composed_full_chain_parity_vm, composed_full_chain_probes, dump_faithfulness_witness,
};
pub use diagnostic::{Diagnostic, DiagnosticCode, Severity};
pub use expander_parity::{
    EXPANDER_SOURCE, ExpanderParityLayer, ExpanderParityReport, MACRO_SOURCE,
    assembled_expander_source, expander_parity, expander_parity_with, forms_stream_prefix,
    gate_b_bytecode, oracle_dump_items, reconstruct_expand_error,
};
pub use fixpoint::{
    FixpointReport, SemanticDigest, SemanticProtoDigest, fixpoint_selfhost_compiler,
    fixpoint_selfhost_compiler_target, gate_b_elevated, gate_b_transitivity_target,
    semantic_projection,
};
pub use lexer_parity::{
    FullChainReport, LEXER_SOURCE, assemble_full_chain, byte_table_prefix, oracle_token_dump,
    reader_parity_full, reader_parity_full_vm, reader_parity_full_with,
};
pub use line_index::LineIndex;
pub use parity::{
    CorpusCase, EquivalenceReport, Expectation, Observed, parse_directive, validate, validate_all,
};
pub use pipeline::{
    CheckOutcome, EmitCOutcome, Engine, ParityReport, ParsedProgram, ReaderFace, RunOutcome,
    check_source, emit_c_source, parse, parse_target, run_parity_source, run_source,
};
pub use reader_parity::{
    ParityLayer, READER_SOURCE, ReaderParityReport, oracle_dump, reader_parity, reader_parity_with,
    reconstruct_error, token_table_prefix,
};
pub use render::{column_of, render_diagnostics};
pub use repl::{Repl, ReplEvent};
pub use session::Session;
pub use target_corpus::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, LEXER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    READER_TARGET_SOURCE, assembled_expander_target_source, ktf_compile_rich, ktf_compile_rich_vm,
    read_target_source_for_bootstrap, target_byte_table_prefix, target_forms_stream_prefix,
    target_items_stream_prefix, target_token_table_prefix,
};

// Since v0.28.0 coordinate types are imported directly from kerf-span
// (the no-forwarding rule, stage0.md §9.59; SOP §18.5 v15.2).

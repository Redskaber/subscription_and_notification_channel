//! The `kerf` binary entry (thin shell — all logic lives in the
//! library so it stays unit-testable; SOP §2.1.1-7 single-direction
//! flow).

use std::io::{IsTerminal, Read};

use kerf_driver::{Command, parse_args, run_cli};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();

    // Piped stdin feeds `run`'s read-line calls (read fully upfront —
    // a deterministic input tape). Only the `run` command consumes
    // stdin this way: `repl` reads its submissions line by line, and
    // a terminal is never consumed.
    let input_lines = match parse_args(&args) {
        Ok(Command::Run { .. }) if !std::io::stdin().is_terminal() => {
            let mut buf = String::new();
            let _ = std::io::stdin().read_to_string(&mut buf);
            buf.lines().map(|l| l.to_owned()).collect()
        }
        _ => Vec::new(),
    };

    let read_file = |path: &str| std::fs::read_to_string(path);
    let mut repl_input = || {
        let mut line = String::new();
        match std::io::stdin().read_line(&mut line) {
            Ok(0) => None,
            Ok(_) => Some(line.trim_end_matches(['\n', '\r']).to_owned()),
            Err(_) => None,
        }
    };

    let code = run_cli(
        &args,
        &read_file,
        &mut repl_input,
        input_lines,
        &mut std::io::stdout().lock(),
        &mut std::io::stderr().lock(),
    );
    std::process::exit(code);
}

//! Stage 2.4, fixpoint B — the full composed chain (§9.87; the 2.4
//! window of `docs/develop/v2/stage-2-plan.md` §2, single source):
//! the 2.4 formula verified as ONE chain, front end to back end,
//!
//! ```text
//! compile(expand(read(lex(S))))
//!   == compile_krf(expand_krf(read_krf(lex_krf(S))))
//! ```
//!
//! Three staged junctions, each a differential gate (the r84 CP9
//! spine generalized; the front end is now the `.krf` chain's OWN
//! products at every junction — never the oracle's intermediates):
//!
//! * **Junction 1 — the read chain (r85)**: byte table →
//!   `lexer.krf` + `reader.krf` on both engines; the `.krf` reader's
//!   forms rebuild and feed FORWARD (the expander consumes THESE
//!   forms, not the oracle's re-encoded ones). Gates: engines agree,
//!   and token/tree/error axes match the oracle reader.
//! * **Junction 2 — the expansion layer (1.6)**: the `.krf` expander
//!   on those forms, both engines; the rebuilt items feed forward.
//!   Gates: engines agree; on the tree axis the items are
//!   structurally identical to the oracle's expansion of the
//!   oracle's forms (the 1.6 criterion, `ModuleItem: PartialEq`); on
//!   the error axis the parity keys match.
//! * **Junction 3 — the compile layer (2.2/2.3)**: the `.krf`
//!   compiler on those items, both engines; the product faces the
//!   oracle full pipeline through the CP dump grammar (code, dbg,
//!   captures, globals, consts — the seven-field proto product).
//!   Gates: engines agree, products match, and the oracle face of
//!   the report equals the oracle FULL pipeline's compile (CP9's
//!   final face).
//!
//! The routing is TOTAL — the drift ledger (§9.87.4): a source the
//! oracle rejects at the reader layer verifies on junction 1's error
//! axis (junctions 2/3 are vacuous: no tree exists to feed them); an
//! expander/loader rejection verifies on junction 2's error axis; a
//! compile rejection rides junction 3's error axis. Every corpus
//! file lands in exactly one layer — the counts are pinned by the
//! sweep tests, so corpus growth forces the ledger to move with it.
//!
//! Engine brackets (the r74/r85 K165-K167 discipline): junction 1's
//! evaluator envelope is finite; sources past it ride the VM-only
//! bracket face ([`composed_full_chain_parity_vm`]) with the bracket
//! disclosed — the selfhost own-sources are the canonical cases.

use kerf_compiler::{Bytecode, Instr, Opcode, compile_program};
use kerf_reader::read_program;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

use crate::compiler_parity::{
    compiler_parity_items, compiler_parity_items_with, cp_error_key, oracle_analysis_dump,
};
use crate::expander_parity::{
    assembled_expander_source, forms_stream_prefix, oracle_expansion, run_dual_rich,
};
use crate::lexer_parity::{LEXER_SOURCE, reader_parity_full_feed_vm, reader_parity_full_with_feed};

/// Which junction decided the case (the drift ledger's routing key).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComposedLayer {
    /// The read chain (lexer + reader): a reader-layer rejection, or
    /// a junction-1 drift. Downstream junctions are vacuous.
    Read,
    /// The expansion layer: an expander/loader rejection verified on
    /// the error axis, or a junction-2 drift.
    Expand,
    /// The compile layer: products or compile-error keys, or a
    /// junction-3 drift.
    Compile,
}

/// The outcome of one full-composed-chain case.
#[derive(Debug, Clone)]
pub struct ComposedFullChainReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// The junction that decided the case.
    pub layer: ComposedLayer,
    /// Junction 1 (the read chain, the r85 face): matched.
    pub read_matched: bool,
    /// Junction 2 (the expansion layer): `Some(matched)` when the
    /// chain fed it (vacuous — `None` — on a read-layer rejection).
    pub expand_matched: Option<bool>,
    /// Junction 3 (the compile layer): `Some(matched)` when the
    /// chain fed it.
    pub compile_matched: Option<bool>,
    /// Both engines agreed at every junction reached (trivially true
    /// for the VM-bracket face's read junction).
    pub engines_agree: bool,
    /// The whole chain matched (all reached junctions).
    pub matched: bool,
    /// The mismatch description when `!matched` — names the failing
    /// junction, never a bare product diff.
    pub drift: Option<String>,
}

impl ComposedFullChainReport {
    /// The one-line failure form (the `failure_line` lineage —
    /// corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("composed full chain FAIL [{}]: {}", self.case, d),
            None => format!("composed full chain PASS [{}]", self.case),
        }
    }
}

/// The plain face (dual engines at every junction).
pub fn composed_full_chain_parity(case: &str, source: &str) -> ComposedFullChainReport {
    composed_full_chain_impl(case, source, LEXER_SOURCE, None, None, true)
}

/// The VM-bracket face: junction 1 rides the VM alone (sources past
/// the evaluator's read-chain envelope — the r85 bracket lineage);
/// junctions 2/3 stay dual.
pub fn composed_full_chain_parity_vm(case: &str, source: &str) -> ComposedFullChainReport {
    composed_full_chain_impl(case, source, LEXER_SOURCE, None, None, false)
}

/// The tamper face — one or more stage sources replaced to prove the
/// chain DETECTS divergence at every junction (a chain that cannot
/// fail is not a chain; the FP8 lineage composed). `None` rides the
/// canonical selfhost source.
pub fn composed_full_chain_probes(
    case: &str,
    source: &str,
    lexer_source: Option<&str>,
    expander_source: Option<&str>,
    compiler_source: Option<&str>,
) -> ComposedFullChainReport {
    let lexer = lexer_source.unwrap_or(LEXER_SOURCE);
    composed_full_chain_impl(
        case,
        source,
        lexer,
        expander_source,
        compiler_source,
        // The tamper faces ride the dual bracket (small probe
        // sources — the brackets are a corpus-scale concern).
        true,
    )
}

fn composed_full_chain_impl(
    case: &str,
    source: &str,
    lexer_source: &str,
    expander_source: Option<&str>,
    compiler_source: Option<&str>,
    read_dual: bool,
) -> ComposedFullChainReport {
    // ---- Junction 1: the read chain — the .krf forms feed forward.
    let (read_report, krf_forms) = if read_dual {
        reader_parity_full_with_feed(case, source, lexer_source)
    } else {
        reader_parity_full_feed_vm(case, source)
    };
    // The oracle routing: which layer owns this source's verdict?
    let oracle_forms = read_program(FileId(0), source);
    if !read_report.matched || !read_report.engines_agree {
        // A junction-1 drift or harness classification (defect /
        // limit) — the chain names it and never feeds forward.
        return ComposedFullChainReport {
            case: case.to_string(),
            layer: ComposedLayer::Read,
            read_matched: false,
            expand_matched: None,
            compile_matched: None,
            engines_agree: read_report.engines_agree,
            matched: false,
            drift: read_report.drift,
        };
    }
    let oracle_forms = match oracle_forms {
        Err(_) => {
            // The oracle reader rejects: the matched read chain
            // already proved the .krf chain rejects with the same
            // key (the r85 error axis is part of `matched`), and a
            // matched chain with an oracle rejection produced no
            // forms. The ledger's Read row.
            let vacuously_clean = krf_forms.is_none();
            let drift = if vacuously_clean {
                None
            } else {
                Some(
                    "junction 1: the oracle reader rejected but the .krf chain produced forms"
                        .to_string(),
                )
            };
            return ComposedFullChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Read,
                read_matched: true,
                expand_matched: None,
                compile_matched: None,
                engines_agree: true,
                matched: vacuously_clean,
                drift,
            };
        }
        Ok(forms) => forms,
    };
    // A matched read chain over an oracle-readable source must have
    // produced forms (the feed's own invariant — a harness defect
    // otherwise).
    let krf_forms = krf_forms.unwrap_or_else(|| {
        // Unreachable in a consistent harness: matched implies the
        // tree axis is Ok, which implies forms. Treated as a defect,
        // never a silent pass.
        panic!("harness defect: junction 1 matched but produced no forms for {case}");
    });

    // ---- Junction 2: the expansion layer — the .krf expander on
    // the .krf reader's own forms, both engines.
    let expander = expander_source
        .map(|s| s.to_string())
        .unwrap_or_else(assembled_expander_source);
    let prefix = forms_stream_prefix(&krf_forms);
    let assembled = format!("{prefix}\n{expander}");
    let (rebuilt, vm_verdict, eval_verdict) = match run_dual_rich(&assembled) {
        Ok(run) => run,
        Err(harness) => {
            // The r74 classification rides the string itself
            // ("harness defect: …" / "harness limit: …").
            return ComposedFullChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Expand,
                read_matched: true,
                expand_matched: Some(false),
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(harness),
            };
        }
    };
    if vm_verdict != eval_verdict {
        return ComposedFullChainReport {
            case: case.to_string(),
            layer: ComposedLayer::Expand,
            read_matched: true,
            expand_matched: Some(false),
            compile_matched: None,
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "junction 2: engines disagree: vm `{}` vs eval `{}`",
                vm_verdict.text(),
                eval_verdict.text()
            )),
        };
    }
    // The oracle's own expansion of the oracle's forms — the
    // differential at this junction.
    match oracle_expansion(&oracle_forms) {
        Err(oracle_key) => {
            // The ledger's Expand row: the .krf expander must reject
            // with the same parity key (shape included — the text
            // comparison pairs Error with Error).
            let krf_text = vm_verdict.text();
            let matched = krf_text == oracle_key && rebuilt.is_none();
            let drift = if matched {
                None
            } else {
                Some(format!(
                    "junction 2: oracle `{oracle_key}` vs krf `{krf_text}`"
                ))
            };
            ComposedFullChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Expand,
                read_matched: true,
                expand_matched: Some(matched),
                compile_matched: None,
                engines_agree: true,
                matched,
                drift,
            }
        }
        Ok(oracle_items) => {
            // The tree identity gate (the 1.6 criterion in-chain —
            // CP9's spine): the .krf expander's items on the .krf
            // forms equal the oracle's items on the oracle's forms.
            let Some(items) = rebuilt else {
                return ComposedFullChainReport {
                    case: case.to_string(),
                    layer: ComposedLayer::Expand,
                    read_matched: true,
                    expand_matched: Some(false),
                    compile_matched: None,
                    engines_agree: true,
                    matched: false,
                    drift: Some(format!(
                        "junction 2: the oracle expanded but the .krf expander rejected: {}",
                        vm_verdict.text()
                    )),
                };
            };
            if items != oracle_items {
                return ComposedFullChainReport {
                    case: case.to_string(),
                    layer: ComposedLayer::Expand,
                    read_matched: true,
                    expand_matched: Some(false),
                    compile_matched: None,
                    engines_agree: true,
                    matched: false,
                    drift: Some(
                        "junction 2: tree drift between the .krf expander and the oracle"
                            .to_string(),
                    ),
                };
            }
            // ---- Junction 3: the compile layer — the .krf compiler
            // on the .krf expander's own items.
            let report = match compiler_source {
                Some(src) => compiler_parity_items_with(case, &items, src),
                None => compiler_parity_items(case, &items),
            };
            // The oracle full pipeline's compile of the oracle's own
            // items (CP9's final face — the report's oracle half
            // compiled the .krf tree, which junction 2 just proved
            // identical, so both faces must agree).
            let oracle_full_text = match compile_program(&oracle_items) {
                Ok(bc) => oracle_analysis_dump(&bc),
                Err(err) => cp_error_key(&err),
            };
            let compile_matched =
                report.engines_agree && report.matched && report.oracle == oracle_full_text;
            let drift = if compile_matched {
                None
            } else {
                Some(report.failure_line())
            };
            ComposedFullChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Compile,
                read_matched: true,
                expand_matched: Some(true),
                compile_matched: Some(compile_matched),
                engines_agree: report.engines_agree,
                matched: compile_matched,
                drift,
            }
        }
    }
}

/// The gate-B promotion witness (§9.87.5, the 2.4 evaluation slot):
/// the analysis-dump grammar must be a FAITHFUL image of the
/// `Bytecode` semantics — every field mutation visible in the dump.
/// With the witness holding, dump equality implies bytecode equality,
/// which is the precondition `stage-2-plan` §2 row 2.5 registers for
/// the gate-B full-pipeline dual-track (the `.krf` compiler product
/// as one side of gate B's axis (a)).
///
/// The verdict names the FIRST field whose mutation the dump failed
/// to surface (fail-closed — never a silent pass).
pub fn dump_faithfulness_witness(bc: &Bytecode) -> Result<(), String> {
    let baseline = oracle_analysis_dump(bc);
    let mut probes: Vec<(String, String)> = Vec::new(); // (field, mutated dump)
    let mut mutated = bc.clone();
    // funcs[0].name — nil vs a name (and back) flips the dump.
    if let Some(first) = mutated.funcs.first_mut() {
        let flipped = match first.name {
            Some(_) => None,
            None => Some(Symbol::new("witness").expect("a valid witness name")),
        };
        first.name = flipped;
    }
    probes.push(("funcs[0].name".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    // captures: flip emptiness both ways — clear when present, add
    // one descriptor when empty (either direction must surface).
    if let Some(first) = mutated.funcs.first_mut() {
        if first.captures.is_empty() {
            first.captures.push(kerf_compiler::CaptureSource::Local(0));
        } else {
            first.captures.clear();
        }
    }
    probes.push(("funcs[0].captures".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.params = first.params.wrapping_add(1);
    }
    probes.push(("funcs[0].params".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.n_locals = first.n_locals.wrapping_add(1);
    }
    probes.push(("funcs[0].n_locals".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        // Any appended instruction changes the rendered sequence —
        // `Ret` with zero operands is the canonical witness.
        first.code.push(Instr::new(Opcode::Ret));
    }
    probes.push(("funcs[0].code".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        let span = first.debug_info.first().copied().unwrap_or(Span {
            file_id: FileId(0),
            start: ByteOffset(0),
            end: ByteOffset(1),
            expansion_id: ExpansionId::ROOT,
        });
        first.debug_info.clear();
        first.debug_info.push(span);
        first.debug_info.push(span);
    }
    probes.push(("funcs[0].debug_info".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    mutated.funcs.clear();
    probes.push(("funcs (dropped)".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if !mutated.globals.is_empty() {
        mutated.globals.clear();
        probes.push(("globals".into(), oracle_analysis_dump(&mutated)));
    }

    mutated = bc.clone();
    if !mutated.consts.is_empty() {
        mutated.consts.clear();
        probes.push(("consts".into(), oracle_analysis_dump(&mutated)));
    }

    for (field, dump) in probes {
        if dump == baseline {
            return Err(format!(
                "the dump grammar lost a semantic field: mutating `{field}` changed nothing"
            ));
        }
    }
    Ok(())
}

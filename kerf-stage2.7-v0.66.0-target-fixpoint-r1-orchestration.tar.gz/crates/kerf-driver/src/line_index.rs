//! Line/column derivation from byte offsets — the TD-001 payoff.
//!
//! docs/stage0.md §12.1: spans store byte offsets only; line and
//! column are *derived at diagnostic render time*, never stored — a
//! single source of truth (SOP §2.3-2) with zero double-storage
//! drift. This module is that render-time derivation.
//!
//! Conventions (rustc-flavored):
//! - lines are 1-based in the public API; the index stores 0-based
//!   line starts;
//! - columns are 1-based **character** counts, not byte counts — a
//!   CJK source must point at the column a terminal actually shows;
//! - an offset landing inside a multi-byte character floors to the
//!   character boundary (deterministic clamping, never a panic —
//!   renderer inputs come from error payloads, and a renderer must
//!   not crash on a malformed payload);
//! - an offset past end-of-input clamps to the last line;
//! - `line_bounds` returns `(start, end)` where `end` excludes the
//!   `\n`; a `\r` just before it belongs to the separator and is
//!   trimmed from excerpts by the renderer.

/// Byte-offset → (line, column) derivation over one source text.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LineIndex {
    /// Byte offset where each 0-based line starts (`[0]` is always 0).
    line_starts: Vec<u32>,
    /// Total source length in bytes.
    len: u32,
}

impl LineIndex {
    /// Build the index for `source` (one pass, `\n`-separated lines).
    pub fn new(source: &str) -> Self {
        let mut line_starts = vec![0u32];
        for (i, b) in source.bytes().enumerate() {
            if b == b'\n' {
                line_starts.push(i as u32 + 1);
            }
        }
        LineIndex {
            line_starts,
            len: source.len() as u32,
        }
    }

    /// Number of lines (an empty source has one line — offsets must
    /// still resolve).
    pub fn line_count(&self) -> usize {
        self.line_starts.len()
    }

    /// The 0-based line containing `offset`. Offsets past the end
    /// clamp to the last line; offset 0 is always line 0.
    pub fn line_of(&self, offset: u32) -> usize {
        let clamped = offset.min(self.len);
        match self.line_starts.binary_search(&clamped) {
            Ok(line) => line,
            Err(next) => next - 1,
        }
    }

    /// `(start, end)` byte bounds of a 0-based line: `end` excludes
    /// the `\n` separator. `None` when `line` is out of range
    /// (fail-closed — no fabricated empty line).
    pub fn line_bounds(&self, line: usize) -> Option<(u32, u32)> {
        if line >= self.line_starts.len() {
            return None;
        }
        let start = self.line_starts[line];
        let end = if line + 1 < self.line_starts.len() {
            self.line_starts[line + 1] - 1 // drop the `\n`
        } else {
            self.len
        };
        Some((start, end))
    }

    /// `(line, column)` for a byte offset, both 1-based. The column
    /// counts *characters* from the line start; an offset inside a
    /// multi-byte character floors to that character's boundary
    /// (deterministic, never a panic). Offsets past end-of-input
    /// clamp to the last line.
    pub fn to_line_col(&self, source: &str, offset: u32) -> (usize, usize) {
        let line = self.line_of(offset);
        let (start, _) = self
            .line_bounds(line)
            .expect("line_of only returns in-range lines");
        let from = (start.min(self.len)) as usize;
        let mut at = (offset.min(self.len)) as usize;
        // Floor to a char boundary (the renderer must survive any
        // payload; a mid-character offset is a payload defect, not a
        // crash license — SOP §2.3-3 deterministic boundary).
        while at > from && !source.is_char_boundary(at) {
            at -= 1;
        }
        let col = source[from..at].chars().count() + 1;
        (line + 1, col)
    }
}

#[cfg(test)]
mod tests {
    //! LineIndex tests (FP2): TD-001 derivation semantics — basic
    //! lines, boundaries, clamping, CJK character columns, CRLF.
    //!
    //! CJK fixtures are registered whitelist items (SOP §10.5 —
    //! CJK-as-test-target exemption, dual-registered here and in
    //! docs/tests/v0/stage0/plan/driver.md §2/§5).

    use super::*;

    #[test]
    fn empty_source_has_one_line_and_resolves_offset_zero() {
        let idx = LineIndex::new("");
        assert_eq!(idx.line_count(), 1);
        assert_eq!(idx.to_line_col("", 0), (1, 1));
        assert_eq!(idx.line_bounds(0), Some((0, 0)));
    }

    #[test]
    fn single_line_without_newline() {
        let src = "(+ 1 2)";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 1);
        assert_eq!(idx.to_line_col(src, 0), (1, 1));
        assert_eq!(idx.to_line_col(src, 4), (1, 5));
        // Past end clamps to the last line; 7 characters -> column 8.
        assert_eq!(idx.to_line_col(src, 100), (1, 8));
    }

    #[test]
    fn multi_line_basic_derivation() {
        // Line 1 is 12 bytes + `\n` at 12; line 2 starts at 13 and is
        // 7 bytes + `\n` at 20; line 3 starts at 21.
        let src = "(define x 1)\n(+ x 2)\n(* x 3)";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 3);
        assert_eq!(idx.to_line_col(src, 0), (1, 1));
        assert_eq!(idx.to_line_col(src, 13), (2, 1));
        assert_eq!(idx.to_line_col(src, 14), (2, 2));
        assert_eq!(idx.to_line_col(src, 20), (2, 8));
        assert_eq!(idx.to_line_col(src, 21), (3, 1));
    }

    #[test]
    fn offset_on_newline_belongs_to_the_earlier_line() {
        // The `\n` at byte 12 terminates line 1; the offset of the
        // separator itself still points into line 1 (column 13).
        let src = "(define x 1)\n(+ x 2)";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_of(12), 0);
        assert_eq!(idx.to_line_col(src, 12), (1, 13));
        assert_eq!(idx.line_of(13), 1);
    }

    #[test]
    fn lone_newline_yields_two_empty_lines() {
        let idx = LineIndex::new("\n");
        assert_eq!(idx.line_count(), 2);
        assert_eq!(idx.line_bounds(0), Some((0, 0)));
        assert_eq!(idx.line_bounds(1), Some((1, 1)));
        assert_eq!(idx.to_line_col("\n", 0), (1, 1));
        assert_eq!(idx.to_line_col("\n", 1), (2, 1));
    }

    #[test]
    fn cjk_source_reports_character_columns() {
        // Registered CJK fixture. Each char is 3 bytes: line 1 is 9
        // bytes + `\n` at 9; line 2 starts at byte 10.
        let src = "一二三\n四五六";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 2);
        // Byte 10 = 四 (column 1); byte 13 = 五 (column 2); byte 19
        // is past 六 (columns count characters, not bytes).
        assert_eq!(idx.to_line_col(src, 10), (2, 1));
        assert_eq!(idx.to_line_col(src, 13), (2, 2));
        assert_eq!(idx.to_line_col(src, 19), (2, 4));
    }

    #[test]
    fn mid_character_offset_floors_to_boundary() {
        let src = "四";
        let idx = LineIndex::new(src);
        // Bytes 1 and 2 are inside 四; all floor to column 1.
        assert_eq!(idx.to_line_col(src, 1), (1, 1));
        assert_eq!(idx.to_line_col(src, 2), (1, 1));
        // End of the character = column 2.
        assert_eq!(idx.to_line_col(src, 3), (1, 2));
    }

    #[test]
    fn offset_past_end_clamps_to_last_line() {
        let src = "a\nb";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_of(9999), 1);
        assert_eq!(idx.to_line_col(src, 9999), (2, 2));
    }

    #[test]
    fn crlf_line_bounds_stop_at_the_newline() {
        // `line_bounds` excludes only the `\n` (offsets must resolve
        // against the raw byte range); the trailing `\r` stays inside
        // the bounds and the *renderer* trims it from excerpts.
        let src = "abc\r\ndef";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 2);
        let (start, end) = idx.line_bounds(0).expect("line 0 exists");
        assert_eq!((start, end), (0, 4), "only the `\\n` is excluded");
        assert_eq!(&src[start as usize..end as usize], "abc\r");
        // The renderer-facing excerpt contract trims the `\r`.
        assert_eq!(
            src[start as usize..end as usize].trim_end_matches('\r'),
            "abc"
        );
    }

    #[test]
    fn out_of_range_line_bounds_fail_closed() {
        let idx = LineIndex::new("x");
        assert_eq!(idx.line_bounds(1), None);
        assert_eq!(idx.line_bounds(999), None);
    }

    #[test]
    fn trailing_newline_yields_a_final_empty_line() {
        let src = "x\n";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 2);
        assert_eq!(idx.line_bounds(1), Some((2, 2)));
        assert_eq!(idx.to_line_col(src, 2), (2, 1));
    }

    #[test]
    fn line_of_is_monotonic_across_the_full_range() {
        let src = "aa\nbb\ncc";
        let idx = LineIndex::new(src);
        let mut last = 0;
        for off in 0..=src.len() as u32 {
            let line = idx.line_of(off);
            assert!(line >= last, "line_of must be monotonic at {off}");
            last = line;
        }
    }

    #[test]
    fn many_lines_count_and_last_bounds() {
        // Nine 2-byte lines ("N\n"), one 3-byte line ("10\n"), then
        // the final 2-byte line "11" starting at byte 21.
        let src = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11";
        let idx = LineIndex::new(src);
        assert_eq!(idx.line_count(), 11);
        assert_eq!(idx.line_bounds(10), Some((21, 23)));
    }
}

//! Diagnostic rendering — rustc-flavored, multi-error, deterministic.
//!
//! §12.2: diagnostics are collected, then rendered in one pass. The
//! output shape (all texts R8 English, lowercase, no trailing
//! periods; §9.56 DIAG-1 — stage messages carry no position
//! fragments, the location line below is the single position
//! render):
//!
//! ```text
//! error[kerf-read]: unexpected closing delimiter `)`
//!   --> bad.krf:2:4
//!    |
//!  2 | (+ 1 2))
//!    |        ^
//! ```
//!
//! - the caret run covers the primary span (an empty span gets a
//!   single `^`); a span crossing lines clamps to its first line;
//! - a position-less diagnostic renders without `-->` and without an
//!   excerpt (no DUMMY locations);
//! - several diagnostics are separated by a blank line and, when
//!   more than one, followed by a rustc-style summary line;
//! - the line-number gutter widens with the largest rendered line
//!   number.

use kerf_span::ByteOffset;

use crate::diagnostic::{Diagnostic, Severity};
use crate::line_index::LineIndex;
use crate::session::Session;

/// Render `diags` against the session's sources. An empty slice
/// renders as the empty string (nothing to report is not an event).
pub fn render_diagnostics(session: &Session, diags: &[Diagnostic]) -> String {
    let mut out = String::new();
    if diags.is_empty() {
        return out;
    }
    // Gutter width: the widest line number shown (>= 1 digit).
    let width = diags
        .iter()
        .filter_map(|d| render_position(session, d).map(|(_, line, _)| line))
        .max()
        .unwrap_or(0)
        .to_string()
        .len()
        .max(1);

    for (i, diag) in diags.iter().enumerate() {
        if i > 0 {
            out.push('\n');
        }
        out.push_str(&render_one(session, diag, width));
    }
    if diags.len() > 1 {
        // Stage 1.1: warning batches get their own summary line, and
        // the abort line only prints when errors exist (a
        // warnings-only batch must not claim an abort it never made).
        // Zero-warning batches render byte-identically to the Stage 0
        // form (the ds10 golden freeze obligation).
        let errors = diags
            .iter()
            .filter(|d| d.severity == Severity::Error)
            .count();
        let warnings = diags
            .iter()
            .filter(|d| d.severity == Severity::Warning)
            .count();
        if warnings > 0 {
            out.push_str(&format!(
                "warning: {} warning{} emitted\n",
                warnings,
                if warnings == 1 { "" } else { "s" }
            ));
        }
        if errors > 0 {
            out.push_str(&format!(
                "error: aborting due to {errors} previous error{}\n",
                if errors == 1 { "" } else { "s" }
            ));
        }
    }
    out
}

/// `(name, 1-based line, 1-based column)` when the diagnostic has a
/// renderable position; `None` otherwise (no span, or the session
/// does not know the file — rendered without a location).
fn render_position(session: &Session, diag: &Diagnostic) -> Option<(String, usize, usize)> {
    let span = diag.primary_span?;
    let source = session.source(span.file_id)?;
    let index = session.line_index(span.file_id)?;
    let (line, col) = index.to_line_col(source, span.start.0);
    let name = session.file_name(span.file_id)?.to_owned();
    Some((name, line, col))
}

/// One diagnostic block (no leading separator; ends with `\n`).
fn render_one(session: &Session, diag: &Diagnostic, width: usize) -> String {
    let mut out = format!("{}[{}]: {}\n", diag.severity, diag.code.tag(), diag.message);
    let Some(span) = diag.primary_span else {
        return out;
    };
    let (Some(source), Some(name)) = (
        session.source(span.file_id),
        session.file_name(span.file_id),
    ) else {
        // Unknown file in the span: the message is still delivered;
        // the location line is dropped rather than fabricated.
        return out;
    };
    // §9.56 DIAG-4: the session-owned cached index (built once per
    // file at intern), not a fresh per-diagnostic rebuild.
    let Some(index) = session.line_index(span.file_id) else {
        return out;
    };
    let (line, col) = index.to_line_col(source, span.start.0);
    out.push_str(&format!("{:width$}--> {name}:{line}:{col}\n", ""));
    out.push_str(&format!("{:width$} |\n", ""));
    let line_idx = line - 1;
    let Some((line_start, line_end)) = index.line_bounds(line_idx) else {
        return out;
    };
    let excerpt: String = source[line_start as usize..line_end as usize]
        .trim_end_matches('\r')
        .to_owned();
    out.push_str(&format!("{line:>width$} | {excerpt}\n"));
    // Caret run: the span's on-line portion in *characters* (a CJK
    // span of 12 bytes is 4 columns wide), clamped to this line, at
    // least one caret. An empty span gets a single `^`.
    let run_end = span.end.0.min(line_end).max(span.start.0);
    let caret_len = if run_end > span.start.0 {
        source[span.start.0 as usize..run_end as usize]
            .chars()
            .count()
    } else {
        1
    };
    let pad = " ".repeat(col - 1);
    let carets = "^".repeat(caret_len);
    out.push_str(&format!("{:width$} | {pad}{carets}\n", ""));
    out
}

/// Convenience for callers holding raw byte offsets: the number of
/// characters between the line start and `offset` (1-based column),
/// computed against `source` via a fresh [`LineIndex`].
pub fn column_of(source: &str, offset: ByteOffset) -> usize {
    LineIndex::new(source).to_line_col(source, offset.0).1
}

#[cfg(test)]
mod tests {
    //! Renderer tests (FP3): golden shapes, clamping, multi-diagnostics,
    //! gutter widths, CJK excerpts (registered CJK fixtures — see the
    //! line_index module registration note).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId, Span};

    fn setup() -> (Session, FileId) {
        let mut s = Session::new();
        let id = s.intern("main.krf", "(define (f x)\n  (+ x 1))\n(f 2)");
        (s, id)
    }

    fn span_at(file: FileId, start: u32, end: u32) -> Span {
        Span::new(file, ByteOffset(start), ByteOffset(end), ExpansionId::ROOT).expect("test span")
    }

    #[test]
    fn empty_slice_renders_empty_string() {
        let (s, _) = setup();
        assert_eq!(render_diagnostics(&s, &[]), "");
    }

    #[test]
    fn single_diagnostic_golden_shape() {
        let (s, id) = setup();
        // `(f 2)` = line 3 (bytes 25..29), whole-span underline.
        let d = Diagnostic::driver_error("call failed", id, Some(span_at(id, 25, 29)));
        let out = render_diagnostics(&s, &[d]);
        let expected =
            "error[kerf-driver]: call failed\n --> main.krf:3:1\n  |\n3 | (f 2)\n  | ^^^^\n";
        assert_eq!(out, expected);
    }

    #[test]
    fn positionless_diagnostic_skips_location_and_excerpt() {
        let (s, id) = setup();
        let d = Diagnostic::driver_error("nope", id, None);
        let out = render_diagnostics(&s, &[d]);
        assert_eq!(out, "error[kerf-driver]: nope\n");
        assert!(!out.contains("-->"));
    }

    #[test]
    fn empty_span_gets_single_caret() {
        let (s, id) = setup();
        // Byte 26 = `f` inside line 3's `(f 2)` -> column 2.
        let d = Diagnostic::driver_error("point", id, Some(span_at(id, 26, 26)));
        let out = render_diagnostics(&s, &[d]);
        assert!(out.contains(" --> main.krf:3:2\n"));
        assert!(
            out.ends_with("  |  ^\n"),
            "single caret for empty span: {out}"
        );
    }

    #[test]
    fn multi_line_span_clamps_to_first_line() {
        let (s, id) = setup();
        // Line 2 = `  (+ x 1))` at bytes 14..23; a span from byte 16
        // into line 3 underlines only the line-2 remainder.
        let d = Diagnostic::driver_error("wide", id, Some(span_at(id, 16, 28)));
        let out = render_diagnostics(&s, &[d]);
        assert!(out.contains("--> main.krf:2:3"), "{out}");
        // Carets cover columns 3..=10 of line 2 (8 ASCII columns).
        let caret_line = out.lines().nth(4).expect("caret line");
        assert!(caret_line.contains("^^^^^^^^"), "clamped run: {caret_line}");
        assert!(!caret_line.contains("^^^^^^^^^"), "no leak past line 2");
    }

    #[test]
    fn multiple_diagnostics_get_separator_and_summary() {
        let (s, id) = setup();
        let d1 = Diagnostic::driver_error("first", id, Some(span_at(id, 0, 7)));
        let d2 = Diagnostic::driver_error("second", id, None);
        let out = render_diagnostics(&s, &[d1, d2]);
        assert!(out.contains("\nerror[kerf-driver]: second\n"));
        assert!(
            out.ends_with("error: aborting due to 2 previous errors\n"),
            "summary line: {out}"
        );
    }

    #[test]
    fn single_diagnostic_has_no_summary_line() {
        let (s, id) = setup();
        let d = Diagnostic::driver_error("only", id, None);
        let out = render_diagnostics(&s, &[d]);
        assert!(!out.contains("aborting due to"));
    }

    // ---- Stage 1.1: warning summaries (test doc driver-wiring.md FP4) ----

    fn typecheck_diag(
        code: kerf_typecheck::TypeCode,
        severity: kerf_typecheck::Severity,
        span: Span,
        message: &str,
    ) -> Diagnostic {
        Diagnostic::from_typecheck(&kerf_typecheck::TypeDiagnostic::new(
            code,
            severity,
            span,
            message.to_owned(),
        ))
    }

    #[test]
    fn warnings_only_batch_gets_warning_summary_without_abort_line() {
        let (s, id) = setup();
        let w1 = typecheck_diag(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span_at(id, 1, 2),
            "assignment rebinds builtin `car`",
        );
        let w2 = typecheck_diag(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span_at(id, 5, 6),
            "assignment rebinds builtin `cdr`",
        );
        let out = render_diagnostics(&s, &[w1, w2]);
        assert!(
            out.ends_with("warning: 2 warnings emitted\n"),
            "warning summary: {out}"
        );
        assert!(
            !out.contains("aborting due to"),
            "a warnings-only batch never claims an abort: {out}"
        );
        assert!(out.contains("warning[E0008]:"), "{out}");
    }

    #[test]
    fn mixed_batch_prints_warning_summary_then_abort_line() {
        let (s, id) = setup();
        let w = typecheck_diag(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span_at(id, 1, 2),
            "assignment rebinds builtin `car`",
        );
        let e = typecheck_diag(
            kerf_typecheck::TypeCode::ArityMismatch,
            kerf_typecheck::Severity::Error,
            span_at(id, 25, 29),
            "this function takes 1 argument but 2 were supplied",
        );
        let out = render_diagnostics(&s, &[w, e]);
        let warning_at = out.find("warning: 1 warning emitted\n");
        let abort_at = out.find("error: aborting due to 1 previous error\n");
        assert!(warning_at.is_some(), "{out}");
        assert!(abort_at.is_some(), "{out}");
        assert!(
            warning_at < abort_at,
            "the warning summary precedes the abort line (rustc order): {out}"
        );
    }

    #[test]
    fn zero_warning_batches_render_byte_identically_to_stage0() {
        // The ds10 freeze obligation at the unit layer: two errors,
        // zero warnings — output ends with the Stage 0 abort line and
        // contains no warning summary.
        let (s, id) = setup();
        let e1 = Diagnostic::driver_error("first", id, Some(span_at(id, 1, 2)));
        let e2 = Diagnostic::driver_error("second", id, Some(span_at(id, 25, 29)));
        let out = render_diagnostics(&s, &[e1, e2]);
        assert!(out.ends_with("error: aborting due to 2 previous errors\n"));
        assert!(!out.contains("warning"));
    }

    #[test]
    fn single_warning_has_no_summary_line() {
        // The len > 1 rule is unchanged: one warning, no summary.
        let (s, id) = setup();
        let w = typecheck_diag(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span_at(id, 1, 2),
            "assignment rebinds builtin `car`",
        );
        let out = render_diagnostics(&s, &[w]);
        assert!(out.starts_with("warning[E0008]: assignment rebinds builtin `car`\n"));
        assert!(
            !out.contains("warning:"),
            "no summary for a single warning: {out}"
        );
    }

    #[test]
    fn gutter_widens_past_line_nine() {
        let mut s = Session::new();
        let mut src = String::new();
        for i in 0..11 {
            src.push_str(&format!("(define v{i} {i})\n"));
        }
        let id = s.intern("many.krf", &src);
        // Lines v0..v9 are 14 bytes each: line 11 starts at byte 140.
        let start = 140u32;
        let d = Diagnostic::driver_error("deep", id, Some(span_at(id, start, start + 3)));
        let out = render_diagnostics(&s, &[d]);
        assert!(out.contains("--> many.krf:11:1"), "{out}");
        assert!(
            out.contains("\n11 | (define v10 10)\n"),
            "two-digit gutter: {out}"
        );
    }

    #[test]
    fn cjk_excerpt_and_character_column() {
        // Registered CJK fixture (SOP §10.5 whitelist).
        let mut s = Session::new();
        let id = s.intern("cjk.krf", "(write-line \"你好世界\")");
        // The string payload starts at byte 13 (每个 char 3 bytes).
        let d = Diagnostic::driver_error("cjk", id, Some(span_at(id, 13, 25)));
        let out = render_diagnostics(&s, &[d]);
        assert!(out.contains("--> cjk.krf:1:14"), "{out}");
        assert!(out.contains("(write-line \"你好世界\")"), "{out}");
        // Caret run: 12 bytes = 4 chars -> ^^^^ under the payload.
        assert!(
            out.lines()
                .nth(4)
                .expect("caret")
                .trim_end()
                .ends_with("^^^^"),
            "{out}"
        );
    }

    #[test]
    fn unknown_file_renders_message_without_location() {
        let (s, _) = setup();
        // A span in a file the session never interned.
        let ghost = span_at(FileId(42), 0, 3);
        let d = Diagnostic::driver_error("ghost", FileId(42), Some(ghost));
        let out = render_diagnostics(&s, &[d]);
        assert_eq!(out, "error[kerf-driver]: ghost\n");
    }

    #[test]
    fn severity_prefixes_render_per_level() {
        let (s, id) = setup();
        let mut d = Diagnostic::driver_error("w", id, None);
        d.severity = Severity::Warning;
        assert!(render_diagnostics(&s, &[d.clone()]).starts_with("warning[kerf-driver]: w\n"));
        d.severity = Severity::Note;
        assert!(render_diagnostics(&s, &[d.clone()]).starts_with("note[kerf-driver]: w\n"));
        d.severity = Severity::Help;
        assert!(render_diagnostics(&s, &[d]).starts_with("help[kerf-driver]: w\n"));
    }

    #[test]
    fn mixed_files_render_each_with_own_name() {
        let mut s = Session::new();
        let a = s.intern("a.krf", "(+ 1 2)\n");
        let b = s.intern("b.krf", "(define x 1)\n(undefined-fn)");
        let d1 = Diagnostic::driver_error("in a", a, Some(span_at(a, 0, 7)));
        // Line 2 of b starts at byte 13.
        let d2 = Diagnostic::driver_error("in b", b, Some(span_at(b, 13, 26)));
        let out = render_diagnostics(&s, &[d1, d2]);
        assert!(out.contains("--> a.krf:1:1"));
        assert!(out.contains("--> b.krf:2:1"));
    }

    #[test]
    fn column_of_counts_characters() {
        let src = "(+ 你 1)";
        assert_eq!(column_of(src, ByteOffset(0)), 1);
        // 你 occupies bytes 3..6; its column is 4 (three chars ahead).
        assert_eq!(column_of(src, ByteOffset(3)), 4);
        // A mid-character byte floors to the character start.
        assert_eq!(column_of(src, ByteOffset(4)), 4);
        // The space after 你 is column 5.
        assert_eq!(column_of(src, ByteOffset(6)), 5);
    }
}

//! kerf-syntax — the SyntaxObject model (Layer 1).
//!
//! Charter (docs/stage0.md §3.3): every piece of surface syntax carries a
//! real span (never `Option`, never a dummy — the TD-004 discipline), a
//! scope set and a phase — the hygiene foundation consumed by the reader
//! (Layer 2, plan sub-stage 0.3) and the expander (Layer 3, plan
//! sub-stage 0.4). §7.3.6 positions the datum as the "extended
//! S-expression" (skeleton + per-node enhancements — Racket's industrial
//! proof); the skeleton is the Stage 0 bootstrap-parser scaffold (SOP
//! §2.5, choice A of the six-dimension ruling), removed from the
//! bootstrap chain at Stage 2b — never a permanent internal IR.
//!
//! Naming (SOP §21.12): syntax-object family types carry the `Stx`
//! prefix (`StxDatum`); cross-stage ID types carry none (`ScopeId`,
//! `ScopeSet` — same family as `Span`/`FileId`/`Symbol`). Since v0.27.0
//! the identifier symbol is the cross-stage `kerf_span::Symbol` (the
//! single identity pool of the crate boundary review, stage0.md §9.58):
//! the pre-v0.27.0 layer-local twin `StxSymbol` and its private interner
//! are retired — the surface layer now shares one pool with the core
//! layer (the rustc `rustc_span::Symbol` precedent, §9.58 K78).

mod error;
mod expr;
mod phase;
mod scope;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use error::SyntaxError;
pub use expr::{StxDatum, SyntaxObject};
pub use phase::Phase;
pub use scope::{ScopeId, ScopeSet};

// Since v0.28.0 this crate re-exports nothing from kerf-span (the
// no-forwarding rule, stage0.md §9.59): `Span`/`ExpansionId`/`Symbol`
// still appear throughout this crate's public API, but consumers import
// them directly from kerf-span (the rustc_ast precedent, §9.59 K81;
// SOP §18.5 v15.2).

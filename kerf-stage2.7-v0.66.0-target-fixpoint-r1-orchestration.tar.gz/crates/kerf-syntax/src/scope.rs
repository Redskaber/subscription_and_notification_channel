//! Scope identifiers and scope sets — the hygiene substrate
//! (docs/stage0.md §3.3 field 3 + §9.38 scope-coloring sketch).
//!
//! A [`ScopeId`] is an opaque identifier for one scope introduced during
//! expansion (module scope, binding-form scope, macro-definition scope,
//! ...). Allocation freshness (never reusing an id within one
//! compilation) is a *consumer* discipline: the sub-stage 0.4 expander
//! context will own a monotonic allocator; this layer only guarantees
//! set semantics.
//!
//! A [`ScopeSet`] stores its members sorted and deduplicated, so
//! iteration order is deterministic (SOP §2.3-3 deterministic
//! boundaries — no HashMap iteration randomness) and equality/hash
//! follow content.

/// One scope (ID type, no `Stx` prefix — SOP §21.12-3 cross-stage ID
/// naming rule, same family as `Span`/`FileId`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ScopeId(pub u32);

/// The set of scopes attached to one syntax-object node.
///
/// The hygiene invariant (docs/stage0.md §19.2 invariant 2: the scope
/// sets of macro-introduced identifiers and user identifiers never merge
/// into one shared set) constrains how the expander *uses* sets; the
/// [`ScopeSet::union`] operation itself is the scope-coloring join the
/// algorithm needs (an expanded identifier carries
/// `definition_scope ∪ use_scope`, §9.38).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct ScopeSet {
    /// Invariant: strictly ascending, no duplicates.
    ids: Vec<ScopeId>,
}

impl ScopeSet {
    /// The empty set (top-level, pre-scope syntax).
    pub fn new() -> Self {
        Self { ids: Vec::new() }
    }

    /// Insert one scope; returns whether it was absent before.
    pub fn insert(&mut self, id: ScopeId) -> bool {
        match self.ids.binary_search(&id) {
            Ok(_) => false,
            Err(pos) => {
                self.ids.insert(pos, id);
                true
            }
        }
    }

    /// Membership test.
    pub fn contains(&self, id: ScopeId) -> bool {
        self.ids.binary_search(&id).is_ok()
    }

    /// Number of member scopes.
    pub fn len(&self) -> usize {
        self.ids.len()
    }

    /// Whether no scope is a member.
    pub fn is_empty(&self) -> bool {
        self.ids.is_empty()
    }

    /// Members in ascending order (deterministic — sorted-storage
    /// invariant).
    pub fn iter(&self) -> impl Iterator<Item = ScopeId> + '_ {
        self.ids.iter().copied()
    }

    /// Union (functional — neither operand is mutated, SOP principle 23).
    pub fn union(&self, other: &ScopeSet) -> ScopeSet {
        let mut out = self.clone();
        for id in other.ids.iter().copied() {
            out.insert(id);
        }
        out
    }

    /// Subset test — the lexical-resolution query: a binding site whose
    /// scope set is a subset of a reference's scope set is visible to it
    /// (docs/stage0.md §9.38 resolution sketch).
    pub fn is_subset_of(&self, other: &ScopeSet) -> bool {
        self.ids.iter().all(|id| other.contains(*id))
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ScopeSet feature point (sub-stage test doc FP3).

    use super::*;

    fn set_of(ids: &[u32]) -> ScopeSet {
        let mut set = ScopeSet::new();
        for id in ids {
            set.insert(ScopeId(*id));
        }
        set
    }

    // ---------- positive ----------

    #[test]
    fn insert_contains_iter_are_deterministic() {
        let mut set = ScopeSet::new();
        assert!(set.is_empty());
        // Insertion out of order plus one duplicate.
        assert!(set.insert(ScopeId(3)));
        assert!(set.insert(ScopeId(1)));
        assert!(set.insert(ScopeId(2)));
        assert!(
            !set.insert(ScopeId(3)),
            "duplicate insert must report false"
        );
        assert_eq!(set.len(), 3, "dedup invariant keeps the size at 3");
        for id in [1, 2, 3] {
            assert!(set.contains(ScopeId(id)));
        }
        // Sorted-storage invariant: iteration is ascending.
        let collected: Vec<u32> = set.iter().map(|ScopeId(id)| id).collect();
        assert_eq!(collected, vec![1, 2, 3]);
    }

    #[test]
    fn union_merges_and_subset_relations_hold() {
        let a = set_of(&[0, 1]);
        let b = set_of(&[1, 2]);
        let merged = a.union(&b);
        let collected: Vec<u32> = merged.iter().map(|ScopeId(id)| id).collect();
        assert_eq!(collected, vec![0, 1, 2]);
        // Lexical-resolution query: a binding at {0,1} is visible from a
        // reference at {0,1,2} (subset), and reflexivity holds.
        assert!(a.is_subset_of(&merged));
        assert!(a.is_subset_of(&a));
    }

    // ---------- negative ----------

    #[test]
    fn contains_missing_scope_returns_false() {
        let set = set_of(&[1]);
        assert!(!set.contains(ScopeId(0)));
        assert!(!set.contains(ScopeId(2)));
        assert!(!ScopeSet::new().contains(ScopeId(0)));
    }

    #[test]
    fn non_subset_returns_false() {
        let binding = set_of(&[0, 5]);
        let reference = set_of(&[0, 1, 2]);
        assert!(!binding.is_subset_of(&reference));
    }

    #[test]
    fn different_sets_are_unequal() {
        assert_ne!(set_of(&[0, 1]), set_of(&[0, 2]));
        assert_ne!(set_of(&[0]), ScopeSet::new());
        // Union actually adds members when operands are not nested.
        let a = set_of(&[0]);
        let merged = a.union(&set_of(&[1]));
        assert_ne!(merged, a);
    }

    #[test]
    fn duplicate_union_members_never_appear() {
        let a = set_of(&[0, 1]);
        let double = a.union(&a);
        assert_eq!(double.len(), 2, "union with self must stay deduplicated");
        let collected: Vec<u32> = double.iter().map(|ScopeId(id)| id).collect();
        assert_eq!(collected, vec![0, 1]);
    }
}

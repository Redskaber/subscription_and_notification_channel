//! Errors produced by kerf-syntax construction and validation.

use std::error::Error;
use std::fmt;

use kerf_span::SymbolError;

/// Errors raised while building syntax objects from source-shaped text
/// (validated constructors — the sub-stage 0.3 reader contract) and while
/// decoding phase levels.
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks. The
/// `InvalidSymbol` arm delegates its rendering to the single source
/// `kerf_span::SymbolError` (the unified identifier floor since v0.27.0 —
/// stage0.md §9.58): the same source concept always renders the same
/// English text (the single-source dictionary — the parity-guard
/// prerequisite).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SyntaxError {
    /// A name failed the [`kerf_span::Symbol`](kerf_span::Symbol) floor
    /// (empty, whitespace, or control character).
    InvalidSymbol(SymbolError),
    /// `Phase::from_u8` received a level outside the frozen two-level
    /// set (docs/stage0.md §3.3: 0 = runtime, 1 = macro expansion).
    InvalidPhase { phase: u8 },
}

impl From<SymbolError> for SyntaxError {
    fn from(err: SymbolError) -> Self {
        SyntaxError::InvalidSymbol(err)
    }
}

impl fmt::Display for SyntaxError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SyntaxError::InvalidSymbol(err) => err.fmt(f),
            SyntaxError::InvalidPhase { phase } => {
                write!(
                    f,
                    "invalid phase `{phase}`: must be 0 (runtime) or 1 (macro expansion)"
                )
            }
        }
    }
}

impl Error for SyntaxError {}

#[cfg(test)]
mod tests {
    //! Unit tests for the SyntaxError rendering surface (sub-stage test
    //! doc FP1/FP2; R8 message-shape assertions).

    use super::*;

    // ---------- negative (error surface) ----------

    #[test]
    fn display_invalid_symbol_mentions_text_and_rules() {
        let err = SyntaxError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "a b".to_owned(),
        });
        let rendered = err.to_string();
        assert!(rendered.contains("`a b`"));
        assert!(rendered.contains("non-empty"));
        assert!(rendered.contains("whitespace"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn symbol_error_converts_into_the_syntax_face() {
        // The `?` bridge: kerf_span::SymbolError flows into SyntaxError
        // unchanged in payload and rendering (single source).
        let inner = SymbolError::InvalidSymbol {
            text: "x".to_owned(),
        };
        let outer: SyntaxError = inner.clone().into();
        assert_eq!(outer, SyntaxError::InvalidSymbol(inner));
        assert_eq!(
            outer.to_string(),
            "invalid symbol `x`: must be non-empty with no whitespace or control characters"
        );
    }

    #[test]
    fn display_invalid_phase_mentions_level_and_valid_values() {
        let err = SyntaxError::InvalidPhase { phase: 2 };
        let rendered = err.to_string();
        assert!(rendered.contains("`2`"));
        assert!(rendered.contains("runtime"));
        assert!(rendered.contains("macro expansion"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn error_variants_distinguishable_by_equality() {
        let a = SyntaxError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "x".to_owned(),
        });
        let b = SyntaxError::InvalidPhase { phase: 9 };
        assert_ne!(a, b);
        // Same variant with same payload compares equal (test assertions
        // rely on this).
        assert_eq!(
            a,
            SyntaxError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "x".to_owned()
            })
        );
    }
}

//! Phase levels for syntax objects (docs/stage0.md §3.3 field 4 / §8.9).
//!
//! Stage 0 freezes the two-level model: `Runtime` (phase 0 — program
//! code) and `MacroExpansion` (phase 1 — transformer code). Deeper
//! multi-stage levels are a 0.10 interface-reservation item (type shapes
//! only, no implementation obligation); extending the level set later is
//! additive (SOP principle 27) and never happens by silently wrapping an
//! out-of-range number.

use std::fmt;

use crate::error::SyntaxError;

/// The phase a syntax object belongs to.
///
/// Phase closure ("a phase-1 transformer only produces phase-0 syntax
/// objects", docs/stage0.md §8.9 rule 1) is an *expander* invariant
/// (plan sub-stage 0.4): the data layer stores one phase per node and
/// deliberately does not cross-validate phases inside a tree.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Phase {
    /// Phase 0 — runtime program code.
    Runtime,
    /// Phase 1 — macro-expansion-time transformer code.
    MacroExpansion,
}

impl Phase {
    /// The numeric level (docs/stage0.md §3.3 models `phase : int`).
    pub fn as_u8(self) -> u8 {
        match self {
            Phase::Runtime => 0,
            Phase::MacroExpansion => 1,
        }
    }

    /// Checked decoder: rejects every level outside the frozen two-level
    /// set with [`SyntaxError::InvalidPhase`].
    pub fn from_u8(phase: u8) -> Result<Self, SyntaxError> {
        match phase {
            0 => Ok(Phase::Runtime),
            1 => Ok(Phase::MacroExpansion),
            other => Err(SyntaxError::InvalidPhase { phase: other }),
        }
    }
}

impl fmt::Display for Phase {
    /// Stable diagnostic names (lowercase).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Phase::Runtime => "runtime",
            Phase::MacroExpansion => "macro expansion",
        })
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the Phase feature point (sub-stage test doc FP2).

    use super::*;

    // ---------- positive ----------

    #[test]
    fn phase_roundtrip_as_u8_from_u8() {
        for phase in [Phase::Runtime, Phase::MacroExpansion] {
            let decoded = Phase::from_u8(phase.as_u8()).expect("in-range level must decode");
            assert_eq!(decoded, phase);
        }
        assert_eq!(Phase::Runtime.as_u8(), 0);
        assert_eq!(Phase::MacroExpansion.as_u8(), 1);
        // Copy semantics (cheap to pass through the pipeline).
        let p = Phase::Runtime;
        let q = p;
        assert_eq!(p, q);
    }

    #[test]
    fn phase_display_forms() {
        assert_eq!(Phase::Runtime.to_string(), "runtime");
        assert_eq!(Phase::MacroExpansion.to_string(), "macro expansion");
    }

    // ---------- negative ----------

    #[test]
    fn from_u8_rejects_two() {
        let err = Phase::from_u8(2).expect_err("level 2 must be rejected");
        assert_eq!(err, SyntaxError::InvalidPhase { phase: 2 });
    }

    #[test]
    fn from_u8_rejects_max() {
        assert!(matches!(
            Phase::from_u8(u8::MAX),
            Err(SyntaxError::InvalidPhase { .. })
        ));
    }

    #[test]
    fn from_u8_error_payload_carries_the_level() {
        let err = Phase::from_u8(7).expect_err("out-of-range level must be rejected");
        let SyntaxError::InvalidPhase { phase } = err else {
            panic!("must be the InvalidPhase variant");
        };
        assert_eq!(phase, 7);
        assert!(err.to_string().contains("`7`"));
    }
}

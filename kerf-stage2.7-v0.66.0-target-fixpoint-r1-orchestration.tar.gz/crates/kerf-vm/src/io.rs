//! The VM I/O face (docs/stage0.md §8.8: read_line / write_line only).
//!
//! Stage 0 keeps I/O pluggable and deterministic: the default
//! [`BufferIo`] seeds input lines and records output for tests, and
//! the 0.8 driver wires the real process streams. `write-line` takes
//! a `string` strictly (display formatting of arbitrary values is a
//! later library concern, not an I/O primitive semantic).

use std::collections::VecDeque;
use std::fmt;

/// The pluggable I/O face behind the `read-line` / `write-line`
/// builtins.
pub trait VmIo {
    /// One input line, or None at end of input.
    fn read_line(&mut self) -> Option<String>;

    /// Emit one output line.
    fn write_line(&mut self, line: &str);

    /// Drain the recorded output (default: nothing recorded).
    fn take_output(&mut self) -> Vec<String> {
        Vec::new()
    }
}

/// The default deterministic face: seeded input, recorded output.
pub struct BufferIo {
    input: VecDeque<String>,
    output: Vec<String>,
}

impl BufferIo {
    /// Empty input, empty output.
    pub fn new() -> Self {
        BufferIo {
            input: VecDeque::new(),
            output: Vec::new(),
        }
    }

    /// Seed the input with lines (consumed front-first).
    pub fn with_input<I, S>(lines: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        BufferIo {
            input: lines.into_iter().map(Into::into).collect(),
            output: Vec::new(),
        }
    }

    /// Push one more input line at the back.
    pub fn push_input(&mut self, line: impl Into<String>) {
        self.input.push_back(line.into());
    }
}

impl Default for BufferIo {
    fn default() -> Self {
        BufferIo::new()
    }
}

impl fmt::Debug for BufferIo {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BufferIo")
            .field("pending_input", &self.input.len())
            .field("output_lines", &self.output.len())
            .finish()
    }
}

impl VmIo for BufferIo {
    fn read_line(&mut self) -> Option<String> {
        self.input.pop_front()
    }

    fn write_line(&mut self, line: &str) {
        self.output.push(line.to_string());
    }

    fn take_output(&mut self) -> Vec<String> {
        std::mem::take(&mut self.output)
    }
}

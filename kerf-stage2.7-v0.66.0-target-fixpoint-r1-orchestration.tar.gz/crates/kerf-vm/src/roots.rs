//! The §19.4 root set and the collector injection face.
//!
//! Root-set completeness is the collector's first core invariant
//! (docs/stage0.md §19.4): the VM operand stacks, the call-stack
//! locals, the global environment, and the explicitly registered
//! foreign references (the §15 FFI-reserved fourth class, spelled
//! `Vm::register_foreign_ref` on the VM side) — missing any class
//! means dangling references. Roots are SNAPSHOT values: the
//! collector runs between allocations, never mid-instruction, so a
//! clone is a faithful root picture.
//!
//! [`Collector`] is the dependency-inversion face: Layer 6 owns the
//! hook points (where and with what roots a cycle may run), Layer 7
//! (kerf-runtime) owns the algorithm — depending on the abstraction,
//! never on a concrete implementation (SOP §21.12-10②).

use crate::value::{Heap, Value};

/// The §19.4 root classes, snapshot form (four spec classes plus the
/// handler-table extension of class 2 — installed handler values are
/// frame-adjacent VM state a cycle must not reclaim).
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Roots {
    /// Every operand-stack cell of every frame.
    pub stack: Vec<Value>,
    /// Every local slot of every frame.
    pub locals: Vec<Value>,
    /// Every bound global.
    pub globals: Vec<Value>,
    /// Host-held references registered via
    /// `Vm::register_foreign_ref` (the §19.4 "C stack explicit
    /// roots" class — Stage 0's Rust spelling).
    pub foreign: Vec<Value>,
    /// Installed handler values (`push-handler` entries — class-2
    /// extension: frame-adjacent state, missing it dangles handlers).
    pub handlers: Vec<Value>,
}

impl Roots {
    /// The no-roots picture (an explicit-sweep convenience face for
    /// tests and the evaluator's standalone heap).
    pub fn empty() -> Self {
        Roots::default()
    }

    /// Iterate every root value, root classes in declaration order
    /// (the mark-phase input face).
    pub fn iter_values(&self) -> impl Iterator<Item = &Value> {
        self.stack
            .iter()
            .chain(self.locals.iter())
            .chain(self.globals.iter())
            .chain(self.foreign.iter())
            .chain(self.handlers.iter())
    }
}

/// One garbage-collection algorithm, injectable into the VM (the
/// collect-then-retry evolution of the §19.4 safety point) or run
/// explicitly over a standalone heap.
pub trait Collector {
    /// Run one `gc_cycle` over `heap` starting from `roots`; returns
    /// the number of swept cells.
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32;
}

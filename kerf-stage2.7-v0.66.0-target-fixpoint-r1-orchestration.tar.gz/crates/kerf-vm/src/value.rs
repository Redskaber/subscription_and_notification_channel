//! Runtime values and the object heap (docs/stage0.md §8.12 "VM state"
//! and §19.4 heap model, 0.6 slice).
//!
//! [`Value`] is the runtime carrier of [`LiteralValue`] constants plus
//! the three execution-born kinds: heap pairs ([`Opcode::MakePair`],
//! the `cons` builtin), closures ([`Opcode::Closure`]), and builtins
//! (STAGE0_GLOBALS seeding). Pairs and closures live in [`Heap`] cells
//! addressed by [`HeapRef`] — the addressable-object shape the 0.7
//! mark-sweep collector walks (allocation quota is the §19.4 safety
//! point; reclamation is the 0.7 `gc_cycle` over this same shape,
//! with mark bits and a free list carried here).

use std::fmt;
use std::rc::Rc;

use kerf_core::LiteralValue;

use crate::builtin::Builtin;

/// Index into [`Heap`] cells.
pub type HeapRef = u32;

/// The captured environment plus the body proto index — the
/// §19.5 skeleton's `Value::closure(p, vm.capture_env())` carrier.
///
/// Active since the Stage 2.1 semantic MUV (LA-3/LA-5): `env` holds
/// exactly the values the proto's capture descriptors name, in
/// descriptor order (the flat closure — a selective copy taken at
/// `closure`-instruction time from the defining frame's locals and
/// capture area). The dormant era (0.6-0.49: a full-frame snapshot
/// no instruction ever read) is preserved in git history; the GC
/// traces `env` slots through the closure cell exactly as before.
#[derive(Debug, Clone, PartialEq)]
pub struct ClosureData {
    /// Proto index into `Bytecode::funcs`.
    pub proto: u32,
    /// The captured values, in descriptor order (the frame's capture
    /// area installs from here at `invoke`).
    pub env: Vec<Value>,
}

/// One heap cell. 0.6 allocates monotonically (bump semantics); the
/// 0.7 collector adds mark bits and a free list over this same shape.
#[derive(Debug, Clone, PartialEq)]
pub enum HeapObj {
    Pair(Value, Value),
    Closure(ClosureData),
}

/// One heap slot: the object (None once swept) plus the collector's
/// mark bit (docs/stage0.md §19.4 — mark bits live on the heap; the
/// three-phase orchestration lives in the kerf-runtime collector).
#[derive(Debug, Clone, Default, PartialEq)]
struct Cell {
    obj: Option<HeapObj>,
    mark: bool,
}

/// Cell arena with a free list — the §19.4 bump heap plus the 0.7
/// reclamation face. Allocation reuses swept slots (LIFO) before
/// growing the arena; `len` semantics is LIVE cells (the 0.6
/// monotonic count is the no-collection special case).
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Heap {
    cells: Vec<Cell>,
    free: Vec<HeapRef>,
    live: u32,
}

impl Heap {
    /// Allocate one cell and return its reference.
    ///
    /// Swept slots are reused before the arena grows (free-list LIFO,
    /// §19.4 sweep face). Panics past `u32::MAX` live cells: callers
    /// bound allocations with the VM budget long before (a budget is
    /// a `u32`), so this edge is a caller-contract assertion, not a
    /// reachable path.
    pub fn alloc(&mut self, obj: HeapObj) -> HeapRef {
        self.live += 1;
        if let Some(r) = self.free.pop() {
            self.cells[r as usize].obj = Some(obj);
            r
        } else {
            let r = self.cells.len() as HeapRef;
            self.cells.push(Cell {
                obj: Some(obj),
                mark: false,
            });
            r
        }
    }

    /// Number of live (allocated, not swept) cells.
    pub fn len(&self) -> usize {
        self.live as usize
    }

    /// Live-cell count (explicit spelling for collector call sites).
    pub fn live_len(&self) -> usize {
        self.live as usize
    }

    /// Total arena slots (live + swept; the sweep-walk bound).
    pub fn total_slots(&self) -> usize {
        self.cells.len()
    }

    /// True when no cell is live.
    pub fn is_empty(&self) -> bool {
        self.live == 0
    }

    /// Borrow a cell (None on an out-of-range or swept reference).
    pub fn get(&self, r: HeapRef) -> Option<&HeapObj> {
        self.cells.get(r as usize).and_then(|c| c.obj.as_ref())
    }

    /// Mutably borrow a live cell (None on out-of-range or swept).
    pub fn get_mut(&mut self, r: HeapRef) -> Option<&mut HeapObj> {
        self.cells.get_mut(r as usize).and_then(|c| c.obj.as_mut())
    }

    // ---------- 0.7 collector face (the §19.4 heap-method skeleton) ----------

    /// True when the slot holds a live object.
    pub fn is_live(&self, r: HeapRef) -> bool {
        self.cells.get(r as usize).is_some_and(|c| c.obj.is_some())
    }

    /// The mark bit of a slot (false for swept slots — `clear_marks`
    /// resets both, keeping the reset-symmetry invariant).
    pub fn is_marked(&self, r: HeapRef) -> bool {
        self.cells.get(r as usize).is_some_and(|c| c.mark)
    }

    /// Set the mark bit; true when it was already set (the work-stack
    /// dedup face — §19.4 `test_and_set_mark`). Panics on an
    /// out-of-range reference: the collector only walks references
    /// that allocation produced, so a miss is a caller bug, not a
    /// data condition.
    pub fn test_and_set_mark(&mut self, r: HeapRef) -> bool {
        let cell = self
            .cells
            .get_mut(r as usize)
            .expect("collector only walks arena references");
        let was = cell.mark;
        cell.mark = true;
        was
    }

    /// Clear every mark bit — ALL slots, swept ones included (the
    /// reset-symmetry invariant: a stale bit would leak into the next
    /// cycle as a false retain, never as a false sweep).
    pub fn clear_marks(&mut self) {
        for cell in &mut self.cells {
            cell.mark = false;
        }
    }

    /// Return one object to the free list (the sweep step). True when
    /// a live object was reclaimed; sweeping an already-swept slot is
    /// a defensive no-op false (§19.4: reclaiming a live object is
    /// intolerable, double-freeing is merely detected).
    pub fn free(&mut self, r: HeapRef) -> bool {
        let cell = self
            .cells
            .get_mut(r as usize)
            .expect("collector only walks arena references");
        if cell.obj.take().is_some() {
            self.live -= 1;
            self.free.push(r);
            true
        } else {
            false
        }
    }

    /// Walk every arena slot with its reference (the sweep face —
    /// includes swept-empty slots so mark reset stays symmetric).
    pub fn iter_slots(&self) -> impl Iterator<Item = (HeapRef, Option<&HeapObj>)> {
        self.cells
            .iter()
            .enumerate()
            .map(|(i, c)| (i as HeapRef, c.obj.as_ref()))
    }
}

/// A runtime value.
///
/// §9.72 SYN-1: `Str` carries a shared `Rc<str>` — materializing a
/// constant and loading a local both clone the pointer (refcount),
/// never the bytes; the enum shrinks 32→24 bytes (the `String`
/// triple-word payload is replaced by a two-word fat pointer).
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(Rc<str>),
    Nil,
    Pair(HeapRef),
    Closure(HeapRef),
    Builtin(Builtin),
}

impl Value {
    /// Stable diagnostic name (lowercase, one word — error payloads
    /// quote this via [`crate::RuntimeError::TypeMismatch`]).
    pub fn kind_name(&self) -> &'static str {
        match self {
            Value::Int(_) => "int",
            Value::Float(_) => "float",
            Value::Bool(_) => "bool",
            Value::Str(_) => "string",
            Value::Nil => "nil",
            Value::Pair(_) => "pair",
            Value::Closure(_) => "closure",
            Value::Builtin(_) => "builtin",
        }
    }

    /// The pair cell of a pair value (None for any other value).
    pub fn as_pair<'h>(&self, heap: &'h Heap) -> Option<(&'h Value, &'h Value)> {
        match self {
            Value::Pair(r) => match heap.get(*r) {
                Some(HeapObj::Pair(a, b)) => Some((a, b)),
                _ => None,
            },
            _ => None,
        }
    }

    /// The closure data of a closure value (None for any other value).
    pub fn as_closure<'h>(&self, heap: &'h Heap) -> Option<&'h ClosureData> {
        match self {
            Value::Closure(r) => match heap.get(*r) {
                Some(HeapObj::Closure(data)) => Some(data),
                _ => None,
            },
            _ => None,
        }
    }

    /// Identity equality (`eq?` semantics): structural for immediates
    /// (floats compare bitwise — eqv?-style, so `+0.0` and `-0.0` are
    /// distinct and a NaN equals its bit-identical copy) and
    /// same-cell for pairs and closures.
    pub fn eq_identity(&self, other: &Value) -> bool {
        match (self, other) {
            (Value::Int(a), Value::Int(b)) => a == b,
            (Value::Float(a), Value::Float(b)) => a.to_bits() == b.to_bits(),
            (Value::Bool(a), Value::Bool(b)) => a == b,
            (Value::Str(a), Value::Str(b)) => a == b,
            (Value::Nil, Value::Nil) => true,
            (Value::Pair(a), Value::Pair(b)) => a == b,
            (Value::Closure(a), Value::Closure(b)) => a == b,
            (Value::Builtin(a), Value::Builtin(b)) => a == b,
            _ => false,
        }
    }

    /// Convert a constant-pool literal, allocating heap cells for pair
    /// shapes (a constant pair re-allocates on every push — interning
    /// is a Stage 2 optimization, not a 0.6 semantic).
    pub fn from_literal(lit: &LiteralValue, heap: &mut Heap) -> Value {
        match lit {
            LiteralValue::Int(v) => Value::Int(*v),
            LiteralValue::Float(v) => Value::Float(*v),
            LiteralValue::Bool(v) => Value::Bool(*v),
            LiteralValue::String(v) => Value::Str(v.clone()),
            LiteralValue::Nil => Value::Nil,
            LiteralValue::Pair(a, b) => {
                let av = Value::from_literal(a, heap);
                let bv = Value::from_literal(b, heap);
                Value::Pair(heap.alloc(HeapObj::Pair(av, bv)))
            }
        }
    }
}

impl fmt::Display for Value {
    /// Readable immediate form; heap references render opaquely
    /// (`#<pair>`, `#<closure>`) because resolving them needs heap
    /// context — diagnostics quote [`Value::kind_name`] instead.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Int(v) => write!(f, "{v}"),
            Value::Float(v) => write!(f, "{v}"),
            Value::Bool(v) => write!(f, "{v}"),
            Value::Str(v) => write!(f, "\"{v}\""),
            Value::Nil => write!(f, "nil"),
            Value::Pair(_) => write!(f, "#<pair>"),
            Value::Closure(_) => write!(f, "#<closure>"),
            Value::Builtin(b) => write!(f, "#<builtin:{}>", b.name()),
        }
    }
}

#[cfg(test)]
mod tests {
    //! Value/Heap data-shape tests (FP2): display forms, identity
    //! equality, and literal conversion.

    use super::*;

    fn pair_cell(a: Value, b: Value) -> HeapObj {
        HeapObj::Pair(a, b)
    }

    #[test]
    fn immediate_display_forms_and_kind_names() {
        assert_eq!(Value::Int(7).to_string(), "7");
        assert_eq!(Value::Bool(false).to_string(), "false");
        assert_eq!(Value::Str("ab".into()).to_string(), "\"ab\"");
        assert_eq!(Value::Nil.to_string(), "nil");
        assert_eq!(Value::Float(2.5).to_string(), "2.5");
        // Heap references are opaque in the context-free display.
        assert_eq!(Value::Pair(3).to_string(), "#<pair>");
        assert_eq!(Value::Closure(9).to_string(), "#<closure>");
        // kind_name table is stable and lowercase.
        for (v, name) in [
            (Value::Int(0), "int"),
            (Value::Float(0.0), "float"),
            (Value::Bool(true), "bool"),
            (Value::Str("".into()), "string"),
            (Value::Nil, "nil"),
            (Value::Pair(0), "pair"),
            (Value::Closure(0), "closure"),
        ] {
            assert_eq!(v.kind_name(), name);
        }
    }

    #[test]
    fn heap_alloc_read_back_and_typed_views() {
        let mut heap = Heap::default();
        let p = heap.alloc(pair_cell(Value::Int(1), Value::Nil));
        let c = heap.alloc(HeapObj::Closure(ClosureData {
            proto: 2,
            env: vec![Value::Int(5)],
        }));
        assert_eq!(heap.len(), 2);
        assert!(!heap.is_empty());
        let (a, b) = Value::Pair(p).as_pair(&heap).expect("pair view");
        assert_eq!(a, &Value::Int(1));
        assert_eq!(b, &Value::Nil);
        let data = Value::Closure(c).as_closure(&heap).expect("closure view");
        assert_eq!(data.proto, 2);
        assert_eq!(data.env, vec![Value::Int(5)]);
    }

    #[test]
    fn literal_conversion_covers_immediates_and_nested_pairs() {
        let mut heap = Heap::default();
        assert_eq!(
            Value::from_literal(&LiteralValue::Int(3), &mut heap),
            Value::Int(3)
        );
        assert_eq!(
            Value::from_literal(&LiteralValue::Float(0.5), &mut heap),
            Value::Float(0.5)
        );
        assert_eq!(
            Value::from_literal(&LiteralValue::Bool(true), &mut heap),
            Value::Bool(true)
        );
        assert_eq!(
            Value::from_literal(&LiteralValue::String("s".into()), &mut heap),
            Value::Str("s".into())
        );
        assert_eq!(
            Value::from_literal(&LiteralValue::Nil, &mut heap),
            Value::Nil
        );
        // (1 . (2 . nil)) allocates two cells; structure reads back.
        let lit = LiteralValue::Pair(
            Box::new(LiteralValue::Int(1)),
            Box::new(LiteralValue::Pair(
                Box::new(LiteralValue::Int(2)),
                Box::new(LiteralValue::Nil),
            )),
        );
        let v = Value::from_literal(&lit, &mut heap);
        assert_eq!(heap.len(), 2);
        let (a, rest) = v.as_pair(&heap).expect("outer pair");
        assert_eq!(a, &Value::Int(1));
        let (b, tail) = rest.as_pair(&heap).expect("inner pair");
        assert_eq!(b, &Value::Int(2));
        assert_eq!(tail, &Value::Nil);
    }

    #[test]
    fn heap_free_list_reuse_and_live_count() {
        // The 0.7 reclamation face: sweeping returns a slot, the live
        // count drops, and the next allocation reuses that address.
        let mut heap = Heap::default();
        let a = heap.alloc(pair_cell(Value::Int(1), Value::Nil));
        let b = heap.alloc(pair_cell(Value::Int(2), Value::Nil));
        let c = heap.alloc(pair_cell(Value::Int(3), Value::Nil));
        assert_eq!(heap.live_len(), 3);
        assert_eq!(heap.total_slots(), 3);
        assert!(heap.free(b)); // sweep the middle cell
        assert_eq!(heap.live_len(), 2);
        assert_eq!(heap.len(), 2); // len == live semantics
        assert_eq!(heap.total_slots(), 3); // arena never shrinks
        let d = heap.alloc(pair_cell(Value::Int(4), Value::Nil));
        assert_eq!(d, b, "free-list LIFO reuses the swept address");
        assert!(heap.is_live(d));
        let _ = (a, c);
    }

    #[test]
    fn swept_slot_reads_none_and_double_free_is_noop() {
        let mut heap = Heap::default();
        let r = heap.alloc(pair_cell(Value::Int(1), Value::Nil));
        assert!(heap.free(r));
        assert!(heap.get(r).is_none(), "swept slot reads as None");
        assert!(!heap.is_live(r));
        assert!(!heap.free(r), "double free is a defensive no-op");
        assert_eq!(heap.live_len(), 0);
        assert!(heap.is_empty());
    }

    #[test]
    fn mark_bits_set_test_and_reset_symmetrically() {
        // test_and_set_mark: false on first touch, true after; the
        // reset clears every slot INCLUDING swept ones (a stale bit
        // must not leak into the next cycle as a false retain).
        let mut heap = Heap::default();
        let a = heap.alloc(pair_cell(Value::Int(1), Value::Nil));
        let b = heap.alloc(pair_cell(Value::Int(2), Value::Nil));
        assert!(!heap.test_and_set_mark(a));
        assert!(heap.test_and_set_mark(a)); // already set
        assert!(!heap.is_marked(b));
        heap.free(b);
        assert!(!heap.is_marked(b), "swept slots report unmarked");
        heap.clear_marks();
        assert!(!heap.is_marked(a));
        assert!(!heap.is_marked(b));
    }

    #[test]
    fn mark_face_is_defensive_out_of_range() {
        let mut heap = Heap::default();
        heap.alloc(pair_cell(Value::Nil, Value::Nil));
        // Out-of-range references read as unmarked (sweep filters
        // through is_live anyway; is_marked must not panic).
        assert!(!heap.is_marked(99));
        assert!(!heap.is_live(99));
        assert!(heap.get(99).is_none());
    }

    #[test]
    fn heap_get_out_of_range_reference_is_none() {
        let mut heap = Heap::default();
        heap.alloc(pair_cell(Value::Nil, Value::Nil));
        assert!(heap.get(1).is_none());
        assert!(heap.get(u32::MAX).is_none());
        assert!(heap.get(0).is_some());
    }

    #[test]
    fn typed_views_miss_on_wrong_cell_or_wrong_kind() {
        let mut heap = Heap::default();
        let p = heap.alloc(pair_cell(Value::Nil, Value::Nil));
        let c = heap.alloc(HeapObj::Closure(ClosureData {
            proto: 0,
            env: vec![],
        }));
        // Wrong cell type behind the reference.
        assert!(Value::Pair(c).as_pair(&heap).is_none());
        assert!(Value::Closure(p).as_closure(&heap).is_none());
        // Wrong value kind (no heap involvement at all).
        assert!(Value::Int(1).as_pair(&heap).is_none());
        assert!(Value::Nil.as_closure(&heap).is_none());
    }

    #[test]
    fn identity_equality_across_distinct_kinds_is_false() {
        assert!(!Value::Int(1).eq_identity(&Value::Float(1.0)));
        assert!(!Value::Bool(true).eq_identity(&Value::Int(1)));
        assert!(!Value::Str("1".into()).eq_identity(&Value::Int(1)));
        assert!(!Value::Nil.eq_identity(&Value::Bool(false)));
        assert!(!Value::Int(1).eq_identity(&Value::Pair(0)));
    }

    #[test]
    fn identity_equality_compares_floats_bitwise() {
        // eqv?-style: signed zeros are distinct bit patterns.
        assert!(!Value::Float(0.0).eq_identity(&Value::Float(-0.0)));
        // A NaN equals its bit-identical copy (total, deterministic).
        let nan = f64::NAN;
        assert!(Value::Float(nan).eq_identity(&Value::Float(nan)));
    }

    #[test]
    fn identity_equality_on_heap_objects_requires_same_cell() {
        let mut heap = Heap::default();
        let a = heap.alloc(pair_cell(Value::Int(1), Value::Int(2)));
        let b = heap.alloc(pair_cell(Value::Int(1), Value::Int(2)));
        // Structurally equal but distinct cells.
        assert!(!Value::Pair(a).eq_identity(&Value::Pair(b)));
        assert!(Value::Pair(a).eq_identity(&Value::Pair(a)));
        assert!(Value::Closure(b).eq_identity(&Value::Closure(b)));
    }

    #[test]
    fn closure_display_does_not_leak_names_or_envs() {
        // The context-free form is opaque: no proto index, no env, no
        // source names (those live in the bytecode, not the value).
        assert_eq!(Value::Closure(0).to_string(), "#<closure>");
        assert_eq!(Value::Builtin(Builtin::Add).to_string(), "#<builtin:+>");
    }

    #[test]
    fn materialized_string_constants_share_one_allocation() {
        // §9.72 SYN-1 guard: every materialization of the same string
        // constant clones the shared payload (refcount bump), never the
        // bytes — the pre-SYN-1 form re-allocated a fresh `String` per
        // materialization (and per local load).
        let lit = LiteralValue::String("shared".into());
        let mut heap = Heap::default();
        let first = Value::from_literal(&lit, &mut heap);
        let second = Value::from_literal(&lit, &mut heap);
        let rc_of = |v: &Value| match v {
            Value::Str(s) => std::rc::Rc::clone(s),
            _ => panic!("expected a string value"),
        };
        let lit_rc = match &lit {
            LiteralValue::String(s) => std::rc::Rc::clone(s),
            _ => panic!("expected a string literal"),
        };
        assert!(
            std::rc::Rc::ptr_eq(&rc_of(&first), &rc_of(&second)),
            "two materializations must alias one allocation"
        );
        assert!(
            std::rc::Rc::ptr_eq(&rc_of(&first), &lit_rc),
            "the materialized value must alias the constant's allocation"
        );
        // Content semantics are unchanged: equality stays by value.
        assert_eq!(first, Value::Str("shared".into()));
        assert_ne!(first, Value::Str("other".into()));
    }

    #[test]
    fn value_layout_is_pinned_at_the_shared_payload_size() {
        // §9.72 SYN-1 layout pin (64-bit): the `String` payload (three
        // words) became a two-word fat pointer, shrinking `Value` from
        // 32 to 24 bytes — the operand stack and every frame-local slot
        // ride on this. Reverting to an owned `String` fails here first.
        assert_eq!(std::mem::size_of::<Value>(), 24);
    }
}

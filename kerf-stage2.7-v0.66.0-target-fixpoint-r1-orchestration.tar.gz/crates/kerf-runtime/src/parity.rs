//! Dual-path parity (stage-0-plan §5 row 0.7): the structural value
//! representation shared by the eval and VM cross-check.
//!
//! The two engines own separate heaps, so `Value::Pair(HeapRef)`
//! equality compares ADDRESSES, never structure. [`parity_repr`]
//! renders a value into a structure-identical string: immediates
//! verbatim, pairs as dotted notation recursing into both arms,
//! closures and builtins as their opaque forms (closure identity is
//! not a program-result semantic — kind-level agreement is the
//! contract). Two engines agree on a program exactly when their
//! final values (and observed globals) print the same repr.

use kerf_vm::{Heap, HeapObj, Value};

/// The structural representation (the parity comparison key).
pub fn parity_repr(value: &Value, heap: &Heap) -> String {
    let mut out = String::new();
    render(value, heap, &mut out);
    out
}

fn render(value: &Value, heap: &Heap, out: &mut String) {
    match value {
        Value::Int(v) => out.push_str(&v.to_string()),
        Value::Float(v) => out.push_str(&format!("{v:?}")),
        Value::Bool(v) => out.push_str(if *v { "true" } else { "false" }),
        Value::Str(v) => {
            out.push('"');
            out.push_str(v);
            out.push('"');
        }
        Value::Nil => out.push_str("nil"),
        Value::Pair(r) => match heap.get(*r) {
            Some(HeapObj::Pair(a, b)) => {
                out.push('(');
                render(a, heap, out);
                out.push_str(" . ");
                render(b, heap, out);
                out.push(')');
            }
            _ => out.push_str("#<pair>"), // dead reference: opaque
        },
        Value::Closure(_) => out.push_str("#<closure>"),
        Value::Builtin(b) => {
            out.push_str("#<builtin:");
            out.push_str(b.name());
            out.push('>');
        }
    }
}

/// Assert two engine results agree structurally (returns the shared
/// repr on agreement; panics with both reprs otherwise — the parity
/// tests' one-line consumption face).
pub fn assert_parity(a: &Value, heap_a: &Heap, b: &Value, heap_b: &Heap) -> String {
    let ra = parity_repr(a, heap_a);
    let rb = parity_repr(b, heap_b);
    assert_eq!(ra, rb, "dual-path divergence (eval vs VM)");
    ra
}

#[cfg(test)]
mod tests {
    //! Parity representation tests (FP3): forms, recursion, and the
    //! divergence-detector self-check.

    use super::*;
    use kerf_vm::{Builtin, HeapObj};

    fn pair(heap: &mut Heap, a: Value, b: Value) -> Value {
        Value::Pair(heap.alloc(HeapObj::Pair(a, b)))
    }

    #[test]
    fn immediates_and_opaques_render_stable_forms() {
        let heap = Heap::default();
        assert_eq!(parity_repr(&Value::Int(-7), &heap), "-7");
        assert_eq!(parity_repr(&Value::Float(2.5), &heap), "2.5");
        assert_eq!(parity_repr(&Value::Bool(true), &heap), "true");
        assert_eq!(parity_repr(&Value::Str("ab".into()), &heap), "\"ab\"");
        assert_eq!(parity_repr(&Value::Nil, &heap), "nil");
        assert_eq!(
            parity_repr(&Value::Builtin(Builtin::Add), &heap),
            "#<builtin:+>"
        );
        assert_eq!(parity_repr(&Value::Closure(0), &heap), "#<closure>");
    }

    #[test]
    fn pairs_render_structurally_and_ignore_addresses() {
        // The same structure in two different heaps (and different
        // slot addresses) must render identically — the whole point
        // of the parity key.
        let mut ha = Heap::default();
        let mut hb = Heap::default();
        pair(&mut hb, Value::Int(99), Value::Nil); // noise slot first
        let va = pair(&mut ha, Value::Int(1), Value::Nil);
        let vb = pair(&mut hb, Value::Int(1), Value::Nil);
        assert_eq!(
            parity_repr(&va, &ha),
            parity_repr(&vb, &hb),
            "structure, not address, is the key"
        );
        // Nested pairs recurse.
        let inner = pair(&mut ha, Value::Int(2), Value::Nil);
        let outer = pair(&mut ha, Value::Int(1), inner);
        assert_eq!(parity_repr(&outer, &ha), "(1 . (2 . nil))");
    }

    #[test]
    fn assert_parity_detects_divergence() {
        // The detector self-check: different structures must fail
        // (a detector that cannot fail proves nothing).
        let mut ha = Heap::default();
        let mut hb = Heap::default();
        let va = pair(&mut ha, Value::Int(1), Value::Nil);
        let vb = pair(&mut hb, Value::Int(2), Value::Nil);
        let result = std::panic::catch_unwind(|| {
            assert_parity(&va, &ha, &vb, &hb);
        });
        assert!(result.is_err(), "divergent values must be detected");
        // And equal structures return the shared repr.
        let vc = pair(&mut hb, Value::Int(1), Value::Nil);
        assert_eq!(assert_parity(&va, &ha, &vc, &hb), "(1 . nil)");
    }
}

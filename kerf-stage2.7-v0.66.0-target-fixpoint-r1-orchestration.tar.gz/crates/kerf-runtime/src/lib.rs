//! kerf-runtime — runtime, mark-sweep GC and meta-circular evaluator
//! (Layer 7).
//!
//! Charter (docs/stage0.md §19.4 + §21.8 Phase 1): the mark-sweep
//! collector and the `eval` meta-circular evaluator used for the
//! dual-execution-path cross-check against the VM (eval vs VM mutual
//! verification of the primitive semantics — stage-0-plan §5 row
//! 0.7; a divergence is a P1 line stop per §21.11 risk 5).
//!
//! Layout: [`gc`] (the §19.4 three-phase orchestration over the
//! kerf-vm heap face), [`eval`] (the CoreExpr interpreter mirroring
//! the compiler/VM semantics decision-for-decision), [`parity`] (the
//! structural value key the cross-check compares). The 18
//! STAGE0_GLOBALS builtins dispatch through the kerf-vm shared
//! functions — one implementation, two engines, zero drift.
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c),
//! implemented at sub-stage 0.7 (TD-003 resolution step 3 of 4).

pub mod eval;
pub mod gc;
pub mod parity;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use eval::{EVAL_CLOSURE_PROTO, EVAL_DEPTH_LIMIT, Evaluator};
pub use gc::{GcStats, MarkSweep, collect};
pub use parity::{assert_parity, parity_repr};

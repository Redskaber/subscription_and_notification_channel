//! kerf-runtime public-API tests (SOP §9.1 rule 5 — the crate face a
//! consumer sees). Layer discipline: this file exercises the runtime
//! through its declared dependencies only (kerf-core/kerf-compiler/
//! kerf-vm per §18.5 L7 edges); source-level pipelines live in the
//! root integration tree (tests/v0/stage0/plan/runtime_seed_tests.rs).

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_runtime::{EVAL_CLOSURE_PROTO, Evaluator, GcStats, MarkSweep};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_vm::{BufferIo, HeapObj, RuntimeError, Value};

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(8), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

fn lit(v: LiteralValue) -> CoreExpr {
    CoreExpr::Literal {
        span: fix_span(),
        value: v,
    }
}

#[test]
fn evaluator_assembles_observes_and_collects() {
    // Assembly: default budget, buffered I/O, 18 builtins seeded.
    let mut ev = Evaluator::new();
    assert!(matches!(ev.global("+"), Some(Value::Builtin(_))));
    assert_eq!(ev.collector_cycles(), 0);
    assert_eq!(ev.allocations(), 0);

    // Observation: a define lands in the global table; the closure
    // carries the evaluator sentinel proto.
    let f = CoreExpr::fn_(fix_span(), &[], lit(LiteralValue::Int(1))).expect("fixture fn");
    let item = ModuleItem::define(fix_span(), "f", f).expect("fixture define");
    let items = [item];
    ev.eval_program(&items).expect("program runs");
    match ev.global("f") {
        Some(Value::Closure(r)) => {
            // The dormant capture face: the sentinel proto plus the
            // defining-frame locals snapshot.
            match ev.heap().get(*r) {
                Some(HeapObj::Closure(data)) => {
                    assert_eq!(data.proto, EVAL_CLOSURE_PROTO);
                }
                other => panic!("closure cell expected, got {other:?}"),
            }
        }
        other => panic!("closure global expected, got {other:?}"),
    }
    assert!(ev.allocations() > 0);

    // Explicit collection: the closure stays (a live global), the
    // stats report a clean cycle.
    let stats: GcStats = ev.collect_now();
    assert!(stats.swept == 0);
    assert!(stats.live_after >= 1);
}

#[test]
fn with_io_face_round_trips_write_line() {
    let mut ev = Evaluator::with_io(Box::new(BufferIo::new()));
    let s = lit(LiteralValue::String("hello".into()));
    let call = CoreExpr::Apply {
        span: fix_span(),
        func: Box::new(CoreExpr::var(fix_span(), "write-line").expect("fixture var")),
        args: vec![s],
    };
    assert_eq!(ev.eval_expr(&call).expect("write-line runs"), Value::Nil);
    assert_eq!(ev.take_output(), vec!["hello".to_string()]);
}

#[test]
fn with_budget_fails_closed_when_live_set_exceeds_it() {
    // A program whose LIVE set (entry frame + retained pairs) exceeds
    // a tiny budget: collection cannot help (every cell is rooted),
    // so the run fails closed with BudgetExceeded.
    let mut ev = Evaluator::with_budget(2);
    let cons_of = |a: CoreExpr, b: CoreExpr| CoreExpr::Apply {
        span: fix_span(),
        func: Box::new(CoreExpr::var(fix_span(), "cons").expect("fixture var")),
        args: vec![a, b],
    };
    let mut cells = Vec::new();
    for i in 0..4 {
        cells.push(cons_of(lit(LiteralValue::Int(i)), lit(LiteralValue::Nil)));
    }
    // A right-nested chain keeps every pair live through the args.
    let expr = cells
        .into_iter()
        .rev()
        .reduce(|acc, cell| cons_of(cell, acc))
        .expect("non-empty chain");
    let err = ev.eval_expr(&expr).expect_err("live set over budget");
    assert!(matches!(err, RuntimeError::BudgetExceeded { .. }));
}

#[test]
fn mark_sweep_implements_the_collector_trait() {
    // The injection face: MarkSweep drives a kerf-vm heap through
    // the Collector trait (what Vm::with_collector consumes).
    use kerf_vm::{Collector, Heap, Roots};
    let mut heap = Heap::default();
    let a = Value::Pair(heap.alloc(HeapObj::Pair(Value::Int(1), Value::Nil)));
    let _b = Value::Pair(heap.alloc(HeapObj::Pair(Value::Int(2), Value::Nil)));
    let mut collector = MarkSweep;
    let roots = Roots {
        stack: vec![a],
        ..Roots::empty()
    };
    let swept = Collector::collect(&mut collector, &mut heap, &roots);
    assert_eq!(swept, 1);
    assert_eq!(heap.live_len(), 1);
}

#[test]
fn api_errors_render_in_the_r8_family() {
    // §9.56 DIAG-1: the message stands on its own — no span suffix.
    let mut ev = Evaluator::new();
    let err = ev
        .eval_expr(&CoreExpr::var(fix_span(), "nope").expect("fixture var"))
        .expect_err("unbound");
    assert_eq!(err.to_string(), "unbound global `nope`");
}

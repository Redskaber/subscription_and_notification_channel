//! CompileError: the structured failure surface of bytecode generation
//! (sub-stage 0.5).
//!
//! Two defense layers share this type (plan-0.5.md ruling 4):
//! compile-time bookkeeping (depth caps, unpatched placeholders, patch
//! depth assertions) and `Bytecode::verify` (operand bounds, debug-info
//! alignment, DAG stack-depth propagation). Product-side variants carry
//! the offending `pc` plus the instruction's span; compile-side variants
//! carry `depth` plus the source span. `DebugInfoMissing`,
//! `MissingTerminator` and `EmptyFuncTable` carry no span on purpose:
//! the missing span *is* the defect being reported.

use std::fmt;

use kerf_span::{Span, Symbol};

#[derive(Debug, Clone, PartialEq)]
pub enum CompileError {
    /// Compile recursion exceeded [`crate::COMPILE_DEPTH_LIMIT`]
    /// (synthesized deep trees; expander output is structurally bounded
    /// by its own budget).
    DepthExceeded { depth: usize, span: Span },
    /// A jump placeholder was still unpatched when the proto finished
    /// (internal CodeBuf defense; the placeholder sentinel is never a
    /// valid pc).
    UnpatchedJump { at: usize, span: Span },
    /// The static stack simulation popped below zero (compile-time
    /// bookkeeping, or a `verify` basic-block walk).
    StackUnderflow { pc: usize, span: Span },
    /// A basic block was reached with two different entry depths
    /// (`verify` DAG propagation or a compile-time patch assertion).
    StackImbalance {
        pc: usize,
        expected: u32,
        actual: u32,
        span: Span,
    },
    /// `push-const` operand beyond the constant pool.
    ConstIndexOutOfRange { pc: usize, index: usize, span: Span },
    /// `load-global` / `store-global` / `push-handler` / `perform`
    /// operand beyond the global symbol table.
    GlobalIndexOutOfRange { pc: usize, index: usize, span: Span },
    /// `load-local` / `store-local` operand beyond the proto's locals.
    LocalSlotOutOfRange { pc: usize, slot: usize, span: Span },
    /// A closure proto's capture descriptor names a source the
    /// defining frame cannot supply (Stage 2.1 LA-2): a
    /// [`crate::CaptureSource::Local`] slot beyond the defining
    /// proto's `n_locals`, or a [`crate::CaptureSource::Captured`]
    /// index beyond the defining proto's own capture table. `func`
    /// is the callee proto, `index` the descriptor entry, `pc`/`span`
    /// the `closure` instruction that would install the captures.
    CaptureSourceOutOfRange {
        pc: usize,
        func: usize,
        index: usize,
        span: Span,
    },
    /// `closure` operand beyond the proto table.
    ProtoIndexOutOfRange { pc: usize, index: usize, span: Span },
    /// `jump` / `jump-if-false` target beyond the code sequence.
    JumpTargetOutOfRange {
        pc: usize,
        target: usize,
        span: Span,
    },
    /// An `assign` inside a closure targets a name the enclosing
    /// scope binds (Stage 2.1 LA-7): the first-cut subset keeps
    /// captures immutable, so the target is a definite rejection —
    /// never a silent global store. The checker reports the same
    /// boundary as E0012; this arm is the compile-side defense for
    /// hand-built or API-fed `CoreExpr`.
    AssignToCaptured { name: Symbol, span: Span },
    /// `load-captured` operand beyond the proto's capture table
    /// (Stage 2.1 LA-3): only hand-built data reaches this arm —
    /// compile products index their own descriptor tables by
    /// construction, and `verify` checks every descriptor against
    /// its defining frame.
    CaptureIndexOutOfRange { pc: usize, index: usize, span: Span },
    /// `debug_info` is not parallel to `code` (a bare instruction —
    /// §19.3 invariant 3; the missing span is the defect itself).
    DebugInfoMissing { func: usize, pc: usize },
    /// The proto does not end with `ret` or `halt`.
    MissingTerminator { func: usize, pc: usize },
    /// `halt` appeared in a non-entry proto (entry = `funcs[0]`).
    HaltOutsideEntry { pc: usize, span: Span },
    /// The bytecode has no proto at all (compile output always has the
    /// entry proto; only hand-built data can trigger this).
    EmptyFuncTable,
}

impl fmt::Display for CompileError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            // §9.56 DIAG-1: position fragments stay out of Display —
            // the message is general and stands on its own (rustc
            // convention); spans live in the payload and the driver
            // renders them as the `--> file:line:col` location line.
            // pc/func/slot/index operands stay: they are semantic
            // payloads of the defect, not source positions.
            CompileError::DepthExceeded { depth, .. } => write!(
                f,
                "compile depth `{depth}` exceeds limit `{}`",
                crate::COMPILE_DEPTH_LIMIT
            ),
            CompileError::UnpatchedJump { at, .. } => {
                write!(f, "unpatched jump placeholder at `{at}`")
            }
            CompileError::StackUnderflow { pc, .. } => {
                write!(f, "stack underflow at pc `{pc}`")
            }
            CompileError::StackImbalance {
                pc,
                expected,
                actual,
                ..
            } => write!(
                f,
                "stack depth `{actual}` at pc `{pc}` disagrees with predecessor depth `{expected}`"
            ),
            CompileError::ConstIndexOutOfRange { pc, index, .. } => {
                write!(f, "constant index `{index}` out of range at pc `{pc}`")
            }
            CompileError::GlobalIndexOutOfRange { pc, index, .. } => {
                write!(f, "global index `{index}` out of range at pc `{pc}`")
            }
            CompileError::LocalSlotOutOfRange { pc, slot, .. } => {
                write!(f, "local slot `{slot}` out of range at pc `{pc}`")
            }
            CompileError::CaptureSourceOutOfRange {
                pc, func, index, ..
            } => {
                write!(
                    f,
                    "capture entry `{index}` of func `{func}` names a source outside the defining frame at pc `{pc}`"
                )
            }
            CompileError::ProtoIndexOutOfRange { pc, index, .. } => {
                write!(f, "proto index `{index}` out of range at pc `{pc}`")
            }
            CompileError::JumpTargetOutOfRange { pc, target, .. } => {
                write!(f, "jump target `{target}` out of range at pc `{pc}`")
            }
            CompileError::AssignToCaptured { name, .. } => write!(
                f,
                "cannot assign to captured variable `{name}` (captures are immutable in the current subset)"
            ),
            CompileError::CaptureIndexOutOfRange { pc, index, .. } => {
                write!(f, "capture index `{index}` out of range at pc `{pc}`")
            }
            CompileError::DebugInfoMissing { func, pc } => write!(
                f,
                "debug info missing for func `{func}` pc `{pc}` (bare instruction)"
            ),
            CompileError::MissingTerminator { func, pc } => write!(
                f,
                "func `{func}` must end with `ret` or `halt` (last pc `{pc}`)"
            ),
            CompileError::HaltOutsideEntry { pc, .. } => {
                write!(f, "`halt` outside entry proto at pc `{pc}`")
            }
            CompileError::EmptyFuncTable => {
                f.write_str("bytecode has no function proto (entry proto missing)")
            }
        }
    }
}

impl std::error::Error for CompileError {}

impl CompileError {
    /// The byte-precise source span of the offending construct, when
    /// the variant carries one. The three product-shape variants
    /// (`DebugInfoMissing`, `MissingTerminator`, `EmptyFuncTable`)
    /// carry no span on purpose: the missing span *is* the defect
    /// being reported, and a fabricated location would be a DUMMY
    /// span. The driver's diagnostic layer (plan sub-stage 0.8)
    /// renders `Some` spans with an excerpt and `None` without a
    /// location line.
    pub fn span(&self) -> Option<Span> {
        match self {
            CompileError::DepthExceeded { span, .. }
            | CompileError::UnpatchedJump { span, .. }
            | CompileError::StackUnderflow { span, .. }
            | CompileError::StackImbalance { span, .. }
            | CompileError::ConstIndexOutOfRange { span, .. }
            | CompileError::GlobalIndexOutOfRange { span, .. }
            | CompileError::LocalSlotOutOfRange { span, .. }
            | CompileError::CaptureSourceOutOfRange { span, .. }
            | CompileError::ProtoIndexOutOfRange { span, .. }
            | CompileError::JumpTargetOutOfRange { span, .. }
            | CompileError::AssignToCaptured { span, .. }
            | CompileError::CaptureIndexOutOfRange { span, .. }
            | CompileError::HaltOutsideEntry { span, .. } => Some(*span),
            CompileError::DebugInfoMissing { .. }
            | CompileError::MissingTerminator { .. }
            | CompileError::EmptyFuncTable => None,
        }
    }
}

#[cfg(test)]
mod tests {
    //! CompileError surface tests (FP1): construction, span/pc payloads,
    //! R8 message shapes (lowercase start, no trailing period, backtick
    //! payloads, technical anchors kept verbatim).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    #[test]
    fn depth_exceeded_display_keeps_r8_shape() {
        // §9.56 DIAG-1: position-free — the span lives in the payload.
        let err = CompileError::DepthExceeded {
            depth: 1025,
            span: span(3, 7),
        };
        assert_eq!(err.to_string(), "compile depth `1025` exceeds limit `1024`");
    }

    #[test]
    fn unpatched_jump_and_underflow_display_forms() {
        // §9.56 DIAG-1: position-free — pc operands stay (semantic
        // payloads), span fragments go (payload-only).
        let unpatched = CompileError::UnpatchedJump {
            at: 4,
            span: span(0, 2),
        };
        assert_eq!(unpatched.to_string(), "unpatched jump placeholder at `4`");
        let underflow = CompileError::StackUnderflow {
            pc: 9,
            span: span(1, 3),
        };
        assert_eq!(underflow.to_string(), "stack underflow at pc `9`");
    }

    #[test]
    fn capture_source_out_of_range_display_and_span() {
        // Stage 2.1 LA-2: the descriptor violation names the callee
        // proto, the descriptor entry, and the installing `closure`
        // pc — R8 shape (lowercase start, no trailing period, payload
        // backticks), span carried for the driver's location line.
        let err = CompileError::CaptureSourceOutOfRange {
            pc: 5,
            func: 1,
            index: 2,
            span: span(4, 9),
        };
        assert_eq!(
            err.to_string(),
            "capture entry `2` of func `1` names a source outside the defining frame at pc `5`"
        );
        assert_eq!(err.span(), Some(span(4, 9)));
    }

    #[test]
    fn stack_imbalance_names_both_depths() {
        let err = CompileError::StackImbalance {
            pc: 6,
            expected: 1,
            actual: 2,
            span: span(10, 12),
        };
        let msg = err.to_string();
        assert!(msg.starts_with("stack depth `2` at pc `6` disagrees with predecessor depth `1`"));
        assert!(!msg.ends_with('.'));
    }

    #[test]
    fn index_range_family_display_forms() {
        let cases = [
            (
                CompileError::ConstIndexOutOfRange {
                    pc: 1,
                    index: 3,
                    span: span(0, 1),
                },
                "constant index `3` out of range at pc `1`",
            ),
            (
                CompileError::GlobalIndexOutOfRange {
                    pc: 2,
                    index: 0,
                    span: span(0, 1),
                },
                "global index `0` out of range at pc `2`",
            ),
            (
                CompileError::LocalSlotOutOfRange {
                    pc: 3,
                    slot: 5,
                    span: span(0, 1),
                },
                "local slot `5` out of range at pc `3`",
            ),
            (
                CompileError::ProtoIndexOutOfRange {
                    pc: 4,
                    index: 1,
                    span: span(0, 1),
                },
                "proto index `1` out of range at pc `4`",
            ),
            (
                CompileError::JumpTargetOutOfRange {
                    pc: 5,
                    target: 8,
                    span: span(0, 1),
                },
                "jump target `8` out of range at pc `5`",
            ),
        ];
        for (err, prefix) in &cases {
            let msg = err.to_string();
            assert!(
                msg.starts_with(prefix),
                "message `{msg}` must start with `{prefix}`"
            );
            assert!(!msg.ends_with('.'), "no trailing period in `{msg}`");
        }
    }

    #[test]
    fn spanless_variants_report_structural_position() {
        let missing = CompileError::DebugInfoMissing { func: 2, pc: 4 };
        assert_eq!(
            missing.to_string(),
            "debug info missing for func `2` pc `4` (bare instruction)"
        );
        let term = CompileError::MissingTerminator { func: 1, pc: 6 };
        assert_eq!(
            term.to_string(),
            "func `1` must end with `ret` or `halt` (last pc `6`)"
        );
        let empty = CompileError::EmptyFuncTable;
        assert_eq!(
            empty.to_string(),
            "bytecode has no function proto (entry proto missing)"
        );
    }

    #[test]
    fn halt_outside_entry_display_form() {
        let err = CompileError::HaltOutsideEntry {
            pc: 2,
            span: span(8, 9),
        };
        assert_eq!(err.to_string(), "`halt` outside entry proto at pc `2`");
    }

    #[test]
    fn variants_carry_pc_depth_and_span_payloads() {
        // Payload assertions: product-side variants keep pc + span,
        // compile-side keep depth + span (FP1 contract).
        let e = CompileError::StackUnderflow {
            pc: 12,
            span: span(4, 6),
        };
        match e {
            CompileError::StackUnderflow {
                pc: 12,
                span: payload,
            } => {
                assert_eq!(payload, span(4, 6));
            }
            other => panic!("wrong variant: {other}"),
        }
        let d = CompileError::DepthExceeded {
            depth: 2000,
            span: span(0, 9),
        };
        assert!(matches!(d, CompileError::DepthExceeded { depth: 2000, .. }));
    }

    #[test]
    fn error_trait_is_implemented_for_boxing() {
        // The 0.8 diagnostics renderer composes error sources; the trait
        // must be implemented even though compile errors have no source
        // chain (inputs are pre-validated).
        let err: Box<dyn std::error::Error> = Box::new(CompileError::EmptyFuncTable);
        assert_eq!(err.to_string(), CompileError::EmptyFuncTable.to_string());
    }

    /// 0.8 consumer-face extension: the ten spanned variants expose
    /// their span, the three product-shape variants expose none (the
    /// missing span is the defect itself — no DUMMY fabrication).
    #[test]
    fn span_extraction_matches_variant_kind() {
        let spanned = vec![
            CompileError::DepthExceeded {
                depth: 1025,
                span: span(0, 1),
            },
            CompileError::UnpatchedJump {
                at: 2,
                span: span(0, 1),
            },
            CompileError::StackUnderflow {
                pc: 3,
                span: span(0, 1),
            },
            CompileError::StackImbalance {
                pc: 4,
                expected: 1,
                actual: 2,
                span: span(0, 1),
            },
            CompileError::ConstIndexOutOfRange {
                pc: 5,
                index: 9,
                span: span(0, 1),
            },
            CompileError::GlobalIndexOutOfRange {
                pc: 6,
                index: 9,
                span: span(0, 1),
            },
            CompileError::LocalSlotOutOfRange {
                pc: 7,
                slot: 9,
                span: span(0, 1),
            },
            CompileError::ProtoIndexOutOfRange {
                pc: 8,
                index: 9,
                span: span(0, 1),
            },
            CompileError::JumpTargetOutOfRange {
                pc: 9,
                target: 99,
                span: span(0, 1),
            },
            CompileError::AssignToCaptured {
                name: Symbol::new("n").expect("fixture symbol"),
                span: span(0, 1),
            },
            CompileError::CaptureIndexOutOfRange {
                pc: 10,
                index: 3,
                span: span(0, 1),
            },
            CompileError::HaltOutsideEntry {
                pc: 10,
                span: span(0, 1),
            },
        ];
        for (i, err) in spanned.iter().enumerate() {
            assert_eq!(
                err.span(),
                Some(span(0, 1)),
                "variant {i} must expose its span"
            );
        }
        let spanless = [
            CompileError::DebugInfoMissing { func: 0, pc: 1 },
            CompileError::MissingTerminator { func: 0, pc: 2 },
            CompileError::EmptyFuncTable,
        ];
        for (i, err) in spanless.iter().enumerate() {
            assert!(err.span().is_none(), "variant {i} must not fake a span");
        }
    }

    /// The extracted span is the exact payload, not a neighboring
    /// variant's position.
    #[test]
    fn span_extraction_returns_payload_span() {
        assert_eq!(
            CompileError::HaltOutsideEntry {
                pc: 3,
                span: span(11, 22)
            }
            .span(),
            Some(span(11, 22))
        );
    }

    /// Stage 2.1 LA-7 arm: lowercase start, no trailing period, the
    /// name payload in backticks, the subset note in parentheses
    /// (the checker's E0012 mirrors the same wording family — the
    /// single-source dictionary).
    #[test]
    fn assign_to_captured_display_keeps_r8_shape() {
        let err = CompileError::AssignToCaptured {
            name: Symbol::new("start").expect("fixture symbol"),
            span: span(4, 9),
        };
        assert_eq!(
            err.to_string(),
            "cannot assign to captured variable `start` (captures are immutable in the current subset)"
        );
        assert_eq!(err.span(), Some(span(4, 9)));
    }

    /// Stage 2.1 LA-3 arm: the operand-bounds message mirrors the
    /// local-slot family.
    #[test]
    fn capture_index_out_of_range_display_keeps_r8_shape() {
        let err = CompileError::CaptureIndexOutOfRange {
            pc: 6,
            index: 2,
            span: span(2, 5),
        };
        assert_eq!(err.to_string(), "capture index `2` out of range at pc `6`");
        assert_eq!(err.span(), Some(span(2, 5)));
    }
}

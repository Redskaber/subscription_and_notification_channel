//! kerf-compiler — bytecode generation (Layer 5).
//!
//! Charter (docs/stage0.md §19.3): CoreExpr -> Bytecode with jump
//! backpatching, a deduplicated constant pool, an interned global
//! symbol table, and a debug_info_table mapping every pc back to a
//! source span (docs/stage0.md §12.1 consumption table). The 24-op
//! set covers the §8.12 groups plus the Perform/Handle carriers; the
//! 0.6 VM executes it and resolves runtime errors through
//! [`Bytecode::span_of`].
//!
//! Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
//! (depth caps, patch assertions, placeholder drain) fails closed
//! with structured errors, and [`Bytecode::verify`] re-checks the
//! product (operand bounds, debug-info parallelism, DAG stack-depth
//! propagation) — the VM load-time hook.
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c),
//! implemented at sub-stage 0.5 (TD-003 resolution step 1 of 4).

mod bytecode;
mod compile;
mod error;
mod opcode;
mod verify;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use bytecode::{Bytecode, CaptureSource, FuncProto, Instr};
pub use compile::{compile, compile_program};
pub use error::CompileError;
pub use opcode::Opcode;

// Since v0.28.0 this crate re-exports nothing from kerf-core or
// kerf-span (the no-forwarding rule, stage0.md §9.59): the types this
// crate's API mentions (`CoreExpr`/`ModuleItem`/`LiteralValue`/`Span`/
// `Symbol`/...) are imported by consumers directly from their defining
// crates — kerf-core for the core AST family, kerf-span for the
// coordinate/identity family (the rustc_ast precedent, §9.59 K81;
// SOP §18.5 v15.2 replaces the former "no direct edge" passthrough
// policy that made these re-exports structurally necessary).

/// Compile-recursion depth cap: 2× the expander budget (512) — the
/// same 2× headroom ratio the expander keeps over the reader cap
/// (256). Expander output is structurally bounded below this; only
/// synthesized trees can exceed it, and they fail closed with
/// [`CompileError::DepthExceeded`] (never a stack overflow — §19.2
/// invariant 1 mirrored on the compiler side).
pub const COMPILE_DEPTH_LIMIT: usize = 1024;

/// Jump placeholder sentinel emitted by `emit_jump`: never a valid pc
/// (it equals u32::MAX); `finish` drains unpatched placeholders and
/// `verify` rejects any survivor as an out-of-range target.
pub const JUMP_PLACEHOLDER: u32 = u32::MAX;

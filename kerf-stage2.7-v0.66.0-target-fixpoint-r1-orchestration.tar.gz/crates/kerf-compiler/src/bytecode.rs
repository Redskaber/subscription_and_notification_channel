//! Bytecode: the in-memory compilation product (sub-stage 0.5).
//!
//! Pure data, hand-constructible for tests; [`crate::Bytecode::verify`]
//! is the single legality judge (plan-0.5.md ruling 4). The layout
//! follows docs/stage0.md §19.3: a proto table (`funcs[0]` = entry
//! toplevel), a deduplicated constant pool, an interned global symbol
//! table, and a per-instruction debug_info table parallel to code
//! (§19.3 invariant 3 — no bare instructions; §12.1 consumption table:
//! the VM resolves runtime errors back to source through it).

use std::fmt;

use kerf_core::LiteralValue;
use kerf_span::{Span, Symbol};

use crate::opcode::Opcode;

/// One instruction: opcode plus two u32 operand slots; an unused slot
/// is always 0 (semantics per [`Opcode::operand_help`]).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Instr {
    pub op: Opcode,
    pub a: u32,
    pub b: u32,
}

impl Instr {
    /// Build an instruction (operand slots default to 0).
    pub fn new(op: Opcode) -> Self {
        Instr { op, a: 0, b: 0 }
    }

    /// Build an instruction with the `a` operand.
    pub fn with_a(op: Opcode, a: u32) -> Self {
        Instr { op, a, b: 0 }
    }

    /// Build an instruction with both operands.
    pub fn with_ab(op: Opcode, a: u32, b: u32) -> Self {
        Instr { op, a, b }
    }
}

impl fmt::Display for Instr {
    /// Machine form `op a b` (fixed three fields — unambiguous for
    /// zero-valued operands such as `jump 0 0`).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} {} {}", self.op.kind_name(), self.a, self.b)
    }
}

/// One capture requirement of a closure proto: where the *defining*
/// frame holds the value at closure-creation time (Stage 2.1 LA-2 —
/// flat-capture descriptor, the two-source form of Lua 5.4
/// `Upvaldesc { instack, idx }`; `Bytecode::verify` validates every
/// descriptor against the proto that encloses the `closure`
/// instruction). Since the LA-1/LA-4 semantic MUV the compiler fills
/// the table with its capture analysis (free names an enclosing
/// proto holds, in first-use order); `load-captured` reads the
/// installed values by index (LA-3).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum CaptureSource {
    /// A local slot of the proto that encloses the `closure`
    /// instruction (Lua `instack = 1`).
    Local(u32),
    /// An index in the *defining closure's own* capture area — a
    /// transitive capture (Lua `instack = 0`; the LA-4 pass-through
    /// case: an inner closure re-capturing an outer value its
    /// enclosing closure itself captured).
    Captured(u32),
}

/// One subroutine: the entry toplevel proto or a closure proto.
#[derive(Debug, Clone, PartialEq)]
pub struct FuncProto {
    /// Diagnostic name (the `define`d name for named closures; the
    /// entry proto has none).
    pub name: Option<Symbol>,
    /// Parameter count (the entry proto takes none).
    pub params: u32,
    /// Total local slots (parameters occupy 0..params first; let-form
    /// slots recycle through a per-proto LIFO free-list at scope exit,
    /// so this is the peak simultaneous binding count, not the
    /// cumulative one — Lua `freereg` discipline, valid because
    /// compile products are back-edge-free).
    pub n_locals: u32,
    /// Flat-capture descriptor table (Stage 2.1 LA-2): entry `i` says
    /// where the defining frame holds the value that this proto's
    /// closure body will read as capture `i`. Keyed by slot/capture
    /// indices, never by name text (the §9.52.5 Symbol identity base
    /// serves the compiler-side analysis; the product lands as
    /// indices). Filled by the compiler's capture analysis since the
    /// LA-1/LA-4 semantic MUV (first-use order); `Bytecode`'s
    /// `PartialEq` absorbs the field, so the gate-B bytecode-identity
    /// oracle covers it without any codec change.
    pub captures: Vec<CaptureSource>,
    /// Instruction sequence (pc = index).
    pub code: Vec<Instr>,
    /// Per-instruction source spans, parallel to `code`.
    pub debug_info: Vec<Span>,
}

impl FuncProto {
    /// Build a proto with empty code/debug_info/captures.
    pub fn new(name: Option<Symbol>, params: u32, n_locals: u32) -> Self {
        FuncProto {
            name,
            params,
            n_locals,
            captures: Vec::new(),
            code: Vec::new(),
            debug_info: Vec::new(),
        }
    }
}

/// The compilation product (`funcs[0]` = entry proto).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Bytecode {
    pub funcs: Vec<FuncProto>,
    /// Deduplicated constant pool (NaN-canonicalized keys; +0.0/-0.0
    /// stay distinct slots — bit-pattern keys keep map consistency).
    pub consts: Vec<LiteralValue>,
    /// Interned global symbol table (same name -> same slot).
    pub globals: Vec<Symbol>,
}

impl Bytecode {
    /// Resolve the source span of `(func, pc)` — the §12.1
    /// compiler-side consumption row; the 0.6 VM walks runtime errors
    /// back to source through this face.
    pub fn span_of(&self, func: usize, pc: usize) -> Option<Span> {
        self.funcs.get(func)?.debug_info.get(pc).copied()
    }

    /// The entry proto (`funcs[0]`).
    pub fn entry(&self) -> Option<&FuncProto> {
        self.funcs.first()
    }
}

#[cfg(test)]
mod tests {
    //! Bytecode data-shape tests (FP3): constructors, accessors, and
    //! the span_of lookup contract (hit plus both miss directions).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sample_bytecode() -> Bytecode {
        let mut proto = FuncProto::new(None, 0, 1);
        proto.code = vec![
            Instr::with_a(Opcode::LoadLocal, 0),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![span(4, 8), span(4, 8)];
        let mut bc = Bytecode::default();
        bc.funcs.push(proto);
        bc.consts.push(LiteralValue::Int(7));
        bc.globals.push(Symbol::new("+").expect("fixture symbol"));
        bc
    }

    #[test]
    fn instr_builders_and_display_form() {
        let plain = Instr::new(Opcode::Ret);
        assert_eq!(
            plain,
            Instr {
                op: Opcode::Ret,
                a: 0,
                b: 0
            }
        );
        let one = Instr::with_a(Opcode::Call, 2);
        assert_eq!(one.b, 0);
        let both = Instr::with_ab(Opcode::Perform, 3, 2);
        assert_eq!(
            both,
            Instr {
                op: Opcode::Perform,
                a: 3,
                b: 2
            }
        );
        assert_eq!(plain.to_string(), "ret 0 0");
        assert_eq!(one.to_string(), "call 2 0");
        assert_eq!(both.to_string(), "perform 3 2");
    }

    #[test]
    fn proto_and_bytecode_accessors() {
        let bc = sample_bytecode();
        let entry = bc.entry().expect("entry proto present");
        assert!(entry.name.is_none());
        assert_eq!(entry.params, 0);
        assert_eq!(entry.n_locals, 1);
        assert_eq!(entry.code.len(), 2);
        assert_eq!(bc.consts.len(), 1);
        assert_eq!(bc.globals.len(), 1);
        assert_eq!(bc.globals[0].as_str(), "+");
    }

    #[test]
    fn capture_field_defaults_empty_and_joins_equality() {
        // LA-2 landing discipline: every constructor leaves the table
        // empty (zero-production until the LA-1/LA-3 semantic MUV),
        // and the field participates in `PartialEq` — the gate-B
        // bytecode-identity oracle absorbs it structurally.
        let fresh = FuncProto::new(None, 0, 1);
        assert!(fresh.captures.is_empty());
        let mut with_local = FuncProto::new(None, 0, 1);
        with_local.captures.push(CaptureSource::Local(0));
        let mut with_transitive = FuncProto::new(None, 0, 1);
        with_transitive.captures.push(CaptureSource::Captured(0));
        assert_eq!(fresh, fresh.clone());
        assert_ne!(fresh, with_local);
        assert_ne!(with_local, with_transitive);
        assert_eq!(with_local.captures, vec![CaptureSource::Local(0)]);
    }

    #[test]
    fn span_of_misses_on_unknown_func() {
        let bc = sample_bytecode();
        assert!(bc.span_of(1, 0).is_none());
    }

    #[test]
    fn span_of_misses_on_out_of_range_pc() {
        let bc = sample_bytecode();
        assert!(bc.span_of(0, 2).is_none());
        assert!(bc.span_of(0, 0).is_some());
    }
}

//! kerf-cbackend — the C transpilation backend (Stage 2.6, stage0.md
//! §9.92; the r90 adjudication II implementation slice).
//!
//! Constitutional position: **chain-external, never part of the
//! bootstrap chain** — building the kerf compiler never invokes a C
//! compiler; this crate is a pure consumer of the frozen bytecode
//! product and is optional at every consumption site (the e2e
//! harnesses skip with disclosure when the host lacks `cc`).
//!
//! The three layers (architecture-review.md obligation row 3):
//! 1. **Emitter** ([`emit_c`]): verified [`kerf_compiler::Bytecode`]
//!    → one self-contained C translation unit (per-proto functions
//!    with statically addressed operand stacks, `goto` control flow,
//!    a single generated call trampoline, bit-pattern floats, byte
//!    arrays for strings — total determinism).
//! 2. **Host runtime shim** ([`shim_source`]): the embedded C text
//!    (`kerf_rt.h`) every generated file carries — the value model,
//!    the cell arena (no GC first cut, budget fail-closed), the
//!    18-builtin dispatch, the handler stack, and the Rust-parity
//!    float display.
//! 3. **cc-gated e2e**: the verification face lives in the root
//!    integration tests and the audit AA section — cc-absent
//!    environments skip with disclosure, never fail.

mod depth;
mod emit;

use std::fmt;

use kerf_compiler::{Bytecode, CompileError};

/// Why a product refused to transpile.
#[derive(Debug, Clone, PartialEq)]
pub enum EmitError {
    /// The product failed `Bytecode::verify` — the emitter only
    /// consumes verified products (fail-closed against hand-built
    /// or corrupted input).
    Verify(CompileError),
    /// A `closure` instruction referenced the entry proto: its
    /// `halt` is machine-stopping in the VM and cannot become a
    /// returning C call (compile products never produce this shape).
    EntryProtoAsClosure {
        /// The pc of the offending `closure` instruction.
        pc: usize,
    },
    /// The entry proto carries capture descriptors — the runtime
    /// installs none at top level (the VM panics on such hand-built
    /// data; the emitter fails closed instead).
    EntryCaptures,
    /// The depth analysis (the `verify` mirror) disagreed — reachable
    /// only through unverified input; the defense-in-depth layer.
    DepthUnverified {
        /// The pc where the analysis refused to continue.
        pc: usize,
    },
}

impl fmt::Display for EmitError {
    /// R8 family: lowercase start, no trailing period, backticked
    /// payloads (mirrors the CompileError/Display conventions).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            EmitError::Verify(err) => write!(f, "unverified bytecode: {err}"),
            EmitError::EntryProtoAsClosure { pc } => write!(
                f,
                "closure over the entry proto at pc `{pc}` (the entry halt is machine-stopping)"
            ),
            EmitError::EntryCaptures => {
                write!(f, "the entry proto carries capture descriptors")
            }
            EmitError::DepthUnverified { pc } => {
                write!(f, "depth analysis refused at pc `{pc}` (unverified input)")
            }
        }
    }
}

impl std::error::Error for EmitError {}

/// Transpile a verified bytecode product to one self-contained C
/// translation unit.
///
/// Runs `Bytecode::verify` first (fail-closed), then the two
/// transpilation-shaped structural guards, then emits. Deterministic:
/// identical input emits byte-identical output (no map iteration
/// reaches the output order — pinned by unit tests).
pub fn emit_c(bc: &Bytecode) -> Result<String, EmitError> {
    bc.verify().map_err(EmitError::Verify)?;
    emit::emit_verified(bc)
}

/// The embedded host runtime shim (`kerf_rt.h`), verbatim — the
/// single source for cross-checks (the builtin-name parity guards in
/// the unit tests and the audit AA section read this text).
pub fn shim_source() -> &'static str {
    emit::SHIM
}

#[cfg(test)]
mod tests {
    //! Public-face tests (FP1/FP2/FP3): determinism, the fail-closed
    //! guards, the single-source parity faces, and the emitted
    //! defines. The behavioral face (cc) lives in the root
    //! integration tests — no unit test here invokes a C compiler.

    use super::*;
    use kerf_compiler::{FuncProto, Instr, Opcode};
    use kerf_core::LiteralValue;
    use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
    use kerf_vm::Builtin;

    fn span() -> Span {
        Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
            .expect("test fixture span must be well-formed")
    }

    fn compile(source: &str) -> Bytecode {
        let forms = kerf_reader::read_program(FileId(0), source).expect("read");
        let items = kerf_expander::expand_program(&forms).expect("expand");
        kerf_compiler::compile_program(&items).expect("compile")
    }

    fn fib_product() -> Bytecode {
        compile(
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 6))",
        )
    }

    #[test]
    fn emission_is_deterministic_byte_for_byte() {
        let bc = fib_product();
        let first = emit_c(&bc).expect("emits");
        let second = emit_c(&bc).expect("emits again");
        assert_eq!(first, second, "identical input must emit identical C");
        assert!(
            first.contains(&format!(
                "generated by kerf emit-c {}",
                env!("CARGO_PKG_VERSION")
            )),
            "the header pins the workspace version"
        );
        assert!(
            first.contains("chain-external; never part of the bootstrap chain"),
            "the header states the constitutional position"
        );
    }

    #[test]
    fn unverified_input_fails_closed() {
        // Truncated debug_info: verify rejects before any emission.
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![Instr::new(Opcode::Halt)];
        proto.debug_info = vec![];
        let mut bc = Bytecode::default();
        bc.funcs.push(proto);
        assert!(matches!(
            emit_c(&bc),
            Err(EmitError::Verify(CompileError::DebugInfoMissing { .. }))
        ));
    }

    #[test]
    fn closure_over_the_entry_proto_is_rejected() {
        // Hand-built: closure 0 inside the entry proto (verify passes
        // — proto index 0 exists; the emitter refuses the shape).
        let mut entry = FuncProto::new(None, 0, 0);
        entry.code = vec![
            Instr::with_a(Opcode::Closure, 0),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        entry.debug_info = vec![span(); 3];
        let mut bc = Bytecode::default();
        bc.funcs.push(entry);
        assert_eq!(emit_c(&bc), Err(EmitError::EntryProtoAsClosure { pc: 0 }));
    }

    #[test]
    fn entry_capture_descriptors_are_rejected() {
        // Hand-built: the entry proto carries one descriptor (verify
        // allows it; the runtime installs none — the VM would panic).
        let mut entry = FuncProto::new(None, 0, 0);
        entry.captures.push(kerf_compiler::CaptureSource::Local(0));
        entry.code = vec![Instr::new(Opcode::Halt)];
        entry.debug_info = vec![span()];
        let mut bc = Bytecode::default();
        bc.funcs.push(entry);
        assert_eq!(emit_c(&bc), Err(EmitError::EntryCaptures));
    }

    #[test]
    fn shim_names_every_registry_builtin_exactly_once() {
        // The drift guard between Builtin::ALL (the Rust single
        // source) and the shim's name/arity arms: every registry
        // name must appear in the shim text as a quoted string.
        let shim = shim_source();
        for (_, name, _) in Builtin::ALL {
            assert!(
                shim.contains(&format!("\"{name}\"")),
                "the shim must name builtin `{name}` (Builtin::ALL parity)"
            );
        }
    }

    #[test]
    fn every_opcode_has_an_emission_path_over_a_real_product() {
        // A program whose product touches every opcode family the
        // SOURCE surface reaches (pair literals ride the constant
        // pool, so `make-pair` never appears in compile products —
        // the hand-built fixture below covers it plus dup/swap/pop).
        let bc = compile(concat!(
            "(define (add a b) (+ a b))\n",
            "(define pair1 (cons 1 nil))\n",
            "(define letsum (let ((a 2) (b 3)) (+ a b)))\n",
            "(define hd (car pair1))\n",
            "(define tl (cdr pair1))\n",
            "(define r (handle (perform add 1 2) (add (fn (a b) (+ a b)))))\n",
            "(define s (if (= hd 1) (write-line \"yes\") (write-line \"no\")))\n",
            "(define f (fn (x) (fn (y) (+ x y))))\n",
            "(define g (f 3))\n",
            "(define result (g 4))\n",
        ));
        let c = emit_c(&bc).expect("emits");
        for marker in [
            "push-const",
            "call",
            "ret",
            "closure",
            "jump-if-false",
            "load-local",
            "store-local",
            "load-global",
            "store-global",
            "load-captured",
            "push-handler",
            "pop-handler",
            "perform",
            "halt",
        ] {
            assert!(
                c.contains(&format!(": {marker} */")),
                "opcode family `{marker}` must appear in the emission"
            );
        }
        // The hand-built complement: the stack-shape, pair-shape,
        // and arithmetic opcodes no compile product reaches (pairs
        // and arithmetic go through builtins; literals through the
        // constant pool — never the raw opcodes).
        let mut proto = FuncProto::new(None, 0, 1);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Add),
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Sub),
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Mul),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Div),
            Instr::new(Opcode::Dup),
            Instr::new(Opcode::MakePair),
            Instr::with_a(Opcode::StoreLocal, 0),
            Instr::with_a(Opcode::LoadLocal, 0),
            Instr::new(Opcode::Car),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Swap),
            Instr::new(Opcode::Cdr),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![span(); 20];
        let hb = Bytecode {
            consts: vec![LiteralValue::Int(1), LiteralValue::Nil],
            funcs: vec![proto],
            ..Default::default()
        };
        let ch = emit_c(&hb).expect("emits hand-built");
        for marker in [
            "make-pair",
            "dup",
            "swap",
            "pop",
            "car",
            "cdr",
            "add",
            "sub",
            "mul",
            "div",
        ] {
            assert!(
                ch.contains(&format!(": {marker} */")),
                "stack-shape opcode `{marker}` must appear in the emission"
            );
        }
    }

    #[test]
    fn emitted_defines_pin_budget_and_depth_guard() {
        let c = emit_c(&fib_product()).expect("emits");
        assert!(c.contains("#ifndef K_BUDGET"));
        assert!(c.contains("#define K_BUDGET 8388608u"));
        assert!(c.contains("#ifndef K_DEPTH_CAP"));
        assert!(c.contains("#define K_DEPTH_CAP "), "computed guard present");
        // Overridability: both defines sit behind #ifndef guards, so
        // `-DK_BUDGET=...` / `-DK_DEPTH_CAP=...` win at cc time (the
        // e2e budget/depth fail-closed faces ride this).
        let ifndefs = c.matches("#ifndef").count();
        assert!(ifndefs >= 3, "shim guard + two overridable defines");
    }

    #[test]
    fn constants_empty_and_globals_empty_products_still_emit() {
        // The zero-size C array trap: an entry-only halt with no
        // consts and no globals must still produce compilable text.
        let mut entry = FuncProto::new(None, 0, 0);
        entry.code = vec![Instr::new(Opcode::Halt)];
        entry.debug_info = vec![span()];
        let mut bc = Bytecode::default();
        bc.funcs.push(entry);
        let c = emit_c(&bc).expect("emits");
        assert!(!c.contains("k_const_table["));
        assert!(!c.contains("k_gstore["));
        assert!(c.contains("int main(void)"));
    }

    #[test]
    fn error_displays_follow_the_r8_family() {
        let cases = [
            (
                EmitError::EntryProtoAsClosure { pc: 7 },
                "closure over the entry proto at pc `7` (the entry halt is machine-stopping)",
            ),
            (
                EmitError::EntryCaptures,
                "the entry proto carries capture descriptors",
            ),
            (
                EmitError::DepthUnverified { pc: 3 },
                "depth analysis refused at pc `3` (unverified input)",
            ),
        ];
        for (err, expected) in cases {
            let text = err.to_string();
            assert!(text.starts_with(|c: char| c.is_lowercase()));
            assert!(!text.ends_with('.'));
            assert_eq!(text, expected);
        }
        assert!(
            EmitError::Verify(CompileError::EmptyFuncTable)
                .to_string()
                .starts_with("unverified bytecode:")
        );
    }

    #[test]
    fn literal_kinds_all_reach_the_const_pool_shape() {
        let bc = {
            let mut proto = FuncProto::new(None, 0, 0);
            proto.code = vec![
                Instr::with_a(Opcode::PushConst, 0),
                Instr::new(Opcode::Pop),
                Instr::with_a(Opcode::PushConst, 1),
                Instr::new(Opcode::Pop),
                Instr::with_a(Opcode::PushConst, 2),
                Instr::new(Opcode::Pop),
                Instr::with_a(Opcode::PushConst, 3),
                Instr::new(Opcode::Pop),
                Instr::with_a(Opcode::PushConst, 4),
                Instr::new(Opcode::Halt),
            ];
            proto.debug_info = vec![span(); 10];
            Bytecode {
                consts: vec![
                    LiteralValue::Int(-41),
                    LiteralValue::Float(2.5),
                    LiteralValue::Bool(true),
                    LiteralValue::String("s".into()),
                    LiteralValue::Nil,
                ],
                funcs: vec![proto],
                ..Default::default()
            }
        };
        let c = emit_c(&bc).expect("emits");
        assert!(c.contains(".kind = 0, .cells = 0u, .as.i = INT64_C(-41)"));
        assert!(c.contains(".kind = 1, .cells = 0u, .as.bits = UINT64_C(0x"));
        assert!(c.contains(".kind = 2, .cells = 0u, .as.b = 1"));
        assert!(c.contains(".kind = 3, .cells = 0u, .as.s.p = (const char *)kcs"));
        assert!(c.contains(".kind = 4, .cells = 0u"));
    }
}

//! Stack-depth analysis for the C emitter (stage0.md §9.92).
//!
//! [`super::emit_c`] requires, for every reachable instruction, the
//! operand-stack depth *on entry* — the generated C addressing is
//! static (`st[i]` indices, no stack pointer). The analysis mirrors
//! `Bytecode::verify`'s DAG walk exactly (same leaders, same
//! propagation, same disagreement rule), so a verified product can
//! never disagree here; re-running it in the emitter is the
//! defense-in-depth discipline (the LoadLocal-family invariant: the
//! emitter's bare indexing is structurally unreachable on garbage).
//!
//! Unreachable blocks are *not* depth-checked (verify's own rule) and
//! are reported as such — the emitter skips their instructions and
//! plants a fail-closed marker, and a wrongly-unreachable block fails
//! the C compile loudly (a `goto` to a missing label), never a silent
//! misexecution.

use std::collections::{BTreeSet, HashMap, VecDeque};

use kerf_compiler::{FuncProto, Opcode};

/// The per-proto depth analysis product.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ProtoDepth {
    /// Entry depth of every reachable instruction (depth *before*
    /// the instruction executes; missing = unreachable).
    pub depth_in: HashMap<usize, u32>,
    /// The operand-stack size the generated frame must declare:
    /// max over reachable instructions of `depth_in - pops +
    /// pushes`.
    pub stack_size: u32,
}

/// A disagreement or underflow the verifier would have caught —
/// reachable only through unverified input (fail-closed).
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum DepthError {
    Underflow {
        pc: usize,
    },
    Imbalance {
        pc: usize,
        expected: u32,
        actual: u32,
    },
}

fn propagate(
    depth_at: &mut HashMap<usize, u32>,
    queue: &mut VecDeque<usize>,
    target: usize,
    depth: u32,
) -> Result<(), DepthError> {
    match depth_at.get(&target) {
        Some(&recorded) => {
            if recorded != depth {
                return Err(DepthError::Imbalance {
                    pc: target,
                    expected: recorded,
                    actual: depth,
                });
            }
        }
        None => {
            depth_at.insert(target, depth);
            queue.push_back(target);
        }
    }
    Ok(())
}

/// Analyze one proto (the verify mirror; input is expected to be
/// verified — errors here mean the caller skipped `verify`).
pub(crate) fn analyze(proto: &FuncProto) -> Result<ProtoDepth, DepthError> {
    let n = proto.code.len();
    let mut leaders: BTreeSet<usize> = BTreeSet::new();
    leaders.insert(0);
    for (pc, instr) in proto.code.iter().enumerate() {
        if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse) {
            leaders.insert(instr.a as usize);
        }
        if instr.op.is_terminator() && pc < n {
            leaders.insert(pc + 1);
        }
    }
    leaders.retain(|&pc| pc < n);

    let mut depth_at: HashMap<usize, u32> = HashMap::new();
    let mut queue: VecDeque<usize> = VecDeque::new();
    depth_at.insert(0, 0);
    queue.push_back(0);

    let mut depth_in: HashMap<usize, u32> = HashMap::new();
    let mut stack_size: u32 = 0;

    while let Some(start) = queue.pop_front() {
        let mut depth = depth_at[&start];
        let mut pc = start;
        while pc < n {
            let instr = proto.code[pc];
            depth_in.insert(pc, depth);
            let pops = instr.op.pops(instr.a, instr.b);
            if depth < pops {
                return Err(DepthError::Underflow { pc });
            }
            let after = depth - pops + instr.op.pushes();
            stack_size = stack_size.max(after);
            match instr.op {
                Opcode::Jump => {
                    propagate(&mut depth_at, &mut queue, instr.a as usize, after)?;
                    break;
                }
                Opcode::JumpIfFalse => {
                    propagate(&mut depth_at, &mut queue, instr.a as usize, after)?;
                }
                Opcode::Ret => break,
                Opcode::Halt => break,
                _ => {}
            }
            depth = after;
            pc += 1;
            if pc < n && leaders.contains(&pc) {
                propagate(&mut depth_at, &mut queue, pc, depth)?;
                break;
            }
        }
    }

    Ok(ProtoDepth {
        depth_in,
        stack_size,
    })
}

#[cfg(test)]
mod tests {
    //! Depth-analysis tests (FP2/FP3): the entry-depth map, the
    //! stack-size bound, unreachable-block classification, and the
    //! fail-closed defense layer on hand-built garbage.

    use super::*;
    use kerf_compiler::{FuncProto, Instr};
    use kerf_span::{ByteOffset, ExpansionId, FileId, Span};

    fn span() -> Span {
        Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
            .expect("test fixture span must be well-formed")
    }

    fn proto_of(code: Vec<Instr>) -> FuncProto {
        let mut p = FuncProto::new(None, 0, 0);
        p.code = code;
        p.debug_info = vec![span(); p.code.len()];
        p
    }

    #[test]
    fn entry_depths_follow_the_stack_effect_table() {
        // push; push; pop; halt -> depths 0, 1, 2, 1.
        let p = proto_of(vec![
            Instr::new(Opcode::PushConst),
            Instr::new(Opcode::PushConst),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ]);
        let d = analyze(&p).expect("depths");
        assert_eq!(d.depth_in[&0], 0);
        assert_eq!(d.depth_in[&1], 1);
        assert_eq!(d.depth_in[&2], 2);
        assert_eq!(d.depth_in[&3], 1);
        assert_eq!(d.stack_size, 2);
    }

    #[test]
    fn branch_merges_agree_and_report_the_max() {
        // push; push; jump-if-false 4 (pops the condition, target 4
        // at depth 1); jump 4 (arrives at the same depth 1); halt.
        let p = proto_of(vec![
            Instr::new(Opcode::PushConst),
            Instr::new(Opcode::PushConst),
            Instr::with_a(Opcode::JumpIfFalse, 4),
            Instr::with_a(Opcode::Jump, 4),
            Instr::new(Opcode::Halt),
        ]);
        let d = analyze(&p).expect("depths");
        assert_eq!(d.depth_in[&4], 1, "both arms arrive at depth 1");
        assert_eq!(d.stack_size, 2);
    }

    #[test]
    fn unreachable_blocks_carry_no_entry_depth() {
        // halt at pc 0 ends execution; pc 1 is dead (never a target).
        let p = proto_of(vec![
            Instr::new(Opcode::Halt),
            Instr::new(Opcode::PushConst),
        ]);
        let d = analyze(&p).expect("depths");
        assert!(d.depth_in.contains_key(&0));
        assert!(!d.depth_in.contains_key(&1), "dead code has no depth");
    }

    #[test]
    fn hand_built_underflow_fails_closed_here_too() {
        let p = proto_of(vec![Instr::new(Opcode::Pop), Instr::new(Opcode::Halt)]);
        assert_eq!(analyze(&p), Err(DepthError::Underflow { pc: 0 }));
    }

    #[test]
    fn hand_built_imbalance_fails_closed_here_too() {
        // The verify.rs imbalance fixture: target recorded at 1,
        // fallthrough arrives at 2.
        let p = proto_of(vec![
            Instr::new(Opcode::PushConst),
            Instr::new(Opcode::PushConst),
            Instr::with_a(Opcode::JumpIfFalse, 4),
            Instr::new(Opcode::PushConst),
            Instr::new(Opcode::Halt),
        ]);
        assert_eq!(
            analyze(&p),
            Err(DepthError::Imbalance {
                pc: 4,
                expected: 1,
                actual: 2
            })
        );
    }
}

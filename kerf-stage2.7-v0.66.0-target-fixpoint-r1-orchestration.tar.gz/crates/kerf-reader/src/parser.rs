//! Parser: typed token stream → syntax-object tree (recursive descent).
//!
//! Module name per the stage-0 Week-1 prescription (docs/stage0.md
//! reader plan). Every produced node is a public [`SyntaxObject`]:
//! datum + byte-precise span (list nodes span from the `(` to the `)`,
//! atoms take their token span) + an empty scope set + `Phase::Runtime`
//! — scope coloring and phase flipping are expander-side concerns
//! (plan sub-stages 0.4 / docs/stage0.md §9.38, §8.9).
//!
//! Nesting is capped at [`NESTING_LIMIT`] = 256 levels: the cap bounds
//! the native recursion depth of the descent (adversarial deep input
//! fails with a structured error, never a stack overflow).

use crate::error::ReadError;
use crate::token::{Delimiter, StxToken, StxTokenKind};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};

/// The Stage 0 list-nesting cap of 256 levels (sub-stage 0.3
/// acceptance: the 256-deep nesting limit).
pub const NESTING_LIMIT: usize = 256;

/// Parse a whole token stream (as produced by [`crate::lex`], ending
/// with `Eof`) into the sequence of top-level forms.
///
/// A token slice that ends without an `Eof` token is tolerated: end of
/// slice behaves like end of input (the lexer always appends `Eof`, so
/// this only matters for hand-built slices in tests).
pub fn parse_program(file_id: FileId, tokens: &[StxToken]) -> Result<Vec<SyntaxObject>, ReadError> {
    let mut parser = Parser {
        file_id,
        tokens,
        idx: 0,
        depth: 0,
    };
    let mut forms = Vec::new();
    loop {
        match parser.peek_kind() {
            None | Some(StxTokenKind::Eof) => return Ok(forms),
            Some(StxTokenKind::Delimiter(Delimiter::Close)) => {
                return Err(ReadError::UnexpectedClose {
                    at: parser.peek_offset(),
                });
            }
            Some(_) => forms.push(parser.parse_form()?),
        }
    }
}

struct Parser<'t> {
    file_id: FileId,
    tokens: &'t [StxToken],
    idx: usize,
    depth: usize,
}

impl<'t> Parser<'t> {
    fn parse_form(&mut self) -> Result<SyntaxObject, ReadError> {
        let token = &self.tokens[self.idx];
        match &token.kind {
            StxTokenKind::Delimiter(Delimiter::Open) => {
                let opened_at = token.span.start;
                self.idx += 1;
                self.parse_list(opened_at)
            }
            StxTokenKind::Delimiter(Delimiter::Close) => Err(ReadError::UnexpectedClose {
                at: token.span.start,
            }),
            StxTokenKind::Identifier(symbol) => {
                self.idx += 1;
                Ok(SyntaxObject {
                    datum: StxDatum::Symbol(symbol.clone()),
                    span: token.span,
                    scopes: ScopeSet::new(),
                    phase: Phase::Runtime,
                })
            }
            StxTokenKind::IntLiteral(v) => {
                self.idx += 1;
                Ok(SyntaxObject::int(
                    token.span,
                    ScopeSet::new(),
                    Phase::Runtime,
                    *v,
                ))
            }
            StxTokenKind::FloatLiteral(v) => {
                self.idx += 1;
                Ok(SyntaxObject::float(
                    token.span,
                    ScopeSet::new(),
                    Phase::Runtime,
                    *v,
                ))
            }
            StxTokenKind::BoolLiteral(v) => {
                self.idx += 1;
                Ok(SyntaxObject::bool(
                    token.span,
                    ScopeSet::new(),
                    Phase::Runtime,
                    *v,
                ))
            }
            StxTokenKind::StringLiteral(v) => {
                self.idx += 1;
                Ok(SyntaxObject::string(
                    token.span,
                    ScopeSet::new(),
                    Phase::Runtime,
                    v.clone(),
                ))
            }
            StxTokenKind::Eof => Err(ReadError::UnclosedList {
                // Defensive arm: both call sites check Eof before
                // calling parse_form, so this is unreachable in
                // practice — the offset is the best available location.
                opened_at: token.span.start,
            }),
        }
    }

    /// Parse the body of a list whose `(` is already consumed.
    fn parse_list(&mut self, opened_at: ByteOffset) -> Result<SyntaxObject, ReadError> {
        self.depth += 1;
        if self.depth > NESTING_LIMIT {
            return Err(ReadError::NestingDepthExceeded {
                depth: self.depth,
                limit: NESTING_LIMIT,
            });
        }
        let mut items: Vec<SyntaxObject> = Vec::new();
        let close_span;
        loop {
            match self.peek_kind() {
                None | Some(StxTokenKind::Eof) => {
                    // The innermost open list — the one being parsed
                    // when input ran out — reports its own `(` first as
                    // the error propagates up: deterministic boundary,
                    // and the closest location to where input ended.
                    return Err(ReadError::UnclosedList { opened_at });
                }
                Some(StxTokenKind::Delimiter(Delimiter::Close)) => {
                    close_span = self.tokens[self.idx].span;
                    self.idx += 1;
                    break;
                }
                Some(_) => items.push(self.parse_form()?),
            }
        }
        self.depth -= 1;
        if items.is_empty() {
            return Err(ReadError::EmptyApplication { at: opened_at });
        }
        let span = Span::new(self.file_id, opened_at, close_span.end, ExpansionId::ROOT)
            .expect("list span is well-ordered by construction");
        Ok(SyntaxObject::list(
            span,
            ScopeSet::new(),
            Phase::Runtime,
            items,
        ))
    }

    fn peek_kind(&self) -> Option<&StxTokenKind> {
        self.tokens.get(self.idx).map(|t| &t.kind)
    }

    fn peek_offset(&self) -> ByteOffset {
        self.tokens[self.idx].span.start
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the parser feature point (sub-stage test doc
    //! FP2/FP4).

    use super::*;

    fn read(src: &str) -> Result<Vec<SyntaxObject>, ReadError> {
        crate::read_program(FileId(0), src)
    }

    fn deep_source(depth: usize) -> String {
        let mut src = String::new();
        for _ in 0..depth {
            src.push('(');
        }
        src.push('x');
        for _ in 0..depth {
            src.push(')');
        }
        src
    }

    // ---------- positive ----------

    #[test]
    fn parses_multi_form_program_with_stamps() {
        let forms = read("(a) 1 x").expect("three top-level forms");
        assert_eq!(forms.len(), 3);
        assert_eq!(forms[0].datum.to_string(), "(a)");
        assert_eq!(forms[1].datum.to_string(), "1");
        assert_eq!(forms[2].datum.to_string(), "x");
        // Reader stamps: every node carries Phase::Runtime and an
        // empty scope set (coloring/flipping are expander-side).
        for form in &forms {
            assert_eq!(form.phase, Phase::Runtime);
            assert!(form.scopes.is_empty());
        }
    }

    #[test]
    fn nested_tree_carries_exact_byte_spans() {
        let forms = read("(f (g 1) 2)").expect("nested program parses");
        let root = &forms[0];
        assert_eq!((root.span.start.0, root.span.end.0), (0, 11));
        let mut order = Vec::new();
        root.visit_spans(&mut |s| order.push((s.start.0, s.end.0)));
        // Root, `f`, inner list, `g`, `1`, `2` — pre-order.
        assert_eq!(
            order,
            vec![(0, 11), (1, 2), (3, 8), (4, 5), (6, 7), (9, 10)]
        );
    }

    #[test]
    fn whitespace_and_comment_only_source_is_empty_program() {
        let forms = read(" ; nothing here\n\t\n").expect("trivia-only source reads");
        assert!(forms.is_empty());
    }

    #[test]
    fn nesting_limit_boundary_is_inclusive() {
        // 256 levels of nesting are legal; 257 fails (see the negative
        // case below). Depth counts entering lists, not token count.
        let forms = read(&deep_source(NESTING_LIMIT)).expect("256-deep nesting is legal");
        let mut node = &forms[0];
        let mut depth = 1usize;
        while let StxDatum::List(items) = &node.datum {
            if items.is_empty() {
                break;
            }
            node = &items[0];
            depth += 1;
        }
        assert_eq!(depth, NESTING_LIMIT + 1, "root + 256 nested lists");
    }

    // ---------- negative ----------

    #[test]
    fn rejects_unclosed_list() {
        let err = read("(f").expect_err("unclosed list must fail");
        assert_eq!(
            err,
            ReadError::UnclosedList {
                opened_at: ByteOffset(0)
            }
        );
    }

    #[test]
    fn rejects_unclosed_inner_list() {
        // `(a (b` — no closing delimiter at all: the innermost open
        // list (the `(b` at byte 3) is the one being parsed when the
        // input ran out. (With `(a (b)` the single `)` would close the
        // inner list and leave the *root* unclosed at byte 0.)
        let err = read("(a (b").expect_err("unclosed inner list must fail");
        assert_eq!(
            err,
            ReadError::UnclosedList {
                opened_at: ByteOffset(3)
            }
        );
    }

    #[test]
    fn rejects_stray_close() {
        let err = read(")").expect_err("stray close must fail");
        assert_eq!(err, ReadError::UnexpectedClose { at: ByteOffset(0) });
    }

    #[test]
    fn rejects_stray_close_after_forms() {
        let err = read("(a 1) )").expect_err("stray close after forms must fail");
        assert_eq!(err, ReadError::UnexpectedClose { at: ByteOffset(6) });
    }

    #[test]
    fn rejects_empty_application() {
        let err = read("()").expect_err("empty application must fail");
        assert_eq!(err, ReadError::EmptyApplication { at: ByteOffset(0) });
    }

    #[test]
    fn rejects_nested_empty_application() {
        let err = read("(f ())").expect_err("nested empty application must fail");
        assert_eq!(err, ReadError::EmptyApplication { at: ByteOffset(3) });
    }

    #[test]
    fn rejects_empty_application_deep_inside() {
        let err = read("(a (b ()))").expect_err("deep empty application must fail");
        assert_eq!(err, ReadError::EmptyApplication { at: ByteOffset(6) });
    }

    #[test]
    fn rejects_empty_application_in_argument_position() {
        // `(f () 1)` — the empty form sits in argument position; the
        // reader rejects it the moment the `()` closes.
        let err = read("(f () 1)").expect_err("empty argument must fail");
        assert_eq!(err, ReadError::EmptyApplication { at: ByteOffset(3) });
    }

    #[test]
    fn rejects_unclosed_locates_third_form() {
        // `(a) (b) (c` — location precision in a multi-form program:
        // the third form's `(` at byte 8 is reported.
        let err = read("(a) (b) (c").expect_err("unclosed third form must fail");
        assert_eq!(
            err,
            ReadError::UnclosedList {
                opened_at: ByteOffset(8)
            }
        );
    }

    #[test]
    fn rejects_nesting_over_the_limit() {
        let err = read(&deep_source(NESTING_LIMIT + 1)).expect_err("257-deep nesting must fail");
        assert_eq!(
            err,
            ReadError::NestingDepthExceeded {
                depth: NESTING_LIMIT + 1,
                limit: NESTING_LIMIT,
            }
        );
    }

    #[test]
    fn unclosed_error_locates_the_form() {
        // Error in the second of several forms: the location points at
        // the broken form's `(`, byte-precise.
        let err = read("(a 1) (b (c) x").expect_err("mid-program error must locate");
        assert_eq!(
            err,
            ReadError::UnclosedList {
                opened_at: ByteOffset(6)
            }
        );
    }

    #[test]
    fn multiple_open_lists_report_innermost() {
        // `(((x` — three lists open at end of input; the innermost
        // (latest-opened, closest to where input ran out) `(` is
        // reported: deterministic boundary.
        let err = read("(((x").expect_err("stacked opens must fail");
        assert_eq!(
            err,
            ReadError::UnclosedList {
                opened_at: ByteOffset(2)
            }
        );
    }

    #[test]
    fn empty_application_fires_before_outer_unclosed() {
        // `(()` — the inner `()` closes and is rejected as an empty
        // application during the left-to-right descent, before the
        // outer list ever reaches end of input.
        let err = read("(()").expect_err("inner empty application must fail");
        assert_eq!(err, ReadError::EmptyApplication { at: ByteOffset(1) });
    }
}

//! Errors produced by the reader (lexical and syntactic phases).

use std::error::Error;
use std::fmt;

use kerf_span::{ByteOffset, Span, SymbolError};

/// Everything that can go wrong while turning source text into a
/// syntax-object tree (docs/stage0.md §278 capability signature:
/// `read : string → Result<SyntaxObject, ReadError>`; the §8.1
/// `LexError` of the tokenize contract maps onto the lexical variants
/// of this single error surface — one consumer, one error type).
///
/// All payloads carry byte-precise locations (docs/stage0.md §12.1 —
/// byte-offset representation; line/column are derived at diagnostic
/// render time, never stored — TD-001).
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks. The
/// `InvalidSymbol` arm delegates its rendering to the single source
/// `kerf_span::SymbolError` (the unified identifier floor since v0.27.0 —
/// stage0.md §9.58): the same source concept always renders the same
/// English text everywhere (the single-source dictionary).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReadError {
    /// A `(` was never closed before end of input. When several lists
    /// are open at end of input, the innermost one (the list being
    /// parsed when input ran out — the latest-opened `(`) is reported:
    /// a deterministic boundary (SOP §2.3-3) and the location closest
    /// to where the input ended.
    UnclosedList { opened_at: ByteOffset },
    /// A `)` appeared with no matching open delimiter.
    UnexpectedClose { at: ByteOffset },
    /// A string literal was never terminated before end of input (raw
    /// newlines inside strings are legal — Scheme tradition).
    UnterminatedString { started_at: ByteOffset },
    /// A string escape was not one of `\"` `\\` `\n` `\t` `\r`.
    InvalidEscape { escape: char, at: ByteOffset },
    /// An atom starting with `#` was not `#t` or `#f` (fail-closed —
    /// the Stage 0 skin defines exactly two hash literals). The
    /// payload carries the whole-token span: the literal family
    /// reports its real byte extent (surfaced by [`ReadError::token_span`]),
    /// never a fabricated single byte.
    InvalidBool { text: String, span: Span },
    /// A number-shaped atom (leading digit, or `+`/`-`/`.` followed by
    /// a digit) that parses as neither `i64` nor `f64`. No Racket-style
    /// symbol fallback: a typo like `1.2.3` must be an error, not a
    /// silent identifier (SOP §2.3-4 — errors over silence). The
    /// payload carries the whole-token span (see [`ReadError::InvalidBool`]).
    MalformedNumber { text: String, span: Span },
    /// An integer-shaped atom (optional sign + digits only) whose
    /// value overflows `i64`. Fail-closed: the strict Int/Float typing
    /// rejects the silent int→float demotion — a float is spelled with
    /// a `.` or an exponent (K138: rustc denies both overflow faces by
    /// default; K139: the Go spec requires an error when an integer
    /// constant cannot be represented precisely).
    IntOutOfRange { text: String, span: Span },
    /// A float-shaped atom whose value overflows `f64` (it would read
    /// as ±inf). Fail-closed per the same ruling family — overflow is
    /// unrepresentable, so it errors; underflow rounds to the nearest
    /// representable value (`1e-999` reads as `0.0`) and stays legal
    /// (K139: precision limits round, overflow errors).
    FloatOutOfRange { text: String, span: Span },
    /// An atom failed the [`kerf_span::Symbol`] floor
    /// (control characters — whitespace cannot occur inside a
    /// lexed atom because whitespace terminates atoms).
    InvalidSymbol(SymbolError),
    /// `()` — the empty application (SOP §7.1.1 error class 3). The
    /// Stage 0 skin has no reading for an empty form: it can never
    /// carry an operator, so the reader rejects it fail-closed instead
    /// of passing it downstream.
    EmptyApplication { at: ByteOffset },
    /// List nesting exceeded the Stage 0 cap of 256 levels
    /// (docs/develop/v0/stage-0/stage-0-plan.md, sub-stage 0.3).
    NestingDepthExceeded { depth: usize, limit: usize },
    /// A character that has no meaning in the Stage 0 skin: the
    /// bracket characters `[` `]` `{` `}` and the reader-macro
    /// characters `` ` `` `'` `,` (no reader macros exist in Stage 0 —
    /// quote is spelled `(quote x)`).
    UnexpectedCharacter { character: char, at: ByteOffset },
    /// A target-skin delimiter (`{`, `(`, `[` or the `/*` comment)
    /// was never closed — the switch-window seed surface (stage0.md
    /// §9.94). The payload carries the opening delimiter for the
    /// message (the byte offset locates the opener).
    UnclosedTargetDelim {
        opened_at: ByteOffset,
        /// The opening delimiter text: `{`, `(`, `[` or `/*`.
        opening: &'static str,
    },
    /// A closing delimiter with no matching opener, target skin.
    StrayTargetDelim {
        at: ByteOffset,
        /// The closing delimiter character: `}`, `)` or `]`.
        closing: char,
    },
    /// A target-skin token that cannot occupy the expected position.
    /// The payload carries the whole-token span and the lexeme (the
    /// literal-family discipline — a complete token has no single
    /// honest byte).
    UnexpectedTargetToken { text: String, span: Span },
    /// A production inside the v9 Level 0 final domain but outside
    /// the seed parity subset — a registered switch-window step 2
    /// obligation, never a silent acceptance.
    UnsupportedTargetForm { form: &'static str, span: Span },
}

impl fmt::Display for ReadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            // §9.56 DIAG-1: position fragments stay out of Display —
            // the message is general and stands on its own (rustc
            // convention); offsets live in the payload and the driver
            // renders them as the `--> file:line:col` location line.
            ReadError::UnclosedList { .. } => {
                f.write_str("unclosed delimiter: `(` is never closed")
            }
            ReadError::UnexpectedClose { .. } => f.write_str("unexpected closing delimiter `)`"),
            ReadError::UnterminatedString { .. } => f.write_str("unterminated string literal"),
            ReadError::InvalidEscape { escape, .. } => {
                write!(f, "invalid string escape `{escape}`")
            }
            ReadError::InvalidBool { text, .. } => {
                write!(f, "invalid boolean literal `{text}`: expected `#t` or `#f`")
            }
            ReadError::MalformedNumber { text, .. } => {
                write!(f, "malformed number literal `{text}`")
            }
            ReadError::IntOutOfRange { text, .. } => {
                write!(f, "integer literal `{text}` out of range for `i64`")
            }
            ReadError::FloatOutOfRange { text, .. } => {
                write!(f, "float literal `{text}` out of range for `f64`")
            }
            ReadError::InvalidSymbol(err) => err.fmt(f),
            ReadError::EmptyApplication { .. } => {
                f.write_str("empty application: `()` has no operator")
            }
            ReadError::NestingDepthExceeded { depth, limit } => {
                write!(f, "nesting depth {depth} exceeds the limit of {limit}")
            }
            ReadError::UnexpectedCharacter { character, .. } => {
                write!(f, "unexpected character `{character}`")
            }
            ReadError::UnclosedTargetDelim { opening, .. } => {
                write!(f, "unclosed delimiter: `{opening}` is never closed")
            }
            ReadError::StrayTargetDelim { closing, .. } => {
                write!(f, "unexpected closing delimiter `{closing}`")
            }
            ReadError::UnexpectedTargetToken { text, .. } => {
                write!(f, "unexpected token `{text}`")
            }
            ReadError::UnsupportedTargetForm { form, .. } => {
                write!(
                    f,
                    "`{form}` is outside the seed reader scope (switch-window step 2)"
                )
            }
        }
    }
}

impl Error for ReadError {}

impl ReadError {
    /// The byte-precise location of the offending token, when the
    /// variant carries one. The literal family (`InvalidBool`,
    /// `MalformedNumber`, `IntOutOfRange`, `FloatOutOfRange`)
    /// reports through its whole-token span instead — a complete atom
    /// has no single honest byte, and a fabricated position would be
    /// a DUMMY span (stage-0-plan row 0.1 ruling family); the extent
    /// is surfaced by [`ReadError::token_span`]. `InvalidSymbol` and
    /// `NestingDepthExceeded` report through their text/depth payload
    /// only. The driver's diagnostic layer (plan sub-stage 0.8)
    /// renders `Some` offsets as spans and `None` without a location
    /// line.
    pub fn offset(&self) -> Option<ByteOffset> {
        match self {
            ReadError::UnclosedList { opened_at } => Some(*opened_at),
            ReadError::UnexpectedClose { at }
            | ReadError::InvalidEscape { at, .. }
            | ReadError::EmptyApplication { at }
            | ReadError::UnexpectedCharacter { at, .. } => Some(*at),
            ReadError::UnterminatedString { started_at } => Some(*started_at),
            ReadError::UnclosedTargetDelim { opened_at, .. } => Some(*opened_at),
            ReadError::StrayTargetDelim { at, .. } => Some(*at),
            ReadError::InvalidBool { .. }
            | ReadError::MalformedNumber { .. }
            | ReadError::IntOutOfRange { .. }
            | ReadError::FloatOutOfRange { .. }
            | ReadError::InvalidSymbol(_)
            | ReadError::NestingDepthExceeded { .. }
            | ReadError::UnexpectedTargetToken { .. }
            | ReadError::UnsupportedTargetForm { .. } => None,
        }
    }

    /// The whole-token span of the rejecting-family variants — the
    /// atom family that rejects a complete token (`InvalidBool`,
    /// `MalformedNumber`, `IntOutOfRange`, `FloatOutOfRange`) plus
    /// the target-skin position and scope faces
    /// (`UnexpectedTargetToken`, `UnsupportedTargetForm`). The span
    /// is the token's real byte range (start of the literal to its
    /// end), not a fabricated single byte: rustc underlines the full
    /// literal
    /// extent in its own out-of-range diagnostics, and the driver
    /// mirrors that shape (v0.40.0, stage0.md §9.71). Every other
    /// variant returns `None` (single-offset variants report through
    /// [`ReadError::offset`]; whole-stream defects carry neither).
    pub fn token_span(&self) -> Option<Span> {
        match self {
            ReadError::InvalidBool { span, .. }
            | ReadError::MalformedNumber { span, .. }
            | ReadError::IntOutOfRange { span, .. }
            | ReadError::FloatOutOfRange { span, .. }
            | ReadError::UnexpectedTargetToken { span, .. }
            | ReadError::UnsupportedTargetForm { span, .. } => Some(*span),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ReadError rendering surface (sub-stage test
    //! doc FP3; R8 message-shape assertions).

    use super::*;

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            kerf_span::FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            kerf_span::ExpansionId::ROOT,
        )
        .expect("test spans are well-ordered")
    }

    fn every_variant() -> Vec<ReadError> {
        vec![
            ReadError::UnclosedList {
                opened_at: ByteOffset(3),
            },
            ReadError::UnexpectedClose { at: ByteOffset(7) },
            ReadError::UnterminatedString {
                started_at: ByteOffset(0),
            },
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(4),
            },
            ReadError::InvalidBool {
                text: "#q".to_owned(),
                span: span(0, 2),
            },
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned(),
                span: span(0, 5),
            },
            ReadError::IntOutOfRange {
                text: "9223372036854775808".to_owned(),
                span: span(4, 24),
            },
            ReadError::FloatOutOfRange {
                text: "1e999".to_owned(),
                span: span(4, 9),
            },
            ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            }),
            ReadError::EmptyApplication { at: ByteOffset(0) },
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
            ReadError::UnexpectedCharacter {
                character: '[',
                at: ByteOffset(2),
            },
        ]
    }

    // ---------- negative (error surface) ----------

    #[test]
    fn display_family_follows_rust_message_conventions() {
        // R8 family check over every variant: lowercase start, no
        // trailing period.
        for err in every_variant() {
            let rendered = err.to_string();
            let first = rendered.chars().next().expect("non-empty message");
            assert!(
                first.is_lowercase(),
                "message must start lowercase: {rendered}"
            );
            assert!(!rendered.ends_with('.'), "no trailing period: {rendered}");
        }
    }

    #[test]
    fn display_unclosed_is_position_free() {
        // §9.56 DIAG-1: the message stands on its own — the byte offset
        // lives in the payload (`offset()`), never in the Display.
        let err = ReadError::UnclosedList {
            opened_at: ByteOffset(12),
        };
        let rendered = err.to_string();
        assert_eq!(rendered, "unclosed delimiter: `(` is never closed");
        assert!(!rendered.contains("12"));
        assert_eq!(err.offset(), Some(ByteOffset(12)), "payload keeps it");
    }

    #[test]
    fn display_invalid_symbol_is_byte_identical_across_layers() {
        // Single-source dictionary (SOP §10.5 / R8): the same source
        // concept renders the same English text in every layer.
        let reader = ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "a b".to_owned(),
        })
        .to_string();
        let syntax = kerf_syntax::SyntaxError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "a b".to_owned(),
        })
        .to_string();
        assert_eq!(reader, syntax);
    }

    #[test]
    fn display_invalid_bool_mentions_expected_literals() {
        let err = ReadError::InvalidBool {
            text: "#true".to_owned(),
            span: span(0, 5),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`#true`"));
        assert!(rendered.contains("`#t`"));
        assert!(rendered.contains("`#f`"));
    }

    #[test]
    fn error_variants_distinguishable_by_equality() {
        let variants = every_variant();
        for (i, a) in variants.iter().enumerate() {
            for (j, b) in variants.iter().enumerate() {
                if i != j {
                    assert_ne!(a, b, "variants {i} and {j} must be distinct");
                }
            }
        }
        // Same variant with same payload compares equal.
        assert_eq!(variants[0], variants[0].clone());
    }

    /// 0.8 consumer-face extension: the six positioned variants expose
    /// their byte offset; the literal family and the two payload-only
    /// variants expose none (the literal family carries the real
    /// token extent via `token_span` instead — a fabricated single
    /// byte would be a DUMMY span).
    #[test]
    fn offset_extraction_matches_variant_kind() {
        let positioned = [
            ReadError::UnclosedList {
                opened_at: ByteOffset(3),
            },
            ReadError::UnexpectedClose { at: ByteOffset(7) },
            ReadError::UnterminatedString {
                started_at: ByteOffset(0),
            },
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(4),
            },
            ReadError::EmptyApplication { at: ByteOffset(0) },
            ReadError::UnexpectedCharacter {
                character: '[',
                at: ByteOffset(9),
            },
        ];
        for (i, err) in positioned.iter().enumerate() {
            assert!(err.offset().is_some(), "variant {i} must carry an offset");
            assert!(
                err.token_span().is_none(),
                "single-offset variant {i} must not carry a token span"
            );
        }
        let payload_only = [
            ReadError::InvalidBool {
                text: "#q".to_owned(),
                span: span(0, 2),
            },
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned(),
                span: span(0, 5),
            },
            ReadError::IntOutOfRange {
                text: "9223372036854775808".to_owned(),
                span: span(4, 24),
            },
            ReadError::FloatOutOfRange {
                text: "1e999".to_owned(),
                span: span(4, 9),
            },
            ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            }),
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
        ];
        for (i, err) in payload_only.iter().enumerate() {
            assert!(
                err.offset().is_none(),
                "variant {i} must not fake an offset"
            );
        }
    }

    /// The literal family surfaces its whole-token span — the four
    /// complete-atom rejections; every other variant surfaces none
    /// (single-offset variants report through `offset`, whole-stream
    /// defects carry neither).
    #[test]
    fn token_span_extraction_covers_the_literal_family() {
        let spanned = [
            (
                ReadError::InvalidBool {
                    text: "#true".to_owned(),
                    span: span(13, 18),
                },
                (13, 18),
            ),
            (
                ReadError::MalformedNumber {
                    text: "1.2.3".to_owned(),
                    span: span(11, 16),
                },
                (11, 16),
            ),
            (
                ReadError::IntOutOfRange {
                    text: "99999999999999999999".to_owned(),
                    span: span(11, 31),
                },
                (11, 31),
            ),
            (
                ReadError::FloatOutOfRange {
                    text: "1e999".to_owned(),
                    span: span(11, 16),
                },
                (11, 16),
            ),
        ];
        for (i, (err, (s, e))) in spanned.iter().enumerate() {
            let got = err
                .token_span()
                .unwrap_or_else(|| panic!("variant {i} carries no span"));
            assert_eq!((got.start.0, got.end.0), (*s, *e), "variant {i} span");
            assert_eq!(got.file_id, kerf_span::FileId(0));
        }
        let unspanned = [
            ReadError::UnclosedList {
                opened_at: ByteOffset(3),
            },
            ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            }),
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
        ];
        for (i, err) in unspanned.iter().enumerate() {
            assert!(
                err.token_span().is_none(),
                "non-literal variant {i} must not carry a token span"
            );
        }
    }

    /// The extracted offset is the exact payload byte, not a copy of a
    /// neighboring variant's position.
    #[test]
    fn offset_extraction_returns_payload_byte() {
        assert_eq!(
            ReadError::UnclosedList {
                opened_at: ByteOffset(42)
            }
            .offset(),
            Some(ByteOffset(42))
        );
        assert_eq!(
            ReadError::UnexpectedClose { at: ByteOffset(7) }.offset(),
            Some(ByteOffset(7))
        );
    }

    /// UnterminatedString reports the opening quote position (the
    /// deterministic anchor for a defect with no end).
    #[test]
    fn offset_extraction_string_reports_start() {
        assert_eq!(
            ReadError::UnterminatedString {
                started_at: ByteOffset(11)
            }
            .offset(),
            Some(ByteOffset(11))
        );
    }
}

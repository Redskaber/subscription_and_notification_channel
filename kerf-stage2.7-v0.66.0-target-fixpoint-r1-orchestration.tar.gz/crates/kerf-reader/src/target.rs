//! The target-syntax reader seed — switch-window step 1 (stage0.md
//! §9.94, EBNF v9 Level 0 parity subset).
//!
//! Charter: this module is the *seed* of the Stage 2b syntax
//! replacement window (the five-step process of stage0.md §9.30.4 /
//! docs/develop/v2/switch-window-plan.md). It parses the v9 target
//! skin (EBNF v9 Level 0, docs/stage0.md §9.26.2) and produces the
//! same [`SyntaxObject`] trees the S-expression reader produces for
//! the equivalent program — the skin-dictionary mapping (stage0.md
//! §9.26.9) is applied at parse time, so the downstream pipeline
//! (expander -> compiler -> vm) is untouched. Parity is byte-level at
//! the bytecode face (§9.25.4 BS-C: same program, two skins, one
//! bytecode), not at the Stx face — Stx shapes that expand to the
//! same core form are equal for this contract.
//!
//! B2 ruling applied (stage0.md §9.42.4, option 1 — the window-opening
//! adjudication): `if`, `perform` and `handle` are expression-position
//! forms (primary face), matching the kernel's expressiveness, the
//! Koka/OCaml 5/Rust precedents and the skin dictionary's completeness
//! requirement.
//!
//! Seed scope (the Level 0 parity subset — everything with a Stage 0
//! S-expression counterpart):
//! - items: `fn` declarations (type annotations parsed and dropped),
//!   `module`, `use "name"` (the transitional string form; the v9 path
//!   form carries the `::`-vs-`/` separator policy, a step 2
//!   obligation), and expression statements — the call-form rule of
//!   the skin dictionary (`define(name, value);` -> `(define name
//!   value)`, `quote(x)` -> `(quote x)`) falls out of the ordinary
//!   call mapping with no special case;
//! - statements: `let` (single and comma multi-binding — the r110
//!   parity ruling: consecutive bindings must not desugar to nested
//!   lets), assignment (`x = e;` -> `(set! x e)`), expression
//!   statements, and the block tail as the block value;
//! - expressions: the full §9.26.4 precedence cascade with the
//!   operator skin (`a + b` -> `(+ a b)`, `==` -> `=`, `!=` ->
//!   `(not (= a b))`, `&&`/`||` -> short-circuit `if` desugars,
//!   unary `-`/`!`), calls, `name!(...)` macro invocations (the `!`
//!   marker drops; the head resolves through the expander's
//!   scope-keyed judgment), closures (`||`/`move ||`), blocks, `if`,
//!   `perform`, `handle` with `resume` handler bodies, `()` unit
//!   (-> `nil`, ruling C12) and all literal families.
//!
//! Out of seed scope (structured fail-closed errors, registered as
//! step 2 obligations in the switch-window plan): struct/enum/type/
//! effect/capability declarations, `match` and patterns, generics,
//! where clauses, casts, ranges, field/method access, indexing, and
//! the `halt`/`pass` handler bodies (no core counterpart yet).
//!
//! Scaffolding lifecycle (principle 41): this seed is the *building*
//! phase of the new-reader scaffold. The identifier surface is the
//! v9 ASCII domain; carrying kebab-case corpus names across the two
//! skins is the step 3 corpus-translation obligation (the E5 name
//! batches own that policy).

use std::rc::Rc;

use crate::error::ReadError;
use crate::parser::NESTING_LIMIT;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};

/// Read a whole target-skin program: source text -> top-level forms.
///
/// The dual of [`crate::read_program`] for the v9 skin; both share
/// the single [`ReadError`] surface.
pub fn read_target_program(file_id: FileId, source: &str) -> Result<Vec<SyntaxObject>, ReadError> {
    let tokens = lex_target(file_id, source)?;
    let mut parser = TargetParser {
        file_id,
        tokens: &tokens,
        idx: 0,
        depth: 0,
    };
    parser.parse_items()
}

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------

/// One target-skin token: kind + byte-precise span + raw lexeme (the
/// lexeme backs the `UnexpectedTargetToken` payload).
struct TgtToken {
    kind: TgtKind,
    span: Span,
    text: String,
}

#[derive(Debug, Clone, PartialEq)]
enum TgtKind {
    /// Identifier atom (already interned — the pool hit is the token
    /// identity, §9.66 TRF-8 discipline).
    Ident(Symbol),
    Int(i64),
    Float(f64),
    Str(Rc<str>),
    Bool(bool),
    // The 22 finalized word faces (§9.26.5) plus the two boolean
    // literal spellings.
    KwFn,
    KwLet,
    KwMut,
    KwIf,
    KwElse,
    KwMatch,
    KwPerform,
    KwHandle,
    KwModule,
    KwUse,
    KwPub,
    KwStruct,
    KwEnum,
    KwType,
    KwEffect,
    KwCapability,
    KwMove,
    KwAs,
    KwImpl,
    KwResume,
    KwHalt,
    KwPass,
    // Punctuation and operators.
    OpenBrace,
    CloseBrace,
    OpenParen,
    CloseParen,
    OpenBracket,
    CloseBracket,
    Semi,
    Comma,
    Colon,
    ColonColon,
    Arrow,
    FatArrow,
    Dot,
    DotDot,
    Bang,
    Assign,
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Lt,
    Gt,
    Le,
    Ge,
    EqEq,
    NotEq,
    AndAnd,
    OrOr,
    Amp,
    Pipe,
    Caret,
    Shl,
    Shr,
    Eof,
}

/// The word face's spelling, for datum-position keywords (`quote`
/// data may name the word faces — the S-expr face quotes them as
/// plain symbols).
fn word_text(kind: &TgtKind) -> Option<&'static str> {
    match kind {
        TgtKind::KwFn => Some("fn"),
        TgtKind::KwLet => Some("let"),
        TgtKind::KwMut => Some("mut"),
        TgtKind::KwIf => Some("if"),
        TgtKind::KwElse => Some("else"),
        TgtKind::KwMatch => Some("match"),
        TgtKind::KwPerform => Some("perform"),
        TgtKind::KwHandle => Some("handle"),
        TgtKind::KwModule => Some("module"),
        TgtKind::KwUse => Some("use"),
        TgtKind::KwPub => Some("pub"),
        TgtKind::KwStruct => Some("struct"),
        TgtKind::KwEnum => Some("enum"),
        TgtKind::KwType => Some("type"),
        TgtKind::KwEffect => Some("effect"),
        TgtKind::KwCapability => Some("capability"),
        TgtKind::KwMove => Some("move"),
        TgtKind::KwAs => Some("as"),
        TgtKind::KwImpl => Some("impl"),
        TgtKind::KwResume => Some("resume"),
        TgtKind::KwHalt => Some("halt"),
        TgtKind::KwPass => Some("pass"),
        _ => None,
    }
}

/// The interned text of an identifier token.
fn ident_symbol(text: &str) -> Result<Symbol, ReadError> {
    Symbol::new(text).map_err(ReadError::InvalidSymbol)
}

/// The E5 name-modernization skin at the token face (batches 1+2 —
/// switch-window-plan §5.1 rulings E/E2).
///
/// Batch 1 (r99, ruling E): the two kebab-case Stage 0 I/O globals
/// ride snake-case spellings.
///
/// Batch 2 (this round, ruling E2 — the Lisp-name retirement): the
/// target skin's two general one-way conventions plus the builtin
/// family table:
/// - **Rule P (predicates)**: an `is_` segment (leading, or after
///   the last interior `_is_`) spells the `?`-suffixed final kebab
///   segment — `is_nil` → `nil?`, `lx_is_digit` → `lx-digit?`;
/// - **Rule K (the separator)**: a `_` between two alphanumeric
///   characters is the `-` of the S-expr face — `rd_loop` →
///   `rd-loop`. A leading or trailing `_` (the blank marker family,
///   including the lone `_` wildcard) is NOT a separator and passes
///   through verbatim;
/// - the builtin table retires the historical pair names
///   (`first`/`car`, `rest`/`cdr`, `pair`/`cons`, `eq`/`eq?`) and
///   spells the assign form's call carrier (`set`/`set!` — the
///   expression-position twin of the `x = e;` statement sugar,
///   ruling G: the kernel's `Assign` is an expression, and the
///   corpus exercises it in if-branches where no statement can
///   ride).
///
/// Both rules are one-way (target → S-expr): definition sites map
/// together with reference sites, so shadowing behavior is
/// unchanged. S-expr identifiers with an interior `_` (legal on
/// that face) stay outside the target vocabulary rather than being
/// renamed — the r98-registered constraint this ruling confirms —
/// and the interior `_is_` infix and the four builtin spellings are
/// skin-reserved on the target face.
fn skin_symbol(text: &str) -> Result<Symbol, ReadError> {
    let mapped: String = match text {
        "read_line" => "read-line".to_string(),
        "write_line" => "write-line".to_string(),
        "first" => "car".to_string(),
        "rest" => "cdr".to_string(),
        "pair" => "cons".to_string(),
        "eq" => "eq?".to_string(),
        "set" => "set!".to_string(),
        _ => {
            // Rule P: split at the last interior `_is_` marker (or a
            // leading `is_`); the tail becomes the `?`-suffixed
            // final segment.
            let pred_marked = match text.rfind("_is_") {
                Some(i) if i > 0 && text.as_bytes()[i - 1].is_ascii_alphanumeric() => {
                    format!("{}-{}?", &text[..i], &text[i + 4..])
                }
                _ if text.starts_with("is_") => format!("{}?", &text[3..]),
                _ => text.to_string(),
            };
            // Rule K: interior separators only — a `_` between two
            // alphanumeric characters. The blank marker family
            // (`_`, `_x`, `x_`, `__`) passes through verbatim.
            let bytes = pred_marked.as_bytes();
            let mut out = String::with_capacity(pred_marked.len());
            for (i, b) in bytes.iter().enumerate() {
                if *b == b'_'
                    && i > 0
                    && i + 1 < bytes.len()
                    && bytes[i - 1].is_ascii_alphanumeric()
                    && bytes[i + 1].is_ascii_alphanumeric()
                {
                    out.push('-');
                } else {
                    out.push(*b as char);
                }
            }
            out
        }
    };
    ident_symbol(&mapped)
}

// ---------------------------------------------------------------------------
// Lexer
// ---------------------------------------------------------------------------

/// Lex the target skin: source text -> tokens (ending with `Eof`).
///
/// The lexical layer follows EBNF v9 §9.26.2: ASCII identifiers, the
/// 22 finalized word faces, `true`/`false` literals, decimal/hex/
/// octal/binary integers with `_` separators, dot-mandatory floats,
/// strings with the v9 escape family (including `\u{...}`), `//` line
/// comments and nested `/* ... */` block comments. The ASCII
/// identifier domain is the v9 ruling (Unicode identifiers are a
/// registered Stage 2+ lexer obligation), so non-ASCII outside
/// strings and comments is `UnexpectedCharacter`.
fn lex_target(file_id: FileId, source: &str) -> Result<Vec<TgtToken>, ReadError> {
    let bytes = source.as_bytes();
    let mut tokens = Vec::new();
    let mut i = 0usize;
    let len = bytes.len();

    let span = |start: usize, end: usize| -> Span {
        Span::new(
            file_id,
            ByteOffset(start as u32),
            ByteOffset(end as u32),
            ExpansionId::ROOT,
        )
        .expect("lexer spans are well-ordered by construction")
    };
    let push = |tokens: &mut Vec<TgtToken>, kind: TgtKind, start: usize, end: usize| {
        tokens.push(TgtToken {
            kind,
            span: span(start, end),
            text: source[start..end].to_string(),
        });
    };

    while i < len {
        let b = bytes[i];
        // Whitespace.
        if b == b' ' || b == b'\t' || b == b'\n' || b == b'\r' {
            i += 1;
            continue;
        }
        // Comments.
        if b == b'/' && i + 1 < len && bytes[i + 1] == b'/' {
            while i < len && bytes[i] != b'\n' && bytes[i] != b'\r' {
                i += 1;
            }
            continue;
        }
        if b == b'/' && i + 1 < len && bytes[i + 1] == b'*' {
            let start = i;
            i += 2;
            let mut depth = 1usize;
            while i < len && depth > 0 {
                if bytes[i] == b'/' && i + 1 < len && bytes[i + 1] == b'*' {
                    depth += 1;
                    i += 2;
                } else if bytes[i] == b'*' && i + 1 < len && bytes[i + 1] == b'/' {
                    depth -= 1;
                    i += 2;
                } else {
                    i += 1;
                }
            }
            if depth > 0 {
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: ByteOffset(start as u32),
                    opening: "/*",
                });
            }
            continue;
        }
        let start = i;
        // Identifiers and word faces.
        if b.is_ascii_alphabetic() || b == b'_' {
            i += 1;
            while i < len && (bytes[i].is_ascii_alphanumeric() || bytes[i] == b'_') {
                i += 1;
            }
            let text = &source[start..i];
            let kind = match text {
                "fn" => TgtKind::KwFn,
                "let" => TgtKind::KwLet,
                "mut" => TgtKind::KwMut,
                "if" => TgtKind::KwIf,
                "else" => TgtKind::KwElse,
                "match" => TgtKind::KwMatch,
                "perform" => TgtKind::KwPerform,
                "handle" => TgtKind::KwHandle,
                "module" => TgtKind::KwModule,
                "use" => TgtKind::KwUse,
                "pub" => TgtKind::KwPub,
                "struct" => TgtKind::KwStruct,
                "enum" => TgtKind::KwEnum,
                "type" => TgtKind::KwType,
                "effect" => TgtKind::KwEffect,
                "capability" => TgtKind::KwCapability,
                "move" => TgtKind::KwMove,
                "as" => TgtKind::KwAs,
                "impl" => TgtKind::KwImpl,
                "resume" => TgtKind::KwResume,
                "halt" => TgtKind::KwHalt,
                "pass" => TgtKind::KwPass,
                "true" => TgtKind::Bool(true),
                "false" => TgtKind::Bool(false),
                _ => TgtKind::Ident(skin_symbol(text)?),
            };
            push(&mut tokens, kind, start, i);
            continue;
        }
        // Numbers.
        if b.is_ascii_digit() {
            let (kind, end) = lex_number(file_id, source, bytes, i)?;
            push(&mut tokens, kind, start, end);
            i = end;
            continue;
        }
        // Strings.
        if b == b'"' {
            let (value, end) = lex_string(source, bytes, i)?;
            tokens.push(TgtToken {
                kind: TgtKind::Str(value),
                span: span(i, end),
                text: source[i..end].to_string(),
            });
            i = end;
            continue;
        }
        // Multi-char operators (maximal munch).
        let rest = &bytes[i..];
        let two = if rest.starts_with(b"->") {
            Some(TgtKind::Arrow)
        } else if rest.starts_with(b"=>") {
            Some(TgtKind::FatArrow)
        } else if rest.starts_with(b"::") {
            Some(TgtKind::ColonColon)
        } else if rest.starts_with(b"..") {
            Some(TgtKind::DotDot)
        } else if rest.starts_with(b"==") {
            Some(TgtKind::EqEq)
        } else if rest.starts_with(b"!=") {
            Some(TgtKind::NotEq)
        } else if rest.starts_with(b"&&") {
            Some(TgtKind::AndAnd)
        } else if rest.starts_with(b"||") {
            Some(TgtKind::OrOr)
        } else if rest.starts_with(b"<=") {
            Some(TgtKind::Le)
        } else if rest.starts_with(b">=") {
            Some(TgtKind::Ge)
        } else if rest.starts_with(b"<<") {
            Some(TgtKind::Shl)
        } else if rest.starts_with(b">>") {
            Some(TgtKind::Shr)
        } else {
            None
        };
        if let Some(kind) = two {
            i += 2;
            push(&mut tokens, kind, start, i);
            continue;
        }
        // Single-char tokens.
        let kind = match b {
            b'{' => TgtKind::OpenBrace,
            b'}' => TgtKind::CloseBrace,
            b'(' => TgtKind::OpenParen,
            b')' => TgtKind::CloseParen,
            b'[' => TgtKind::OpenBracket,
            b']' => TgtKind::CloseBracket,
            b';' => TgtKind::Semi,
            b',' => TgtKind::Comma,
            b':' => TgtKind::Colon,
            b'.' => TgtKind::Dot,
            b'!' => TgtKind::Bang,
            b'=' => TgtKind::Assign,
            b'+' => TgtKind::Plus,
            b'-' => TgtKind::Minus,
            b'*' => TgtKind::Star,
            b'/' => TgtKind::Slash,
            b'%' => TgtKind::Percent,
            b'<' => TgtKind::Lt,
            b'>' => TgtKind::Gt,
            b'&' => TgtKind::Amp,
            b'|' => TgtKind::Pipe,
            b'^' => TgtKind::Caret,
            _ => {
                // Decode the char for the payload (multi-byte safe).
                let ch = source[i..]
                    .chars()
                    .next()
                    .expect("position is a char start");
                return Err(ReadError::UnexpectedCharacter {
                    character: ch,
                    at: ByteOffset(i as u32),
                });
            }
        };
        i += 1;
        push(&mut tokens, kind, start, i);
    }
    tokens.push(TgtToken {
        kind: TgtKind::Eof,
        span: span(len, len),
        text: String::new(),
    });
    Ok(tokens)
}

/// Lex a number starting at `i` (a digit). Integer families: decimal
/// with `_`, `0x`/`0o`/`0b` radix forms. Floats require the dot
/// followed by a digit, with an optional exponent — `1.` is not a
/// float (the `1` lexes as an int, the `.` as a field token), and
/// `1e10` is not a float either (the v9 grammar mandates the dot).
/// Returns the kind and the end offset.
fn lex_number(
    file_id: FileId,
    source: &str,
    bytes: &[u8],
    start: usize,
) -> Result<(TgtKind, usize), ReadError> {
    let len = bytes.len();
    let mut i = start;
    let err_span = |s: usize, e: usize| -> Span {
        Span::new(
            file_id,
            ByteOffset(s as u32),
            ByteOffset(e as u32),
            ExpansionId::ROOT,
        )
        .expect("number span is well-ordered")
    };
    let radix = if bytes[i] == b'0' && i + 1 < len {
        match bytes[i + 1] {
            b'x' | b'X' => Some(16u32),
            b'o' | b'O' => Some(8),
            b'b' | b'B' => Some(2),
            _ => None,
        }
    } else {
        None
    };
    if let Some(radix) = radix {
        i += 2;
        let digits_start = i;
        while i < len && (bytes[i].is_ascii_alphanumeric() || bytes[i] == b'_') {
            // Alphanumeric keeps the scan simple; the parse below
            // rejects out-of-domain digits.
            i += 1;
        }
        if i == digits_start {
            return Err(ReadError::MalformedNumber {
                text: source[start..i].to_string(),
                span: err_span(start, i),
            });
        }
        let text: String = source[digits_start..i]
            .chars()
            .filter(|c| *c != '_')
            .collect();
        let value = i64::from_str_radix(&text, radix).map_err(|_| {
            if u64::from_str_radix(&text, radix).is_ok() {
                ReadError::IntOutOfRange {
                    text: source[start..i].to_string(),
                    span: err_span(start, i),
                }
            } else {
                ReadError::MalformedNumber {
                    text: source[start..i].to_string(),
                    span: err_span(start, i),
                }
            }
        })?;
        return Ok((TgtKind::Int(value), i));
    }
    // Decimal integer part.
    while i < len && (bytes[i].is_ascii_digit() || bytes[i] == b'_') {
        i += 1;
    }
    let int_end = i;
    // Float: dot followed by a digit.
    if i + 1 < len && bytes[i] == b'.' && bytes[i + 1].is_ascii_digit() {
        i += 1; // the dot
        while i < len && (bytes[i].is_ascii_digit() || bytes[i] == b'_') {
            i += 1;
        }
        // Optional exponent.
        if i < len && (bytes[i] == b'e' || bytes[i] == b'E') {
            let mut j = i + 1;
            if j < len && (bytes[j] == b'+' || bytes[j] == b'-') {
                j += 1;
            }
            if j < len && bytes[j].is_ascii_digit() {
                i = j;
                while i < len && (bytes[i].is_ascii_digit() || bytes[i] == b'_') {
                    i += 1;
                }
            }
        }
        let text: String = source[start..i].chars().filter(|c| *c != '_').collect();
        let value: f64 = text.parse().map_err(|_| ReadError::MalformedNumber {
            text: source[start..i].to_string(),
            span: err_span(start, i),
        })?;
        if !value.is_finite() {
            return Err(ReadError::FloatOutOfRange {
                text: source[start..i].to_string(),
                span: err_span(start, i),
            });
        }
        return Ok((TgtKind::Float(value), i));
    }
    let text: String = source[start..i].chars().filter(|c| *c != '_').collect();
    let value: i64 = text.parse().map_err(|_| ReadError::IntOutOfRange {
        text: source[start..i].to_string(),
        span: err_span(start, i),
    })?;
    Ok((TgtKind::Int(value), int_end))
}

/// Lex a `"..."` string starting at `i`. Raw newlines are legal
/// (Stage 0 tradition); the escape family is the v9 set: `\n` `\t`
/// `\r` `\0` `\\` `\"` `\'` `\u{1..6 hex}`. Returns the value and the
/// end offset (past the closing quote).
fn lex_string(source: &str, bytes: &[u8], start: usize) -> Result<(Rc<str>, usize), ReadError> {
    let len = bytes.len();
    let mut i = start + 1;
    let mut value = String::new();
    while i < len {
        let b = bytes[i];
        if b == b'"' {
            return Ok((Rc::from(value.as_str()), i + 1));
        }
        if b == b'\\' {
            i += 1;
            if i >= len {
                break;
            }
            let at = ByteOffset((i - 1) as u32);
            match bytes[i] {
                b'n' => {
                    value.push('\n');
                    i += 1;
                }
                b't' => {
                    value.push('\t');
                    i += 1;
                }
                b'r' => {
                    value.push('\r');
                    i += 1;
                }
                b'0' => {
                    value.push('\0');
                    i += 1;
                }
                b'\\' => {
                    value.push('\\');
                    i += 1;
                }
                b'"' => {
                    value.push('"');
                    i += 1;
                }
                b'\'' => {
                    value.push('\'');
                    i += 1;
                }
                b'u' => {
                    // \u{ hex, 1..6 digits, `_` separators allowed }
                    let brace = i + 1;
                    if brace >= len || bytes[brace] != b'{' {
                        return Err(ReadError::InvalidEscape { escape: 'u', at });
                    }
                    let mut j = brace + 1;
                    let mut hex = String::new();
                    while j < len && bytes[j] != b'}' {
                        if bytes[j].is_ascii_hexdigit() {
                            hex.push(bytes[j] as char);
                            j += 1;
                        } else if bytes[j] == b'_' {
                            j += 1;
                        } else {
                            return Err(ReadError::InvalidEscape { escape: 'u', at });
                        }
                    }
                    if j >= len || hex.is_empty() || hex.len() > 6 {
                        return Err(ReadError::InvalidEscape { escape: 'u', at });
                    }
                    let code = u32::from_str_radix(&hex, 16)
                        .map_err(|_| ReadError::InvalidEscape { escape: 'u', at })?;
                    let ch =
                        char::from_u32(code).ok_or(ReadError::InvalidEscape { escape: 'u', at })?;
                    value.push(ch);
                    i = j + 1;
                }
                _ => {
                    let escape = source[i..]
                        .chars()
                        .next()
                        .expect("position is a char start");
                    return Err(ReadError::InvalidEscape { escape, at });
                }
            }
            continue;
        }
        // Ordinary char: copy the UTF-8 sequence.
        let ch = source[i..]
            .chars()
            .next()
            .expect("position is a char start");
        value.push(ch);
        i += ch.len_utf8();
    }
    Err(ReadError::UnterminatedString {
        started_at: ByteOffset(start as u32),
    })
}

// ---------------------------------------------------------------------------
// Parser + skin mapping
// ---------------------------------------------------------------------------

/// One block entry for the do/let fold: a plain form (its value
/// discards — the `do` discipline) or a `let` group (it swallows the
/// remainder as its body).
enum BlockEntry {
    Form(SyntaxObject),
    Let {
        /// (name form, value form) pairs — the name carries its own
        /// binding-site span.
        bindings: Vec<(SyntaxObject, SyntaxObject)>,
        let_start: ByteOffset,
    },
}

struct TargetParser<'t> {
    file_id: FileId,
    tokens: &'t [TgtToken],
    idx: usize,
    depth: usize,
}

/// A parsed identifier: the interned symbol + its span.
struct IdentToken {
    symbol: Symbol,
    span: Span,
}

/// Zero-sized proof token for the depth guard (the guard forces the
/// paired `leave` — the parser code reads as enter/leave brackets).
struct DepthGuard;

impl<'t> TargetParser<'t> {
    // ---------- token helpers ----------

    fn peek(&self) -> &TgtToken {
        &self.tokens[self.idx.min(self.tokens.len() - 1)]
    }

    fn peek2(&self) -> &TgtToken {
        &self.tokens[(self.idx + 1).min(self.tokens.len() - 1)]
    }

    fn bump(&mut self) -> Span {
        let span = self.peek().span;
        if self.idx < self.tokens.len() - 1 {
            self.idx += 1;
        }
        span
    }

    fn at(&self, kind: &TgtKind) -> bool {
        std::mem::discriminant(&self.peek().kind) == std::mem::discriminant(kind)
    }

    fn err_unexpected(&self) -> ReadError {
        let token = self.peek();
        let text = if token.text.is_empty() {
            "end of input".to_string()
        } else {
            token.text.clone()
        };
        ReadError::UnexpectedTargetToken {
            text,
            span: token.span,
        }
    }

    fn expect(&mut self, kind: TgtKind) -> Result<Span, ReadError> {
        if self.at(&kind) {
            Ok(self.bump())
        } else {
            Err(self.err_unexpected())
        }
    }

    fn enter(&mut self) -> Result<DepthGuard, ReadError> {
        self.depth += 1;
        if self.depth > NESTING_LIMIT {
            return Err(ReadError::NestingDepthExceeded {
                depth: self.depth,
                limit: NESTING_LIMIT,
            });
        }
        Ok(DepthGuard)
    }

    fn leave(&mut self, _guard: DepthGuard) {
        self.depth -= 1;
    }

    fn span_from(&self, start: ByteOffset, end: ByteOffset) -> Span {
        Span::new(self.file_id, start, end, ExpansionId::ROOT)
            .expect("parser spans are well-ordered by construction")
    }

    // ---------- node builders ----------

    fn atom(&self, datum: StxDatum, span: Span) -> SyntaxObject {
        SyntaxObject {
            datum,
            span,
            scopes: ScopeSet::new(),
            phase: Phase::Runtime,
        }
    }

    fn list(&self, start: ByteOffset, items: Vec<SyntaxObject>, end: ByteOffset) -> SyntaxObject {
        let span = self.span_from(start, end);
        self.atom(StxDatum::List(items), span)
    }

    /// The `nil` atom for the unit skin (ruling C12: `()` is `nil`).
    /// The span is the construct the unit stands for (a closing
    /// delimiter or a whole block — the nearest honest extent).
    fn nil_form(&self, span: Span) -> SyntaxObject {
        let nil = Symbol::new("nil").expect("the nil spelling is a valid symbol");
        self.atom(StxDatum::Symbol(nil), span)
    }

    fn head_symbol(&self, text: &str, span: Span) -> SyntaxObject {
        let symbol = Symbol::new(text).expect("form heads are valid symbols");
        self.atom(StxDatum::Symbol(symbol), span)
    }

    /// `(op left right)` — the operator-own-name application form.
    fn binop_form(
        &self,
        op_text: &str,
        op_span: Span,
        left: SyntaxObject,
        right: SyntaxObject,
    ) -> SyntaxObject {
        let start = op_span.start;
        let end = right.span.end;
        let items = vec![self.head_symbol(op_text, op_span), left, right];
        self.list(start, items, end)
    }

    // ---------- items ----------

    fn parse_items(&mut self) -> Result<Vec<SyntaxObject>, ReadError> {
        let mut items = Vec::new();
        loop {
            if self.at(&TgtKind::Eof) {
                return Ok(items);
            }
            items.push(self.parse_item()?);
        }
    }

    /// One top-level item: `fn` / `module` / `use` declarations, or an
    /// expression statement (the call-form rule: `define(n, e);` and
    /// `quote(x);` ride the ordinary call mapping).
    fn parse_item(&mut self) -> Result<SyntaxObject, ReadError> {
        match self.peek().kind {
            TgtKind::KwFn => self.parse_fn_decl(),
            TgtKind::KwModule => self.parse_module_decl(),
            TgtKind::KwUse => self.parse_use_decl(),
            TgtKind::KwStruct
            | TgtKind::KwEnum
            | TgtKind::KwType
            | TgtKind::KwEffect
            | TgtKind::KwCapability => Err(ReadError::UnsupportedTargetForm {
                form: "type declarations",
                span: self.peek().span,
            }),
            _ => self.parse_expr_statement(),
        }
    }

    fn parse_expr_statement(&mut self) -> Result<SyntaxObject, ReadError> {
        let form = self.parse_expr()?;
        self.expect(TgtKind::Semi)?;
        Ok(form)
    }

    /// `fn name(params) -> T { body }` -> `(define (name params...)
    /// body)`. Type annotations and `mut` parse and drop — the
    /// annotations are surface sugar the HM layer owns.
    fn parse_fn_decl(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwFn)?;
        let name = self.expect_ident()?;
        self.reject_generics()?;
        let params = self.parse_params()?;
        if self.at(&TgtKind::Arrow) {
            self.bump();
            self.parse_type_drop()?;
        }
        let body = self.parse_block()?;
        // (define (name params...) body)
        let params_end = params.last().map(|p| p.span.end).unwrap_or(name.span.end);
        let name_and_params = self.list(
            name.span.start,
            {
                let mut v = vec![self.atom(StxDatum::Symbol(name.symbol), name.span)];
                v.extend(params);
                v
            },
            params_end,
        );
        let end = body.span.end;
        let items = vec![self.head_symbol("define", kw_span), name_and_params, body];
        Ok(self.list(kw_span.start, items, end))
    }

    /// `( params )` — `[mut] ident [: type]`, comma-separated. The
    /// annotations drop at the mapping face.
    fn parse_params(&mut self) -> Result<Vec<SyntaxObject>, ReadError> {
        self.expect(TgtKind::OpenParen)?;
        let mut params = Vec::new();
        if self.at(&TgtKind::CloseParen) {
            self.bump();
            return Ok(params);
        }
        loop {
            if self.at(&TgtKind::KwMut) {
                self.bump();
            }
            let ident = self.expect_ident()?;
            params.push(self.atom(StxDatum::Symbol(ident.symbol), ident.span));
            if self.at(&TgtKind::Colon) {
                self.bump();
                self.parse_type_drop()?;
            }
            if self.at(&TgtKind::Comma) {
                self.bump();
                continue;
            }
            break;
        }
        self.expect(TgtKind::CloseParen)?;
        Ok(params)
    }

    /// `module name { items }` -> `(module name items...)`.
    fn parse_module_decl(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwModule)?;
        let name = self.expect_ident()?;
        let open_span = self.expect(TgtKind::OpenBrace)?;
        let guard = self.enter()?;
        let mut items = Vec::new();
        loop {
            if self.at(&TgtKind::CloseBrace) {
                break;
            }
            if self.at(&TgtKind::Eof) {
                self.leave(guard);
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: open_span.start,
                    opening: "{",
                });
            }
            items.push(self.parse_item()?);
        }
        let close_span = self.bump();
        self.leave(guard);
        let mut form_items = vec![
            self.head_symbol("module", kw_span),
            self.atom(StxDatum::Symbol(name.symbol), name.span),
        ];
        form_items.extend(items);
        Ok(self.list(kw_span.start, form_items, close_span.end))
    }

    /// `use "name";` -> `(require "name")` (the transitional string
    /// form) and `use a::b::c;` -> `(require "a/b/c")` (the path
    /// form — ruling D, C-C1 separator policy at the module-name
    /// face). Use trees, `as` aliases and `pub` prefixes are
    /// registered step-3+ faces and reject fail-closed.
    fn parse_use_decl(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwUse)?;
        // `use "name";` — the transitional string form (the module
        // name is a string datum; fail-closed elsewhere).
        if let TgtKind::Str(value) = self.peek().kind.clone() {
            let name_span = self.bump();
            let semi_span = self.expect(TgtKind::Semi)?;
            let items = vec![
                self.head_symbol("require", kw_span),
                self.atom(StxDatum::String(value), name_span),
            ];
            Ok(self.list(kw_span.start, items, semi_span.end))
        } else if matches!(self.peek().kind, TgtKind::Ident(_)) {
            // `use a::b::c;` — the path form (ruling D, switch-window-
            // plan §5.1): the module name rides the C-C1 `/`-joined
            // segments. Module names use the raw segment text — the
            // E5 batch-1 skin maps *value* names only, and the module
            // namespace is not the value namespace.
            let mut text = self.use_segment()?;
            while self.at(&TgtKind::ColonColon) {
                self.bump();
                if matches!(self.peek().kind, TgtKind::OpenBrace) {
                    // `a::{b, c}` — the use-tree form.
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "use tree or alias forms",
                        span: self.peek().span,
                    });
                }
                text.push('/');
                text.push_str(&self.use_segment()?);
            }
            if matches!(self.peek().kind, TgtKind::OpenBrace | TgtKind::KwAs) {
                return Err(ReadError::UnsupportedTargetForm {
                    form: "use tree or alias forms",
                    span: self.peek().span,
                });
            }
            let name_span_end = self.peek().span.end;
            let semi_span = self.expect(TgtKind::Semi)?;
            let items = vec![
                self.head_symbol("require", kw_span),
                self.atom(
                    StxDatum::String(std::rc::Rc::from(text.as_str())),
                    self.span_from(kw_span.start, name_span_end),
                ),
            ];
            Ok(self.list(kw_span.start, items, semi_span.end))
        } else {
            Err(ReadError::UnsupportedTargetForm {
                form: "use path form",
                span: self.peek().span,
            })
        }
    }

    /// One `use` path segment: the raw identifier text (the module
    /// namespace — deliberately not the E5 skin face).
    fn use_segment(&mut self) -> Result<String, ReadError> {
        if matches!(self.peek().kind, TgtKind::Ident(_)) {
            let text = self.peek().text.clone();
            self.bump();
            Ok(text)
        } else {
            Err(self.err_unexpected())
        }
    }

    fn expect_ident(&mut self) -> Result<IdentToken, ReadError> {
        if let TgtKind::Ident(symbol) = self.peek().kind.clone() {
            let span = self.bump();
            return Ok(IdentToken { symbol, span });
        }
        Err(self.err_unexpected())
    }

    fn reject_generics(&mut self) -> Result<(), ReadError> {
        if self.at(&TgtKind::Lt) {
            return Err(ReadError::UnsupportedTargetForm {
                form: "generic parameters",
                span: self.peek().span,
            });
        }
        Ok(())
    }

    // ---------- statements and blocks ----------

    /// `{ stmts [tail] }` -> the do/let fold. Plain statements ride a
    /// `do` (each discards into `_`, the Begin desugaring); a `let`
    /// swallows the remainder as its body. The fold is
    /// CoreExpr-identical to the flat `(do ...)` of the S-expression
    /// original (a nested `do` desugars to the same Let chain).
    fn parse_block(&mut self) -> Result<SyntaxObject, ReadError> {
        let open_span = self.expect(TgtKind::OpenBrace)?;
        let guard = self.enter()?;
        let mut entries: Vec<BlockEntry> = Vec::new();
        let mut tail: Option<SyntaxObject> = None;
        let close_span;
        loop {
            if self.at(&TgtKind::CloseBrace) {
                close_span = self.bump();
                break;
            }
            if self.at(&TgtKind::Eof) {
                self.leave(guard);
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: open_span.start,
                    opening: "{",
                });
            }
            if self.at(&TgtKind::KwLet) {
                let entry = self.parse_let_stmt()?;
                entries.push(entry);
                continue;
            }
            // Assignment statement: ident `=` (lookahead — `==` is a
            // distinct token, so the ambiguity cannot arise).
            if matches!(self.peek().kind, TgtKind::Ident(_)) && self.peek2().kind == TgtKind::Assign
            {
                let assign = self.parse_assign_stmt()?;
                entries.push(BlockEntry::Form(assign));
                continue;
            }
            let expr = self.parse_expr()?;
            if self.at(&TgtKind::Semi) {
                self.bump();
                entries.push(BlockEntry::Form(expr));
            } else if self.at(&TgtKind::CloseBrace) {
                tail = Some(expr);
            } else if self.at(&TgtKind::Eof) {
                // The tail expression consumed the last token: the
                // block itself is what ran out of input.
                self.leave(guard);
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: open_span.start,
                    opening: "{",
                });
            } else {
                self.leave(guard);
                return Err(self.err_unexpected());
            }
        }
        self.leave(guard);
        // The backwards fold.
        let mut cur = match tail {
            Some(form) => form,
            None => self.nil_form(close_span),
        };
        for entry in entries.iter().rev() {
            match entry {
                BlockEntry::Form(form) => {
                    let start = form.span.start;
                    let end = cur.span.end;
                    let head_span = form.span;
                    let items = vec![self.head_symbol("do", head_span), form.clone(), cur];
                    cur = self.list(start, items, end);
                }
                BlockEntry::Let {
                    bindings,
                    let_start,
                } => {
                    let end = cur.span.end;
                    let head_span = self.span_from(*let_start, ByteOffset(let_start.0 + 3));
                    let spec = self.binding_spec(bindings);
                    let items = vec![self.head_symbol("let", head_span), spec, cur];
                    cur = self.list(*let_start, items, end);
                }
            }
        }
        Ok(cur)
    }

    /// The binding spec: one pair -> `(name value)`; several ->
    /// `((n1 v1) (n2 v2) ...)` — both shapes the expander accepts,
    /// matching the corpus spelling (the r110 parity ruling).
    fn binding_spec(&self, bindings: &[(SyntaxObject, SyntaxObject)]) -> SyntaxObject {
        let start = bindings[0].0.span.start;
        let end = bindings.last().map(|(_, v)| v.span.end).unwrap_or(start);
        let pairs: Vec<SyntaxObject> = bindings
            .iter()
            .map(|(name, value)| {
                let pair_start = name.span.start;
                let pair_end = value.span.end;
                let pair = vec![name.clone(), value.clone()];
                self.list(pair_start, pair, pair_end)
            })
            .collect();
        if pairs.len() == 1 {
            return pairs.into_iter().next().expect("one pair");
        }
        self.list(start, pairs, end)
    }

    /// `let [mut] x [: T] = e { , [mut] y [: T] = e } ;` — the
    /// multi-binding comma form is the r110 ruling (sequential single
    /// lets would desugar to nested bindings and break bytecode
    /// parity with the multi-binding original).
    fn parse_let_stmt(&mut self) -> Result<BlockEntry, ReadError> {
        let kw_span = self.expect(TgtKind::KwLet)?;
        let mut bindings = Vec::new();
        loop {
            if self.at(&TgtKind::KwMut) {
                self.bump();
            }
            let name = self.expect_ident()?;
            let name_form = self.atom(StxDatum::Symbol(name.symbol), name.span);
            if self.at(&TgtKind::Colon) {
                self.bump();
                self.parse_type_drop()?;
            }
            self.expect(TgtKind::Assign)?;
            let value = self.parse_expr()?;
            bindings.push((name_form, value));
            if self.at(&TgtKind::Comma) {
                self.bump();
                continue;
            }
            break;
        }
        self.expect(TgtKind::Semi)?;
        Ok(BlockEntry::Let {
            bindings,
            let_start: kw_span.start,
        })
    }

    /// `x = e;` -> `(set! x e)`.
    fn parse_assign_stmt(&mut self) -> Result<SyntaxObject, ReadError> {
        let name = self.expect_ident()?;
        self.expect(TgtKind::Assign)?;
        let value = self.parse_expr()?;
        let semi_span = self.expect(TgtKind::Semi)?;
        let start = name.span.start;
        let items = vec![
            self.head_symbol("set!", name.span),
            self.atom(StxDatum::Symbol(name.symbol), name.span),
            value,
        ];
        Ok(self.list(start, items, semi_span.end))
    }

    // ---------- expressions (the §9.26.4 precedence cascade) ----------

    fn parse_expr(&mut self) -> Result<SyntaxObject, ReadError> {
        let expr = self.parse_or()?;
        if self.at(&TgtKind::DotDot) {
            return Err(ReadError::UnsupportedTargetForm {
                form: "range expression",
                span: self.peek().span,
            });
        }
        Ok(expr)
    }

    /// `||` — short-circuit desugar: `a || b` -> `(if a true b)`.
    fn parse_or(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut left = self.parse_and()?;
        while self.at(&TgtKind::OrOr) {
            let op_span = self.bump();
            let right = self.parse_and()?;
            let start = op_span.start;
            let end = right.span.end;
            let items = vec![
                self.head_symbol("if", op_span),
                left,
                self.atom(StxDatum::Bool(true), op_span),
                right,
            ];
            left = self.list(start, items, end);
        }
        Ok(left)
    }

    /// `&&` — short-circuit desugar: `a && b` -> `(if a b false)`.
    fn parse_and(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut left = self.parse_comparison()?;
        while self.at(&TgtKind::AndAnd) {
            let op_span = self.bump();
            let right = self.parse_comparison()?;
            let start = op_span.start;
            let end = right.span.end;
            let items = vec![
                self.head_symbol("if", op_span),
                left,
                right,
                self.atom(StxDatum::Bool(false), op_span),
            ];
            left = self.list(start, items, end);
        }
        Ok(left)
    }

    /// Comparisons do not chain (ambiguity ruling 19): at most one
    /// comparison operator per expression face. `!=` desugars through
    /// `not` (no `!=` builtin); `==` maps to the `=` builtin.
    fn parse_comparison(&mut self) -> Result<SyntaxObject, ReadError> {
        let left = self.parse_bitor()?;
        let op_text = match self.peek().kind {
            TgtKind::EqEq => Some("="),
            TgtKind::NotEq => Some("!="),
            TgtKind::Lt => Some("<"),
            TgtKind::Gt => Some(">"),
            TgtKind::Le => Some("<="),
            TgtKind::Ge => Some(">="),
            _ => None,
        };
        let Some(op_text) = op_text else {
            return Ok(left);
        };
        let op_span = self.bump();
        let right = self.parse_bitor()?;
        let joined = if op_text == "!=" {
            let eq_form = self.binop_form("=", op_span, left, right);
            let start = op_span.start;
            let end = eq_form.span.end;
            let items = vec![self.head_symbol("not", op_span), eq_form];
            self.list(start, items, end)
        } else {
            self.binop_form(op_text, op_span, left, right)
        };
        // Reject the chain: another comparison operator here is the
        // ruling-19 non-chainable face.
        if matches!(
            self.peek().kind,
            TgtKind::EqEq | TgtKind::NotEq | TgtKind::Lt | TgtKind::Gt | TgtKind::Le | TgtKind::Ge
        ) {
            return Err(self.err_unexpected());
        }
        Ok(joined)
    }

    fn parse_bitor(&mut self) -> Result<SyntaxObject, ReadError> {
        self.parse_binary_chain(TgtKind::Pipe, "|", Self::parse_bitxor)
    }

    fn parse_bitxor(&mut self) -> Result<SyntaxObject, ReadError> {
        self.parse_binary_chain(TgtKind::Caret, "^", Self::parse_bitand)
    }

    fn parse_bitand(&mut self) -> Result<SyntaxObject, ReadError> {
        self.parse_binary_chain(TgtKind::Amp, "&", Self::parse_shift)
    }

    fn parse_shift(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut left = self.parse_arith()?;
        loop {
            let op_text = match self.peek().kind {
                TgtKind::Shl => "<<",
                TgtKind::Shr => ">>",
                _ => break,
            };
            let op_span = self.bump();
            let right = self.parse_arith()?;
            left = self.binop_form(op_text, op_span, left, right);
        }
        Ok(left)
    }

    fn parse_arith(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut left = self.parse_term()?;
        loop {
            let op_text = match self.peek().kind {
                TgtKind::Plus => "+",
                TgtKind::Minus => "-",
                _ => break,
            };
            let op_span = self.bump();
            let right = self.parse_term()?;
            left = self.binop_form(op_text, op_span, left, right);
        }
        Ok(left)
    }

    fn parse_term(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut left = self.parse_unary()?;
        loop {
            let op_text = match self.peek().kind {
                TgtKind::Star => "*",
                TgtKind::Slash => "/",
                TgtKind::Percent => "%",
                _ => break,
            };
            let op_span = self.bump();
            let right = self.parse_unary()?;
            left = self.binop_form(op_text, op_span, left, right);
        }
        Ok(left)
    }

    fn parse_binary_chain(
        &mut self,
        op_kind: TgtKind,
        op_text: &str,
        next: fn(&mut Self) -> Result<SyntaxObject, ReadError>,
    ) -> Result<SyntaxObject, ReadError> {
        let mut left = next(self)?;
        while self.at(&op_kind) {
            let op_span = self.bump();
            let right = next(self)?;
            left = self.binop_form(op_text, op_span, left, right);
        }
        Ok(left)
    }

    /// Unary `-e` -> `(- 0 e)`; `!e` -> `(not e)`.
    fn parse_unary(&mut self) -> Result<SyntaxObject, ReadError> {
        if self.at(&TgtKind::Minus) {
            let op_span = self.bump();
            let operand = self.parse_unary()?;
            let start = op_span.start;
            let end = operand.span.end;
            let items = vec![
                self.head_symbol("-", op_span),
                self.atom(StxDatum::Int(0), op_span),
                operand,
            ];
            return Ok(self.list(start, items, end));
        }
        if self.at(&TgtKind::Bang) {
            let op_span = self.bump();
            let operand = self.parse_unary()?;
            let start = op_span.start;
            let end = operand.span.end;
            let items = vec![self.head_symbol("not", op_span), operand];
            return Ok(self.list(start, items, end));
        }
        self.parse_postfix()
    }

    /// Postfix: calls `f(args)`, macro invocations `name!(args)` (the
    /// `!` marker drops — the head resolves through the expander's
    /// scope-keyed judgment), and the seed-scope rejections (field/
    /// method access, indexing, casts).
    fn parse_postfix(&mut self) -> Result<SyntaxObject, ReadError> {
        let mut expr = self.parse_primary()?;
        loop {
            match self.peek().kind {
                TgtKind::OpenParen | TgtKind::Bang => {
                    // The macro marker drops; both faces share the
                    // call mapping.
                    if self.at(&TgtKind::Bang) {
                        self.bump();
                    }
                    let open_span = self.expect(TgtKind::OpenParen)?;
                    let guard = self.enter()?;
                    // The quote datum carrier (ruling F — the
                    // pattern-position tuple skin extended to quoted
                    // data): `quote(<datum>)` parses its single
                    // argument in datum mode, where `(d1, d2, ...)`
                    // is a list datum — the exact tree the S-expr
                    // face's `(quote (d1 d2 ...))` produces.
                    if matches!(&expr.datum, StxDatum::Symbol(s) if s.as_str() == "quote") {
                        if self.at(&TgtKind::CloseParen) {
                            self.leave(guard);
                            return Err(self.err_unexpected());
                        }
                        let datum = self.parse_datum()?;
                        if !self.at(&TgtKind::CloseParen) {
                            self.leave(guard);
                            return Err(ReadError::UnsupportedTargetForm {
                                form: "quote carries data, not expressions",
                                span: self.peek().span,
                            });
                        }
                        let close_span = self.bump();
                        self.leave(guard);
                        let end = close_span.end;
                        expr = self.list(open_span.start, vec![expr, datum], end);
                        continue;
                    }
                    let mut args = Vec::new();
                    if !self.at(&TgtKind::CloseParen) {
                        loop {
                            args.push(self.parse_expr()?);
                            if self.at(&TgtKind::Comma) {
                                self.bump();
                                continue;
                            }
                            break;
                        }
                    }
                    let close_span = self.expect(TgtKind::CloseParen)?;
                    self.leave(guard);
                    let mut items = vec![expr];
                    items.extend(args);
                    expr = self.list(open_span.start, items, close_span.end);
                }
                TgtKind::OpenBracket => {
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "index expression",
                        span: self.peek().span,
                    });
                }
                TgtKind::Dot => {
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "field or method access",
                        span: self.peek().span,
                    });
                }
                TgtKind::KwAs => {
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "cast expression",
                        span: self.peek().span,
                    });
                }
                _ => break,
            }
        }
        Ok(expr)
    }

    fn parse_primary(&mut self) -> Result<SyntaxObject, ReadError> {
        let token = self.peek().clone_shallow();
        match token.kind {
            TgtKind::Int(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Int(v), token.span))
            }
            TgtKind::Float(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Float(v), token.span))
            }
            TgtKind::Str(ref value) => {
                let value = value.clone();
                self.bump();
                Ok(self.atom(StxDatum::String(value), token.span))
            }
            TgtKind::Bool(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Bool(v), token.span))
            }
            TgtKind::Ident(_) => self.parse_path(),
            TgtKind::OpenParen => {
                // `()` is the unit skin (ruling C12); `(e)` groups.
                self.bump();
                let guard = self.enter()?;
                if self.at(&TgtKind::CloseParen) {
                    let close_span = self.bump();
                    self.leave(guard);
                    return Ok(self.nil_form(close_span));
                }
                let inner = self.parse_expr()?;
                self.expect(TgtKind::CloseParen)?;
                self.leave(guard);
                Ok(inner)
            }
            TgtKind::OpenBrace => self.parse_block(),
            TgtKind::OpenBracket => Err(ReadError::UnsupportedTargetForm {
                form: "array or index syntax",
                span: token.span,
            }),
            TgtKind::OrOr | TgtKind::KwMove => self.parse_closure(),
            TgtKind::KwIf => self.parse_if_expr(),
            TgtKind::KwPerform => self.parse_perform_expr(),
            TgtKind::KwHandle => self.parse_handle_expr(),
            TgtKind::KwFn => Err(ReadError::UnsupportedTargetForm {
                form: "fn expression (closures use `||`)",
                span: token.span,
            }),
            TgtKind::KwMatch => self.parse_match_expr(),
            TgtKind::KwStruct
            | TgtKind::KwEnum
            | TgtKind::KwType
            | TgtKind::KwEffect
            | TgtKind::KwCapability => Err(ReadError::UnsupportedTargetForm {
                form: "type declarations",
                span: token.span,
            }),
            TgtKind::KwImpl => Err(ReadError::UnsupportedTargetForm {
                form: "impl expressions",
                span: token.span,
            }),
            TgtKind::KwResume | TgtKind::KwHalt | TgtKind::KwPass => {
                Err(ReadError::UnsupportedTargetForm {
                    form: "handler body keyword outside a handler arm",
                    span: token.span,
                })
            }
            TgtKind::CloseBrace => Err(ReadError::StrayTargetDelim {
                closing: '}',
                at: token.span.start,
            }),
            TgtKind::CloseParen => Err(ReadError::StrayTargetDelim {
                closing: ')',
                at: token.span.start,
            }),
            TgtKind::CloseBracket => Err(ReadError::StrayTargetDelim {
                closing: ']',
                at: token.span.start,
            }),
            _ => Err(self.err_unexpected()),
        }
    }

    /// A path: `a::b::c` -> the symbol `a/b/c` (the C-C1 separator
    /// mapping — the S-expression face spells qualified names with
    /// `/` inside identifiers).
    fn parse_path(&mut self) -> Result<SyntaxObject, ReadError> {
        let first = self.expect_ident()?;
        let mut text = first.symbol.as_str().to_string();
        let start = first.span.start;
        let mut end = first.span.end;
        while self.at(&TgtKind::ColonColon) {
            self.bump();
            let segment = self.expect_ident()?;
            text.push('/');
            text.push_str(segment.symbol.as_str());
            end = segment.span.end;
        }
        let symbol = ident_symbol(&text)?;
        Ok(self.atom(StxDatum::Symbol(symbol), self.span_from(start, end)))
    }

    /// One quoted datum (ruling F — the quote datum carrier, the
    /// step-3 corpus-translation ruling): the tuple skin of pattern
    /// position extended to quoted data.
    ///
    /// - `(d1, d2, ..., dn)` with n >= 2 is a **list datum** — the
    ///   exact tree the S-expr face's `(quote (d1 d2 ...))` reads;
    /// - `(d)` groups (the `tuple_pattern` passthrough);
    /// - `()` is fail-closed: the S-expr face rejects `(quote ())`
    ///   (subset-spec §2.5) — `nil` is the datum face of the empty
    ///   list (the record encoders' convention);
    /// - word faces and paths quote as symbols (the skin map
    ///   applies — quoted kebab data rides the target spellings);
    /// - numeric literals may carry a leading `-`.
    ///
    /// Everything else — operators, blocks, calls — is data the
    /// kernel does not have and rejects fail-closed.
    fn parse_datum(&mut self) -> Result<SyntaxObject, ReadError> {
        let token = self.peek().clone_shallow();
        match token.kind {
            TgtKind::Int(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Int(v), token.span))
            }
            TgtKind::Float(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Float(v), token.span))
            }
            TgtKind::Str(ref value) => {
                let value = value.clone();
                self.bump();
                Ok(self.atom(StxDatum::String(value), token.span))
            }
            TgtKind::Bool(v) => {
                self.bump();
                Ok(self.atom(StxDatum::Bool(v), token.span))
            }
            TgtKind::Ident(_) => self.parse_path(),
            TgtKind::Minus => {
                // A negative numeric literal is data too.
                self.bump();
                let next = self.peek().clone_shallow();
                let span = self.span_from(token.span.start, next.span.end);
                match next.kind {
                    TgtKind::Int(v) => {
                        self.bump();
                        let neg = v.checked_neg().ok_or_else(|| ReadError::IntOutOfRange {
                            text: format!("-{v}"),
                            span,
                        })?;
                        Ok(self.atom(StxDatum::Int(neg), span))
                    }
                    TgtKind::Float(v) => {
                        self.bump();
                        Ok(self.atom(StxDatum::Float(-v), span))
                    }
                    _ => Err(ReadError::UnsupportedTargetForm {
                        form: "quote carries data, not expressions",
                        span: token.span,
                    }),
                }
            }
            ref kind if word_text(kind).is_some() => {
                self.bump();
                let text = word_text(&token.kind).expect("the guard checked the word face");
                let symbol = Symbol::new(text).expect("word faces are valid symbols");
                Ok(self.atom(StxDatum::Symbol(symbol), token.span))
            }
            TgtKind::OpenParen => {
                self.bump();
                let guard = self.enter()?;
                if self.at(&TgtKind::CloseParen) {
                    self.leave(guard);
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "the empty quoted list (write `nil` — the datum face of the empty list)",
                        span: token.span,
                    });
                }
                let mut items = vec![self.parse_datum()?];
                let mut is_list = false;
                while self.at(&TgtKind::Comma) {
                    is_list = true;
                    self.bump();
                    // A trailing comma closes the list (the Rust
                    // tuple convention): `(d,)` is a ONE-element
                    // list — the grouping passthrough `(d)` stays
                    // a bare datum.
                    if self.at(&TgtKind::CloseParen) {
                        break;
                    }
                    items.push(self.parse_datum()?);
                }
                if !self.at(&TgtKind::CloseParen) {
                    self.leave(guard);
                    return Err(ReadError::UnsupportedTargetForm {
                        form: "quote carries data, not expressions",
                        span: self.peek().span,
                    });
                }
                let close_span = self.bump();
                // The success path leaves too — the guard is
                // released on EVERY path (the parse_pattern
                // precedent's discipline; without this the depth
                // meter leaks one level per sequential datum
                // bracket, and a wide record stream — the step-4
                // compiler twin's item stream, 200+ records —
                // trips the nesting limit without any real
                // nesting: sequential brackets accumulated).
                self.leave(guard);
                if is_list {
                    Ok(self.list(token.span.start, items, close_span.end))
                } else {
                    // `(d)` groups — the tuple_pattern passthrough.
                    Ok(items.pop().expect("the single datum is present"))
                }
            }
            _ => Err(ReadError::UnsupportedTargetForm {
                form: "quote carries data, not expressions",
                span: token.span,
            }),
        }
    }

    /// `[move] || ( params ) -> T { body }` -> `(fn (params) body)`.
    fn parse_closure(&mut self) -> Result<SyntaxObject, ReadError> {
        let start = self.peek().span.start;
        if self.at(&TgtKind::KwMove) {
            self.bump();
        }
        self.expect(TgtKind::OrOr)?;
        let mut params = Vec::new();
        if self.at(&TgtKind::OpenParen) {
            params = self.parse_params()?;
        }
        if self.at(&TgtKind::Arrow) {
            self.bump();
            self.parse_type_drop()?;
        }
        let body = self.parse_block()?;
        let params_end = params.last().map(|p| p.span.end).unwrap_or(start);
        let params_list = self.list(start, params, params_end);
        let head_span = self.span_from(start, ByteOffset(start.0 + 2));
        let end = body.span.end;
        let items = vec![self.head_symbol("fn", head_span), params_list, body];
        Ok(self.list(start, items, end))
    }

    /// `if c { t } [else (if | { e })]` -> `(if c t e)` — a missing
    /// else desugars to the unit value (the kernel's `if` is
    /// two-armed).
    fn parse_if_expr(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwIf)?;
        let cond = self.parse_expr()?;
        let then_block = self.parse_block()?;
        let else_form = if self.at(&TgtKind::KwElse) {
            self.bump();
            if self.at(&TgtKind::KwIf) {
                self.parse_if_expr()?
            } else {
                self.parse_block()?
            }
        } else {
            self.nil_form(then_block.span)
        };
        let start = kw_span.start;
        let end = else_form.span.end;
        let items = vec![self.head_symbol("if", kw_span), cond, then_block, else_form];
        Ok(self.list(start, items, end))
    }

    /// `perform E(args)` -> `(perform E args...)`.
    fn parse_perform_expr(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwPerform)?;
        let effect = self.parse_path()?;
        self.expect(TgtKind::OpenParen)?;
        let guard = self.enter()?;
        let mut args = Vec::new();
        if !self.at(&TgtKind::CloseParen) {
            loop {
                args.push(self.parse_expr()?);
                if self.at(&TgtKind::Comma) {
                    self.bump();
                    continue;
                }
                break;
            }
        }
        let close_span = self.expect(TgtKind::CloseParen)?;
        self.leave(guard);
        let start = kw_span.start;
        let mut items = vec![self.head_symbol("perform", kw_span), effect];
        items.extend(args);
        Ok(self.list(start, items, close_span.end))
    }

    /// `handle body { arms }` -> `(handle body (E (fn (p...) e))...)`.
    /// Handler bodies: `resume(e)` (the handler return *is* the
    /// resumption — the drop is the skin entry) or a block; `halt`/
    /// `pass` reject fail-closed (no core counterpart yet — a step 2
    /// registration).
    fn parse_handle_expr(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwHandle)?;
        let body = self.parse_expr()?;
        let open_span = self.expect(TgtKind::OpenBrace)?;
        let guard = self.enter()?;
        let mut arms = Vec::new();
        loop {
            if self.at(&TgtKind::CloseBrace) {
                break;
            }
            if self.at(&TgtKind::Eof) {
                self.leave(guard);
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: open_span.start,
                    opening: "{",
                });
            }
            let effect = self.parse_path()?;
            let effect_symbol = match &effect.datum {
                StxDatum::Symbol(symbol) => symbol.clone(),
                _ => {
                    return Err(ReadError::UnexpectedTargetToken {
                        text: effect.datum.to_string(),
                        span: effect.span,
                    });
                }
            };
            let mut params = Vec::new();
            if self.at(&TgtKind::OpenParen) {
                params = self.parse_params()?;
            }
            self.expect(TgtKind::FatArrow)?;
            let handler_body = if self.at(&TgtKind::KwResume) {
                self.bump();
                self.expect(TgtKind::OpenParen)?;
                let value = self.parse_expr()?;
                self.expect(TgtKind::CloseParen)?;
                value
            } else if self.at(&TgtKind::KwHalt) {
                self.leave(guard);
                return Err(ReadError::UnsupportedTargetForm {
                    form: "halt handler body",
                    span: self.peek().span,
                });
            } else if self.at(&TgtKind::KwPass) {
                self.leave(guard);
                return Err(ReadError::UnsupportedTargetForm {
                    form: "pass handler body",
                    span: self.peek().span,
                });
            } else {
                self.parse_block()?
            };
            self.expect(TgtKind::Comma)?;
            // The arm: (E (fn (params...) body)).
            let arm_start = effect.span.start;
            let params_end = params.last().map(|p| p.span.end).unwrap_or(arm_start);
            let params_list = self.list(arm_start, params, params_end);
            let fn_end = handler_body.span.end;
            let fn_items = vec![
                self.head_symbol("fn", effect.span),
                params_list,
                handler_body,
            ];
            let fn_form = self.list(arm_start, fn_items, fn_end);
            let arm_end = fn_form.span.end;
            let arm = vec![
                self.atom(StxDatum::Symbol(effect_symbol), effect.span),
                fn_form,
            ];
            arms.push(self.list(arm_start, arm, arm_end));
        }
        let close_span = self.bump();
        self.leave(guard);
        let start = kw_span.start;
        let mut items = vec![self.head_symbol("handle", kw_span), body];
        items.extend(arms);
        Ok(self.list(start, items, close_span.end))
    }

    /// `match e { pattern => block, ... }` -> `(match e' (pattern'
    /// block')...)` — the classification sugar on the target skin
    /// (ruling A, switch-window-plan §5.1). Arm bodies are blocks
    /// (v9 match_arm); the trailing comma per arm is mandatory (the
    /// handle-arm discipline). A guard after a pattern rejects
    /// fail-closed (the registered face — fallthrough duplication is
    /// an optimization-window problem, not a step-2 one).
    fn parse_match_expr(&mut self) -> Result<SyntaxObject, ReadError> {
        let kw_span = self.expect(TgtKind::KwMatch)?;
        let scrutinee = self.parse_expr()?;
        let open_span = self.expect(TgtKind::OpenBrace)?;
        let guard = self.enter()?;
        let mut arms = Vec::new();
        loop {
            if self.at(&TgtKind::CloseBrace) {
                break;
            }
            if self.at(&TgtKind::Eof) {
                self.leave(guard);
                return Err(ReadError::UnclosedTargetDelim {
                    opened_at: open_span.start,
                    opening: "{",
                });
            }
            if matches!(self.peek().kind, TgtKind::Pipe) {
                self.leave(guard);
                return Err(ReadError::UnsupportedTargetForm {
                    form: "or-patterns",
                    span: self.peek().span,
                });
            }
            let pattern = self.parse_pattern()?;
            if matches!(self.peek().kind, TgtKind::Pipe) {
                // `1 | 2` — the or-pattern continues after the first
                // pattern; reject with the same face either side.
                self.leave(guard);
                return Err(ReadError::UnsupportedTargetForm {
                    form: "or-patterns",
                    span: self.peek().span,
                });
            }
            if self.at(&TgtKind::KwIf) {
                self.leave(guard);
                return Err(ReadError::UnsupportedTargetForm {
                    form: "match arm guards",
                    span: self.peek().span,
                });
            }
            self.expect(TgtKind::FatArrow)?;
            let body = self.parse_block()?;
            self.expect(TgtKind::Comma)?;
            let arm_start = pattern.span.start;
            let arm_end = body.span.end;
            let arm = self.list(arm_start, vec![pattern, body], arm_end);
            arms.push(arm);
        }
        if arms.is_empty() {
            self.leave(guard);
            return Err(ReadError::UnexpectedTargetToken {
                text: "}".to_string(),
                span: self.peek().span,
            });
        }
        let close_span = self.bump();
        self.leave(guard);
        let start = kw_span.start;
        let mut items = vec![self.head_symbol("match", kw_span), scrutinee];
        items.extend(arms);
        Ok(self.list(start, items, close_span.end))
    }

    /// One match pattern -> the S-expr face pattern Stx (switch-
    /// window-plan §5.2): literals ride their atoms, `mut x`/`x`
    /// bind (the `mut` drops — the core binding is immutable),
    /// `()` is the nil pattern (C12), `(p)` rides a one-element list
    /// (the parenthesized pass-through), `(p1, p2)` a two-element
    /// list (the pair shape). Paths, `@` bindings, variant and struct
    /// patterns reject fail-closed (registered faces).
    fn parse_pattern(&mut self) -> Result<SyntaxObject, ReadError> {
        match self.peek().kind.clone() {
            TgtKind::Int(value) => {
                let span = self.bump();
                Ok(self.atom(StxDatum::Int(value), span))
            }
            TgtKind::Float(value) => {
                let span = self.bump();
                Ok(self.atom(StxDatum::Float(value), span))
            }
            TgtKind::Bool(value) => {
                let span = self.bump();
                Ok(self.atom(StxDatum::Bool(value), span))
            }
            TgtKind::Str(value) => {
                let span = self.bump();
                Ok(self.atom(StxDatum::String(value), span))
            }
            TgtKind::KwMut => {
                // `[ "mut" ] identifier` — the mutability marker is
                // surface sugar (the let/param discipline).
                self.bump();
                let ident = self.expect_ident()?;
                Ok(self.atom(StxDatum::Symbol(ident.symbol), ident.span))
            }
            TgtKind::Ident(_) => {
                let ident = self.expect_ident()?;
                Ok(self.atom(StxDatum::Symbol(ident.symbol), ident.span))
            }
            TgtKind::OpenParen => {
                let open_span = self.bump();
                let guard = self.enter()?;
                let result = (|| {
                    if self.at(&TgtKind::CloseParen) {
                        // `()` — the nil pattern (C12: unit is nil).
                        let close_span = self.expect(TgtKind::CloseParen)?;
                        let span = self.span_from(open_span.start, close_span.end);
                        return Ok(self.head_symbol("nil", span));
                    }
                    let mut elements = vec![self.parse_pattern()?];
                    while self.at(&TgtKind::Comma) {
                        self.bump();
                        if self.at(&TgtKind::CloseParen) {
                            // Trailing comma before `)` — reject: the
                            // two-element tuple is exactly two
                            // patterns with no trailing slot.
                            return Err(self.err_unexpected());
                        }
                        if elements.len() == 2 {
                            // Three or more elements — the registered
                            // family (Type::Pair is two-ary).
                            return Err(ReadError::UnsupportedTargetForm {
                                form: "tuple patterns with three or more elements",
                                span: self.peek().span,
                            });
                        }
                        elements.push(self.parse_pattern()?);
                    }
                    let close_span = self.expect(TgtKind::CloseParen)?;
                    Ok(self.list(open_span.start, elements, close_span.end))
                })();
                self.leave(guard);
                result
            }
            _ => Err(ReadError::UnsupportedTargetForm {
                form: "pattern syntax (paths, `@` bindings, variant and struct patterns are not implemented)",
                span: self.peek().span,
            }),
        }
    }

    /// Types parse and drop (annotations are surface sugar). The
    /// grammar face: paths (with parenthesized argument lists —
    /// `Return(i64)`, `Fn(i64) -> i64`), parenthesized type lists,
    /// effect unions (`|`), function returns (`->`), the `impl` and
    /// `effect` prefixes. Generic arguments reject (step 2).
    fn parse_type_drop(&mut self) -> Result<(), ReadError> {
        match self.peek().kind {
            TgtKind::KwImpl | TgtKind::KwEffect => {
                self.bump();
            }
            TgtKind::OpenParen => {
                self.parse_type_parens()?;
            }
            TgtKind::Ident(_) => {
                self.parse_path()?;
                // Generic arguments (`Foo<i64>`) are part of the
                // annotation surface — parse and drop together with
                // the type (ruling C1 second half, switch-window-plan
                // §5.1: adt_type is a legitimate v9 production, so
                // the argument list rides the annotation-drop face).
                if self.at(&TgtKind::Lt) {
                    self.parse_generic_args_drop()?;
                }
                if self.at(&TgtKind::OpenParen) {
                    self.parse_type_parens()?;
                }
            }
            _ => return Err(self.err_unexpected()),
        }
        while matches!(self.peek().kind, TgtKind::Pipe | TgtKind::Arrow) {
            self.bump();
            self.parse_type_drop()?;
        }
        Ok(())
    }

    /// A parenthesized type list: `( T, T, ... )` or `()`.
    fn parse_type_parens(&mut self) -> Result<(), ReadError> {
        self.expect(TgtKind::OpenParen)?;
        let guard = self.enter()?;
        let result = (|| {
            if !self.at(&TgtKind::CloseParen) {
                loop {
                    self.parse_type_drop()?;
                    if self.at(&TgtKind::Comma) {
                        self.bump();
                        continue;
                    }
                    break;
                }
            }
            self.expect(TgtKind::CloseParen)?;
            Ok(())
        })();
        self.leave(guard);
        result
    }

    /// A generic-argument list `< T, T, ... >` — parse and drop (the
    /// annotation surface; ruling C1 second half). The `>` closes;
    /// nested argument lists recurse through [`parse_type_drop`].
    fn parse_generic_args_drop(&mut self) -> Result<(), ReadError> {
        self.expect(TgtKind::Lt)?;
        let guard = self.enter()?;
        let result = (|| {
            if !self.at(&TgtKind::Gt) {
                loop {
                    self.parse_type_drop()?;
                    if self.at(&TgtKind::Comma) {
                        self.bump();
                        continue;
                    }
                    break;
                }
            }
            self.expect(TgtKind::Gt)?;
            Ok(())
        })();
        self.leave(guard);
        result
    }
}

impl TgtToken {
    /// Clone without the lexeme (the parser only reads `text` on the
    /// error path, through the live token).
    fn clone_shallow(&self) -> TgtToken {
        TgtToken {
            kind: self.kind.clone(),
            span: self.span,
            text: String::new(),
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    //! Unit tests for the target-skin seed: each skin-dictionary
    //! mapping (asserted through the Stx `Display` — the S-expression
    //! notation) and each error face.

    use super::*;

    fn read(src: &str) -> Result<Vec<SyntaxObject>, ReadError> {
        read_target_program(FileId(0), src)
    }

    fn one(src: &str) -> String {
        let forms = read(src).expect("target source parses");
        assert_eq!(forms.len(), 1, "one top-level form expected");
        forms[0].datum.to_string()
    }

    // ---------- items ----------

    #[test]
    fn fn_decl_maps_to_define_sugar() {
        assert_eq!(
            one("fn add(a: i64, b: i64) -> i64 { a + b }"),
            "(define (add a b) (+ a b))"
        );
    }

    #[test]
    fn fn_decl_zero_params_and_mut_drop() {
        assert_eq!(one("fn f(mut x) { x }"), "(define (f x) x)");
        assert_eq!(one("fn f() { 1 }"), "(define (f) 1)");
    }

    #[test]
    fn value_define_rides_the_call_form() {
        assert_eq!(
            one("define(result, add(1, 2));"),
            "(define result (add 1 2))"
        );
    }

    #[test]
    fn module_and_use_map_to_their_forms() {
        assert_eq!(one("use \"math\";"), "(require \"math\")");
        assert_eq!(
            one("module m { fn f() { 1 } }"),
            "(module m (define (f) 1))"
        );
    }

    #[test]
    fn quote_rides_the_call_form() {
        assert_eq!(one("quote(sym);"), "(quote sym)");
    }

    // ---------- statements and blocks ----------

    #[test]
    fn single_let_swallows_the_rest() {
        assert_eq!(
            one("define(r, { let x = 1; x });"),
            "(define r (let (x 1) x))"
        );
    }

    #[test]
    fn multi_let_comma_form_is_one_binding_spec() {
        assert_eq!(
            one("define(r, { let a = 1, b = 2; a + b });"),
            "(define r (let ((a 1) (b 2)) (+ a b)))"
        );
    }

    #[test]
    fn plain_statements_ride_do() {
        assert_eq!(
            one("define(r, { f(1); g(2); });"),
            "(define r (do (f 1) (do (g 2) nil)))"
        );
    }

    #[test]
    fn block_tail_is_the_value() {
        assert_eq!(one("define(r, { f(1); 2 });"), "(define r (do (f 1) 2))");
    }

    #[test]
    fn empty_block_is_unit() {
        assert_eq!(one("define(r, { });"), "(define r nil)");
    }

    #[test]
    fn assign_maps_to_set() {
        assert_eq!(
            one("define(r, { let x = 1; x = 2; x });"),
            "(define r (let (x 1) (do (set! x 2) x)))"
        );
    }

    // ---------- expressions ----------

    #[test]
    fn operator_cascade_maps_to_application_forms() {
        assert_eq!(one("define(r, 1 + 2 * 3);"), "(define r (+ 1 (* 2 3)))");
        assert_eq!(one("define(r, (1 + 2) * 3);"), "(define r (* (+ 1 2) 3))");
        assert_eq!(one("define(r, 10 - 4 / 2);"), "(define r (- 10 (/ 4 2)))");
        assert_eq!(one("define(r, 1 << 2);"), "(define r (<< 1 2))");
        assert_eq!(one("define(r, 7 & 3);"), "(define r (& 7 3))");
    }

    #[test]
    fn equality_and_inequality_skin() {
        assert_eq!(one("define(r, 1 == 2);"), "(define r (= 1 2))");
        assert_eq!(one("define(r, 1 != 2);"), "(define r (not (= 1 2)))");
        assert_eq!(one("define(r, 1 <= 2);"), "(define r (<= 1 2))");
    }

    #[test]
    fn short_circuit_desugars() {
        // `a && b` -> (if a b false); `a || b` -> (if a true b).
        assert_eq!(one("define(r, x && y);"), "(define r (if x y false))");
        assert_eq!(one("define(r, x || y);"), "(define r (if x true y))");
        assert_eq!(
            one("define(r, x && y && z);"),
            "(define r (if (if x y false) z false))"
        );
    }

    #[test]
    fn unary_operators() {
        assert_eq!(one("define(r, -x);"), "(define r (- 0 x))");
        assert_eq!(one("define(r, !x);"), "(define r (not x))");
    }

    #[test]
    fn calls_and_qualified_paths() {
        assert_eq!(one("define(r, f());"), "(define r (f))");
        assert_eq!(one("define(r, f(1, 2));"), "(define r (f 1 2))");
        assert_eq!(
            one("define(r, string::append(a, b));"),
            "(define r (string/append a b))"
        );
    }

    #[test]
    fn macro_marker_drops() {
        assert_eq!(one("define(r, m!(1));"), "(define r (m 1))");
    }

    #[test]
    fn closure_maps_to_fn() {
        assert_eq!(
            one("define(r, ||(a, b) { a + b });"),
            "(define r (fn (a b) (+ a b)))"
        );
        assert_eq!(one("define(r, || { 1 });"), "(define r (fn () 1))");
        assert_eq!(one("define(r, move || { 1 });"), "(define r (fn () 1))");
    }

    #[test]
    fn if_maps_with_else_default() {
        assert_eq!(
            one("define(r, if x { 1 } else { 2 });"),
            "(define r (if x 1 2))"
        );
        assert_eq!(one("define(r, if x { 1 });"), "(define r (if x 1 nil))");
        assert_eq!(
            one("define(r, if a { 1 } else if b { 2 } else { 3 });"),
            "(define r (if a 1 (if b 2 3)))"
        );
    }

    #[test]
    fn perform_maps_with_args() {
        assert_eq!(
            one("define(r, perform Add(1, 2));"),
            "(define r (perform Add 1 2))"
        );
        assert_eq!(one("define(r, perform Log());"), "(define r (perform Log))");
    }

    #[test]
    fn handle_maps_to_closure_arms() {
        assert_eq!(
            one("define(r, handle perform Add(1, 2) { Add(a, b) => resume(a + b), });"),
            "(define r (handle (perform Add 1 2) (Add (fn (a b) (+ a b)))))"
        );
    }

    #[test]
    fn literals_map_to_datums() {
        assert_eq!(one("define(r, 42);"), "(define r 42)");
        assert_eq!(one("define(r, 0x1F);"), "(define r 31)");
        assert_eq!(one("define(r, 1_000);"), "(define r 1000)");
        assert_eq!(one("define(r, 2.5);"), "(define r 2.5)");
        assert_eq!(one("define(r, \"s\");"), "(define r \"s\")");
        assert_eq!(one("define(r, true);"), "(define r true)");
        assert_eq!(one("define(r, ());"), "(define r nil)");
    }

    #[test]
    fn comments_and_separators_are_ignored() {
        assert_eq!(
            one("define(r, 1 // line\n + /* nested /* inner */ */ 2);"),
            "(define r (+ 1 2))"
        );
    }

    // ---------- negative faces ----------

    #[test]
    fn rejects_struct_out_of_seed_scope() {
        let err = read("struct P { x: i64, }").expect_err("struct rejects");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "type declarations"
        ));
    }

    #[test]
    fn match_maps_to_the_s_expr_arm_list() {
        // Step 2 (ruling A): match is core-mapped now — the arm list
        // rides `(match scrutinee (pattern body)...)` with `()` the
        // nil pattern (C12) and `(a, b)` the pair shape.
        assert_eq!(
            one("define(r, match x { 1 => { 10 }, _ => { 20 }, });"),
            "(define r (match x (1 10) (_ 20)))"
        );
        assert_eq!(
            one("define(r, match p { (a, b) => { a }, nil => { 0 }, _ => { 0 - 1 }, });"),
            "(define r (match p ((a b) a) (nil 0) (_ (- 0 1))))"
        );
        // The `mut` marker drops (identifier_pattern surface sugar).
        assert_eq!(
            one("define(r, match x { mut y => { y }, });"),
            "(define r (match x (y y)))"
        );
    }

    #[test]
    fn match_guard_and_or_pattern_reject_fail_closed() {
        let guard_err =
            read("define(r, match x { 1 if x > 0 => { 1 }, _ => { 2 }, });").expect_err("guard");
        assert!(matches!(
            guard_err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "match arm guards"
        ));
        let or_err =
            read("define(r, match x { 1 | 2 => { 1 }, _ => { 2 }, });").expect_err("or-pattern");
        assert!(matches!(
            or_err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "or-patterns"
        ));
        // Three-element tuples are the registered family (Type::Pair
        // is two-ary).
        let tuple_err =
            read("define(r, match x { (a, b, c) => { a }, _ => { 0 }, });").expect_err("3-tuple");
        assert!(
            matches!(tuple_err, ReadError::UnsupportedTargetForm { form, .. } if form
                == "tuple patterns with three or more elements")
        );
    }

    #[test]
    fn use_path_form_maps_through_c_c1() {
        // Ruling D: `use a::b::c;` -> `(require "a/b/c")` — module
        // names ride the raw segment text (not the E5 skin face).
        assert_eq!(one("use a::b::c;"), "(require \"a/b/c\")");
        assert_eq!(one("use math;"), "(require \"math\")");
        // Use trees and aliases are registered faces.
        let tree_err = read("use a::{b, c};").expect_err("use tree rejects");
        assert!(matches!(
            tree_err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "use tree or alias forms"
        ));
        let alias_err = read("use a::b as c;").expect_err("alias rejects");
        assert!(matches!(
            alias_err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "use tree or alias forms"
        ));
    }

    #[test]
    fn e5_batch1_snake_skin_maps_at_the_token_face() {
        // Ruling E: the two kebab globals ride snake spellings; the
        // Stx layer sees the S-expr face names verbatim.
        assert_eq!(one("define(r, read_line());"), "(define r (read-line))");
        assert_eq!(
            one("define(r, write_line(x));"),
            "(define r (write-line x))"
        );
        // Module names are not the value namespace: `use read_line;`
        // keeps the raw segment text.
        assert_eq!(one("use read_line;"), "(require \"read_line\")");
    }

    #[test]
    fn generic_arguments_in_annotations_drop() {
        // Ruling C1 second half: adt_type generic arguments are part
        // of the annotation surface — `Foo<i64>` parses and drops.
        assert_eq!(
            one("fn f(x: Foo<i64>) -> Bar<Baz> { x }"),
            "(define (f x) x)"
        );
        // The fn-head parameter declaration `<T>` stays fail-closed
        // (the tick form has no lexical token — registered gap).
        let err = read("fn f<T>(x) { x }").expect_err("fn-head generics reject");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "generic parameters"
        ));
    }

    #[test]
    fn rejects_unclosed_brace() {
        let err = read("fn f() { 1").expect_err("unclosed brace rejects");
        assert!(matches!(
            err,
            ReadError::UnclosedTargetDelim { opening: "{", .. }
        ));
    }

    #[test]
    fn rejects_stray_close_brace() {
        let err = read("}").expect_err("stray brace rejects");
        assert!(matches!(
            err,
            ReadError::StrayTargetDelim { closing: '}', .. }
        ));
    }

    #[test]
    fn rejects_stray_close_paren_in_args() {
        let err = read("define(r, f(1, ));").expect_err("stray paren rejects");
        assert!(matches!(
            err,
            ReadError::StrayTargetDelim { closing: ')', .. }
        ));
    }

    #[test]
    fn rejects_unexpected_token() {
        let err = read("fn 1() { 1 }").expect_err("bad fn name rejects");
        assert!(matches!(err, ReadError::UnexpectedTargetToken { .. }));
    }

    #[test]
    fn rejects_comparison_chain() {
        let err = read("define(r, 1 < 2 < 3);").expect_err("chain rejects");
        assert!(matches!(err, ReadError::UnexpectedTargetToken { .. }));
    }

    #[test]
    fn rejects_int_overflow_fail_closed() {
        let err = read("define(r, 9223372036854775808);").expect_err("overflow rejects");
        assert!(matches!(err, ReadError::IntOutOfRange { .. }));
    }

    #[test]
    fn rejects_float_overflow_fail_closed() {
        let err = read("define(r, 1.8e308);").expect_err("float overflow rejects");
        assert!(matches!(err, ReadError::FloatOutOfRange { .. }));
    }

    #[test]
    fn rejects_nested_comment_left_open() {
        let err = read("/* outer /* inner */").expect_err("unclosed comment rejects");
        assert!(matches!(
            err,
            ReadError::UnclosedTargetDelim { opening: "/*", .. }
        ));
    }

    #[test]
    fn rejects_halt_and_pass_handler_bodies() {
        let err =
            read("define(r, handle perform E() { E => halt, });").expect_err("halt body rejects");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. } if form == "halt handler body"
        ));
    }

    #[test]
    fn nesting_cap_covers_target_delimiters() {
        let mut src = String::new();
        for _ in 0..(NESTING_LIMIT + 1) {
            src.push('(');
        }
        src.push('1');
        for _ in 0..(NESTING_LIMIT + 1) {
            src.push(')');
        }
        let err = read(&src).expect_err("deep nesting rejects");
        assert!(matches!(err, ReadError::NestingDepthExceeded { .. }));
    }

    #[test]
    fn sequential_datum_brackets_do_not_accumulate_depth() {
        // The step-4 regression (the wide-record-stream leak): the
        // datum parser's OpenParen success path once forgot to
        // release its depth guard, so every SEQUENTIAL bracket —
        // no nesting at all — leaked one level; a record stream
        // past the limit (the compiler twin's item prefix, 200+
        // records) tripped the cap on flat data. The fix releases
        // the guard on every path; this test pins the flat-stream
        // face with strictly more sequential brackets than the
        // limit allows as nested depth.
        let mut src = String::from("define(items, quote((");
        for i in 0..(NESTING_LIMIT + 40) {
            if i > 0 {
                src.push_str(", ");
            }
            src.push_str(&format!("(\"rec\", {i})"));
        }
        src.push_str(")));");
        let forms =
            read(&src).expect("a flat record stream reads (sequential brackets, no nesting)");
        assert_eq!(forms.len(), 1);
        // And real nesting still trips the cap — the guard stays a
        // guard (the sibling test above owns the deep face).
        let mut deep = String::from("define(items, quote(");
        for _ in 0..(NESTING_LIMIT + 1) {
            deep.push('(');
        }
        deep.push('1');
        for _ in 0..(NESTING_LIMIT + 1) {
            deep.push(')');
        }
        deep.push_str("));");
        let err = read(&deep).expect_err("genuinely deep data still rejects");
        assert!(matches!(err, ReadError::NestingDepthExceeded { .. }));
    }

    // ---------- E5 batch 2: the Lisp-name retirement (ruling E2) ----------

    #[test]
    fn e5_batch2_builtin_table_retires_the_pair_names() {
        // The four table entries: first/rest/pair/eq spell the
        // historical car/cdr/cons/eq? on the target face.
        assert_eq!(
            one("define(r, first(pair(1, 2)));"),
            "(define r (car (cons 1 2)))"
        );
        assert_eq!(
            one("define(r, rest(first(pair(1, 2))));"),
            "(define r (cdr (car (cons 1 2))))"
        );
        assert_eq!(one("define(r, eq(1, 1));"), "(define r (eq? 1 1))");
        // Ruling G: `set` is the assign form's call carrier — the
        // expression-position twin of the `x = e;` statement sugar.
        assert_eq!(
            one("fn f(x) { if x > 0 { set(r, x) } else { nil } }"),
            "(define (f x) (if (> x 0) (set! r x) nil))"
        );
    }

    #[test]
    fn e5_batch2_predicate_rule_spells_the_question_suffix() {
        // Rule P at both positions: the leading `is_` (the builtins)
        // and the `_is_` infix (the corpus predicates).
        assert_eq!(one("define(r, is_nil(nil));"), "(define r (nil? nil))");
        assert_eq!(
            one("define(r, is_pair(first(p)));"),
            "(define r (pair? (car p)))"
        );
        assert_eq!(
            one("define(r, lx_is_digit(57));"),
            "(define r (lx-digit? 57))"
        );
        assert_eq!(
            one("fn f(x) { lx_is_all_digits(x) }"),
            "(define (f x) (lx-all-digits? x))"
        );
        assert_eq!(
            one("fn f(x) { ex_is_name_eq(x) }"),
            "(define (f x) (ex-name-eq? x))"
        );
    }

    #[test]
    fn e5_batch2_separator_rule_spells_kebab() {
        // Rule K: every remaining `_` is the `-` of the S-expr face
        // (definition sites map together with reference sites).
        assert_eq!(
            one("fn rd_loop(t, s, f) { rd_loop(t, s, f) }"),
            "(define (rd-loop t s f) (rd-loop t s f))"
        );
        assert_eq!(one("define(lx_max_pos, 57);"), "(define lx-max-pos 57)");
        // Multi-segment names join through.
        assert_eq!(
            one("define(r, cp_emit_ewalk());"),
            "(define r (cp-emit-ewalk))"
        );
    }

    #[test]
    fn e5_batch2_names_shadow_consistently_through_the_skin() {
        // A user function spelled `first` and the builtin `car` are
        // one name after the skin map (the table entry) — definition
        // and reference sites map together, so the shadowing
        // behavior of the S-expr original is preserved (the identity
        // principle).
        let forms = read("fn first(x) { x }\nfn g() { first(1) }\nfn h(p) { first(p) }")
            .expect("skin names parse");
        let text: Vec<String> = forms.iter().map(|f| f.datum.to_string()).collect();
        assert_eq!(
            text,
            vec![
                "(define (car x) x)".to_string(),
                "(define (g) (car 1))".to_string(),
                "(define (h p) (car p))".to_string(),
            ]
        );
    }

    #[test]
    fn e5_batch2_blank_markers_are_not_separators() {
        // The blank marker family passes through verbatim: the lone
        // `_` (the pattern wildcard) above all — rule K maps only
        // interior separators.
        assert_eq!(
            one("define(r, match x { 1 => { 10 }, _ => { 20 }, });"),
            "(define r (match x (1 10) (_ 20)))"
        );
        assert_eq!(one("define(_unused, 1);"), "(define _unused 1)");
        assert_eq!(one("define(tail_, 2);"), "(define tail_ 2)");
    }

    // ---------- ruling F: the quote datum carrier ----------

    #[test]
    fn quote_tuple_carries_a_list_datum() {
        // The step-3 anchor: `(quote (57 50 ...))` rides the tuple
        // skin — the record-table shape of the corpus lexicon.
        assert_eq!(
            one("define(lx_max_pos, quote((57, 50, 51)));"),
            "(define lx-max-pos (quote (57 50 51)))"
        );
        assert_eq!(
            one("define(ops, quote((\"+\", \"-\", \"*\")));"),
            "(define ops (quote (\"+\" \"-\" \"*\")))"
        );
    }

    #[test]
    fn quote_carrier_nests_and_groups() {
        // Nested lists recurse; `(d)` groups (the tuple_pattern
        // passthrough); a bare datum quotes directly.
        assert_eq!(
            one("define(r, quote(((1, 2), 3)));"),
            "(define r (quote ((1 2) 3)))"
        );
        assert_eq!(one("define(r, quote((1)));"), "(define r (quote 1))");
        // The Rust tuple convention: a trailing comma marks the
        // list — `(d,)` is a ONE-element list, distinct from the
        // grouping `(d)`.
        assert_eq!(one("define(r, quote((7,)));"), "(define r (quote (7)))");
        assert_eq!(one("define(r, quote(((7,))));"), "(define r (quote (7)))");
        assert_eq!(
            one("define(r, quote((1, 2,)));"),
            "(define r (quote (1 2)))"
        );
        assert_eq!(one("define(r, quote(x));"), "(define r (quote x))");
        // `nil` is the datum face of the empty list (the record
        // encoders' convention).
        assert_eq!(one("define(r, quote(nil));"), "(define r (quote nil))");
    }

    #[test]
    fn quote_carrier_takes_word_faces_and_negative_numbers() {
        assert_eq!(
            one("define(r, quote((if, else, resume)));"),
            "(define r (quote (if else resume)))"
        );
        assert_eq!(
            one("define(r, quote((-1, 2)));"),
            "(define r (quote (-1 2)))"
        );
        assert_eq!(one("define(r, quote((-2.5)));"), "(define r (quote -2.5))");
        // Paths ride the C-C1 separator mapping.
        assert_eq!(
            one("define(r, quote((a::b, c)));"),
            "(define r (quote (a/b c)))"
        );
    }

    #[test]
    fn quote_carrier_rejects_expressions_and_the_empty_list() {
        // Expressions are not data — fail-closed, never silently
        // accepted.
        let err = read("define(r, quote((1 + 2)));").expect_err("expressions reject");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. }
                if form == "quote carries data, not expressions"
        ));
        // The empty list datum is `nil` — `()` is the subset-spec
        // §2.5 rejection the S-expr face shares.
        let err = read("define(r, quote(()));").expect_err("the empty datum rejects");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. }
                if form.contains("the empty quoted list")
        ));
        // Quote takes exactly one datum (a second datum or a
        // trailing expression is the same data-only rejection).
        let err = read("define(r, quote(1, 2));").expect_err("two datums reject");
        assert!(matches!(
            err,
            ReadError::UnsupportedTargetForm { form, .. }
                if form == "quote carries data, not expressions"
        ));
        // The empty argument list is not a datum either.
        let err = read("define(r, quote());").expect_err("the empty call rejects");
        assert!(matches!(err, ReadError::UnexpectedTargetToken { .. }));
    }
}

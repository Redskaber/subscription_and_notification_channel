//! Lexer: source text → typed token stream (docs/stage0.md §8.1).
//!
//! Interface contract (§8.1 `tokenize` guarantees, all honored):
//! the emitted tokens losslessly cover the input (the gaps between
//! consecutive token spans are exactly the skipped whitespace and
//! `;` comments), every token carries a precise byte span, and lexical
//! failures return the structured [`ReadError`] with a byte-precise
//! location — never a panic, never a silent fallback.
//!
//! Atom terminators follow the standard Lisp reader: whitespace, `(`,
//! `)`, `"` and `;`. Whitespace is Unicode-aware plus the BOM
//! `\u{feff}` (invisible format character — skipped like whitespace
//! rather than glued into identifiers). Numbers follow Rust `i64` /
//! `f64` parse semantics; number-shaped atoms that parse as neither
//! are rejected (no Racket-style symbol fallback — SOP §2.3-4), and
//! both overflow faces fail closed: an integer-shaped atom that
//! overflows `i64` is not silently demoted to a float, and a
//! float-shaped atom that overflows `f64` is not silently read as
//! ±inf (stage0.md §9.71; underflow rounds to the nearest
//! representable value and stays legal).
//!
//! Scan discipline (stage0.md §9.71): the loops dispatch on bytes —
//! the ASCII fast path moves by single bytes and never decodes, and
//! only non-ASCII bytes fall through to a char decode (K137/K142).
//! Atoms are classified from a zero-copy slice of the source (the
//! run is contiguous and both ends are char boundaries by
//! construction) — no per-atom intermediate `String`, exactly one
//! pool insertion per identifier (K137: rustc tokens are lengths;
//! the consumer slices the source once).

use crate::error::ReadError;
use crate::token::{Delimiter, StxToken, StxTokenKind};
use kerf_span::Symbol;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};

/// Lex `source` into a typed token stream ending with one `Eof` token.
///
/// The `file_id` stamps every span (docs/stage0.md §12.1 — byte
/// offsets; the session/file interner lands with the 0.8 driver).
pub fn lex(file_id: FileId, source: &str) -> Result<Vec<StxToken>, ReadError> {
    let mut lexer = Lexer {
        file_id,
        source,
        pos: 0,
    };
    let mut tokens = Vec::new();
    loop {
        lexer.skip_trivia()?;
        if lexer.pos >= lexer.source.len() {
            let end = lexer.pos;
            tokens.push(StxToken {
                kind: StxTokenKind::Eof,
                span: lexer.span(end, end),
            });
            return Ok(tokens);
        }
        tokens.push(lexer.next_token()?);
    }
}

struct Lexer<'a> {
    file_id: FileId,
    source: &'a str,
    /// Current byte position (always on a char boundary when the
    /// scan loops peek — comment scans may pass over continuation
    /// bytes but only ever stop on boundaries).
    pos: usize,
}

/// The ASCII atom terminators: the byte set that ends an atom run.
/// This spells the ASCII subset of `char::is_whitespace` explicitly —
/// including the vertical tab `\x0b`, which `u8::is_ascii_whitespace`
/// misses but `char::is_whitespace` counts (the drift trap this table
/// exists to avoid) — plus the standard Lisp delimiters `(`, `)`, `"`
/// and `;`.
#[inline]
fn is_ascii_terminator(b: u8) -> bool {
    matches!(
        b,
        b' ' | b'\t' | b'\n' | 0x0b | 0x0c | b'\r' | b'(' | b')' | b'"' | b';'
    )
}

impl<'a> Lexer<'a> {
    /// The next byte without consuming it — the dispatch of every
    /// scan loop (ASCII fast path; non-ASCII falls to the decode
    /// arms). Returns `None` at end of input.
    #[inline]
    fn peek_byte(&self) -> Option<u8> {
        self.source.as_bytes().get(self.pos).copied()
    }

    /// The next char without consuming it. ASCII bytes map directly
    /// (`b as char`); only non-ASCII pays a UTF-8 decode.
    #[inline]
    fn peek_char(&self) -> Option<char> {
        let b = self.source.as_bytes().get(self.pos)?;
        if b.is_ascii() {
            Some(*b as char)
        } else {
            self.source[self.pos..].chars().next()
        }
    }

    /// Whitespace (Unicode-aware, plus BOM) and `;` line comments.
    /// Byte-dispatched: ASCII whitespace advances by one byte, the
    /// comment scan runs bytes to the newline, and only non-ASCII
    /// bytes decode a char (pos is always on a boundary here).
    fn skip_trivia(&mut self) -> Result<(), ReadError> {
        loop {
            match self.peek_byte() {
                Some(b' ' | b'\t' | b'\n' | 0x0b | 0x0c | b'\r') => self.pos += 1,
                Some(b';') => {
                    self.pos += 1;
                    while let Some(b) = self.peek_byte() {
                        if b == b'\n' {
                            break;
                        }
                        // Any byte ≠ `\n` — including UTF-8 continuation
                        // bytes — advances; the loop only ever stops on
                        // the ASCII newline or end of input, so `pos`
                        // stays boundary-aligned at every peek.
                        self.pos += 1;
                    }
                }
                Some(b) if !b.is_ascii() => {
                    // pos is on a char boundary here (every other arm
                    // preserves boundary alignment), so a non-ASCII
                    // byte is a char start: decode one char.
                    if let Some(ch) = self.source[self.pos..].chars().next() {
                        if ch.is_whitespace() || ch == '\u{feff}' {
                            self.advance(ch);
                            continue;
                        }
                    }
                    return Ok(());
                }
                _ => return Ok(()),
            }
        }
    }

    fn next_token(&mut self) -> Result<StxToken, ReadError> {
        let start = self.pos;
        let first = self.peek_byte().expect("caller checked non-end");
        match first {
            b'(' => {
                self.pos += 1;
                Ok(self.token(Delimiter::Open, start))
            }
            b')' => {
                self.pos += 1;
                Ok(self.token(Delimiter::Close, start))
            }
            b'"' => self.lex_string(start),
            b'[' | b']' | b'{' | b'}' | b'`' | b'\'' | b',' => {
                // No meaning in the Stage 0 skin: brackets are not
                // delimiters here and no reader macros exist —
                // fail-closed instead of silently lexing weird symbols.
                // (The reject set is all ASCII, so `as char` is exact.)
                Err(ReadError::UnexpectedCharacter {
                    character: first as char,
                    at: ByteOffset(start as u32),
                })
            }
            _ => self.lex_atom(start),
        }
    }

    /// String literal: `"..."` with escapes `\"` `\\` `\n` `\t` `\r`;
    /// raw newlines are legal (Scheme tradition); unterminated input
    /// fails with the start offset.
    ///
    /// Plain ASCII bytes between the specials are bulk-copied as one
    /// contiguous run (K142: the range copy keeps the common
    /// all-ASCII scan fast); non-ASCII chars and escapes take the
    /// per-char slow path.
    fn lex_string(&mut self, start: usize) -> Result<StxToken, ReadError> {
        self.pos += 1; // the opening quote (ASCII)
        let mut value = String::new();
        loop {
            // Bulk run: consecutive plain ASCII bytes (not `"`, not
            // `\`). Non-ASCII terminates the run and is handled by
            // the per-char arms below.
            let run_start = self.pos;
            while let Some(b) = self.peek_byte() {
                if b == b'"' || b == b'\\' || !b.is_ascii() {
                    break;
                }
                self.pos += 1;
            }
            if self.pos > run_start {
                value.push_str(&self.source[run_start..self.pos]);
            }
            match self.peek_char() {
                None => {
                    return Err(ReadError::UnterminatedString {
                        started_at: ByteOffset(start as u32),
                    });
                }
                Some('"') => {
                    self.pos += 1;
                    return Ok(StxToken {
                        kind: StxTokenKind::StringLiteral(value),
                        span: self.span(start, self.pos),
                    });
                }
                Some('\\') => {
                    self.pos += 1; // the backslash (ASCII)
                    let escape_at = self.pos;
                    let Some(escaped) = self.peek_char() else {
                        return Err(ReadError::UnterminatedString {
                            started_at: ByteOffset(start as u32),
                        });
                    };
                    let decoded = match escaped {
                        '"' => '"',
                        '\\' => '\\',
                        'n' => '\n',
                        't' => '\t',
                        'r' => '\r',
                        other => {
                            return Err(ReadError::InvalidEscape {
                                escape: other,
                                at: ByteOffset(escape_at as u32),
                            });
                        }
                    };
                    value.push(decoded);
                    self.advance(escaped);
                }
                Some(ch) => {
                    value.push(ch);
                    self.advance(ch);
                }
            }
        }
    }

    /// Atom: identifier, boolean, or number — the byte run up to the
    /// next terminator (whitespace, `(`, `)`, `"`, `;`) or end of
    /// input, classified from a zero-copy slice of the source.
    fn lex_atom(&mut self, start: usize) -> Result<StxToken, ReadError> {
        loop {
            match self.peek_byte() {
                Some(b) if b.is_ascii() => {
                    if is_ascii_terminator(b) {
                        break;
                    }
                    self.pos += 1;
                }
                Some(_) => {
                    // pos is on a char boundary: decode one char and
                    // apply the Unicode terminator set (whitespace,
                    // BOM).
                    let ch = self.source[self.pos..]
                        .chars()
                        .next()
                        .expect("pos on a char boundary");
                    if ch.is_whitespace() || ch == '\u{feff}' {
                        break;
                    }
                    self.advance(ch);
                }
                None => break,
            }
        }
        // Zero-copy: the atom's bytes are a contiguous slice of the
        // source; both ends are char boundaries (the loop only stops
        // at ASCII terminators or after a whole-char advance).
        let text = &self.source[start..self.pos];
        let span = self.span(start, self.pos);
        if text.is_empty() {
            // The dispatch guarantees a non-terminator first char, so
            // the run consumes at least one byte — unreachable by
            // construction.
            unreachable!("atom run always consumes at least one character");
        }
        Ok(StxToken {
            kind: classify_atom(text, span)?,
            span,
        })
    }

    fn advance(&mut self, ch: char) {
        self.pos += ch.len_utf8();
    }

    fn token(&self, delimiter: Delimiter, start: usize) -> StxToken {
        StxToken {
            kind: StxTokenKind::Delimiter(delimiter),
            span: self.span(start, self.pos),
        }
    }

    fn span(&self, start: usize, end: usize) -> Span {
        Span::new(
            self.file_id,
            ByteOffset(start as u32),
            ByteOffset(end as u32),
            ExpansionId::ROOT,
        )
        .expect("lexer spans are well-ordered by construction")
    }
}

/// Classify one atom's text (a zero-copy source slice): the token
/// kind, or a lexical error carrying the whole-token span.
fn classify_atom(text: &str, span: Span) -> Result<StxTokenKind, ReadError> {
    if text.starts_with('#') {
        return match text {
            "#t" => Ok(StxTokenKind::BoolLiteral(true)),
            "#f" => Ok(StxTokenKind::BoolLiteral(false)),
            _ => Err(ReadError::InvalidBool {
                text: text.to_owned(),
                span,
            }),
        };
    }
    if is_number_shaped(text) {
        if is_integer_shaped(text) {
            // Integer-shaped atoms never fall back to the float
            // parse: silently retyping an overflowing integer as a
            // float contradicts the strict Int/Float typing (K138:
            // rustc denies both overflow faces by default; K139: the
            // Go spec requires an error when an integer constant
            // cannot be represented precisely). A float is spelled
            // with a `.` or an exponent.
            return match text.parse::<i64>() {
                Ok(v) => Ok(StxTokenKind::IntLiteral(v)),
                Err(_) => Err(ReadError::IntOutOfRange {
                    text: text.to_owned(),
                    span,
                }),
            };
        }
        return match text.parse::<f64>() {
            Ok(v) if v.is_infinite() => Err(ReadError::FloatOutOfRange {
                text: text.to_owned(),
                span,
            }),
            Ok(v) => Ok(StxTokenKind::FloatLiteral(v)),
            // A float-shaped atom that does not parse at all stays a
            // malformed number (`1.2.3`, `1e`, `0x1F`) — the overflow
            // split never swallows the malformed family.
            Err(_) => Err(ReadError::MalformedNumber {
                text: text.to_owned(),
                span,
            }),
        };
    }
    match Symbol::new(text) {
        Ok(symbol) => Ok(StxTokenKind::Identifier(symbol)),
        Err(err) => Err(ReadError::InvalidSymbol(err)),
    }
}

/// Number-shaped: leading ASCII digit; or `+`/`-`/`.` immediately
/// followed by an ASCII digit (so `+`, `-`, `...`, `nil?` stay
/// identifiers while `-7`, `.5`, `+3` are numbers).
fn is_number_shaped(text: &str) -> bool {
    let bytes = text.as_bytes();
    let first = bytes[0];
    if first.is_ascii_digit() {
        return true;
    }
    if matches!(first, b'+' | b'-' | b'.') {
        return bytes.len() > 1 && bytes[1].is_ascii_digit();
    }
    false
}

/// Integer-shaped: an optional sign followed by ASCII digits only
/// (no `.`, `e`, `_` or letters — those take the float-shaped path).
/// Only an integer-shaped atom can parse as `i64`, so this predicate
/// is exactly the `i64`-parse candidacy test.
fn is_integer_shaped(text: &str) -> bool {
    let digits = text.strip_prefix(['+', '-']).unwrap_or(text);
    !digits.is_empty() && digits.bytes().all(|b| b.is_ascii_digit())
}

#[cfg(test)]
mod tests {
    //! Unit tests for the lexer feature point (sub-stage test doc FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (atom acceptance), which is the sanctioned fixture
    //! category.

    use super::*;
    use crate::token::StxTokenKind as K;

    fn file() -> FileId {
        FileId(0)
    }

    fn kinds(src: &str) -> Vec<StxTokenKind> {
        lex(file(), src)
            .expect("lexing must succeed")
            .into_iter()
            .map(|t| t.kind)
            .collect()
    }

    // ---------- positive ----------

    #[test]
    fn lexes_mixed_program_all_kinds() {
        let tokens = lex(file(), "(add 1 2.5 #t \"s\")").expect("mixed program lexes");
        let kinds: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(
            kinds,
            vec![
                "delimiter",
                "identifier",
                "int",
                "float",
                "bool",
                "string",
                "delimiter",
                "eof"
            ]
        );
        let spans: Vec<(u32, u32)> = tokens
            .iter()
            .map(|t| (t.span.start.0, t.span.end.0))
            .collect();
        assert_eq!(
            spans,
            vec![
                (0, 1),
                (1, 4),
                (5, 6),
                (7, 10),
                (11, 13),
                (14, 17),
                (17, 18),
                (18, 18)
            ]
        );
    }

    #[test]
    fn numbers_follow_rust_parse_semantics() {
        let kinds = kinds(".5 1. 1e5 +3 -7 42");
        assert_eq!(
            kinds,
            vec![
                K::FloatLiteral(0.5),
                K::FloatLiteral(1.0),
                K::FloatLiteral(100000.0),
                K::IntLiteral(3),
                K::IntLiteral(-7),
                K::IntLiteral(42),
                K::Eof
            ]
        );
    }

    #[test]
    fn symbols_accept_unicode_cjk_and_specials() {
        // Symbols that must NOT be number-shaped: `+`, `-`, `...`,
        // `nil?`, `set!`, CJK identifiers.
        let kinds = kinds("+ - ... nil? set! 计数器");
        let names: Vec<&str> = kinds
            .iter()
            .map(|k| match k {
                K::Identifier(s) => s.as_str(),
                K::Eof => "eof",
                _ => "other",
            })
            .collect();
        assert_eq!(
            names,
            vec!["+", "-", "...", "nil?", "set!", "计数器", "eof"]
        );
    }

    #[test]
    fn comments_and_whitespace_are_skipped_losslessly() {
        let src = "; header\n ( f ; inline\n 1 ) ; tail";
        let tokens = lex(file(), src).expect("commented source lexes");
        let names: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(
            names,
            vec!["delimiter", "identifier", "int", "delimiter", "eof"]
        );
        // Lossless coverage: the slice between consecutive token spans
        // is exactly the skipped trivia — whitespace runs and `;`
        // comments (possibly several, possibly trailing without a
        // newline).
        for pair in tokens.windows(2) {
            let gap = &src[bytes_of(src, pair[0].span.end.0)..bytes_of(src, pair[1].span.start.0)];
            let mut rest = gap;
            loop {
                let trimmed = rest.trim_start();
                if trimmed.is_empty() {
                    break;
                }
                assert!(
                    trimmed.starts_with(';'),
                    "gap must be whitespace or comment trivia, got {gap:?}"
                );
                let line_end = trimmed.find('\n').unwrap_or(trimmed.len());
                rest = &trimmed[line_end..];
            }
        }
    }

    /// Map a byte offset back to a `str` slice index for gap inspection
    /// (offsets in this fixture are ASCII-only, so index == offset).
    fn bytes_of(src: &str, offset: u32) -> usize {
        let idx = offset as usize;
        assert!(src.is_char_boundary(idx), "fixture is ASCII at {idx}");
        idx
    }

    #[test]
    fn string_escapes_decode() {
        // Source: "a\n\t\r\\\"b" written as a Rust escaped literal.
        let kinds = kinds("\"a\\n\\t\\r\\\\\\\"b\"");
        assert_eq!(
            kinds,
            vec![K::StringLiteral("a\n\t\r\\\"b".to_owned()), K::Eof]
        );
    }

    #[test]
    fn eof_token_is_empty_and_bom_is_skipped() {
        let tokens = lex(file(), "\u{feff}x\u{feff}").expect("BOM-only trivia lexes");
        // BOM + `x` + BOM: both BOMs skip, `x` is the only token.
        assert_eq!(tokens.len(), 2);
        assert_eq!(tokens[0].kind_name(), "identifier");
        assert_eq!((tokens[0].span.start.0, tokens[0].span.end.0), (3, 4));
        assert_eq!(tokens[1].kind, K::Eof);
        assert!(tokens[1].span.is_empty());
        // Empty source: just Eof.
        let empty = lex(file(), "").expect("empty source lexes");
        assert_eq!(empty.len(), 1);
        assert_eq!(empty[0].kind, K::Eof);
    }

    /// The byte-dispatch scan (v0.40.0, stage0.md §9.71) is
    /// behavior-identical to the char-based scan it replaced: the
    /// whole token stream — kinds and byte spans — is pinned on one
    /// fixture that exercises every mixed-width path at once (BOM,
    /// multi-byte CJK atoms, the vertical-tab separator that
    /// `u8::is_ascii_whitespace` would miss, non-ASCII inside a
    /// comment, escapes, adjacency, multi-line).
    #[test]
    fn byte_scan_token_stream_is_pinned_on_a_rich_fixture() {
        let src = "\u{feff}(f 计数器\u{0b}+ -3 .5 1e5 1e-999 \"a\\nb\" x;y\n(z \"s\"))";
        let tokens = lex(file(), src).expect("rich fixture lexes");
        let names: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(
            names,
            vec![
                "delimiter",  // (
                "identifier", // f
                "identifier", // the CJK atom (multi-byte)
                "identifier", // + (after the \x0b separator)
                "int",        // -3
                "float",      // .5
                "float",      // 1e5
                "float",      // 1e-999 (underflow → 0.0, legal)
                "string",     // "a\nb" (escape decode)
                "identifier", // x (before the comment)
                "delimiter",  // ( (after the commented line)
                "identifier", // z
                "string",     // "s"
                "delimiter",  // )
                "delimiter",  // )
                "eof",
            ]
        );
        let floats: Vec<f64> = tokens
            .iter()
            .filter_map(|t| match t.kind {
                K::FloatLiteral(v) => Some(v),
                _ => None,
            })
            .collect();
        assert_eq!(floats, vec![0.5, 100000.0, 0.0]);
        // Byte-span pin — BOM 3B, CJK 3B/char, \x0b 1B: the exact
        // arithmetic of the mixed-width scan.
        let spans: Vec<(u32, u32)> = tokens
            .iter()
            .map(|t| (t.span.start.0, t.span.end.0))
            .collect();
        assert_eq!(
            spans,
            vec![
                (3, 4),   // (
                (4, 5),   // f
                (6, 15),  // the CJK atom
                (16, 17), // +
                (18, 20), // -3
                (21, 23), // .5
                (24, 27), // 1e5
                (28, 34), // 1e-999
                (35, 41), // "a\nb"
                (42, 43), // x
                (46, 47), // (
                (47, 48), // z
                (49, 52), // "s"
                (52, 53), // )
                (53, 54), // )
                (54, 54), // eof
            ]
        );
        // The decoded escape round-trips.
        assert_eq!(tokens[8].kind, K::StringLiteral("a\nb".to_owned()));
    }

    /// Non-ASCII whitespace (U+3000 ideographic space) separates
    /// atoms and is skipped like any other trivia; non-ASCII bytes
    /// inside a comment run to the newline harmlessly.
    #[test]
    fn unicode_whitespace_separates_and_comments_swallow_non_ascii() {
        let kinds = kinds("a\u{3000}b; 注释到行尾\nc");
        let names: Vec<&str> = kinds
            .iter()
            .map(|k| match k {
                K::Identifier(s) => s.as_str(),
                K::Eof => "eof",
                _ => "other",
            })
            .collect();
        assert_eq!(names, vec!["a", "b", "c", "eof"]);
    }

    // ---------- negative ----------

    #[test]
    fn rejects_unterminated_string() {
        let err = lex(file(), "\"abc").expect_err("unterminated string must fail");
        assert_eq!(
            err,
            ReadError::UnterminatedString {
                started_at: ByteOffset(0)
            }
        );
    }

    #[test]
    fn rejects_invalid_escape() {
        let err = lex(file(), "\"a\\x\"").expect_err("unknown escape must fail");
        assert_eq!(
            err,
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(3)
            }
        );
    }

    #[test]
    fn rejects_unknown_hash_atom() {
        let err = lex(file(), "#q").expect_err("unknown hash atom must fail");
        assert_eq!(
            err,
            ReadError::InvalidBool {
                text: "#q".to_owned(),
                span: span(0, 2),
            }
        );
    }

    #[test]
    fn rejects_long_bool_spelling() {
        // The Stage 0 skin defines exactly `#t` / `#f` — `#true` is
        // fail-closed, not silently accepted.
        let err = lex(file(), "(#true)").expect_err("long bool spelling must fail");
        assert!(matches!(
            err,
            ReadError::InvalidBool { text, span } if text == "#true"
                && span.start.0 == 1 && span.end.0 == 6
        ));
    }

    #[test]
    fn rejects_multi_dot_number() {
        let err = lex(file(), "1.2.3").expect_err("multi-dot number must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned(),
                span: span(0, 5),
            }
        );
    }

    #[test]
    fn rejects_digit_prefixed_symbol() {
        let err = lex(file(), "12abc").expect_err("digit-prefixed symbol must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "12abc".to_owned(),
                span: span(0, 5),
            }
        );
    }

    #[test]
    fn rejects_hex_prefixed_number() {
        let err = lex(file(), "0x1F").expect_err("hex literal must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "0x1F".to_owned(),
                span: span(0, 4),
            }
        );
    }

    #[test]
    fn rejects_underscored_number() {
        let err = lex(file(), "1_000").expect_err("underscored number must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1_000".to_owned(),
                span: span(0, 5),
            }
        );
    }

    #[test]
    fn rejects_dangling_exponent() {
        let err = lex(file(), "1e").expect_err("dangling exponent must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1e".to_owned(),
                span: span(0, 2),
            }
        );
    }

    #[test]
    fn rejects_control_char_atom() {
        let err = lex(file(), "a\u{0}b").expect_err("control char atom must fail");
        assert_eq!(
            err,
            ReadError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned()
            })
        );
    }

    #[test]
    fn rejects_bracket_characters() {
        for src in ["[", "]", "{", "}"] {
            let ch = src.chars().next().expect("one char");
            let err = lex(file(), src).expect_err("brackets have no Stage 0 meaning");
            assert_eq!(
                err,
                ReadError::UnexpectedCharacter {
                    character: ch,
                    at: ByteOffset(0)
                }
            );
        }
    }

    #[test]
    fn rejects_reader_macro_characters() {
        for src in ["`", "'", ","] {
            let ch = src.chars().next().expect("one char");
            let err = lex(file(), src).expect_err("reader macros do not exist in Stage 0");
            assert_eq!(
                err,
                ReadError::UnexpectedCharacter {
                    character: ch,
                    at: ByteOffset(0)
                }
            );
        }
    }

    #[test]
    fn rejects_lone_hash_atom() {
        // `#` alone starts a hash atom but matches neither `#t` nor
        // `#f` — fail-closed, not a symbol.
        let err = lex(file(), "#").expect_err("lone hash must fail");
        assert_eq!(
            err,
            ReadError::InvalidBool {
                text: "#".to_owned(),
                span: span(0, 1),
            }
        );
    }

    #[test]
    fn rejects_escape_at_end_of_input() {
        // `"a\` — the escape backslash runs into end of input: the
        // string (already open) is unterminated.
        let err = lex(file(), "\"a\\").expect_err("escape at end of input must fail");
        assert_eq!(
            err,
            ReadError::UnterminatedString {
                started_at: ByteOffset(0)
            }
        );
    }

    #[test]
    fn atom_boundaries_are_lisp_terminators() {
        // `a"b"` = symbol `a` followed by string "b"; `x;y` = symbol `x`
        // then a comment — positive adjacency check that also pins the
        // terminator set used by the negative cases above.
        let kinds = kinds("a\"b\"");
        assert_eq!(
            kinds,
            vec![
                K::Identifier(Symbol::new("a").expect("valid symbol")),
                K::StringLiteral("b".to_owned()),
                K::Eof
            ]
        );
        let tokens = lex(file(), "x;y\nz").expect("comment-adjacent atoms lex");
        let names: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(names, vec!["identifier", "identifier", "eof"]);
    }

    // ---------- overflow faces (v0.40.0, stage0.md §9.71) ----------

    /// A well-ordered span helper for the payload assertions.
    fn span(start: u32, end: u32) -> Span {
        Span::new(
            file(),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test spans are well-ordered")
    }

    #[test]
    fn rejects_i64_overflow_integer_literal() {
        // i64::MAX + 1: integer-shaped, no float demotion (K138/K139).
        let err = lex(file(), "(+ 1 9223372036854775808)").expect_err("i64 overflow must fail");
        assert!(matches!(
            err,
            ReadError::IntOutOfRange { text, span } if text == "9223372036854775808"
                && span.start.0 == 5 && span.end.0 == 24
        ));
        // The negative face: i64::MIN - 1.
        let err = lex(file(), "-9223372036854775809").expect_err("negative i64 overflow");
        assert!(matches!(
            err,
            ReadError::IntOutOfRange { text, .. } if text == "-9223372036854775809"
        ));
    }

    #[test]
    fn rejects_f64_overflow_float_literal() {
        let err = lex(file(), "1e999").expect_err("f64 overflow must fail");
        assert_eq!(
            err,
            ReadError::FloatOutOfRange {
                text: "1e999".to_owned(),
                span: span(0, 5),
            }
        );
        // The negative face reads as -inf today — same rejection.
        let err = lex(file(), "-1e999").expect_err("negative f64 overflow");
        assert!(matches!(
            err,
            ReadError::FloatOutOfRange { text, .. } if text == "-1e999"
        ));
    }

    #[test]
    fn maximal_literals_parse_exactly() {
        // The inclusive boundaries: i64::MAX/MIN and f64::MAX stay
        // legal; only beyond-the-format values reject.
        let kinds = kinds("9223372036854775807 -9223372036854775808 1.7976931348623157e308");
        assert_eq!(
            kinds,
            vec![
                K::IntLiteral(i64::MAX),
                K::IntLiteral(i64::MIN),
                K::FloatLiteral(f64::MAX),
                K::Eof
            ]
        );
    }

    #[test]
    fn underflow_rounds_to_zero_and_stays_legal() {
        // Precision limits round to the nearest representable value
        // (K139): `1e-999` reads as 0.0 — legal, pinned.
        let kinds = kinds("1e-999 5e-324");
        assert_eq!(
            kinds,
            vec![
                K::FloatLiteral(0.0),
                K::FloatLiteral(f64::from_bits(1)), // the smallest subnormal
                K::Eof
            ]
        );
    }

    #[test]
    fn spelled_floats_above_i64_stay_floats() {
        // The escape for a big value is spelling it as a float —
        // `.` or an exponent makes it float-shaped, and any f64-range
        // magnitude is legal.
        let kinds = kinds("99999999999999999999.0 1e20");
        assert_eq!(
            kinds,
            vec![K::FloatLiteral(1e20), K::FloatLiteral(1e20), K::Eof]
        );
    }
}

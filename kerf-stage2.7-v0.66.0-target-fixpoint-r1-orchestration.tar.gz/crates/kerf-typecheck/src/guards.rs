//! Mirror-alignment guards for the two pre-collection walks (INF-9,
//! stage0.md §9.77).
//!
//! `check::collect_table` and `infer::collect_info` are deliberate
//! twins (§9.68 CHK-1/CHK-3): the checker table carries kind shapes,
//! the inference table carries literal values, and both walks must
//! agree on *names in walk order* and the *assigned set* — the
//! position-aware visibility and the assignment over-approximation
//! guard are only sound while the two walks stay aligned. These
//! guards pin that alignment mechanically (the TEST-2 table↔tree
//! parity methodology, applied to a twin-walk pair): any drift
//! between the walks fails here instead of surfacing as a
//! visibility or assignment semantic difference at a distance.
//!
//! Compiled for tests only (`#[cfg(test)]`, mounted in `lib.rs`) —
//! zero public-API footprint.

use std::collections::HashSet;

use kerf_core::{Binding, CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

use crate::check::collect_table;
use crate::infer::{DefineTable, collect_info};

const FILE: FileId = FileId(0);

fn sp(a: u32, b: u32) -> Span {
    Span::new(FILE, ByteOffset(a), ByteOffset(b), ExpansionId::ROOT).expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbols pass the floor")
}

fn var(name: &str) -> CoreExpr {
    CoreExpr::Var {
        span: sp(0, 1),
        name: sym(name),
    }
}

fn int(v: i64) -> CoreExpr {
    CoreExpr::Literal {
        span: sp(2, 3),
        value: LiteralValue::Int(v),
    }
}

/// Assert the two collections agree on names-in-order and the
/// assigned set (the INF-9 mirror contract).
fn assert_mirror(items: &[ModuleItem]) {
    let check_table = collect_table(items);
    let mut infer_table = DefineTable::default();
    collect_info(items, &mut infer_table);

    let check_names: Vec<&Symbol> = check_table.defines.iter().map(|(n, _)| n).collect();
    let infer_names: Vec<&Symbol> = infer_table.defines.iter().map(|(n, _)| n).collect();
    assert_eq!(
        check_names, infer_names,
        "mirror drift: define walk order diverged between check and infer"
    );

    let check_assigned: HashSet<&Symbol> = check_table.assigned.iter().collect();
    let infer_assigned: HashSet<&Symbol> = infer_table.assigned.iter().collect();
    assert_eq!(
        check_assigned, infer_assigned,
        "mirror drift: assigned set diverged between check and infer"
    );
}

/// Every define shape (Fn / each literal kind / Other), assigns in
/// every expression position (top-level value, under Fn, under If,
/// inside Let bindings and body, under Perform args, under Handle
/// body and handler clauses), plus nested modules and duplicate
/// names — the full representative surface of both walks.
fn representative_module() -> Vec<ModuleItem> {
    let assigned_everywhere = CoreExpr::Let {
        span: sp(0, 40),
        bindings: vec![
            Binding {
                span: sp(1, 10),
                name: sym("lx"),
                value: CoreExpr::Assign {
                    span: sp(2, 8),
                    name: sym("top-a"),
                    value: Box::new(int(1)),
                },
            },
            Binding {
                span: sp(11, 20),
                name: sym("lf"),
                value: CoreExpr::Fn {
                    span: sp(12, 18),
                    params: vec![sym("p")],
                    body: Box::new(CoreExpr::Assign {
                        span: sp(13, 17),
                        name: sym("fn-a"),
                        value: Box::new(var("p")),
                    }),
                },
            },
        ],
        body: Box::new(CoreExpr::Handle {
            span: sp(21, 39),
            body: Box::new(CoreExpr::If {
                span: sp(22, 30),
                cond: Box::new(CoreExpr::Assign {
                    span: sp(23, 26),
                    name: sym("cond-a"),
                    value: Box::new(CoreExpr::Literal {
                        span: sp(24, 25),
                        value: LiteralValue::Bool(true),
                    }),
                }),
                then_branch: Box::new(int(1)),
                else_branch: Box::new(int(2)),
            }),
            handlers: vec![HandlerClause {
                span: sp(31, 38),
                effect: sym("log"),
                handler: Box::new(CoreExpr::Assign {
                    span: sp(32, 37),
                    name: sym("handler-a"),
                    value: Box::new(CoreExpr::Apply {
                        span: sp(33, 36),
                        func: Box::new(var("lf")),
                        args: vec![CoreExpr::Perform {
                            span: sp(34, 35),
                            effect: sym("log"),
                            args: vec![CoreExpr::Assign {
                                span: sp(34, 35),
                                name: sym("arg-a"),
                                value: Box::new(int(3)),
                            }],
                        }],
                    }),
                }),
            }],
        }),
    };

    vec![
        ModuleItem::Require {
            span: sp(0, 2),
            module: sym("dep"),
        },
        ModuleItem::Define {
            span: sp(3, 6),
            name: sym("f"),
            value: CoreExpr::Fn {
                span: sp(4, 5),
                params: vec![sym("x")],
                body: Box::new(var("x")),
            },
        },
        ModuleItem::Define {
            span: sp(7, 9),
            name: sym("int-lit"),
            value: int(7),
        },
        ModuleItem::Define {
            span: sp(10, 12),
            name: sym("float-lit"),
            value: CoreExpr::Literal {
                span: sp(11, 11),
                value: LiteralValue::Float(1.5),
            },
        },
        ModuleItem::Define {
            span: sp(13, 15),
            name: sym("bool-lit"),
            value: CoreExpr::Literal {
                span: sp(14, 14),
                value: LiteralValue::Bool(false),
            },
        },
        ModuleItem::Define {
            span: sp(16, 18),
            name: sym("str-lit"),
            value: CoreExpr::Literal {
                span: sp(17, 17),
                value: LiteralValue::String("s".into()),
            },
        },
        ModuleItem::Define {
            span: sp(19, 21),
            name: sym("nil-lit"),
            value: CoreExpr::Literal {
                span: sp(20, 20),
                value: LiteralValue::Nil,
            },
        },
        ModuleItem::Define {
            span: sp(22, 26),
            name: sym("pair-lit"),
            value: CoreExpr::Literal {
                span: sp(23, 25),
                value: LiteralValue::Pair(
                    Box::new(LiteralValue::Int(1)),
                    Box::new(LiteralValue::Nil),
                ),
            },
        },
        ModuleItem::Define {
            span: sp(27, 31),
            name: sym("other-shape"),
            value: CoreExpr::Apply {
                span: sp(28, 30),
                func: Box::new(var("f")),
                args: vec![int(1)],
            },
        },
        ModuleItem::Define {
            span: sp(32, 80),
            name: sym("assigned-everywhere"),
            value: assigned_everywhere,
        },
        // A duplicate name: both walks must record it twice, in order.
        ModuleItem::Define {
            span: sp(81, 83),
            name: sym("f"),
            value: int(9),
        },
        ModuleItem::Module {
            span: sp(84, 90),
            name: sym("nested"),
            items: vec![
                ModuleItem::Define {
                    span: sp(85, 87),
                    name: sym("inner"),
                    value: CoreExpr::Assign {
                        span: sp(86, 86),
                        name: sym("nested-a"),
                        value: Box::new(int(4)),
                    },
                },
                ModuleItem::Module {
                    span: sp(88, 89),
                    name: sym("deeper"),
                    items: vec![ModuleItem::Define {
                        span: sp(88, 89),
                        name: sym("deepest"),
                        value: CoreExpr::Literal {
                            span: sp(88, 89),
                            value: LiteralValue::Nil,
                        },
                    }],
                },
            ],
        },
    ]
}

#[test]
fn mirror_tables_align_on_the_representative_module() {
    // The INF-9 guard: both collections see the same defines in the
    // same order and the same assigned set (every assign position:
    // top-level value, let binding, under Fn, if condition, perform
    // arg, handle handler — plus nested modules and duplicates).
    assert_mirror(&representative_module());
}

#[test]
fn mirror_tables_align_on_the_empty_module() {
    assert_mirror(&[]);
}

#[test]
fn mirror_tables_align_on_syntax_items_without_expressions() {
    // Require and DefineSyntax carry no expression payload — both
    // walks must skip them identically (zero code faces).
    let items = vec![
        ModuleItem::Require {
            span: sp(0, 2),
            module: sym("a"),
        },
        ModuleItem::Require {
            span: sp(3, 5),
            module: sym("b"),
        },
    ];
    assert_mirror(&items);
}

#[test]
fn mirror_assigned_sets_are_nonempty_on_the_fixture() {
    // Detection-power arm (the TEST-3b shape): the fixture really
    // exercises the assigned-set walk — a guard that passes because
    // the fixture collects nothing would pin nothing. Every position
    // the walks know must appear in both tables.
    let items = representative_module();
    let check_table = collect_table(&items);
    let mut infer_table = DefineTable::default();
    collect_info(&items, &mut infer_table);

    for expected in ["top-a", "fn-a", "cond-a", "handler-a", "arg-a", "nested-a"] {
        let name = sym(expected);
        assert!(
            check_table.assigned.contains(&name),
            "fixture must exercise the assigned walk: {expected} missing (check)"
        );
        assert!(
            infer_table.assigned.contains(&name),
            "fixture must exercise the assigned walk: {expected} missing (infer)"
        );
    }
}

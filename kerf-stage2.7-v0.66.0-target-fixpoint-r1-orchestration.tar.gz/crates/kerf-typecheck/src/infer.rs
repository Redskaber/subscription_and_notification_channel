//! The Hindley-Milner inference engine — Stage 1.3 base
//! (stage0.md §9.44.4; stage-1-plan §2 row 1.3).
//!
//! # Shape (per the §9.44.4 design record)
//!
//! * **Iterative Algorithm W** over an explicit task stack (the A6
//!   lineage, stage0.md §9.30 REC-A: zero deep Rust recursion —
//!   bootstrap-friendly for the later `.krf` rewrite on the
//!   flat-stack VM). Tree walk, unification, occurs check, deep
//!   resolve and the final annotation pass are all loop-based.
//! * **Union-find style metavariables** with an **undo log**. The
//!   undo log exists for *soundness*, not precision: bindings made
//!   while inferring an `if` branch must not leak past the branch —
//!   a dynamically-typed language allows the other branch to run,
//!   so a leaked binding could poison later code into a false
//!   positive (`E0009`). Since INF-1 (§9.77) the undo log also
//!   carries the transactional contract of `unify` itself: a failed
//!   unification restores the entry state, so partial worklist
//!   bindings can never leak regardless of caller. `Handle` needs
//!   no isolation: handler *values* and the body all evaluate
//!   unconditionally at setup (compile.rs order), and `Fn` bodies
//!   are the parametric contract itself.
//! * **Cross-define pre-binding (letrec through variables)**: every
//!   unassigned `Fn`-literal define gets a metavariable up front;
//!   references through it unify — mutual recursion types the way
//!   ML letrec does. Position-aware visibility mirrors the checker
//!   exactly: top-level immediates see defines-so-far only, `Fn`
//!   bodies see everything (call time is post-load).
//! * **Conservative discipline (definite-error-only)**: `Dyn` is the
//!   one-way unknown top — the join of dynamically-legal branches
//!   and every unresolved flow. It absorbs everything and never
//!   constrains, so a legal program never gets a diagnostic. The
//!   numeric builtins are typed **ad hoc** at application sites
//!   (no type classes — the 18 builtins are a closed set); `if`
//!   conditions unify with `bool` (evaluation-order sound: the
//!   condition evaluates before anything it binds); `if` branches
//!   are joined, never unified with each other.
//! * **Assigned names never generalize** (value-restriction
//!   analog): a rebinding can change the shape, so references type
//!   as `Dyn`. Only syntactic `Fn`-literal values generalize —
//!   binding-time zero side effects, zero escape.
//! * **Effect rows are a collection face**: `Perform` appends,
//!   `Handle` subtracts what its clauses intercept (definite — the
//!   clauses install before the body) and merges each handler
//!   body's row (over-approximate). Calls do **not** absorb callee
//!   rows — that is row polymorphism, the Stage 2+ TY-C window.
//!
//! # Budget (A6 semantics)
//!
//! `INFERENCE_DEPTH_LIMIT = 512` counts expression-tree depth per
//! define. A subtree past the limit emits one `E0011` *warning* and
//! the whole define is excluded from the typed program (no partial
//! annotations) — deep-but-legal programs must keep running, so the
//! budget can never be an `Error`.

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::Span;
use kerf_span::Symbol;

use crate::code::{Severity, TypeCode, TypeDiagnostic};
use crate::env::Externals;
use crate::types::{EffectRow, Type, TypeSchema, substitute};

/// The per-define expression-depth budget (A6 — stage0.md §9.30).
pub const INFERENCE_DEPTH_LIMIT: u32 = 512;

/// Quote-literal pair chains deeper than this collapse their tail
/// to `Dyn` (sound: unknown; keeps annotation depth bounded even
/// for long quoted lists, which the reader's *nesting* cap does not
/// bound — a flat list is one nesting level).
const LITERAL_TYPE_DEPTH: u32 = 64;

// ---------- the typed annotation IR (Layer 2 — stage0.md §6.13) ----------

/// One annotated binding (`let` arm).
#[derive(Debug, Clone, PartialEq)]
pub struct TypedBinding {
    pub span: Span,
    pub name: Symbol,
    /// The binding's own type (the value's type at bind time).
    pub ty: Type,
    pub value: TypedExpr,
}

/// One annotated handler clause.
#[derive(Debug, Clone, PartialEq)]
pub struct TypedHandler {
    pub span: Span,
    pub effect: Symbol,
    pub ty: Type,
    pub handler: TypedExpr,
}

/// The Layer 2 annotation tree — a full mirror of `CoreExpr` where
/// every node carries its inferred type and effect row. Types are
/// stored fully resolved (the final pass resolves after all late
/// bindings — call sites binding param vars — have landed).
#[derive(Debug, Clone, PartialEq)]
pub enum TypedExpr {
    Fn {
        span: Span,
        params: Vec<Symbol>,
        body: Box<TypedExpr>,
        ty: Type,
    },
    Apply {
        span: Span,
        func: Box<TypedExpr>,
        args: Vec<TypedExpr>,
        ty: Type,
        effects: EffectRow,
    },
    If {
        span: Span,
        cond: Box<TypedExpr>,
        then_branch: Box<TypedExpr>,
        else_branch: Box<TypedExpr>,
        ty: Type,
        effects: EffectRow,
    },
    Var {
        span: Span,
        name: Symbol,
        ty: Type,
    },
    Literal {
        span: Span,
        value: LiteralValue,
        ty: Type,
    },
    Assign {
        span: Span,
        name: Symbol,
        value: Box<TypedExpr>,
        ty: Type,
        effects: EffectRow,
    },
    Let {
        span: Span,
        bindings: Vec<TypedBinding>,
        body: Box<TypedExpr>,
        ty: Type,
        effects: EffectRow,
    },
    Perform {
        span: Span,
        effect: Symbol,
        args: Vec<TypedExpr>,
        ty: Type,
        effects: EffectRow,
    },
    Handle {
        span: Span,
        body: Box<TypedExpr>,
        handlers: Vec<TypedHandler>,
        ty: Type,
        effects: EffectRow,
    },
}

/// One annotated top-level define.
#[derive(Debug, Clone, PartialEq)]
pub struct TypedDefine {
    pub span: Span,
    pub name: Symbol,
    /// The define's type: a generalized schema for unassigned
    /// `Fn`-literal values, otherwise the sealed monomorphic type
    /// (or `Dyn` when unknown/reassigned).
    pub schema: TypeSchema,
    pub body: TypedExpr,
    pub effects: EffectRow,
}

/// The annotation artifact of one `infer_module` run.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct TypedProgram {
    pub defines: Vec<TypedDefine>,
}

/// The `infer_module` result: typed program + every diagnostic found
/// (multi-error collection — the same architectural property as
/// `check_module`, ruling 21).
#[derive(Debug, Clone, Default)]
pub struct InferOutcome {
    pub typed: TypedProgram,
    pub diagnostics: Vec<TypeDiagnostic>,
}

// ---------- the module table (mirrors check.rs collect_table) ----------

/// What the inference table knows about one define. This is a
/// separate walk from `check.rs` (that table keeps only the kind
/// name for literals; inference needs the value for pair types) —
/// the walk order and assigned-set semantics mirror it exactly.
#[derive(Debug, Clone)]
pub(crate) enum DefineInfo {
    /// Bound to an `Fn` literal (pre-bound with a metavariable).
    FnLiteral,
    /// Bound to a literal value (sealed type available up front).
    Literal(LiteralValue),
    /// Anything else.
    Other,
}

#[derive(Debug, Clone, Default)]
pub(crate) struct DefineTable {
    pub(crate) defines: Vec<(Symbol, DefineInfo)>,
    pub(crate) assigned: std::collections::HashSet<Symbol>,
}

impl DefineTable {
    fn is_assigned(&self, name: &Symbol) -> bool {
        self.assigned.contains(name)
    }
}

pub(crate) fn collect_info(items: &[ModuleItem], table: &mut DefineTable) {
    // Same order as check.rs `collect_items` — the mirror discipline.
    for item in items {
        match item {
            ModuleItem::Define { name, value, .. } => {
                let info = match value {
                    CoreExpr::Fn { .. } => DefineInfo::FnLiteral,
                    CoreExpr::Literal { value, .. } => DefineInfo::Literal(value.clone()),
                    _ => DefineInfo::Other,
                };
                table.defines.push((name.clone(), info));
                collect_assigns(value, table);
            }
            ModuleItem::Module { items, .. } => collect_info(items, table),
            ModuleItem::Require { .. } | ModuleItem::DefineSyntax { .. } => {}
        }
    }
}

fn collect_assigns(expr: &CoreExpr, table: &mut DefineTable) {
    // Mirrors check.rs `collect_expr` (the assignment
    // over-approximation guard: any assign anywhere poisons the
    // name's static shape).
    match expr {
        CoreExpr::Assign { name, value, .. } => {
            // HashSet insert is idempotent — the manual scan-then-push
            // dedup of the pre-§9.68 form is gone (CHK-3).
            table.assigned.insert(name.clone());
            collect_assigns(value, table);
        }
        CoreExpr::Fn { body, .. } => collect_assigns(body, table),
        CoreExpr::Apply { func, args, .. } => {
            collect_assigns(func, table);
            for a in args {
                collect_assigns(a, table);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            collect_assigns(cond, table);
            collect_assigns(then_branch, table);
            collect_assigns(else_branch, table);
        }
        CoreExpr::Let { bindings, body, .. } => {
            for b in bindings {
                collect_assigns(&b.value, table);
            }
            collect_assigns(body, table);
        }
        CoreExpr::Perform { args, .. } => {
            for a in args {
                collect_assigns(a, table);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            collect_assigns(body, table);
            for h in handlers {
                collect_assigns(&h.handler, table);
            }
        }
        CoreExpr::Var { .. } | CoreExpr::Literal { .. } => {}
    }
}

// ---------- metavariable links with an undo log ----------

/// The union-find link table. `slots[i]` holds var `i`'s binding;
/// every `bind` pushes the previous value onto `undo` so branch
/// inference can be rolled back (soundness — see the module docs).
#[derive(Debug, Default)]
struct Links {
    slots: Vec<Option<Type>>,
    undo: Vec<(u32, Option<Type>)>,
}

impl Links {
    fn fresh(&mut self) -> Type {
        let idx = self.slots.len() as u32;
        self.slots.push(None);
        Type::Var(idx)
    }

    fn bind(&mut self, i: u32, t: Type) {
        let slot = &mut self.slots[i as usize];
        self.undo.push((i, slot.take()));
        *slot = Some(t);
    }

    fn link_of(&self, i: u32) -> Option<&Type> {
        self.slots.get(i as usize).and_then(|s| s.as_ref())
    }

    fn mark(&self) -> usize {
        self.undo.len()
    }

    fn rollback(&mut self, to: usize) {
        while self.undo.len() > to {
            let (i, old) = self.undo.pop().expect("mark <= undo len");
            self.slots[i as usize] = old;
        }
    }
}

/// A unification failure.
#[derive(Debug, Clone, PartialEq)]
enum UnifyErr {
    /// Two concrete types that cannot match.
    Mismatch { expected: Type, found: Type },
    /// The occurs check found a cycle.
    Recursive { var: u32, in_type: Type },
}

// ---------- the inference context ----------

struct Ctx<'a> {
    links: Links,
    externals: &'a Externals,
    diagnostics: Vec<TypeDiagnostic>,
    /// Parameter positions per define whose metavariable was
    /// directly forced to `bool` by an if-condition demand inside
    /// the define's own value (the single body-sensitive binding
    /// source — every other builtin domain check releases
    /// unresolved vars instead of binding them). A concrete
    /// non-bool argument at one of these positions is a definite
    /// error (the VM's bool-strict `jump-if-false` rejects it);
    /// shape mismatches at any other parameter position are
    /// call-site over-approximation (heterogeneous tag dispatch is
    /// legal dynamic code) and must be released, never reported
    /// (stage0.md §9.49, GATE-2 hardening).
    bool_demanded: Vec<std::collections::HashSet<usize>>,
}

impl<'a> Ctx<'a> {
    fn report(&mut self, code: TypeCode, severity: Severity, span: Span, message: String) {
        self.diagnostics
            .push(TypeDiagnostic::new(code, severity, span, message));
    }

    /// Resolve one var's chain to its endpoint (an unbound var or a
    /// non-var type). Iterative; hop-capped defensively.
    ///
    /// Acyclicity is a structural invariant, not an assumption:
    /// `bind` runs only after `occurs` rejects i-in-t, so no chain
    /// can loop, and any acyclic chain over `slots.len()` slots has
    /// at most `slots.len()` hops — the cap equals that bound.
    /// Hitting the cap would mean a logic bug elsewhere (a cycle
    /// created outside `unify`); the break then returns a mid-chain
    /// var, which is safe-but-wrong rather than a hang (the fixpoint
    /// guard test pins the invariant — INF-2, §9.77). Frontier
    /// note: ena (rustc) and OCaml `btype` walkers assume acyclicity
    /// with no cap at all; the defensive cap stays as belt-and-
    /// suspenders (stage0.md §9.77 K177).
    fn resolve_shallow(&self, t: Type) -> Type {
        let mut cur = t;
        let mut hops = 0usize;
        while let Type::Var(i) = cur {
            match self.links.link_of(i) {
                Some(next) => {
                    cur = next.clone();
                    hops += 1;
                    if hops > self.links.slots.len() {
                        break;
                    }
                }
                None => break,
            }
        }
        cur
    }

    /// Deep-resolve a type: every bound var is replaced by its
    /// (deeply resolved) binding. Iterative post-order rebuild.
    fn resolve(&self, t: &Type) -> Type {
        enum Item {
            Visit(Type),
            Pair,
            Arrow(usize),
        }
        let mut stack = vec![Item::Visit(t.clone())];
        let mut done: Vec<Type> = Vec::new();
        while let Some(item) = stack.pop() {
            match item {
                Item::Visit(ty) => match ty {
                    Type::Var(_) => {
                        // Chain endpoint: an unbound var (leaf) or a
                        // composite reached through links — keep
                        // visiting its structure.
                        let end = self.resolve_shallow(ty);
                        match end {
                            Type::Var(_) => done.push(end),
                            Type::Pair(a, b) => {
                                stack.push(Item::Pair);
                                stack.push(Item::Visit(*b));
                                stack.push(Item::Visit(*a));
                            }
                            Type::Arrow { params, ret } => {
                                stack.push(Item::Arrow(params.len()));
                                stack.push(Item::Visit(*ret));
                                for p in params {
                                    stack.push(Item::Visit(p));
                                }
                            }
                            leaf => done.push(leaf),
                        }
                    }
                    Type::Pair(a, b) => {
                        stack.push(Item::Pair);
                        stack.push(Item::Visit(*b));
                        stack.push(Item::Visit(*a));
                    }
                    Type::Arrow { params, ret } => {
                        stack.push(Item::Arrow(params.len()));
                        stack.push(Item::Visit(*ret));
                        for p in params {
                            stack.push(Item::Visit(p));
                        }
                    }
                    leaf => done.push(leaf),
                },
                Item::Pair => {
                    let b = done.pop().expect("pair cdr");
                    let a = done.pop().expect("pair car");
                    done.push(Type::Pair(Box::new(a), Box::new(b)));
                }
                Item::Arrow(n) => {
                    let ret = done.pop().expect("arrow ret");
                    let mut params = Vec::with_capacity(n);
                    for _ in 0..n {
                        params.push(done.pop().expect("arrow param"));
                    }
                    params.reverse();
                    done.push(Type::Arrow {
                        params,
                        ret: Box::new(ret),
                    });
                }
            }
        }
        done.pop().expect("resolve produces one tree")
    }

    /// Whether var `i` occurs (transitively) in `t` — iterative,
    /// resolving through links at every step.
    fn occurs(&self, i: u32, t: &Type) -> bool {
        let mut stack = vec![t.clone()];
        while let Some(t) = stack.pop() {
            match self.resolve_shallow(t) {
                Type::Var(j) => {
                    if j == i {
                        return true;
                    }
                }
                Type::Pair(a, b) => {
                    stack.push(*b);
                    stack.push(*a);
                }
                Type::Arrow { params, ret } => {
                    stack.extend(params);
                    stack.push(*ret);
                }
                _ => {}
            }
        }
        false
    }

    /// Unify two types. Iterative over a pair worklist; `Dyn`
    /// absorbs without binding (the one-way unknown top).
    ///
    /// Transactional (INF-1, §9.77): a failed unification rolls the
    /// link table back to the entry state — bindings from an aborted
    /// worklist never leak into later inference. The contract is
    /// structural (single source, this function) rather than a
    /// per-caller discipline; the rollback shape follows the rustc
    /// inference context's probe/`commit_if_ok` family (snapshot the
    /// undo log, roll back on error — stage0.md §9.77 K174).
    fn unify(&mut self, expected: &Type, found: &Type) -> Result<(), UnifyErr> {
        let mark = self.links.mark();
        match self.unify_worklist(expected, found) {
            Ok(()) => Ok(()),
            Err(e) => {
                self.links.rollback(mark);
                Err(e)
            }
        }
    }

    /// The unification worklist (called only by [`Ctx::unify`], which
    /// owns the transaction boundary).
    fn unify_worklist(&mut self, expected: &Type, found: &Type) -> Result<(), UnifyErr> {
        let mut work = vec![(expected.clone(), found.clone())];
        while let Some((a, b)) = work.pop() {
            let a = self.resolve_shallow(a);
            let b = self.resolve_shallow(b);
            match (a, b) {
                // Dyn absorbs first — it never constrains, so a var
                // meeting Dyn stays free for later refinement.
                (Type::Dyn, _) | (_, Type::Dyn) => {}
                (Type::Var(i), Type::Var(j)) if i == j => {}
                (Type::Var(i), t) => {
                    if self.occurs(i, &t) {
                        return Err(UnifyErr::Recursive { var: i, in_type: t });
                    }
                    self.links.bind(i, t);
                }
                (t, Type::Var(i)) => {
                    if self.occurs(i, &t) {
                        return Err(UnifyErr::Recursive { var: i, in_type: t });
                    }
                    self.links.bind(i, t);
                }
                (Type::Int, Type::Int)
                | (Type::Float, Type::Float)
                | (Type::Bool, Type::Bool)
                | (Type::Str, Type::Str)
                | (Type::Nil, Type::Nil) => {}
                (Type::Pair(a1, b1), Type::Pair(a2, b2)) => {
                    work.push((*a1, *a2));
                    work.push((*b1, *b2));
                }
                (
                    Type::Arrow {
                        params: p1,
                        ret: r1,
                    },
                    Type::Arrow {
                        params: p2,
                        ret: r2,
                    },
                ) if p1.len() == p2.len() => {
                    for (x, y) in p1.into_iter().zip(p2) {
                        work.push((x, y));
                    }
                    work.push((*r1, *r2));
                }
                (expected, found) => return Err(UnifyErr::Mismatch { expected, found }),
            }
        }
        Ok(())
    }

    /// Quantify every free variable of the (resolved) type — the
    /// engine's reference types never leak another binding's vars
    /// (monomorphic lookups seal to concrete-or-`Dyn`, schemas
    /// instantiate fresh), so plain first-seen quantification is
    /// sound; vars shared between mutually recursive defines only
    /// lose precision, never correctness.
    fn generalize(&self, t: &Type) -> TypeSchema {
        let resolved = self.resolve(t);
        let mut vars = Vec::new();
        resolved.var_occurrences(&mut vars);
        vars.dedup();
        TypeSchema {
            vars,
            body: resolved,
        }
    }

    /// Replace the schema's quantified vars with fresh metavariables.
    fn instantiate(&mut self, schema: &TypeSchema) -> Type {
        if schema.vars.is_empty() {
            return schema.body.clone();
        }
        let repl: Vec<Type> = (0..schema.vars.len()).map(|_| self.links.fresh()).collect();
        substitute(&schema.body, &schema.vars, &repl)
    }
}

/// The join of two (resolved) branch types: equal keeps the type,
/// anything else is the unknown top (`if` branches are joined,
/// never unified — dynamic semantics: `(if c 1 #t)` is legal).
fn join(a: &Type, b: &Type) -> Type {
    if a == b { a.clone() } else { Type::Dyn }
}

/// The ground type of a quote literal, iteratively, with the pair
/// depth cap (deep tails collapse to `Dyn`).
fn type_of_literal(v: &LiteralValue) -> Type {
    enum Item<'t> {
        Visit(&'t LiteralValue, u32),
        Pair,
    }
    let mut stack = vec![Item::Visit(v, 0)];
    let mut done: Vec<Type> = Vec::new();
    while let Some(item) = stack.pop() {
        match item {
            Item::Visit(val, depth) => match val {
                LiteralValue::Int(_) => done.push(Type::Int),
                LiteralValue::Float(_) => done.push(Type::Float),
                LiteralValue::Bool(_) => done.push(Type::Bool),
                LiteralValue::String(_) => done.push(Type::Str),
                LiteralValue::Nil => done.push(Type::Nil),
                LiteralValue::Pair(a, b) => {
                    if depth >= LITERAL_TYPE_DEPTH {
                        done.push(Type::Dyn);
                    } else {
                        stack.push(Item::Pair);
                        stack.push(Item::Visit(b, depth + 1));
                        stack.push(Item::Visit(a, depth + 1));
                    }
                }
            },
            Item::Pair => {
                let b = done.pop().expect("literal cdr");
                let a = done.pop().expect("literal car");
                done.push(Type::Pair(Box::new(a), Box::new(b)));
            }
        }
    }
    done.pop().expect("literal type")
}

// ---------- the tree-walk machine ----------

/// One synthesized node: its (raw) type, effect row, and annotated
/// subtree. Types resolve in the final pass, after all late
/// bindings have landed.
struct NodeResult {
    ty: Type,
    effects: EffectRow,
    node: TypedExpr,
}

/// A local binding in the machine environment.
struct LocalEntry {
    /// The pool identity of the bound name (§9.68 CHK-4): params and
    /// let bindings clone the `Symbol` the tree already holds.
    name: Symbol,
    kind: LocalKind,
    poisoned: bool,
}

enum LocalKind {
    /// Parameters and monomorphic let bindings — lookups return the
    /// resolved type, free variables included (sound by evaluation
    /// order: the binding evaluates before every use).
    Mono(Type),
    /// Generalized (Fn-literal let values) — every lookup
    /// instantiates fresh.
    Poly(TypeSchema),
}

/// What the machine asks for next. `'i` is the items lifetime
/// (node references); `'c` is the per-run borrow of the shared
/// context.
enum Task<'i> {
    Enter {
        node: &'i CoreExpr,
        depth: u32,
    },
    /// `if` phase 0: the condition result is on top.
    IfCond {
        node: &'i CoreExpr,
        depth: u32,
    },
    /// `if` phase 1: the then-branch result is on top; `mark` is
    /// the undo-log mark captured after the condition (its bindings
    /// persist — the condition evaluates).
    IfThen {
        node: &'i CoreExpr,
        cond: NodeResult,
        mark: usize,
        depth: u32,
    },
    /// `if` phase 2: the else-branch result is on top; synthesize.
    IfElse {
        node: &'i CoreExpr,
        cond: NodeResult,
        then: NodeResult,
        mark: usize,
    },
    /// `apply`: func + args results on top (func pushed first).
    Apply {
        node: &'i CoreExpr,
        n_args: usize,
    },
    /// `fn`: the body result is on top; truncate the env.
    FnBody {
        node: &'i CoreExpr,
        env_mark: usize,
        param_vars: Vec<Type>,
    },
    /// `let`: re-entrant — bind the finished value (a result is on
    /// top when `next < n`), or pop the body result (`next == n`).
    LetStep {
        node: &'i CoreExpr,
        env_mark: usize,
        depth: u32,
        next: usize,
        bindings: Vec<TypedBinding>,
        effects: EffectRow,
    },
    /// `assign`: the value result is on top; poison the target.
    Assign {
        node: &'i CoreExpr,
    },
    /// `perform`: the arg results are on top.
    Perform {
        node: &'i CoreExpr,
        n_args: usize,
    },
    /// `handle`: body + handler results on top (handlers first).
    Handle {
        node: &'i CoreExpr,
        n_handlers: usize,
    },
}

/// The per-define machine outcome.
enum RunOutcome {
    Done(NodeResult),
    BudgetExceeded,
}

struct Machine<'c, 'i, 'a> {
    ctx: &'c mut Ctx<'a>,
    table: &'c DefineTable,
    /// Pre-bound metavariable per define (parallel to
    /// `table.defines`; same-SCC members only — earlier SCCs are
    /// reached through their generalized schemas).
    pre_vars: &'c [Option<Type>],
    /// The completed schema per define (filled as each SCC
    /// finishes).
    schemas: &'c [Option<TypeSchema>],
    /// SCC membership per define index.
    scc_of: &'c [usize],
    /// This machine's SCC ordinal.
    cur_scc: usize,
    /// The define this machine infers (for `bool_demanded`
    /// bookkeeping — stage0.md §9.49 GATE-2 hardening).
    define_index: usize,
    /// The outermost Fn's parameter metavariables (var idx ->
    /// parameter position). Only the first Fn of the define's value
    /// is registered: those are the schema's parameter positions.
    fn_param_pos: std::collections::HashMap<u32, usize>,
    /// How many defines the module walk has passed (the checker's
    /// `defined_so_far` mirror).
    defined_so_far: usize,
    /// The local environment (params + let bindings), mark/truncate.
    env: Vec<LocalEntry>,
    /// Whether the current position is inside any `Fn` body (the
    /// checker's `in_fn` mirror — call-time visibility).
    fn_depth: usize,
    tasks: Vec<Task<'i>>,
    results: Vec<NodeResult>,
}

impl<'c, 'i, 'a> Machine<'c, 'i, 'a> {
    fn new(
        ctx: &'c mut Ctx<'a>,
        table: &'c DefineTable,
        pre_vars: &'c [Option<Type>],
        schemas: &'c [Option<TypeSchema>],
        scc_of: &'c [usize],
        cur_scc: usize,
        define_index: usize,
    ) -> Self {
        // The letrec pre-bind mirror (expander/checker discipline):
        // the name is visible while inferring its own value.
        let (name, pre) = {
            let (n, info) = &table.defines[define_index];
            let pre = if table.is_assigned(n) {
                Type::Dyn
            } else {
                match info {
                    DefineInfo::Literal(v) => type_of_literal(v),
                    DefineInfo::FnLiteral | DefineInfo::Other => {
                        pre_vars[define_index].clone().unwrap_or(Type::Dyn)
                    }
                }
            };
            (n.clone(), pre)
        };
        let env = vec![LocalEntry {
            name,
            kind: LocalKind::Mono(pre),
            poisoned: false,
        }];
        Machine {
            ctx,
            table,
            pre_vars,
            schemas,
            scc_of,
            cur_scc,
            define_index,
            fn_param_pos: std::collections::HashMap::new(),
            defined_so_far: define_index,
            env,
            fn_depth: 0,
            tasks: Vec::new(),
            results: Vec::new(),
        }
    }

    fn run(mut self, value: &'i CoreExpr) -> RunOutcome {
        self.tasks.push(Task::Enter {
            node: value,
            depth: 0,
        });
        while let Some(task) = self.tasks.pop() {
            match task {
                Task::Enter { node, depth } => {
                    if depth > INFERENCE_DEPTH_LIMIT {
                        return RunOutcome::BudgetExceeded;
                    }
                    self.enter(node, depth);
                }
                Task::IfCond { node, depth } => self.leave_if_cond(node, depth),
                Task::IfThen {
                    node,
                    cond,
                    mark,
                    depth,
                } => self.leave_if_then(node, cond, mark, depth),
                Task::IfElse {
                    node,
                    cond,
                    then,
                    mark,
                } => self.leave_if_else(node, cond, then, mark),
                Task::Apply { node, n_args } => self.leave_apply(node, n_args),
                Task::FnBody {
                    node,
                    env_mark,
                    param_vars,
                } => self.leave_fn(node, env_mark, param_vars),
                Task::LetStep {
                    node,
                    env_mark,
                    depth,
                    next,
                    bindings,
                    effects,
                } => self.leave_let(node, env_mark, depth, next, bindings, effects),
                Task::Assign { node } => self.leave_assign(node),
                Task::Perform { node, n_args } => self.leave_perform(node, n_args),
                Task::Handle { node, n_handlers } => self.leave_handle(node, n_handlers),
            }
        }
        match self.results.pop() {
            Some(r) => RunOutcome::Done(r),
            None => RunOutcome::BudgetExceeded,
        }
    }

    fn enter(&mut self, node: &'i CoreExpr, depth: u32) {
        match node {
            CoreExpr::Literal { span, value } => {
                let ty = type_of_literal(value);
                self.results.push(NodeResult {
                    ty: ty.clone(),
                    effects: EffectRow::empty(),
                    node: TypedExpr::Literal {
                        span: *span,
                        value: value.clone(),
                        ty,
                    },
                });
            }
            CoreExpr::Var { span, name } => {
                let ty = self.lookup(name);
                self.results.push(NodeResult {
                    ty: ty.clone(),
                    effects: EffectRow::empty(),
                    node: TypedExpr::Var {
                        span: *span,
                        name: name.clone(),
                        ty,
                    },
                });
            }
            CoreExpr::Fn { params, body, .. } => {
                let env_mark = self.env.len();
                let mut param_vars = Vec::with_capacity(params.len());
                for (pos, p) in params.iter().enumerate() {
                    let v = self.ctx.links.fresh();
                    // Register the outermost Fn's parameters — the
                    // define's schema positions — for the if-cond
                    // bool-demand bookkeeping (§9.49 GATE-2).
                    if self.fn_depth == 0 {
                        if let Type::Var(i) = &v {
                            self.fn_param_pos.insert(*i, pos);
                        }
                    }
                    param_vars.push(v.clone());
                    self.env.push(LocalEntry {
                        name: p.clone(),
                        kind: LocalKind::Mono(v),
                        poisoned: false,
                    });
                }
                self.fn_depth += 1;
                self.tasks.push(Task::FnBody {
                    node,
                    env_mark,
                    param_vars,
                });
                self.tasks.push(Task::Enter {
                    node: body,
                    depth: depth + 1,
                });
            }
            CoreExpr::Apply { func, args, .. } => {
                self.tasks.push(Task::Apply {
                    node,
                    n_args: args.len(),
                });
                // Pop order: func, arg1..argN — push in reverse.
                for a in args.iter().rev() {
                    self.tasks.push(Task::Enter {
                        node: a,
                        depth: depth + 1,
                    });
                }
                self.tasks.push(Task::Enter {
                    node: func,
                    depth: depth + 1,
                });
            }
            CoreExpr::If { .. } => {
                self.tasks.push(Task::IfCond { node, depth });
                let CoreExpr::If { cond, .. } = node else {
                    unreachable!("matched If");
                };
                self.tasks.push(Task::Enter {
                    node: cond,
                    depth: depth + 1,
                });
                // The branches are entered by the phase steps so
                // each branch's bindings can be bracketed on the
                // undo log.
            }
            CoreExpr::Let { bindings, body, .. } => {
                let env_mark = self.env.len();
                self.tasks.push(Task::LetStep {
                    node,
                    env_mark,
                    depth,
                    next: 0,
                    bindings: Vec::new(),
                    effects: EffectRow::empty(),
                });
                if let Some(first) = bindings.first() {
                    self.tasks.push(Task::Enter {
                        node: &first.value,
                        depth: depth + 1,
                    });
                } else {
                    // Empty bindings: straight to the body (the
                    // expander rejects empty `let`; direct
                    // constructions may still reach here).
                    self.tasks.push(Task::Enter {
                        node: body,
                        depth: depth + 1,
                    });
                }
            }
            CoreExpr::Assign { value, .. } => {
                self.tasks.push(Task::Assign { node });
                self.tasks.push(Task::Enter {
                    node: value,
                    depth: depth + 1,
                });
            }
            CoreExpr::Perform { args, .. } => {
                self.tasks.push(Task::Perform {
                    node,
                    n_args: args.len(),
                });
                for a in args.iter().rev() {
                    self.tasks.push(Task::Enter {
                        node: a,
                        depth: depth + 1,
                    });
                }
            }
            CoreExpr::Handle { body, handlers, .. } => {
                self.tasks.push(Task::Handle {
                    node,
                    n_handlers: handlers.len(),
                });
                // Pop order: handlers first, then the body.
                self.tasks.push(Task::Enter {
                    node: body,
                    depth: depth + 1,
                });
                for h in handlers {
                    self.tasks.push(Task::Enter {
                        node: &h.handler,
                        depth: depth + 1,
                    });
                }
            }
        }
    }

    // ---------- name resolution (the checker's mirror) ----------

    /// Resolve a variable reference to a type. Order mirrors the
    /// pipeline: locals (innermost wins) -> module defines
    /// (position-aware) -> externals -> unknown (`Dyn`; the unbound
    /// case is R1's domain, never cascaded here).
    fn lookup(&mut self, name: &Symbol) -> Type {
        // 1. locals (reverse scan — innermost binding wins; pool
        // identity comparison, §9.68 CHK-4).
        for entry in self.env.iter().rev() {
            if entry.name == *name {
                if entry.poisoned {
                    return Type::Dyn;
                }
                return match &entry.kind {
                    LocalKind::Mono(t) => self.ctx.resolve(t),
                    LocalKind::Poly(s) => self.ctx.instantiate(s),
                };
            }
        }
        // 2. module defines — position-aware visibility.
        let in_fn = self.fn_depth > 0;
        let visible = if in_fn {
            self.table.defines.len()
        } else {
            self.defined_so_far.min(self.table.defines.len())
        };
        if let Some(idx) = self.table.defines[..visible]
            .iter()
            .rposition(|(n, _)| n == name)
        {
            if self.table.is_assigned(name) {
                return Type::Dyn;
            }
            match &self.table.defines[idx].1 {
                DefineInfo::FnLiteral => {
                    if self.scc_of[idx] == self.cur_scc {
                        // Same SCC (mutual recursion): unify-through
                        // the pre-var — the knot ties after all
                        // members finish.
                        match &self.pre_vars[idx] {
                            Some(t) => self.ctx.resolve(t),
                            None => Type::Dyn,
                        }
                    } else {
                        // An earlier SCC: instantiate its generalized
                        // schema — polymorphic reuse is decoupled per
                        // use (same-module `(id 1)` + `(id #t)` must
                        // both typecheck).
                        match &self.schemas[idx] {
                            Some(s) => self.ctx.instantiate(s),
                            None => Type::Dyn,
                        }
                    }
                }
                DefineInfo::Literal(v) => type_of_literal(v),
                DefineInfo::Other => match &self.schemas[idx] {
                    // Sealed concrete-or-Dyn at its own SCC pass —
                    // references never share its vars.
                    Some(s) => s.body.clone(),
                    // Not inferred yet (a forward reference from a
                    // non-Fn position is impossible on the source
                    // path — the expander rejects it; direct
                    // constructions get the conservative Dyn).
                    None => Type::Dyn,
                },
            }
        } else {
            // 3. externals — a bare builtin reference types as Dyn;
            //    the ad-hoc table applies at application sites only.
            let _ = self.ctx.externals.resolve(name);
            Type::Dyn
        }
    }

    // ---------- leave steps ----------

    fn leave_if_cond(&mut self, node: &'i CoreExpr, depth: u32) {
        let CoreExpr::If { then_branch, .. } = node else {
            unreachable!("matched If");
        };
        let cond_r = self.results.pop().expect("cond result");
        // The condition evaluates before either branch: its
        // bindings persist (evaluation-order soundness).
        // Register the bool demand before the unify binds: an
        // unresolved parameter metavariable forced to `bool` here
        // is the one body-sensitive binding source — a later
        // concrete non-bool argument at this position is a
        // definite error (§9.49 GATE-2).
        if let Type::Var(i) = &cond_r.ty {
            if let Some(&pos) = self.fn_param_pos.get(i) {
                self.ctx.bool_demanded[self.define_index].insert(pos);
            }
        }
        // Demanded side first so a mismatch carries the condition's
        // type as the `found` payload.
        if let Err(e) = self.ctx.unify(&Type::Bool, &cond_r.ty) {
            self.report_unify_cond(e, node);
        }
        let mark = self.ctx.links.mark();
        self.tasks.push(Task::IfThen {
            node,
            cond: cond_r,
            mark,
            depth,
        });
        self.tasks.push(Task::Enter {
            node: then_branch,
            depth: depth + 1,
        });
    }

    fn leave_if_then(&mut self, node: &'i CoreExpr, cond: NodeResult, mark: usize, depth: u32) {
        let CoreExpr::If { else_branch, .. } = node else {
            unreachable!("matched If");
        };
        let then_r = self.results.pop().expect("then result");
        // Bracket the then-branch: its bindings must not leak.
        self.ctx.links.rollback(mark);
        self.tasks.push(Task::IfElse {
            node,
            cond,
            then: then_r,
            mark,
        });
        self.tasks.push(Task::Enter {
            node: else_branch,
            depth: depth + 1,
        });
    }

    fn leave_if_else(
        &mut self,
        node: &'i CoreExpr,
        cond: NodeResult,
        then: NodeResult,
        mark: usize,
    ) {
        let CoreExpr::If { span, .. } = node else {
            unreachable!("matched If");
        };
        let else_r = self.results.pop().expect("else result");
        // Bracket the else-branch too.
        self.ctx.links.rollback(mark);
        let ty = join(&self.ctx.resolve(&then.ty), &self.ctx.resolve(&else_r.ty));
        let mut effects = cond.effects.clone();
        effects.union(&then.effects);
        effects.union(&else_r.effects);
        self.results.push(NodeResult {
            ty: ty.clone(),
            effects: effects.clone(),
            node: TypedExpr::If {
                span: *span,
                cond: Box::new(cond.node),
                then_branch: Box::new(then.node),
                else_branch: Box::new(else_r.node),
                ty,
                effects,
            },
        });
    }

    fn leave_apply(&mut self, node: &'i CoreExpr, n_args: usize) {
        let CoreExpr::Apply {
            span, func, args, ..
        } = node
        else {
            unreachable!("matched Apply");
        };
        // Results arrived func-first.
        let mut arg_results: Vec<NodeResult> = Vec::with_capacity(n_args);
        for _ in 0..n_args {
            arg_results.push(self.results.pop().expect("arg result"));
        }
        arg_results.reverse();
        let func_r = self.results.pop().expect("func result");

        let ty = self.apply_type(*span, func, &func_r, args, &arg_results);

        let mut effects = func_r.effects.clone();
        for a in &arg_results {
            effects.union(&a.effects);
        }
        let arg_nodes = arg_results.into_iter().map(|r| r.node).collect::<Vec<_>>();
        self.results.push(NodeResult {
            ty: ty.clone(),
            effects: effects.clone(),
            node: TypedExpr::Apply {
                span: *span,
                func: Box::new(func_r.node),
                args: arg_nodes,
                ty,
                effects,
            },
        });
    }

    /// The application typing: ad-hoc builtins, arrow unification,
    /// and the R4 mirror guard. Arity is R2's domain — a count
    /// mismatch skips type unification entirely.
    fn apply_type(
        &mut self,
        span: Span,
        func_node: &CoreExpr,
        func_r: &NodeResult,
        args: &[CoreExpr],
        arg_results: &[NodeResult],
    ) -> Type {
        // 1. The builtin ad-hoc path — only when the callee is a
        //    bare name resolving to an external (locals shadow,
        //    defines shadow, assigned names skip — R2's guard
        //    mirror).
        if let CoreExpr::Var { name, .. } = func_node {
            // Shadow and assign-guard checks ride pool identities;
            // the ad-hoc builtin dispatch below keeps the text face
            // (str-literal match arms — CHK-7).
            let text = name.as_str();
            let shadowed = self.env.iter().any(|e| e.name == *name) || self.shadowing_define(name);
            let builtin_path = !shadowed
                && !self.table.is_assigned(name)
                && self.ctx.externals.resolve(name).is_some();
            if builtin_path {
                return self.builtin_type(text, span, arg_results);
            }
        }
        // 2. The general path: unify the callee with an arrow.
        // The callee's define index (when the callee is a bare
        // name hitting a visible Fn-literal define) feeds the
        // bool-demand exception of `unify_args` (§9.49 GATE-2).
        let callee_define = self.callee_define_index(func_node);
        let callee = self.ctx.resolve_shallow(func_r.ty.clone());
        match callee {
            Type::Dyn => Type::Dyn,
            Type::Var(i) => {
                let param_vars: Vec<Type> =
                    (0..args.len()).map(|_| self.ctx.links.fresh()).collect();
                let ret = self.ctx.links.fresh();
                let arrow = Type::Arrow {
                    params: param_vars.clone(),
                    ret: Box::new(ret.clone()),
                };
                if let Err(e) = self.ctx.unify(&Type::Var(i), &arrow) {
                    self.report_unify(e, span);
                    return Type::Dyn;
                }
                self.unify_args(&param_vars, args, arg_results, callee_define);
                ret
            }
            Type::Arrow { params, ret } => {
                if params.len() != args.len() {
                    // R2 owns arity — skip typing, keep the ret.
                    return self.ctx.resolve(&ret);
                }
                self.unify_args(&params, args, arg_results, callee_define);
                self.ctx.resolve(&ret)
            }
            concrete => {
                // Definitely not callable — unless R4 owns the case
                // (literal callee shapes), which is never duplicated.
                if r4_owns(func_node, self.table) {
                    return Type::Dyn;
                }
                self.ctx.report(
                    TypeCode::TypeMismatch,
                    Severity::Error,
                    span,
                    format!("type mismatch: expected a function, found `{concrete}`"),
                );
                Type::Dyn
            }
        }
    }

    /// The define index behind a callee, when the callee is a bare
    /// name resolving to a visible, unassigned Fn-literal define
    /// (the same visibility the `lookup` walk uses). Used only for
    /// the bool-demand exception in `unify_args`.
    fn callee_define_index(&self, func_node: &CoreExpr) -> Option<usize> {
        let CoreExpr::Var { name, .. } = func_node else {
            return None;
        };
        // A local binding (param/let) shadows the define; an
        // assigned define types as Dyn and never reaches the arrow
        // unification, so it is excluded here too.
        if self.env.iter().any(|e| e.name == *name) || self.table.is_assigned(name) {
            return None;
        }
        let visible = if self.fn_depth > 0 {
            self.table.defines.len()
        } else {
            self.defined_so_far.min(self.table.defines.len())
        };
        self.table.defines[..visible]
            .iter()
            .rposition(|(n, info)| n == name && matches!(info, DefineInfo::FnLiteral))
    }

    fn unify_args(
        &mut self,
        params: &[Type],
        args: &[CoreExpr],
        arg_results: &[NodeResult],
        callee: Option<usize>,
    ) {
        // A failing argument-shape constraint is an
        // over-approximation of failure, not a definite one:
        // heterogeneous tag dispatch (one parameter fed different
        // tuple shapes at different call sites) is legal dynamic
        // code, so the constraint this call site imposes is rolled
        // back and released — never reported. The one exception is
        // the bool demand: a parameter position the callee's own
        // body forced to `bool` via an if condition rejects every
        // concrete non-bool argument at run time (the VM's
        // bool-strict `jump-if-false`), which is a definite error.
        // The occurs check (E0010) stays: a cyclic type is a
        // structural defect, not a shape approximation.
        let mark = self.ctx.links.mark();
        let mut failures = Vec::new();
        for (pos, ((p, arg_node), r)) in params.iter().zip(args).zip(arg_results).enumerate() {
            if let Err(e) = self.ctx.unify(p, &r.ty) {
                failures.push((pos, e, expr_span(arg_node)));
            }
        }
        if failures.is_empty() {
            return;
        }
        // Release every constraint this call site imposed — the
        // successful ones too, not just the failed pairs (a clean
        // slate keeps later unifications free of half-applied
        // shapes). Failed pairs additionally rolled back inside
        // `unify` itself since INF-1 (§9.77); this outer rollback
        // owns the release semantics of the whole call site.
        self.ctx.links.rollback(mark);
        for (pos, e, span) in failures {
            match e {
                UnifyErr::Mismatch { expected, found } => {
                    if matches!(expected, Type::Var(_)) || matches!(found, Type::Var(_)) {
                        continue; // Unresolved — not definite.
                    }
                    let demanded = callee
                        .map(|idx| {
                            self.ctx
                                .bool_demanded
                                .get(idx)
                                .is_some_and(|set| set.contains(&pos))
                        })
                        .unwrap_or(false)
                        && expected == Type::Bool
                        && !matches!(found, Type::Bool | Type::Dyn);
                    if demanded {
                        self.ctx.report(
                            TypeCode::TypeMismatch,
                            Severity::Error,
                            span,
                            format!("type mismatch: expected `{expected}`, found `{found}`"),
                        );
                    }
                    // Otherwise: over-approximation — released. The
                    // parameter keeps whatever its body demanded.
                }
                UnifyErr::Recursive { var, in_type } => {
                    self.ctx.report(
                        TypeCode::RecursiveType,
                        Severity::Error,
                        span,
                        format!("recursive type: `t{var}` occurs in `{in_type}`"),
                    );
                }
            }
        }
    }

    /// The ad-hoc builtin table (18 builtins, a closed set — the
    /// runtime's own domain rules, builtin.rs, mirrored type-side).
    fn builtin_type(&mut self, name: &str, span: Span, args: &[NodeResult]) -> Type {
        let n = args.len();
        match name {
            "+" | "-" | "*" | "/" => {
                if n != 2 {
                    return Type::Dyn; // R2 owns arity.
                }
                let a = self.ctx.resolve(&args[0].ty);
                let b = self.ctx.resolve(&args[1].ty);
                match (is_numeric(&a), is_numeric(&b)) {
                    (Some(true), Some(true)) => {
                        if a == b {
                            a
                        } else {
                            self.ctx.report(
                                TypeCode::TypeMismatch,
                                Severity::Error,
                                span,
                                format!("type mismatch: expected `{a}`, found `{b}`"),
                            );
                            Type::Dyn
                        }
                    }
                    (Some(false), _) => {
                        self.report_non_numeric(span, &a);
                        Type::Dyn
                    }
                    (_, Some(false)) => {
                        self.report_non_numeric(span, &b);
                        Type::Dyn
                    }
                    _ => Type::Dyn,
                }
            }
            "<" | "<=" | ">" | ">=" | "=" => {
                if n != 2 {
                    return Type::Bool; // Errors or a bool either way.
                }
                let a = self.ctx.resolve(&args[0].ty);
                let b = self.ctx.resolve(&args[1].ty);
                match (is_numeric(&a), is_numeric(&b)) {
                    (Some(true), Some(true)) => {
                        if a == b {
                            Type::Bool
                        } else {
                            self.ctx.report(
                                TypeCode::TypeMismatch,
                                Severity::Error,
                                span,
                                format!("type mismatch: expected `{a}`, found `{b}`"),
                            );
                            Type::Dyn
                        }
                    }
                    (Some(false), _) => {
                        self.report_non_numeric(span, &a);
                        Type::Dyn
                    }
                    (_, Some(false)) => {
                        self.report_non_numeric(span, &b);
                        Type::Dyn
                    }
                    _ => Type::Bool,
                }
            }
            "car" | "cdr" => {
                if n != 1 {
                    return Type::Dyn;
                }
                let a = self.ctx.resolve(&args[0].ty);
                match a {
                    Type::Pair(car_t, cdr_t) => {
                        if name == "car" {
                            *car_t
                        } else {
                            *cdr_t
                        }
                    }
                    Type::Dyn | Type::Var(_) => Type::Dyn,
                    concrete => {
                        self.ctx.report(
                            TypeCode::TypeMismatch,
                            Severity::Error,
                            span,
                            format!("type mismatch: expected `pair`, found `{concrete}`"),
                        );
                        Type::Dyn
                    }
                }
            }
            "cons" => {
                if n != 2 {
                    return Type::Dyn;
                }
                Type::Pair(Box::new(args[0].ty.clone()), Box::new(args[1].ty.clone()))
            }
            "pair?" | "nil?" | "eq?" => Type::Bool,
            "not" => {
                if n != 1 {
                    return Type::Bool;
                }
                let a = self.ctx.resolve(&args[0].ty);
                match a {
                    Type::Bool | Type::Dyn | Type::Var(_) => Type::Bool,
                    concrete => {
                        self.ctx.report(
                            TypeCode::TypeMismatch,
                            Severity::Error,
                            span,
                            format!("type mismatch: expected `bool`, found `{concrete}`"),
                        );
                        Type::Dyn
                    }
                }
            }
            "read-line" => Type::Str,
            "write-line" => {
                if n != 1 {
                    return Type::Nil;
                }
                let a = self.ctx.resolve(&args[0].ty);
                match a {
                    Type::Str | Type::Dyn | Type::Var(_) => Type::Nil,
                    concrete => {
                        self.ctx.report(
                            TypeCode::TypeMismatch,
                            Severity::Error,
                            span,
                            format!("type mismatch: expected `str`, found `{concrete}`"),
                        );
                        Type::Nil
                    }
                }
            }
            _ => Type::Dyn,
        }
    }

    fn report_non_numeric(&mut self, span: Span, got: &Type) {
        self.ctx.report(
            TypeCode::TypeMismatch,
            Severity::Error,
            span,
            format!("type mismatch: expected `int` or `float`, found `{got}`"),
        );
    }

    /// Report an if-condition unification failure (the demanded
    /// side is always `bool`).
    fn report_unify_cond(&mut self, e: UnifyErr, node: &CoreExpr) {
        let span = expr_span(node);
        match e {
            UnifyErr::Mismatch { found, .. } => {
                if matches!(found, Type::Var(_)) {
                    return; // Unresolved — not definite.
                }
                self.ctx.report(
                    TypeCode::TypeMismatch,
                    Severity::Error,
                    span,
                    format!("type mismatch: expected `bool`, found `{found}`"),
                );
            }
            UnifyErr::Recursive { var, in_type } => {
                self.ctx.report(
                    TypeCode::RecursiveType,
                    Severity::Error,
                    span,
                    format!("recursive type: `t{var}` occurs in `{in_type}`"),
                );
            }
        }
    }

    /// Report a general unification failure in the R8 message
    /// family (arrows/args). Unresolved (var) sides are not
    /// definite errors — the unify layer only fails Mismatch on
    /// concrete-concrete, so the var guard is defensive.
    fn report_unify(&mut self, e: UnifyErr, span: Span) {
        match e {
            UnifyErr::Mismatch { expected, found } => {
                if matches!(expected, Type::Var(_)) || matches!(found, Type::Var(_)) {
                    return;
                }
                self.ctx.report(
                    TypeCode::TypeMismatch,
                    Severity::Error,
                    span,
                    format!("type mismatch: expected `{expected}`, found `{found}`"),
                );
            }
            UnifyErr::Recursive { var, in_type } => {
                self.ctx.report(
                    TypeCode::RecursiveType,
                    Severity::Error,
                    span,
                    format!("recursive type: `t{var}` occurs in `{in_type}`"),
                );
            }
        }
    }

    fn leave_fn(&mut self, node: &'i CoreExpr, env_mark: usize, param_vars: Vec<Type>) {
        let CoreExpr::Fn { span, params, .. } = node else {
            unreachable!("matched Fn");
        };
        let body_r = self.results.pop().expect("body result");
        self.env.truncate(env_mark);
        self.fn_depth -= 1;
        let ty = Type::Arrow {
            params: param_vars,
            ret: Box::new(body_r.ty),
        };
        // The fn's own row is its body's row (the collection face).
        self.results.push(NodeResult {
            ty: ty.clone(),
            effects: body_r.effects,
            node: TypedExpr::Fn {
                span: *span,
                params: params.clone(),
                body: Box::new(body_r.node),
                ty,
            },
        });
    }

    #[allow(clippy::too_many_arguments)]
    fn leave_let(
        &mut self,
        node: &'i CoreExpr,
        env_mark: usize,
        depth: u32,
        next: usize,
        mut bindings: Vec<TypedBinding>,
        mut effects: EffectRow,
    ) {
        let CoreExpr::Let {
            span,
            bindings: src,
            body,
        } = node
        else {
            unreachable!("matched Let");
        };
        if next < src.len() {
            // A binding value just finished (its result is on top).
            let r = self.results.pop().expect("binding result");
            let b = &src[next];
            let kind = if matches!(b.value, CoreExpr::Fn { .. }) {
                // Let-polymorphism: syntactic Fn values generalize.
                LocalKind::Poly(self.ctx.generalize(&r.ty))
            } else {
                LocalKind::Mono(r.ty.clone())
            };
            self.env.push(LocalEntry {
                name: b.name.clone(),
                kind,
                poisoned: false,
            });
            effects.union(&r.effects);
            bindings.push(TypedBinding {
                span: b.span,
                name: b.name.clone(),
                ty: r.ty,
                value: r.node,
            });
            let next = next + 1;
            self.tasks.push(Task::LetStep {
                node,
                env_mark,
                depth,
                next,
                bindings,
                effects,
            });
            let target = if next < src.len() {
                &src[next].value
            } else {
                body
            };
            self.tasks.push(Task::Enter {
                node: target,
                depth: depth + 1,
            });
        } else {
            // The body just finished.
            let body_r = self.results.pop().expect("body result");
            self.env.truncate(env_mark);
            effects.union(&body_r.effects);
            self.results.push(NodeResult {
                ty: body_r.ty.clone(),
                effects: effects.clone(),
                node: TypedExpr::Let {
                    span: *span,
                    bindings,
                    body: Box::new(body_r.node),
                    ty: body_r.ty,
                    effects,
                },
            });
        }
    }

    fn leave_assign(&mut self, node: &'i CoreExpr) {
        let CoreExpr::Assign { span, name, .. } = node else {
            unreachable!("matched Assign");
        };
        let value_r = self.results.pop().expect("value result");
        // Evaluation order: the value evaluates first, then the
        // binding changes — poison the local target *after* the
        // value's lookups, for everything after this point.
        for entry in self.env.iter_mut().rev() {
            if entry.name == *name {
                entry.poisoned = true;
                break;
            }
        }
        // Assignments evaluate to the assigned value (eval.rs).
        self.results.push(NodeResult {
            ty: value_r.ty.clone(),
            effects: value_r.effects.clone(),
            node: TypedExpr::Assign {
                span: *span,
                name: name.clone(),
                value: Box::new(value_r.node),
                ty: value_r.ty,
                effects: value_r.effects,
            },
        });
    }

    fn leave_perform(&mut self, node: &'i CoreExpr, n_args: usize) {
        let CoreExpr::Perform { span, effect, .. } = node else {
            unreachable!("matched Perform");
        };
        let mut arg_results: Vec<NodeResult> = Vec::with_capacity(n_args);
        for _ in 0..n_args {
            arg_results.push(self.results.pop().expect("perform arg"));
        }
        arg_results.reverse();
        let mut effects = EffectRow::empty();
        for r in &arg_results {
            effects.union(&r.effects);
        }
        effects.push(effect.clone());
        let arg_nodes = arg_results.into_iter().map(|r| r.node).collect::<Vec<_>>();
        // The handler's return type is unknown at perform time.
        self.results.push(NodeResult {
            ty: Type::Dyn,
            effects: effects.clone(),
            node: TypedExpr::Perform {
                span: *span,
                effect: effect.clone(),
                args: arg_nodes,
                ty: Type::Dyn,
                effects,
            },
        });
    }

    fn leave_handle(&mut self, node: &'i CoreExpr, n_handlers: usize) {
        let CoreExpr::Handle { span, handlers, .. } = node else {
            unreachable!("matched Handle");
        };
        // Results arrived: handlers first, then the body.
        let body_r = self.results.pop().expect("handle body result");
        let mut handler_results: Vec<NodeResult> = Vec::with_capacity(n_handlers);
        for _ in 0..n_handlers {
            handler_results.push(self.results.pop().expect("handler result"));
        }
        handler_results.reverse();

        // row = (row(body) \ intercepted) ∪ ⋃ row(handler_i) — the
        // subtraction is definite (clauses install before the body
        // runs), the handler merge is the over-approximate direction.
        let intercepted: Vec<&Symbol> = handlers.iter().map(|h| &h.effect).collect();
        let mut effects = body_r.effects.without(&intercepted);
        let mut typed_handlers = Vec::with_capacity(n_handlers);
        for (clause, r) in handlers.iter().zip(handler_results) {
            effects.union(&r.effects);
            typed_handlers.push(TypedHandler {
                span: clause.span,
                effect: clause.effect.clone(),
                ty: r.ty,
                handler: r.node,
            });
        }
        self.results.push(NodeResult {
            ty: body_r.ty.clone(),
            effects: effects.clone(),
            node: TypedExpr::Handle {
                span: *span,
                body: Box::new(body_r.node),
                handlers: typed_handlers,
                ty: body_r.ty,
                effects,
            },
        });
    }

    /// Whether any *visible* define binds this name (a define
    /// shadows the builtin ad-hoc path — the R2 mirror).
    fn shadowing_define(&self, name: &Symbol) -> bool {
        let visible = if self.fn_depth > 0 {
            self.table.defines.len()
        } else {
            self.defined_so_far.min(self.table.defines.len())
        };
        self.table.defines[..visible].iter().any(|(n, _)| n == name)
    }
}

/// Whether a resolved type is numeric — `Some(bool)` when known,
/// `None` for the skip direction (var/Dyn).
fn is_numeric(t: &Type) -> Option<bool> {
    match t {
        Type::Int | Type::Float => Some(true),
        Type::Var(_) | Type::Dyn => None,
        _ => Some(false),
    }
}

/// Whether the R4 rule (non-callable callee) owns this callee — the
/// inference layer never duplicates R4's diagnostics.
fn r4_owns(func_node: &CoreExpr, table: &DefineTable) -> bool {
    match func_node {
        CoreExpr::Literal { .. } => true,
        CoreExpr::Var { name, .. } => {
            table
                .defines
                .iter()
                .rev()
                .any(|(n, info)| n == name && matches!(info, DefineInfo::Literal(_)))
                && !table.is_assigned(name)
        }
        _ => false,
    }
}

/// Every `CoreExpr` carries a span — a tiny helper for call sites
/// that hold the node generically.
fn expr_span(e: &CoreExpr) -> Span {
    match e {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

// ---------- module driver ----------

/// Infer types and effect rows for one expanded program.
///
/// Runs after (or beside) `check_module` — the two collect
/// independently and never short-circuit. The typed program
/// contains only the defines whose inference completed within the
/// depth budget; a define past the budget emits one `E0011`
/// warning and is skipped whole (no partial annotations).
///
/// # SCC processing (the polymorphism/recursion split)
///
/// Defines are grouped by strongly-connected components of the
/// syntactic call graph and processed dependencies-first (iterative
/// Tarjan). Within an SCC, members unify through pre-bound
/// metavariables — mutual recursion types the way ML letrec does.
/// Across SCCs, references instantiate the callee's *generalized
/// schema* — same-module polymorphic reuse (`(id 1)` + `(id #t)`)
/// is decoupled per use and never monomorphized by its own module.
pub fn infer_module(items: &[ModuleItem], externals: &Externals) -> InferOutcome {
    let mut table = DefineTable::default();
    collect_info(items, &mut table);

    let n = table.defines.len();
    let mut ctx = Ctx {
        links: Links::default(),
        externals,
        diagnostics: Vec::new(),
        bool_demanded: vec![std::collections::HashSet::new(); n],
    };

    // The syntactic call graph (over-approximated: every Var name
    // matching any define counts — local shadowing only widens an
    // SCC, which loses precision, never correctness).
    let flat = flatten_defines(items);
    let mut refs: Vec<Vec<Symbol>> = vec![Vec::new(); n];
    for d in &flat {
        let ModuleItem::Define { value, .. } = d.item else {
            unreachable!("flatten yields defines");
        };
        collect_var_names(value, &mut refs[d.index]);
    }
    let edges: Vec<Vec<usize>> = (0..n)
        .map(|i| {
            let mut out = Vec::new();
            for (j, (name, _)) in table.defines.iter().enumerate() {
                if refs[i].iter().any(|r| r == name) && !out.contains(&j) {
                    out.push(j);
                }
            }
            out
        })
        .collect();

    // Tarjan emits SCCs with dependencies first — exactly the
    // processing order (a reference can only target an earlier SCC
    // or the same one).
    let sccs = tarjan_sccs(n, &edges);
    let mut scc_of = vec![usize::MAX; n];
    for (si, scc) in sccs.iter().enumerate() {
        for &m in scc {
            scc_of[m] = si;
        }
    }

    let mut pre_vars: Vec<Option<Type>> = vec![None; n];
    let mut schemas: Vec<Option<TypeSchema>> = vec![None; n];
    let mut sealed_tys: Vec<Option<Type>> = vec![None; n];
    let mut results: Vec<Option<NodeResult>> = (0..n).map(|_| None).collect();

    for scc in &sccs {
        // Pre-bind this SCC's members (the letrec knot).
        for &idx in scc {
            let (name, info) = &table.defines[idx];
            let pre = if table.is_assigned(name) {
                Type::Dyn
            } else {
                match info {
                    DefineInfo::Literal(v) => type_of_literal(v),
                    DefineInfo::FnLiteral | DefineInfo::Other => ctx.links.fresh(),
                }
            };
            pre_vars[idx] = Some(pre);
        }
        // Infer members in module order (the walk mirrors check.rs
        // `walk_items` — `defined_so_far` advances before each
        // value, the letrec pre-bind mirror).
        let mut members = scc.clone();
        members.sort_unstable();
        for &idx in &members {
            let ModuleItem::Define {
                name, value, span, ..
            } = flat
                .iter()
                .find(|d| d.index == idx)
                .expect("flat holds every define")
                .item
            else {
                unreachable!("flatten yields defines");
            };
            let pre = pre_vars[idx].clone().unwrap_or(Type::Dyn);
            let cur_scc = scc_of[idx];
            let outcome =
                Machine::new(&mut ctx, &table, &pre_vars, &schemas, &scc_of, cur_scc, idx)
                    .run(value);
            match outcome {
                RunOutcome::Done(r) => {
                    // Bind the pre-var (a no-op when internal calls
                    // already constrained it through unification) and
                    // seal the monomorphic members.
                    match &table.defines[idx].1 {
                        DefineInfo::FnLiteral => {
                            if let Type::Var(v) = pre {
                                if ctx.links.link_of(v).is_none() {
                                    ctx.links.bind(v, r.ty.clone());
                                }
                            }
                        }
                        _ => {
                            let resolved = ctx.resolve(&r.ty);
                            let mut fv = Vec::new();
                            resolved.var_occurrences(&mut fv);
                            // A monomorphic define exposing free vars
                            // means "fixed but unknown value" — seal
                            // to Dyn (references must not share them).
                            let sealed_ty = if fv.is_empty() { resolved } else { Type::Dyn };
                            sealed_tys[idx] = Some(sealed_ty.clone());
                            if let Type::Var(v) = pre {
                                if ctx.links.link_of(v).is_none() {
                                    ctx.links.bind(v, sealed_ty);
                                }
                            }
                        }
                    }
                    results[idx] = Some(r);
                }
                RunOutcome::BudgetExceeded => {
                    // Seal the pre-var to Dyn (references must not
                    // dangle) and disclose the limit — a warning,
                    // never an error.
                    if let Type::Var(v) = pre {
                        if ctx.links.link_of(v).is_none() {
                            ctx.links.bind(v, Type::Dyn);
                        }
                    }
                    ctx.report(
                        TypeCode::InferenceBudgetExceeded,
                        Severity::Warning,
                        *span,
                        format!(
                            "type inference budget of `{INFERENCE_DEPTH_LIMIT}` exceeded in `{name}`"
                        ),
                    );
                }
            }
        }
        // The knot: schemas only after every member's body is done.
        for &idx in &members {
            let (name, info) = &table.defines[idx];
            let schema = if table.is_assigned(name) {
                TypeSchema::mono(Type::Dyn)
            } else {
                match info {
                    DefineInfo::FnLiteral => {
                        let pre = pre_vars[idx].clone().unwrap_or(Type::Dyn);
                        ctx.generalize(&pre)
                    }
                    DefineInfo::Literal(v) => TypeSchema::mono(type_of_literal(v)),
                    DefineInfo::Other => {
                        TypeSchema::mono(sealed_tys[idx].clone().unwrap_or(Type::Dyn))
                    }
                }
            };
            schemas[idx] = Some(schema);
        }
    }

    // Final pass: resolve every annotation in place (late bindings —
    // call sites binding earlier defines' param vars — have all
    // landed by now).
    let mut typed = TypedProgram::default();
    for d in &flat {
        let ModuleItem::Define { name, span, .. } = d.item else {
            unreachable!("flatten yields defines");
        };
        let idx = d.index;
        let Some(r) = results[idx].take() else {
            continue; // Budget-skipped.
        };
        let schema = schemas[idx]
            .clone()
            .unwrap_or_else(|| TypeSchema::mono(Type::Dyn));
        let mut node = r.node;
        resolve_annotations(&ctx, &mut node);
        typed.defines.push(TypedDefine {
            span: *span,
            name: name.clone(),
            schema,
            body: node,
            effects: r.effects,
        });
    }

    InferOutcome {
        typed,
        diagnostics: ctx.diagnostics,
    }
}

/// Collect every `Var` name in an expression (over-approximating
/// the call graph — local names simply widen SCCs). Entries are pool
/// identities (§9.68 CHK-5): the tree already holds the `Symbol`.
fn collect_var_names(expr: &CoreExpr, out: &mut Vec<Symbol>) {
    let mut stack = vec![expr];
    while let Some(e) = stack.pop() {
        match e {
            CoreExpr::Var { name, .. } => {
                if !out.contains(name) {
                    out.push(name.clone());
                }
            }
            CoreExpr::Fn { body, .. } => stack.push(body),
            CoreExpr::Apply { func, args, .. } => {
                stack.push(func);
                for a in args {
                    stack.push(a);
                }
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                stack.push(cond);
                stack.push(then_branch);
                stack.push(else_branch);
            }
            CoreExpr::Assign { value, .. } => stack.push(value),
            CoreExpr::Let { bindings, body, .. } => {
                for b in bindings {
                    stack.push(&b.value);
                }
                stack.push(body);
            }
            CoreExpr::Perform { args, .. } => {
                for a in args {
                    stack.push(a);
                }
            }
            CoreExpr::Handle { body, handlers, .. } => {
                stack.push(body);
                for h in handlers {
                    stack.push(&h.handler);
                }
            }
            CoreExpr::Literal { .. } => {}
        }
    }
}

/// Iterative Tarjan SCC. Emits SCCs with dependencies first (each
/// SCC is completed after every SCC it can reach).
fn tarjan_sccs(n: usize, edges: &[Vec<usize>]) -> Vec<Vec<usize>> {
    let mut index: Vec<Option<usize>> = vec![None; n];
    let mut low = vec![0usize; n];
    let mut on_stack = vec![false; n];
    let mut next = vec![0usize; n];
    let mut stack: Vec<usize> = Vec::new();
    let mut counter = 0usize;
    let mut sccs: Vec<Vec<usize>> = Vec::new();

    for root in 0..n {
        if index[root].is_some() {
            continue;
        }
        let mut work = vec![root];
        while let Some(&v) = work.last() {
            if index[v].is_none() {
                index[v] = Some(counter);
                low[v] = counter;
                counter += 1;
                stack.push(v);
                on_stack[v] = true;
            }
            let mut descended = false;
            while next[v] < edges[v].len() {
                let w = edges[v][next[v]];
                next[v] += 1;
                if index[w].is_none() {
                    work.push(w);
                    descended = true;
                    break;
                }
                if on_stack[w] {
                    low[v] = low[v].min(index[w].expect("indexed"));
                }
            }
            if descended {
                continue;
            }
            work.pop();
            if let Some(&parent) = work.last() {
                low[parent] = low[parent].min(low[v]);
            }
            if low[v] == index[v].expect("indexed") {
                let mut scc = Vec::new();
                while let Some(w) = stack.pop() {
                    on_stack[w] = false;
                    scc.push(w);
                    if w == v {
                        break;
                    }
                }
                sccs.push(scc);
            }
        }
    }
    sccs
}

/// One flattened define with its table index (the order matches
/// `collect_info` exactly — index alignment).
struct FlatDefine<'i> {
    index: usize,
    item: &'i ModuleItem,
}

fn flatten_defines(items: &[ModuleItem]) -> Vec<FlatDefine<'_>> {
    let mut out = Vec::new();
    flatten_into(items, &mut out);
    out
}

fn flatten_into<'i>(items: &'i [ModuleItem], out: &mut Vec<FlatDefine<'i>>) {
    for item in items {
        match item {
            ModuleItem::Define { .. } => {
                let index = out.len();
                out.push(FlatDefine { index, item });
            }
            ModuleItem::Module { items, .. } => flatten_into(items, out),
            ModuleItem::Require { .. } | ModuleItem::DefineSyntax { .. } => {}
        }
    }
}

/// Resolve every annotation in the tree in place (iterative walk —
/// the A6 discipline).
fn resolve_annotations(ctx: &Ctx, node: &mut TypedExpr) {
    let mut stack: Vec<&mut TypedExpr> = vec![node];
    while let Some(n) = stack.pop() {
        match n {
            TypedExpr::Fn { body, ty, .. } => {
                *ty = ctx.resolve(ty);
                stack.push(body);
            }
            TypedExpr::Apply { func, args, ty, .. } => {
                *ty = ctx.resolve(ty);
                stack.push(func);
                for a in args.iter_mut() {
                    stack.push(a);
                }
            }
            TypedExpr::If {
                cond,
                then_branch,
                else_branch,
                ty,
                ..
            } => {
                *ty = ctx.resolve(ty);
                stack.push(cond);
                stack.push(then_branch);
                stack.push(else_branch);
            }
            TypedExpr::Var { ty, .. } => *ty = ctx.resolve(ty),
            TypedExpr::Literal { ty, .. } => *ty = ctx.resolve(ty),
            TypedExpr::Assign { value, ty, .. } => {
                *ty = ctx.resolve(ty);
                stack.push(value);
            }
            TypedExpr::Let {
                bindings, body, ty, ..
            } => {
                *ty = ctx.resolve(ty);
                for b in bindings.iter_mut() {
                    b.ty = ctx.resolve(&b.ty);
                    stack.push(&mut b.value);
                }
                stack.push(body);
            }
            TypedExpr::Perform { args, ty, .. } => {
                *ty = ctx.resolve(ty);
                for a in args.iter_mut() {
                    stack.push(a);
                }
            }
            TypedExpr::Handle {
                body, handlers, ty, ..
            } => {
                *ty = ctx.resolve(ty);
                stack.push(body);
                for h in handlers.iter_mut() {
                    h.ty = ctx.resolve(&h.ty);
                    stack.push(&mut h.handler);
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    //! Engine-core tests: the link table + undo log, unification,
    //! occurs, deep resolve, literal caps, generalization and
    //! instantiation. Source-level end-to-end behavior lives in the
    //! root integration family (hm-inference.md FP1-FP8).

    use super::*;

    fn ctx() -> Ctx<'static> {
        static EMPTY: Externals = Externals::empty();
        Ctx {
            links: Links::default(),
            externals: &EMPTY,
            diagnostics: Vec::new(),
            bool_demanded: Vec::new(),
        }
    }

    #[test]
    fn links_bind_and_rollback_restores_previous_state() {
        let mut c = ctx();
        let a = c.links.fresh();
        let b = c.links.fresh();
        let mark = c.links.mark();
        assert_eq!(a, Type::Var(0));
        c.links.bind(0, Type::Int);
        assert_eq!(c.resolve_shallow(a.clone()), Type::Int);
        c.links.bind(1, Type::Bool);
        c.links.rollback(mark);
        assert_eq!(c.resolve_shallow(a.clone()), Type::Var(0));
        assert_eq!(c.resolve_shallow(b.clone()), Type::Var(1));
    }

    #[test]
    fn unify_concrete_pairs() {
        let mut c = ctx();
        assert!(c.unify(&Type::Int, &Type::Int).is_ok());
        assert!(c.unify(&Type::Int, &Type::Bool).is_err());
        assert!(c.unify(&Type::Str, &Type::Str).is_ok());
        let p1 = Type::Pair(Box::new(Type::Int), Box::new(Type::Bool));
        let p2 = Type::Pair(Box::new(Type::Int), Box::new(Type::Bool));
        assert!(c.unify(&p1, &p2).is_ok());
        let p3 = Type::Pair(Box::new(Type::Int), Box::new(Type::Int));
        assert!(c.unify(&p1, &p3).is_err());
    }

    #[test]
    fn unify_binds_vars_in_either_direction() {
        let mut c = ctx();
        let a = c.links.fresh();
        assert!(c.unify(&a, &Type::Int).is_ok());
        assert_eq!(c.resolve_shallow(a.clone()), Type::Int);
        let b = c.links.fresh();
        assert!(c.unify(&Type::Bool, &b).is_ok());
        assert_eq!(c.resolve_shallow(b), Type::Bool);
    }

    #[test]
    fn dyn_absorbs_everything_without_binding() {
        let mut c = ctx();
        let a = c.links.fresh();
        assert!(c.unify(&a, &Type::Dyn).is_ok());
        // Dyn never constrains: the var stays free for later.
        assert_eq!(c.resolve_shallow(a.clone()), a);
        assert!(c.unify(&a, &Type::Int).is_ok());
        assert_eq!(c.resolve_shallow(a), Type::Int);
    }

    #[test]
    fn unify_arrows_structurally() {
        let mut c = ctx();
        let f = Type::Arrow {
            params: vec![Type::Int],
            ret: Box::new(Type::Bool),
        };
        let g = Type::Arrow {
            params: vec![Type::Int],
            ret: Box::new(Type::Bool),
        };
        assert!(c.unify(&f, &g).is_ok());
        let h = Type::Arrow {
            params: vec![Type::Bool],
            ret: Box::new(Type::Bool),
        };
        assert!(c.unify(&f, &h).is_err());
    }

    #[test]
    fn occurs_check_rejects_cycles() {
        let mut c = ctx();
        let a = c.links.fresh(); // t0
        let self_ref = Type::Arrow {
            params: vec![a.clone()],
            ret: Box::new(Type::Int),
        };
        match c.unify(&a, &self_ref) {
            Err(UnifyErr::Recursive { var, .. }) => assert_eq!(var, 0),
            other => panic!("expected recursive, got {other:?}"),
        }
    }

    #[test]
    fn resolve_follows_link_chains_deeply() {
        let mut c = ctx();
        let a = c.links.fresh(); // t0
        let b = c.links.fresh(); // t1
        c.links
            .bind(0, Type::Pair(Box::new(b.clone()), Box::new(Type::Int)));
        c.links.bind(1, Type::Bool);
        assert_eq!(
            c.resolve(&a),
            Type::Pair(Box::new(Type::Bool), Box::new(Type::Int))
        );
    }

    #[test]
    fn literal_types_map_ground_kinds() {
        assert_eq!(type_of_literal(&LiteralValue::Int(3)), Type::Int);
        assert_eq!(type_of_literal(&LiteralValue::Float(1.5)), Type::Float);
        assert_eq!(type_of_literal(&LiteralValue::Bool(true)), Type::Bool);
        assert_eq!(
            type_of_literal(&LiteralValue::String("s".into())),
            Type::Str
        );
        assert_eq!(type_of_literal(&LiteralValue::Nil), Type::Nil);
    }

    #[test]
    fn deep_literal_chains_collapse_the_tail_to_dyn() {
        // A pair chain deeper than the cap keeps the first levels
        // and collapses the rest to Dyn (sound: unknown).
        let mut chain = LiteralValue::Nil;
        for i in 0..(LITERAL_TYPE_DEPTH + 8) {
            chain = LiteralValue::Pair(Box::new(LiteralValue::Int(i as i64)), Box::new(chain));
        }
        let ty = type_of_literal(&chain);
        // Walk down LITERAL_TYPE_DEPTH levels: the tail is Dyn.
        let mut cur = ty;
        for _ in 0..(LITERAL_TYPE_DEPTH - 1) {
            match cur {
                Type::Pair(_, cdr) => cur = *cdr,
                other => panic!("pair chain expected, got {other}"),
            }
        }
        assert_eq!(cur, Type::Pair(Box::new(Type::Int), Box::new(Type::Dyn)));
    }

    #[test]
    fn join_equal_keeps_type_else_dyn() {
        assert_eq!(join(&Type::Int, &Type::Int), Type::Int);
        assert_eq!(join(&Type::Int, &Type::Bool), Type::Dyn);
        assert_eq!(join(&Type::Dyn, &Type::Dyn), Type::Dyn);
    }

    #[test]
    fn generalize_quantifies_free_vars_in_first_seen_order() {
        let mut c = ctx();
        let a = c.links.fresh(); // t0
        let b = c.links.fresh(); // t1
        c.links.bind(1, Type::Int); // t1 fixed; t0 stays free.
        let t = Type::Arrow {
            params: vec![a.clone()],
            ret: Box::new(b.clone()),
        };
        let s = c.generalize(&t);
        assert_eq!(s.vars, vec![0]);
        assert_eq!(
            s.body,
            Type::Arrow {
                params: vec![Type::Var(0)],
                ret: Box::new(Type::Int),
            }
        );
    }

    #[test]
    fn instantiate_replaces_quantified_with_fresh() {
        let mut c = ctx();
        let a = c.links.fresh(); // t0
        let s = TypeSchema {
            vars: vec![0],
            body: Type::Arrow {
                params: vec![a],
                ret: Box::new(Type::Var(0)),
            },
        };
        let out = c.instantiate(&s);
        // t0 -> t1 (fresh), and both occurrences map to the same t1.
        assert_eq!(
            out,
            Type::Arrow {
                params: vec![Type::Var(1)],
                ret: Box::new(Type::Var(1)),
            }
        );
    }

    #[test]
    fn is_numeric_three_valued() {
        assert_eq!(is_numeric(&Type::Int), Some(true));
        assert_eq!(is_numeric(&Type::Float), Some(true));
        assert_eq!(is_numeric(&Type::Bool), Some(false));
        assert_eq!(is_numeric(&Type::Dyn), None);
        assert_eq!(is_numeric(&Type::Var(7)), None);
    }

    // ---------- single-pool identity (§9.68 CHK-3/CHK-4/CHK-5) ----------

    #[test]
    fn define_table_env_and_scc_refs_ride_the_single_pool() {
        // The inference-side work state holds pool identities, not
        // text copies (the check.rs mirror discipline): an
        // independently interned Symbol of the same text IS the
        // table key; duplicate assigns land as one HashSet member;
        // the SCC over-approximation collects Var names as pool
        // entries (the §9.52 single-pool invariant pinned on the
        // inference work state).
        use kerf_span::{ByteOffset, ExpansionId, FileId};
        let sp = |a: u32, b: u32| {
            Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
                .expect("test span is ordered")
        };
        let int = |v: i64| CoreExpr::Literal {
            span: sp(1, 3),
            value: LiteralValue::Int(v),
        };
        let items = vec![
            ModuleItem::define(
                sp(0, 10),
                "g",
                CoreExpr::fn_(
                    sp(1, 8),
                    &["x"],
                    CoreExpr::var(sp(2, 4), "x").expect("valid"),
                )
                .expect("valid fn"),
            )
            .expect("valid define"),
            ModuleItem::define(
                sp(0, 10),
                "z",
                CoreExpr::assign(sp(4, 6), "g", int(1)).expect("valid assign"),
            )
            .expect("valid define"),
            ModuleItem::define(
                sp(0, 10),
                "w",
                CoreExpr::assign(sp(4, 6), "g", int(2)).expect("valid assign"),
            )
            .expect("valid define"),
        ];
        let mut table = DefineTable::default();
        collect_info(&items, &mut table);
        let g = Symbol::new("g").expect("valid name");
        assert!(
            table.defines.iter().any(|(n, _)| *n == g),
            "define rows key on pool identities"
        );
        assert!(table.is_assigned(&g));
        // The assign guard set dedups: two assigns to `g`, one
        // member (the CHK-3 HashSet unification — the manual
        // scan-then-push of the Vec form is gone).
        assert_eq!(table.assigned.len(), 1);
        // Walk order mirrors check.rs `collect_items` (the mirror
        // discipline): rows land in module order.
        assert_eq!(table.defines.len(), 3);
        assert_eq!(table.defines[0].0.as_str(), "g");
        // The SCC face (CHK-5): collect_var_names pushes pool
        // identities — an independent intern of the same text is
        // the collected entry.
        let call = CoreExpr::Apply {
            span: sp(2, 9),
            func: Box::new(CoreExpr::var(sp(3, 4), "g").expect("valid")),
            args: vec![int(1)],
        };
        let mut refs = Vec::new();
        collect_var_names(&call, &mut refs);
        assert_eq!(refs.len(), 1);
        assert_eq!(refs[0], g);
    }

    // ---------- INF-1: transactional unify contract (§9.77) ----------

    #[test]
    fn unify_failure_rolls_back_partial_bindings() {
        // A composite-vs-composite mismatch binds the leading pairs
        // before failing on the trailing one — the transactional
        // contract must restore the entry state (no leak).
        let mut c = ctx();
        let v0 = c.links.fresh(); // Var(0)
        let mark = c.links.mark();
        let expected = Type::Pair(Box::new(v0.clone()), Box::new(Type::Int));
        let found = Type::Pair(Box::new(Type::Bool), Box::new(Type::Bool));
        let err = c
            .unify(&expected, &found)
            .expect_err("trailing Int vs Bool must fail");
        assert!(matches!(err, UnifyErr::Mismatch { .. }));
        // The leading binding (Var0 = Bool) must have been rolled back.
        assert_eq!(c.resolve_shallow(v0.clone()), Type::Var(0));
        // And the undo log is back at the entry mark.
        assert_eq!(c.links.mark(), mark);
    }

    #[test]
    fn unify_recursive_failure_leaves_no_bindings() {
        // The occurs failure path never reaches `bind` by construction
        // (occurs precedes bind); the transactional wrapper pins that
        // the whole-call contract holds there too.
        let mut c = ctx();
        let v0 = c.links.fresh();
        let t = Type::Pair(Box::new(v0.clone()), Box::new(Type::Int));
        let err = c.unify(&v0, &t).expect_err("occurs must reject");
        assert!(matches!(err, UnifyErr::Recursive { .. }));
        assert_eq!(c.resolve_shallow(v0), Type::Var(0));
    }

    #[test]
    fn unify_failure_is_repeatable_after_rollback() {
        // After a rolled-back failure the engine state is clean, so
        // the same unify fails the same way again (determinism of the
        // transactional boundary — no half-state residue).
        let mut c = ctx();
        let a = c.links.fresh();
        let b = c.links.fresh();
        let lhs = Type::Pair(Box::new(a), Box::new(Type::Int));
        let rhs = Type::Pair(Box::new(b), Box::new(Type::Bool));
        let e1 = c.unify(&lhs, &rhs).expect_err("must fail");
        let e2 = c
            .unify(&lhs, &rhs)
            .expect_err("must fail again identically");
        assert_eq!(e1, e2);
        // Neither side's var was bound by either attempt.
        assert_eq!(c.resolve_shallow(Type::Var(0)), Type::Var(0));
        assert_eq!(c.resolve_shallow(Type::Var(1)), Type::Var(1));
    }

    // ---------- INF-2: acyclicity fixpoint guard (§9.77) ----------

    #[test]
    fn resolve_shallow_is_fixpoint_over_pseudo_random_unify_sequences() {
        // Deterministic pseudo-random driver (an LCG — no dev-dep):
        // interleave `fresh` with random small-type unifications and
        // assert, after every operation, that every var's chain ends
        // at a fixpoint (`resolve_shallow(r) == r`). On an acyclic
        // table every endpoint is an unbound var or a concrete type;
        // a cycle (a bind that bypassed the occurs guard) would make
        // the walk break at the hop cap mid-cycle, where the returned
        // var still has a link — the fixpoint assertion catches it.
        let mut c = ctx();
        let mut state: u64 = 0x9E3779B97F4A7C15; // fixed seed: reproducible
        let mut next = move || {
            state = state
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            state
        };

        fn rand_type(rng: &mut impl FnMut() -> u64, c: &Ctx, depth: u32) -> Type {
            let n_vars = c.links.slots.len() as u64;
            let pick = rng() % 10;
            if depth == 0 || pick < 4 {
                match pick % 7 {
                    0 => Type::Int,
                    1 => Type::Bool,
                    2 => Type::Str,
                    3 => Type::Nil,
                    4 => Type::Float,
                    5 => Type::Dyn,
                    _ => {
                        if n_vars == 0 {
                            Type::Int
                        } else {
                            Type::Var((rng() % n_vars) as u32)
                        }
                    }
                }
            } else if pick < 7 {
                Type::Pair(
                    Box::new(rand_type(rng, c, depth - 1)),
                    Box::new(rand_type(rng, c, depth - 1)),
                )
            } else {
                let n_params = (rng() % 2 + 1) as usize;
                Type::Arrow {
                    params: (0..n_params)
                        .map(|_| rand_type(rng, c, depth - 1))
                        .collect(),
                    ret: Box::new(rand_type(rng, c, depth - 1)),
                }
            }
        }

        for _ in 0..400 {
            // Grow the table periodically (25% of iterations).
            if next() % 4 == 0 {
                c.links.fresh();
            }
            let a = rand_type(&mut next, &c, 2);
            let b = rand_type(&mut next, &c, 2);
            let _ = c.unify(&a, &b);
            // The fixpoint oracle over the whole table.
            for v in 0..(c.links.slots.len() as u32) {
                let end = c.resolve_shallow(Type::Var(v));
                assert_eq!(
                    c.resolve_shallow(end.clone()),
                    end,
                    "chain from t{v} is not at a fixpoint — a cycle bypassed the occurs guard"
                );
            }
        }
        // The driver really exercised the engine (not a vacuous loop).
        assert!(c.links.slots.len() >= 100, "expected a grown table");
    }
}

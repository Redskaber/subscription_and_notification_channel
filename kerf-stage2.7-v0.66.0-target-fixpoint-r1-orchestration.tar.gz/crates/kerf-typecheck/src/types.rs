//! The inference type language — the Layer 2 annotation face
//! (stage0.md §9.44.4; stage-1-plan §2 row 1.3).
//!
//! The type lattice is deliberately minimal: the five ground kinds
//! mirror the runtime `Value` kinds (single-source naming — `Display`
//! matches `Value::kind_name` strings), `Pair`/`Arrow` are structural,
//! `Dyn` is the one-way unknown top, and `Var` is a union-find
//! metavariable. There is no user-facing type syntax anywhere: types
//! exist only inside the checker and its annotations (zero new
//! kernel primitives, zero new syntax — the frozen-kernel invariant).
//!
//! Determinism: every constructor here is order-stable (no hashing,
//! no iteration over unordered sets) so snapshot goldens are
//! reproducible run over run.

use kerf_span::Symbol;

/// One inferred type over the frozen eight-primitive kernel.
#[derive(Debug, Clone, PartialEq)]
pub enum Type {
    /// `i64` integers (checked arithmetic at runtime).
    Int,
    /// IEEE-754 floats.
    Float,
    /// Booleans (the only truthy kind — `truthy` rejects the rest).
    Bool,
    /// Strings.
    Str,
    /// The unit/empty-list literal.
    Nil,
    /// A heap pair of two component types.
    Pair(Box<Type>, Box<Type>),
    /// A function type: fixed parameter list, one return type.
    /// Effects are *not* part of the arrow in the 1.3 base — the
    /// effect face is the [`EffectRow`] collection annotation
    /// (row polymorphism is the Stage 2+ TY-C window, stage0.md
    /// §9.44.4 point 4).
    Arrow { params: Vec<Type>, ret: Box<Type> },
    /// The one-way unknown top: the join of dynamically-legal
    /// branches, any unresolved flow, and budget-skipped subtrees.
    /// `Dyn` unifies with everything and never constrains — it is
    /// *not* a user-writable `any` (there is no type syntax); it
    /// exists so the conservative discipline holds: a legal program
    /// never gets a diagnostic (stage0.md §9.44.4 point 1).
    Dyn,
    /// An inference metavariable — an index into the engine's
    /// link table (`infer::Ctx`). Display renders as `t{n}`.
    Var(u32),
}

impl Type {
    /// Whether this is a metavariable (unresolved or not — the
    /// engine resolves through links before asking).
    pub fn is_var(&self) -> bool {
        matches!(self, Type::Var(_))
    }

    /// Collect every `Var` occurrence structurally (iterative walk —
    /// A6 discipline; duplicates preserved in first-seen order so
    /// generalization quantifies deterministically).
    pub fn var_occurrences(&self, out: &mut Vec<u32>) {
        let mut stack = vec![self];
        while let Some(t) = stack.pop() {
            match t {
                Type::Var(i) => out.push(*i),
                Type::Pair(a, b) => {
                    stack.push(b);
                    stack.push(a);
                }
                Type::Arrow { params, ret } => {
                    // Pop order: params left-to-right, then the ret —
                    // push in reverse.
                    stack.push(ret.as_ref());
                    for p in params.iter().rev() {
                        stack.push(p);
                    }
                }
                _ => {}
            }
        }
    }
}

impl std::fmt::Display for Type {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Type::Int => f.write_str("int"),
            Type::Float => f.write_str("float"),
            Type::Bool => f.write_str("bool"),
            Type::Str => f.write_str("str"),
            Type::Nil => f.write_str("nil"),
            Type::Dyn => f.write_str("dyn"),
            Type::Var(i) => write!(f, "t{i}"),
            Type::Pair(a, b) => write!(f, "(pair {a} {b})"),
            Type::Arrow { params, ret } => {
                let ps: Vec<String> = params.iter().map(|p| p.to_string()).collect();
                write!(f, "(fn ({}) {ret})", ps.join(" "))
            }
        }
    }
}

/// A generalized (rank-1 quantified) type — what a polymorphic
/// `define` or `let` binding carries.
///
/// `vars` lists the quantified metavariable indices (deterministic
/// first-seen order). `Display` α-renames them positionally (`t0`,
/// `t1`, …) so annotations stay stable regardless of the engine's
/// global counter state.
#[derive(Debug, Clone, PartialEq)]
pub struct TypeSchema {
    pub vars: Vec<u32>,
    pub body: Type,
}

impl TypeSchema {
    /// A monomorphic schema (nothing quantified).
    pub fn mono(body: Type) -> Self {
        Self {
            vars: Vec::new(),
            body,
        }
    }

    /// Render with positional α-renaming of the quantified vars.
    pub fn render(&self) -> String {
        if self.vars.is_empty() {
            return self.body.to_string();
        }
        let rename = |t: &Type| -> Type {
            // Substitute each quantified var index with a positional
            // marker var (index = its position in `vars`) — display
            // only, never stored.
            substitute(t, &self.vars, &positional_marks(self.vars.len()))
        };
        format!(
            "(forall ({}) {})",
            var_names(self.vars.len()),
            rename(&self.body)
        )
    }
}

fn var_names(n: usize) -> String {
    (0..n)
        .map(|i| format!("t{i}"))
        .collect::<Vec<_>>()
        .join(" ")
}

fn positional_marks(n: usize) -> Vec<Type> {
    (0..n as u32).map(Type::Var).collect()
}

/// Replace occurrences of `vars[i]` with `repl[i]` (iterative
/// rebuild — the same two-slot machine shape `infer::Ctx::resolve`
/// uses; shared by schema rendering and instantiation).
pub(crate) fn substitute(t: &Type, vars: &[u32], repl: &[Type]) -> Type {
    debug_assert_eq!(vars.len(), repl.len());
    enum Item<'a> {
        Visit(&'a Type),
        Pair,
        Arrow(usize),
    }
    let mut stack = vec![Item::Visit(t)];
    let mut done: Vec<Type> = Vec::new();
    while let Some(item) = stack.pop() {
        match item {
            Item::Visit(t) => match t {
                Type::Var(i) => match vars.iter().position(|v| v == i) {
                    Some(pos) => done.push(repl[pos].clone()),
                    None => done.push(Type::Var(*i)),
                },
                leaf @ (Type::Int
                | Type::Float
                | Type::Bool
                | Type::Str
                | Type::Nil
                | Type::Dyn) => done.push(leaf.clone()),
                Type::Pair(a, b) => {
                    stack.push(Item::Pair);
                    stack.push(Item::Visit(b));
                    stack.push(Item::Visit(a));
                }
                Type::Arrow { params, ret } => {
                    stack.push(Item::Arrow(params.len()));
                    stack.push(Item::Visit(ret));
                    for p in params.iter().rev() {
                        stack.push(Item::Visit(p));
                    }
                }
            },
            Item::Pair => {
                let b = done.pop().expect("pair cdr");
                let a = done.pop().expect("pair car");
                done.push(Type::Pair(Box::new(a), Box::new(b)));
            }
            Item::Arrow(n) => {
                let ret = done.pop().expect("arrow ret");
                let mut params = Vec::with_capacity(n);
                for _ in 0..n {
                    params.push(done.pop().expect("arrow param"));
                }
                params.reverse();
                done.push(Type::Arrow {
                    params,
                    ret: Box::new(ret),
                });
            }
        }
    }
    done.pop().expect("substitute produces one tree")
}

/// An effect row — the 1.3 *collection face* (stage0.md §9.44.4
/// point 4). An ordered, deduplicated list of effect names performed
/// during evaluation of the annotated node.
///
/// Boundaries (disclosed, stage-1-plan 1.3):
/// * `Perform` appends its own effect; `Handle` subtracts the effects
///   its clauses intercept (definite — the clauses install before the
///   body runs) and merges each handler body's row (over-approximate:
///   the handler may be invoked mid-body with no lexical cover);
/// * calls do **not** absorb the callee's row — per-function effect
///   signatures are row polymorphism, the Stage 2+ TY-C window.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct EffectRow {
    effects: Vec<Symbol>,
}

impl EffectRow {
    /// The empty row.
    pub fn empty() -> Self {
        Self::default()
    }

    /// A row holding exactly one effect.
    pub fn of(effect: Symbol) -> Self {
        Self {
            effects: vec![effect],
        }
    }

    /// Merge `other` in (ordered union, first-seen order kept).
    pub fn union(&mut self, other: &EffectRow) {
        for e in &other.effects {
            self.push(e.clone());
        }
    }

    /// Append one effect if not already present.
    pub fn push(&mut self, effect: Symbol) {
        if !self.effects.contains(&effect) {
            self.effects.push(effect);
        }
    }

    /// The row minus every named effect (Handle subtraction).
    pub fn without(&self, removed: &[&Symbol]) -> Self {
        Self {
            effects: self
                .effects
                .iter()
                .filter(|e| !removed.iter().any(|r| r == e))
                .cloned()
                .collect(),
        }
    }

    /// Whether nothing is performed.
    pub fn is_empty(&self) -> bool {
        self.effects.is_empty()
    }

    /// The ordered effect list.
    pub fn as_slice(&self) -> &[Symbol] {
        &self.effects
    }

    /// Render for annotations/dumps: space-joined names (empty when
    /// the row is empty).
    pub fn render(&self) -> String {
        self.effects
            .iter()
            .map(|e| e.as_str())
            .collect::<Vec<_>>()
            .join(" ")
    }
}

#[cfg(test)]
mod tests {
    //! Type-language face tests: display forms, occurrence walks,
    //! schema rendering with α-renaming, row algebra.

    use super::*;

    #[test]
    fn ground_types_render_as_runtime_kind_names() {
        // Single-source naming: these strings mirror Value::kind_name.
        assert_eq!(Type::Int.to_string(), "int");
        assert_eq!(Type::Float.to_string(), "float");
        assert_eq!(Type::Bool.to_string(), "bool");
        assert_eq!(Type::Str.to_string(), "str");
        assert_eq!(Type::Nil.to_string(), "nil");
        assert_eq!(Type::Dyn.to_string(), "dyn");
    }

    #[test]
    fn structural_types_render_parenthesized() {
        let pair = Type::Pair(Box::new(Type::Int), Box::new(Type::Bool));
        assert_eq!(pair.to_string(), "(pair int bool)");
        let arrow = Type::Arrow {
            params: vec![Type::Int, Type::Int],
            ret: Box::new(Type::Int),
        };
        assert_eq!(arrow.to_string(), "(fn (int int) int)");
    }

    #[test]
    fn var_renders_with_its_index() {
        assert_eq!(Type::Var(0).to_string(), "t0");
        assert_eq!(Type::Var(41).to_string(), "t41");
    }

    #[test]
    fn var_occurrences_walks_structure_in_first_seen_order() {
        // (fn (t3 t1) (pair t1 t3)) — depth-first left-to-right order.
        let t = Type::Arrow {
            params: vec![Type::Var(3), Type::Var(1)],
            ret: Box::new(Type::Pair(Box::new(Type::Var(1)), Box::new(Type::Var(3)))),
        };
        let mut seen = Vec::new();
        t.var_occurrences(&mut seen);
        assert_eq!(seen, vec![3, 1, 1, 3]);
    }

    #[test]
    fn mono_schema_renders_bare_body() {
        let s = TypeSchema::mono(Type::Int);
        assert_eq!(s.render(), "int");
    }

    #[test]
    fn schema_render_alpha_renames_positionally() {
        // Quantified vars 7 and 2 render as t0/t1 by position.
        let s = TypeSchema {
            vars: vec![7, 2],
            body: Type::Arrow {
                params: vec![Type::Var(7)],
                ret: Box::new(Type::Var(2)),
            },
        };
        assert_eq!(s.render(), "(forall (t0 t1) (fn (t0) t1))");
    }

    #[test]
    fn substitute_remaps_only_listed_vars() {
        let t = Type::Arrow {
            params: vec![Type::Var(1), Type::Var(2)],
            ret: Box::new(Type::Var(9)),
        };
        let out = substitute(&t, &[1, 2], &[Type::Int, Type::Bool]);
        assert_eq!(
            out,
            Type::Arrow {
                params: vec![Type::Int, Type::Bool],
                ret: Box::new(Type::Var(9)),
            }
        );
    }

    #[test]
    fn row_union_keeps_first_seen_order_and_dedups() {
        let mut r = EffectRow::empty();
        r.push(Symbol::new("log").expect("symbol"));
        r.push(Symbol::new("read").expect("symbol"));
        r.push(Symbol::new("log").expect("symbol"));
        let mut other = EffectRow::empty();
        other.push(Symbol::new("write").expect("symbol"));
        other.push(Symbol::new("log").expect("symbol"));
        r.union(&other);
        assert_eq!(r.render(), "log read write");
    }

    #[test]
    fn row_without_subtracts_every_named_effect() {
        let mut r = EffectRow::empty();
        r.push(Symbol::new("log").expect("symbol"));
        r.push(Symbol::new("read").expect("symbol"));
        let log = Symbol::new("log").expect("symbol");
        let kept = r.without(&[&log]);
        assert_eq!(kept.render(), "read");
        assert_eq!(r.render(), "log read", "without is non-destructive");
    }
}

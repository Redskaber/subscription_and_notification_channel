//! Reserved effect-system face — docs/stage0.md §9.1.1 (P3 type shape).
//!
//! Frozen type shape only; no production implementation exists at
//! Stage 0 and none is owed before Stage 2 (the effect DSL window —
//! docs/stage0.md §9.4 matrix row "Effect Handlers"). The primitive
//! semantics of effects already live in the kernel: `CoreExpr::Perform`
//! and `CoreExpr::Handle` with the primitive-level
//! [`crate::HandlerClause`] arm.
//!
//! Vocabulary mapping (blueprint drift resolved in favor of the §9.1.1
//! sketch, plan-0.10.md ruling 18): the §9.3.1 summary names
//! "EffectKind / HandlerClause / Continuation" — the §9.1.1 sketch (the
//! authoritative reservation block) spells them as the associated types
//! `Effect` / `Handler` / `Continuation` below. The kernel-level
//! [`crate::HandlerClause`] stays the primitive arm; this face's
//! `Handler` associated type is the future system-level handler.

/// The operation face of a single effect kind.
///
/// Translation note (plan-0.10.md ruling 18): the blueprint sketch
/// spells the perform result as `Self::Effect::Result`; Rust resolves
/// that shape through a companion trait bound, carried here so the
/// frozen `perform` signature can name its result type.
pub trait EffectOp {
    /// What performing this effect kind yields.
    type Result;
}

/// The reserved effect-system face (blueprint §9.1.1, frozen at 0.10).
///
/// Stage 2 instantiates this with the language-level effect system;
/// until then the trait exists so that the shape — the associated
/// types and the two method signatures — cannot drift.
pub trait EffectSystem {
    /// The effect kinds this system can perform.
    type Effect: EffectOp;
    /// The system-level handler face that intercepts effects.
    type Handler;
    /// The continuation face a handler may resume (one-shot by the
    /// kernel discipline — SOP §21.12-12(3); the shape itself stays
    /// abstract here).
    type Continuation;
    /// The language value carried by computations. Deliberately an
    /// associated type, not the VM value type: the reservation face
    /// takes zero inbound edges beyond `std` (SOP §21.12-10(2)).
    type Value;

    /// Perform an effect, yielding the effect kind's result.
    fn perform(&self, effect: Self::Effect) -> <Self::Effect as EffectOp>::Result;

    /// Run `computation` under `handler`, intercepting the effects it
    /// performs.
    fn handle(
        &self,
        handler: Self::Handler,
        computation: impl FnOnce() -> Self::Value,
    ) -> Self::Value;
}

#[cfg(test)]
mod tests {
    //! Signature-stability witness + shape probes for the effect face
    //! (docs/tests/v0/stage0/plan/reserved.md FP1).

    use super::*;
    use std::cell::Cell;

    /// Canonical conforming implementor — the signature-stability
    /// snapshot. Any drift in the frozen trait shape breaks this
    /// witness at compile time.
    struct CountingEffects {
        ops: Cell<u32>,
    }

    enum CountEffect {
        Tick,
    }

    impl EffectOp for CountEffect {
        type Result = u32;
    }

    struct CountHandler {
        bonus: u32,
    }

    struct NoResume;

    impl EffectSystem for CountingEffects {
        type Effect = CountEffect;
        type Handler = CountHandler;
        type Continuation = NoResume;
        type Value = u32;

        fn perform(&self, effect: CountEffect) -> u32 {
            match effect {
                CountEffect::Tick => {
                    let next = self.ops.get() + 1;
                    self.ops.set(next);
                    next
                }
            }
        }

        fn handle(&self, handler: CountHandler, computation: impl FnOnce() -> u32) -> u32 {
            computation() + handler.bonus
        }
    }

    /// Compile-level type-equality pin: `assert_same(&a, &b)` compiles
    /// only when `a` and `b` share one type.
    fn assert_same<T>(_: &T, _: &T) {}

    #[test]
    fn witness_perform_routes_through_effect_op_result() {
        let system = CountingEffects { ops: Cell::new(0) };
        let result = system.perform(CountEffect::Tick);
        // The frozen signature resolves through `EffectOp::Result`.
        assert_same(&result, &0u32);
        assert_eq!(result, 1, "first tick observes one prior op");
    }

    #[test]
    fn witness_perform_accumulates_state_across_calls() {
        // The `&self` receiver threading: repeated performs observe
        // the accumulated system state.
        let system = CountingEffects { ops: Cell::new(0) };
        assert_eq!(system.perform(CountEffect::Tick), 1);
        assert_eq!(system.perform(CountEffect::Tick), 2);
        assert_eq!(system.perform(CountEffect::Tick), 3);
    }

    #[test]
    fn witness_handle_composes_the_value_path() {
        let system = CountingEffects { ops: Cell::new(0) };
        let value = system.handle(CountHandler { bonus: 10 }, || 32);
        assert_eq!(value, 42, "handler modifier applies to the computation");
    }

    #[test]
    fn witness_handle_accepts_capturing_closures() {
        // The `impl FnOnce() -> Self::Value` bound must accept closures
        // that capture their environment — part of the frozen shape.
        let system = CountingEffects { ops: Cell::new(0) };
        let captured = 40;
        let value = system.handle(CountHandler { bonus: 2 }, || captured);
        assert_eq!(value, 42, "capturing closure flows through handle");
    }

    #[test]
    fn perform_result_type_is_pinned_to_the_associated_type() {
        // Nameability of the frozen associated-type path itself.
        type WitnessResult = <CountEffect as EffectOp>::Result;
        let r: WitnessResult = 7;
        assert_same(&r, &7u32);
    }

    #[test]
    fn continuation_shape_is_nameable_through_the_system() {
        // The `Continuation` associated type is reachable through the
        // system type — part of the frozen shape.
        let maybe: Option<<CountingEffects as EffectSystem>::Continuation> = None;
        assert!(maybe.is_none(), "continuation slot is nameable and usable");
    }
}

//! Reserved compilation-cache face — docs/stage0.md §9.1.4 (P2: trait
//! signatures + behavior spec).
//!
//! The blueprint freezes three methods over a content-addressed key and
//! an opaque result. Stage 1 implements the in-memory content-addressed
//! cache (docs/stage0.md §9.4 matrix row "compilation cache");
//! the known follow-on needs (cross-session persistence, distributed
//! caches — §9.3.1) motivated the *serializable* opaque-payload shape:
//! [`CachedResult`] carries bytes, not a typed compiler product, so the
//! frozen face never pins a product type (SOP §21.12-10(2)).
//!
//! The behavior spec is executable: [`check_compilation_cache_contract`]
//! runs the six contract probes every implementation must satisfy, and
//! Stage 1 implementations reuse it directly as their contract tests.

/// A content-addressed cache key.
///
/// The digest width matches the common 256-bit content-hash family;
/// the hashing algorithm itself is an implementation detail of the
/// Stage 1 cache, not of this frozen key type.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct CacheKey {
    digest: [u8; 32],
}

impl CacheKey {
    /// Build a key from a digest.
    pub fn from_digest(digest: [u8; 32]) -> Self {
        CacheKey { digest }
    }

    /// The content digest.
    pub fn digest(&self) -> &[u8; 32] {
        &self.digest
    }
}

/// An opaque cached result.
///
/// Payload bytes by design: the value shape stays out of the frozen
/// face so product-type evolution never breaks the cache contract.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CachedResult {
    payload: Vec<u8>,
}

impl CachedResult {
    /// Wrap a payload.
    pub fn new(payload: Vec<u8>) -> Self {
        CachedResult { payload }
    }

    /// Borrow the payload.
    pub fn as_payload(&self) -> &[u8] {
        &self.payload
    }

    /// Unwrap the payload.
    pub fn into_payload(self) -> Vec<u8> {
        self.payload
    }
}

/// The reserved compilation-cache face (blueprint §9.1.4, frozen at
/// 0.10).
pub trait CompilationCache {
    /// Fetch the cached result for `key`, if present.
    fn get_cached(&self, key: CacheKey) -> Option<CachedResult>;
    /// Store `result` under `key` (latest store wins).
    fn store(&mut self, key: CacheKey, result: CachedResult);
    /// Remove the entry for `key`, if present (a no-op on missing
    /// keys).
    fn invalidate(&mut self, key: CacheKey);
}

/// A test key with a one-byte tag in the digest (probe-local helper).
fn probe_key(tag: u8) -> CacheKey {
    let mut digest = [0u8; 32];
    digest[0] = tag;
    CacheKey::from_digest(digest)
}

/// The executable behavior spec of [`CompilationCache`] (P2 — the
/// behavior spec made runnable).
///
/// Runs all six contract probes against `cache` and panics on the
/// first violation. Any Stage 1 implementation must pass this kit;
/// the panic messages name the violated contract so failures route
/// directly to the broken probe.
///
/// # Contracts
///
/// 1. store-then-get hits, with value equality (payload round-trip)
/// 2. get on a never-stored key misses (`None`)
/// 3. get after invalidate misses (`None`)
/// 4. invalidate on a missing key is a no-op (must not panic)
/// 5. a second store under the same key overwrites (latest wins)
/// 6. stores do not leak across keys (isolation)
pub fn check_compilation_cache_contract<C: CompilationCache>(cache: &mut C) {
    // Contract 1: store-then-get hits with value equality.
    cache.store(probe_key(1), CachedResult::new(vec![1, 2, 3]));
    let hit = cache
        .get_cached(probe_key(1))
        .expect("cache contract: store-then-get must hit");
    assert_eq!(
        hit,
        CachedResult::new(vec![1, 2, 3]),
        "cache contract: the stored result must round-trip equal"
    );

    // Contract 2: a never-stored key misses.
    assert!(
        cache.get_cached(probe_key(2)).is_none(),
        "cache contract: get on a never-stored key must miss"
    );

    // Contract 5: latest store wins.
    cache.store(probe_key(1), CachedResult::new(vec![9]));
    let overwritten = cache
        .get_cached(probe_key(1))
        .expect("cache contract: get after re-store must hit");
    assert_eq!(
        overwritten,
        CachedResult::new(vec![9]),
        "cache contract: re-store must overwrite (latest wins)"
    );

    // Contract 6: no leakage across keys.
    cache.store(probe_key(3), CachedResult::new(vec![7, 7]));
    let other = cache
        .get_cached(probe_key(3))
        .expect("cache contract: the second stored key must hit");
    assert_eq!(
        other,
        CachedResult::new(vec![7, 7]),
        "cache contract: the second key must hold its own result"
    );
    assert_eq!(
        cache.get_cached(probe_key(1)),
        Some(CachedResult::new(vec![9])),
        "cache contract: stores must not leak across keys"
    );

    // Contract 3: invalidate removes.
    cache.invalidate(probe_key(1));
    assert!(
        cache.get_cached(probe_key(1)).is_none(),
        "cache contract: get after invalidate must miss"
    );

    // Contract 4: invalidate on a missing key is a no-op (this call
    // itself is the probe — a panic here fails the kit).
    cache.invalidate(probe_key(1));
    cache.invalidate(probe_key(0xEE));

    // Post-invalidate re-store recovers the entry.
    cache.store(probe_key(1), CachedResult::new(vec![5]));
    assert_eq!(
        cache.get_cached(probe_key(1)),
        Some(CachedResult::new(vec![5])),
        "cache contract: re-store after invalidate must hit again"
    );
}

#[cfg(test)]
mod tests {
    //! Key/result shape probes + contract-kit runs, including broken
    //! implementations the kit must catch (docs/tests/v0/stage0/plan/
    //! reserved.md FP4).

    use super::*;
    use std::collections::HashMap;

    /// Witness 1: the obvious `HashMap` cache.
    struct HashMapCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for HashMapCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).cloned()
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.insert(key, result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    /// Witness 2: a `Vec`-backed cache — proves the kit is generic
    /// over implementations, not `HashMap`-shaped.
    struct VecCache {
        entries: Vec<(CacheKey, CachedResult)>,
    }

    impl CompilationCache for VecCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.entries
                .iter()
                .rev()
                .find(|(k, _)| *k == key)
                .map(|(_, v)| v.clone())
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.entries.retain(|(k, _)| *k != key);
            self.entries.push((key, result));
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.entries.retain(|(k, _)| *k != key);
        }
    }

    #[test]
    fn cache_key_digest_round_trips() {
        let digest = [7u8; 32];
        let key = CacheKey::from_digest(digest);
        assert_eq!(key.digest(), &digest, "digest accessor round-trips");
    }

    #[test]
    fn cache_key_equality_follows_the_digest() {
        let a = CacheKey::from_digest([1u8; 32]);
        let b = CacheKey::from_digest([1u8; 32]);
        let c = CacheKey::from_digest([2u8; 32]);
        assert_eq!(a, b, "same digest means same key");
        assert_ne!(a, c, "different digests mean different keys");
        let mut map = HashMap::new();
        map.insert(a, 1u8);
        map.insert(c, 2u8);
        assert_eq!(map.len(), 2, "distinct keys hash apart");
        assert_eq!(map.get(&b), Some(&1), "equal keys hash together");
    }

    #[test]
    fn cached_result_payload_three_faces() {
        let result = CachedResult::new(vec![4, 5]);
        assert_eq!(result.as_payload(), &[4, 5], "borrow face");
        assert_eq!(result.into_payload(), vec![4, 5], "unwrap face");
        assert_eq!(
            CachedResult::new(vec![4, 5]),
            CachedResult::new(vec![4, 5]),
            "value-equality face"
        );
    }

    #[test]
    fn contract_passes_on_the_hash_map_witness() {
        let mut cache = HashMapCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }

    #[test]
    fn contract_passes_on_the_vec_witness() {
        let mut cache = VecCache { entries: vec![] };
        check_compilation_cache_contract(&mut cache);
    }

    /// A cache whose `get_cached` always misses — the kit must catch
    /// contract 1.
    struct AlwaysMissCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for AlwaysMissCache {
        fn get_cached(&self, _key: CacheKey) -> Option<CachedResult> {
            None
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.insert(key, result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    #[test]
    #[should_panic(expected = "store-then-get must hit")]
    fn kit_catches_a_cache_that_never_hits() {
        let mut cache = AlwaysMissCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }

    /// A cache whose `invalidate` is a no-op — the kit must catch
    /// contract 3.
    struct NoInvalidateCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for NoInvalidateCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).cloned()
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.insert(key, result);
        }

        fn invalidate(&mut self, _key: CacheKey) {}
    }

    #[test]
    #[should_panic(expected = "get after invalidate must miss")]
    fn kit_caches_a_cache_that_never_invalidates() {
        let mut cache = NoInvalidateCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }

    /// A cache that never overwrites — the kit must catch contract 5.
    struct FirstWriteWinsCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for FirstWriteWinsCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).cloned()
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.entry(key).or_insert(result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    #[test]
    #[should_panic(expected = "latest wins")]
    fn kit_catches_a_cache_that_never_overwrites() {
        let mut cache = FirstWriteWinsCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }

    /// A cache that stores under the wrong key — the kit must catch
    /// contract 6 (isolation).
    struct OffByOneKeyCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for OffByOneKeyCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).cloned()
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            let mut digest = *key.digest();
            digest[0] = digest[0].wrapping_add(1);
            self.map.insert(CacheKey::from_digest(digest), result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    #[test]
    #[should_panic(expected = "store-then-get must hit")]
    fn kit_catches_a_cache_that_stores_under_a_wrong_key() {
        let mut cache = OffByOneKeyCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }

    /// A cache whose `get_cached` returns a different payload than was
    /// stored — the kit must catch the value-equality half of
    /// contract 1.
    struct PayloadCorruptingCache {
        map: HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for PayloadCorruptingCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).map(|r| {
                let mut bytes = r.as_payload().to_vec();
                bytes.push(0xFF);
                CachedResult::new(bytes)
            })
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.insert(key, result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    #[test]
    #[should_panic(expected = "round-trip equal")]
    fn kit_catches_a_cache_that_corrupts_payloads() {
        let mut cache = PayloadCorruptingCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut cache);
    }
}

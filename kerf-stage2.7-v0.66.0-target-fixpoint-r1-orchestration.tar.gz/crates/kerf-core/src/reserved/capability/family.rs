//! The capability-model family contract — the reserved SPACE face.
//!
//! A capability model is "a closed set of permission-bearing
//! operations governed by unforgeable tokens" (the object-capability
//! model — the de-facto industry standard for permission systems;
//! canonical resources: filesystem, network, clock, and any
//! user-defined resource). This contract freezes what unifies every
//! such model at Stage 0 — an identity card plus a closed error
//! face — and deliberately does NOT predict per-model operation
//! signatures (the interface-prediction paradox, docs/stage0.md
//! §9.9.1: the operations live in each model's own face, e.g. the
//! io sub-model's `CapabilityIO`; mint / delegate / revoke stay the
//! Stage 1 capability-passing window and are additive).
//!
//! A concrete model occupies the capability space by satisfying this
//! contract (constraint satisfaction — membership, not inheritance).

/// The identity card of a capability model — registry key material.
///
/// Three fields, all `'static` (identity is compile-time knowable):
/// the model name (unique inside a registry), the authority terms
/// this model governs (each unique inside a registry — the closed
/// world at any moment), and the operation-face anchor (the trait
/// name that gates this model's operations, e.g. `"CapabilityIO"`
/// for the io sub-model — an identity string, not a type, per the
/// no-prediction discipline).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct CapabilityModelDescriptor {
    name: &'static str,
    authorities: &'static [&'static str],
    operation_face: &'static str,
}

impl CapabilityModelDescriptor {
    /// Build an identity card from its three fields.
    ///
    /// Construction is open (this is metadata); the registry's
    /// `register` is the fail-closed gate that validates identity
    /// (non-empty fields, no duplicate authority terms).
    pub const fn new(
        name: &'static str,
        authorities: &'static [&'static str],
        operation_face: &'static str,
    ) -> Self {
        CapabilityModelDescriptor {
            name,
            authorities,
            operation_face,
        }
    }

    /// The model name (unique inside a registry).
    pub fn name(&self) -> &'static str {
        self.name
    }

    /// The authority terms this model governs, in declared order.
    pub fn authorities(&self) -> &'static [&'static str] {
        self.authorities
    }

    /// The operation-face anchor (the gating trait's name).
    pub fn operation_face(&self) -> &'static str {
        self.operation_face
    }
}

/// The general capability-model family contract (frozen at 0.10-r2).
///
/// Stage 0 freezes the shape only. What a model must declare:
/// its closed error face (the error type its gated operations
/// report) and its identity card (registry key material). What a
/// model may NOT do at Stage 0: mint, delegate or revoke tokens —
/// those are the Stage 1 capability-passing design window, and
/// adding them later is additive (new methods never break this
/// frozen shape).
pub trait CapabilityModelFamily {
    /// The closed error face of this model's capability-gated
    /// operations (e.g. `IOError` for the io sub-model).
    type Error;

    /// The identity card — registry key material.
    fn descriptor() -> CapabilityModelDescriptor;
}

#[cfg(test)]
mod tests {
    //! Descriptor shape probes + family-contract witness
    //! (docs/tests/v0/stage0/plan/reserved.md FP5).

    use super::*;

    /// A local conforming family — the contract witness. The
    /// framework modules never reference concrete models (the
    /// dependency-direction discipline), so the witness lives in
    /// tests exactly like the other frozen faces.
    struct ProbeModel;

    /// The probe's closed error face (a one-variant probe).
    #[derive(Debug, Clone, PartialEq, Eq)]
    struct ProbeError {
        detail: &'static str,
    }

    impl CapabilityModelFamily for ProbeModel {
        type Error = ProbeError;
        fn descriptor() -> CapabilityModelDescriptor {
            CapabilityModelDescriptor::new("probe", &["probe.read"], "ProbeIO")
        }
    }

    #[test]
    fn descriptor_round_trips_all_three_fields() {
        let d = CapabilityModelDescriptor::new("fs", &["fs.read", "fs.write"], "FsIO");
        assert_eq!(d.name(), "fs");
        assert_eq!(d.authorities(), &["fs.read", "fs.write"]);
        assert_eq!(d.operation_face(), "FsIO");
    }

    #[test]
    fn descriptor_equality_follows_field_identity() {
        let a = CapabilityModelDescriptor::new("fs", &["fs.read"], "FsIO");
        let b = CapabilityModelDescriptor::new("fs", &["fs.read"], "FsIO");
        assert_eq!(a, b, "same fields mean same identity card");
        // Hash consistency: equal cards hash equal (HashSet lookup
        // by value works — the Eq/Hash contract).
        let mut set = std::collections::HashSet::new();
        assert!(set.insert(a));
        assert!(!set.insert(b), "an equal card is already present");
    }

    #[test]
    fn descriptors_with_different_fields_are_distinct() {
        let base = CapabilityModelDescriptor::new("fs", &["fs.read"], "FsIO");
        let renamed = CapabilityModelDescriptor::new("net", &["fs.read"], "FsIO");
        let re_auth = CapabilityModelDescriptor::new("fs", &["fs.write"], "FsIO");
        let re_face = CapabilityModelDescriptor::new("fs", &["fs.read"], "OtherIO");
        assert_ne!(base, renamed, "name is identity material");
        assert_ne!(base, re_auth, "authorities are identity material");
        assert_ne!(base, re_face, "operation face is identity material");
    }

    #[test]
    fn witness_family_binds_error_face_and_descriptor() {
        // The frozen shape is implementable with a local error face
        // and yields its identity card through the associated
        // function.
        type WitnessError = <ProbeModel as CapabilityModelFamily>::Error;
        let err: WitnessError = ProbeError { detail: "probe" };
        assert_eq!(err.detail, "probe");
        let d = <ProbeModel as CapabilityModelFamily>::descriptor();
        assert_eq!(d.name(), "probe");
        assert_eq!(d.authorities(), &["probe.read"]);
        assert_eq!(d.operation_face(), "ProbeIO");
    }
}

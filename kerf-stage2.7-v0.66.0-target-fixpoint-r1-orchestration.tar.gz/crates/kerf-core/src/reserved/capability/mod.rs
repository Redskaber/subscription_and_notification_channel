//! The capability space — the general capability-model framework
//! (docs/stage0.md §9.10 root-space organization + §9.13 space
//! hierarchy; the r2 generalization of the 0.10 io point-reservation).
//!
//! What this family reserves is NOT any concrete capability model.
//! It reserves the SPACE: the ability to register and extend abstract
//! capability models (principle 36's organizational answer — an
//! interface predicts points, a mechanism reserves channels, and a
//! space hosts both). Every concrete model — io now; fs / net /
//! clock and user-defined models at Stage 1+ — is a point inside
//! this space, arriving additively without framework changes
//! (principle 37: abstraction covers the space, concrete models are
//! points in it).
//!
//! # Members (capability domain — docs/stage0.md §9.13.3)
//!
//! | Member | Role |
//! |--------|------|
//! | [`family`] | the family contract — what any capability model IS (identity card + closed error face) |
//! | [`token`] | the sealed-token discipline every model's tokens follow |
//! | [`registry`] | the registration & extension mechanism (register / lookup, fail-closed on identity conflicts) |
//! | [`io`] | the io sub-model — the first concrete model (the 0.10-r1 frozen face, re-hung) |
//!
//! # Space relations (constraint combination, not inheritance — §9.10.2)
//!
//! A concrete model occupies the capability space by *satisfying
//! constraints*, never by inheritance: the model satisfies the family
//! contract, its tokens satisfy the token calculus, and its entry
//! satisfies the registry's identity rules. Space relations are set
//! intersections and constraint conjunctions (a lattice, not a
//! tree) — the phrasing "sub-model" is a conceptual convenience, the
//! mathematics is membership.
//!
//! # Dependency direction (SOP §21.12-10(2) / docs/stage0.md §9.10.5)
//!
//! The framework (family / token / registry) depends on zero concrete
//! models; the io sub-model depends on the framework. "Depend on
//! abstract constraints, not concrete implementations" holds in the
//! same zero-inbound-edge cold-start form as the rest of the
//! reservation face: no references beyond `std`, associated types
//! fully self-contained. The registry never names `IoModel` — io
//! registers itself into registries at use sites.
//!
//! # Domain affiliation (SOP §21.12-10(1) — doc-declaration form)
//!
//! This family is the capability domain of the extension space
//! (permission payload). The kerf-space marker family remains a
//! Stage 1+ registration item (plan-0.10.md decision register), so
//! the affiliation is declared here in documentation form; re-anchoring
//! onto the marker family at Stage 1+ is additive and non-breaking.

pub mod family;
pub mod io;
pub mod registry;
pub mod token;

//! The capability-model registry — the reserved registration and
//! extension mechanism (docs/stage0.md §9.10.5 registry pattern, the
//! r2 generalization from the effect-space sketch to the capability
//! space).
//!
//! This is what the reservation actually reserves: not any concrete
//! model, but the ABILITY to register and extend abstract capability
//! models. A new model (fs / net / clock / anything at Stage 1+)
//! enters the space by implementing the family contract and
//! registering here — zero framework changes (the open-closed
//! principle realized at the organizational layer). The registry
//! validates identity fail-closed: a duplicate model name or an
//! authority already governed by another model is rejected, and a
//! rejected registration leaves the registry untouched.
//!
//! The registry is metadata-level and carries no language runtime
//! semantics (the same discipline as the reservation face): it is
//! the management/discovery half of the space, while type-level
//! membership is the family-contract impl on each model (the
//! marker-impl-is-membership rule). Compile-time lookup by a future
//! compiler pipeline and live capability routing are Stage 1+
//! additive windows on this frozen shape.

use super::family::{CapabilityModelDescriptor, CapabilityModelFamily};

/// The closed error-kind set for registry operations.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum RegistryErrorKind {
    /// The descriptor is malformed (an empty name, an empty
    /// authority list, a duplicate authority term inside the
    /// descriptor, or an empty operation-face anchor).
    InvalidDescriptor,
    /// A model with this name is already registered.
    DuplicateModel,
    /// An authority term in the descriptor is already governed by
    /// another registered model (unique subordination — the space
    /// keeps one governing model per authority).
    AuthorityConflict,
}

/// The error face of the registry.
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 /
/// R8): lowercase start, no trailing period, payloads in backticks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RegistryError {
    kind: RegistryErrorKind,
    message: String,
}

impl RegistryError {
    /// Build a registry error from a kind and a message.
    pub fn new(kind: RegistryErrorKind, message: impl Into<String>) -> Self {
        RegistryError {
            kind,
            message: message.into(),
        }
    }

    /// The closed error kind.
    pub fn kind(&self) -> RegistryErrorKind {
        self.kind
    }

    /// The human-readable message.
    pub fn message(&self) -> &str {
        &self.message
    }
}

impl std::fmt::Display for RegistryError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // R8 shape: lowercase start, no trailing period.
        write!(
            f,
            "capability registry error {:?}: {}",
            self.kind, self.message
        )
    }
}

impl std::error::Error for RegistryError {}

/// The capability-model registry — the registration & extension
/// mechanism of the capability space (frozen at 0.10-r2).
///
/// Entries preserve registration order (a deterministic closed
/// world); lookups resolve by model name or by authority term.
pub struct CapabilityModelRegistry {
    entries: Vec<CapabilityModelDescriptor>,
}

impl CapabilityModelRegistry {
    /// An empty registry (the cold-start closed world).
    pub fn new() -> Self {
        CapabilityModelRegistry {
            entries: Vec::new(),
        }
    }

    /// Register a model family — the extension entry point.
    ///
    /// The family's identity card enters the table after fail-closed
    /// validation: the descriptor must be well-formed (non-empty
    /// name, non-empty authority list, no duplicate authority terms
    /// inside the descriptor, non-empty operation-face anchor), the
    /// model name must be unclaimed, and every authority term must
    /// be ungoverned (unique subordination). A rejected registration
    /// leaves the registry untouched.
    pub fn register<F: CapabilityModelFamily>(
        &mut self,
    ) -> Result<&CapabilityModelDescriptor, RegistryError> {
        let descriptor = F::descriptor();

        if descriptor.name().is_empty() {
            return Err(RegistryError::new(
                RegistryErrorKind::InvalidDescriptor,
                "model name must be non-empty",
            ));
        }
        if descriptor.operation_face().is_empty() {
            return Err(RegistryError::new(
                RegistryErrorKind::InvalidDescriptor,
                "operation face must be non-empty",
            ));
        }
        if descriptor.authorities().is_empty() {
            return Err(RegistryError::new(
                RegistryErrorKind::InvalidDescriptor,
                "authority list must be non-empty",
            ));
        }
        // Duplicate authority terms inside one descriptor are a
        // malformed identity card (the same authority twice is not a
        // wider model — it is a contradiction).
        let authorities = descriptor.authorities();
        for (i, term) in authorities.iter().enumerate() {
            if authorities[..i].contains(term) {
                return Err(RegistryError::new(
                    RegistryErrorKind::InvalidDescriptor,
                    format!("duplicate authority term `{term}` inside the descriptor"),
                ));
            }
        }

        // Fail-closed identity checks against the closed world.
        if let Some(registered) = self.lookup(descriptor.name()) {
            return Err(RegistryError::new(
                RegistryErrorKind::DuplicateModel,
                format!(
                    "model `{}` is already registered (operation face `{}`)",
                    registered.name(),
                    registered.operation_face()
                ),
            ));
        }
        for term in authorities {
            if let Some(owner) = self.governing_model(term) {
                return Err(RegistryError::new(
                    RegistryErrorKind::AuthorityConflict,
                    format!(
                        "authority `{term}` is already governed by model `{}`",
                        owner.name()
                    ),
                ));
            }
        }

        self.entries.push(descriptor);
        Ok(self.entries.last().expect("just-pushed entry is present"))
    }

    /// Look up a registered model by name.
    pub fn lookup(&self, name: &str) -> Option<&CapabilityModelDescriptor> {
        self.entries.iter().find(|d| d.name() == name)
    }

    /// Resolve which registered model governs an authority term.
    pub fn governing_model(&self, authority: &str) -> Option<&CapabilityModelDescriptor> {
        self.entries
            .iter()
            .find(|d| d.authorities().contains(&authority))
    }

    /// The closed world at this moment: every governed authority
    /// term, in registration order.
    pub fn governed_authorities(&self) -> Vec<&'static str> {
        self.entries
            .iter()
            .flat_map(|d| d.authorities().iter().copied())
            .collect()
    }

    /// The number of registered models.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether no model is registered yet.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

impl Default for CapabilityModelRegistry {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    //! Registry mechanism probes — the registration & extension
    //! ability with fail-closed identity validation (docs/tests/v0/
    //! stage0/plan/reserved.md FP5).

    use super::*;
    use std::cell::Cell;

    /// A first local model family (the framework layer never names
    /// concrete models — witnesses are local, like every frozen
    /// face).
    struct ProbeModel;

    impl CapabilityModelFamily for ProbeModel {
        type Error = &'static str;
        fn descriptor() -> CapabilityModelDescriptor {
            CapabilityModelDescriptor::new("probe", &["probe.read", "probe.write"], "ProbeIO")
        }
    }

    /// A second local model family — the extension witness: a new
    /// model enters the same registry without any framework change.
    struct ClockModel;

    impl CapabilityModelFamily for ClockModel {
        type Error = &'static str;
        fn descriptor() -> CapabilityModelDescriptor {
            CapabilityModelDescriptor::new("clock", &["clock.now"], "ClockSource")
        }
    }

    /// A family whose descriptor is built from runtime-shaped data —
    /// the invalid-descriptor probes need dynamically chosen cards,
    /// so this witness reads thread-local slots at `descriptor()`
    /// time.
    struct ShapedModel;

    impl CapabilityModelFamily for ShapedModel {
        type Error = &'static str;
        fn descriptor() -> CapabilityModelDescriptor {
            SHAPED.with(|s| s.get())
        }
    }

    thread_local! {
        static SHAPED: Cell<CapabilityModelDescriptor> = const {
            Cell::new(CapabilityModelDescriptor::new(
                "shaped",
                &["shaped.read"],
                "ShapedIO",
            ))
        };
    }

    fn with_shape(d: CapabilityModelDescriptor, f: impl FnOnce()) {
        SHAPED.with(|s| s.set(d));
        f();
    }

    #[test]
    fn new_registry_starts_empty() {
        let registry = CapabilityModelRegistry::new();
        assert!(registry.is_empty());
        assert_eq!(registry.len(), 0);
        assert!(registry.lookup("probe").is_none());
        assert!(registry.governing_model("probe.read").is_none());
        assert!(registry.governed_authorities().is_empty());
    }

    #[test]
    fn default_construction_matches_new() {
        let registry = CapabilityModelRegistry::default();
        assert!(registry.is_empty(), "`Default` is the cold-start registry");
    }

    #[test]
    fn register_resolves_and_lookup_finds_the_model() {
        let mut registry = CapabilityModelRegistry::new();
        let registered = registry
            .register::<ProbeModel>()
            .expect("a well-formed unclaimed model registers");
        assert_eq!(registered.name(), "probe");
        let found = registry.lookup("probe").expect("the model is findable");
        assert_eq!(found.operation_face(), "ProbeIO");
        assert_eq!(registry.len(), 1);
    }

    #[test]
    fn governed_authorities_list_the_closed_world_in_registration_order() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        registry.register::<ClockModel>().expect("clock registers");
        assert_eq!(
            registry.governed_authorities(),
            vec!["probe.read", "probe.write", "clock.now"],
            "registration order is preserved across models"
        );
    }

    #[test]
    fn governing_model_resolves_the_owning_model() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        registry.register::<ClockModel>().expect("clock registers");
        assert_eq!(
            registry.governing_model("probe.write").map(|d| d.name()),
            Some("probe")
        );
        assert_eq!(
            registry.governing_model("clock.now").map(|d| d.name()),
            Some("clock")
        );
    }

    #[test]
    fn register_duplicate_model_name_fails_closed() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("first registers");
        let err = registry
            .register::<ProbeModel>()
            .expect_err("the same model name is rejected");
        assert_eq!(err.kind(), RegistryErrorKind::DuplicateModel);
        assert_eq!(registry.len(), 1, "a rejected registration adds nothing");
    }

    #[test]
    fn register_conflicting_authority_fails_closed() {
        // A differently-named model that claims an authority already
        // governed by probe — unique subordination rejects it.
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        with_shape(
            CapabilityModelDescriptor::new("other", &["probe.read"], "OtherIO"),
            || {
                let err = registry
                    .register::<ShapedModel>()
                    .expect_err("a governed authority is rejected");
                assert_eq!(err.kind(), RegistryErrorKind::AuthorityConflict);
                assert!(
                    err.message().contains("probe.read"),
                    "the conflict message names the authority: {}",
                    err.message()
                );
                assert_eq!(registry.len(), 1, "the closed world is unchanged");
            },
        );
    }

    #[test]
    fn register_rejects_an_empty_name() {
        let mut registry = CapabilityModelRegistry::new();
        with_shape(
            CapabilityModelDescriptor::new("", &["x.read"], "XIO"),
            || {
                let err = registry
                    .register::<ShapedModel>()
                    .expect_err("an empty name is malformed");
                assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor);
            },
        );
    }

    #[test]
    fn register_rejects_an_empty_authority_list() {
        let mut registry = CapabilityModelRegistry::new();
        with_shape(CapabilityModelDescriptor::new("x", &[], "XIO"), || {
            let err = registry
                .register::<ShapedModel>()
                .expect_err("an empty authority list is malformed");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor);
        });
    }

    #[test]
    fn register_rejects_duplicate_authority_terms_inside_a_descriptor() {
        let mut registry = CapabilityModelRegistry::new();
        with_shape(
            CapabilityModelDescriptor::new("x", &["x.read", "x.read"], "XIO"),
            || {
                let err = registry
                    .register::<ShapedModel>()
                    .expect_err("a self-duplicated authority is malformed");
                assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor);
                assert!(
                    err.message().contains("x.read"),
                    "the message names the duplicated term: {}",
                    err.message()
                );
            },
        );
    }

    #[test]
    fn register_rejects_an_empty_operation_face() {
        let mut registry = CapabilityModelRegistry::new();
        with_shape(CapabilityModelDescriptor::new("x", &["x.read"], ""), || {
            let err = registry
                .register::<ShapedModel>()
                .expect_err("an empty operation face is malformed");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor);
        });
    }

    #[test]
    fn lookup_of_an_unknown_name_returns_none() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        assert!(
            registry.lookup("clock").is_none(),
            "only probe is registered"
        );
    }

    #[test]
    fn governing_model_of_an_unknown_authority_returns_none() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        assert!(registry.governing_model("clock.now").is_none());
    }

    #[test]
    fn registry_error_display_follows_r8_shape() {
        for kind in [
            RegistryErrorKind::InvalidDescriptor,
            RegistryErrorKind::DuplicateModel,
            RegistryErrorKind::AuthorityConflict,
        ] {
            let err = RegistryError::new(kind, "probe");
            let text = err.to_string();
            let first = text.chars().next().expect("non-empty display");
            assert!(
                first.is_lowercase(),
                "display must start lowercase: `{text}`"
            );
            assert!(
                !text.ends_with('.'),
                "display must not end with a period: `{text}`"
            );
            assert!(
                text.contains("probe"),
                "display must carry the message payload: `{text}`"
            );
        }
    }

    #[test]
    fn registry_error_kinds_render_pairwise_distinct() {
        let texts: Vec<String> = [
            RegistryErrorKind::InvalidDescriptor,
            RegistryErrorKind::DuplicateModel,
            RegistryErrorKind::AuthorityConflict,
        ]
        .iter()
        .map(|k| RegistryError::new(*k, "x").to_string())
        .collect();
        for i in 0..texts.len() {
            for j in (i + 1)..texts.len() {
                assert_ne!(
                    texts[i], texts[j],
                    "kinds {i} and {j} must render distinctly"
                );
            }
        }
    }

    #[test]
    fn a_failed_registration_leaves_the_closed_world_unchanged() {
        let mut registry = CapabilityModelRegistry::new();
        registry.register::<ProbeModel>().expect("probe registers");
        let before = registry.governed_authorities();
        with_shape(
            CapabilityModelDescriptor::new("other", &["probe.read"], "OtherIO"),
            || {
                let _ = registry.register::<ShapedModel>();
            },
        );
        assert_eq!(
            registry.governed_authorities(),
            before,
            "fail-closed rejection mutates nothing"
        );
    }
}

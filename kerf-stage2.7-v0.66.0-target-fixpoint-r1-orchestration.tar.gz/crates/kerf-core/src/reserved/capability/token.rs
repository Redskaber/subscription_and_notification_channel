//! The token calculus — the sealed-token discipline of the capability
//! space (docs/stage0.md §9.13.3 capability-domain member).
//!
//! Every token of every capability model follows one discipline,
//! restated from the 0.10-r1 io face and generalized: a token is an
//! unforgeable proof of authority — construction is closed (sealed
//! private fields, enforced per model), possession is the only
//! permission proof, and the token itself carries zero ambient
//! authority (default deny). Linear discipline — at most one live
//! holder, delegation consumes the source — is the Stage 1
//! capability-passing window (the object-capability lineage pairs
//! tokens with linear/uniqueness types); adding mint / delegate /
//! revoke later is additive and never breaks this frozen shape.
//!
//! The Stage 0 face carries one associated function: the authority
//! term the token proves, drawn from the registry vocabulary
//! (convention: `"<model>.<authority>"`, e.g. `"io.read"`). The term
//! links a sealed token type back to its governing model's identity
//! card — the coherence invariant tested on the io sub-model.

/// The sealed-token discipline every capability model's tokens follow
/// (frozen at 0.10-r2).
pub trait TokenCalculus {
    /// The authority term this token proves — a registry vocabulary
    /// term of the form `"<model>.<authority>"` (e.g. `"io.read"`).
    fn authority() -> &'static str;
}

#[cfg(test)]
mod tests {
    //! Token-calculus witness probes (docs/tests/v0/stage0/plan/
    //! reserved.md FP5).

    use super::*;

    /// A local sealed token — the same private-field discipline as
    /// the io tokens, witnessed at the framework layer.
    #[derive(Clone, Copy, PartialEq, Eq, Hash)]
    struct ProbeToken {
        _private: (),
    }

    impl TokenCalculus for ProbeToken {
        fn authority() -> &'static str {
            "probe.read"
        }
    }

    #[test]
    fn witness_token_reports_its_authority_term() {
        assert_eq!(ProbeToken::authority(), "probe.read");
    }

    #[test]
    fn authority_terms_follow_the_dotted_model_convention() {
        // The vocabulary convention: "<model>.<authority>" — the
        // term is namespaced by its governing model, linking the
        // token back to the model's identity card.
        for term in [ProbeToken::authority(), "io.read", "io.write"] {
            let (model, authority) = term
                .split_once('.')
                .unwrap_or_else(|| panic!("term `{term}` must be dotted"));
            assert!(!model.is_empty(), "model part of `{term}` is non-empty");
            assert!(
                !authority.is_empty(),
                "authority part of `{term}` is non-empty"
            );
        }
    }
}

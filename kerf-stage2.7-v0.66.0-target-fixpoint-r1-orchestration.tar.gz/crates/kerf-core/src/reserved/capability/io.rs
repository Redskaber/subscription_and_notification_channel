//! The io capability model — the first concrete sub-model under the
//! general capability framework (blueprint docs/stage0.md §9.1.3,
//! frozen at 0.10-r1, re-hung at 0.10-r2).
//!
//! The 0.10-r1 face is preserved verbatim — the sealed tokens, the
//! closed error set and the gated operation trait keep their frozen
//! shapes and their old module path (the `capability_io` re-export
//! in the reservation face root). What r2 adds is the *space* around
//! the point: this model now satisfies [`CapabilityModelFamily`]
//! (the family contract) and its tokens satisfy [`TokenCalculus`],
//! so the model registers into
//! [`CapabilityModelRegistry`](super::registry::CapabilityModelRegistry)
//! like every future model (fs / net / clock / user-defined) — the
//! registration and extension ability the reservation actually
//! reserves.
//!
//! Stage 0 keeps the traditional I/O faces (the VM `VmIo`/`BufferIo`
//! pair and the driver `TapeIo`); Stage 1+ implements capability
//! passing on this shape (basic capability passing — docs/stage0.md
//! §9.4 matrix row "capability-model I/O").
//!
//! Token discipline (fail-closed): both capability tokens carry a
//! private field, so construction is closed outside this crate. No
//! public constructor exists at Stage 0 — minting and delegation are
//! the Stage 1 capability-passing design window, and adding them is
//! additive (new methods never break the frozen shape). "Default
//! deny" is the Stage 0 discipline: possession of a token is the only
//! proof of permission, and no token can be minted yet.

use super::family::{CapabilityModelDescriptor, CapabilityModelFamily};
use super::token::TokenCalculus;

/// The io capability model — the anchor type of the first concrete
/// sub-model in the capability space.
///
/// A zero-sized anchor: the model's substance is its identity card
/// (name `"io"`, authorities `["io.read", "io.write"]`, operation
/// face `"CapabilityIO"`) and its frozen error face; registering
/// `IoModel` into a registry is how the io point enters any closed
/// world.
pub struct IoModel;

impl CapabilityModelFamily for IoModel {
    type Error = IOError;
    fn descriptor() -> CapabilityModelDescriptor {
        CapabilityModelDescriptor::new("io", &["io.read", "io.write"], "CapabilityIO")
    }
}

impl TokenCalculus for ReadCapability {
    fn authority() -> &'static str {
        "io.read"
    }
}

impl TokenCalculus for WriteCapability {
    fn authority() -> &'static str {
        "io.write"
    }
}

/// Unforgeable read-capability token (zero-sized).
///
/// `Debug` is hand-written (not derived) so the token renders as the
/// bare name — the derived form would leak the private field.
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct ReadCapability {
    _private: (),
}

impl std::fmt::Debug for ReadCapability {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("ReadCapability")
    }
}

/// Unforgeable write-capability token (zero-sized).
///
/// Same hand-written `Debug` discipline as [`ReadCapability`].
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct WriteCapability {
    _private: (),
}

impl std::fmt::Debug for WriteCapability {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("WriteCapability")
    }
}

/// The closed error-kind set for capability-gated I/O.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum IoErrorKind {
    /// The source is exhausted (no more lines).
    Eof,
    /// The operation was denied (capability revoked or absent).
    Denied,
    /// The operation was interrupted; a retry is legal.
    Interrupted,
    /// Anything else, described by the message.
    Other,
}

/// The error face of capability-gated I/O.
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IOError {
    kind: IoErrorKind,
    message: String,
}

impl IOError {
    /// Build an I/O error from a kind and a message.
    pub fn new(kind: IoErrorKind, message: impl Into<String>) -> Self {
        IOError {
            kind,
            message: message.into(),
        }
    }

    /// The closed error kind.
    pub fn kind(&self) -> IoErrorKind {
        self.kind
    }

    /// The human-readable message.
    pub fn message(&self) -> &str {
        &self.message
    }
}

impl std::fmt::Display for IOError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // R8 shape: lowercase start, no trailing period.
        write!(f, "io error {:?}: {}", self.kind, self.message)
    }
}

impl std::error::Error for IOError {}

/// The reserved capability-model I/O face (blueprint §9.1.3, frozen at
/// 0.10).
pub trait CapabilityIO {
    /// Read one line, gated by the read capability.
    fn read_line(cap: &mut ReadCapability) -> Result<String, IOError>;

    /// Write one line, gated by the write capability.
    fn write_line(cap: &mut WriteCapability, s: &str) -> Result<(), IOError>;
}

#[cfg(test)]
mod tests {
    //! Signature-stability witness + token discipline + error-face
    //! probes (docs/tests/v0/stage0/plan/reserved.md FP3) and the
    //! r2 re-hang probes (FP5: family binding, token calculus,
    //! registry end-to-end).
    //!
    //! The I/O paths run here because token construction is closed
    //! outside this crate: the witness mints tokens through the
    //! private field (same-module privacy), which is exactly the
    //! Stage 1 mint seam the freeze leaves open.

    use super::*;
    use crate::reserved::capability::registry::CapabilityModelRegistry;

    /// A line-source double: fixed lines, then exhaustion. An
    /// `interrupt_next` flag simulates one interrupted read (the
    /// `Interrupted` kind contract: a retry is legal).
    struct FixedLines {
        lines: Vec<String>,
        pos: usize,
        interrupt_next: bool,
    }

    /// A line-sink double with a revocation switch.
    struct DeniableSink {
        deny: bool,
        captured: Vec<String>,
    }

    struct CapabilityIoDouble;

    impl CapabilityIO for CapabilityIoDouble {
        fn read_line(cap: &mut ReadCapability) -> Result<String, IOError> {
            // Possession check: the token is required to even reach
            // the source (the double keeps the token in scope).
            let _ = cap;
            FIXED_LINES.with(|s| {
                let mut source = s.borrow_mut();
                if source.interrupt_next {
                    source.interrupt_next = false;
                    return Err(IOError::new(
                        IoErrorKind::Interrupted,
                        "transient interruption, retry is legal",
                    ));
                }
                if source.pos < source.lines.len() {
                    let line = source.lines[source.pos].clone();
                    source.pos += 1;
                    Ok(line)
                } else {
                    Err(IOError::new(IoErrorKind::Eof, "line source exhausted"))
                }
            })
        }

        fn write_line(cap: &mut WriteCapability, s: &str) -> Result<(), IOError> {
            let _ = cap;
            SINK.with(|sink| {
                let mut sink = sink.borrow_mut();
                if sink.deny {
                    Err(IOError::new(
                        IoErrorKind::Denied,
                        "write capability revoked",
                    ))
                } else {
                    sink.captured.push(s.to_string());
                    Ok(())
                }
            })
        }
    }

    thread_local! {
        static FIXED_LINES: std::cell::RefCell<FixedLines> = const {
            std::cell::RefCell::new(FixedLines {
                lines: vec![],
                pos: 0,
                interrupt_next: false,
            })
        };
        static SINK: std::cell::RefCell<DeniableSink> =
            const { std::cell::RefCell::new(DeniableSink { deny: false, captured: vec![] }) };
    }

    /// Mint a read token through the private field — the same-crate
    /// seam the Stage 1 mint protocol will formalize.
    fn read_token() -> ReadCapability {
        ReadCapability { _private: () }
    }

    fn write_token() -> WriteCapability {
        WriteCapability { _private: () }
    }

    fn with_lines(lines: &[&str], f: impl FnOnce()) {
        FIXED_LINES.with(|s| {
            *s.borrow_mut() = FixedLines {
                lines: lines.iter().map(|l| l.to_string()).collect(),
                pos: 0,
                interrupt_next: false,
            }
        });
        SINK.with(|s| {
            *s.borrow_mut() = DeniableSink {
                deny: false,
                captured: vec![],
            }
        });
        f();
    }

    #[test]
    fn tokens_are_zero_sized() {
        assert_eq!(
            std::mem::size_of::<ReadCapability>(),
            0,
            "read token is a ZST"
        );
        assert_eq!(
            std::mem::size_of::<WriteCapability>(),
            0,
            "write token is a ZST"
        );
    }

    #[test]
    fn token_debug_forms_are_stable() {
        let r = read_token();
        let w = write_token();
        assert_eq!(format!("{r:?}"), "ReadCapability");
        assert_eq!(format!("{w:?}"), "WriteCapability");
    }

    #[test]
    fn io_error_round_trips_kind_and_message() {
        let err = IOError::new(IoErrorKind::Eof, "line source exhausted");
        assert_eq!(err.kind(), IoErrorKind::Eof);
        assert_eq!(err.message(), "line source exhausted");
    }

    #[test]
    fn read_two_lines_happy_path() {
        with_lines(&["alpha", "beta"], || {
            let mut cap = read_token();
            let a = CapabilityIoDouble::read_line(&mut cap).expect("first line");
            let b = CapabilityIoDouble::read_line(&mut cap).expect("second line");
            assert_eq!((a.as_str(), b.as_str()), ("alpha", "beta"));
        });
    }

    #[test]
    fn read_past_the_end_returns_eof_error() {
        with_lines(&["only"], || {
            let mut cap = read_token();
            let _ = CapabilityIoDouble::read_line(&mut cap).expect("the one line");
            let err = CapabilityIoDouble::read_line(&mut cap).expect_err("source is exhausted");
            assert_eq!(err.kind(), IoErrorKind::Eof, "exhaustion is `Eof`");
        });
    }

    #[test]
    fn interrupted_read_retries_legally() {
        // The `Interrupted` contract: the kind reports a transient
        // failure and a retry must succeed on the same token.
        with_lines(&["after retry"], || {
            FIXED_LINES.with(|s| s.borrow_mut().interrupt_next = true);
            let mut cap = read_token();
            let err =
                CapabilityIoDouble::read_line(&mut cap).expect_err("first read is interrupted");
            assert_eq!(err.kind(), IoErrorKind::Interrupted);
            let line =
                CapabilityIoDouble::read_line(&mut cap).expect("retry on the same token succeeds");
            assert_eq!(line, "after retry");
        });
    }

    #[test]
    fn write_captures_then_denial_fails_closed() {
        with_lines(&[], || {
            let mut cap = write_token();
            CapabilityIoDouble::write_line(&mut cap, "note").expect("write with a live capability");
            SINK.with(|s| s.borrow_mut().deny = true);
            let err = CapabilityIoDouble::write_line(&mut cap, "denied")
                .expect_err("revoked capability must fail closed");
            assert_eq!(err.kind(), IoErrorKind::Denied, "revocation is `Denied`");
            SINK.with(|s| {
                assert_eq!(
                    s.borrow().captured,
                    vec!["note".to_string()],
                    "only the pre-revocation line was captured"
                );
            });
        });
    }

    #[test]
    fn write_denied_from_the_start_captures_nothing() {
        // A capability that never lived: the first write fails closed
        // and the sink stays empty.
        with_lines(&[], || {
            SINK.with(|s| s.borrow_mut().deny = true);
            let mut cap = write_token();
            let err = CapabilityIoDouble::write_line(&mut cap, "never")
                .expect_err("no live capability from the start");
            assert_eq!(err.kind(), IoErrorKind::Denied);
            SINK.with(|s| {
                assert!(
                    s.borrow().captured.is_empty(),
                    "a denied write captures nothing"
                );
            });
        });
    }

    #[test]
    fn display_follows_r8_message_shape() {
        for kind in [
            IoErrorKind::Eof,
            IoErrorKind::Denied,
            IoErrorKind::Interrupted,
            IoErrorKind::Other,
        ] {
            let err = IOError::new(kind, "probe");
            let text = err.to_string();
            let first = text.chars().next().expect("non-empty display");
            assert!(
                first.is_lowercase(),
                "display must start lowercase: `{text}`"
            );
            assert!(
                !text.ends_with('.'),
                "display must not end with a period: `{text}`"
            );
            assert!(
                text.contains("probe"),
                "display must carry the message payload: `{text}`"
            );
        }
    }

    #[test]
    fn error_kinds_render_pairwise_distinct() {
        let texts: Vec<String> = [
            IoErrorKind::Eof,
            IoErrorKind::Denied,
            IoErrorKind::Interrupted,
            IoErrorKind::Other,
        ]
        .iter()
        .map(|k| IOError::new(*k, "x").to_string())
        .collect();
        for i in 0..texts.len() {
            for j in (i + 1)..texts.len() {
                assert_ne!(
                    texts[i], texts[j],
                    "kinds {} and {} must render distinctly",
                    i, j
                );
            }
        }
    }

    // ----- r2 re-hang probes (FP5) -----

    #[test]
    fn io_model_binds_the_frozen_error_face() {
        // The family contract's associated type is pinned to the
        // 0.10-r1 frozen error face (the annotation compiles only
        // when `Error` is exactly `IOError`).
        let err: IOError =
            <IoModel as CapabilityModelFamily>::Error::new(IoErrorKind::Denied, "probe");
        assert_eq!(err.kind(), IoErrorKind::Denied);
    }

    #[test]
    fn io_model_descriptor_names_the_model_and_operation_face() {
        let d = <IoModel as CapabilityModelFamily>::descriptor();
        assert_eq!(d.name(), "io");
        assert_eq!(d.operation_face(), "CapabilityIO");
    }

    #[test]
    fn io_tokens_calculate_their_authority_terms() {
        assert_eq!(ReadCapability::authority(), "io.read");
        assert_eq!(WriteCapability::authority(), "io.write");
    }

    #[test]
    fn io_descriptor_authorities_cover_every_token_term() {
        // The coherence invariant: each sealed token type's authority
        // term is governed by the model's identity card.
        let d = <IoModel as CapabilityModelFamily>::descriptor();
        assert!(d.authorities().contains(&ReadCapability::authority()));
        assert!(d.authorities().contains(&WriteCapability::authority()));
    }

    #[test]
    fn io_model_registers_into_a_fresh_registry() {
        // End-to-end: the concrete point enters a closed world
        // through the reserved mechanism.
        let mut registry = CapabilityModelRegistry::new();
        let registered = registry
            .register::<IoModel>()
            .expect("the io model registers into a fresh registry");
        assert_eq!(registered.name(), "io");
        assert_eq!(
            registry.governing_model("io.read").map(|d| d.name()),
            Some("io")
        );
        assert_eq!(registry.governed_authorities(), vec!["io.read", "io.write"]);
    }
}

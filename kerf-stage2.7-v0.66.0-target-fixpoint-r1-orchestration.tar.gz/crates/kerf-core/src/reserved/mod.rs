//! Stage 0 frozen reservation face — docs/stage0.md §9.1.1-§9.1.4 + §9.4.
//!
//! This module family is the single freeze anchor for the four reserved
//! contract families of the Stage 0 milestone checklist (§22.3):
//! effects, multistage, capability I/O and the compilation cache —
//! "interface defined, implementation may be empty" (P3 = type shape,
//! P2 = trait signatures + behavior spec; docs/stage0.md §9.5.1).
//! Nothing here carries runtime semantics at Stage 0: the primitive
//! semantics of effects already live in the kernel (`CoreExpr::Perform`
//! / `CoreExpr::Handle`), traditional I/O stays in the VM/driver faces,
//! and no cache implementation exists yet.
//!
//! # The capability space (0.10-r2 generalization)
//!
//! The capability reservation is a SPACE, not a point: [`capability`]
//! hosts the general capability-model framework (family contract +
//! token calculus + registration/extension registry), with the io
//! sub-model as the first concrete model inside it. The 0.10-r1 io
//! face keeps its frozen shape and its old path —
//! `reserved::capability_io` re-exports `capability::io` (freeze
//! continuity; the four 0.10 consumer faces compile unchanged).
//!
//! # Dependency direction (SOP §21.12-8 / §21.12-10(2))
//!
//! The reservation face is fully self-contained: associated types and
//! generic bounds only, zero references to concrete downstream types
//! (the language value is an associated type, not the VM value; the
//! cache payload is opaque bytes, not the compiler product). "Depend
//! on abstract constraints, not concrete implementations" is realized
//! in its strongest cold-start form: zero inbound edges beyond `std`.
//!
//! # Domain affiliation (SOP §21.12-10(1) — doc-declaration form)
//!
//! The kerf-space marker family is a Stage 1+ registration item
//! (stage-0-plan.md §5 row 0.10, cold-start note), so the six-domain
//! affiliation is declared here in documentation form; re-anchoring
//! onto the marker family at Stage 1+ is additive and non-breaking
//! (plan-0.10.md decision register):
//!
//! | Family | Domain (SOP §21.12-10(1) six-domain table) |
//! |--------|--------------------------------------------|
//! | [`effects`] | effect domain (side effects) |
//! | [`multistage`] | metaprogramming domain (staged programming) |
//! | [`capability`] | capability domain (permission — the capability space: family contract / token calculus / registry / io sub-model) |
//! | [`cache`] | toolchain domain (compile-time services — `compilation_cache`) |
//!
//! # Signature stability
//!
//! Each frozen trait ships a canonical conforming implementor ("witness")
//! in its test suite: any drift in the frozen shape breaks the witness
//! compilation, which the six-command acceptance run (SOP §3.2) turns
//! into a hard gate. See docs/tests/v0/stage0/plan/reserved.md.

pub mod cache;
pub mod capability;
pub mod effects;
pub mod multistage;

/// The 0.10-r1 module path of the io sub-model, preserved as a
/// re-export (freeze continuity: the four 0.10 consumer faces —
/// api tests, root integration tests, the audit set and the docs —
/// compile unchanged across the r2 re-hang).
pub use capability::io as capability_io;

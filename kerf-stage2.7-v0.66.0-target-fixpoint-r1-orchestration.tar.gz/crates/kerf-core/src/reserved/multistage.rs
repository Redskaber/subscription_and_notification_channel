//! Reserved multistage-programming face — docs/stage0.md §9.1.2 (P3 type shape).
//!
//! Frozen type shape only; the `quote` / `splice` / `run` semantics are
//! the Stage 2 implementation window (docs/stage0.md §9.4 matrix row
//! "multistage programming"; SOP §19.2 registers the staged-programming
//! distinction).
//!
//! Two naming disclosures (plan-0.10.md decision register):
//!
//! * This face's [`MultiStage::quote`] is the *staged-code constructor*
//!   (build code from an expression for a later stage). It is distinct
//!   from the expander's `quote` *data-literal* form delivered at
//!   sub-stage 0.9 (Pair-chain literals) — the §19.2 distinction,
//!   boundary-noted in plan-0.9.md §5.
//! * This face's `Code` associated type is the staged-code carrier. It
//!   is distinct from `kerf_expander::CodeValue` (the L3 structural
//!   syntax carrier of the macro system) — different layers, different
//!   Stage windows.

/// The expression input face of `quote` (blueprint sketch `impl Expr`).
///
/// A marker-level shape at Stage 0: any expression carrier the future
/// staged frontend accepts. Stage 2 fills the real surface; freezing
/// the bound now pins the `quote` signature.
pub trait Expr {
    // Marker shape — Stage 2 owns the surface.
}

/// The code-carrier face: what `splice` and `run` consume.
///
/// Translation note (plan-0.10.md ruling 18): the blueprint sketch
/// spells the spliced and run results as `Self::Code::Inner` and
/// `Self::Code::Result`; Rust resolves those shapes through this
/// companion trait bound.
pub trait CodeCarrier {
    /// What splicing the code yields back into an expression position.
    type Inner;
    /// What running the code yields.
    type Result;
}

/// The reserved multistage face (blueprint §9.1.2, frozen at 0.10).
pub trait MultiStage {
    /// The staged-code type this system builds and consumes.
    type Code: CodeCarrier;

    /// Build code from an expression.
    fn quote<E: Expr>(expr: E) -> Self::Code;

    /// Splice code back into an expression position.
    fn splice(code: Self::Code) -> <Self::Code as CodeCarrier>::Inner;

    /// Run code to its result.
    fn run(code: Self::Code) -> <Self::Code as CodeCarrier>::Result;
}

#[cfg(test)]
mod tests {
    //! Signature-stability witness + shape probes for the multistage
    //! face (docs/tests/v0/stage0/plan/reserved.md FP2).

    use super::*;

    /// The witness expression carrier (a unit carrier: the freeze is
    /// the signature, not the payload semantics).
    struct NumExpr;

    impl Expr for NumExpr {}

    /// The witness staged-code carrier: brackets one number.
    struct NumCode {
        n: i64,
    }

    impl CodeCarrier for NumCode {
        type Inner = i64;
        type Result = i64;
    }

    /// Canonical conforming implementor — the signature-stability
    /// snapshot for the multistage face.
    struct NumStaging;

    impl MultiStage for NumStaging {
        type Code = NumCode;

        fn quote<E: Expr>(expr: E) -> NumCode {
            // The witness ignores the carrier; only the shape matters
            // (the freeze is the signature, not semantics).
            let _ = expr;
            NumCode { n: 0 }
        }

        fn splice(code: NumCode) -> i64 {
            code.n
        }

        fn run(code: NumCode) -> i64 {
            code.n * 2
        }
    }

    fn assert_same<T>(_: &T, _: &T) {}

    #[test]
    fn witness_quote_then_splice_round_trips() {
        let code = NumStaging::quote(NumExpr);
        let inner = NumStaging::splice(code);
        assert_same(&inner, &0i64);
        // Splice yields the `CodeCarrier::Inner` type by construction.
    }

    #[test]
    fn witness_quote_accepts_distinct_expression_carriers() {
        // The generic `E: Expr` bound must accept any expression
        // carrier — two distinct types flow through the one `quote`.
        struct OtherExpr;

        impl Expr for OtherExpr {}

        let a = NumStaging::quote(NumExpr);
        let b = NumStaging::quote(OtherExpr);
        assert_eq!(NumStaging::splice(a), 0, "carrier A flows through");
        assert_eq!(NumStaging::splice(b), 0, "carrier B flows through");
    }

    #[test]
    fn witness_run_executes_to_the_carrier_result() {
        let code = NumCode { n: 21 };
        let result = NumStaging::run(code);
        assert_same(&result, &42i64);
        assert_eq!(result, 42, "run reaches the carrier result type");
    }

    #[test]
    fn carrier_types_are_pinned_through_the_system() {
        // Nameability of the frozen associated-type paths themselves.
        type InnerOf = <<NumStaging as MultiStage>::Code as CodeCarrier>::Inner;
        type ResultOf = <<NumStaging as MultiStage>::Code as CodeCarrier>::Result;
        let inner: InnerOf = 1;
        let result: ResultOf = 2;
        assert_same(&inner, &1i64);
        assert_same(&result, &2i64);
    }
}

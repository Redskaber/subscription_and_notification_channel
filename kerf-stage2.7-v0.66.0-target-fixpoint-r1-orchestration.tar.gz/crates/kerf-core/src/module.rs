//! ModuleItem: the declaration layer above CoreExpr (Layer 4).
//!
//! Per the TD-005 adjudication (docs/develop/v0/stage-0/
//! 0.1-design-adjudications.md), the historical §3.2 `Define`/`Module`
//! expression variants migrate to a declaration layer (§7.4.4 migration
//! table: "module moves to the module system layer"), and `Require` joins
//! them as the third declaration variant. A program is a `Vec<ModuleItem>`
//! whose items nest `CoreExpr` payloads. Sub-stage 0.9 adds the fourth
//! variant `DefineSyntax`: the macro declaration is part of the module's
//! declaration record (the single source of truth for what a module
//! declares), while carrying zero runtime code — the transformer itself
//! lives in the expansion environment (kerf-expander, Layer 3).

use std::fmt;

use crate::error::CoreError;
use crate::expr::CoreExpr;
use kerf_span::Span;
use kerf_span::Symbol;

/// One top-level (or nested-module) declaration.
#[derive(Debug, Clone, PartialEq)]
pub enum ModuleItem {
    /// `name` bound to `value` in the module namespace.
    Define {
        span: Span,
        name: Symbol,
        value: CoreExpr,
    },
    /// Dependency declaration on another module.
    Require { span: Span, module: Symbol },
    /// A nested module with its own item list.
    Module {
        span: Span,
        name: Symbol,
        items: Vec<ModuleItem>,
    },
    /// A `define-syntax` macro declaration (sub-stage 0.9). The name is
    /// recorded for diagnostics and module bookkeeping; the transformer
    /// body never reaches code generation or evaluation (the compiler
    /// and the evaluator both skip it — the `Require` zero-code
    /// precedent applied to the macro phase).
    DefineSyntax { span: Span, name: Symbol },
}

impl ModuleItem {
    /// The span of this declaration (every variant carries one — TD-004).
    pub fn span(&self) -> Span {
        match self {
            ModuleItem::Define { span, .. }
            | ModuleItem::Require { span, .. }
            | ModuleItem::Module { span, .. }
            | ModuleItem::DefineSyntax { span, .. } => *span,
        }
    }

    /// Stable diagnostic name (one lowercase word).
    pub fn kind_name(&self) -> &'static str {
        match self {
            ModuleItem::Define { .. } => "define",
            ModuleItem::Require { .. } => "require",
            ModuleItem::Module { .. } => "module",
            ModuleItem::DefineSyntax { .. } => "define-syntax",
        }
    }

    /// Pre-order span traversal: this item's span first, then nested
    /// expression / item spans depth-first (mirrors
    /// [`CoreExpr::visit_spans`] — the same consumption contract at the
    /// declaration layer).
    pub fn visit_spans(&self, f: &mut impl FnMut(Span)) {
        match self {
            ModuleItem::Define { span, value, .. } => {
                f(*span);
                value.visit_spans(f);
            }
            ModuleItem::Require { span, .. } => f(*span),
            ModuleItem::Module { span, items, .. } => {
                f(*span);
                for item in items {
                    item.visit_spans(f);
                }
            }
            ModuleItem::DefineSyntax { span, .. } => f(*span),
        }
    }

    /// Checked `define` constructor from source-shaped name text.
    pub fn define(span: Span, name: &str, value: CoreExpr) -> Result<Self, CoreError> {
        Ok(ModuleItem::Define {
            span,
            name: Symbol::new(name)?,
            value,
        })
    }

    /// Checked `require` constructor from source-shaped module text.
    pub fn require(span: Span, module: &str) -> Result<Self, CoreError> {
        Ok(ModuleItem::Require {
            span,
            module: Symbol::new(module)?,
        })
    }

    /// Checked `module` constructor from source-shaped name text.
    ///
    /// Member-name uniqueness and cross-module cycles are module-system
    /// semantics owned by plan sub-stage 0.9 (§7.1.1 "module cyclic
    /// dependency" error class); this constructor validates only the
    /// module's own name.
    pub fn module(span: Span, name: &str, items: Vec<ModuleItem>) -> Result<Self, CoreError> {
        Ok(ModuleItem::Module {
            span,
            name: Symbol::new(name)?,
            items,
        })
    }

    /// Checked `define-syntax` constructor from source-shaped name text
    /// (sub-stage 0.9 — the macro declaration record).
    pub fn define_syntax(span: Span, name: &str) -> Result<Self, CoreError> {
        Ok(ModuleItem::DefineSyntax {
            span,
            name: Symbol::new(name)?,
        })
    }
}

impl fmt::Display for ModuleItem {
    /// Minimal one-word rendering (stable diagnostic name); canonical
    /// program rendering is deferred with `CoreExpr` (0.8 / 0.11).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.kind_name())
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ModuleItem declaration layer (sub-stage test doc
    //! FP2/FP4; docs/tests/v0/stage0/plan/core.md).

    use super::*;
    use crate::expr::LiteralValue;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn literal(start: u32, end: u32) -> CoreExpr {
        CoreExpr::Literal {
            span: span(start, end),
            value: LiteralValue::Int(1),
        }
    }

    // ---------- positive ----------

    #[test]
    fn moduleitem_kinds_spans_and_nested_visit() {
        let program = vec![
            ModuleItem::require(span(0, 8), "math").unwrap(),
            ModuleItem::module(
                span(10, 60),
                "inner",
                vec![
                    ModuleItem::define(span(20, 40), "one", literal(30, 32)).unwrap(),
                    ModuleItem::define(span(40, 60), "two", literal(50, 52)).unwrap(),
                ],
            )
            .unwrap(),
            ModuleItem::define_syntax(span(70, 90), "my-if").unwrap(),
        ];
        let kinds: Vec<&'static str> = program.iter().map(|i| i.kind_name()).collect();
        assert_eq!(kinds, vec!["require", "module", "define-syntax"]);
        assert_eq!(program[0].span(), span(0, 8));
        assert_eq!(program[0].to_string(), "require");
        assert_eq!(program[2].span(), span(70, 90));
        assert_eq!(program[2].to_string(), "define-syntax");

        let mut collected = Vec::new();
        for item in &program {
            item.visit_spans(&mut |s| collected.push(s.start.0));
        }
        // require; module; inner define1, its literal; inner define2, its
        // literal; define-syntax.
        assert_eq!(collected, vec![0, 10, 20, 30, 40, 50, 70]);
    }

    // ---------- negative ----------

    #[test]
    fn define_constructor_rejects_invalid_name() {
        let err = ModuleItem::define(span(0, 1), "bad name", literal(0, 1))
            .expect_err("invalid define name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    #[test]
    fn require_constructor_rejects_invalid_module_name() {
        let err =
            ModuleItem::require(span(0, 1), "").expect_err("empty module name must be rejected");
        assert_eq!(
            err,
            CoreError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol {
                text: String::new()
            })
        );
    }

    #[test]
    fn define_syntax_constructor_rejects_invalid_name() {
        let err = ModuleItem::define_syntax(span(0, 1), "not a name")
            .expect_err("invalid macro name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    #[test]
    fn module_constructor_rejects_invalid_name() {
        let err = ModuleItem::module(span(0, 1), "a b", vec![])
            .expect_err("invalid module name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }
}

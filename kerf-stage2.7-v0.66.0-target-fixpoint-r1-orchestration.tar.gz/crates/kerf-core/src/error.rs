//! Errors produced by kerf-core construction and validation.

use std::error::Error;
use std::fmt;

use kerf_span::{Symbol, SymbolError};

/// Errors raised while building core nodes from source-shaped text
/// (validated constructors — the sub-stage 0.4 expander contract).
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks. The
/// `InvalidSymbol` arm delegates its rendering to the single source
/// `kerf_span::SymbolError` (the unified identifier floor since v0.27.0 —
/// stage0.md §9.58): the same source concept always renders the same
/// English text everywhere (the single-source dictionary — the
/// parity-guard prerequisite).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CoreError {
    /// A name failed the [`kerf_span::Symbol`](kerf_span::Symbol) floor
    /// (empty, whitespace, or control character).
    InvalidSymbol(SymbolError),
    /// `fn` form binds the same parameter name twice. The payload is
    /// the interned identity of the duplicate — the constructor
    /// interned every parameter before the duplicate scan, so the
    /// error reuses that entry (§9.65 EXP-4; 4-byte clone, never a
    /// text copy).
    DuplicateParam { name: Symbol },
    /// `handle` installs two clauses for the same effect. The payload
    /// is the clause's interned effect identity (§9.65 EXP-5).
    DuplicateHandler { effect: Symbol },
}

impl From<SymbolError> for CoreError {
    fn from(err: SymbolError) -> Self {
        CoreError::InvalidSymbol(err)
    }
}

impl fmt::Display for CoreError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CoreError::InvalidSymbol(err) => err.fmt(f),
            CoreError::DuplicateParam { name } => {
                write!(f, "duplicate parameter `{name}` in fn form")
            }
            CoreError::DuplicateHandler { effect } => {
                write!(f, "duplicate handler clause for effect `{effect}`")
            }
        }
    }
}

impl Error for CoreError {}

#[cfg(test)]
mod tests {
    //! Unit tests for the CoreError rendering surface (sub-stage test doc
    //! FP4; R8 message-shape assertions).

    use super::*;

    // ---------- negative (error surface) ----------

    #[test]
    fn display_invalid_symbol_mentions_text_and_rules() {
        let err = CoreError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "a b".to_owned(),
        });
        let rendered = err.to_string();
        assert!(rendered.contains("`a b`"));
        assert!(rendered.contains("non-empty"));
        assert!(rendered.contains("whitespace"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn symbol_error_converts_into_the_core_face() {
        // The `?` bridge: kerf_span::SymbolError flows into CoreError
        // unchanged in payload and rendering (single source).
        let inner = SymbolError::InvalidSymbol {
            text: "x".to_owned(),
        };
        let outer: CoreError = inner.clone().into();
        assert_eq!(outer, CoreError::InvalidSymbol(inner));
        assert_eq!(
            outer.to_string(),
            "invalid symbol `x`: must be non-empty with no whitespace or control characters"
        );
    }

    #[test]
    fn display_duplicate_param_mentions_name() {
        // §9.65 EXP-4: interned identity payload; Display rides the
        // `as_str` bridge — byte-identical to the String era.
        let err = CoreError::DuplicateParam {
            name: Symbol::new("x").expect("fixture symbol must be valid"),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`x`"));
        assert!(rendered.contains("fn"));
        assert_eq!(rendered.chars().next().unwrap(), 'd');
    }

    #[test]
    fn display_duplicate_handler_mentions_effect() {
        let err = CoreError::DuplicateHandler {
            effect: Symbol::new("read").expect("fixture symbol must be valid"),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`read`"));
        assert!(rendered.contains("handler"));
    }

    #[test]
    fn error_variants_distinguishable_by_equality() {
        let a = CoreError::InvalidSymbol(SymbolError::InvalidSymbol {
            text: "x".to_owned(),
        });
        let b = CoreError::DuplicateParam {
            name: Symbol::new("x").expect("fixture symbol must be valid"),
        };
        let c = CoreError::DuplicateHandler {
            effect: Symbol::new("x").expect("fixture symbol must be valid"),
        };
        assert_ne!(a, b);
        assert_ne!(b, c);
        assert_ne!(a, c);
        // Same variant with same payload compares equal (test assertions
        // rely on this).
        assert_eq!(
            a,
            CoreError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "x".to_owned()
            })
        );
    }
}

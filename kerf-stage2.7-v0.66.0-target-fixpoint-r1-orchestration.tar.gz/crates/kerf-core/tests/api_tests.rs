//! kerf-core crate-level integration tests: verify the public API surface
//! re-exported from `lib.rs` (SOP §9.1 rule 5 — crate-internal `tests/`
//! validates only this crate's public API; cross-crate assertions live in
//! the workspace root `tests/` tree).

use kerf_core::{Binding, CoreError, CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId};
use kerf_span::{Span, Symbol};

fn span(start: u32, end: u32) -> Span {
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId::ROOT,
    )
    .expect("test fixture span must be well-formed")
}

#[test]
fn public_api_exports_documented_surface() {
    // Compile-level surface check: every documented name is reachable from
    // the crate root (SOP §10.1 rule 4 explicit re-export list).
    let symbol = Symbol::new("x").expect("valid symbol via public path");
    assert_eq!(symbol.as_str(), "x");

    let literal = CoreExpr::Literal {
        span: span(0, 2),
        value: LiteralValue::Int(42),
    };
    assert_eq!(literal.kind_name(), "literal");
    let _binding: Binding = Binding::new(span(0, 1), "x", literal.clone()).unwrap();
    let _clause: HandlerClause = HandlerClause::new(span(0, 1), "read", literal.clone()).unwrap();
    let _err: CoreError = CoreError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol {
        text: String::new(),
    });
}

#[test]
fn validated_constructors_build_full_program() {
    // A representative program: define f = fn(x) => if x then 1 else 2,
    // handled under an effect clause — every name-bearing node goes
    // through a validated constructor.
    let body = CoreExpr::If {
        span: span(10, 30),
        cond: Box::new(CoreExpr::var(span(10, 11), "x").unwrap()),
        then_branch: Box::new(CoreExpr::Literal {
            span: span(16, 17),
            value: LiteralValue::Int(1),
        }),
        else_branch: Box::new(CoreExpr::Literal {
            span: span(24, 25),
            value: LiteralValue::Int(2),
        }),
    };
    let function = CoreExpr::fn_(span(0, 30), &["x"], body).unwrap();
    let handled = CoreExpr::handle(
        span(0, 60),
        function,
        vec![
            HandlerClause::new(
                span(40, 50),
                "read",
                CoreExpr::var(span(41, 42), "h").unwrap(),
            )
            .unwrap(),
        ],
    )
    .unwrap();
    let item = ModuleItem::define(span(0, 60), "f", handled).unwrap();

    let mut span_count = 0usize;
    item.visit_spans(&mut |_s| span_count += 1);
    assert!(
        span_count >= 6,
        "nested program must report >= 6 spans, got {span_count}"
    );
    assert_eq!(item.kind_name(), "define");
}

#[test]
fn public_fn_constructor_rejects_duplicate_params() {
    let err = CoreExpr::fn_(
        span(0, 1),
        &["x", "y", "x"],
        CoreExpr::Literal {
            span: span(0, 1),
            value: LiteralValue::Nil,
        },
    )
    .expect_err("duplicate params must be rejected via public path");
    assert_eq!(
        err,
        CoreError::DuplicateParam {
            // §9.65 EXP-4: interned identity payload.
            name: Symbol::new("x").expect("fixture symbol must be valid")
        }
    );
}

#[test]
fn public_handle_constructor_rejects_duplicate_effects() {
    let literal = || CoreExpr::Literal {
        span: span(0, 1),
        value: LiteralValue::Nil,
    };
    let err = CoreExpr::handle(
        span(0, 1),
        literal(),
        vec![
            HandlerClause::new(span(0, 1), "read", literal()).unwrap(),
            HandlerClause::new(span(0, 1), "read", literal()).unwrap(),
        ],
    )
    .expect_err("duplicate effect clauses must be rejected via public path");
    assert_eq!(
        err,
        CoreError::DuplicateHandler {
            // §9.65 EXP-5: interned identity payload.
            effect: Symbol::new("read").expect("fixture symbol must be valid")
        }
    );
}

#[test]
fn public_var_constructor_rejects_invalid_name() {
    assert!(matches!(
        CoreExpr::var(span(0, 1), "a b"),
        Err(CoreError::InvalidSymbol(_))
    ));
}

#[test]
fn public_define_rejects_invalid_name() {
    let value = CoreExpr::Literal {
        span: span(0, 1),
        value: LiteralValue::Nil,
    };
    assert!(matches!(
        ModuleItem::define(span(0, 1), "a b", value),
        Err(CoreError::InvalidSymbol(_))
    ));
}

#[test]
fn public_require_rejects_invalid_module_name() {
    assert!(matches!(
        ModuleItem::require(span(0, 1), "\t"),
        Err(CoreError::InvalidSymbol(_))
    ));
}

#[test]
fn public_module_rejects_invalid_name() {
    assert!(matches!(
        ModuleItem::module(span(0, 1), "a b", vec![]),
        Err(CoreError::InvalidSymbol(_))
    ));
}

// ---------- reserved face (sub-stage 0.10) ----------

use kerf_core::reserved::cache::{self as cache_face, CacheKey, CachedResult, CompilationCache};
use kerf_core::reserved::capability_io::{
    CapabilityIO, IOError, IoErrorKind, ReadCapability, WriteCapability,
};
use kerf_core::reserved::effects::{EffectOp, EffectSystem};
use kerf_core::reserved::multistage::{CodeCarrier, Expr, MultiStage};

#[test]
fn reserved_module_exposes_all_four_families() {
    // Compile-level family check: all four contract families are
    // reachable through the public `reserved` module path.
    let key = CacheKey::from_digest([0u8; 32]);
    assert_eq!(key.digest(), &[0u8; 32], "cache family reachable");
    assert_eq!(
        std::mem::size_of::<ReadCapability>(),
        0,
        "capability_io family reachable (read token is a ZST)"
    );
    assert_eq!(
        std::mem::size_of::<WriteCapability>(),
        0,
        "capability_io family reachable (write token is a ZST)"
    );
    // effects / multistage families are compile-level names — pinned
    // by the witness impls below.
}

#[test]
fn reserved_cache_contract_kit_runs_against_a_local_witness() {
    struct LocalCache {
        map: std::collections::HashMap<CacheKey, CachedResult>,
    }

    impl CompilationCache for LocalCache {
        fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
            self.map.get(&key).cloned()
        }

        fn store(&mut self, key: CacheKey, result: CachedResult) {
            self.map.insert(key, result);
        }

        fn invalidate(&mut self, key: CacheKey) {
            self.map.remove(&key);
        }
    }

    let mut cache = LocalCache {
        map: std::collections::HashMap::new(),
    };
    cache_face::check_compilation_cache_contract(&mut cache);
}

#[test]
fn reserved_capability_error_face_renders_in_r8_shape() {
    let err = IOError::new(IoErrorKind::Denied, "capability absent");
    let text = err.to_string();
    let first = text.chars().next().expect("non-empty display");
    assert!(first.is_lowercase(), "lowercase start: `{text}`");
    assert!(!text.ends_with('.'), "no trailing period: `{text}`");
    assert_eq!(err.kind(), IoErrorKind::Denied);
    assert_eq!(err.message(), "capability absent");
}

#[test]
fn reserved_trait_witnesses_compile_from_outside_the_crate() {
    // Signature-stability from the external view: implementing the
    // frozen traits outside kerf-core must compile unchanged. The
    // capability methods stay callable only through crate-minted
    // tokens (construction is sealed) — the impl block itself is the
    // frozen-signature witness.
    struct OutsideEffects;

    enum OutsideEffect {
        Ping,
    }

    impl EffectOp for OutsideEffect {
        type Result = bool;
    }

    impl EffectSystem for OutsideEffects {
        type Effect = OutsideEffect;
        type Handler = ();
        type Continuation = ();
        type Value = bool;

        fn perform(&self, effect: OutsideEffect) -> bool {
            matches!(effect, OutsideEffect::Ping)
        }

        fn handle(&self, _handler: (), computation: impl FnOnce() -> bool) -> bool {
            computation()
        }
    }

    struct OutsideStaging;

    /// Outside-crate capability I/O witness: the impl compiles
    /// unchanged (signature freeze), but without a minted token it can
    /// only fail closed — exactly the sealed-token discipline.
    struct OutsideIo;

    impl CapabilityIO for OutsideIo {
        fn read_line(cap: &mut ReadCapability) -> Result<String, IOError> {
            let _ = cap;
            Err(IOError::new(
                IoErrorKind::Denied,
                "no token source outside the defining crate",
            ))
        }

        fn write_line(cap: &mut WriteCapability, _s: &str) -> Result<(), IOError> {
            let _ = cap;
            Err(IOError::new(
                IoErrorKind::Denied,
                "no token source outside the defining crate",
            ))
        }
    }

    /// Local newtype carrier (the orphan rule forbids implementing the
    /// frozen trait on a primitive from outside the crate — which is
    /// itself the dependency-direction discipline at work).
    struct OutsideCode(i32);

    impl CodeCarrier for OutsideCode {
        type Inner = i32;
        type Result = i32;
    }

    impl MultiStage for OutsideStaging {
        type Code = OutsideCode;

        fn quote<E: Expr>(_expr: E) -> OutsideCode {
            OutsideCode(0)
        }

        fn splice(code: OutsideCode) -> i32 {
            code.0
        }

        fn run(code: OutsideCode) -> i32 {
            code.0
        }
    }

    // The compiled witnesses execute their minimal semantics.
    struct MarkerExpr;

    impl Expr for MarkerExpr {}

    let system = OutsideEffects;
    assert!(system.perform(OutsideEffect::Ping), "effects witness runs");
    assert!(system.handle((), || true), "handle runs");
    let code = OutsideStaging::quote(MarkerExpr);
    assert_eq!(OutsideStaging::run(code), 0, "multistage witness runs");
    // The outside capability I/O witness type stays nameable (its impl
    // above is the frozen-signature proof; construction needs no token).
    let _io_witness_type_pinned = std::marker::PhantomData::<OutsideIo>;
}

#[test]
fn reserved_cache_shape_faces_reachable_from_outside() {
    // The cache data shapes through the public path (SOP §9.1 rule 5):
    // digest round-trip and payload faces are crate-public.
    let key = CacheKey::from_digest([9u8; 32]);
    assert_eq!(key.digest(), &[9u8; 32]);
    let copied = key;
    assert_eq!(copied, key, "keys are copyable");
    let result = CachedResult::new(vec![1, 2, 3]);
    assert_eq!(result.as_payload(), &[1, 2, 3]);
    assert_eq!(result.clone().into_payload(), vec![1, 2, 3]);
    assert_ne!(
        CachedResult::new(vec![1]),
        CachedResult::new(vec![2]),
        "payload equality is value-based"
    );
}

#[test]
fn reserved_io_error_is_a_std_error_object() {
    // The frozen face implements `std::error::Error`: the error boxes
    // into a trait object and downcasts back — the integration shape
    // any Stage 1 caller relies on.
    let err: Box<dyn std::error::Error> =
        Box::new(IOError::new(IoErrorKind::Interrupted, "boxed probe"));
    assert!(
        err.to_string().contains("boxed probe"),
        "boxed display carries the payload: {err}"
    );
    let downcast = err
        .downcast_ref::<IOError>()
        .expect("downcast back to IOError");
    assert_eq!(downcast.kind(), IoErrorKind::Interrupted);
}

// ---------- capability space (sub-stage 0.10-r2) ----------

use kerf_core::reserved::capability::family::{CapabilityModelDescriptor, CapabilityModelFamily};
use kerf_core::reserved::capability::io::IoModel;
use kerf_core::reserved::capability::registry::{
    CapabilityModelRegistry, RegistryError, RegistryErrorKind,
};
use kerf_core::reserved::capability::token::TokenCalculus;
use kerf_core::reserved::capability_io as frozen_io_path;

#[test]
fn capability_space_faces_reachable_from_outside() {
    // The general framework is crate-public through the capability
    // module path: identity cards, the family contract, the token
    // calculus and the registry all nameable from outside.
    let card = CapabilityModelDescriptor::new("fs", &["fs.read", "fs.write"], "FsIO");
    assert_eq!(card.name(), "fs");
    assert_eq!(card.authorities(), &["fs.read", "fs.write"]);
    assert_eq!(card.operation_face(), "FsIO");
    let registry = CapabilityModelRegistry::new();
    assert!(registry.is_empty(), "the cold-start closed world is empty");
}

#[test]
fn io_model_registers_through_the_public_path() {
    // End-to-end through the public path: the first concrete model
    // enters a closed world via the reserved mechanism.
    let mut registry = CapabilityModelRegistry::new();
    let registered = registry
        .register::<IoModel>()
        .expect("the io model registers");
    assert_eq!(registered.name(), "io");
    assert_eq!(
        registry.lookup("io").map(|d| d.operation_face()),
        Some("CapabilityIO")
    );
    assert_eq!(registry.governed_authorities(), vec!["io.read", "io.write"]);
}

#[test]
fn outside_model_family_registers_into_a_registry() {
    // The extension ability from outside the crate: a local family
    // (the canonical `net` resource) satisfies the contract and
    // registers without any framework change — the open-closed
    // principle witnessed at the api layer.
    struct OutsideNet;

    #[derive(Debug, Clone, PartialEq, Eq)]
    struct NetError {
        detail: String,
    }

    impl CapabilityModelFamily for OutsideNet {
        type Error = NetError;
        fn descriptor() -> CapabilityModelDescriptor {
            CapabilityModelDescriptor::new("net", &["net.connect"], "NetIO")
        }
    }

    let mut registry = CapabilityModelRegistry::new();
    registry.register::<IoModel>().expect("io registers");
    let net = registry
        .register::<OutsideNet>()
        .expect("an outside family registers alongside io");
    assert_eq!(net.name(), "net");
    assert_eq!(
        registry.governed_authorities(),
        vec!["io.read", "io.write", "net.connect"],
        "the closed world grows additively"
    );
    // The family's error face stays pinned to the local type from
    // outside (the annotation compiles only on exact equality).
    let err = NetError {
        detail: "probe".to_string(),
    };
    let _pinned: <OutsideNet as CapabilityModelFamily>::Error = err.clone();
    assert_eq!(err.detail, "probe");
}

#[test]
fn capability_registry_fails_closed_through_the_public_path() {
    let mut registry = CapabilityModelRegistry::new();
    registry.register::<IoModel>().expect("first registration");
    let err = registry
        .register::<IoModel>()
        .expect_err("a duplicate model is rejected");
    assert_eq!(err.kind(), RegistryErrorKind::DuplicateModel);
    assert_eq!(registry.len(), 1, "a rejected registration adds nothing");
}

#[test]
fn capability_io_reexport_preserves_the_frozen_module_path() {
    // Freeze continuity (0.10-r2 re-hang): the 0.10-r1 module path
    // resolves the very same items as the new capability-space path —
    // path identity, not a copy.
    assert_eq!(
        std::any::TypeId::of::<frozen_io_path::ReadCapability>(),
        std::any::TypeId::of::<kerf_core::reserved::capability::io::ReadCapability>(),
        "the re-exported read token is the same type"
    );
    assert_eq!(
        std::any::TypeId::of::<frozen_io_path::WriteCapability>(),
        std::any::TypeId::of::<kerf_core::reserved::capability::io::WriteCapability>(),
        "the re-exported write token is the same type"
    );
    assert_eq!(
        std::any::TypeId::of::<frozen_io_path::IOError>(),
        std::any::TypeId::of::<kerf_core::reserved::capability::io::IOError>(),
        "the re-exported error face is the same type"
    );
    // The sealed-token discipline survives the re-hang untouched,
    // and the token calculus stays reachable through the public
    // path (the authority terms of the frozen tokens).
    assert_eq!(std::mem::size_of::<frozen_io_path::ReadCapability>(), 0);
    assert_eq!(std::mem::size_of::<frozen_io_path::WriteCapability>(), 0);
    assert_eq!(
        <frozen_io_path::ReadCapability as TokenCalculus>::authority(),
        "io.read"
    );
    assert_eq!(
        <frozen_io_path::WriteCapability as TokenCalculus>::authority(),
        "io.write"
    );
}

#[test]
fn registry_error_is_a_std_error_object() {
    // The registry error face implements `std::error::Error` — the
    // same integration shape as the frozen io error face.
    let err: Box<dyn std::error::Error> = Box::new(RegistryError::new(
        RegistryErrorKind::AuthorityConflict,
        "boxed probe",
    ));
    assert!(
        err.to_string().contains("boxed probe"),
        "boxed display carries the payload: {err}"
    );
    let downcast = err
        .downcast_ref::<RegistryError>()
        .expect("downcast back to RegistryError");
    assert_eq!(downcast.kind(), RegistryErrorKind::AuthorityConflict);
}

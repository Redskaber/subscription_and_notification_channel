//! kerf-span — source positions and cross-stage symbol identity for the
//! kerf compiler pipeline.
//!
//! Layer 0 crate (SOP §18.5): zero internal dependencies, consumed by every
//! pipeline stage. Design basis: `docs/stage0.md` §8.6 (Span full-pipeline
//! propagation) and §12.1 (byte-offset representation; line/column are
//! derived at diagnostic-render time, never stored).
//!
//! Since v0.27.0 this crate also owns the identifier [`Symbol`] and its
//! single process-global interner (docs/stage0.md §9.58 — the crate
//! boundary review): the surface layer (`kerf-syntax`) and the core layer
//! (`kerf-core`) previously carried structurally identical interner twins
//! (§9.52.4) and crossed the boundary as source text; the unified
//! foundation face gives the whole pipeline one identity pool, following
//! the rustc precedent (`rustc_span::Symbol` — the interner the lexer,
//! AST, HIR and MIR all consume; §9.58 K78 anchor; oxc and rust-analyzer
//! share the same foundation-layer shape — K79/K80).
//!
//! The crate is intentionally dependency-free (no `thiserror`/`anyhow`):
//! external-dependency introduction requires SOP §18 review, and the error
//! surface here is small enough for a manual `std::error::Error` impl.

pub mod span;
pub mod symbol;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
// Convention: cross-stage shared ID types carry no prefix (SOP §10.1 rule 3).
pub use span::{ByteOffset, ExpansionId, FileId, Span, SpanError};
pub use symbol::{Symbol, SymbolError};

# krf_reformat.py — selfhost `.krf` 源格式化工具（tools/selfhost/）

> 归档依据 SOP §3.4 规则 2；落位轮 = r78（§9.79 selfhost 格式整理轮，v0.48.0）。

## 用途

对 `selfhost/v1/*.krf`（冻结子集自承载源）做**空白级**重排：只拆超宽行、不触碰任何 token。四个构造性保证：

1. 每个被重发的顶层形式的 **token 流逐位不变**（注释与空白对 kerf lexer 不是 token）；
2. 每个被重发形式的**语法树结构相等**（解析器逐节点比对）；
3. 四个 tamper 锚串（parity 测试的防篡改探针）在产物中**保持连续**；
4. 全文件 token 流不变 + 残余超宽行清零。

## 用法

```bash
# 本地检查（CI 面为 Rust 守卫 tests/v1/stage1/plan/selfhost_format_guard_tests.rs）
python3 tools/selfhost/krf_reformat.py selfhost/v1/reader.krf --check
python3 tools/selfhost/krf_reformat.py selfhost/v1/expander.krf --check
python3 tools/selfhost/krf_reformat.py selfhost/v1/macro.krf --check

# 演练（报告将触碰的形式，不写回）
python3 tools/selfhost/krf_reformat.py <file.krf> --dry-run --width 100 --style indent

# 实际重排（只重发含超宽行的顶层形式）
python3 tools/selfhost/krf_reformat.py <file.krf> --width 100 --style indent
```

## 参数

| 参数 | 说明 |
|---|---|
| `--width N` | 行宽硬界（默认 100 = SOP §10.5「~100 列内」+ rustfmt max_width 同源） |
| `--style indent` | +1 缩进风格（macro.krf 主导手工风格：`(<head>` 单独行，子形式每行 +1 列） |
| `--style aligned` | 参数对齐风格（reader/expander 主导手工风格：后续参数对齐于首参列） |
| `--dry-run` | 只报告不写回 |
| `--check` | 只做约定校验（宽度 + 非 ASCII 白名单 {`—`, `§`} + 零 ASCII 旁注破折号），违例 exit 1 |

## 边界（诚实登记）

- **形内注释跳过**：含形内独立注释行的顶层形式会被 `SKIP`（重发会丢注释）——此类形式需手工拆分 + 同款树等价验证（r78 的 reader.krf `rd-loop` L102 即此通道）。
- **右倾 cons 链的 aligned 风格列数爆炸**：参数对齐风格在深层右倾链上每级 +len(head)+2 列，~20 级即超界——深链场景用 `--style indent` 或手工外科拆分（r78 的 expander.krf L422/L532/L684 即外科通道）。
- 本工具**不做**破折号风格转换（r78 的 ` - `/`  -  ` → ` — ` 归一为一次性 sed 操作，约定由守卫机检锁定，见 §9.79）。

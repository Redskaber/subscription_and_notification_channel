# 04 · stage-0.3 reader 种子（Task 6-a 压实摘要）

**1 行概述**：kerf-reader 完整实现（StxToken 词法 + 递归下降语法 → SyntaxObject 树 + ReadError 十变体字节定位 + 256 嵌套帽 + fail-closed 词法分类），60 新测试 1:3 + §7.3.1 审计集 r1 30 case（全额口径起强），workspace 累计 204 绿，版本 0.4.0，七类错误 2/7 点亮。

**压实摘要**：
- 设计对齐（14 项，plan-0.3.md §4）：两相读取 / 数字形 fail-closed（无 Racket 符号回退——Rust parse 语义）/ `()` 读期拒绝（SOP 第 3 类纵深防御 + 引号空表诚实边界）/ `#t`/`#f` 精确二值（L12253 语料）/ 注释 + BOM 空白类 / 字符串转义五元 + 裸换行 / 括号族与读取器宏字符拒绝（无读取器宏——quote 拼写全形）/ 最内层未闭合报告（确定性）/ 256 帽公开常量双向 / Runtime+空域戳（着色属 0.4）/ TokenLike 退役执行 / §8.1 三保证 + 皮肤子集申明 / 单源字典三层断言 / 审计集 r1 基线（单调增长至 0.11 的 7/7）。
- 实现：五模块（token/error/lexer/parser/lib）+ lex/read_program 双入口 + 根 Cargo.toml [[example]]；TokenLike 退役——seed 测试迁移真实 StxToken（0.0 章程承诺时点）。
- 测试：三层 60 case（43+8+9，正负 15:45——首轮 15:40 未达标补 5 真实负向）+ 审计集 30 case（A10+B10+C5+D5，cargo run exit 0）。
- 内循环 7 轮（实现侧零缺陷——全部为测试期望值字节偏移手算错位族 8 处 + 导入 + 比例 + R8 注释；教训：偏移断言以错误消息回读而非手数）。
- 版本：workspace 0.3.0 → 0.4.0。

**关键裁定**（s）：空应用 reader 期拒绝（SOP 检测点标注 expander——先拦 = 纵深防御）；最内层未闭合报告（最接近输入耗尽处）；数字形 fail-closed（报错>静默）；审计集 = 独立可重跑 example（§7.3.1 规则 3 落位）。

**溯源指针**：flat worklog Task 6-a（本里程碑详录）；交付实录 plan-0.3.md（含 §6 审计构成映射）；测试文档 docs/tests/v0/stage0/plan/reader.md；审计集 examples/audit/stage0_gate_audit_r1.rs。

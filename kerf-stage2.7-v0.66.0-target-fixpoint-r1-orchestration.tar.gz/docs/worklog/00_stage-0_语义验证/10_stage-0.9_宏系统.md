# 09 · stage-0.9 宏系统种子（Task 12-a 压实摘要）

**1 行概述**：kerf-expander 宏系统完整落位（**基础卫生宏系统** define-syntax/syntax-rules 变换器[定长图案 + 字面量表 + 通配 + 模式变量——省略号边界注册期 fail-closed] + **双机制卫生**[裁定十四：scope coloring binder-scopes 子集判据定展开期绑定——0.4 membership 一般化、非宏代码结构性零回归 + rename-on-capture `name__macro_N` 传导名字基后端——触发集 = 拼接实符号 ∪ STAGE0_GLOBALS ∪ 保留名] + **CodeValue**[§6.3.3 六操作合同面：from_syntax/to_syntax/substitute/alpha_rename/symbols/to_source] + **模块加载层**[三色 DFS 环检测——第 7 类点亮 + LoadPlan 依赖先行次序 + 缺失/重名 fail-closed] + **quote 消费面**[LiteralValue::Pair 右折链——plan-0.7 决策 13 兑现；符号 fail-closed] + ModuleItem 第四变体 DefineSyntax[零码记录——Require 先例对偶] + 宏分派[核心形式后/应用前——列表头位置边界] + 代次递增[dea12b：引入 gen+1 / 宏产宏单调]），净 +73 测试（34:39 偏差申报——验收面四段全正向）+ §7.3.1 审计集 80→90（J 节），**七类 7/7 双门槛达成**（第 7 类模块循环依赖 J06/J07 + seed 三形态——子阶段级 + 门审级首次全点亮），workspace 累计 624 绿，版本 0.10.0；实现侧运行语义缺陷 0（设计级预防补齐 1[rename-on-capture——E2E 前推演发现] + 设计修正 2[UnboundMacro 死变体删除 + nil 字面量拼写裁定]）。

**压实摘要**：
- 设计对齐（裁定十四/十五/十六 + 决策 13 项，plan-0.9.md §4）：**裁定十四 双机制卫生配套**（§9.38(b) 两算法 = 配套非择一：子集判据决定展开期绑定 + 重命名传导名字基后端[CoreExpr/字节码/VM 按 Var 名解析]；验证 = 引入参 `tmp__macro_0` 断言 + 可观察值[无卫生 200/有卫生 101] + make-adder 15/105 双向）/ **裁定十五 nil 字面量拼写**（reader 拒绝 `()`[0.3 决策 3] → syntax-rules 空字面量表 = `nil`——与语言空表全局拼写一致；文档-代码冲突以代码为准 §8.4.5）/ **裁定十六 统一未绑定判据**（头名无绑定 = 函数/宏二义 → Racket 统一 UnboundIdentifier；UnboundMacro 死变体删除——R1 桩纪律）/ 决策：DefineSyntax 第四变体零码记录、变换器帧内词法登记（isolate_frames 承接模块隔离）、分派序核心形式→宏→应用 + 保留名注册期拒绝、列表头位置边界、引入节点 span = 模板区间 + gen+1、拼接实参四保持、quote = 数据字面量面（§19.2 多阶段 quote/splice = Stage 2+ 区分登记）、模块交付 = 图验证 + 次序（可见性合并 = Stage 1）、平面命名空间 + 声明序确定性、CodeValue.symbols = 普查（free_variables = Stage 2+ 演进位）、缓存不实现（Stage 2 优化窗）、零规则合法。
- **设计级预防补齐 1**（§20.6 精神前置）：CoreExpr 名字基事实——展开层子集判据正确但 VM 按名解析 → 引入绑定与拼接实参同名时错误捕获；E2E 测试设计推演发现（非运行炸裂）→ rename-on-capture 机制补齐（触发集防碰撞 + 嵌套同名栈式遮蔽 + 拼接节点永不动）。
- 实现：内循环 7 轮（编译级 8[dev-dep 误用 ×3/lifetime ×2/导入/残留] + 设计级 3[预防补齐 + 死变体 + 拼写裁定] + 测试侧 7[bool 皮肤 #t/#f/期望反/span 使用位/遍历确定性/列期望] + clippy/fmt 尾清）。
- 测试：净 +73（code 5 + ctx +2 + transformer 12 + module 8 + expand +16 + error +2 + core +1 + 根集成 27；正负 34:39 ≈ 1:1.15 偏差申报——凑数违反 §12）+ 审计集 90 case（A-J 十节，cargo run exit 0）。
- 版本：workspace 0.9.0 → 0.10.0。

**关键裁定**（s）：裁定十四（卫生 = 双机制配套——子集判据 + rename-on-capture）；裁定十五（nil = 空字面量表拼写——语言全局一致性）；裁定十六（统一未绑定判据——死变体即桩）。

**溯源指针**：flat worklog Task 12-a（本里程碑详录）；交付实录 plan-0.9.md（含 §2 六命令实录 + §3 比例偏差申报 + §4 裁定十四/十五/十六 + 决策 13 项 + §5 边界九项 + §6 审计构成映射 + §7 投票 5.5/5.5）；测试文档 docs/tests/v0/stage0/plan/macro.md；审计集 examples/audit/stage0_gate_audit_r1.rs（J 节）。

# 06 · stage-0.5 compiler 种子（Task 8-a 压实摘要）

**1 行概述**：kerf-compiler 完整实现（CoreExpr→Bytecode 直译 + 跳转回填完备 + 常量池 NaN 规范化去重 + 全局 intern 单源 + debug_info 逐指令平行 + 尾位 If 留位 + 24 操作码双槽全解析 + COMPILE_DEPTH_LIMIT 1024 + CompileError 十三变体 + Bytecode::verify 公共校验面），48 新测试 1:3 + §7.3.1 审计集 40→50（F 节编译器负向），workspace 累计 300 绿，版本 0.6.0，七类维持 4/7，TD-003 消解一项（余 3）。

**压实摘要**：
- 设计对齐（裁定四 + 15 项决策，plan-0.5.md §4）：verify 公共面裁定（编译期簿记 fail-closed + `Bytecode::verify` DAG 基本块深度传播/结构校验两道防线——0.6 VM 加载钩子 + 手工坏产物负向面）/ 双入口（compile 单表达式 Halt 深度 1 / compile_program 深度 0）/ 24 操作码（§8.12 七分组 + Perform/Handle 承载扩展）/ 求值顺序契约（args 左→右 + 被调者栈顶——§19.5 peek(n) 对偶）/ 闭包 proto + n_locals 单调分配 / **尾位 If 留位**（分支直达终结指令无汇合 Jump——Stage 1 TCO 只改 Compiler）/ Assign Dup+Store 栈平衡 / Let = let\* 渐进 StoreLocal 链 / Handle 卸载边界截断尾位（尾位穿透 = Stage 2 EffectElimination 登记态）/ 常量池 NaN 折叠 + ±0.0 按位 / 全局 intern 不校验 STAGE0_GLOBALS（DAG 边纪律——校验归 VM 加载期）/ 1024 深度帽（三层帽序 reader 256 < expander 512 < compiler 1024）/ debug_info Span 除冷启动锚外零构造 / CompileError 十三变体（三变体无 Span——缺失的 span 即缺陷本身）/ manifest 零生产新边（core re-export 坐标类型扩展）。
- 实现：六模块（error/opcode/bytecode/verify/compile/lib）+ compile/compile_program 双入口；内循环 6 轮（**运行语义级实现缺陷 2**：Opcode 效应表 Dup/Swap 分组错位 + 非尾 If post_cond 取值时机——均当轮捕获修复零遗留；夹具/期望 5 + 编译级 2 + clippy 3 + fmt 2；教训 = 效应表逐 opcode 全量断言）。
- 测试：三层 48 case（32+8+8，正负 12:36）+ 审计集 50 case（A10+B10+C5+D5+E10+F10，cargo run exit 0）。
- 版本：workspace 0.5.0 → 0.6.0。

**关键裁定**（s）：裁定四 verify 公共面（两道防线 + 产物纯数据 + verify 唯一合法性判据）；尾位 If 无汇合 Jump 模式（TCO 留位——§19.3 陷阱一最小实现）；Handle body 尾位截断（handler 必须返回前弹出）；三层帽序事实（256/512/1024 逐层 2×——源码树结构性 ≤256，257..512 仅宏展开可产）；kerf-core 再导出坐标类型（消费面完整性传递，非新 DAG 边）。

**溯源指针**：flat worklog Task 8-a（本里程碑详录）；交付实录 plan-0.5.md（含 §4 裁定四 + 决策 15 项 + §6 审计构成映射 + §7 投票 5.5/5.5）；测试文档 docs/tests/v0/stage0/plan/compiler.md；审计集 examples/audit/stage0_gate_audit_r1.rs（F 节）。

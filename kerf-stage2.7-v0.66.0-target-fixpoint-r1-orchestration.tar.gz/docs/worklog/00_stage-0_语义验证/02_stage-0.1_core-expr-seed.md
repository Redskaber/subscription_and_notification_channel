# 02 · stage-0.1 core 表达式种子（Task 4-a 压实摘要）

**1 行概述**：TD-005/TD-004 双裁定落地 + kerf-core 完整实现（CoreExpr 九语义原语 + ModuleItem 声明层 + Symbol 校验标识 + visit_spans 遍历契约），48 新测试 1:3，workspace 累计 96 绿。

**压实摘要**：
- 设计对齐（首议程）：裁定一（TD-005）——r67 九语义原语（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）+ ModuleItem[Define/Require/Module] + do→Let；与 §3.2 冻结集经 §6.12.6 映射表双向闭合；八原语 ANF 形态登记为 Stage 2 评估目标（零信号不开窗）。裁定二（TD-004）——全节点必填 Span（非 Option，结构性无 DUMMY）+ 加边 L0→L4。
- 实现：symbol.rs（私有内芯校验构造——非空/无空白/无控制字符保守下限，CJK 保持合法留文法余地）+ error.rs（CoreError 三变体，R8 消息形态）+ expr.rs（九变体 + LiteralValue 六变体 + Binding/HandlerClause 带位点 + 前序 visit_spans + 九个 &str 校验构造器——0.4 展开器「源文本→已验证节点」契约）+ module.rs（三声明变体 + 嵌套遍历；成员唯一性/循环属 0.9 模块系统语义，登记延后）。
- 测试：三层 48 case（32+8+8，正负 12:36）；集成双向 span 归约（expander 形状程序折叠 + reader 形状 token→节点）= TD-004 边活性证明。
- 内循环 3 轮收敛：fmt 格式 → clippy 重复模块挂载（common 改 runner 单点挂载 + super:: 导入）+ unused 变量 → 全绿。
- 版本：workspace 0.1.0 → 0.2.0；WORKSPACE_VERSION 断言 env! 自洽化（勘误入裁定文附录）。

**关键裁定**（s）：TD-005（原语集真值落 expr.rs 单一事实源——SOP §21.12-11）；TD-004（Span 必填字段化）；module 成员唯一性延后 0.9（避免错误变体语义漂移——DuplicateParam 不复用于非参数场景）。

**溯源指针**：flat worklog Task 4-a（本里程碑详录）；裁定文 docs/develop/v0/stage-0/0.1-design-adjudications.md；交付实录 plan-0.1.md；测试文档 docs/tests/v0/stage0/plan/core.md。

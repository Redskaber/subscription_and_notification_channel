# 08 · stage-0.8 driver 种子（Task 11-a 压实摘要）

**1 行概述**：kerf-driver 完整实现（管线编排双引擎 Engine{Vm,Eval} + Session 文件 intern upsert + **TD-001 清偿** LineIndex 渲染期行列派生[1 基字符列——CJK 终端真值] + §8.7 诊断切片[41 变体穷尽映射 + Option 诚实无位] + rustc 风格多诊断渲染 + ParityReport 三面[值/输出/全局表——分歧数据化] + RunOutcome.globals halt 快照 + check 免执行面 + REPL session-replay[表达式 $repl:N 包装 + 错误回滚 + 单调输入带] + bin `kerf` run/check/repl + CLI 退出码 0/1/2），净 +124 测试（73:51 反向偏差申报——编排层主功能面）+ §7.3.1 审计集 70→80（I 节 driver E2E），**TD-003 清零（9/9 crate 全落位——0.0 章程终态）**，workspace 累计 551 绿，版本 0.9.0，七类 6/7 维持（**五类源可达错误类经 driver E2E 全点亮**——第六类宏展开深度 = 合成树专属[256<512 帽序结构性事实]）；消费面扩展 ×3（ReadError::offset / CompileError::span / kerf-compiler ModuleItem 再导出——全加法零回归）；当轮实现缺陷 2 闭环（TapeIo 记录语义 + stdin 预读条件化——§20.6 制度化为决策 8/11）。

**压实摘要**：
- 设计对齐（裁定十一/十二/十三 + 决策 12 项，plan-0.8.md §4）：**裁定十一 DAG 双新边**（L1→L8 REPL 表单分类直查 SyntaxObject——沿 L1→L3 直接消费者先例，0.0 脚手架声明实义化；L7→L8 eval 引擎函数调用面——类型可再导出传递、函数调用不可，沿 0.7 裁定十四加边先例；零环 + dataflow.md 同步）/ **裁定十二 REPL session-replay 语义**（引擎每程序一次性构造[0.7 程序隔离防御]→ 累积源整体重跑 + r110「top-level expression channel = define calling form」源级包装落位 + 错误回滚会话存活 + 单调输入带重放确定性 + 增量输出前缀尾部；O(n²) 披露）/ **裁定十三 TD-001 清偿形态**（§12.1 渲染期派生完整落位：LineIndex 单遍构建 + 字符列非字节列 + 中点取整钳制不 panic + Option<Span> 无位不伪造 DUMMY + 阶段级 DiagnosticCode[E0xxx = Stage 1+ 议程]）/ 决策：Severity 四变体结构面（仅 Error 有生产者）、children/suggestions 不入（R1 桩规避——0.10 议程）、访问器而非 41 臂匹配（§2.3-2 位置知识归错误本体）、run_parity 保活双引擎 + parity_repr（Display 坍缩 #<pair> 会假一致）、ParityReport 全局表面（0.7 观察面转正）、RunOutcome.globals（define-only 程序 halt=nil 的可观察结果面）、check = verify 显式面、TapeIo 同构记录（R3 缺陷制度化）、CLI 手工解析零依赖 + 退出码 0/1/2、run 模式 nil 静默、stdin 仅 run 预读（R3 缺陷制度化）、main 薄壳依赖注入。
- **当轮缺陷闭环（§20.6 同类全量制度化）**：① TapeIo::write_line 误 no-op（VmIo io 面 = 引擎输出唯一记录点——BufferIo 同构；no-op 致 REPL 输出恒空，E2E 实跑发现）→ 修复 + 决策 8 制度化；② main() 无条件预读 stdin（repl 提交行被吞）→ 仅 run 预读条件化 + 决策 11 制度化。
- 实现：内循环 7 轮（编译级 11[全编译/借用级零运行语义] + 测试侧 8[字节偏移手算错位族——0.3 教训同族实跑回读修正] + 实现缺陷 2 + 测试程序形态 3[define 函数≠调用] + 重写 1 + clippy/fmt）。
- 测试：净 +124（单元 93 + api 6 + 根集成 22 + 消费面扩展 5；正负 73:51 ≈ 1:0.7 反向偏差申报——凑数违反 §12）+ 审计集 80 case（A10+B10+C5+D5+E10+F10+G10+H10+I10，cargo run exit 0）。
- 版本：workspace 0.8.0 → 0.9.0。

**关键裁定**（s）：裁定十一（L1→L8/L7→L8 双新边——函数调用边必须显式）；裁定十二（REPL = session-replay——引擎一次性构造的既定设计下唯一确定性语义）；裁定十三（TD-001 = 渲染期派生 + 字符列 + Option 诚实——伪 span = DUMMY 同罪拒绝）。

**溯源指针**：flat worklog Task 11-a（本里程碑详录）；交付实录 plan-0.8.md（含 §4 裁定十一/十二/十三 + 决策 12 项 + §3 比例反向偏差申报 + §6 审计构成映射 + §7 投票 5.5/5.5）；测试文档 docs/tests/v0/stage0/plan/driver.md；审计集 examples/audit/stage0_gate_audit_r1.rs（I 节）。

# 05 · stage-0.4 expander 种子（Task 7-a 压实摘要）

**1 行概述**：kerf-expander 完整实现（展开→CoreExpr 九形式 + do→Let 链脱糖 + 域键控卫生解析 + 相位封闭 fail-closed + EXPANSION_LIMIT 512 预算 + ExpandError 七变体 + STAGE0_GLOBALS 18 名），48 新测试 1:3 + §7.3.1 审计集 30→40（E 节展开器负向），workspace 累计 252 绿，版本 0.5.0，七类错误 4/7 点亮，TD-002 裁定清偿。

**压实摘要**：
- 设计对齐（16 项 + TD-002 裁定三，plan-0.4.md §4）：双入口（表达式/程序分层——顶层仅声明）/ define 双形 + letrec 式顶层预绑定（fib 自引用）/ do→Let 链（§6.12.6——`_` 弃置名）/ let 双 spec + let\* 渐进绑定 / 头保留字平面分派（scoped-keyword = 0.9）/ nil 保留字面量 / STAGE0_GLOBALS 扁平全局表（§8.8——0.7 parity 钩子）/ 域键控解析（with_scope_added 生产化——0.2 契约兑现）/ 相位封闭（§8.9 规则 1 切片）/ 512 预算（独立界定合成树）/ set! 目标必须可解析 / module 域隔离 / ExpandError 七变体（Core 传播 source 链）/ 空表合成面复检（0.3 纵深防御第二层）/ core 构造器再断言（0.1 契约兑现）/ manifest 零生产边（kerf-span 仅 dev-deps）。
- TD-002 裁定（P3→P1 当轮清偿）：0.4 展开器**零 span 构造**（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生 → JoinExpansionMismatch 拒绝语义保持为设计行为 + 0.9 span 集合表示议程登记（非点合并）。
- 实现：四模块（error/ctx/expand/lib）+ expand/expand_program 双入口；内循环 6 轮（运行语义级实现缺陷 0——编译级可见性/闭包形态 2 + 夹具语义 2 + 比例修复 + R8 注释）。
- 测试：三层 48 case（32+8+8，正负 12:36——首轮 12:34 补 2 真实负向）+ 审计集 40 case（A10+B10+C5+D5+E10，cargo run exit 0）。
- 版本：workspace 0.4.0 → 0.5.0。

**关键裁定**（s）：TD-002 跨代 join = 结构性论证清偿（零构造即零跨代）；顶层裸表达式拒绝（r102「define 调用形通则」锚 + 0.8 driver 主通道）；域键控解析拒绝名匹配越权（foreign-scope 负向锚定——卫生骨架）；STAGE0_GLOBALS 单源 = 前端拥有表面契约（0.7 parity 断言钩子）。

**溯源指针**：flat worklog Task 7-a（本里程碑详录）；交付实录 plan-0.4.md（含 §6 审计构成映射 + §7 投票）；测试文档 docs/tests/v0/stage0/plan/expander.md；审计集 examples/audit/stage0_gate_audit_r1.rs（E 节）。

# 14 · stage-1.1 driver 接线（Task 18-a 压实摘要）

**1 行概述**：检查器入管线——`read → expand → typecheck → {compile, eval}` 全_faces 接线：**中止语义裁定**（Error 级执行前中止[确定错误程序不运行——静态检查净新增值] / Warning 级永不阻断[§2.3-4 警告级] / 收集不短路）+ **渲染汇合**（DiagnosticCode::Typecheck(TypeCode) 数据携带变体——tag = E0xxx 注册码，渲染形 `error[E0002]:` rustc 风格；stage-1-plan §4「接线处汇合」兑现）+ **警告摘要行**（`warning: N warnings emitted` abort 行前 rustc 序 + abort 门控修正[纯警告批次不误导] + 零警告批次字节不变[ds10 冻结]）+ **Outcome 警告通道**（RunOutcome/CheckOutcome/ParityReport + warnings 字段）+ **CLI 三命令警告路径**（err 汇 + 退出码 0 维持）+ **REPL 增量警告**（前缀规则与 outputs 同款——shown once/silent on replay/new is news；警告提交进入程序[合法]，仅错误回滚）+ **Externals 第三消费位**（单源双源构造）+ 新内部边 L4.5→L8 + 846→**881**（净 +35：17:18 对偶均衡）+ audit 120→**130**（N 节）+ v0.14.0。

**压实摘要**：
- 交付构成（MUV 18-a）：测试文档先行（driver-wiring.md）→ 五模块接线（pipeline/diagnostic/render/cli/repl）→ 内循环 3 轮（绑定点遗漏 ×2 + 测试语料语法事实 ×3[前向引用展开器拒绝 + handler fn 字面量 + set! 重绑触发 R2 护栏]——实现侧运行语义缺陷 0[连续六轮]）→ 六命令冷构建 881:0:0 → audit N 节 → 投票 5.5/5.5 → 文档族 → v0.14.0。
- **基线共变 5 处**（行为变更披露——已知元数错误静态化）：pipeline/driver_seed/audit-I04 运行期 arity 面改 checker-opaque 形态（`((fn (g) (g 1 2)) car)` 参数中介——R2 护栏正确跳过）+ ds03 黄金 E0002 静态形 + ds08 版本 0.14.0。
- **设计级验证发现 1 项**（非缺陷）：REPL `(set! car 1)` 重绑使后续 `(car 1 2)` 的 R2 正确跳过（assign 护栏跨提交生效——保守纪律实证；语料改用未重绑 cons）。
- dataflow L4.5 节点登记回补（1.0 漏更——§20.3 同族顺修）+ L4.5→L8 新边入图。

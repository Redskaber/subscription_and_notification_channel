# 03 · stage-0.2 SyntaxObject 种子（Task 4-b + 5-a 压实摘要）

**1 行概述**：tarball 回退恢复轮（r166 全量回退 → 0.1 基线 96:0:0 逐位复验）+ kerf-syntax 完整实现（SyntaxObject 四元组 + StxDatum 六变体 + StxSymbol 相位孪生 + Phase 二值 + ScopeSet 卫生基座 + visit_spans/深翻转），48 新测试 1:3，workspace 累计 144 绿，版本 0.3.0。

**压实摘要**：
- 恢复轮（Task 4-b）：用户指令裁定——kerf-stage0.1-v0.2.0-core-expr-seed-r1.tar.gz 解包替换项目与 worklog；diff -rq 归零实证 + 六命令 96:0:0 逐位恢复 + docs 三方一致（本地 = 文件仓库 = tarball）；r166 相关内容全量清除。
- 设计对齐（八决策，plan-0.2.md §4）：逐节点包装（List 成员 = 完整 SyntaxObject——§7.3.6 扩展 S 表达式 + §19.2 逐标识符作用域集）/ StxSymbol 相位孪生（与 core::Symbol 同下限异类型，&str 跨界）/ Phase 二值 + 相位封闭性归 0.4 / ScopeSet 有序去重（确定性迭代）/ ScopeId 无前缀 ID / with_scope_added 深翻转函数式（原则 23）/ 虚线对不建模（0.3 文法决策）/ Span 必填无 DUMMY（TD-004 延展）。
- 实现：五模块（symbol/error/phase/scope/expr）+ 零外部依赖手写 Error + 六构造器面（symbol 校验 + int/float/bool/string/list 直构）。
- 测试：三层 48 case（32+8+8，正负 12:36）；集成双契约锚定——token→stx 装配（0.3 reader）+ scope 翻转/span 归约/卫生并集（0.4 expander）+ TD-002 跨代次拒绝穿透。
- 内循环 3 轮收敛：`//!` 笔误 + Display 委托 → len_zero 复发（0.0 同族第二例）+ unused import → ∅⊆S 断言错误纠正（数学正确性优先）+ 负向补齐。
- 版本：workspace 0.2.0 → 0.3.0。

**关键裁定**（s）：StxSymbol = 管线相位孪生非重复类型（§21.12-5 辖共享类型；L1/L4 独立性保持）；相位封闭性 = 展开器不变量（数据层不交叉校验——诚实边界）；深翻转 = scope coloring 原语（函数式，原树不可变）。

**溯源指针**：flat worklog Task 4-b + 5-a（本里程碑详录）；交付实录 plan-0.2.md；测试文档 docs/tests/v0/stage0/plan/syntax.md。

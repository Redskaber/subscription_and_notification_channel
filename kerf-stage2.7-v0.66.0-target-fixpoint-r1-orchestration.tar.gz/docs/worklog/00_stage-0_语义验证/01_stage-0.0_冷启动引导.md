# 01 · stage-0.0 冷启动引导（Task 1-2 压实摘要）

**1 行概述**：从上游文档仓库冷启动 kerf——Cargo workspace（edition 2024，9 crate，§18.5 DAG）+ kerf-span 种子 MUV + Stage 0 规划（0.0-0.11）。

**压实摘要**：
- 环境（Task 2-a）：rustup stable 1.98.1 + rustfmt/clippy 装配（§3.1；nohup 后台进程被会话回收 → 改同步安装——流程教训）。
- 仓库（2-b）+ workspace（2-c）：docs 导入（sop.md v15.0 / stage0.md v9.8 内容态）；§18.5 精确建边；default-members 使 `cargo test` 原文覆盖全 workspace（§8.4.6 规则 7 落地）。
- 种子（2-d）：Span 四字段（FileId/ByteOffset×2/ExpansionId，stage0.md §8.6）+ 校验构造 + join 双轴拒绝 + 零外部依赖错误面；三层测试 48 case 正负 12:36=1:3。
- 规划（2-e）：stage-0-plan（§17 七步 DAG + 0.0-0.11 MUV 六字段表 + §21.9 矩阵对齐 + §13.1 四裁定代偿）；TD-001..006 登记；calibration 首数据点。
- 验证（2-f）：六命令全绿（clippy 1 处 len_zero 修复即收敛——内循环 1 轮）；门审冷启动适配裁定（≥30 case 义务自 0.3 起强制，理由入档）；单 Agent 五角色模拟投票 5/0（100% 加权）；§6.4 commit + §19 打包。
- 仪表盘（2-g，环境侧）：Next.js `/` 只读展示（沙箱可见性，非 kerf 仓库工件）。

**关键裁定**（s）：原语集以 SOP §21.12-11 r67 真值为准（TD-005 于 0.1 正式化）；VM 永久 Rust 基座写入骨架章程；lang-design 缺口以 stage0.md 单源代偿（不伪造拆分文件）。

**溯源指针**：flat worklog Task 1（激活路由轮）+ Task 2-a…2-g（本里程碑全部详录）；产物清单见 docs/develop/v0/stage-0/plan-0.0.md §4。

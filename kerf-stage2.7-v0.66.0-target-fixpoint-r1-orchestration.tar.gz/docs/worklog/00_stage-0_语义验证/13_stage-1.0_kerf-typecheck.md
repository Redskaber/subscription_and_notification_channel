# 13 · stage-1.0 kerf-typecheck 种子（Task 17-a~d 压实摘要——1.1 轮 §20.3 回补落位）

**1 行概述**：Stage 1 开工轮——kerf-typecheck 种子（L4.5 新 crate 五模块 1407 行）：**E0xxx 诊断注册面**（TypeCode E0001-E0008 + Severity Error/Warning + TypeDiagnostic R8 消息纪律）+ **保守静态 R1-R8**（确定性错误才报——每规则健全性论证：R1 未绑定[展开器第一道防线的结构层重断言] / R2 已知元数三通路[assign 护栏 + 词法遮蔽跳过] / R3 非布尔条件 / R4 不可调用被调者[含无重绑字面 Define 扩展终态] / R5 处理器元数 / R6 顶层未处理效应 / R7 字面处理器 / R8 赋值目标意外[首个 Warning 生产者]）+ **多错误收集**（裁定二十一：架构属性不占 E 码槽——check_module → Vec 全量遍历不短路；E0005 槽归 R5）+ **Externals 单源面**（from_named_arities——STAGE0_GLOBALS + Builtin::ALL 双源，kerf-typecheck 不复制清单）+ **TD-006 清偿**（stage0.md v8.8→v9.9 四处一致化——TD 账面归零）+ **stage-1-plan.md 落档**（1.0-1.9 排期 + R1-R8 权威定义 + PBT §18 裁定 DEFER-WITH-TRIGGER→1.2）+ 出阶段确认记录（用户指令 = §14.6.3 规则 5 确认位）+ 767→**846**（净 +79：43:36 负负对偶）+ audit 110→**120**（M 节）+ v0.13.0 + git 83bcfea。

**压实摘要**：
- 交付构成（MUV 17-a~d）：基准核验（r4 767:0:0 形式化 no-op）→ 17-b stage0.md 版本标签同步（TD-006）→ 17-c Stage 1 开工规划（stage-1-plan）→ 17-d kerf-typecheck 实施（测试文档先行 typecheck.md → 五模块 → 测试三层 → audit M 节 → 投票 5.5/5.5 → 文档族 → v0.13.0）。
- 层间分工披露：R1 = 第二道防线（直接构造路径）；R2-R7 = 净新增值（今日仅运行时可检错误的静态化）；R8 = 静默行为首个表面化。
- 位置感知可见性：顶层即时位 defines-so-far / Fn 体全定义可见（调用时 = 加载完成后——前向引用合法）；镜像双序（编译器 locals-then-globals + 展开器 define-so-far/letrec 预绑定）。
- 本条目由 1.1 轮回补落位（原会话 17-d commit 后上下文耗尽——rec 树 13 号件未及创建；§20.3 同族回补，详录见 plan-1.0.md + worklog Task 17-a~d）。

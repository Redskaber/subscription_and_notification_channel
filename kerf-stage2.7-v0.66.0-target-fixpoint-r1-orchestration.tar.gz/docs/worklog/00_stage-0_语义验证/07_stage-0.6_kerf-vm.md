# 07 · stage-0.6 vm 种子（Task 9-a 压实摘要）

**1 行概述**：kerf-vm 完整实现（§19.5 迭代主循环 + 堆帧栈无原生递归[TD-023 锚] + 24 操作码全执行 + 每帧操作数栈 + RuntimeError 十变体全携带 Span 回查[§12.1 消费行] + verify 加载钩子 + STAGE0_GLOBALS 18 名播种 + 分配预算 8MiB[§19.4 安全点 0.6 形态] + 可插拔 I/O），54 新测试 12:42 + §7.3.1 审计集 50→60（G 节 VM 负向），**fib(25)=75025 源码→值全链首次贯通**（§20.1 Week 3 判据），workspace 累计 356 绿，版本 0.7.0，七类 6/7 点亮（+参数个数 #4 +类型不匹配 #5），TD-003 消解一项（余 2）；同轮修复 0.5 缺陷 end_closure cur 递减（§20.6 同类全量 + 回归对 2）。

**压实摘要**：
- 设计对齐（裁定五/六 + 15 项决策，plan-0.6.md §4）：**裁定五 Call 栈布局调和**（§19.5 骨架 peek(n) 绘图 vs 0.5 编译器实际发射「args 先·被调者栈顶」——以代码为准[§8.4.5]，VM 按 `[args…, callee]` 消费）/ **裁定六 Perform 最小执行语义**（最近匹配 handler 动态查找 + handler 即函数调用——返回值即 Perform 值，真续延留 ext1 槽 Stage 1+；§9.1.1 预留层边界内最小完备）/ 六模块布局（value/builtin/error/frame/io/vm）/ Value 八变体 + eq_identity（f64 位级 eqv? 语义）/ 帧三扩展槽冻结（ext1/ext2 Reserved + ext3 调试帧实名）/ 每帧操作数栈（§19.5 leave_frame→push 忠实读法——0.5 per-proto depth 簿记对偶）/ 预算 = 终止界论证（无循环原语 → 增长必经分配——帧+堆单元合账）/ Halt 双形态（深度 0→Nil / 深度 1→弹值——0.5 双入口对偶；观察面 = global(name)）/ 内建固定 arity（`(+ 1 2 3)` 报 ArityMismatch 为 0.6 语义）/ 算术显式性（同种类 checked Int / IEEE Float；异种 TypeMismatch；NaN 一切比较 false）/ write-line 严格 Str + read-line Eof / 防御纵深分界（数据栈运行期检查 vs 操作数索引 verify 域）/ MakePair 休眠操作码全实现 / 闭包 env 捕获 dormant 载体（Stage 1 激活，帧布局零改动）。
- **0.5 缺陷修复（§20.6）**：`end_closure` 的 `cur -= 1` 在兄弟/嵌套闭包下发射错位（首个闭包 idx=1 巧合正确故 0.5 全绿）——嵌套 handle 测试触发 MissingTerminator → 临时转储定位 → cur_stack LIFO 修复 + 回归对 2（兄弟/嵌套闭包）+ cur 全使用点同类审查；verify 第二道防线在 VM 加载期拦截损坏产物（裁定四纵深防御实证）。
- 实现：内循环 6 轮（编译级 4 + 测试布局 3 + clippy 2 + fmt 1；VM 运行语义级缺陷 0）。
- 测试：三层 54 case（39+7+8，正负 12:42）+ 0.5 回归对 2 + 审计集 60 case（A10+B10+C5+D5+E10+F10+G10，cargo run exit 0）。
- 版本：workspace 0.6.0 → 0.7.0。

**关键裁定**（s）：裁定五（Call 栈契约以编译器实际发射为单一事实源）；裁定六（Perform = handler 即动态函数——预留层边界内最小完备）；预算 = §19.4 安全点 0.6 形态（0.7 gc_cycle 挂接点预留）；防御纵深分界（§19.5 陷阱二数据栈检查 vs 0.5 verify 操作数域——职责文档化）。

**溯源指针**：flat worklog Task 9-a（本里程碑详录）；交付实录 plan-0.6.md（含 §4 裁定五/六 + 决策 15 项 + 0.5 缺陷修复记录 + §6 审计构成映射 + §7 投票 5.5/5.5）；测试文档 docs/tests/v0/stage0/plan/vm.md；审计集 examples/audit/stage0_gate_audit_r1.rs（G 节）。

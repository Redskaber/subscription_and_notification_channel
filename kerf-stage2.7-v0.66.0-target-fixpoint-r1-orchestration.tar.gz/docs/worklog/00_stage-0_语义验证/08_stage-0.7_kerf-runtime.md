# 08 · stage-0.7 runtime 种子（Task 10-a 压实摘要）

**1 行概述**：kerf-runtime 完整实现（§19.4 标记-清除 GC 三阶段[显式工作栈 mark 防爆栈 + 线性 sweep + 对称复位] + Roots 五类根[四类 + handlers 扩展——0.7 发现的根集第五面] + Collector trait 依赖倒置[L6 挂接点/L7 算法] + collect-then-retry[live 计量 + 预算软超限→回收→重试] + eval 元循环九原语逐字对齐 + 18 builtin 单源分派 + parity 结构化 repr[地址不参与] + Evaluator 帧槽位环境 + EVAL_CLOSURE_PROTO 哨兵 + EVAL_DEPTH_LIMIT 2048），净 +71 测试（19:52 = 1:2.7 偏差申报——GC 防御族 12 全负向 + parity 验收本体）+ §7.3.1 审计集 60→70（H 节 runtime 负向），**双路径互查贯通**（≥15 程序 eval == VM 结构一致 + STAGE0_GLOBALS 三面官方断言 + E2E 源码→值 I/O parity + fib(25)=75025 注入回归），workspace 累计 427 绿，版本 0.8.0，TD-003 余 1（driver）；**P1 实现缺陷当轮闭环**（invoke saved-env 悬垂——GC 根集不完备的 eval 形态；temp 保护 + 程序隔离同类回补 §20.6）。

**压实摘要**：
- 设计对齐（裁定七/八/九/十 + 决策 14 项，plan-0.7.md §4）：**裁定七 GC 架构**（mark 位内置堆 + 编排注入算法 + 依赖倒置挂接——L6 定义 Collector trait/Roots 面、L7 实现 MarkSweep）/ **裁定八 预算安全点演进**（live 计量 + collect-then-retry + 双轨计数——无 collector 保持 0.6 fail-closed 零行为变化）/ **裁定九 eval 闭包**（基础闭包语义 + 登记簿 + EVAL_CLOSURE_PROTO 哨兵——env dormant 与 0.6 VM 载体逐字对偶）/ 裁定十（builtin 单源分派——双侧同函数体零漂移）。
- **P1 缺陷闭环（§20.6）**：invoke 换出 saved-env locals 不在 roots → 递归回溯悬垂读取（发现路径 = 预算测试构造审查——drop 模式 p 在 let 槽 = 活根，测试通过恰依赖错误回收）→ temp 保护修复（guard/truncate）+ 同类回补（apply/perform temp 契约 + eval_program/eval_expr 程序隔离）。
- 实现：内循环 7 轮（编译级 3 + 测试侧 4 + P1 悬垂 1 当轮闭环）。
- 测试：净 +71（runtime 42[gc 12 + eval 22 + parity 3 + api 5] + vm 演进 9 + 根集成 20；轮 19:52）+ 审计集 70 case。
- 版本：workspace 0.7.0 → 0.8.0。

**关键裁定**（s）：裁定七（GC = 数据结构内置堆 + 算法注入 L7——§21.12-10② 依赖抽象）；裁定八（collect-then-retry = §19.4「分配失败时触发回收」落位——无 collector 零行为变化兼容契约）；裁定九（eval 闭包 = 基础闭包对偶 + 哨兵 proto 不可冲突不变式）。

**溯源指针**：flat worklog Task 10-a（本里程碑详录）；交付实录 plan-0.7.md（含 §4 裁定七/八/九/十 + 决策 14 + §3 比例偏差申报 + §8 0.8 消费契约）；测试文档 docs/tests/v0/stage0/plan/runtime.md；审计集 examples/audit/stage0_gate_audit_r1.rs（H 节）。

# 构建指南（build-guide.md）

> 依据：docs/sop.md §3.1（环境）/ §3.2（验收）/ §18.4（外部依赖审查）。

## 工具链（Stage 0-1 必需项）

| 工具 | 安装 | 本仓库验证版本 |
|------|------|---------------|
| rustc + cargo | `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \| sh -s -- -y --default-toolchain stable --profile minimal` | 1.98.1 |
| rustfmt | `rustup component add rustfmt` | 1.9.0 |
| clippy | `rustup component add clippy` | 0.1.98 |

外部 crate 依赖：**零**（workspace 仅 path 依赖——任何外部依赖引入须先过 SOP §18 审查）。

## 验收命令（SOP §3.2，Stage 0-1 口径——交付前必须实际运行且全绿）

```bash
cargo clean && cargo build --release && cargo check && \
  cargo fmt --check && cargo clippy --all-targets -- -D warnings && \
  cargo test --release
```

- 根清单已配置 `default-members`（含根包 + 全部成员），故上述命令在仓库根目录执行即覆盖全部 10 个包（SOP §8.4.6 规则 7）。
- 选择性运行：`cargo test --test runner span_seed_tests::<case>`（模块路径即过滤器）；单 crate：`cargo test -p kerf-span`。

## 打包（SOP §19）

```bash
tar -czf /home/z/my-project/download/kerf-stage0.0-v0.1.0-bootstrap-span-seed-r1.tar.gz \
    src/ crates/ tests/ docs/ examples/ scripts/ tools/ benchmarks/ \
    Cargo.toml Cargo.lock README.md RELEASE_NOTES.md worklog.md .gitignore
```

（排除 `target/` 与 `.git/`；打包后验证存在且 >1MB。）

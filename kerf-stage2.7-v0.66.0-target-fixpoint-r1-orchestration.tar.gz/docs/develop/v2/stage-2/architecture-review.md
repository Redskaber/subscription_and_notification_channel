# Stage 2 架构设计审查（architecture-review.md）

> **Status**: 骨架（2.6 评估窗开启轮落位——r90 · v0.60.0；r91 · v0.61.0 现状基线更新——C 转译后端三层落地；r92 · v0.62.0 收口行——2.6 关闭 / Stage 2a 三判据 (1)(2)(3) 终核全过 + 七件套 2.6 行回写）；**终稿义务 = 2.8 Stage 2 末轮 L3 收口**（§14.6.6 七件套之一；本表为防骨架不填义务表——沿 1.8 GATE-4 骨架先例）
> **流程权威**：docs/sop.md §14.6.6 / §14.7（跨阶段架构审查协议——C1-C6 维度）
> **先例**：docs/develop/v1/stage-1/architecture-review.md（Stage 1 终稿形态）

## 1. 现状基线（截至 r90——骨架层快照）

- **管道架构**：reader → expander → typecheck → compiler → verify → VM/runtime 双引擎（eval 镜像 + VM 执行），Cargo Workspace edition 2024，crate 谱系 = kerf-span/syntax/core/symbol/reader/expander/compiler/vm/runtime/driver/typecheck + 根 kerf。
- **自举架构**：selfhost/v1/ 五件平铺（lexer 473 / reader 117 / expander 750 / macro 660 / compiler 1257 行）——FLAT 五件制裁定（66-b：.krf 无模块系统，目录化零语义增益）；harness 单装配点（Rust 构建引导——r90 裁决一维持）。
- **fixpoint 架构**：三相位驱动器（C(S) 双引擎 + C(C(S)) VM-only 括号 + 重建产品 VM 执行）+ 门 B 升格（gate_b_elevated 全语料结构化字节码全等）——判据 (1)(2) 双兑现（r88/r89）。
- **链外后端架构（实施位——r91 三层落地）**：C 转译路线（r90 裁决二）已实施——`crates/kerf-cbackend`（发射器：静态编址操作数栈 + goto 控制流 + 单 trampoline + 位模式常量池）+ `kerf_rt.h`（内嵌宿主 shim：值模型/字节 arena/18 内建单源分派/最短往返浮点显示）+ cc 门控 e2e（跳过披露不失败；语料 C 全量重放 41/41 + audit AA 274/274）。crate 为 DAG 纯消费叶子——零自举链引用（宪制维持）。
- **宪制边界**：8 原语冻结（第六十三轮维持）、VM 永久 Rust 基座、LLVM/本地码后端永不入自举链。

## 2. 2.8 终稿义务表

| # | 义务 | 承载证据面 |
|---|------|-----------|
| 1 | 每阶段（2.1-2.8）架构评分 + 建议（§14.6.6 表列） | 各子阶段 round-records + 本文档终稿评分表 |
| 2 | C1-C6 跨阶段维度清单核对（§14.7.1——阶段内路径/阶段间路径/高内聚低耦合/可插拔/数据流校验/路径缺漏） | driver.rs 交接点 + CompileResult 字段消费对账 |
| 3 | C 转译后端架构章（判据 (3) 工作位——发射器/shim/e2e 门控三层） | **已落地并终核（r91 实施 + r92 收口终核——语料 C 重放 41/41 复跑 + B9c 带内）**：§1 现状基线 + round-records #9.92/#9.93 + 代码实态（2.8 终稿时整理成章） |
| 4 | FFI 边界架构章（R-F1..R-F4 四规则的实施面映射——2.8 评估窗） | §9.91 裁决三 + FFI 实施位 |
| 5 | Stage 2 → Stage 3+ 架构移交清单（构建编排 .krf 化测量基线[B7/B8 公式]——r90 裁决一登记） | stage-2-plan §5 + roadmap |

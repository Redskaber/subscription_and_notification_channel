# stage-2 轮次记录移档（round-records.md）——§9.80-§9.85 实施细节

> 依据：docs/stage0.md 分层整理（2026-10-02 用户指令）——本档案承接 Stage 2 实施轮（§9.80-§9.85，v0.49-v0.54：LA 首刀 / 语义同刀 / 收口验证 / fixpoint 三 Pass / 组成链收口）的实施细节**逐字移档**。检索锚表/演进窗/线程关系/裁定族留驻 stage0.md；锚互指同前。

---

## 9.80 Stage 2 入口轮：门翻转与 LA-2 捕获描述符首刀第一工程 MUV（第七十九轮 · r79 · Task 57 · v0.49.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.80.1 门翻转记录（Stage 1 → Stage 2 第 4 要件）

- **解除句式命中**：第七十九轮用户消息首条指令 =「开放 stage 2 实施入口限制」——显式解除句式，语义 = stage-2-plan §0 第 3 条句式族「进入 Stage 2」/「开始 Stage 2」/「Stage 2 启动」族且解除方向更显式（点名 stage 2 + 点名实施入口 + 命令开放）；同消息条件句「只要有一个问题没有得到解决则禁止继续向前推进（每一轮都需要进行）」维持——**行权前置按第 3 条执行：十项复查全绿核验**（六命令冷跑 1261:0:0 + audit 200/200 + B 五轴带内{B4 gc 1/swept 1023 逐位一致} + TD 开放项 0{连续四十一轮} + 语料 82{31/41/10} + selfhost 三件 117/750/660 + 谱系 37 段在场 + 行动项锚维持 + 登记窗全零 + web 侧 T56 同步态 + 基准核验{doc 告警 1 cargo#6313 登记} + 裁定{历史审查发现全部实施或登记维持}）——禁令复活条件（问题未解决）不成立。**裁定：门第 4 要件 ✓ 行权闭合——Stage 2.1 词法寻址 + 捕获激活首刀即时开启**；门翻转登记三处：stage-2-plan §0 r79 解除注记 / roadmap v2.20 §7 / 本小节。
- **历史禁入链存档**：r54 登记（2026-09-30）+ r55-r78 二十四次重申（末次 r78）——凡二十五轮；期间阶段间轮 T34-T56（二十三轮）完成全管道审查谱系 §9.57-§9.79（用户点名清单十一阶段全主审 + 横切面三域清偿 + 用户点名域直承），Stage 2 自举段验证基础设施在禁入解除日即完备。


#### 9.80.3 LA-2 零消费落地实施（第一工程 MUV）

- **bytecode.rs**：新 `CaptureSource` 两源枚举（`Local(u32)` 定义帧槽位 / `Captured(u32)` 传递捕获索引——K189 同构）+ `FuncProto.captures: Vec<CaptureSource>` 字段（键于槽位/捕获索引非名字文本——§9.52.5 Symbol 身份基座用于编译期分析，产物落索引；`Bytecode` PartialEq 自然吸收——门 B 字节码全等口径零 codec 变更覆盖[compiler 尚无 .krf 记录面]）。
- **verify.rs**：Closure 位点扩展——callee proto 的捕获描述符逐条对**定义帧**（持有该 Closure 指令的 proto）校验：`Local(s)` 须 `s < definer.n_locals`；`Captured(k)` 须 `k < definer.captures.len()`（LA-4 传递边界）。编译产品恒空表（零生产），仅手工构建数据可及此臂——合法性裁判公共面扩展（plan-0.5 裁定 4 传统）。
- **error.rs**：新 `CaptureSourceOutOfRange { pc, func, index, span }` 变体——R8 形态（小写开头、无句尾句号、反引号载荷、技术锚保留）：``capture entry `N` of func `M` names a source outside the defining frame at pc `P```；span() 载 Closure 指令定位（驱动渲染 `-->` 位置行）。
- **compile.rs**：finish() 显式 `captures: Vec::new()`——零生产纪律（编译器捕获分析[LA-1/LA-4 自由变量分析]随语义 MUV 落地）。
- **守卫 +10**（库内 6 + 根树 4）：库内 = bytecode 字段默认空与 PartialEq 吸收（2）+ error R8 形态与 span（1）+ verify 接受界内双源（1）+ 拒绝 Local 越界（1）+ 拒绝 Captured 空表越界（1）+ 拒绝 Captured 超定义者表长（1）；根树 lexical_capture_guard_tests.rs（§8.4.6 跨 crate 断言入根）= 全语料 sweep 零生产（预登记语义翻转锚——§9.51.2 锚族同族，LA-1/LA-3 语义 MUV 落地日翻转）（1）+ 手建描述符 verify/等值双方向（1）+ 单源双编译一致（含 captures 字节同一——确定性缝）（1）+ CorpusCase 双引擎 e2e 语义未动（闭包体 n 仍解析为全局 define——翻转前行为双引擎一致）（1）。
- **涟漪审计**：FuncProto 全部 11 构造站点经 `FuncProto::new`（字段默认零破坏）+ finish() 唯一字面站点已补 + VM/runtime/typecheck 零消费者（休眠设计不变）+ ds08 金链 0.48.0→0.49.0 + dump_bytecode 不打印 captures（快照黄金零 re-bless）+ audit 注册计数不变（200/200——新守卫测试不入 audit 登记簿，沿 T50-T56 守卫轮先例）。


#### 9.80.4 验收

六命令 1261→**1271:0:0**（+10 守卫：库内 6 + 根树 4；1258 语料存量全存活——零生产纪律构造性无扰动实证）+ audit **200/200** 维持 + fmt 零 diff + clippy `-D warnings` 零告警 + doc 告警 1{cargo#6313 登记}；B 五轴全带内：B1 7.0µs / B1a 1.0 / B1b 3.5 / **B1c 1.5µs 逐位一致（描述符空表对 compile+verify 零成本）** / B2 82.5ms / B3 7.4ms / **B4 gc-cycles 1 / swept 1023 逐位一致** / B5 81.4ms。


#### 9.80.5 2.1 剩余面（MUV 2/3 排期——stage-2-plan §2/§3 单源）

- **MUV 2（语义同刀）**：LA-1 作用域栈穿透（begin_closure 穿透外层 locals 快照 + 自由变量 (depth,slot) 解析）+ LA-3 LoadCaptured 操作码族（K192 同构——Opcode::ALL 24→25 + pops/pushes 单源表 + subset-spec §3.3 共变）+ LA-4 传递捕获（编译器侧 Steensgaard 自由变量分析内化——K45 最小捕获集判据）+ LA-5 求值器镜像（"MIRRORS, never invents"）+ **LA-6 语义翻转锚族**（§9.51.2 四锚{neg-045 期望翻转 + negative_parity_basic_closure_free_name 双引擎对偶翻转 + closure_captures_env_and_calls_through_frames 全帧快照断言翻转 + let_assign_perform_handle_forms 槽位布局复定} + HM FnBody 可见性翻转 + 检查器镜像 + 语料闭包密集正案/捕获边界负案/传递捕获案扩展 + 本轮零生产 sweep 锚翻转）——双引擎同翻纪律（parity 安全网）。
- **MUV 3（2.2 收口验证轮）**：门 B 双口径全管线复跑（字节码全等含 captures 字段）+ 子集规格语义面捕获章节共变 + B1-B5 基线对账 + 校准 T2.1-T2.2 行回填 + ★1' 双成本化解实证（闭包创建 O(n_locals)→O(captured) + GC 保留精确化）。


#### 9.80.6 门状态（翻转后）

**Stage 2 实施入口 = ✓ 已开启（r79 解除——2026-10-01）**：用户显式解除句式 + 行权轮十项全绿前置核验通过；门翻转登记三处（stage-2-plan §0 r79 解除注记 / roadmap v2.20 §7 / 本小节）。**本轮 = Stage 2.1 首个工程 MUV**（LA-2 零消费落地 v0.49.0）；剩余面 = 语义同刀 MUV + 收口验证轮（§9.80.5 排期）——2.1 内按 stage-2-plan §3 工程分批裁定，批间 feature 无关中间态保持全绿。


#### 9.80.8 收敛口径

第七十九轮 = **Stage 2 开启轮（门翻转轮 + 首个工程 MUV）**：8 原语不变性第五十三轮验证（描述符 = 编译产品结构面非语言面——零新原语、零通道、零 VM 变更、零语法增量、零记录文法变更[compiler 无记录面]）；每轮阻断条款十项复查全绿（第七十九轮——含门行权前置核验）；管道面零语义变化（B1c/B4 逐位一致双实证 + 语料双引擎 e2e 未动）；零新外部依赖（CaptureSource = kerf-compiler 内部面扩展——§18.5 维持）；TD 开放项 0 维持（第四十二轮）；语料 82 与 selfhost 三件维持；用户常设指令六项闭环（不冻结 / 规划{stage-2-plan + roadmap v2.20 + §9.80 三面规划共变} / Stage 2 实施入口开启{LA-2 落地} / 每轮十项检查全绿 / web 同步待 57-web / 打包待 57-pkg）。



---

## 9.81 Stage 2.1 MUV 2 语义同刀轮：词法捕获激活（第八十轮 · r80 · Task 58 · v0.50.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.81.1 本轮性质与行权前置

第八十轮 = **Stage 2.1 语义同刀 MUV**（stage-2-plan §3 工程分批的第二批：LA-1/LA-3/LA-4/LA-5/LA-6 双引擎同翻——「同一刀切面」的语义面兑现，LA-2 零消费中间态翻转）。行权前置十项复查全绿（六命令冷跑复现 1271:0:0 + audit 200/200 + B 五轴带内{B1c 1.5µs / B4 gc 1/swept 1023 逐位一致} + TD 开放项 0{第四十二轮} + 语料 82{31/41/10} + selfhost 三件 117/750/660 + 谱系 38 段在场 + 行动项锚维持 + 登记窗全零 + web 侧 T57 同步态 + 裁定{历史审查发现全部实施或登记维持}）——禁令复活条件不成立，行权有效维持。


#### 9.81.2 LA-1/LA-4 编译器捕获分析（kerf-compiler）

- **ProtoState 扩展**：`captures: Vec<(Symbol, CaptureSource)>`（分析侧名字键表——首用序，产物表落索引）+ `parent: Option<usize>`（begin_closure 记录定义者链——entry 恒 None，顶层自由名走全局不变）。
- **解析三叉**（Var 臂）：own locals → `LoadLocal`；enclosing 链持有 → 捕获读 `LoadCaptured k`；否则 `LoadGlobal`（dormant 期行为对无人绑定的名维持不变）。
- **capture_in_cur / held_by 递归**（LA-4 传递捕获内化——Steensgaard 自由变量分析 + K45 最小捕获集判据）：held_by(holder, name) = holder 局部槽 → `Local(s)`；holder 既有捕获 → `Captured(k)`；否则经 parent 递归并使中间 proto 增补 pass-through 捕获（中间体自身代码零读取合法——其消费位点是嵌套 `closure` 指令的 Captured(k) 源）。健全性论证：holder.locals 在 fn 表达式位点 = 恰好该处活跃绑定集（mark/truncate 纪律），`closure` 指令同位点发射 → 每个记录槽位在 VM 拷贝时必有值。
- **finish() 翻转**：显式 `Vec::new()` 零生产 → 分析表落地为产物描述符表（LA-2 中间态终结）。
- **确定性**：深度优先编译游走 + 首用序 = 产物表逐字节确定（门 B 字节码全等口径自动吸收——`Bytecode` PartialEq）。


#### 9.81.3 LA-3 VM 执行域（kerf-vm）

- **Opcode::LoadCaptured**（操作码 24→25——K192 分离操作码族裁定；**StoreCaptured 不落地**：LA-7 不可变捕获子集下零发射位点 = 死码，登记 LA-7 后续窗随可变捕获[装箱单元 K44/K53 路线]再入）。`a: capture index`；pops 0 / pushes 1；ALL 常量 + kind_name + operand_help + 单源表共变；stage_exit 基数守卫 24→25 + audit V06 25 同翻。
- **Frame.captured: Vec<Value>**（独立 Vec——§9.51.2 第 1 行裁定：冻结 3-ext 块不动；invoke 时从闭包单元 env 安装；entry 恒空）。
- **Opcode::Closure 选择性拷贝**：全帧 `locals.clone()` 退役 → 按 proto.captures 逐源拷贝（Local(s) → 定义帧 locals[s]；Captured(k) → 定义帧 captured[k]）——**★1' 双成本化解第一面落地**（O(captured) 非 O(n_locals)；GC 保留精确化第二面 = 2.2 收口对账）。
- **verify**：LoadCaptured 界检查（`a < f.captures.len()`——新变体 CaptureIndexOutOfRange{pc,index,span}，R8 形态）；T57 的 Closure 位点定义帧界检查维持。
- **roots 完整性**：snapshot_roots 的 locals 根类并入 frame.captured（§19.4 完备性——帧邻接活跃态）。


#### 9.81.4 LA-5 求值器镜像（kerf-runtime）

- **Env.captured: Vec<(Symbol, Value)>**（own names → captured → globals 三级解析序 = 编译器镜像；"MIRRORS, never invents" 契约）。
- **free_names 自由变量分析**（LA-4 求值器侧内化）：body 自由名首遇序收集（Fn/Let 绑定遮蔽感知）；**Assign 目标计入引用集**——LA-7 边界在 invoke 时可判定（外层作用域已消亡，捕获区是唯一证据载体）。
- **make_closure 选择性捕获**：free 名 ∩ 当前环境解析 = 捕获对（K45 最小集镜像）；**temp 显式根**跨越 reserve→alloc 窗口（collect-then-retry 周期不得清扫在途捕获值——§19.4 显式根类）。
- **invoke 安装**：闭包单元 env（堆上——GC 经 closure 追踪既有面）zip 注册表 captured_names 重建帧环境；**saved 环境根保护扩展**（temp.extend(saved.captured)——缺失则调用者帧捕获值在 callee 执行期可被回收）。
- **collect_now 根集扩展**：当前 env.captured 并入 locals 根类（帧邻接镜像）。
- **EvalClosure 注册表**：captured_names: Vec<Symbol>（仅名字——值驻堆单元，杜绝 Rust 侧未根值）。


#### 9.81.5 LA-7 边界与三层防御

Assign-to-captured = 确定拒绝（不可变捕获子集——首刀裁定维持）。三层单源字典族：**E0012**（检查器——TypeCode::AssignToCaptured 入注册表 E0001..E0012；Fn 臂捕获区边界索引 captured_marks 栈 + Assign 臂「own 区命中否 / 捕获区命中是」判定；遮蔽 let 使目标回落 own 区 = 合法存储）+ **CompileError::AssignToCaptured**（编译器直接构造面防御——resolves_outer 只读探测不物化捕获项）+ **RuntimeError::AssignToCaptured**（求值器直接 API 防御——消息与编译器同族措辞 `cannot assign to captured variable \`n\` (captures are immutable in the current subset)`）。HM 零变更（env 本就穿透 Fn 体——§9.51.2 第 13 行「预镜像」实证：良型程序集扩展自动成立）。


#### 9.81.6 LA-6 语义翻转锚族翻转实录（§9.51.2 预登记全兑现）

| 锚 | 翻转前 | 翻转后 |
|----|--------|--------|
| neg-045-closure-no-capture | type-error E0001 | **pos-034-closure-capture：value 8**（重命名入正案族——neg 前缀语义归位） |
| negative_parity_basic_closure_free_name_is_unbound_on_both | 双引擎 UnboundGlobal x | **positive_parity_basic_closure_captures_on_both：双引擎 value 6** |
| closure_captures_env_and_calls_through_frames | data.env == 全帧 [Int(7)] | **closure_env_is_selective_and_captures_flow_through_frames：空表[无描述符] + 描述符流经帧往返 value 9** |
| closure_free_name_stays_unbound_and_dormant_capture_keeps_the_snapshot（eval crate 内锚） | UnboundGlobal x | **closure_captures_the_let_binding_beyond_its_scope：r == 6** |
| r1_fn_body_does_not_see_enclosing_fn_params（checker 内锚） | E0001 | **r1_fn_body_sees_enclosing_fn_params_as_captures：零诊断** |
| corpus_compiles_with_zero_capture_production（T57 预登记 sweep 锚） | 全语料零生产 | **corpus_capture_production_flips_on_and_stays_minimal：≥1 产物捕获 + 每描述符消费证明{直接 load-captured ∨ 嵌套 pass-through}——K45 最小性传递感知** |

语料扩展四件（82→85）：pos-034（翻转件）+ pos-035 闭包密集正案（兄弟闭包独立捕获 + 参数遮蔽捕获名[`(fn (a) (* a b))` 内 a 遮蔽外层 a]→ value 23）+ pos-036 传递捕获案（三层链 base/offset 经 mid pass-through → value 60）+ neg-057 捕获边界负案（E0012 首案）。expander 层计数 74→77（neg-045 移出 + 4 件移入）；gate B 轴 (a) 资格面扩展（oracle compile 成功——编译期拒绝件无字节码产物可比对，拒绝面归语料 harness 所有）。


#### 9.81.7 验收

六命令 **1283:0:0**（1271 存量全存活 + 净 +12：compile 捕获族 4 + checker 2[翻转 1 + E0012 1] + verify 2 + eval 翻转 1 + vm 翻转 1 + 守卫 sweep 族增量）+ audit **200/200**（V06 基数 25 同翻——授权扩展非漂移）+ fmt 零 diff + clippy `-D warnings` 零告警 + doc 零告警 + 非英文编码面扫描清零（23 变更文件全英文）。B 五轴：B1 7.5µs / B1a 1.1 / B1b 4.0µs{+11% 结构性：父链字段 + 分派臂——25% 噪声带内} / **B1c 1.6µs{1.5→1.6 +6.7% 带内：per-proto 新字段初始化 + 新分派臂——fib 无捕获故非语义成本}** / B2 83.8ms / B3 7.9ms{+7.5% 带内：invoke 安装面} / **B4 gc 1/swept 1023 逐位一致**{churn 基准无闭包——GC 根集扩展零扰动实证} / B5 84.1ms——全轴 25% 带内，结构性微增如实登记。


#### 9.81.8 收敛口径与 2.1 剩余面

第八十轮 = **Stage 2.1 语义同刀 MUV**：8 原语不变性**第五十四轮**验证（捕获 = 编译器内部作用域分析 + VM 执行机制 + 求值器镜像——零新原语、零通道、零语法增量、零记录文法变更；操作码 +1 为 §9.80.2 K192 预裁定授权扩展）；每轮阻断条款十项复查全绿（第八十轮）；双引擎 parity 构造性维持（语料 85 双引擎 e2e + DISPATCH_PROBES 18 + 十五程序电池全绿——语义同翻纪律兑现）；零新外部依赖；TD 开放项 0 维持（第四十三轮）；**2.1 剩余面 = MUV 3 收口验证轮**（§9.80.5 排期维持：门 B 双口径全管线复跑[含 captures 字段] + 子集规格语义面捕获章节 + B1-B5 基线对账 + ★1' 双成本化解实证[闭包创建 O(n_locals)→O(captured) 量化 + GC 保留精确化] + 校准 T2.1-T2.2 行回填）。



---

## 9.82 Stage 2.2 首刀收口验证轮：门 B 全管线复跑与 ★1' 量化实证（第八十一轮 · r81 · Task 59 · v0.51.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.82.1 行权前置十项复查（第三次维持）

第八十一轮开工前置（stage-2-plan §0 第 3 条前置有效性条件——问题未解决则禁令复活）：① 六命令冷跑 **1283:0:0** 完整复现（cargo clean 后 release 全链 + RUST_MIN_STACK 环境注记沿 r115/r117 OBS）② audit 200/200 ③ B 五轴带内——B1 7.0µs / B1a 1.0 逐位 / B1b 3.5µs / B1c 1.5µs / B2 82.8ms / B3 7.95ms / **B4 gc 1/swept 1023 逐位一致** / B5 82.9ms ④ TD 开放项 0（第 44 轮维持）⑤ 语料 85{pos 34/neg 41/bnd 10} ⑥ selfhost 三件 117/750/660 ⑦ 谱系 39 段在场（§9.43-§9.81）⑧ 行动项锚维持（K189-K192 + K43/K45/K51 既有——本轮验证域零新检索，审查收敛于既有锚族，T58 先例）⑨ 登记窗全零信号维持 ⑩ web 侧 T58 同步态（API 第八十轮/1283/v9.47 = kerf HEAD aa248df 一致）。**裁定：禁令复活条件不成立——Stage 2 实施入口 ✓ 已开启维持（r79 解除 + r80/r81 两次维持复验）。**


#### 9.82.2 门 B 双口径全管线复跑（字节码全等含 captures 字段）

- **轴 (a) 字节码全等**：全语料 sweep 维持（85 案资格面——oracle 管线接受者全量过 `gate_b_bytecode`，含捕获三案 pos-034/035/036——**`FuncProto.captures` 经 `Bytecode` `PartialEq` 自然进入等价判据，描述符漂移即字节码漂移**）；本轮新增**捕获密集复合锚**（`gate_b_holds_on_a_capture_dense_composite`：宏 `wrap` + 两级传递捕获链 `outer→mid→inner` + 尾 if——oracle 编译产物 vs .krf 重建产物字节码全等 + 双引擎值一致 10 + 传递源 `Captured(k)` 与 `load-captured` 在场断言）——全管线复跑以复合锚 + 全语料 sweep 双面承载。
- **轴 (b) 自应用幂等**：mp10/T10/V02 既有自应用锚随六命令全绿复跑（装配源自应用字节码全等维持）。
- 描述符漂移双向守卫（既有 `hand_built_descriptor_round_trips_verify_and_equality`：同表等 / 异表不等 + 越界拒验）维持。


#### 9.82.3 子集规格语义面捕获章节完整重写（subset-spec.md §2.1）

MUV 3 排期义务兑现：§2.1 从先行翻转态升格**七条完整语义面**——① LA-1 捕获合法性与解析序（三叉 + 顶层永不捕获）② LA-2 描述符两源（K189 同构 + K45 最小集消费证明）③ LA-3 VM 执行语义（选择性拷贝 O(captured) + invoke 安装 + verify 界检查）④ LA-5 求值器镜像（MIRRORS 契约）⑤ LA-7 不可变边界（E0012 + 可变捕获后续窗）⑥ 门 B 吸收（2.2 收口实证）⑦ ★1' 双成本化解实证（量化数字注入）+ 历史语义注记保留 + 头部 Status 注记 + §3.3「2.2 收口注记」。


#### 9.82.4 ★1' 双成本化解量化实证（登记注销）

- **成本轴（O(captured) 非 O(n_locals)）**：① 结构证（守卫 `capture_table_and_env_size_are_the_capture_count_not_the_frame_width`：C/K ∈ {1/3, 1/49, 7/43} 三形态——描述符数 = C、帧宽 = C+K、运行期 env 尺寸 = C；1/3 vs 1/49 即化解证明：帧宽 4→50 槽逐创建拷贝恒一值）② 时序证（**B6 基准轴首录**——纯指令级隔离：手工字节码万次 `closure;pop` 展开循环；B6a C=1/N=4 median **47.8ns** vs B6b C=1/N=100 median **47.7ns**——帧宽 25× 成本持平（−0.1ns 噪声带内）= 宽度无关性实测；B6c C=25/N=100 median **222.2ns**——固定成本 ~40ns + **~7.3ns/捕获**线性）。dormant 时代对照：全帧克隆成本 ∝ N（B6b 形态下将为 ~25× B6a），现 ~47.7ns 与 N 无关。
- **保留轴（GC 保留精确化）**：确定性计数守卫（`gc_cycle_sweeps_exactly_the_uncaptured_locals`：八 pair 局部 + 捕获一值 → run 后显式 §19.4 周期 **swept 恰 7 / marked 3 / live 10→3**——闭包单元 + 捕获 pair 存活且 env[0] 仍可读 car=1；dormant 快照下 env 含全部八 pair → 同周期 swept 将为 0）。GC 根集扩展（帧捕获区并入 §19.4——r80）与 B4 逐位一致（churn 基准无闭包）共同构成保留面零回归证据。
- **注销**：§9.51.3 ★1' 登记条目追加注销注记（登记义务履行完毕，转历史登记）。


#### 9.82.5 B1-B5 基线对账与 B6 首录

全轴带内（r80 对照）：B1 7.5→7.0µs / B1a 1.1→1.0（逐位级）/ B1b 4.0→3.5µs / B1c 1.6→1.5-1.6µs（均值 1.9 受单跑离群 stdev 7.8 拉高——median 1.6 判定带内）/ B2 83.8→82.8ms / B3 7.91→7.95ms（+0.5%）/ **B4 gc 1/swept 1023 逐位一致（零 GC 语义漂移第五次连续）** / B5 84.1→82.9ms——**语义翻转（r80）后首轮全量对账：零回归**。B6 三面首录落档（47.8/47.7/222.2ns——上表）。基准文件 r81 行 + B6 轴表行新增。


#### 9.82.6 audit W 节（捕获激活族端到端——200→210/210）

十 case：W01 E0012 边界（check_source 端到端 + 渲染码 + 措辞族）+ W02-W04 三值面（pos-034/035/036 形态双引擎 agrees + globals_repr 末位 8/23/60）+ W05/W06 verify 双源越界（Local(2) 过二槽定义帧 / Captured(3) 过一元捕获表 → CaptureSourceOutOfRange）+ W07 顶层非捕获（全 proto 空表 + global 解析维持）+ W08 ★1' 成本轴（五十槽帧 env 恰一）+ W09 ★1' 保留轴（swept 恰 7）+ W10 门 B 捕获密集复合。V08 节清单补 W01；头doc 组成表补 Section W；最终 println 210/210。**GATE 5 构成**：全集 210 ≥ 30 ✓；七类错误覆盖维持（E0012 新错误类端到端在列）；上轮修复边界（r80 六锚翻转族）经 W02-W04 + 既有锚复跑覆盖 ✓。


#### 9.82.7 验收

六命令 **1286:0:0**（1283 存量全存活 + 净 +3：capture_cost_guard_tests 新文件三测——env 尺寸三形态结构证[正向] + GC swept 精确计数[负向观察面：非捕获局部必被回收] + 门 B 复合锚[跨阶段消费：compiler→vm→runtime collect→driver gate_b]）+ audit **210/210** + fmt 零 diff + clippy `-D warnings` 零告警 + doc 零告警 + 非英文编码面扫描清零（新文件全英文注释/消息）。正负比：本轮增量以确定性断言与负向观察面为主（守卫负向 2 + audit 负向 3[W01/W05/W06]），全树正负比 ≥1:3 维持。语料 85 维持（零语料增量——2.2 为验证轮非语料轮）；selfhost 三件 117/750/660 维持（零触碰）；B 六轴全带内 + B6 首录。


#### 9.82.8 收敛口径与 2.1 关闭（下一入口 = 2.3 fixpoint 窗）

第八十一轮 = **Stage 2.2 首刀收口验证轮**：8 原语不变性**第五十五轮**验证（纯验证域——零生产 crate 语义变更，捕获族守卫全为只读观察面 + 手工字节码构造；零新原语零通道零 VM 变更零语法增量零操作码增量）；每轮阻断条款十项复查全绿（第八十一轮——第三次维持）；**2.1 词法寻址 + 捕获激活首刀三 MUV 链闭合**（r79 描述符零消费 → r80 语义同刀 → r81 收口验证——LA-1..LA-7 全兑现 + 门 B 全管线 + ★1' 注销 + 子集规格完整重写）；TD 开放项 0 维持（第 45 轮）；零新外部依赖；零新检索（审查收敛于 K43/K45/K51/K189-K192 既有锚族——验证域轮 T58 先例）。**下一入口 = Stage 2.3 fixpoint 窗开启轮**（compiler 自举三阶段 A 阶段——compiler .krf 重写第一 Pass：编译期纯函数面优先；K13-K17 锚沿袭 + 逐 Pass parity 骨架 + 零新外部依赖——stage-2-plan §2 行 2.3 单源；行权轮十项全绿前置每轮维持）。





---

## 9.83 Stage 2.3 fixpoint 窗开启轮：compiler 词法域分析第一 Pass（第八十二轮 · r82 · Task 60 · v0.52.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.83.1 行权前置十项复查（第四次维持）与中断残留恢复

第八十二轮开工前置（stage-2-plan §0 第 3 条前置有效性条件——问题未解决则禁令复活）：① 六命令冷跑 **1286:0:0** 完整复现（cargo clean 后 release 全链 + RUST_MIN_STACK=268435456 环境口径沿 r115/r117 OBS §9.51.8）② audit 210/210（A-W 二十二节）③ B 五轴带内——B1 7.5µs / B1a 1.1 / B1b 3.9µs / B1c 1.6µs / B2 med 83.2ms / B3 med 7.9ms / **B4 gc 1/swept 1023 逐位一致（第六次连续）** / B5 83.7ms / B6a-c 47.0/46.7/222.8ns 复现 ④ TD 开放项 0（第 46 轮维持）⑤ 语料 85{34/41/10} ⑥ selfhost 三件 117/750/660（+compiler.krf 758 第四件本轮入册）⑦ 谱系 40 段在场（§9.43-§9.82）⑧ 行动项锚维持（B 审先行 K193-K197 五新锚——60-b 子代理七查，强 5/弱 2 诚实降级）⑨ 登记窗全零信号维持 ⑩ web 侧 T59 同步态（API 第八十一轮/1286/v9.48 = kerf HEAD 2871672 一致）。**裁定：禁令复活条件不成立——Stage 2 实施入口 ✓ 已开启维持（r79 解除 + r80/r81/r82 三次维持复验）。**

**中断残留恢复（24-d 先例）**：上轮会话中断留下两未跟踪件——`selfhost/v1/compiler.krf`（初稿 731 行）+ `tool-results/r82-search/`（60-b 存档）——kerf 侧 worklog 零 T60 记录。恢复核验轮逐数复检发现**四处实质缺陷**（详见 9.83.6）：括号失衡 ×2 + 产品形状 doc/impl 失配 ×1 + 嵌套 pair 字面量塌陷 ×1——全部在 parity harness 首跑前由恢复核验与首轮 sweep 拦截并清偿，worklog 全程留痕。


#### 9.83.4 CP-4 错误轴与深度镜像（eval 输入包络 + VM-only 面）

- **可达拒绝族**（compile_program 实况：finish() 仅 unpatched-jump 防御，verify 为独立阶段）：`assign-to-captured`（LA-7 编译侧面——E0012 检查器侧面的姊妹层）+ `depth`（COMPILE_DEPTH_LIMIT 1024 镜像，`depth: 1025` 载荷 + 越界节点 span）。krf 侧发 `("err" kind payload...)`，宿主 `rebuild_compile_error` 重建 `CompileError` 并经 oracle 自身 `Display` 渲染（字节 parity 构造性透明——kind/payload/span 选择是被测面）；`bad-node` 臂 fail-closed（流词汇表破裂 = harness defect 永不归为源缺陷）。
- **深度镜像边界**（手建树——reader 256 帽使文本源远低于编译深帽；1023 层 else 链 if + define 项帧 = 峰深 1025）：1022 层峰 1024 恰过 / 1023 层峰 1025 结构化拒绝——双侧同 span。
- **eval 输入包络登记**：eval 引擎 2048 调用深帽**低于**编译深帽在流装配器每层 ~2 帧递归上的可达面（1024 层树需 ~2050 帧）——双引擎面在该深度返回诚实 `harness limit` 分类（r74 谱系，K165 位点分类纪律），**VM-only 面**（`compiler_parity_items_vm`——VM 无帧深帽）承载深度镜像全验证；包络本身被测试钉扎（分类措辞 + eval 位点断言）。


#### 9.83.5 CP-5 三层路由与语料 sweep（reader 8 / expander 19 / compiler 58）

- **路由**：reader 拒绝 → Reader 层（1.5 段自有面，krf 不运行）；expander/loader 拒绝 → Expander 层（1.6/1.7 段自有面——无展开树可析）；其余 → Compiler 层（双引擎 + oracle 对拍）。**typecheck 层永不决断 CP 案例**：检查器与编译器是同一展开树的独立消费者，分析产品在检查器拒绝的树上良定义（E 族负案含 neg-057 E0012 孪生——其编译侧拒绝正是 LA-7 防御层，本段所有）。
- **语料 sweep 钉扎**：85 案全 matched——reader 8（与 expander parity 分割逐位一致：neg-054/055 溢出面含）/ expander 19（展开或 loader 拒绝——顶层表达式规则与未绑定名纪律含）/ compiler 58（含检查器负案族）；层计数三向守卫钉扎（routing 回归即败）。
- **诚实边界顺带发现**：expander 未绑定名纪律（`unbound identifier`——自由名永不达 global 回退）与 loader 顶层表达式规则（裸 `(set! g 1)` 拒绝）使 global-fallback assign 面只活在 fn 体内——测试锚随实况落位。


#### 9.83.6 CP-6 第四次自应用与恢复核验自纠实录（中断轮四缺陷）

- **第四次自应用**：compiler.krf 分析自身展开树（宿主尾 `(define result (cp-run items))` 剥离——`items` 为注入全局，裸源未绑定，1.6 selfhost-bare 先例的结构化复用）——758 行闭包/let/深 if 级联，本段全部分析面单程序承载，双引擎一致 + oracle 对拍 matched；前端三源（reader.krf + 装配 expander = macro+expander 1410 行）同过——最强实程序语料。
- **恢复核验自纠四缺陷**（中断轮残留——全部首轮拦截，如实登记）：① 括号失衡 ×2（cp-lit-convert 加 pair 臂未配平 + cp-walk 尾部闭包欠一——机检平衡器逐行深度追踪定位修复）；② 产品形状 doc/impl 失配（`cp-proto-products` 发射平坦 `"caps"` 字段 vs 头部文档嵌套 `("caps" ...)` 记录——实现向文档契约对齐修复）；③ 嵌套 pair 字面量塌陷（`cp-lit-convert` 缺 `"pair"` 已转换透传臂——≥2 元素 quoted 表内层组件静默折为 nil；`"pair"` 臂补入 + 词汇表无歧义论证["pair" 不在 flat 流形、"lpair" 不在产品形] + 回归测试永久钉扎）；④ improper 捕获对（`("local" . slot)` 点对 vs 宿主解码器 nil 终结表期待——`cp-cap-src` 产品化助手修复）。**教训**：中断轮半成品的「文档即契约」恢复核验 = 四缺陷全部可由「读头部文档 → 对照实现」静态发现——24-d 先例的恢复纪律价值再证。


#### 9.83.7 audit X 节与守卫族（210→220/220 + 测试 +17）

- **audit X 节 10 case**（X01-X10：语料重放[捕获密集正案] + LA-4 传递链 + LA-7 编译侧边界 + 深度镜像与 eval 包络 + 嵌套 litval 回归 + 作用域栈纪律 + 常量池恒等 + first-use 序 + 第四次自应用 + tamper 漂移自检）——TEST-3 组成守卫与标题字面量共变（A-X 二十三节 220/220）。
- **测试族 +17**（compiler_parity_tests.rs CP1-CP7：sweep + 路由 + 槽复用/峰 + 遮蔽槽同一性 + 捕获 first-use + 传递 + first-use intern + 常量恒等 + assign 三叉 + 深度边界 + module/defsyn 零分析 + perform/handle + 自应用 ×2 + tamper ×2 + 嵌套 litval 回归）→ **1286→1303:0:0**。
- **格式守卫第四件**：selfhost_format_guard_tests 收 COMPILER（宽 ≤100 + 非 ASCII 白名单 + em-dash——三断言四源共变）；selfhost/README.md 四件清单 + 消费面 + 敏感锚（compiler.krf 增两 tamper 探针锚）。


#### 9.83.8 验收与收敛口径（下一入口 = 2.3 后续 Pass）

第八十二轮 = **Stage 2.3 fixpoint 窗开启轮**：六命令 **1303:0:0**（fmt 零 diff + clippy -D warnings 零告警 + doc 1 告警 = cargo#6313 登记）+ audit **220/220** + B 六轴带内（B4 逐位一致第六次连续——分析段零生产语义变更实证）+ 非英文编码面零新增（CJK 命中 = 既有登记白名单测试夹具）+ 语料 85 维持 + TD 开放项 0（第 46 轮）+ 8 原语不变性**第五十六轮**验证（CP 段 = 编译器自举**前置**——.krf 分析器是**新增消费面**而非语言面变更：零新原语零通道零 VM 变更零语法增量——自举链宪制约束全程有效）+ ds08 金链 0.52.0。**收敛口径**：2.3 A 阶段第一 Pass（词法域分析纯函数面）交付关闭；后续 Pass = 指令发射域（backpatching/栈深簿记/debug_info——compiler.krf 头部预登记的 later Passes），逐 Pass parity 骨架沿用本轮 CP-1..CP-7 形制；2.4 双编译器等价验证窗入口不变（stage-2-plan §2 单源）。



---

## 9.84 Stage 2.3 第二 Pass：compiler 指令发射域 .krf 化（第八十三轮 · r83 · Task 61 · v0.53.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.84.1 行权前置十项复查（第五次维持）与新沙箱栈守卫恢复

第八十三轮开工前置：① 六命令冷跑 **1303:0:0** 复现——**初跑拦截实质缺陷 ×3**：新沙箱 8MiB 测试线程默认栈低于 eval 引擎 2048 深原生递归实测需求（8-12MiB，RUST_MIN_STACK 12MB 探针定位），`runtime_seed_tests::eval_depth_cap_is_eval_only_the_vm_stacks_deeper` + `eval.rs` 两单元测试（`eval_depth_cap_guards_the_rust_stack` / `arity_and_depth_messages_follow_the_r8_family`）+ audit H08 四处栈溢出 SIGABRT——当轮清偿（r74 BST-1 先例：deep_stack 64MiB 线程包裹[parity 测试 768MiB 形制的量体裁衣版] + H08 因 Value 含 Rc 非 Send 采用线程内判定 + 诊断串回传）；生产 crate 零触碰（仅 cfg(test) 模块 + examples 审计面 + 集成测试树）；同类路径全量审查（rg 全库 countdown 3000 深递归驱动点四处在场清偿后收敛）② audit 220/220（A-X 二十三节）③ B 六轴带内 + **B4 gc 1/swept 1023 逐位一致（第七次连续）**——B1a 1.4µs（min 1.0 = r82 值）与 B6c 241ns 环境噪声面如实登记（生产 crate 相对 HEAD 零 diff 归因）④ TD 开放项 0（第 47 轮）⑤ 语料 85{34/41/10} ⑥ selfhost 四件 117/750/660/758 ⑦ 谱系 41 段在场（§9.43-§9.83）⑧ 行动项锚维持（B 审先行 K198-K203 六新锚——61-b 子代理八查，强 6/弱 2[q1 Lua lcode.c 变体 q1b 补位 + q5 去重面变体 q5b 补位]诚实降级）⑨ 登记窗全零维持 ⑩ web T60 态（API 第八十二轮/1303/9.49 = kerf HEAD 9125663 一致）。**裁定：禁令复活条件不成立——Stage 2 实施入口 ✓ 已开启维持（r79 解除 + r80-r83 四次维持复验）。**


#### 9.84.3 逐表达式发射走查（合成模式扩展 + 求值序契约）

- **七合成模式**（互递归禁令下的单自递归 walker）：mwalk/awalk/bwalk/cwalk 四既有 + **acall**（apply 调用位点——args 走尽后编 callee + `call argc`，apply span）+ **peff**（perform 效应位点——args 后 intern(effect) + `perform g argc`，K195 捕获分析与发射分离的效应面同构）+ **cfwalk**（compile_fn 协议——begin-closure 返 idx + body 尾走 + 条件补 ret + end + `closure idx` 以 fn span）。define-with-fn 直入 cfwalk（fn 节点不计深——compile.rs 解构同构）；匿名 fn 经 fn 臂入 cfwalk（fn 节点计深）。
- **求值序与槽位生命周期**（§19.3/§19.5 契约镜像）：apply = args 左→右再 callee（`call n` 经 peek(n) 顶取 callee）；let* = 值先行-槽后配-StoreLocal 以 binding span-push_local；assign = 值-dup-store 三段（值留在栈上供封套表达式）；Perform = args→intern→emit；Handle = 逐子句 handler 值→intern→push-handler（clause span）→body 非尾→`pop-handler n`（handle span）；Define = 值（fn 解构或表达式）→intern(name)→`store-global g`（define span）。
- **乘积渲染与终化排空**：proto 乘积七字段——`("caps" src...) ("code" insn...) ("dbg" sp...)`，code/dbg 反转入 pc 序；insn = `(op-name a b)`（25 kebab 名稳定诊断名单源）；sp = `(s e)` 偏移对。**K199 承载**（前向引用两经典解——第二遍扫描 vs 单遍补簿清单，均以无未解析引用的排空检查收尾）：kerf 取补簿清单支 + `cp-drain` 逐 proto 代码序首占位扫描 = Rust finish 的确定性防御见证同构；**K202 承载**（DWARF 行表按变更共享行 = 逐指令位置表的去重编码形态）：kerf 稠密平行形态的**显式不采**登记——全 span 逐位差分检验优先于编码压缩（诚实边界：编码轴为后续优化窗，非 parity 面）。


#### 9.84.5 发射防御族与错误轴扩展（可读漂移面）

- **结构化拒绝三新 kind**（仅破损发射器可达——正确实现零触发）：`stack-underflow`（pc+span 重建经 oracle Display）+ `stack-imbalance`（pc+expected+actual+span）+ `unpatched-jump`（at+span）——harness `rebuild_compile_error` 三臂重建（负值载荷防御 + Display 字节 parity 构造性透明）；触发即测试失败并以可读双文本呈现（「a parity harness that cannot fail is not a harness」FP8 谱系）。
- **harness 缺陷二 kind**：`bad-patch`（非占位 patch 位点——Rust 侧 panic 的镜像降格：Rust 不可达内部断言在 .krf 以结构化拒绝呈现，判定入 harness defect 类）+ `bad-node`（流词汇表破裂——既有）。**设计说明**：编译器内部防御（Rust: panic/Result）与 .krf 镜像（结构化 err）的形态差异 = 诚实登记面——语义同为 fail-closed，呈现层随载体（Rust 不可恢复断言 vs 子集无 panic 面以 err 承载）。


#### 9.84.7 audit Y 节与守卫族（220→230/230 + 测试 +13）

- **audit Y 节 10 case**（Y01-Y10：尾位终结符契约 + 非尾合流跳转与补靶 + 求值序 + assign dup 形双面 + 效应操作数形状 + 闭包协议索引 + 常量槽位同一性 + 零码锚点 halt + 稠密 debug 表[手建 fixture span] + 第五次自应用）——X 节四断言同步新文法（X01/X02/X06 乘积形 + X10 锚串），标题字面量与组成守卫共变（A-Y 二十四节 230/230）。
- **CP8 测试族 +13**（compiler_parity_tests.rs：尾位终结符 + 合流补靶 + 求值序 + 槽位生命周期 + assign dup + perform 形状 + handler 安装序与 pop 计数 + 稠密表 + 零码锚点 + 闭包协议 + 常量槽位 + pair 常量与内建调用 + 码轴篡改探针[`cp-patch jf (cp-here))` 锚——补靶篡改漂移]）+ CP6 自应用断言扩展（code/dbg 段 ≥40）→ **1303→1316:0:0**。
- **tamper 锚更新**（selfhost/README.md 三锚登记）：var 臂全局回退锚升级为 `(cp-emit "load-global" (cp-intern-global name) 0 (cp-span-of t))`（操作数与驻留双面——0 替 intern 篡改使全局表与操作数双漂移）+ 新增 patch 锚 `(cp-patch jf (cp-here))`；格式守卫四源维持（宽 ≤100 + 白名单 + em-dash）。


#### 9.84.8 验收与收敛口径（2.3 逐 Pass 完整性核对 → 收口评估）

第八十三轮 = **Stage 2.3 第二 Pass 交付轮**：六命令 **1316:0:0**（fmt 零 diff + clippy -D warnings 零告警 + doc 1 告警 = cargo#6313 登记维持）+ audit **230/230**（A-Y）+ B 六轴带内（**B4 逐位一致第八次连续**——发射域 = .krf 消费面扩展，Rust 编译器生产码零触碰）+ 非英文编码面零新增 + 语料 85 维持 + TD 开放项 0（第 47 轮）+ 8 原语不变性**第五十七轮**验证（发射域 = 既有 25 操作码的消费面——零新原语零通道零 VM 变更零语法增量）+ ds08 金链 0.53.0。**用户指令④闭环**：逐 Pass 完整自举纪律——本轮发射域全量交付（机制 + 逐表达式 + proto 终化 + parity 码轴 + 防御族 + 自应用 + audit + 文档——compiler.krf 头部预登记的 later Passes 全部落地），无降级无伪自举；**收敛口径**：2.3 A 阶段两 Pass（词法域分析 + 指令发射）已交付——下一轮入口 = **2.3 收口评估**（CP 段 = compile.rs 编译期纯函数面全量：分析 + 发射均 .krf 化且码轴对拍——收口条件核对后关闭 2.3）→ 2.4 双编译器等价验证窗（compile(expand_oracle(S)) == compile_krf(expand_krf(S)) 全管线化——stage-2-plan §2 单源；行权轮十项全绿前置每轮维持）。



---

## 9.85 Stage 2.3 收口评估：CP 段全量对账与组成链清偿（第八十四轮 · r84 · Task 62 · v0.54.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.85.1 沙箱恢复与行权前置十项复查（第六次维持）

第八十四轮开工环境层 = **沙箱第三次重置恢复轮**（z.ai web 保存机制回退——本地态丢失至 T54/v0.46.0，远端 GitHub 仓库最新 commit 9bc90a9「chore(tmp::upload): session upload」承载 v0.53.0 会话上传包）：按用户指令① depth-1 克隆（禁止查询旧 commit）+ 解包替换 + 本地基线 commit 6210ed9；Rust 工具链重装 1.99.0（前轮 1.98.1）。**行权前置十项复查第六次全绿**：① 六命令 **1316:0:0** 冷跑复现 ② audit **230/230**（A-Y）——**新工具链栈守卫当轮清偿**：audit example 主线程默认 8MiB 低于 Rust 1.99.0 帧布局下 eval 深度面实测需求（§9.84.1 同类第三例：r74 BST-1 测试线程 → r83 H08 线程内判定 → 本轮 audit example 主线程）——audit_body 整体迁入 64MiB 深栈线程（值全在线程内创建，非 Send Value 不跨界；生产 crate 零触碰——examples 面单文件）③ B 六轴带内 + **B4 gc 1/swept 1023 逐位一致（第九次连续）**（B1 7.4µs / B1a 1.0 / B1b 3.7µs / B1c 1.5µs / B2 med 79.701ms / B3 med 7.696ms / B5 79.695ms / B6a 50.1ns / B6b 50.2ns / B6c 228.1ns——B2/B3/B5/B6 四轴较 r83 值均带内改善方向漂移，环境归因如实登记）④ TD 开放项 0（第 48 轮）⑤ 语料 85{34/41/10} 维持 ⑥ selfhost 四件 117/750/660/1221 维持 ⑦ 谱系 42 段在场（§9.43-§9.84）⑧ 行动项锚维持（K198-K203 既有锚族——收口评估为验证域轮零新检索，沿 T58 先例）⑨ 登记窗全零维持 ⑩ web T61 态缺口（沙箱回退断链七轮——T55-T61 web 侧记录缺失，本轮 62-web 全量回补——如实登记非全绿项，处置已排）。**裁定：禁令复活条件不成立——Stage 2 实施入口 ✓ 已开启维持（r79 解除 + r80-r83 四次维持 + r84 第五次维持复验）。**


#### 9.85.2 CP 段全量对账（函数级映射 + 文法/操作码覆盖 + 逐 Pass 证据）

收口条件（§9.84.8 登记）：「CP 段 = compile.rs 编译期纯函数面全量：分析 + 发射均 .krf 化且码轴对拍」。**函数级映射对账**（compile.rs L35-785 实现面 33 函数 → compiler.krf 1221 行 83 defines）：

| compile.rs 面 | compiler.krf 镜像 | Pass |
|---|---|---|
| same_const_slot / const_hash | cp-same-const + cp-const-scan（Debug 文本同一性规则——头注成文） | P1 |
| CodeBuf::new / anchor | cp 状态变量族 + cp-proto-make + cp-estate-make | P2 |
| emit | cp-emit + cp-op-pops/cp-op-pushes + cp-span-of | P2 |
| emit_jump / patch | cp-emit-jump / cp-patch（4294967295 哨兵 + b 源深度 + 双恢复） | P2 |
| set_depth / cur_depth / here | cp-set-edepth / cp-cur-edepth / cp-here | P2 |
| emit_tail_terminator | cp-emit-tail-term（cur==0 halt / 否则 ret） | P2 |
| intern_const / intern_global | cp-intern-const + cp-const-scan / cp-intern-global + cp-global-scan | P1 |
| alloc_local / push_local / lookup_local | cp-alloc-local / cp-push-local + cp-params-locals / cp-assoc-slot + cp-index-of（innermost 优先） | P1 |
| capture_in_cur / held_by / resolves_outer | cp-capture-in-cur / cp-held-by / cp-resolves-outer + cp-chain-holds（LA-4 传递链） | P1 |
| locals_mark / locals_truncate | cp-mark / cp-truncate（LIFO 槽位复用） | P1 |
| begin_closure / end_closure | cp-begin-closure / cp-end-closure（保存栈协议） | P1 |
| enter_depth（1025 深帽） | 深度守卫（("err" "depth" 1025 s e)） | P1/P2 |
| expr / expr_inner | cp-ewalk（七合成模式 + 十三文法臂） | P2 |
| compile_fn | cp-ewalk fn 臂 → cfwalk 合成模式 | P2 |
| item / item_inner | cp-run + cp-assemble + cp-take + cp-run-take | P1/P2 |
| finish | cp-finish + cp-drain + cp-drain-scan + cp-proto-products | P2 |
| compile / compile_program | cp-run → result 绑定（("ok" funcs globals consts) / ("err" kind payload...)） | P1/P2 |

**文法覆盖**：cp-ewalk 十三记录形（define/require/defsyn/module + fn/apply/if/var/lit/assign/let/bind/perform/handle + clause/litval 族）+ 七合成模式（mwalk/awalk/bwalk/cwalk/acall/peff/cfwalk）= CoreExpr + ModuleItem 全量。**操作码覆盖**：cp-op-pops（17 臂 + 默认 0）/ cp-op-pushes（16 臂 + 默认 0）覆盖 25 操作码全栈效应（call = a+1 / perform = b 与 Rust `op.pops(a,b)` 逐臂对齐）。**逐 Pass 证据**：CP1-CP7（17 测试——三层路由 8/19/58 + 产品轴锚 + 驻留序 + 错误轴 + 零分析项 + 第四次自应用 + 漂移探针）+ CP8（13 测试——发射轴）+ 语料 sweep 85 案 + 第五次自应用（码轴全 proto 逐字节）。**对账结论：compile.rs 编译期纯函数面 100% .krf 化覆盖，零缺口零降级。**（compile.rs 785 行后为 Rust oracle 自有测试面——oracle 双跑身份是 2.4 窗的组成件而非待重写面。）


#### 9.85.3 组成链清偿（CP9 + 第六次自应用 + audit Z 节）

**收口实证 = 组成链（CP9）**：2.4 公式 `compile(expand_oracle(S)) == compile_krf(expand_krf(S))` 在锚集上**作为一条链直接验证**（非分段传递性）——harness 双新面：`krf_expand_rich(_with)`（expander_parity——gate B 富跑单源复用，绝不复制骨架）+ `composed_chain_parity(_with)`（compiler_parity——oracle 全管线 vs .krf 前端[组装 expander 双引擎] → 树同一性断言[ModuleItem: PartialEq，span/展开 id 含——1.6 判据链内化] → .krf 编译器消费**.krf expander 自己的树** → 产品对拍 + 全管线文本终断言）。**CP9 五测试**：① 正锚五形（fn 语法糖/捕获序/传递捕获/效应/let 遮蔽）② **selfhost 定点全链**（reader.krf + 组装 expander + compiler.krf——**第六次自应用 = 首次经全 .krf 链**：compiler.krf 的树由 .krf expander 展开、由 .krf 编译器编译、与 oracle 全管线逐字节对拍——fixpoint 前置条件实证）③ 错误轴（LA-7 assign-to-captured 链上双拒一致）④ **语料编译器层 sweep**（58 案全链——read+expand+load 过滤镜像 CP1 路由，含 neg-057 编译侧拒绝）⑤ **前端篡改探针**（深度守卫 512→2——链必以「the .krf expander rejected」失败，FP8 谱系）。**audit Z 节 6 case**（Z01 捕获序 + Z02 效应 + Z03 let 遮蔽 + Z04 LA-7 错误轴 + Z05 reader 定点 + Z06 第六次自应用）→ **230→236/236（A-Z 二十五节）**；守卫 +5 → **1316→1321:0:0**。


#### 9.85.4 过度特化审查（用户指令⑤——每轮义务）

compiler.krf 字面量全量清点：83 defines 内字符串字面量 = 记录文法标签（十三形 + litval 族 + 七合成模式）+ 25 操作码 kebab 名 + 错误族 kind + 产品字段名——**零语料特异符号**；数值字面量 = 协议常量（4294967295 = u32::MAX 哨兵 / 1025 深帽 / 零操作数契约）；CP9 组成链为通用组合面（无锚集特化分支）。**结论：镜像保真零特化——通解形态维持。**


#### 9.85.5 2.3 关闭裁定与 2.4 窗口规划

**裁定：2.3 关闭**（收口条件三面全过：函数级映射 100% + 码轴对拍两 Pass 实证 + 组成链清偿）。**2.4 双编译器等价验证窗开启规划**（stage-2-plan §2 单源）：fixpoint B 阶段——组成链从锚集升格**全语料 + 全 selfhost 系统化**（CP9 sweep 已预演 58 案编译器层；2.4 扩展至 reader/expander 层路由全谱 + 差分收敛纪律[双跑漂移零容忍 + 漂移分类账]）+ **门 B 升格路径预登记**（gate_b_bytecode 的 .krf 侧编译器换装评估位——.krf expander 重建树 → .krf 编译器产品 vs oracle 字节码，2.5 C 阶段全管线双口径的前置）；宪制重申：VM 永久 Rust 基座 + 8 原语不变性（第六十轮验证）+ 零新外部依赖。


#### 9.85.6 验收与收敛口径（2.3 关闭 → 2.4 开窗）

第八十四轮 = **Stage 2.3 收口评估轮（2.3 关闭）**：六命令 **1321:0:0**（fmt 零 diff + clippy -D warnings 零告警 + doc 1 告警 = cargo#6313 登记维持）+ audit **236/236**（A-Z）+ B 六轴带内（**B4 逐位一致第九次连续**）+ 非英文编码面零新增 + 语料 85 维持 + TD 开放项 0（第 48 轮）+ 8 原语不变性**第五十八轮**验证（组成链 = 消费面组合验证——零新原语零通道零 VM 变更零语法增量）+ ds08 金链 0.54.0。**用户指令闭环**：① 远端最新 commit 替换（depth-1 + 解包 + 基线 commit）② Stage 2 入口第五次维持 ③ 不冻结（2.4 窗口即开）④ 逐 Pass 完整自举纪律（收口评估 = 全量对账实证——无降级无伪自举）⑤ 过度特化审查（9.85.4 零特化结论）⑥ 每轮检查（十项复查 + 收口条件三面）⑦ web 同步 + tar.gz 打包（62-web/62-pkg）。**收敛口径**：**2.3 关闭**（compiler 自举三阶段 A 阶段完成——CP 段全量 .krf 化 + 码轴对拍 + 组成链实证）；下一轮入口 = **2.4 双编译器等价验证窗**（组成链全语料系统化 + 差分收敛纪律 + 门 B 升格评估——stage-2-plan §2 单源；行权轮十项全绿前置每轮维持）。


#### 9.87 Stage 2.4 首刀：全组成链与漂移分类账（v0.56.0 · 第八十六轮 · r86）

**裁定**：2.4 公式自此**一条链直证且前端全 .krf**（junction 1 读链 r85 / junction 2 展开层 1.6 / junction 3 编译层 2.2-2.3 三段分级托管，链自身产物逐级前馈）；漂移分类账（8 读层 + 19 展开层 + 58 编译层 = 85 全路由）为测试钉扎不变量；门 B 升格见证（dump 文法对 Bytecode 语义域九探针忠实像）登记为 2.5 前置。设计层单源 = `docs/stage0.md §9.87`（分层纪律）。

**实施实录**：

- **JX-1 junction 重编码器**（lexer_parity.rs +118 行）：`rebuild_read_forms`/`rebuild_read_node`——.krf reader 的 `result` 值树重建为 `Vec<SyntaxObject>`（镜像 dump_krf_node 推导：span + 源切片给 ident/float/string、记录载荷给 int/bool；Symbol::new 校验 floor；Phase::Runtime + ScopeSet::default = 展开层自身托管约定——恰为 forms 流编码消费的字段集）；`drive_full_dual`/`drive_full_vm` 返回值扩展（VM 侧 forms 于 heap 存活期重建——PAR-1 decode_vm_rich 同族模式）+ `DualOutcomeWithForms` 类型别名；公共入口三件（`reader_parity_full_with_feed` 双跑 / `reader_parity_full_feed_vm` VM 面馈送）——r85 既有公共面行为零变更（`.0` 丢弃）。
- **JX-2 全组成链驱动器**（composed_full_chain.rs 新模块 447 行）：`composed_full_chain_parity`（双跑）/ `_vm`（junction 1 VM 括号面）/ `_probes`（三臂篡改面）；路由全谱——oracle read 拒 → Read 行（下游空转 None）；expand/load 拒 → Expand 行（误差轴 parity key 对拍）；否则 Compile 行（树同一性 ModuleItem PartialEq + 产品/误差终面对拍 + 全管线 oracle 终面 = CP9 spine 复用）。单源复用：junction 2 = `run_dual_rich`（pub(crate) 化 + §9.74 PAR-1 骨架）+ `oracle_expansion` 新 pub(crate)（oracle 展开 WITH items——树门需要值非 dump）；junction 3 = `compiler_parity_items_with` 公开化（同 spine 参数面）+ `cp_error_key` pub(crate)（全管线终面误差渲染单源）。
- **JX-3 空表双前缀**：`forms_stream_prefix`/`items_stream_prefix` 空表 → `(quote nil)`（subset-spec §2.5：`(quote ())` 是读错误；r85 byte_table_prefix 先例）——空源/纯注释源 → 空积编译行（oracle read_program("") = Ok([])——空程序合法编译为空积）。
- **JX-4 门 B 升格见证**：`dump_faithfulness_witness`——funcs.name（nil↔名翻转）/ params / n_locals / captures（空↔非空翻转）/ code（追加 Ret）/ debug_info（重复 span）/ funcs 整体（清空）/ globals / consts 九探针逐字段变异全可见性断言（fail-closed：首个不可见字段点名报错）——dump 相等 ⟹ Bytecode 相等（§9.85.5 评估位兑现：2.5 门 B 全管线双口径可换装 .krf 编译器产品侧）。

**测试构成**（composed_full_chain_tests.rs 新文件 15 函数 + runner 挂载）：正锚 7 形（fn 糖/capture 序/transitive/effects/let 遮蔽/多 define 模块/载荷族）+ 空积双源（空/纯注释）+ selfhost 五件全量过链（reader 双跑{VM 括号——头部 ~2.4k 字节单段 trivia 越 eval 包络，r85 先例} + assembled expander/compiler{VM 面} + macro{VM 面——自含无宿主尾} + **第七次自应用**{lexer.krf 自源——尾部四输出全局剥离，字节表→lexer.krf+reader.krf→expander.krf→compiler.krf vs oracle 全管线}）+ **漂移分类账 sweep**（85 文件 oracle 路由分类 + 行匹配 + matched + 8/19/58 计数钉扎 + bnd-006/007 括号重验 ≤2）+ 误差轴三行（neg-001/neg-003 读层 + neg-013/neg-011 展开层 + neg-057 编译层 E0012）+ 篡改探针三臂（lexer VT 表 → junction 1 停 / expander 深度守卫 → junction 2 停 / compiler load-global → junction 3 产品轴）+ 包络双面（2000 原子宽源双跑 → harness limit 分类 + 255 深 if 链 VM 面全链）+ 见证双夹具（全字段代表积 + 空积）。

**内循环实录（§5.3，三族当轮清偿）**：① 空表双前缀——空/纯注释源首跑在 junction 2/3 分别撞 `(quote ())` 解析错（byte 21）→ 双前缀 nil 化（r85 先例）后全绿；② 嵌套 if 缺 else 臂——包络测试初版 255 深 if 无 else → 展开层 arity 拒（matched 但行 = Expand）→ 补 else 臂后 Compile 行；③ 空源行归属——初版假设空源 = Read 行，实测 oracle read_program("") = Ok([]) → Compile 行（空积）——测试假设修正非链缺陷。另：reader 自源定点初版用双跑面 → eval 包络 2048 超（r85 已证头部 trivia 单段 ~2.4k 字节越界）→ VM 面承载（先例复认）。

**audit Z 节 6 → 16**（246 → 256/256）：Z07/Z08 全链正锚 + Z09 读层误差轴 + Z10 展开层误差轴 + Z11 编译误差轴（LA-7）+ Z12 reader 定点（VM 面）+ Z13 第七次自应用（lexer.krf 全链 VM 面）+ Z14/Z15 junction 局部篡改检测臂 + Z16 门 B 升格见证；TEST-3 守卫共变（documented_audit_composition Z 6→16 + 246→256 三处 + 头行字面量）。

**验收**：六命令全绿（fmt 零 diff / build 0e0w / check 0e0w / clippy -D warnings 0 / **test --release 1343 → 1358:0:0**（净 15——正向 3{锚族 + 空积双源 + 见证} / 负向 6{误差轴三行 + 篡改三臂} / 边界 1{包络双面} / 跨阶段消费 5{selfhost 四件定点 + 语料 85 分类账 sweep}）+ **audit 256/256**）+ B 七轴带内（B1 7.0µs / B1a 1.0 逐位 / B1b 3.4 / B1c 1.6 / B2 79.4ms / B3 7.6ms / **B4 gc 1/swept 1023 逐位一致（第十次连续）** / B5 79.4ms / B6 三面复现）+ 非英文编码面零新增（新文件全英文）+ TD 开放项 0 维持（第 49 轮）+ 8 原语不变性第五十九轮验证（零冻结面变更——junction 重编码器 = harness 面）+ 语料 85 维持 + selfhost 五件 117/473/750+660/1221 维持 + 过度特化审查零结论（JX 全为通解面：重编码器文法镜像既定 dump——零语料特异符号）。

**§7.2 六问**：Q1 无桩（JX-3 空表 nil = 数据面正典非桩；JX-4 见证九探针 = 覆盖声明机检化）；Q2 测试构成达标（语料 85 全路由 + 三行误差轴 + 三臂篡改 + 包络双面 + 见证双夹具）；Q3 文档同步完成（stage0 §9.87 v9.53 + round-records 本节 + stage-2-plan 2.4 行 + roadmap v2.27 + RELEASE_NOTES v0.56.0 + subset-spec §3.3 + selfhost/README + 测试记录 composed-full-chain.md + calibration T2.4-1 + performance-baseline r86 行 + test_infra_guard 共变）；Q4 TD 开放 0 维持；Q5 无降级自举（链产物前馈 = fixpoint 诚实方向——oracle 中间产物零回落）；Q6 版本族共变完整（Cargo 0.56.0 + ds08 金链 + README Status + RELEASE_NOTES）。

**§7.3 门审**：audit 256 case（Z 节 10 新案）+ 语料 85 全链重放（分类账 sweep）+ 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（JX-1 单源重建镜像 dump 推导 + JX-2 三段全复用既有 spine——零第二装配路径）/ DEV-A 1.5（三族内循环全清偿 + 空积行正典化）/ QA-A 1.0（篡改三臂 junction 局部性断言 + 包络分类 + 计数钉扎）/ ALG-C 1.0（九探针覆盖 Bytecode 全字段——注入性见证 fail-closed）/ SKL-A 不计权 PASS（VM 括号面沿 r85 先例披露）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：2.4 首刀交付（全组成链 + 漂移分类账 + 门 B 升格见证）；2.4 关闭判据 = §9.85.5 遗留三项评估（门 B 升格实施位[gate_b_bytecode .krf 侧换装——2.5 前置已见证]/ 组成链运行成本测量面[全语料 ×3 junction 的 harness 成本——若进测量关切开窗]/ 双编译器差异收敛账全语料基线化）——若判定无实施面则 2.4 关闭评估轮收官；行权轮十项全绿前置每轮维持。

# 9.88 Stage 2.4 关闭评估轮：三判据裁定与 B7 测量轴（第八十七轮 · r87 · Task 65 · v0.57.0）

**路由**：L3 非末轮（子阶段切换点——2.4 → 关闭 → 2.5；§1.2.1 三指标：跨面共变族[bench + 守卫 + 版本金链 + 文档族] + 关闭裁定改变 stage-2-plan 单源状态机 + parity 域历史中密度但本轮为评估+测量面）。**实施实录**（本轮零生产 crate 触碰——bench example + 守卫扩展 + 文档族 + 版本族）：

**65-a 三判据评估**（代码实态核验先行——§2.3-11）：
- **判据一（门 B 升格实施位）→ 移交 2.5**。核验：`gate_b_bytecode`（expander_parity.rs L1189）现状 = Rust 编译器双侧编译（oracle items vs .krf expander 重建 items）——字节码全等在 expander 产品面；组成链 junction 3（composed_full_chain.rs L313）= .krf 编译器产品 vs oracle 全管线经 CP dump 文法 + 见证（`dump_faithfulness_witness` 九探针——dump 相等 ⟹ 字节码相等）。2.4 验收（逐 Pass 字节码全等全管线化）已直证。换装本体（rebuild_bytecode + opcode 名反查 + Bytecode PartialEq 门）在 2.4 零消费面；2.5 fixpoint（C(C(S)) 两次编译字节一致）要求产品可执行——rebuild 为开场必需件。产品形状勘明：instruction record = `("op-name" a b)` 三元（`dump_krf_insn` L487 直读）——name→Opcode 反查表为 2.5 实施细节。裁定依据：§12（无当轮消费面的前置负载不做）+ stage-2-plan §2 行 2.5 明文（「门 B 升格全管线双口径」为 2.5 交付物）。
- **判据二（组成链运行成本测量面）→ 有实施面，本轮落地 B7**。核验：B 轴 B1-B6 全部为 Rust 管线测量——组成链（永久验证面，每轮语料 sweep 承载）从未有成本数字；T38 规则 5 失察教训对照（无守卫的测量义务十轮无记录）；2.5 fixpoint 驱动器设计需成本包络；2.6 构建编排评估需自举乘数；语料增长政策需每文件成本数。
- **判据三（差异收敛账基线化）→ 校准行落位**。核验：8/19/58 已由 `corpus_ledger_sweep` 测试钉扎（composed_full_chain_tests.rs L301——语料增长强制随动）；基线化 = 校准册 T2.4-2 行 + 本节（测量数字 + 机检断言双承载）。

**65-b B7 轴实施**（examples/bench/stage0_baseline.rs +55 行）：
- B7 = `composed_full_chain_parity("bench-fib", FIB)` 每跑（与 B1 同锚——比值良定义）；9 iters + warmup 3（§9.61 PERF-2）；black_box 栅栏（K90）；四统计量 ms 报告（line_stats_ms——B2-B5 同形）；**fail-closed 双断言**（warmup 与测量环各一——`report.matched` 必须真，漂移链上的基准无意义）；乘数行 = B7 median / B1 median（b1 样本集复用——单源）。
- **B7 首录：median 21.937ms / mean 21.883ms / min 21.694ms / stdev 0.142ms（9 iters）→ 自举乘数 3081×**（vs B1 median 7.1µs Rust 管线）。语义：FIB 经 lexer.krf+reader.krf（双引擎）→ expander.krf（双引擎）→ compiler.krf（双引擎）全链 21.9ms——每次语料 sweep 的组成链面成本量级锚。
- 守卫扩展（perf_observability_guard_tests.rs `bench_harness_methodology_present` +2 断言）：B7 标签在场钉扎（"B7 composed-chain-fib"）+ fail-closed 断言在场钉扎（"the composed chain drifted"）——测量义务的机检面。既有阈值（fences ≥14 / warmup ≥6 / stdev ≥6）自然满足（B7 增量后 16/7/6+）。

**65-c 2.4 关闭裁定 + 版本族 + 文档族**：
- stage-2-plan §2 行 2.4 关闭登记 + 行 2.5 开场注记（移交清单：rebuild_bytecode + fixpoint 驱动器 + 门 B 升格全管线双口径——2.5 首刀 MUV 序列）。
- stage0.md §9.88（分层纪律：裁定/设计依据/一伪代码/验收/develop 引用）+ 版本头 v9.54；roadmap v2.28；RELEASE_NOTES v0.57.0；README Status；Cargo 0.57.0 + ds08 金链（golden 注记共变——v0.57.0 关闭评估版）；calibration T2.4-2 行；test_infra_guard 登记表无共变（零新测试函数/零新 audit case——B7 为 example 面）。

**十项复查（第八十八轮前置——行权轮维持）**：六命令 1358:0:0 维持（B7 为 example 面零测试函数增量）+ audit 256/256 维持 + B 七轴带内（B1 7.1µs / B1a 1.0 逐位 / B1b 3.7 / B1c 1.6 / B2 80.075ms / B3 7.614ms / B4 gc 1/swept 1023 逐位一致第十一次连续 / B5 80.079ms / B6 47.5/47.4/216.6ns 三面复现）+ B7 首录 + TD 开放项 0（第 50 轮）+ 语料 85 维持 + selfhost 五件 117/473/750+660/1221 维持 + 谱系段在场（§9.43-§9.88）+ 登记窗全零信号维持 + web T65 同步态（后置）。过度特化审查零结论（FIB 锚与 B1 共享 + 守卫钉扎为标签字符串——零语料特异符号）。8 原语不变性第六十轮验证（B7 = harness 测量面零冻结面变更）。

**验收**：六命令全绿（fmt 零 diff / build 0e0w / check 0e0w / clippy -D warnings 0 / test --release **1358:0:0** 维持 + audit **256/256** 维持）+ B 七轴带内 + **B7 首录**（21.937ms / 3081×）+ 非英文编码面零新增（新代码面全英文——B7 注释与守卫消息）+ 版本金链 0.57.0 过。

**§7.2 六问**：Q1 无桩（B7 fail-closed 断言 = 覆盖声明机检化；无新生产面）；Q2 测试构成达标（守卫扩展强化既有函数 + B7 双断言内嵌 + 语料 85 全路由维持——评估轮零新正确性面零新测试义务）；Q3 文档同步完成（stage0 §9.88 v9.54 + round-records 本节 + stage-2-plan 2.4/2.5 行 + roadmap v2.28 + RELEASE_NOTES v0.57.0 + calibration T2.4-2 + README Status + ds08 金链）；Q4 TD 开放 0 维持（第 50 轮）；Q5 无降级自举（评估轮零自举面变更——B7 为测量面）；Q6 版本族共变完整。

**§7.3 门审**：audit 256 case 维持 + 语料 85 全链重放（分类账 sweep 维持）+ 七类错误 7/7 维持（零新错误面）。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（三判据裁定各有代码实态锚 + 移交清单落 2.5 单源 + B7 与 B1 同锚比值良定义）/ DEV-A 1.5（B7 实施沿方法学 v2 全纪律——栅栏/预热/四统计量/fail-closed）/ QA-A 1.0（守卫扩展把测量义务机检化 + fail-closed 双断言）/ ALG-C 1.0（乘数 = 同锚同管线语义比值——B1 分母单源复用）/ SKL-A 不计权 PASS → 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.4 关闭**（三判据：①移交 2.5 登记 ②B7 落地 ③账基线化——全部落位）。下一入口 = **2.5 fixpoint C**（自举不动点确认：.krf compiler 编译自身 → 两次编译字节一致 → 门 B 升格全管线双口径；开场 MUV = rebuild_bytecode[.krf 编译器堆产品 → Bytecode 结构重建 + opcode 名反查] + fixpoint 驱动器；§21.3 出口判据 (2) 兑现窗）；行权轮十项全绿前置每轮维持。


## #9.88 → #9.89（第八十八轮 · r88 · v0.58.0——Stage 2.5 首刀：自举不动点确认）

**路由**：L3 实施轮（恢复 + 重审 + 首刀三 MUV 一次交付——三指标：跨面共变族{opcode.rs + compiler_parity.rs + fixpoint.rs 新模块 + compiler.krf token 级 + 守卫 + 审计 + 文档族} + 依赖面跨 crate{kerf-compiler API 扩展 + driver 新模块} + parity 域历史 P0 密度{T63 词法层先例}）。沙箱第六次重置恢复（Pack B v0.57.0 @ 4cccb4d 编排树 830 entries sha256 3cd77b53… 解包 + git 基线 e806f76 重建 + Rust 1.99.0 重装 + worklog 终条目在场核验[2738 行/166 条目——T65 收尾记 2755/166 的 17 行口径差如实登记：终条目内容完整双侧一致]）。

**66-b 重审（用户常设指令④⑤——reader→compiler 链代码实态核验）**：五件自举态逐段复核——lexer.krf ✓（词法决策全 .krf + K20 两件宿主层诚实登记）+ reader.krf ✓（结构层完备）+ expander.krf+macro.krf ✓（装配一体 MX-2 + 世代字段 1.7 补记在位 + 漂移账 19 层钉扎）+ compiler.krf = 树面完备（CP 100% 映射 + 组成链 dump 轴）而**产品面世代缺位** = 升格门 B 的结构化障碍——正是 2.5 开场 MUV ① 的清偿对象（本裁定量化：oracle debug_info 携真实世代[宏产物 use_gen+1]而 .krf 产品仅 (s e)——`Bytecode::PartialEq` 全字段比较下宏语料必然失配）。**过度特化扫描零结论**（.krf 字面量全协议标签 + 世代为协议载荷）。**selfhost 目录结构裁定（用户指令④结构问）**：flat 五件制维持——.krf 文件镜像**设计层谱系**（1.5 词法/1.5 结构/1.6 展开/1.7 宏/2.3 CP——文件名即阶段名）而非 Rust crate 工程布局；组合点宪法性归属 harness（冻结子集零 I/O 原语——`include_str!` ×5 + 数据前缀注入是唯一装配通道，§11 单装配点）；per-stage 目录无语义增益（.krf 无模块系统——目录化暗示不存在的组合语义）+ macro.krf 装配耦合（MX-2 拼接为单一程序）反而被目录结构遮蔽；reader.krf 命名沿阶段谱系（结构层 = 1.5「reader」阶段）非 Rust parser.rs 文件名——两套命名法各自内洽。裁定登记 selfhost/README 消费面注记。**README 文档漂移三处顺修**（66-b 发现）：「四件」→五件（消费面表 + include_str ×5 + 格式守卫行）+ 测试表补全（lexer 22/composed 15/fixpoint 11 三行缺位）+ 敏感锚节 lexer 四锚补录。

**实施（2.5 开场三 MUV）**：
- **MUV ① rebuild_bytecode**（`compiler_parity.rs`）：`rebuild_capture/rebuild_insn/rebuild_span/rebuild_proto/rebuild_bytecode` 全字段重建 + `Opcode::from_kind_name` 反查表（`opcode.rs` 单源对——与 `kind_name` 相邻 + round-trip 守卫）+ `Bytecode::verify` 前置门（越界跳负例实证）。**世代补记**：CP-1 平坦流记录尾部世代整数（emit_item/emit_expr/emit_binding/emit_clause 十五记录形全触面）+ `cp-assemble` 世代末位重排（cp-init 剥离 + 子挂载 + cp-last 回填——**载荷与子位次序零迁移，既有访问器零改动**——define/assign/bind/clause/fn 追加臂与 if/apply/let/handle/perform/module 重建臂全量）+ `cp-span-of` 三元组（cp-2/cp-3/cp-gen-of 末元走查）+ `cp-gen-of` 前向引用重排（T63 缺陷族先例）+ 冷启动 span 三元化（(cons "0" (cons "0" (cons 0 nil)))）+ `dump_krf_span` 三字段解码/二元输出（dump 文本无世系约定保持）+ `rebuild_lit` 升 pub(crate)（consts 单源复用）。
- **MUV ② fixpoint 驱动器**（`fixpoint.rs` 新模块）：三相位驱动 + FixpointReport{self_protos/selfapplied_protos/self_consts/selfapplied_consts/self_insns/fixpoint_holds}——自应用装配的 proto 群与裸编译器相等（76 = 76——烧入输入入常量池不入 proto 群）而常量池严格更大（数据账面自证）；`krf_compile_rich`（双引擎富跑——drive_dual_engines 单源骨架 + VM 堆存活期重建）与 `krf_compile_rich_vm`（VM-only 括号面——`run_vm_only` 谱系；自嵌数据经逐元素递归超出求值器 2048 深度帽，括号披露于模块文档与驱动器注释——r85 junction-1 括号先例沿袭）。
- **MUV ③ 门 B 升格**（`gate_b_elevated`）：.krf expander 树（CP9 前半）→ .krf 编译器产品重建 vs oracle `compile_program` 结构化全等——全语料 sweep（eligible ≥25 地板沿 BST-4）。
- **测试 +11**（`fixpoint_tests.rs` 四正七负 + runner 挂载）：反向表往返 25 对 + 未知名拒绝 / 重建世代轴对拍（宏夹具断言非 ROOT 世代实际落位——**世代补记的回归轴**）/ 未知操作码名/负操作数/坏世代/截断 proto/未知节+err 判定/verify 拒绝 六负例 fail-closed / 升格门 B 语料 sweep / 不动点本体（deep_stack 768MiB 括号 + 规模披露断言）。
- **audit Z17-Z24 八案**（组合守卫 Z 16→24 + 总数 256→264 + 头行字面量共变）：反向表 / 世代轴 / 四负例 / 升格门 B 宏锚 / **不动点本体 Z24**（64MiB 深栈线程内运行 fixpoint 驱动器全相位）。

**内循环实录**：①cp-assemble 尾括号两枚超量（25→23——python 平衡器勘证）当轮修正；②重建负例初版闭包嵌套可变借用（E0499 ×10——ok_product 预建辅助收敛）+ map_err 内 `?`（E0277——载荷先取后格式化）+ 生命周期（闭包→嵌套 fn 显式 'a）三族编译期清偿；③KrfVerdict 私有性泄漏（pub 面收窄为文本 String——判决值留 crate 内）；④clippy useless_format 一枚当轮清偿；⑤rustfmt 六处多行归一；⑥测试断言两处口径修正（自应用 proto 群相等非严格更大——烧入输入入常量池；syntax-rules 空字面集 `nil` 非 `()`——子集空表读错误）；⑦审计 Z19 草稿残行当轮清除。全部当轮清偿，零跨轮残留。

**六命令冷跑全绿**：cargo clean + build --release + check + fmt（零 diff）+ clippy -D warnings（零告警）+ test --release **1369:0:0**（基线 1358 零回归 + 净 11）+ audit **264/264**（Z 16→24）。B 七轴带内维持（本轮零基准触碰——B7 21.937ms 基线数字不动；不动点族 release 实测 ≈3.8s[全部 12 项含语料 sweep]——2.5 收口评估轮可入册 B8 候选）。非英文编码面零新增（新代码面全英文）。8 原语不变性**第六十一轮**验证（世代补记 = harness 记录格式 + .krf 内部簿记——零冻结面变更零新原语零新内建）。

**版本面共变族 v0.58.0 十三件**：Cargo.toml + Cargo.lock + ds08 版本黄金（0.58.0 注记链 + 断言）+ RELEASE_NOTES v0.58.0 + README Status + roadmap v2.29 + stage-2-plan 2.5 行首刀交付态 + stage0.md v9.55 三面（文档状态行 + §9.89 + 本节）+ calibration T2.5-1 行 + selfhost README（五件化顺修 + 测试表补全 + lexer 四锚 + 消费面注记）+ fixpoint.rs/compiler_parity.rs/opcode.rs/fixpoint_tests.rs 头注 + audit Z 节注记。

**§7.2 六问**：Q1 无桩（重建面 verify 前置门 + 负例族实证 fail-closed）；Q2 测试构成达标（+11 = 四正七负——正负比子阶段内 4:7；集成面 = 语料 sweep ≥25 eligible + 不动点本体跨阶段消费[前 .krf 链四层 → 产品重建 → VM 执行]）；Q3 文档同步完成（stage0 §9.89 v9.55 + round-records 本节 + stage-2-plan + roadmap v2.29 + RELEASE_NOTES + calibration + selfhost README 三顺修 + ds08 金链）；Q4 TD 开放 0 维持（第 51 轮——VM-only 括号为诚实包络披露非债）；Q5 无降级自举（产品面世代补记 = 编译器段自举完备性的结构化收口——树面 2.3 已完备 + 产品面 2.5 收口，零降级）；Q6 版本族共变完整。

**§7.3 门审**：audit 264 case（Z17-Z24 新八案）+ 语料 85 全链维持 + 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（三 MUV 与 r87 移交清单一一对应 + 世代补记沿 1.7 谱系零新机制 + baked-input 操作形状为 §21.3 (2) 的诚实读法——设计依据成文）/ DEV-A 1.5（世代末位重排 = 零访问器迁移的最小触面设计 + 单源骨架复用三处[drive_dual_engines/rebuild_lit/run_vm_only 谱系]）/ QA-A 1.0（世代轴回归测试 = 补记的检测力臂 + 六负例 fail-closed + 组合守卫共变）/ ALG-C 1.0（不动点 = 编译器与其自编译产物的行为同一性——§9.25 BS-E 三机制闭合）/ SKL-A 不计权 PASS（fixpoint_tests 3.8s release 可接受）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.5 首刀交付**（开场三 MUV 闭合——§21.3 (2) 兑现）。下一入口 = **2.5 收口评估轮**（出口判据全量核对 + B8 不动点成本轴入册候选 + 2.6 构建编排评估窗开面前置）；行权轮十项全绿前置每轮维持。

# 9.90 Stage 2.5 收口评估轮：出口判据全量核对与 B8 不动点成本轴（第八十九轮 · r89 · Task 67 · v0.59.0）

**行权前置（十项复查——第六十三轮维持）**：六命令冷跑复现 **1369:0:0** + audit **264/264** + B 七轴带内（B1 7.0µs / B1a 1.0 逐位 / B1b 3.4-3.5 / B1c 1.5-1.6µs / B2 79.2-80.7ms / B3 7.6ms / **B4 gc 1/swept 1023 逐位一致第十二次连续** / B5 79.4-80.8ms / B6 46.8/47.6/218.7ns 三面 / B7 21.916-21.958ms 带内）+ TD 开放项 0（第 52 轮）+ 语料 85 + selfhost 五件 117/473/750/660/1257 + 谱系 §9.43-§9.89 在场 + 登记窗全零信号 + web T66 态（67-web 后置）+ 过度特化零结论。沙箱 cargo PATH 完好（第六次重置后首次免恢复——Rust 1.99.0 直承 r88 安装）。后台进程裁汰实录：初试 nohup 后台六命令在工具调用返回后被沙箱进程组清理截杀（log 停于 CLEAN）——改前台分步执行（§3.1 环境实态沿先例如实登记）。

**67-b 链重审（用户常设指令——reader→compiler 自举完备性每轮核验）**：五件自举态逐段复核维持——lexer ✓（r85 词法决策全 .krf）/ reader ✓（结构 r83 + 词法消费 r85）/ expander+macro ✓（MX-2 装配一体 + 世代 1.7 补记）/ compiler ✓（树面 r84 映射 100% + 产品面 r88 世代补记——双面完备）；**零新缺口**（r88 唯一缺口[产品面世代缺位]已于 r88 当轮清偿，本轮复核无复发）。FLAT 五件制裁定维持（.krf 无模块系统——目录化零语义增益；设计层谱系镜像 + harness 单装配点宪法归属）。stage0.md 分层纪律合规复核：§9.89 沿 §9.86 模板（裁定/设计依据+伪代码/技术锚/验收面/develop 引用）——§9.90 本轮同款。

**出口判据全量核对（2.5 承载面）**：
- **判据 (1)**「完整 kerf 编译器用 kerf 编写」：selfhost 五件全量过完整 .krf 链（组成链 r86 五件过链 + 第七次自应用 + fixpoint r88 不动点本体——常设测试证据链）；树面 compile.rs 33 函数 → compiler.krf defines 映射 100%（r84 对账）+ 产品面世代补记（r88）双完备——**核对通过**。
- **判据 (2)**「两次编译自身的结果字节一致」：`b_self_exec == b_self` 逐字节（fixpoint 测试常设复证 + 本轮 B8 轴 fail-closed 每跑断言——核对升格为机检钉扎）——**核对通过**。
- 判据 (3)(4) = 2.6+ 承载面（非 VM 后端评估 + FFI 所有权模型预裁），非 2.5 出口。

**B8 实施（不动点成本轴——r87 移交清单「B8 候选」兑现）**：`examples/bench/stage0_baseline.rs` +52 行——`fixpoint_selfhost_compiler()` 三相位整跑测量（C(S) 双引擎 + C(C(S)) VM-only 括号 + 重建产品 VM 执行）；7 iters + 3 warmup（单跑 ~3.6s 的测量预算裁定——与 B7 九跑 22ms 级总预算同量级）；fail-closed 双断言（warmup + 测量环各一：`fixpoint_holds` 为轴前置条件非产出，`Err` 通道携带分类漂移理由）；黑盒栅栏 + 四统计量（方法学 v2 沿袭）。守卫扩展（`perf_observability_guard_tests.rs` +2 断言）：B8 标签钉扎 + fail-closed 在场钉扎——T38 规则 5 制度化第二例（B7 首例）。

**B8 首录**：**median 3614.497ms / stdev 35.608ms / min 3594.790ms（7 iters）→ 不动点证明成本 = B7 组成链 165×**（21.916ms 基准）。消费面登记：2.6 构建编排评估窗的自举验证预算地板（B7×文件数 + B8×阶段数 = 自举构建总预算形状——§9.90.1）。

**2.6 开面前置登记**：下一入口 = Stage 2.6 收口评估窗（构建编排 .krf 化评估 + 非 VM 后端评估[QBE/C 其一——链外可选，宪制不入自举链] + FFI 所有权模型预裁[判据 (4) 阻塞项] + audit X 节 + 七件套 Stage 2 版 + 九信号 Stage 2a 口径——stage-2-plan §2 行 2.6 单源）。

**内循环实录**：零编译期缺陷（B8 为纯增量 example 面——首次构建即绿）；fmt 归一一轮（B8 断言块 rustfmt 多行归一）。无跨轮残留。

**六命令冷跑全绿（终态）**：cargo clean + build --release + check（0e0w）+ fmt 零 diff + clippy -D warnings 零告警 + test --release **1369:0:0 维持**（B8 为 example 面零测试函数增量；守卫断言内嵌既有函数）+ audit **264/264 维持**（评估轮零新 audit case——r87 先例）。B 八轴带内 + B8 首录（见上）。非英文编码面零新增。8 原语不变性**第六十二轮**验证（harness 测量面零冻结面变更）。

**版本面共变族 v0.59.0 十件**：Cargo.toml 0.59.0 + Cargo.lock + ds08 版本黄金（0.59.0 注记链 + 断言——v0.58.0 转前金链）+ RELEASE_NOTES v0.59.0 + README Status + roadmap v2.30 + stage-2-plan（Status 头 + §2 行 2.5 关闭 + 2.6 下一入口）+ stage0.md v9.56 三面（文档状态行 + §9.90 + 本节）+ calibration T2.5-2 行 + performance-baseline r89 行（B8 首录 + B 七轴复录）+ perf guard 注记共变。

**§7.2 六问**：Q1 无桩（B8 fail-closed 断言 = 覆盖声明机检化；评估轮零新生产面）；Q2 测试构成达标（守卫扩展强化既有函数 + 语料 85 全路由维持——评估轮零新正确性面零新测试义务，r87 先例）；Q3 文档同步完成（stage0 §9.90 v9.56 + round-records 本节 + stage-2-plan + roadmap v2.30 + RELEASE_NOTES + calibration + performance-baseline + ds08 金链 + README Status）；Q4 TD 开放 0 维持（第 52 轮）；Q5 无降级自举（评估轮零自举面变更——B8 为测量面）；Q6 版本族共变完整。

**§7.3 门审**：audit 264 case 维持 + 语料 85 全链重放维持 + 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（出口判据核对各有代码/测试实态锚 + B8 消费面成文）/ DEV-A 1.5（B8 纯增量零生产触碰 + 守卫制度化第二例）/ QA-A 1.0（fail-closed 每跑断言 + 首录数字四统计量披露）/ ALG-C 1.0（不动点成本 = §21.3 (2) 证明的预算面——与 B7 分工清晰）/ SKL-A 不计权 PASS（B8 十跑 ~36s bench 可接受）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.5 关闭**（fixpoint C 阶段完整交付：r88 首刀三 MUV + r89 出口判据核对 + B8 入册）。下一入口 = **Stage 2.6 收口评估窗**；行权轮十项全绿前置每轮维持。

# 9.91 Stage 2.6 评估窗开启轮：三裁决与七件套骨架（第九十轮 · r90 · Task 68 · v0.60.0）

**行权前置（十项复查——第六十四轮维持）**：六命令冷跑复现 **1369:0:0**（clean + build --release 10.94s + check 0e0w + fmt 零 diff + clippy -D warnings 零告警 + test --release 20 套件求和逐位）+ audit **264/264**（Z24 尾节点——评估轮零新 case，r87/r89 先例）+ B 八轴带内（B1 7.2µs / B1a 1.0 逐位 / B1b 3.8 / B1c 1.5µs / B2 79.311ms / B3 7.653ms / **B4 gc 1/swept 1023 逐位一致第十五次连续** / B5 79.360ms / B6 47.4/46.7/220.7ns / B7 21.831ms[自举乘数 3018× 带内] / B8 3616.890ms[vs r89 首录 3614.497ms +0.07% 带内；vs B7 166×]）+ TD 开放项 0（第 53 轮）+ 语料 85 + selfhost 五件 117/473/750/660/1257（与 r89 逐位一致）+ 谱系 §9.43-§9.90 在场（本轮 +§9.91 = 49 节）+ 登记窗全零信号 + web T67 态（68-web 后置）+ 过度特化零结论。环境实录：新会话 shell cargo PATH 缺失（~/.cargo/bin 内联导出恢复——Rust 1.99.0 直承 r89 安装；PATH 不跨工具调用持久，每命令内联）。

**68-b 链重审（用户常设指令——reader→compiler 自举完备性每轮核验）**：五件自举态逐段复核维持——lexer ✓（r85 词法决策全 .krf）/ reader ✓（结构 r83 + 词法消费 r85）/ expander+macro ✓（MX-2 装配一体 + 世代 1.7 补记）/ compiler ✓（树面 r84 映射 100% + 产品面 r88 世代补记双面完备）；**零新缺口**（r88 清偿后连续第三轮无复发）。FLAT 五件制裁定维持（.krf 无模块系统未变——目录化零语义增益；设计层谱系镜像 + harness 单装配点宪法归属）。stage0.md 分层纪律合规复核：§9.90 沿模板 → §9.91 本轮同款（裁定/设计依据+伪代码框/技术锚/验收面/develop 引用五段）。

**裁决一（构建编排 .krf 化评估——维持 Rust 构建引导，不开面）**：三依据落位。①使命分配：§21.1/§21.4 Stage 2 = kerf ~80% + Rust ~20%，构建引导为 Rust 份额宪法归属（与 VM 永久基座同列）；②处理程度：§21.3 Stage 3+ 判据 (2)「构建系统可用 kerf 重写」= 后续阶段承载面——2.6 开面即处理程度倒挂（§21.5 红线「禁止处理程度倒挂」）；③预算形状实测消费（r89 §9.90.1 成文公式）：B7 median 21.831ms（FIB 锚代理）× 文件数 + B8 median 3616.890ms × 阶段数——VM 执行相位 >98% 主导（B8 三相位中 C(C(S)) 装配编译与重建产品 VM 执行占绝对主体），.krf 化编排器自身将跑在 VM 上，成本不降反增且零语义增益（FLAT 同款论证：.krf 无模块系统）。自举链验证面不受 Rust 编排削弱：编译链全 .krf（五件）+ 产品逐字节验证（fixpoint C(C(S))==C(S) 机检钉扎 r88/r89）——Rust 面角色 = 装配 + 驱动 = 构建引导本义。**裁定：不开面；评估结论与 B7/B8 公式当前值登记为 Stage 3+ 判据 (2) 开窗时的测量基线**。

**裁决二（非 VM 后端评估窗——C 转译裁定，QBE 转 Stage 3+ 登记）**：判据 (3)「至少一个非 VM 后端工作（链外可选）」技术路线裁定 = **C 转译**。四依据：①零外部二进制依赖——发射文本，宿主 cc 为环境标配（vs QBE 需 vendored 二进制或 PATH 假设——§18 零外部依赖纪律 + T29 DAG 冻结先例）；②最大可移植性（§21.2 后端策略图 C 转译器定位）；③FFI 面协同（判据 (3)(4) 共享 C ABI 边界——与裁决三边界模型同构）；④可调试性（C 源可读 + cc -O0..3 档可调 + 标准调试器可及）。QBE 处置 = 转 Stage 3+ 候选登记（lang-design/08 §4 既有 QBE AOT 对照登记维持；§21.2 QBE 位维持链外可选并存）；Cranelift = SOP §2.5 登记态维持（in-process JIT 研究性）。**宪制重申：C 转译后端永不入自举链（编译器构建永不依赖 cc——链外可选）**。实施移交 = 2.6 后续轮首刀：C 转译发射器（bytecode→C）+ 宿主运行时 shim + cc 门控 e2e 验证（cc 缺席环境 = 跳过披露不失败）+ audit 新节（AA 起）——判据 (3) 工作位。

**裁决三（FFI 所有权模型预裁——判据 (4) 阻塞项解阻）**：四规则模型落档（stage0.md §9.91）。**R-F1 边界即时物化**：值跨界全量物化为基础 C 类型或显式句柄；零惰性穿越、零跨界堆引用。**R-F2 调用方所有 + 返回值转移**：实参存储归调用方；被调方获借视图（指针 + 长度）或副本；返回值所有权向调用方转移——kerf 侧 GC 根即时接管。**R-F3 跨调用持有 = 显式句柄根**：foreign 跨 kerf 分配点持有 kerf 值须显式根句柄（JNI global ref 同构）；局部借用限单调用内（local ref 同构——帧返回失效）。**R-F4 C ABI 对齐**：零名称修饰、禁按值结构体（指针 + 长度或句柄）；与 C 转译后端共享边界模型（裁决二协同面）。实施位 = 2.8 评估窗承载（FFI 可用性实施评估——预裁先行解阻，沿 stage-2-plan §1 判据 (4) 行「阻塞项须先裁」既定路径）。

**七件套 Stage 2 骨架（沿 1.8 GATE-4 骨架→1.9 终稿先例）**：六件落位 docs/develop/v2/stage-2/（architecture-review / design-impl-test-coverage / hidden-problems-assessment / refactoring-optimality-review / performance-baseline / final-assessment）+ 第七件 pipeline-test-coverage.md §9 Stage 2 增量小节（docs/tests/ 既有文件追加——Stage 1 先例同位）。每件 = 头部 Status（骨架——2.8 终稿义务）+ 截至 r90 现状基线段 + 2.8 终稿义务表（防骨架不填——1.8 先例的义务表机制）。现状基线锚：2.1-2.5 五子阶段关闭链 + 1369:0:0 + audit 264 + B 八轴 + TD 0 第 53 轮 + 五件 selfhost + fixpoint 机检钉扎。

**九信号核对（Stage 2a 口径——§21.5 九项对照）**：①语义稳定 ✓（1369:0:0 + 8 原语第六十三轮）②自举验证 ✓（C(C(S))==C(S) 机检钉扎——判据 (1)(2) r89 核对通过）③测试覆盖 ✓（语料 85 全路由 + audit 264 + 0 UNTESTED/≤5% DEFERRED）④性能基线 ✓（B1-B8 八轴 + 预算形状成文）⑤文档同步 ✓（本轮文档族十件 + 七件套骨架）⑥能力处理程度 ✓（Stage 2a 矩阵项无倒挂——fixpoint 窗全交付；后端 = 本轮裁决 + 实施位 r91+ 在 2.8 前交付窗口内）⑦技术债清零 ✓（TD 0 第 53 轮）⑧外循环投票 ✓（本轮 5.5/5.5）⑨阶段间深度验证 ⏳（2.8 末轮承载——七件套终稿 + D1-D8 + §14.6）。**计 8✓/1⏳**——Stage 2a 就绪度快照：待办 = 判据 (3) 后端实施（r91+）+ 判据 (4) FFI 实施（2.8）+ 第 9 信号（2.8）。

**内循环实录**：零编译期缺陷（零生产 crate 变更——仅版本面 [Cargo.toml + ds08 金链] 触碰）；无 fmt/clippy 事项（文档族为设计文档豁免位 + 版本面英文）；无跨轮残留。

**六命令冷跑全绿（终态）**：cargo clean + build --release + check（0e0w）+ fmt 零 diff + clippy -D warnings 零告警 + test --release **1369:0:0 维持**（ds08 金链断言随版本面共变——WORKSPACE_VERSION 0.60.0）+ audit **264/264 维持**（评估轮零新 case）。B 八轴带内（见行权前置——B4 第十五次逐位）。非英文编码面零新增（本轮触碰面 = 设计文档族豁免位 + 版本注释英文）。8 原语不变性**第六十三轮**验证（零冻结面变更——评估域）。

**版本面共变族 v0.60.0 十一件**：Cargo.toml 0.60.0 + Cargo.lock + ds08 版本黄金（0.60.0 注记链 + 断言——v0.59.0 转前金链）+ RELEASE_NOTES v0.60.0 + README Status + roadmap v2.31（版本头 + 当前位置行）+ stage-2-plan（Status 头 + §2 行 2.6 状态更新）+ stage0.md v9.57 三面（文档状态行 + §9.91 + 本节）+ calibration T2.6 行 + performance-baseline r90 注记行（零触碰轮复跑带内披露）+ 七件套骨架七件（v2/stage-2/ 六件 + pipeline-test-coverage §9）。

**§7.2 六问**：Q1 无桩（三裁决均有文档实态锚 + 骨架有义务表防骨架不填；评估轮零新生产面）；Q2 测试构成达标（评估轮零新正确性面零新测试义务——r87/r89 先例；1369:0:0 维持即构成维持）；Q3 文档同步完成（stage0 §9.91 v9.57 + round-records 本节 + stage-2-plan + roadmap v2.31 + RELEASE_NOTES + calibration + performance-baseline + ds08 金链 + README Status + 七件套）；Q4 TD 开放 0 维持（第 53 轮）；Q5 无降级自举（评估轮零自举面变更——FLAT 维持 + 五件零触碰）；Q6 版本族共变完整（十一件）。

**§7.3 门审**：audit 264 case 维持 + 语料 85 全链重放维持 + 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（三裁决各有 §21 条款 + 实测锚 + 先例链——C 转译四依据闭合，FFI 四规则与 JNI/Rust/WASM 锚对位）/ DEV-A 1.5（零生产变更 + 移交清单明确——r87 形态）/ QA-A 1.0（骨架义务表防骨架不填 + 九信号快照如实 8✓/1⏳ 非满分虚报）/ ALG-C 1.0（C 转译 = PreScheme/CHICKEN/GHC -fvia-C 谱系正位；FFI 模型避 CPython 反例）/ SKL-A 不计权 PASS（评估域可审性——裁决依据全部落档）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.6 评估窗开启（不关闭——判据 (3) 工作位未落）**。本轮交付 = 三裁决 + 七件套骨架 + 九信号 Stage 2a 口径 8✓/1⏳；下一入口 = **2.6 实施首刀**（C 转译发射器 bytecode→C + 宿主运行时 shim + cc 门控 e2e + audit AA 节——判据 (3) 工作位；B 型审查先行[PreScheme/CHICKEN 发射器设计锚检索]→ 设计对齐[发射器架构 + shim 值模型]→ 实现）；行权轮十项全绿前置每轮维持。

## 9.92 第九十一轮（r91 · v0.61.0）：2.6 实施首刀——C 转译后端三层落地

**行权前置（十项复查——第六十五轮维持）**：六命令冷跑复现 **1369:0:0** + audit **264/264** + B 八轴带内（B1 7.0µs / B1a 1.0 逐位 / B1b 3.6 / B1c 1.6µs / B2 79.279ms / B3 7.648ms / **B4 gc 1/swept 1023 逐位一致第十六次连续** / B5 79.189ms / B6 48.5/48.9/224.1ns 三面 / B7 22.231ms[自举乘数 3189× 带内] / B8 3627.726ms[vs r90 3616.890ms +0.30% 带内；vs B7 163×]）+ TD 开放项 0（第 54 轮）+ 语料 85 + selfhost 五件 117/473/750/660/1257（与 r90 逐位一致）+ 谱系 §9.43-§9.91 在场（本轮 +§9.92 = 50 节）+ 登记窗全零信号 + web T68 态（69-web 后置）+ 过度特化零结论。环境实录：cargo PATH 内联导出恢复（Rust 1.99.0 直承 r90 安装）；cc 探针在场（Debian gcc 14.2.0 `/usr/bin/cc`——链外门控环境面）。

**B 型审查先行（新域义务——§1.2）+ §13.1 设计对齐**：锚 K204-K210 落档（§9.92.2——PreScheme[源级受限转译先例·差异锚：无 CPS——栈字节码直接指令级下降] / CHICKEN[CPS-in-C·差异锚：显式 arena + 预算 fail-closed vs 栈 nursery] / GHC -fvia-C[低层 IR→C 正典·差异锚：单文件发射——shim 内嵌无独立 rts] / mrustc[消费冻结 IR 不入自举链的存在性证明] / Steele-White·Ryū[最短往返数字] / K152 沿引[单分派适配点] / TD-023 对照[宿主栈边界]）。设计对齐三件落位：发射器架构（静态编址 st[]——深度 DAG 镜像 verify / goto 控制流 / k_call 单 trampoline）、shim 值模型（KValue 16B + 字节 arena + 18 内建单源映射 + 输出缓冲镜像 `kerf run` 契约）、e2e 门控（cc 探针 + 跳过披露句式钉扎）。

**交付一（kerf-cbackend crate——发射器 + shim）**：`crates/kerf-cbackend/`（第 12 个 workspace member + default-member + 根 re-export `kerf::cbackend` + driver 依赖[唯一消费位]）。三源文件：`src/emit.rs`（发射器 ~700 行：KConst 池[浮点 u64 位模式/字符串十六进制字节数组/pair 后序 KLit 树] + per-proto 函数发射[locals nil 填充镜像 Frame::new + st[N] 静态编址 + 每指令标记注释 + 不可达块跳过+fail-closed 标记] + k_call 生成[per-proto 臂含 arity 检查 + proto 名] + 全局种子[Builtin::from_name 发射期解析→KB_ 码] + main 模板 + K_DEPTH_CAP 最坏帧自适应计算[frame_bytes = (NLOC+STACK+max_argc+max_ncap)×16+192；6MiB/帧]）；`src/depth.rs`（DAG 深度分析——verify_depths 逐位镜像：leaders/propagate/worklist/不可达分类/stack_size 上界）；`src/shim/kerf_rt.h`（~660 行 C11+POSIX：KValue/KPairCell/KClosureCell[env[1] 过配额形] / KVm / 字节 arena[k_arena_alloc 8 对齐倍增] / k_charge[reserve_exact 镜像——单检查可 overshoot n-1] / k_enter·k_leave[深度守卫] / k_mk_pair·k_mk_pair_nochg[计费/预计费双胞胎] / k_lit_mk[from_literal 分配序镜像] / 18 内建 k_builtin_call[per-臂 arity + 族消息] / k_eq[浮点位比较·字符串内容比较·cell 偏移等同] / UB-free 检查算术[k_iadd/k_isub 符号公式 + k_imul 幅值法 + k_idiv INT64_MIN/-1] / k_perform[rposition 镜像最近安装者] / k_fmt_double[%.*e+strtod 回读搜索 + 纯小数渲染 + inf/-inf/NaN/-0 特殊形] / k_finish[输出行先行 + 非 nil 值显示——`kerf run` 契约]）。**宪制落位**：crate 为 DAG 纯消费叶子（依赖 compiler/core/span/vm，零被自举链引用）；发射器头标「chain-external; never part of the bootstrap chain」逐文件声明。

**交付二（driver emit-c 接线——1.8 教程条款同轮接线）**：pipeline.rs `ParsedProgram::c_source()` + `emit_c_source()`（check 镜像形态：检查器警告不阻断；发射器拒绝 → Diagnostic::from_emit 进同批诊断）+ EmitCOutcome 导出；cli.rs `emit-c <file>` 子命令（usage 更新含单文件编译指引行）+ 4 单元测试（parse 单文件严格性 / 头标+main 在场 / 拒绝产物零 C 文本 + 诊断渲染）。

**交付三（e2e cc 门控 + 语料全量重放）**：`tests/v1/stage1/plan/c_backend_e2e_tests.rs`（15 测试：13 常设 + 2 #[ignore] 显式重负载）+ runner.rs 挂载。常设面：cc 门控披露句式钉扎 / 手搓字节码值显示对账 9 例[42·i64::MIN/MAX·bool·nil[**驱动器 nil 静默契约**]·带引号转义字符串·空串·pair 不透明形] / **浮点电池 12 例**[0.1·0.30000000000000004·1e21·1e-7·-0.0·inf·-inf·NaN·1/3·5e-324 最小次正规·f64::MAX·-2.75] / fib(25) check 包装双引擎 / LA-4 传递捕获双层闭包 / handle·perform 效应往返 / read-line 双行 stdin / 三行输出序列逐字节 / 运行时错误族 3[除零·i64 加法上溢·未绑定全局] / arity 代表 3[+·cons·write-line——栈序修正实录：§19.3 被调方在栈顶] / 预算覆写[-DK_BUDGET=24 × 40 cons 链] / 深度覆写[-DK_DEPTH_CAP=8 × 深度 40 递归] / 源级发射确定性。#[ignore] 面：**语料 C 全量重放**（85 案全路由：值案经 check 包装[末 define 全局 + repr 分类——`=`/`eq?`/#t·#f 字面量映射]双引擎同验 + 运行时错误案双非零；**41/41 执行位全对账**，40 前段拒绝 + 4 repr 类跳过均披露行）+ **B 面测量**（发射成本 2000 iters median 7.4µs / cc -O0 103.6ms / C 二进制 fib(25) 10 runs median 24.548ms——bash time 复测 -O2 档 ~12.3ms：-O0 3.2× / -O2 6.4× vs B2 79.3ms）。

**交付四（audit AA 节——264→274）**：AA1 发射确定性 + 宪制头标 + K_BUDGET 钉扎（零 cc 面）/ AA2 即时值显示 6 / AA3 浮点电池 8 / AA4 fib(25) / AA5 捕获+效应 / AA6 arity 族 3 / AA7 预算覆写 / AA8 深度覆写 / AA9 unbound + ret-from-entry[**verify 深度守卫实录：单 ret 在深度 0 下溢——可达形态 = push-const;ret**] / AA10 read-line I/O + 门控披露钉扎。**守卫基础设施共变**：test_infra_guard 审计清单守卫升级双字母节（String 节键 + 1-2 位数字标签文法——「AA 为首个双字母节；节字母表于 Z 耗尽，§7.3.1 规则 4 单调增长沿 AA 延续」；label_counter 夹具测试同步共变）。

**内循环实录（四缺陷全数内环修复）**：①k_fmt_double NaN 检测式（指数全 1 判定先于尾数——电池 f11 逐位清偿）；②Call argc=0 发射索引（st[d]→st[d-1]——arity-write 案捕获）；③e2e 夹具栈序（被调方在顶——arity 族捕获）+ nil 静默契约期望（驱动器 `kerf run` 契约再核对）；④check_form 布尔字面量映射（true/false → #t/#f——kerf 源面非 Rust 字面量）+ 单 ret 深度下溢（AA9 夹具可达化）。零跨轮残留。

**六命令冷跑全绿（终态）**：cargo clean + build --release 11.15s + check 0e0w + fmt 零 diff + clippy -D warnings 零告警 + test --release **1405:0:0**（+36：cbackend 单元 20 + e2e 13 + cli 4——2 ignored 披露[重负载显式面]）+ audit **274/274**。B 八轴带内（见行权前置终态：B1 7.1 / B2 79.651 / **B4 第十七次逐位** / B7 21.902ms[3073×] / B8 3626.859ms[166×]）。非英文编码面零新增（C shim 全英文注释——R8 四层扩展至发射产物面；发射器 Rust 面英文）。8 原语不变性**第六十四轮**验证（消费侧新面零冻结变更）。

**§7.2 六问**：Q1 零桩（四处 R1 判断实录：k_consts 空池 NULL 指针 = 设计[零 push-const 即零读]；kcap NULL = ncap=0 契约；st 空栈免声明 = 零触达推导；不可达块跳过 = 语义空集证）；Q2 构成维持+（25 操作码全发射路径单元钉扎[源面 14 + 手搓补 10] + 18 内建名单源映射 + 浮点显示 12 例 + 负面族 8）；Q3 文档同步（§9.92 + 本节 + plan/roadmap/calibration/RELEASE_NOTES/七件套骨架五件共变 + tests/matrix）；Q4 TD 0（第 54 轮维持——注册边界四项入 hidden-problems 非开放 TD[链外可选后端的首刀登记面，2.8 评估窗承载]）；Q5 零自举面变更（kerf-vm 零触碰；selfhost 五件逐位；fixpoint/门 B 零引用新 crate）；Q6 版本族完整（v0.61.0：Cargo + ds08 金链 + RELEASE_NOTES + 各文档版本头）。**§7.3 门审**：audit 274（AA10 新节）+ 语料 85 全链重放维持 + 语料 C 通道 41/41 + 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（三层结构与裁决二四依据逐位对齐 + 宪制隔离[DAG 叶子零自举引用]）/ DEV-A 1.5（消费面单源纪律[Builtin::ALL 穷尽 match + 命名奇偶守卫] + 驱动同轮接线 + 四缺陷内环清偿实录）/ QA-A 1.0（1405:0:0 + 274/274 + 41/41 + 2 ignored 披露设计 + 门控缺席路径钉扎）/ ALG-C 1.0（K204-K210 谱系正位——静态编址 + 单 trampoline + 位模式常量为发射器设计的可辩护形态；UB-free 检查算术可复核）/ SKL-A 不计权 PASS（全部裁决依据与边界登记可审）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：2.6 实施首刀交付（判据 (3) 工作位落地——C 转译后端工作实证：语料 41/41 + audit AA + e2e 常设面）。剩余 = **2.6 收口评估**（判据 (3) 终核[工作实证已具备——收口轮核对口径与七件套回写] + 九信号第 9 项仍 ⏳[2.8 承载]）；下一入口 = 2.6 收口评估轮；行权轮十项全绿前置每轮维持。

## 9.93 第九十二轮（r92 · v0.62.0）：2.6 收口评估——Stage 2a 三判据终核与七件套回写

**行权前置（十项复查——第六十六轮维持）**：六命令冷跑复现（clean + build --release **12.05s** + check 0e0w）+ **fmt 漂移一处捕获→当轮清偿**（test_infra_guard_tests.rs:240 `assert_eq!(counted.get("AA"), ...)` 双字母节断言行超宽——0bdf64c 起带入交付态；`cargo fmt` 恢复零 diff，+5/-1 零语义变更；根因 = r91 该行最后编辑晚于终态 fmt 检查）+ clippy -D warnings 零告警 + test --release **1405:0:0 维持**（2 ignored 披露维持）+ audit **274/274 维持** + B 八轴带内（B1 7.0µs / B1a 1.1 逐位 / B1b 3.7 / B1c 1.6µs / B2 80.175ms / B3 7.678ms / **B4 gc 1/swept 1023 第十八次逐位** / B5 80.068ms / B6 49.0/48.5/217.1ns / B7 22.090ms[3163× 带内] / **B8 3614.539ms 带内[vs r89 首录 3614.497ms +0.001%；164×]**）+ TD 开放项 0（第 55 轮）+ 语料 85 + selfhost 五件 117/473/750/660/1257（与 r91 逐位一致）+ 谱系 §9.43-§9.92 在场（本轮 +§9.93 = 51 节）+ 登记窗全零信号 + web T69→T70 态（70-c 仓库浏览器同步先行 + 70-d 后置）+ 过度特化零结论。环境实录：沙箱后台进程两度被回收（nohup/setsid 均不存活——冷跑链转前台分段执行，如实登记；cargo PATH 内联导出沿 r91 先例）。

**收口核对（三源交叉——§9.93.1 方法论第四次行使）**：判据 (1) 全链 .krf 化 = 树面对账（r84 函数级映射 33→83 逐行 100% + 文法/操作码覆盖清点 + 字面量过度特化扫描零语料特异）× 产品面世代补记（r88 CP-1 世代整数）× 常设证据（composed_full_chain + fixpoint_tests 11 件 + gate_b_elevated 全语料 sweep——本轮 test --release 复现全绿）；判据 (2) 自举不动点 = b_self_exec == b_self 逐字节（r88 兑现）× B8 带内复跑（3614.539ms）；判据 (3) 非 VM 后端工作 = C 转译三层（r91）× **语料 C 全量重放 41/41 本轮 #[ignore] 复跑**（corpus_c_replay_full_sweep ok）× audit AA 274/274 × B9c 复跑带内（发射 median **7.2µs** / cc -O0 83.6ms / C 二进制 fib(25) median **23.906ms** vs VM ~79ms ≈ **3.3×**——r91 首录 7.4µs/103.6ms/24.548ms 带内）。九信号 Stage 2a 口径 **8✓/1⏳ 维持**（⏳ = 第 9 项阶段间深度验证——2.8 承载）。

**七件套 2.6 行回写**：architecture-review（现状基线 2.6 关闭行 + 义务表行 3 状态翻转「已落地→已终核」）/ design-impl-test-coverage（2.6 收口行）/ hidden-problems-assessment（注册边界四项维持 + 收口核对行）/ performance-baseline（B 轴 2.6 收口快照 + B4 第十八次/B8 带内）/ refactoring-optimality-review（2.6 收口行——fmt 清偿实录）/ final-assessment（出口判据 (3) 翻转 ✓ + 义务表行 1 状态翻转）/ pipeline-test-coverage §9（2.6 收口复跑行）。各件 2.8 终稿义务表维持。

**文档族十一件**：stage0.md §9.93（v9.59 头 + 20131 行）+ round-records #9.93 + roadmap v2.33 + stage-2-plan Status/§2 行 2.6 关闭 + calibration T2.6-3 + RELEASE_NOTES v0.62.0 + 骨架六件 + pipeline-test-coverage §9 + Cargo 0.62.0 + ds08 金链（版本断言 0.62.0 + 先行金链注释段）。

**§7.2 六问**：Q1 零桩（评估域零新代码面；fmt 清偿为格式面零语义——R1 判断实录：无桩）+ Q2 构成维持（评估轮零新测试——1405:0:0 + audit 274/274 维持即收口口径；语料 C 41/41 复跑 + B9c 复跑为实证面非新增面）+ Q3 文档同步（十一件共变）+ Q4 TD 0（第 55 轮维持；fmt 漂移 = r91 遗留交付面缺陷——按 §6.2 分类为 P2 规范类，本轮当轮清偿不入 TD 册）+ Q5 零自举面变更（kerf-vm 零触碰；selfhost 五件逐位；fixpoint/门 B 零变更）+ Q6 版本族完整（v0.62.0：Cargo + ds08 + RELEASE_NOTES + 各文档版本头）。**§7.3 门审**：audit 274 维持 + 语料 85 全链重放维持 + 语料 C 通道 41/41 + 七类错误 7/7 维持。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（三判据证据链三源闭合 + 宪制边界重申[K214]）/ DEV-A 1.5（评估域零生产变更 + fmt 清偿微改零语义 + 移交清单明确）/ QA-A 1.0（1405:0:0 + 274/274 + 41/41 + B9c 带内 + 冷跑纪律捕获 r91 漂移的检测力实证）/ ALG-C 1.0（收口方法论沿 r89 谱系第四次行使 + 九信号如实 8✓/1⏳ 非满分虚报）/ SKL-A 不计权 PASS（全部核对依据落档可审）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.6 关闭（Stage 2a 收口）**——判据 (1)(2)(3) 三源终核全过 + 九信号 8✓/1⏳ + 七件套 2.6 行回写。下一入口 = **2.7 语法替换窗开窗评估**（#15 门控信号核对——零信号不开窗维持[EBNF v9 定稿 §9.26 + 皮肤字典 §9.20 在场但切换窗信号未至] + 开窗五步流程就绪度登记 + 用户行权双前提裁定；2.8 承载第 9 信号与 Stage 2 末轮 L3 收口）；行权轮十项全绿前置每轮维持。

## 9.94 第九十八轮（r98 · v0.63.0）：2.7 切换窗开启——门控核对 · B2 裁定 · 步① 种子段

**轮形**：开窗轮（评估 + 实施同轮——r79「门开启 + 首刀同轮」先例形态）。会话起点 = r97 闭合态（两树存活 + 工具链存活 + 双镜像逐位一致——本会话非恢复形态，环境勘定即 76-a 闭合）；用户消息双触发：推进句式行权（「好了就可以按照规划和计划继续推进项目了」——「排期已确定则继续推进」句式族，stage-2-plan §0 第 3 条先例；前置有效性全绿）+ 常设指令全量重申。

**76-b 开窗评估三件套**（单源 = switch-window-plan.md §0）：①#15 门控五信号核对全过（Stage 2a 收口质量信号 / EBNF v9 定稿 / 皮肤字典基础 / parity 底座 / 零自举链风险——种子并行新增非替换）；②用户行权闭合（句式族命中 + 前置全绿——禁令复活条件不成立）；③**B2 三方案裁定为方案①**（§9.42.4 P1 开窗前置义务清偿：if/perform/handle 表达式位入 primary——内核表达力对齐 + Koka/OCaml 5/Rust 三先例 + 皮肤字典完备性；方案③ 会打破嵌套效应语料 parity 面；match_expr 位裁定先行、实施随步②）。**裁定：窗口开启。**

**76-c 步① 种子段交付**（`crates/kerf-reader/src/target.rs` 1743 行含 35 单测 + `error.rs` 四新变体 + `lib.rs` 接线 + `tests/v1/stage1/plan/target_reader_seed_tests.rs` 8 集成 + audit AB 节 10 case + 守卫计数 274→284）：

- **映射面**（皮肤字典实施版——switch-window-plan §2 表）：fn/module/use + 类型标注丢弃 + do/let 后向折叠（多绑定逗号形 r110——`{ p; let A; tail }` → `(do p' (let A tail'))`，嵌套 do ≡ 平面 do 的 CoreExpr 一致性）+ 14 级优先级运算符皮肤（`==`→`=`、`!=`→`(not (= ..))`、`&&`→`(if a b false)`、`||`→`(if a true b)` 短路脱糖、一元族）+ B2 表达式位 + 缺省 else→nil + resume 返回即续体恢复 + 调用形通则（define/quote 零特判）+ 宏标记丢弃（头部经 expander 作用域键判决）+ C-C1（`a::b`→`a/b`）+ C12（`()`→`nil`）+ v9 词法层全集（radix/`_`/`\u{}`/嵌套注释/ASCII 标识符域）。
- **种子域边界 fail-closed**：UnsupportedTargetForm 专用变体 15 案 sweep 钉扎（类型声明五件/match/泛型/where/cast/range/字段/索引/halt/pass/use 路径形——步② 注册义务永不静默接受）。
- **parity 契约实施**（§9.25.4 分层裁定落地）：**语义投影全等**（per-proto name/params/n_locals/captures/指令流 + 常量池 + 全局表——debug_info 跨皮肤必然不同源文本故排除）+ **行为等价**（VM 值一致）。**首轮修正实录**：初版误用字节级断言（含 debug_info）被测试网大声否决（偏移必然不同）——分层裁定非理论姿态而是实测否决的修正（★ORCH-1 否决-修正谱系新例）；quote 符号载荷双皮肤一致地在展开层拒绝（reader 宽容度 parity——expander 是门）。
- **嵌套帽**：目标分隔符共用 NESTING_LIMIT=256（REC-A 同形树纪律——audit AB9 钉扎帽位与 S-expr 面等帽）。

**六命令冷跑全绿（终态）**：cargo clean（217.8MiB）+ build --release **12.21s** + check 0e0w + fmt 零 diff（clippy vec_init_then_push 17 处 + while-let 一处 + 复杂类型一处当轮清偿——`vec![]` 宏化/类型别名化）+ clippy -D warnings 零告警 + test --release **1448:0:0**（+43：reader crate 单测 35 + 根树集成 8——主套件 603 passed + 2 ignored 披露维持）+ audit **284/284**（AB 新节——第二双字母节；组成：parity 三锚 AB1-AB3 + B2 表达式位 AB4 + 运算符皮肤 AB5 + 关键字经济 AB6 + C-C1 AB7 + 边界 15 案 AB8 + 词法错误面 AB9 + 展开门 parity 与 R8 消息钉扎 AB10）。非英文编码面零新增（target.rs/error.rs/测试/audit 全英文——设计文档中文沿 R8 豁免位）。语料 85 维持 + selfhost 五件逐位维持（步③ 义务）。B 轴：种子为并行新增非替换——生产链零变更（B 轴复跑义务随步④ 前置承载；本轮 B4 未重跑——种子零生产面触碰，如实登记）。8 原语不变性**第六十六轮**验证（Reader 皮肤面 = 零原语零通道零 VM 零冻结面变更）。

**文档族十二件**：stage0.md §9.94（v9.60 头 + 20131→20158 行）+ round-records #9.94（本节）+ **switch-window-plan.md v1.0 新建**（开窗评估 + 五步 MUV + 皮肤字典实施版 + 验证契约 + 风险登记）+ roadmap v2.34 + stage-2-plan Status/§2 行 2.7 开启态 + calibration T2.7-1 + RELEASE_NOTES v0.63.0 + hidden-problems #15 翻转行 + Cargo 0.63.0 + ds08 金链（版本断言 + 先行金链注释段）+ tests/matrix（若有新面）。

**§7.2 六问**：Q1 零桩（四处 R1 判断实录：无——种子域边界全部 fail-closed 专用变体非桩；`parse_type_drop` 丢弃面 = 设计[标注为表面糖 HM 层所有]；`use "string"` 过渡形 = 注册[步② C-C1 政策]；resume 载荷丢弃 = 皮肤条目[返回即恢复语义]）；Q2 构成达标（+43：单测 35 正 22/负 13 + 集成 8[跨阶段消费 parity 三锚 + 正向 2 + 负向 3]——正负比 ≥1:3 集成面负向 3 + 单测负向 13 达标；audit AB 10 case）；Q3 文档同步（十二件）；Q4 TD 0（第 56 轮维持——步②③ 注册义务入 switch-window-plan 排期表非开放 TD）；Q5 零自举面变更（kerf-vm 零触碰；selfhost 五件逐位；S-expr Reader 全链维持——种子并行新增）；Q6 版本族完整（v0.63.0：Cargo + ds08 + RELEASE_NOTES + 各文档版本头）。**§7.3 门审**：audit 284（AB10 新节 + 七类错误 7/7 维持 + 上轮修复边界 case = 无上轮 P0 修复——边界族由 AB8 15 案 sweep 承载）。**§6.3 投票（单 Agent 模拟披露）**：ARCH-A 2.0（开窗三件套依据链闭合 + B2 方案① 三先例对齐 + 并行新增零自举风险）/ DEV-A 1.5（皮肤字典映射零特判设计[调用形通则] + do/let 折叠 CoreExpr 一致性论证 + clippy 全清）/ QA-A 1.0（1448:0:0 + 284/284 + 语义投影断言 + 否决-修正实录如实登记）/ ALG-C 1.0（B2 方案① 与内核表达力对齐——皮肤字典完备性主张维持；C12/C-C1 逐条对齐 §9.26 裁定）/ SKL-A 不计权 PASS（switch-window-plan 单源可审 + 步②-⑤ 排期明确）→ 加权 5.5/5.5 = 100% ≥ 95% APPROVED。

**收敛口径**：**2.7 窗口开启 + 步① 种子段交付**。剩余 = 步②（词法/语法批：match + 模式族 + 类型声明承载裁定 + where/泛型/cast/range/字段/索引/halt/pass 映射或豁免 + use 路径形 C-C1 政策 + E5 批次 1 名称政策）→ 步③（C 类语料 4/4 三路门 + E5 批次 2）→ 步④（目标语法自身编译——自举管道铁律前置）→ 步⑤（验证等价 + E5 批次 3 收口）；2.8 承载第 9 信号与 Stage 2 末轮 L3 收口；行权轮十项全绿前置每轮维持。

---

## 9.95 Stage 2.7 步② 实施记录（v9.61——第九十九轮 r99 · Task 77 · v0.64.0）

#### 9.95a 裁定件（Task 77-a）

- switch-window-plan.md v1.1：§5 六项裁定表（A/A′/B/C1/C2/C3-C5/D/E——核心映射 5 + E5 豁免 5，每项依据链三锚：内核承载/语料信号/反过度特化）+ §5.2 模式族域（实施 8 形 + 登记 6 形，同一性原则锚）+ §5.3 验证契约增量；裁定 C1 初判「裸 ident 丢弃」经词法核查**翻转**为 E5 豁免（v9 type_param 只有撇号形——裸形不在定稿域，解析它 = 发明语法；词法修正实录）。

#### 9.95b match 实施（Task 77-b/b2）

- **expander**（expand.rs +408 行）：`expand_match`（臂结构校验 → 穷尽性门 → scrutinee 展开 → 右折叠 arm 链 → 载体 Let 包裹）+ `compile_pattern`（PatternArm{test 集中形, binds}——数值 `=` / Bool·Str `eq?` / nil `nil?` / `_` 恒真 / 绑定 / 二元 tuple `pair?`+car/cdr 递归 `and_chain`（&& 脱糖形）/ 单元透传 / 三元+ UnsupportedPattern）+ `MATCH_SCRUTINEE = "match(scrut"`（`(` 锚定双面不可写——Symbol 接受无空白文本；嵌套词法隔离）+ `expand_arm_body`/`expand_arm_body_bound` 拆分（fresh_scope 着色 + 帧弹出全路径——clippy redundant_closure_call 规避）+ 分发臂 + RESERVED_MACRO_NAMES + error.rs 两变体（NonExhaustiveMatch/UnsupportedPattern，R8 消息）+ form_shape 模板。
- **target.rs**（+363 行）：`parse_match_expr`（KwMatch 分发两处——parse_item 移除 fail-closed 走 expr_stmt、parse_primary 走专用解析；臂尾逗号必需 = handle 同款；守卫/or 前后双侧检查 fail-closed）+ `parse_pattern`（Int/Float/Bool/Str atom / KwMut 丢弃 / Ident / `()`→nil 符号（C12）/ `(p)` 透传 / `(p1,p2)` 二元 / 逗号后 `)` 拒绝 / 三元+ fail-closed）+ `parse_use_decl` 路径形（`use_segment` 取 peek().text 原文——模块名空间不经 E5 皮肤）+ `parse_generic_args_drop`（`<` type_list `>` 丢弃——parse_type_drop 的 Ident 分支挂接）+ `skin_symbol`（lexer 令牌面两项映射表）。

#### 9.95c 验证与 audit（Task 77-verify/audit）

- 测试族：reader 单测 5 新 1 超期删（86→93——含 span-盲结构比较与 Display 断言）；expander api_tests 5 新（same_shape 深比较 helper——CoreExpr Display 为 kind_name 短名不可用于结构断言的适配）；根树集成 6 新 2 超期改（86→93 计入他册——target_reader_seed 8→14：parity 双锚[match 分类 + tuple 拆解]/行为等价/fallthrough/遮蔽嵌套/负向族[含 expand 期 NonExhaustiveMatch]）。
- audit AC 节 10 case（294/294）：AC1 parity 锚 / AC2 字面量 fallthrough / AC3 tuple+nil 双值 / AC4 穷尽门（R8 消息钉扎）/ AC5 登记面三名 / AC6 use parity / AC7 E5 皮肤落名（globals 含 kebab 名断言）/ AC8 泛型丢弃 parity / AC9 豁免面 / AC10 嵌套载体。AB6 更新（`match(x)` 调用不可能——缺 arm 块死于 expect 而非旧 UnsupportedTargetForm）；AB8 表更新（match/use 路径移出种子边界表）；test_infra_guard 组合表 +AC10/总数 294/headline 三处同步。
- 环境校准两项（§9.95.3）：audit 深栈线程 64→1024 MiB（r98 stash 复验同溢出——环境非回归；64→256→1024 阶梯实测）；根树 cargo test 需 `RUST_MIN_STACK=16M`（source_bounded_tree 线程栈）——**运行环境注记入 worklog 与基准表**。
- 测试终态 **1463:0:0**（+18/-3）；六命令双 profile 全绿（build --release / check / fmt --check 零 diff / clippy -D warnings 零告警 / test / test --release）。

#### 9.95d 自纠实录

- ①裁定 C1 自纠：初判「fn 头泛型裸 ident 形解析丢弃」→ 词法核查发现 v9 type_param 只有撇号形（`'a`）——裸形解析 = 发明语法 → 翻转为 E5 豁免 + 词法缺口登记（裁定文档 §5.1 同轮修正——「文档与代码冲突以代码为准」的反向应用：文法与词法自洽性核查先于实施）；
- ②`Symbol::new` 空白拒绝自纠：载体名初设计 `match scrut`（含空格）——编译期 `InvalidSymbol` 立即否决（Symbol 域拒绝空白/控制字符）→ 改 `(` 锚定 `match(scrut`（双面词法域外 + Symbol 域内——设计假设「Symbol 允许空白」未经查证即实施，编译器即时报错为测试网纪律的正例）；
- ③测试期望值三连自纠：`-1` 一元负号脱糖先例（v9 词法无符号整数——目标面 `-1` = `(- 0 1)`）；or-pattern/use-tree 的 fail-closed 检查点前移（`|` 在 pattern 后、`{` 在 `::` 后——检查点在解析位非臂首位）；S-expr 手写等价程序括号层级（let spec `((s n))`）与布尔字面量 token（`#t`/`#f` 非 `true`/`false` 符号）——均为「目标面/S-expr 面词法差异」的期望值适配，实现零变更；
- ④audit AB6/AB8 r99 语义更新：match 核心映射后旧钉扎面失效——更新为「调用不可能」（expect 失败位）与表项移出（AC 承载），非删除历史（AB10 Display 格式钉扎保留——构造任意 form 文本测试格式不变性）。


#### #9.96 r100——Stage 2.7 步③：C 类语料 5/5（Task 78 系列 · v0.65.0 · §9.96）

> 裁定单源 = switch-window-plan §5.4（v1.2）；知识层 = stage0.md §9.96。本节为实施细节记录。

- **78-a target.rs 三扩展**：①E5 批 2 皮肤（skin_symbol 重写——内建表五项 first/rest/pair/eq/set + 通则 P 谓词段 + 通则 K 内部分隔符；空白标记族透传修正——`_` 通配符经规则 K 会变 `-` 的实测否决与精化）；②quote 数据载体（parse_datum 数据模式——元组列表/分组/尾逗号单元素/`()` fail-closed/词面关键字/负数字面量；调用位挂 parse_postfix）；③else-if 链核查（v9 if_stmt 产生式既有——r98 已实施，本轮核验零变更）。单测 +9（表/谓词/空白/载体/负向族）。
- **78-b/c 五件翻译与 harness**：driver 新模块 target_corpus.rs（四前缀目标面孪生 + 五源常量 + assembled_expander_target_source + 命名守卫回读校验）；reader.ktf 主代理手译（117→143 行管道贯通证明）；lexer.ktf 665 行 + macro.ktf ~700 行（子代理首刀 + 主代理 rest 碰撞手术）；expander.ktf（子代理草稿——`let _ = set(...)` do 脱糖直拼形 + 主代理验收）；compiler.ktf 1500 行（子代理——do 调用形载体 + quote(-1) 负字面量载体 + 中位 let 块表达式）。
- **三路门 harness**（tests/v1/stage1/plan/target_corpus_parity_tests.rs）：门 1 语义投影（SemanticBytecode 复用形）+ 门 2 全全局 VM 行为（global_names 迭代——堆索引可比性 = 恒等字节码 + 确定性执行）+ 门 3 α-等价（AlphaMap 双射 + 捕获避免 + 单射强制；全局/效名字面）。10 测试：四件三路门 + 三负向族（reader 三拒绝/lexer 拒字节/expander 语义错/compile 错）+ 记录文法跨阶段抽查 + 前缀孪生。
- **自纠实录**：①`_` 通配符被规则 K 破坏（match 测试实盘否决 → 内部分隔符限定）；②`rest` 碰撞的语义遮蔽发现（子代理报告名漂移 → 主代理核验 `(lx-take-bytes (cdr rest) ...)` 实为内建遮蔽语义断裂 → 裁定 H 孪生改拼 remaining + α-等价门升格）；③r98「嵌套 do ≡ 平面 do」口径修正（compiler 子代理实测：字节码面成立/树面不成立——裁定 I 登记）；④expander/compiler 子代理超时两次——首超时已写出草稿（54/54 defines 完整）——超时交接实录（主代理验收 + 三 do 位点手术）；⑤audit AD2/AD5/AD10 三处探针修正（未绑定谓词 → 双面定义；符号数据过值模型门 → 读者面单测域；probe 括号）。
- **78-d 守卫与审计**：audit AD 节 10 case（294→304/304——第四双字母节：表/谓词/空白/载体/形状/fail-closed/四件语料门）；test_infra_guard 三处同步（组合表 +AD10 / 总数 304 / headline）；selfhost_format_guard 扩 .ktf 五件（宽/非 ASCII/em-dash 三不变量——dash 检查精化为注释段：目标面中缀算术 `n - 1` 豁免）；lexer.ktf 超宽行折叠（102→折叠）+ `→` 箭头 ASCII 化。
- **六命令**：fmt 零 diff（当轮清偿三处）+ clippy -D warnings 零告警 + test 1485:0:0（+22：单测 9 + 种子 3 + 语料门 10；2 ignored 披露维持）；release profile 与 cold-run 见 worklog 78-kerf 条目。

---

#### #9.97 r101——Stage 2.7 步④：目标语法自身编译（Task 79 系列 · v0.66.0 · §9.97）

> 裁定单源 = switch-window-plan §5.5（v1.3）；知识层 = stage0.md §9.97。本节为实施细节记录。

- **79-a 生产桥（driver 三模块）**：①`pipeline.rs`——`ReaderFace` 枚举 + `parse_with` 共享骨架（intern→read→expand→load 一条脊柱，read 步分叉）+ `parse`/`parse_target` 双入口；`drive_dual_engines` 前端参数化（reader_parity.rs 签名 +1 参数，compiler_parity ×2/expander_parity ×2/reader_parity ×1 五调用点各加 `ReaderFace::Sexpr`——单源 harness 骨架非复制）。②`target_corpus.rs`——`read_target_source_for_bootstrap`（bootstrap 前端目标面：parse_target → items，Err 带分类字符串）+ `ktf_compile_rich_vm`（VM-only 括号：target_items_stream_prefix + .ktf 编译器源 → parse_target → typecheck → compile → VM → decode_verdict_vm → rebuild_bytecode）+ `ktf_compile_rich`（双引擎孪生——drive_dual_engines(ReaderFace::Target)）+ `vm_harness_failure_target`（r74 K165 分类纪律目标面：BudgetExceeded/EvalDepthExceeded = harness limit，其余 = defect）。③compiler_parity 辅助 pub(crate) 化（dump_krf_section/rebuild_compile_error/decode_verdict_vm——单源复用非复制）。
- **79-b fixpoint 目标面**：`fixpoint.rs`——`SemanticDigest`（span 盲语义投影：funcs(name,params,n_locals,captures,code)/consts/globals——debug_info 排除 = §9.25.4 跨皮肤口径）+ `semantic_projection()` 单源 + `structural_target_source()`（hosting tail `\ndefine(result, cp_run(items));` 剥离）+ `compile_self_structural_target()`（C_t(S′) 双引擎）+ `fixpoint_selfhost_compiler_target()`（三相位：C_t(S′) oracle 字节全等 + C_t(C_t(S′)) VM-only oracle 字节全等 + 执行产品重建 == b_self_t 字节全等）+ `gate_b_transitivity_target()`（两面自编译 digest 全等——drift 定位 proto/consts/globals）。
- **P0 深度守卫泄漏修复（步④ 实施中揭露）**：`target.rs parse_datum` OpenParen 成功路径无 `leave(guard)`——每个成功括号 datum 泄漏 1 层，顺序括号累积（257 = 256+1 首爆于 compiler 结构源 item 流 ~153KB emission/200+ 记录）；S-expr 面深度实测仅 5（扁平记录流）证明零真实嵌套。修复 = 成功路径 `self.leave(guard)` 补齐（错误路径两处已有）；§20.3 同类路径全量审查：12 处 enter 站点逐一核对，11 处对称唯此一处泄漏；回归钉扎 = reader 单测 `sequential_datum_brackets_do_not_accumulate_depth`（NESTING_LIMIT+40 顺序括号 + 真嵌套仍拒双臂）。**r98-r100 未触发根因**：三路门 probe 记录括号数 <256——「验证面拓宽（生产桥新消费者）揭露潜伏缺陷」的自举价值实证。
- **79-c 测试网**（tests/v1/stage1/plan/target_fixpoint_tests.rs，10 测试）：正向 4（目标面 fixpoint 主断言 + 规模披露[protos 同族/consts 严格增长] / 传递性 / 前端就绪性[五件裸过 Reader + structural 全桥 + 计数一致] / probe 双引擎 + oracle digest）+ 跨阶段消费 1（reader twin 注入程序经桥 → .ktf 编译器编译 → VM 执行 → result 记录与 seed 面三 probe 逐值一致）+ 负向 5（桥拒 seed 皮肤两形 / 桥拒步② 注册面四形 / LA-7 两面拒绝文本一致且零重建 / digest 六字段扰动可见[params/captures/code/consts/globals+name] / debug_info 排除双口径[清空不动 digest 但字节级仍见]）+ 编译期类型守卫 4 函数。
- **79-d audit 与 B 轴**：audit AE 节 10 case（304→**314/314**——第五双字母节：桥前端计数一致 / 桥 fail-closed / 深度回归双臂 / 目标 fixpoint / 传递性 / digest 忠实六字段 / debug_info 排除 / probe gate B / LA-7 错误面 / 桥面 record 消费）+ V8 节表无需扩（单字符节列表）；B10 目标面不动点成本轴落地（stage0_baseline.rs——B10_ITERS=5 + fail-closed 每跑断言 fixpoint_holds + **vs B8 seed 面 1.04x**——<2x 判据远优）+ perf guard 扩 B10 双断言；**B 轴复跑义务闭合**：B7 22.082ms（基线 21.937ms +0.66% 带内）/ B8 3619.070ms（基线 3614.497ms +0.13% 带内）——生产链零变更实证。
- **六命令**：test --release **1496:0:0**（+11：target_fixpoint 10 + reader 回归 1；2 ignored 披露维持）；fmt/clippy/build/check 详见 worklog 79-gate 条目；非英文编码面零新增（新增注释/消息全英文）。
- **文档族**：switch-window-plan v1.3（§5.5 裁定表 + 步④ 交付态 + 步② 行状态勘正——r100 遗留漂移顺手清偿）+ stage-2-plan 行 2.7 状态 + stage0.md §9.97 + roadmap v2.37 + RELEASE_NOTES v0.66.0 + Cargo 0.66.0 + ds08 金链 + calibration T2.7-4 + round-records 本节 + worklog 双镜像。

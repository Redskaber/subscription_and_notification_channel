# Stage 2b 切换窗计划（switch-window-plan.md）——语法替换窗：开窗评估 + 五步流程 + E5 三批次

> **Status**: Active（r98 开窗轮落档——2026-10-03，Task 76-b；**窗口已开**——#15 门控信号核对全过 + 用户行权闭合 + B2 三方案裁定为方案①；**步① 种子段已交付**（r98 · v0.63.0——kerf-reader target 模块 + 皮肤字典映射 + §9.25.4 parity 契约 + audit AB 284/284）；**步② 词法/语法批已交付**（r99 · v0.64.0——六项裁定 + match 脱糖 + 模式族八形 + audit AC 294/294）；**步③ C 类语料 5/5 已交付**（r100 · v0.65.0——五件 .ktf 孪生 + 三路门 + E5 批次 2 + quote 数据载体 + audit AD 304/304——§5.2 裁定族 E2/F/G/H/I 单源）；**步④ 目标语法自身编译已交付**（r101 · v0.66.0——生产桥 read_target_source_for_bootstrap + 目标面 fixpoint C_t(C_t(S'))==C_t(S') + gate B 传递性 + P0 深度泄漏修复 + audit AE 314/314 + B10 成本轴 1.04x——§5.5 单源））
> **流程权威**：docs/sop.md v15.1-distribution（§13.1/§17/§21/§14.6.3）
> **依据**：docs/stage0.md §9.26（EBNF v9 定稿域——解析规范基线）+ §9.26.9（皮肤字典锚）+ §9.25.4（BS-C 验证体系——语义安全网分层）+ §9.30（REC 五步流程 + 脚手架五段映射）+ §9.42.4（B2 三方案）+ develop/v2/stage-2-plan.md §2 行 2.7 + roadmap §5 演进时机治理四红线
> **前置**：Stage 2a CLOSED（2.0-2.6 · r92 · v0.62.0 · 三判据 (1)(2)(3) 终核全过 · 九信号 8✓/1⏳）
> **职责边界**：本文档承载 2.7 窗口的开窗评估记录、五步流程 MUV 排期、皮肤字典实施版与种子域边界登记；EBNF 文法本体单源 = stage0.md §9.26（本文只引用不重复）。

## 0. 开窗评估三件套（r98 裁定记录——门开启的合法性依据）

### 0.1 #15 门控信号核对（时间治理红线 3：零信号不开窗）

| # | 信号 | 状态 | 证据锚 |
|---|------|------|--------|
| 1 | Stage 2a 收口质量信号 | **✓ 满格** | r92（§9.93）：三判据 (1)(2)(3) 三源终核全过{全链 .krf 化 + C(C(S))==C(S) 不动点 B8 带内 + C 转译后端语料 41/41} + 九信号 8✓/1⏳ 维持（⏳ = 第 9 信号阶段间深度验证——2.8 承载，非本窗前置） |
| 2 | 完整语法规范（六步前置清单第 1 步） | **✓ 设计面就位** | §9.26 v9 定稿域（词法层 + Level 0 + 优先级表 §9.26.4 + 关键字分级 §9.26.5 + 二义性 22 例 §9.26.6）；B2 附条件本轮裁定清偿（§0.3）——「开窗前必选其一，禁止沉默维持」义务闭合 |
| 3 | 皮肤字典映射基础 | **✓ 就位** | §9.26.9 映射表（含 r110 三新登记：多绑定 let 逗号形 / quote 调用形 / define 调用形通则）；C-C1 分隔符映射（`::` ↔ `/`）；C12 unit 裁定（`()` ↔ `nil`） |
| 4 | parity 验证底座 | **✓ 就位** | §9.25.4 BS-C：语义安全网分层（同语法 = 字节级；跨语法 = 语义投影 + 行为等价）+ B3 Reader parity 28 函数 + E5 九腿 + TD-032 + HM parity 四段实例——验证基础设施在开窗日即可用（r74 裁定兑现） |
| 5 | 语义翻转/自举链风险信号 | **✓ 零风险信号** | 本窗零 CoreExpr 变更零 VM 变更零 selfhost 面变更（Reader 种子为**并行新增**——S-expr 原件与 Reader 全链维持；§9.30.4 平行件策略） |

**核对结论**：五信号全满格——零信号不开窗红线不成立（有信号开窗）。

### 0.2 用户行权裁定（双前提之后件）

行权句式族命中（沿 stage-2-plan §0 第 3 条判定标准——Stage 0→1「排期已确定则继续推进」同款句式族先例）：

> 「你都检查布署 3-4 个轮次了还没好么？**好了就可以按照规划和计划继续推进项目了**」（r98 用户消息，2026-10-03）

裁定：①「按照规划和计划继续推进」= 推进方向显式化 + 规划单源（stage-2-plan §2）指向的下一入口 = 2.7 开窗评估——句式族命中；②前置有效性条件：本轮环境勘定全绿（两树存活 + 工具链存活 + 双镜像逐位一致 + r97 闭合态零回退）——禁令复活条件不成立。**行权闭合。**

### 0.3 B2 三方案裁定（§9.42.4 P1——开窗前必选其一）

**裁定：方案①**——v9.1 增补 `if_expr/match_expr/perform_expr/handle_expr` 入 expr 层级（primary 位）。依据链：

1. **内核表达力对齐**：If/Perform/Handle 在 CoreExpr 皆为表达式（§9.26.8 内核映射表自证）——皮肤字典完备性主张（§9.26.9）要求目标面可直译一切 S-expr 语料（含 `(+ 1 (perform E))` 形嵌套效应——方案③ 会打破 parity 验证的面）；
2. **三先例全部表达式位**：Koka `with`（E.31-173）/ OCaml 5 `perform e` / Rust `if`/`match`（E.31-174）；
3. **方案②的语义证明义务更重**（宏模板承载求值时序重排）；方案③的双面表达力不对称须升格宪法条款（与原则 31 皮肤/骨架同构主张张力）；
4. **代价可承受**：Reader 复杂度 +（stmt/expr 双位消歧——Rust 同型先例可抄，已实施：语句位分号 vs 尾表达式统一）。

**match_expr 同步登记为步② 义务**（match 无 Stage 0 皮肤对应物——模式匹配语法族随 E5 批次评估；方案①的 match 表达式位裁定先行落位，实施随步②）。

**窗口开启。** 步①-⑤ 排期如下；E5 三批次（渐进式皮肤现代化）随步②③ 并行承载。

## 1. 五步流程 MUV 排期（07 §3.2.1 单源 + 宏观节奏层）

| 步 | 内容 | 状态 | 验收要点 |
|----|------|------|---------|
| **步① 种子段** | 目标语法 Reader 种子（Rust 侧——`kerf-reader/src/target.rs`）+ 皮肤字典实施版 + ReadError 四新变体 | **✓ 已交付（r98 · v0.63.0）** | Level 0 parity 子集全覆盖映射 + §9.25.4 parity 契约（语义投影 + 行为）+ 种子域边界 fail-closed + audit AB 10 case + 单测 22 + 集成 8 |
| **步② 词法/语法批** | 种子域扩展：match_expr + 模式族 / 类型声明四件（struct/enum/type/effect/capability）的 Stx 承载裁定 / where 子句 / 泛型 / cast/range/field/index 的核心映射或 E5 豁免裁定 / use 路径形（C-C1 政策） | **✓ 已交付（r99 · v0.64.0）** | 每批：新产生式映射 + parity 用例 + 负向族 + audit 增量节；E5 批次 1（名称现代化政策——kebab→snake 映射表）随批承载——裁定单源 §5 |
| **步③ C 类语料 5/5** | 五件 selfhost 语料的目标语法翻译（.krf → .ktf 族）：lexer/reader/expander/macro/compiler 逐件（计划行原文的 preamble = 前时间线四件制携带——本谱系语料为五件分解，宿主注入契约由 driver 前缀构造器承载） | **✓ 已交付（r100 · v0.65.0）** | 每件：三路门（语义投影全等 + VM 行为等价 + 展开门 α-等价——§5.2 裁定 H）实测全过；平行件策略（原件保留为 parity oracle 至步⑤——selfhost 五件 .krf 逐位不动）；E5 批次 2（裁定 E2）+ quote 数据载体（裁定 F）+ set/do 调用形载体（裁定 G/I）承载 |
| **步④ 目标语法自身编译** | fixpoint 前置：新 Reader 经目标语法源码自举（生产桥接线） | **✓ 已交付（r101 · v0.66.0）** | §9.30.4 步④ 判据：目标语法 Reader 编译自身[fixpoint_selfhost_compiler_target 三相位——C_t(S′) 双引擎 + C_t(C_t(S′)) VM-only 括号 + 执行产品重建字节全等] + gate B 传递性扩展[gate_b_transitivity_target——两面自编译产物 SemanticDigest 全等]；生产桥 = pipeline.parse_target + read_target_source_for_bootstrap + ktf_compile_rich[_vm]；同轮修复目标 Reader 深度守卫成功路径泄漏（P0——顺序括号累积）+ B10 成本轴 1.04x |
| **步⑤ 验证等价 + E5 收口** | 全语料三路门收口 + gate B fixpoint（二/三阶段双口径）+ S-expr 生产面拆除评估 + E5 批次 3（一次性移除——拆除判据：自建替代 ≥ 被替换物 × 98% 或额外能力 > 0） | ⏳ 待开 | 种子链 S-expr Reader 保留（混合自举宪制——BS-A）；拆除边界 = 生产链 + 语料面 |

**排期纪律**：自举管道铁律全程有效（用户常设指令⑥）——步④ 必须在步①②③ 完整完全交付后才允许进入；禁止降级自举；禁止不完整实现推进。

## 2. 皮肤字典实施版（步① 落地映射——代码单源 = `kerf-reader/src/target.rs` 文档注释）

| 目标面 v9 | S-expr 面 Stx | 核心形式 | 备注 |
|---|---|---|---|
| `fn f(p1: T1, ...) -> T { b }` | `(define (f p1 ...) b')` | Define+Lambda | 类型标注与 `mut` 解析后丢弃（HM 层所有——表面糖） |
| `let x = e;` / `let a = e1, b = e2;` | `(let (x e) b')` / `(let ((a e1) (b e2)) b')` | Let | r110 裁定：多绑定逗号形防嵌套化 parity 破坏 |
| `x = e;` | `(set! x e)` | Assign | 语句位（lookahead 消歧——`==` 独立 token） |
| `{ s1; s2; tail }` | `(do s1' (do s2' tail'))` | Let 链（Begin 脱糖） | do/let 后向折叠——嵌套 do 与平面 do 的 CoreExpr 逐位一致 |
| `if c { t } else { e }` / `if c { t }` | `(if c' t' e')` / `(if c' t' nil)` | If | 缺省 else → nil（unit）；B2 方案① 表达式位 |
| `perform E(args)` | `(perform E args...)` | Perform | B2 表达式位；效应名 = 限定名 |
| `handle e { E(p) => resume(v), }` | `(handle e' (E (fn (p) v')))` | Handle | resume(v) 的返回即续体恢复（皮肤条目）；halt/pass = 步② 登记 |
| `\|\|(p) { b }` / `move \|\| { b }` | `(fn (p) b')` / `(fn () b')` | Lambda | move 前缀丢弃（捕获策略核心不变） |
| `a op b`（14 级优先级全链） | `(op a' b')` | Apply | 运算符本名应用形；`==`→`=`；`!=`→`(not (= ..))`；`&&`→`(if a b false)`；`\|\|`→`(if a true b)`（短路语义保持） |
| `-e` / `!e` | `(- 0 e)` / `(not e)` | Apply | 一元族 |
| `f(a, b)` / `f()` | `(f a' b')` / `(f)` | Apply | 调用形通则——define/quote 调用形零特判自然落位 |
| `m!(args)` | `(m args')` | 宏使用/Apply | `!` 标记丢弃——头部经 expander 作用域键判决（宏或应用） |
| `a::b::c` | 符号 `a/b/c` | 限定名 | C-C1 分隔符映射 |
| `()` | `nil` 符号 | Literal(Nil) | C12 裁定 |
| `module m { items }` | `(module m items'...)` | Module | |
| `use "name";` | `(require "name")` | Require | 过渡期字符串形；路径形 = 步②（C-C1 政策） |
| `true/false` / 整数族 / 浮点 / 字符串 | Bool/Int/Float/String 数据 | Literal | v9 词法层全集（含 0x/0o/0b/`_`/`\u{}`）；ASCII 标识符域（Unicode = Stage 2+ 词法义务） |

**种子域边界（fail-closed 注册——`UnsupportedTargetForm` 变体）**：类型声明四件（struct/enum/type/effect/capability）/ match 与模式族 / 泛型（`<T>` 与泛型实参）/ where 子句 / cast（`as`）/ range（`..`）/ 字段与方法访问（`.`）/ 索引（`[]`）/ halt 与 pass handler 体 / use 路径形——**全部为步② 注册义务，永不静默接受**。

## 3. 验证契约（§9.25.4 BS-C 实施口径）

- **同语法链**（S-expr ↔ S-expr；.ktf ↔ .ktf）：字节级全等（gate B 口径——含 debug_info）；
- **跨语法链**（S-expr ↔ 目标面）：**语义投影全等**（per-proto name/params/n_locals/captures/指令流 + 常量池 + 全局表——debug_info 跨皮肤必然不同源文本故排除）+ **行为等价**（VM 运行值一致）；
- 门审承载：audit AB 节 10 case（r98 起——274→284）；步③ 每件语料三路门 10-13 case；
- 嵌套帽：目标分隔符（`{`/`(`/`[`）共用 NESTING_LIMIT=256（REC-A 同形树纪律——覆盖下游 expander/compile/eval 同形递归）。

## 4. 风险登记（沿 §9.25.5 四陷阱对账——全部有既有纪律对应物）

| 风险 | 缓解 | 锚 |
|------|------|----|
| 语义漂移（Block 插入改 CoreExpr） | do/let 折叠的 CoreExpr 一致性已由 parity 断言机检（AB1-AB3） | 陷阱 1 三重防护 |
| 错误信息质量下降 | 四新变体走 ReadError 单错误面 + R8 消息惯例（audit AB10 钉扎） | 陷阱 2 |
| 性能回退 | 种子为并行新增非替换——生产链零变更；步④ 前置 B 轴复跑义务 | 陷阱 3（<2x 判据候补） |
| 工具链断裂 | 步②③ 语料翻译期 .krf/.ktf 双轨；E5 收口前 S-expr 工具面维持 | 陷阱 4 |

## 5. 步② 词法/语法批裁定记录（r99 · Task 77-a——六项裁定 + 模式族域 + 脱糖策略）

> **裁定原则**：每项走「核心映射」或「E5 豁免（fail-closed 维持 + 登记态）」二选一，禁止沉默维持。判据 = ①内核/类型系统/VM 三域承载是否就位（§9.26.8 内核映射表——零新原语）；②语料消费信号（五件 selfhost 语料 + 步③ 翻译面）；③反过度特化（用户常设指令⑧——活跃期求通解，零消费面不提前实现化）。

### 5.1 裁定表

| # | 项 | 裁定 | 依据链 |
|---|---|---|---|
| A | **match_expr + 模式族** | **核心映射**——expander `match` 特殊形式（脱糖 If/Let 链）+ target.rs `match` 解析 | §9.26.8「match = 分类讨论糖（宏层）」既有裁定 + B2 方案①（r98）表达式位 + VM 测试原语齐备（`=` 数值 / `eq?` 全 kind 值等 / `nil?` 谓词 / `pair?` 形状） |
| A′ | **match 穷尽性** | **尾臂必须 irrefutable**（绑定/`_` 模式）——`ExpandError::NonExhaustiveMatch` 新变体 | §2.3 报错>静默（零运行时 match-failure 通道——不发明 Panic 效应 = 8 原语纪律）；Rust 穷尽性精神的动态面近似 |
| B | **类型声明四件**（struct/enum/type/effect/capability） | **E5 豁免**——fail-closed 维持 + Stx 承载登记态（未来 `(struct ...)`/`(enum ...)` 数据声明供类型窗消费） | HM `Type` 枚举无 datatype 变体（Int/Float/Bool/Str/Nil/Pair/Arrow/Dyn/Var）+ `Value` 域无构造器 + 「there is no type syntax」（types.rs）——三域零承载；零语料消费 |
| C1 | **fn 头泛型 `<T>`** | **E5 豁免**——fail-closed 维持；登记「type_param 撇号形（`'a`）的词法 token 未定义」缺口（词法层 22 词面 + 无 Lifetime/TypeVar token；`'a` vs `'a'` char 歧义消解 = 深水区） | v9 `type_param ::= "'" identifier` **只有撇号形**（裸 ident 形不在定稿域——解析它 = 发明语法）；HM 显式类型变量零消费（推断自动引入）；词面变更须过 E0020——类型窗一并裁定；**类型位置的泛型实参** `Foo<i64>`（adt_type 合法产生式）随类型标注整体丢弃 ✓ |
| C2 | **where 子句** | **E5 豁免**——fail-closed 维持；登记「where_clause 产生式（v9.8 B3 挂接四处）与 22 定稿词面未对齐」事实 | §9.26.5 分级表 15+4+3 词面无 where；约束三形态（trait 上界/效应行/能力）零语义消费方（HM 无 trait + EffectRow 登记态 + E0006 机制面）；词面变更须过 E0020 经济判据——类型窗一并裁定 |
| C3 | **cast `as`** | **E5 豁免** | `Builtin::ALL` 18 项无类型转换原语；HM 推断无 cast 语义 |
| C4 | **range `..`** | **E5 豁免** | §9.26.10 P3 既有登记（range_expr 单开区间——for! 宏域内按需） |
| C5 | **field `.` / index `[]` / struct_lit** | **E5 豁免** | `Value` 域无 record/array（Pair 二元 + LiteralValue 同构）；pair 面 car/cdr 是函数调用形非字段语法——不映射 |
| D | **use 路径形** | **核心映射（收窄单路径形）**——`use a::b::c;` → `(require "a/b/c")`；use_tree `{...}` 组合形 / `as` 别名 / `pub` 前缀 fail-closed | C-C1 分隔符映射（`::` → `/`）+ require 字符串形既有（模块系统运行时承载）；名字空间/重绑定无承载——模块系统窗义务 |
| E | **E5 批次 1（kebab→snake）** | **核心映射（显式两项表）**——`read-line`↔`read_line`、`write-line`↔`write_line`；target.rs 读入时符号替换（bind/引用一致变换——遮蔽语义不变）；`?` 后缀名族（`pair?`/`nil?`/`eq?`）= 批次 2（Lisp 名退役）域 | v9 词法层 ASCII 标识符域无 `-`（§9.26.2）；显式表非通则转换（含 `_` 的合法 S-expr 名反向不对称风险）；批次边界纪律 |

### 5.2 match 模式族域（步② 实施面 + 登记面）

| 模式 | v9 产生式 | S-expr 承载 | 脱糖（手写等价程序——同一性原则） | 状态 |
|---|---|---|---|---|
| Int/Float 字面量 | `literal_pattern` | `1` / `2.5` atom | `(= scrut lit)`——NumEq 同 kind 值比较（跨 kind = 运行时类型错 = 与手写 `(= s 1)` 报错面一致） | **实施** |
| Bool 字面量 | `literal_pattern` | `true`/`false` | `(eq? scrut lit)`——全 kind 值等（跨 kind false → fallthrough ✓） | **实施** |
| Str 字面量 | `literal_pattern` | `"s"` | `(eq? scrut lit)`——`Rc<str>` 内容比较 | **实施** |
| `()` / `nil` | `unit_literal`（C12） | `nil` 符号 | `(nil? scrut)` | **实施** |
| 通配符 | `wildcard_pattern` | `_` | 恒真 + 零绑定 | **实施** |
| 绑定 | `identifier_pattern`（含 `mut` 丢弃） | 裸符号 | 恒真 + `(let (x scrut) ...)` | **实施** |
| 二元 tuple | `tuple_pattern` `"(p1, p2)"` | `(p1 p2)` 列表 | `(pair? scrut)` + p1 递归于 `(car scrut)` + p2 递归于 `(cdr scrut)`——与 `Type::Pair(Box, Box)` 二元同构 | **实施** |
| 单元括号组 | `tuple_pattern` `"(p)"` | `(p)` 列表 | 透传 p（Rust 同型——`(x)` 即 x） | **实施** |
| 守卫 `if` | `match_arm [ "if" expr ]` | —— | **登记 fail-closed**：守卫失败 fallthrough 需复制 NEXT 链两次（指数膨胀）或 thunk 化（引入闭包改投影）——优化窗问题 | 登记 |
| or 模式 `\|` | `or_pattern` | —— | **登记**：body 复制 + 子模式绑定集不相交语义 | 登记 |
| variant/struct 模式 | `variant_pattern`/`struct_pattern` | —— | **登记**（随裁定 B——datatype 窗） | 登记 |
| 绑定 `@` | `binding_pattern` | —— | **登记**（零内核障碍但零语料消费——反过度特化） | 登记 |
| 三元+ tuple | `tuple_pattern` 3+ 元 | —— | **登记**：`Type::Pair` 二元域无多元承载（链式/列表编码未裁定） | 登记 |

**同一性原则**（脱糖 = 手写等价程序的机械变换）：目标面 `match e { p => b, ... }` 的脱糖产物必须与手写 S-expr `(let (s e) (if <test1> b1' (if ... )))` 语义投影全等（fresh 名与 span 除外）——这是 §9.25.4 parity 契约在脱糖面的自然延伸，也是 parity 用例的构造方式。

**S-expr 承载形**：`(match scrut (pat body) (pat body) ...)`——arm = 二元列表；S-expr Reader 零变更（通用 datum 读入），expander 新增分发臂 + `RESERVED_MACRO_NAMES` 增 `"match"`（核心形式先于宏的平铺分发序——防死绑定）。

**scrutinee 单次求值**：`let scrut$ = e in <arm 链>`（fresh 名）。

### 5.3 验证契约增量（步② 面）

- parity 用例：每新映射 ≥3 正向（语义投影全等：目标面 match/泛型丢弃/use 路径 ↔ S-expr 手写等价）+ ≥3 负向（fail-closed 家族逐变体）+ 跨阶段消费 ≥1（match 程序 VM 运行值一致）；
- 同一性断言：脱糖产物 Display 形与手写等价程序的字面等值抽查（fresh 名规范化后）；
- audit AB 增量节（284 → 预计 +10）；
- E5 批次 1 映射的遮蔽语义回归（局部 `read_line` 变量 + 全局调用共存程序）。

## 5.4 步③ 裁定记录（r100 · Task 78-a——E5 批次 2 + 载体族 + α-等价门）

> **裁定原则沿 §5**（内核承载 / 语料信号 / 反过度特化三锚）。步③ 的实施载荷：`kerf-reader/src/target.rs` 的 E5 批 2 皮肤与 quote 数据载体 + `kerf-driver/src/target_corpus.rs` 的目标面前缀构造器 + 五件 `.ktf` 孪生 + 三路门测试（tests/v1/stage1/plan/target_corpus_parity_tests.rs）。

### 5.4.1 裁定表

| # | 项 | 裁定 | 依据链 |
|---|---|---|---|
| E2 | **E5 批次 2——Lisp 名退役** | **核心映射（表 + 两通则）**：内建表 `first`→`car` / `rest`→`cdr` / `pair`→`cons` / `eq`→`eq?`（Clojure/Racket first-rest 先例 + Rust eq 惯例）；通则 P（谓词）：`is_` 前缀段（前导或末位 `_is_`）拼写 `?` 后缀末段——`is_nil`→`nil?`、`lx_is_digit`→`lx-digit?`；通则 K（分隔符）：**字母数字之间的内部** `_` 恒为 `-`——`rd_loop`→`rd-loop`；空白标记族（`_`/`_x`/`x_`/`__`）逐字透传（`_` 通配符不被破坏） | §9.6 表面现代化三批次（批次 2 域）+ v9 ASCII 标识符域无 `-`/`?`（§9.26.2）+ 单向映射（定义点与引用点共变换——遮蔽语义不变）+ S-expr 内部 `_` 名 = 目标词汇表外（r98 登记约束确认——目标面 `make_adder` 即 S-expr `make-adder`，r98 边界例 make_adder 本轮超期更新为 kebab 对） |
| F | **quote 数据载体** | **核心映射**：`quote(<datum>)` 单参数数据模式——元组皮肤从模式位延伸到引用数据：`(d1, d2, ...)` n≥2 = 列表数据（与 S-expr `(quote (d1 d2 ...))` 同树）；`(d)` 分组透传（tuple_pattern 先例）；`(d,)` 尾逗号 = 单元素列表（Rust 元组惯例——消歧）；`()` fail-closed（S-expr 面 `(quote ())` 即拒绝——子集规格 §2.5，空列表数据面 = `nil`）；词面关键字可作符号数据；负数字面量合法；其余（运算符/块/调用）fail-closed「quote carries data, not expressions」 | 语料信号：五件语料的记录表（`(quote (57 50 ...))`/`(quote ("+" ...))`）+ 宿主注入前缀；§9.25.4 同树要求（语义投影含常量池——cons 链改写会破坏门） |
| G | **set 调用形载体** | **核心映射**：内建表增 `set`→`set!`——表达式位赋值的载体（`if c { set(r, x) } else { nil }` ≡ `(if c (set! r x) nil)`）；语句位 `x = e;` 为语法糖（两者产同树） | 内核 `Assign` 是表达式（CoreExpr::Assign）；语料大量表达式位 set!（expander `(if (nil? ex-err) (set! ex-err ...) nil)` 族）；define/quote 调用形同机制先例 |
| H | **局部名皮肤碰撞 + α-等价门** | 语料局部名 `rest`（lexer 14 函数参数 + macro 2 绑定）与皮肤保留名冲突：目标面拼写 `rest` 读回 `cdr` 且**遮蔽内建**（语义断裂非仅名漂移）——孪生件统一改拼 `remaining`（裁定登记改写）；展开门（三路门之三）升格为 **α-等价**（span 盲 + 局部名捕获避免双射——全局面/效应面保持字面相等；双射内单射强制） | 皮肤单向性（`rest` 无目标拼写）+ 局部变量是槽（门 1/2 不受局部名影响）+ 既有「fresh 名与 span 除外」原则（§5.2 同一性契约）的自然延伸 |
| I | **do 调用形载体** | **核心映射（编译器孪生件实践导出）**：多语句序列（≥3 体形）的目标面用 `do(s1, s2, tail)` 调用形——产平面 `(do s1 s2 tail)` 树（expand_do 单 Let 多绑定）；块折叠 `{s1; s2; tail}` 产链式单绑定 Let（CoreExpr 树级差异——r98「嵌套 do ≡ 平面 do」在字节码面成立、树面不成立，本轮实测修正登记）；双体形 do 块折叠即精确；孪生件亦用 `let _ = e1, _ = e2;` 直拼 do 脱糖形（等价路径） | expand_do 实测（单 Let 多绑定 vs 块折叠链式 Let）+ do 非关键字（v9 22 词面无 do）——调用形映射零特判自然落位（define/quote/set 同机制）；quote 载体同理延伸：`quote(-1)` 表达式位负整字面量（expander 将 Quote(Int) 折为 Literal——树级精确） |

### 5.4.2 前缀构造器与命名守卫（driver 侧）

- `kerf-driver/src/target_corpus.rs`：四前缀目标面孪生（`target_byte_table_prefix`/`target_token_table_prefix`/`target_forms_stream_prefix`/`target_items_stream_prefix`）+ 五源常量 + `assembled_expander_target_source()`；**数据单源** = S-expr 前缀构造器逐字转码（皮肤单源 = 转码器）；**命名守卫** = 转码后经真实目标 Reader 回读校验 Stx Display 全等（不可拼名 = harness 缺陷 panic 非静默改名）。
- 步④ 义务登记：`.ktf` 产品的组成链消费（生产桥）+ gate B 传递性扩展。

## 5.5 步④ 裁定记录（r101 · Task 79——生产桥 + 目标面 fixpoint + 传递性 + 深度泄漏修复）

> **裁定原则沿 §5**（内核承载 / 语料信号 / 反过度特化三锚）。步④ 的实施载荷：`kerf-driver` 的 pipeline/target_corpus/fixpoint 三模块扩展 + `kerf-reader/target.rs` 深度守卫修复 + 根树 `tests/v1/stage1/plan/target_fixpoint_tests.rs` + audit AE 节 + B10 成本轴。自举管道铁律前置满足（步①②③ 完整交付——r98/r99/r100 全链闭合）。

### 5.5.1 裁定表

| # | 项 | 裁定 | 依据链 |
|---|---|---|---|
| PB-1 | **生产桥形态** | **`pipeline::parse_target`（共享骨架 `parse_with` + `ReaderFace` 枚举）**：S-expr/目标两皮肤共享 intern→read→expand→load 一条脊柱，仅 read 步分叉（两 Reader 产出同族 Stx 树——§9.25.4 parity 契约使共享脊柱可靠）；`drive_dual_engines` 前端参数化（五调用点单参数增补——单源 harness 骨架非复制） | 反过度特化（通解面：E5 收口时 Sexpr 臂单点拆除）；语料 API 名对齐 `read_target_source_for_bootstrap`（§9.30.1 漂移检测 7 三路形态的第三路兑现） |
| PB-2 | **目标面组装驱动** | **`ktf_compile_rich[_vm]`**（krf 双引擎/VM-only 驱动的目标面孪生）：target_items_stream_prefix + `.ktf` 编译器源 → `ReaderFace::Target` 解析 → Rust oracle 编译 → VM/eval 执行 → 产品重建；VM-only 括号披露沿袭（r74/r85 包络谱系——自施加 datum 过 eval 包络） | fixpoint.rs 既有形态逐位同构（三相位操作形状携带）；decode 辅助 pub(crate) 单源复用（dump_krf_section/rebuild_compile_error/decode_verdict_vm） |
| PB-3 | **目标面 fixpoint 口径** | **同语法链字节级**：C_t(S′) 双引擎（S′ = structural twin——hosting tail `define(result, cp_run(items));` 剥离，cp_run 参数自含）+ C_t(C_t(S′)) VM-only + 执行产品重建 == b_self_t（逐字节）；gate B elevated 双点（oracle == 重建，两相位各一） | §9.25.4 分层：同语法链（.ktf ↔ .ktf）字节级全等——span 同源文本合法；跨语法链见 PB-4 |
| PB-4 | **gate B 传递性** | **`SemanticDigest` 单源（driver fixpoint.rs）+ `gate_b_transitivity_target`**：digest = per-proto name/params/n_locals/captures/code + consts + globals（debug_info 排除——跨皮肤必然不同源 span）；传递链 = gate B（.krf 面，r88）+ 三路门（语料级，r100）+ gate B（.ktf 面，本轮）⟹ 两面自编译产物 digest 全等；ruling-H 局部名改写（rest→remaining）被槽位吸收（局部变量不进字节码） | §9.25.4 跨语法链语义投影；digest 忠实见证（AE6 六字段扰动可见）+ debug_info 排除见证（AE7 双口径分离钉扎）——「投影不能失败就不是门」 |
| PB-5 | **深度守卫泄漏修复（P0）** | **成功路径 leave 补齐**：`parse_datum` OpenParen 分支此前仅在两错误路径释放 DepthGuard——每个成功括号 datum 泄漏 1 层，顺序括号累积计数（非嵌套）；步④ 前所有测试未触发（记录括号数 <256），compiler 结构源 item 流（200+ 记录）首爆 | §20 同类路径全量审查：12 处 enter 站点逐一核对——11 处对称，唯一泄漏点修复（对齐 parse_pattern 闭包模式语义）；回归钉扎三面（reader 单测 + audit AE3 + 测试网）——「生产桥作为新消费者揭露潜伏缺陷」的自举验证价值实证 |

### 5.5.2 验证契约（步④ 面）

- 目标面 fixpoint：`fixpoint_selfhost_compiler_target` 三相位全断言（双引擎一致 + oracle 字节全等 ×2 + 不动点字节全等）+ 规模披露（protos 同族 / 自施加 consts 严格增长）；
- 传递性：`gate_b_transitivity_target`（drift 定位——proto/consts/globals 首漂点命名，非裸 digest 差）；
- 前端就绪性：五件 `.ktf` 孪生裸过目标 Reader + structural twin 全桥行走 + 与 seed 面 item 计数一致；
- 错误面 parity：LA-7 探针两面拒绝文本一致 + 零重建产品（fail-closed 报告非静默）；
- 桥 fail-closed：seed 皮肤源 + 步② 注册面（struct/泛型/where/cast）拒绝；
- B 轴：B7/B8 复跑带内（+0.66%/+0.13%——生产链零变更实证）+ B10 目标面成本轴 **1.04x**（<2x 判据远优）落地 fail-closed 钉扎。

## 6. 变更日志

| 版本 | 日期 | 内容 | 作者 |
|------|------|------|------|
| v1.0 | 2026-10-03 | r98 开窗轮落档：开窗评估三件套（#15 五信号核对全过 + 用户行权闭合 + B2 裁定方案①）+ 五步流程 MUV 排期（步① 已交付）+ 皮肤字典实施版 + 验证契约 + 风险登记 | Z.ai Code (Task 76-b) |
| v1.1 | 2026-10-04 | r99 步② 裁定轮落档：§6 六项裁定表（match/类型四件/泛型/where/cast/range/field/use/E5 批1——核心映射 5 项 + E5 豁免 5 项）+ 模式族域（实施 8 形 + 登记 6 形）+ 同一性原则 + 穷尽性裁定 A′ + 验证契约增量 | Z.ai Code (Task 77-a) |
| v1.2 | 2026-10-04 | r100 步③ 裁定轮落档：§5.4 步③ 裁定表（E5 批 2 名退役 E2 + quote 数据载体 F + set 调用形 G + 局部名碰撞与 α-等价门 H + do 调用形 I）+ 前缀构造器与命名守卫登记 + 步③ 行交付态（5/5）+ 计划行 preamble 口径勘正（前时间线四件制携带 vs 本谱系五件分解） | Z.ai Code (Task 78-a) |
| v1.3 | 2026-10-05 | r101 步④ 裁定轮落档：§5.5 步④ 裁定表（生产桥形态 PB-1 + 目标面组装驱动 PB-2 + 目标面 fixpoint 口径 PB-3 + gate B 传递性 PB-4 + 深度守卫泄漏修复 PB-5）+ 验证契约（步④ 面）+ 步② 行状态勘正（r99 交付态——r100 轮遗留漂移顺手清偿）+ 步④ 行交付态 | Z.ai Code (Task 79) |

# 阶段间轮次记录移档（interlude-rounds.md）——§9.51-§9.79 实施细节

> 依据：docs/stage0.md 分层整理（2026-10-02 用户指令）——本档案承接阶段间轮（§9.51-§9.63 Stage 2 预备与阶段间审查 + §9.64-§9.79 域审查族，v0.23-v0.48）的实施设计/管道对账/实施清偿/阶段间推进/收敛口径**逐字移档**。检索锚表/演进窗登记/线程关系/裁定族留驻 stage0.md；锚互指同前。门历史单源 = docs/develop/v2/stage-2-plan.md §0。

---

## 9.51 Stage 2 预备域前沿对照与词法寻址/捕获激活预设计（v9.17——第五十轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.51 勘察基线与节引言


> **本节性质**：Stage 1 收口后的**阶段间审查轮**（B 型前沿审查——用户阻断性指令每轮先行义务的第五十轮执行）。审查对象 = **Stage 2 首刀预备域**（词法寻址 + 闭包捕获激活——deep-review-round1.9 D4 ⚠️ 项与 hidden-problems 登记窗的直接前置设计审查；用户「不能只关注当前阶段」指令面）× **Stage 0-1 既有绑定/环境结构的适配性审查**（17 行适配面全量普查——用户「stage0-1 都可变」裁定面的代码实证基线）。**本轮零 Stage 2 实施**（用户禁入指令 + §14.6.3 规则 5 用户确认门未触发；本节 = 登记态设计，供给 Stage 2 §21 规划轮消费）。勘察基线 v0.22.0（六命令冷跑 1145:0:0 + audit 200/200 复验态；环境 OBS 一项登记见 §9.51.8）。


### 9.51.2 Stage 0-1 绑定/环境结构逐域审查表（17 行适配面——勘察 v0.22.0 实态）

> 勘察方法：Explore 子代理只读全量勘察（vm/frame/value/eval/expr/symbol/compile/ctx/infer/check/opcode/verify/roots/gc + 测试与基线锚点）——「stage0-1 都可变」用户裁定面的首次系统性普查。**核心结论先行：VM 运行期已半迁移**（槽位索引化到处处皆是），关联式残留集中在**编译器名字解析 / 求值器名字扫描 / 展开器与检查器名字扫描**四处 + **休眠捕获载体**一处。

| # | 结构 | 锚点 | 现行表示 | 词法寻址迁移点 |
|---|------|------|---------|---------------|
| 1 | `Frame.locals` | kerf-vm/src/frame.rs:62-77 | `Vec<Value>`（参数 0..params + let 槽单调递增；3-ext 冻结块） | 已索引化——捕获区以独立 Vec 扩展（冻结 ext 槽不动） |
| 2 | `Vm.globals` | vm.rs:43-62 | `Vec<Option<Value>>` 按 `bc.globals` 索引 | 收缩为真模块全局（自由词法回退面消失） |
| 3 | `ClosureData` | kerf-vm/src/value.rs:29-35 | `{ proto: u32, env: Vec<Value> }`——env **休眠**（全帧快照，永不被读） | 激活：编译器计算捕获列表 + 新操作码装载；GC 追踪（gc.rs:89-97）现成 |
| 4 | `Opcode::Closure` 执行 | vm.rs:242-251 | **每闭包创建克隆全帧 locals** | 按 LA-2 描述符选择性拷贝（O(captured) 非 O(locals)） |
| 5 | `Vm::invoke` | vm.rs:519-566 | 只读 `data.proto`；args→参数槽 | 安装捕获区进被调帧 |
| 6 | `LoadLocal/StoreLocal` | opcode.rs + vm.rs:295-304 | `a` = 帧内槽位（深度恒 0——begin_closure 空域所致） | 操作数分裂 (context/depth, slot) 或新 `LoadCaptured/StoreCaptured` 族 |
| 7 | 求值器 `Env` | kerf-runtime/src/eval.rs:74-105 | `names: Vec<(String,usize)>` + `locals`——**尾先线性名字扫描** | 镜像编译器（"MIRRORS, never invents" 契约）；resolve 换 (depth,slot)；invoke 环境交换 → 捕获区链接；make_closure 选择性捕获 |
| 8 | `CoreExpr::Var`/绑定子 | kerf-core/src/expr.rs:125-175 | 命名 `Symbol` 引用（冻结 ADT 9 变体） | 首刀保持命名（K47 裁定）；§7.4.3 ANF/de Bruijn 重构 = 独立登记窗 |
| 9 | `Symbol`/`StxSymbol` 双子 | kerf-core/src/symbol.rs:20-23 + kerf-syntax/src/symbol.rs:26-29 | 未驻留 String newtype 对（跨界面按文本） | 驻留 = 独立登记窗维持（§9.44.5 第 1 行 + §9.49 复查——零信号不开窗） |
| 10 | `ProtoState.locals`/`alloc_local`/`lookup_local` | compile.rs:60-75, 239-266 | `Vec<(Symbol,u32)>` 每 proto + **倒序线性扫描**（★5 热点）+ mark/truncate；槽位不重用 | 核心变更位：作用域栈穿透 begin_closure + 自由变量 (depth,slot) + 捕获描述符构造 |
| 11 | `begin_closure`/`compile_fn` | compile.rs:270-296, 449-464 | **全新空域**（自由名 → intern_global → LoadGlobal——休眠捕获设计） | 翻转位：闭包体看见外层作用域；随 `Opcode::Closure` 发射捕获描述符 |
| 12 | `ExpandCtx` frames/`resolve` | kerf-expander/src/ctx.rs:60-144 | sets-of-scopes 子集判定；`Resolution` 仅携带类别（Local/Global/Unbound） | 结构不受影响（卫生按 scope-set 键控非槽位键控）；现状：展开器**允许**内层 fn 引用外层绑定而双引擎拒绝——捕获激活后两面一致；若寻址需要绑定同一性，`Resolution` 须扩展携带 |
| 13 | HM `Machine.env`/`LocalEntry` | kerf-typecheck/src/infer.rs:609-624, 987-1054 | `Vec<LocalEntry>` 名字倒序扫描 + mark/truncate（无 levels） | 镜像新作用域语义（Fn 体自由变量可见性翻转 = 良型程序集扩展）；neg-045 期望翻转 |
| 14 | 检查器 `locals: Vec<Symbol>` | check.rs:264-270 | 名字表 + mark/truncate | 同镜像纪律（「解析顺序镜像编译器」契约） |
| 15 | `FuncProto`/`Bytecode`/`verify` | bytecode.rs:52-90 + verify.rs:84-127 | n_locals + code + debug_info；槽位界检查 | 新捕获表字段 + 新操作数界检查；`Opcode::pops/pushes` 单源表扩展（深度传播器消费） |
| 16 | 预算/roots 面 | vm.rs:33, 390-417 + roots.rs:22-37 | 帧与堆单元共享 u32 预算；roots 快照全帧 | 机制不变；捕获区随 `Roots.locals` 行进；闭包单元沿既有 Closure 追踪 |
| 17 | parity 安全网 | kerf-runtime/src/parity.rs + driver parity | 双引擎结构等价 | **迁移的安全网**：eval 与 VM 必须同翻（eval.rs:16-19 文档注释明文「Stage 1 lexical capture activates it [on both engines]」） |

**语义翻转锚族**（现行**钉死无捕获行为**的测试——捕获激活同刀翻转）：`neg-045-closure-no-capture.krf`（期望 `type-error E0001`——将翻为值 8）+ `negative_parity_basic_closure_free_name_is_unbound_on_both`（runtime_seed_tests.rs:328——双引擎 UnboundGlobal 对偶将翻为捕获语义）+ `closure_captures_env_and_calls_through_frames`（vm.rs:670——断言 `data.env == locals` 全帧快照将翻为选择性捕获）+ `let_assign_perform_handle_forms`（compile.rs:745——钉死槽位索引 0/1 的期望须随捕获区布局复定）。


### 9.51.3 新发现登记（★ 体系延续）

- **★1'（新登记——P3 级 + Stage 2 首刀窗内化解）**：**休眠捕获的双成本**——(a) 每闭包创建 O(n_locals) 全帧克隆（vm.rs:242-251 + eval.rs:398-420 双引擎同构）且产物**永不被读**（invoke vm.rs:519-566 仅读 proto；env 零消费者）；(b) GC 保留过度近似（gc.rs:89-97 追踪 `ClosureData.env` → 每闭包钉死定义帧**全部**局部存活——含死绑定）。现况影响有界（语料闭包浅 + 帧小 + 休眠设计有文档）= P3；**捕获激活（LA-2 选择性拷贝）天然化解双成本**——并入 Stage 2 首刀窗非新窗口。登记依据：R1（有设计文档的非桩判定——dormant 设计文档在 value.rs:29-35 + plan-0.6 裁定 15「帧布局零改动激活」；本登记补全其成本面披露）。【**注销 @ Stage 2.2 收口轮（r81 · v0.51.0 · §9.82.4）**：双成本化解实证落地——(a) 成本轴：B6 基准帧宽 4→100 槽逐创建成本 47.8→47.7ns 持平（O(captured) 非 O(n_locals) 实测）+ capture_cost_guard 守卫（五十槽定义帧捕获一值 → env 恰一槽结构证）；(b) 保留轴：守卫（八 pair 局部捕获一值 → 显式 §19.4 周期 swept 恰 7——dormant 快照将全保留 swept 0）。登记义务履行完毕，本条转为历史登记。】
- **★5 维持**：`lookup_local` O(scope-depth) 倒序扫描（architecture-review ★5 / §9.44.3 第 5 行零信号）——LA-1 编译期 (depth,slot) 解析后，扫描仍存在于**编译期一次性面**（K42 同构：编译期成本非运行期成本——SISC「compiler keeping an environment of all bound variables」），运行期零变化维持；触发器不变。
- 其余适配面 15 行：零新 ★（结构审查全过——帧格式冻结前瞻[「帧布局零改动」]/GC 追踪现成/cur_stack LIFO 修复语义可保留/parity 安全网在位——**Stage 0 的休眠设计前瞻性得到本轮全量确认**）。


### 9.51.4 环境表示三方案 × kerf 冻结面适配裁定

| 方案 | 机制 | 前沿锚 | kerf 适配裁定 |
|------|------|--------|--------------|
| **A 扁平捕获（选择性拷贝）** | 编译器计算捕获集 → `Closure` 时拷贝捕获槽进闭包单元 → `invoke` 安装 | K43 精确闭包环境 + K45 精确捕获粒度 + K51 动态成本裁定 | **首刀采纳**：`ClosureData.env` 载体现成（休眠→激活）；Frame 冻结 3-ext 不动（捕获区独立）；GC 追踪面现成；无共享可变需求（子集边界） |
| B 链式环境（父帧链/display） | 帧持父引用 → 深度寻址走链或显示向量 | 传统 Lisp 显示向量族 | 不采纳：破坏 Frame 冻结格式 + 深度走访动态成本（K51 反向证据）+ cur_stack 语义复杂化 |
| C 共享可变上下文（间接单元） | 捕获 = 堆单元指针共享（开合 upvalue / context 对象） | K44 Lua + K53 V8 | 后续窗登记（LA-7）：服务可变捕获语义——subset-spec 语义面规划轮裁定后再评估 |


### 9.51.6 每轮阻断条款九项复查（第五十轮——全绿实录）

1. 管道五段谱系在场：§9.46-§9.50 节头实读 5/5 ✓；2. 行动项三锚：★1 HM 接线 pipeline.rs:219/223 双层 ✓ / MX-1 mangled macro.krf ×8 ✓ / RS 迭代式 reader.krf rd-loop ×7 ✓；3. 登记项维持：Symbol/intern §9.49 触发器复查结论维持（零信号不开窗——本轮 §9.51.2 第 9 行再证）+ ★2-★6 演进窗登记 ✓；4. TD 登记册 v0.22.0 开放项 0（连续十四轮）✓；5. 语料 79（pos 31 + neg 38 + bnd 10 实测）✓；6. selfhost 三件 116/741/558 ✓；7. web 侧条目在场（Task 23-d/26-d/27 + v0.22.0 仪表盘实态）✓；8. 基准核验：三通道第十一次不可达 → 零替换 + 六命令冷跑 1145:0:0 + audit 200/200 ✓；9. **裁定：阻断性条件解除维持（T27 结论复验）——历史审查发现全部实施或登记维持；Stage 2 零实施纪律维持**（用户禁入指令 + §14.6.3 规则 5 确认门）。


### 9.51.7 规划同步缺口裁定（roadmap §6 陈旧——本轮 28-c 清偿）

roadmap.md v1.0 §6「当前断点与推进序列」节陈旧 @ Stage 1.0-1.2 态（git 勘证：最后触碰 f13852c = 1.2 PBT 轮——「当前位置」停在 Stage 1 开工态、「下一轮首议程」停在 1.1 driver 接线；1.3-1.9 与收口态未回写）——**P2 文档同步缺口**（§8.4.5 文档-代码同步义务：roadmap 为全局规划单源[演进时机/阶段节点/任务排期的第一查询位]，阶段切换点必刷新；1.9 末轮收口时刷新义务漏执行）。本轮 28-c 清偿：§6 刷新至 Stage 1 CLOSED v0.22.0 态（当前位置 + Stage 2 入口计划 + 推进序列总览 + 出阶段评审清单节注记）。


### 9.51.8 收敛口径

零机制变更、零新原语、零语法增量、**零 Stage 2 实施**（用户禁入指令 + §14.6.3 规则 5 用户确认门维持）；8 原语不变性**第二十四轮**验证（第二十三轮之后下一未用号——纯文档域零代码变更零原语触碰）；本节为设计依据层，Stage 2 落地以 §21 规划轮 + plan-2.x 为准。**环境 OBS 登记（沿 r115/r117 先例）**：本沙箱 rustc 1.98.1 debug 帧下深递归测试族（mp7 512 层展开递归 + source_bounded_tree 深树拒绝案）需 `ulimit -s 131072` + `RUST_MIN_STACK=268435456`（plan-1.2 注记的 32MB 口径在本环境不足——mp7 实测 256MB 通过；**环境差异非代码缺陷**：同代码同提交在 T26/T27 环境全绿；六命令在本口径下全绿 1145:0:0 + audit 200/200）。



---

## 9.52 Symbol 驻留终局裁定与实施（第五十一轮——用户第四轮点名触发开窗 + 本轮代码实施 v0.23.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

### 9.52.1 触发器开启记录（§9.44.5 第 1 行状态翻转）

- **既有三触发器（LSP 窗 / B 系列热点 / 自举自编译负载）零信号结论维持**——§9.49 的热查找点七行普查不被推翻（VM 运行期全索引化 + 字符串成本集中编译期一次性面的实况判断仍成立）。
- **新触发器开启 = 用户指令本体（第四轮点名）**：用户于第四十二（§9.44）/四十七（§9.49）/五十（§9.51）/五十一轮四次显式点名「Symbol 当下还是 string，intern 驻留机制？」，且第五十一轮升格为「需要在项目中具体实施设计和重构，而非只有 docs/stage0.md 简单更新」+「stage0-1 都可变」+「当前项目禁止冻结」——按原则 44（用户指令 = 需求信号本体；M1 开窗先例 r104 同构），驻留窗由登记态**开启并本轮实施**。
- **蓝图-实现缺口勘证（文档-代码冲突的第四形态——本次以实施闭合而非改档）**：本蓝图 §7.4 伪代码 `Identifier(Symbol) // Symbol 是 interned string`（两处）与 §8 常量池/全局表 `intern(text)`/`intern_global(name)` 蓝图锚均**假设驻留**；实现交付为 String 载荷（kerf-core/symbol.rs:20-23 + kerf-syntax/symbol.rs:26-29 勘证）——缺口以实施方向闭合（蓝图意图 > 实现现状，用户指令定方向）。
- **域定位**：阶段间（interlude）实施——stage 0-1 域内（用户明示可变），零 Stage 2 语义实施（词法寻址/捕获激活零触碰；§14.6.3 规则 5 确认门维持）。


### 9.52.3 技术与缺陷权衡（三方案对照 + 外部依赖裁定 + 缺陷风险评估）

**方案对照**：

| 方案 | 表示 | 优势 | 缺陷 | 裁定 |
|---|---|---|---|---|
| A 全局驻留（采纳） | `OnceLock<Mutex<Interner>>` + `NonZeroU32` 索引 + `Box::leak` 'static 文本 | O(1) eq/hash；Clone = 位拷贝；进程内身份稳定；K6/K54 正典形态 | 进程生命期文本（leak-by-design）；as_str/Display 读路径一次锁（uncontended ~20ns） | **本轮实施** |
| B `Arc<str>` 载荷 | 引用计数共享 | 无全局状态；clone 廉价 | eq/hash 仍 O(len)；无身份去重；无跨拷贝身份语义 | 不采纳（半措施——驻留核心收益是**身份**不是拷贝） |
| C 会话域驻留器 | Session 持有、显式穿参 | 生命期最净（可回收）；无全局态 | API 侵入 = 10 crate 签名链改造；与 `Symbol::new(&str)` 无上下文构造子直接冲突 | 登记备选：LSP 长会话/泄漏敏感信号出现时重评（§21 评估位） |

**外部依赖裁定（§18）**：string-interner / lasso / symbol_table 三 crate 对照后**均不引入**——DAG 零外部依赖是既有承诺（workspace 除 dev-dependencies proptest 外零运行时依赖）；需求面 ~90 行自持；Send/Sync/泄漏语义自主可控（lasso ThreadedRodeo 拉入 dashmap 族，超需求）。

**缺陷引入风险评估（用户指令「引入技术是否也引入缺陷」的正面回答——四风险全知情）**：
1. **leak-by-design**：驻留池进程生命期不回收——编译器进程语义下无害（rustc 同型）；REPL 长会话上界 = 不同标识符总数（有限且小）；K57 池陷阱（任意字符串被驻留）**不适用**——kerf 只驻留下限校验通过的标识符，语言面字符串 `Value::Str` 维持 String 拥有权（**两个世界边界**：标识符身份驻留 / 字符串数据不驻留）。
2. **读路径锁**：as_str/Display 每次取锁——B1-B5 实测全带内（B1 7.7µs 反降 18% = 编译期 clone/hash 红利 > 锁成本；B3 +11% 带内 = 求值器 display 面锁成本如实登记）；未来热点信号 → C 方案或 RwLock 升级窗。
3. **Ord 语义翻转**（字典序 → 驻留首次出现序）：全树涟漪审计零消费者（§9.52.4 八项之②）；trait impl 仅为冻结公开面维持 + 结构体文档显式警示新代码不得依赖字典序。
4. **并发测试线程**：cargo test 多线程共享驻留池——Mutex 串行化 + 同文本恒同索引（跨线程等值成立）；索引序不定但全观测面（Debug/Display/as_str/eq/hash）文本化或索引封闭——确定性不受影响（实测多线程 1162:0:0）。


### 9.52.4 实施记录（v0.23.0——外科手术式双文件载荷置换）

- **Diff 面**：`crates/kerf-core/src/symbol.rs` + `crates/kerf-syntax/src/symbol.rs` 两文件（+ 根集成模块 `tests/v1/stage1/plan/symbol_intern_tests.rs` + runner 挂载）——**公开 API 零变更**（`Symbol::new`/`as_str`/`Display`/全部 trait impl 签名逐项不变；私有载荷 String → NonZeroU32 驻留索引）；冻结层触碰 = 私有表示面（用户「stage0-1 都可变」授权；冻结承诺的公开面维持——层 API/节点形状零扰动）。
- **相位孪生纪律延伸**：双 crate 各持独立全局驻留池（L1/L4 永不共享索引）——§21.12-5 单定义规则边界维持（孪生纪律从校验逻辑延伸到驻留池）。
- **Interner 形态（K54 同构）**：`HashMap<&'static str, NonZeroU32>` + `Vec<&'static str>`——`Box::leak` 一次性泄漏 + 锁内查插 + 锁外 'static 文本返回（as_str 锁作用域 = 索引读，返回指针指向泄漏内存非守卫数据）；poison-resilient（`unwrap_or_else(PoisonError::into_inner)`）；`NonZeroU32` → `Option<Symbol>` niche 4 字节维持（compiler 闭包名/vm 帧名消费点——新增 niche 布局单测锁定）。
- **Debug 手写复刻派生格式**（`Symbol { text: "x" }` 逐字节）——黄金/诊断字节稳定 + 索引无关（驻留序不定下的测试确定性前提）。
- **Copy 刻意不派生（本轮裁定）**：派生 Copy 将使全树既有 `.clone()` 调用点（消费五 crate）触发 clippy::clone_on_copy 机械翻修——diff 面失控 vs 收益（位拷贝语义已由 Clone 派生获得）；LA-2 捕获描述符开 compiler crate 时一并重评。
- **涟漪审计八项（全树 grep 勘证）**：① `BTreeMap<Symbol/StxSymbol>` = 0 处 ✓ ② 全树五处 sort 实读——expander/code.rs:96 `symbols()` 排 `Vec<String>` / typecheck/infer.rs:1893 排 SCC usize 索引 / driver/parity.rs:287-288 排 `Vec<String>` 标签 / compiler/opcode.rs:222 + vm/builtin.rs:300 排 `Vec<&'static str>` 静态名——**零 Symbol 序消费者** ✓ ③ Debug 黄金含 `text: "` 断言 = reader 错误载荷（ReaderError 非 Symbol）1 处不受影响 ✓ ④ serde/bincode 序列化 = 0 ✓ ⑤ `.text` 私有字段直访 = 两文件自身 4 处 ✓ ⑥ `Value` 无 Symbol 变体（Int/Float/Bool/Str/Nil/Pair/Closure/Builtin——运行期值域零触碰）✓ ⑦ `Option<Symbol>` 消费点（compiler bytecode/compile + vm frame/vm.rs）niche 维持 ✓ ⑧ CoreExpr derives = Debug/Clone/PartialEq（无 Ord）✓
- **测试增量**：单测 +10（core 5 + syntax 5——同一文本单身份 / 多驻留不扰 / as_str 往返 / Debug 文本稳定 / niche 布局 / 拒后不污染）+ 根集成 +7（symbol-heavy 双引擎各一 + parity 合意 + let 遮蔽最内绑定 + parity 契约错误期望检测[detector-detects 对偶] + 未绑定名诊断精确文本 ×2[顶层 + fn 体内自由名]）——正 5 / 负 4 / 跨阶段消费 2（双引擎 parity + 契约面）GATE 6 构成达标；**全量 1162:0:0 + audit 200/200 + fmt 零 diff + clippy `-D warnings` 0**（六命令冷跑 + 热复跑双锚）。
- **B 系列复跑（±25% 带内全过）**：B1 **7.7µs**（基线 9.4µs，-18%——驻留红利带内新低）/ B2 87.6ms（97.45ms）/ B3 10.4ms（9.4ms，+11% 带内——求值器 display 面锁成本如实登记）/ B4 0.352ms（0.372ms）/ B5 87.5ms（97.0ms）。
- **语义面零变更**：8 原语不变性**第二十五轮**验证（纯 Rust 侧表示置换——零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF 增量）；selfhost parity 三件字节全等维持（全量回归承载）；子集冻结面（特殊形式 10 / 内建 18 / 字面量 6 / 构造子 9 / 模块项 2）零触碰。


### 9.52.5 与 Stage 2 LA 的接口 + 登记项影响

- **LA-1..LA-7 输入增益**：捕获描述符（LA-2）现可键于 Symbol 身份（u32 等值）而非文本比较——词法寻址的实现基座就位（规划轮直接受益）。
- **★5 注记维持**：`lookup_local` 倒序扫描**算法不变**（`Vec<(Symbol,u32)>` + mark/truncate 结构正确性独立于载荷），仅比较成本从 O(len) 字符串降为 u32——(depth,slot) 解析窗（Stage 2 LA-1）不变。
- **★1'（休眠捕获双成本）维持登记**：驻留不触碰 `ClosureData.env` 克隆路径——其化解窗仍 = LA-2 选择性拷贝（Stage 2 首刀）。
- **语义翻转锚四件零触碰**（neg-045 E0001→值 8 等——驻留不改任何绑定语义；翻转窗仍 = 捕获激活）。


### 9.52.6 每轮阻断条款九项复查（第五十一轮——全绿）

1. 谱系六段在场：§9.46-§9.51 节头实读 6/6 ✓（本轮 §9.52 = 谱系外实施轮——审查主题 = 用户四轮点名项终局裁定）；2. 行动项三锚维持（★1 HM 接线 / MX-1 mangled / RS 迭代式）✓；3. **登记项更新：Symbol/intern §9.44.5 第 1 行状态翻转 = 已实施（本轮 v0.23.0）** + ★2-★6/★1' 演进窗登记维持 ✓；4. TD 登记册开放项 0 维持（驻留权衡 = 设计裁定入 §9.52.3，非债）✓；5. 语料 79 维持 ✓；6. selfhost 三件 116/741/558 维持 ✓；7. web 侧（本轮 Task 29-d 同步）✓；8. 基准核验：三通道第十二次不可达 → 零替换 + 六命令冷跑 1145:0:0（基线）+ 实施后 1162:0:0 + audit 200/200 双锚 ✓；9. **裁定：历史审查发现全部实施或登记维持 + 本轮用户点名项代码实施清偿；Stage 2 零实施纪律维持**（用户禁入指令 + §14.6.3 规则 5 确认门）。




---

## 9.53 内存管理域前沿对照与既有登记窗复核（第五十二轮——管道审查谱系第六段 · 纯文档域）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.53 勘察基线与节引言


> **定位**：管道审查谱系**第六段**——§9.46 Reader / §9.47 Expander / §9.48 宏面 / §9.49 后端四域（compiler·vm·runtime·driver 的分派与管线面）/ §9.50 检查器五段之外的最后一个未深审域：**内存管理**（GC 算法 / 堆结构 / 值表示 / 根扫描 / 分配路径 / 预算族——§9.49 后端段审查的是 vm 分派与预算语义，未触 GC/堆/值表示本体）。本段收口 = 管道审查谱系**全域闭合**（数据结构 × 算法 × 每域前沿对照三轴完备）。勘察基线 v0.23.0（1162:0:0 · audit 200/200 · 六命令冷跑复验；只读勘察——Explore 子代理零修改，尺寸测量经仓库外同构探针）。


### 9.53.1 审查对象与代码事实基线

**域内六面**（勘察锚点全集——kerf-vm/src/value.rs · roots.rs · vm.rs reserve 面 · kerf-runtime/src/gc.rs · eval.rs 收集面 · examples/bench B4）：

| 面 | 代码事实（锚） |
|---|---|
| 收集算法 | mark-sweep 三相 `mark_all → sweep → clear_marks`（gc.rs:54-65）+ 显式工作栈防递归爆栈（gc.rs:71-102——10^5 深链实测锚 gc.rs:177-188）+ 保守策略（泄漏容忍误回收零容忍——§19.4 骨架兑现） |
| 堆结构 | `Vec<Cell{Option<HeapObj>, mark}>` 槽 arena + LIFO free-list（value.rs:48-63）+ arena 永不收缩无压缩（value.rs:395 测试断言）+ Cell 56B / HeapObj 48B / ClosureData 32B（实测口径） |
| 值表示 | `Value` 8 变体朴素枚举 24B（value.rs:184-194；全 kerf-vm 无 size_of 断言——§9.44.3 第 2 行「~24B」文档口径与实测一致）+ Str 独立堆分配 + `Pair/Closure(HeapRef u32)` |
| 根扫描 | `Roots` 五类快照（stack/locals/globals/foreign/handlers——roots.rs:22-37）+ VM 全值克隆快照（vm.rs:169-185）+ eval 侧类重载（stack 恒空 + 在途中间值寄居 foreign——eval.rs:551-558） |
| 分配路径 | 7 生产分配点（VM pair×3 + closure×1 / eval pair×2 + closure×1）+ free.pop 命中复用否则 cells.push（value.rs:73-86）+ 无 bump 区无 size class |
| 预算族 | 单账本 u32（frames + heap cells 合计——vm.rs:415-417）+ 软上限边界触发（达预算 → 一次 collect → retry——vm.rs:390-409；无分配率启发无周期性）+ 无 collector 注入 = fail-closed（vm.rs:55-58）+ eval 侧无条件 collect-then-retry（eval.rs:528-542） |

**既有登记位复核对象**：§9.44.3 第 2 行（Value 打包备选）/ 第 3 行（Heap——Lua 分页备选 + 分代维持）/ 第 10 行（闭包休眠捕获）；§9.44.5 值打包窗 + 分代窗；§9.51 ★1'（休眠捕获双成本——GC 保留过度近似面）。


### 9.53.3 内存管理域逐面审查表（十二面 × 前沿锚 × 裁定）

| # | 审查面（勘察锚） | 前沿对照 | 裁定 |
|---|---|---|---|
| 1 | 收集算法：mark-sweep 三相 + 显式工作栈（gc.rs:54-102） | K59/K60 | **维持采纳**——纯 tracing 批式 = 对偶谱最简端点（零写屏障 + 环收集免费 + 确定性）；§19.4 骨架兑现 + 三核心不变式全带测试锚 |
| 2 | 全停顿不可细分（vm.rs:395-399 单 reserve 内原子三相） | K61 增量 tricolor | **窗维持 Stage 3+**——单发编译执行零暂停敏感用例；写屏障复杂度不引入 |
| 3 | sweep + clear_marks 双全槽走查（gc.rs:107-120 / value.rs:149-153——每 cycle O(total)×2 + total 随高水位单调） | epoch marking（mark 奇偶免 clear）/ 位图 mark | **★GC-1 观察族登记**（零信号——B4 0.372ms 带内；候选技术 = epoch/位图/HeapRef 工作栈 4B 项；触发器 = B4 进热点前三或 profile 出现 clear 显著占比） |
| 4 | 分配：free-list LIFO pop-or-push 无 bump 区（value.rs:73-86） | K62 Immix 块内 bump | **窗内候选登记**——Immix = 分代窗开启时的分配面候选；当前 B2/B5 带内零信号 |
| 5 | Value 24B 朴素枚举 + Str 独立分配（value.rs:184-194） | K66 NaN-boxing/tagged | **窗维持 + con 证据新增**——i64 全域载荷 vs 48 位净荷冲突（语义缺陷引入面）；触发器不变 |
| 6 | Roots 快照全值克隆 + mark 工作栈 Vec<Value> 24B/项（vm.rs:169-185 / gc.rs:72） | K65（框架不解决 rooting）+ HeapRef 4B 工作栈形态 | **维持**——rooting 为嵌入方职责（kerf 已自持）；工作栈瘦身并入 ★GC-1 观察族 |
| 7 | driver 生产 VM 路径零 collector 注入（pipeline.rs:269 默认 8Mi fail-closed）vs eval 自动回收——双引擎不对称 | —（kerf 特有验证纪律面） | **维持 + 纪律注记**——fail-closed = 验证期语义（预算越界 = 程序缺陷信号不静默回收掩盖，§2.3 报错>静默）；宿主注入面就位（Collector trait + with_budget_and_collector）；触发器 = 长驻服务用例（Stage 3+ 运行时窗） |
| 8 | 预算单账本：帧 + 堆共享 u32（vm.rs:415-417） | — | **维持**——0.6/0.7 已裁（无循环原语 → 全部增长经调用+分配 → 单账本即完备；vm.rs:383-389 单点演进注记） |
| 9 | foreign 根只增不减（vm.rs:161-163 存活至 drop） | weakref/finalizer 面 | **观察登记**——生产消费者仅 eval temp 寄居 + 测试；反注册/弱引用 = Stage 3+ 运行时窗触发器（与 #7 合并评估） |
| 10 | 闭包休眠捕获双成本（vm.rs:244 / eval.rs:406 全帧克隆 + gc.rs:95-97 保留过度近似） | §9.51 ★1' 已登记（K43/K45/K51 锚） | **维持**——GC 保留面 = ★1' 第二成本组成；化解窗 = LA-2 选择性拷贝（Stage 2 首刀，槽位数下降后 mark 穿透语义不变） |
| 11 | 越界策略混用：test_and_set_mark panic（value.rs:136-144）vs is_marked/is_live 防御假（value.rs:121-129） | — | **维持**——语义不同：mark = 不变式违例（收集器只走 arena 引用——is_live 前置过滤后不可达）应 panic（§2.3 报错>静默）；query = 防御读取应假。非缺陷 |
| 12 | `Heap::len()` 语义 = live（value.rs:55-57 双名 len/live_len 同义） | — | **观察**——API 冗余零缺陷（注释单源说明）；重命名 = 零收益公开面涟漪，不为整洁翻修稳定边界（§12 最优>最小双向适用） |

**零 ★ 缺陷发现**（十二面全维持/登记——与 §9.50 检查器段并列的第二个零发现段；TD 账面归零与本轮零新增互证）。


### 9.53.4 技术与缺陷权衡（五类替代方案 × 引入缺陷对照）

| 替代方案 | 收益 | 引入的缺陷/成本 | 裁定 |
|---|---|---|---|
| RC 族（含 deferred——K63） | 增量回收无全停顿 | 每存储/传递写成本进 24 臂热分派环（§19.4 不变式 3 存储侧推广）+ 环收集仍需 tracing（K59 对偶）+ 计数器存储开销 | **不采纳** |
| 增量 tricolor（K61） | 暂停时间细分 | 写屏障 + 三色不变式维护 + 病态案例面；单发执行零收益 | **窗维持 Stage 3+** |
| 分代 nursery（K64） | 短命对象分配面最优（弱分代假设对 B4 churn 成立） | remembered set 写屏障 + 两代堆结构 + 提升策略调参 | **窗维持**（roadmap Stage 3+ 列项；触发器 = 短命占比实测） |
| Immix mark-region（K62） | 分配吞吐 + 局部性 | 块结构堆 + 行级碎片管理复杂度 | **分代窗内候选分配面**（不单独开窗） |
| MMTk 框架（K65） | 多算法生产实现 + policy/binding 分离 | 外部 crate（§18 DAG 冻结违例）+ rooting 仍自持（框架不覆盖嵌入方最难面）+ Stage 0-1 单算法无切换需求 | **§18 零引入维持** |

**核心权衡裁定**：mark-sweep 批式在 K59 对偶谱上的位置（纯 tracing 端点）恰是 Stage 0-1 约束（验证确定性 + 单发执行 + 闭集语义）的最优点——收集算法的「朴素」在当前阶段 = 设计保守性而非债务（§9.50 冻结层收口重审同构口径）；全部替代方案的成本面（写屏障/复杂度/外部依赖）都在当前零信号域，维持「零信号不开窗」（§9.8 + 原则 32 不预测）。


### 9.53.5 蓝图-实现偏差登记（§19.4 · P2 文档对账本轮清偿——以代码为准第 5 例）

**偏差事实**（勘察勘证）：

| 蓝图（§19.4:6214-6252 上游归档） | 实现（v0.23.0 代码） | 偏差性质 |
|---|---|---|
| alloc = `bump_alloc` 失败 → gc → `grow(size)` 扩堆 → 再 bump（:6214-6220） | 槽 arena + free-list LIFO pop-or-push（value.rs:73-86）；无 grow 路径——预算软上限 collect-then-retry，仍超 = BudgetExceeded fail-closed（vm.rs:390-409） | **强化非弱化**：蓝图 grow = 无上界；实现预算上界 = 验证期纪律（无界增长显式暴露为程序缺陷信号——§2.3 报错>静默 + 0.6→0.7 语义演进 vm.rs:383-389 单点注记） |
| sweep 伪码 `if !is_marked`（:6239） | `live && !marked`（gc.rs:113） | 语义等价（蓝图隐含活集域；实现显式双条件含已扫除槽防御） |
| 「bump 分配器与 free list 的共存：sweep 归还空间先记 free list」（:6252） | free-list 为唯一分配路径（无 bump 主路径） | 部分兑现——共存方向反转（free-list 为主）；「Stage 0 只分配不压缩」逐字兑现 |
| 递归标记（能力矩阵 :1882「bump-pointer + 递归标记」） | 显式工作栈（gc.rs:71-102） | §9.30 已登记（REC 四层谱系——10^7 嵌套陷阱防御）；本节收拢指针非新发现 |

**处置**（§8.4.5 文档-代码冲突）：以代码为准——§19.4 为上游蓝图归档（upload/stage0.md v6.1 存档纪律）不修改，**偏差登记以本节为活文档单源**；四处偏差中 grow→预算上界为语义强化（设计资产）、其余三处为等价或已登记。后续引用 §19.4 GC 骨架时以本节为对账层（原则 46 概念漂移防护——GC 域第一查询锚更新为本节）。


### 9.53.6 与 Stage 2 的接口 + 登记项影响

- **LA-2 捕获描述符联动**：选择性拷贝落地后 `ClosureData.env` 从全帧快照 → 精确捕获 → ★1' 第二成本（GC 保留过度近似）同步化解——mark 穿透 env 槽位的语义不变（gc.rs:95-97 代码零变更），仅保留集规模下降。
- **★GC-1 与 LA-3 正交**：收集算法面 vs 指令面——词法寻址首刀不动堆结构；GC 议程 Stage 2 零项（分代/增量/打包三窗全部 Stage 2+/3+）。
- **§9.44.3 第 3 行注记更新**：Heap 行补「§9.53.5 偏差对账层指针」（Lua 分页备选维持）；§9.44.5 值打包窗补「K66 con 证据」注记（触发器不变）。
- **roadmap v1.3**：§6 增补 Task 30 条目（谱系第六段收口 + §19.4 偏差登记清偿 + ★GC-1 观察族）。


### 9.53.7 每轮阻断条款九项复查（第五十二轮——全绿）

1. **谱系七段在场**：§9.46-§9.52 节头实读 7/7 ✓（本轮 §9.53 = 谱系第六段——内存管理域收口，管道审查谱系全域闭合）；2. 行动项四锚维持（★1 HM 接线 pipeline.rs:234/262 / MX-1 mangled macro.krf 8 处 / RS 迭代式 reader.krf rd-loop 7 处 / Symbol 驻留双文件 NonZeroU32）✓；3. **登记项复核**：★2-★6 + ★1' 演进窗维持 + 值打包窗（K66 con 证据补强）+ 分代窗（K62/K64 候选技术族补强）+ 本轮新登记 ★GC-1 观察族（零信号不开窗）✓；4. TD 登记册开放项 0 维持（Stage 1 全程归零 + 阶段间 T27-T30 零新债）✓；5. 语料 79 维持 ✓；6. selfhost 三件 116/741/558 维持 ✓；7. web 侧（本轮 Task 30-d 同步至 §9.53 态）✓；8. 基准核验：三通道第十三次不可达 → 零替换 + 六命令冷跑 1162:0:0 + audit 200/200 ✓；9. **裁定：历史审查发现全部实施或登记维持 + 本轮十二面审查零 ★ 新发现 + P2 偏差登记当轮清偿；阻断性条件解除维持；Stage 2 入口维持待用户确认（§14.6.3 规则 5——本轮零 Stage 2 实施）**。


### 9.53.8 收敛口径

8 原语不变性**第二十六轮**验证（纯文档域零代码变更零原语触碰——本轮无 Rust 代码变更，§3.2 冻结定义不变）；管道审查谱系六域段（§9.46-§9.50 + §9.53）+ 两特域段（§9.51 预备域 + §9.52 符号域）**全域闭合**——后续审查轮进入「复查维持」形态（零信号轮的九项复查即审查本体，§9.50 同构口径）。



---

## 9.54 Stage 2 §21 规划轮裁定（第五十三轮——规划域零代码变更）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.54 勘察基线与节引言


> **定位**：谱系全域闭合后的首个规划轮产出——Stage 2 排期与演进时机的裁定层（排期/验收单源 = develop/v2/stage-2-plan.md v1.0；本节承载设计依据侧：四登记窗核对结论 + 检索覆盖矩阵 + 确认门判定标准登记）。勘察基线 v0.23.0（1162:0:0 · audit 200/200 · 六命令冷跑复验——九项复查全绿[第五十三轮]）。


### 9.54.1 四登记窗信号核对（§21.7 成熟度时间函数）

| 登记窗 | 信号状态 | 裁定 |
|--------|---------|------|
| 词法寻址/捕获激活 | **信号满格**（LA-1..LA-7 预设计[§9.51.5] + Symbol 身份基座[§9.52.5] + GC 接口注记[§9.53.6] + D4 解阻 + ★1' 化解 + 用户「不能只关注当前阶段」常设指令） | **2.1 开启**（用户确认门后——子阶段排期单源 = stage-2-plan.md §2） |
| 符号驻留 | 已实施清偿（v0.23.0） | 窗关闭；C 方案[会话域]重评位维持（§9.52.3） |
| 分代 GC / 值打包 | 零信号维持（K64/K66 触发器不变） | 维持 Stage 3+（§9.53.4） |
| 语法替换（#15） | EBNF v9 定稿就位（§9.26）；切换窗本体未开窗（定稿 ≠ 实施） | 2.7 开窗评估（Stage 2a 收口 + 用户行权双前提） |


### 9.54.2 检索覆盖矩阵（零新检索声明——§12 不凑数）

本轮规划域**零新检索**：Stage 2 两大输入面的前沿对照均已由既有强锚完备覆盖——

| 输入面 | 既有覆盖 | 锚位 |
|--------|---------|------|
| LA 首刀实施面（2.1） | K42-K53 十四查（SISC 编译期解析 / OCaml 精确闭包 / Accattoli 2025 扁平闭包 / Rust 2021 精确捕获 / Lua/V8 不采纳路线） | §9.51.2 + tool-results/r28-search/ |
| fixpoint 三阶段窗（2.3-2.5） | K13-K17 五查（rustc 阶段制 / GHC 三阶段 / mrustc 替代实现 / bootstrappable 链 / Chez）+ BS-B/BS-E | §9.45.2 + §9.25 + tool-results/r21-search/ |

2.1 B 型审查先行时将按新域增量检索义务执行（r31-search/ 入库惯例——roadmap v1.4 §6 首议程 2）。


### 9.54.3 确认门判定标准登记（§14.6.3 规则 5 操作化）

> **r54 状态增注（2026-09-30）**：第五十四轮用户消息句首无条件【禁止进入 stage2】+ 条件句复述 → 门状态「⏳ 待行权」翻转为「⛔ 显式禁入维持」（非永久否决——同消息维持「禁止冻结」+ 常设审查指令，阶段间实施轮继续）；解除判据 = 本节句式清单 + 行权轮九项全绿前置，不变。三点登记：stage-2-plan.md §0 / roadmap v1.5 / §9.55.6。

沿 Stage 0→1 确认先例（stage-1-plan.md §0「排期已确定则继续推进」句式）操作化：用户消息含「进入 Stage 2 / 开始实施 / 首刀启动 / 排期已确定则继续推进」类显式句式 = 确认位补齐；**前置有效性条件** = 行权轮九项复查维持全绿（问题未解决 → 用户禁令复活）。单源落位 develop/v2/stage-2-plan.md §0；本轮裁定：规划域先行（T28 先例同构——规划 ≠ 实施确认）。


### 9.54.4 每轮阻断条款九项复查（第五十三轮——全绿）

1. 谱系八段在场：§9.46-§9.53 节头实读 8/8 ✓；2. 行动项四锚维持（★1 HM 接线 pipeline.rs typecheck() ×4 / MX-1 mangled ×8 / RS rd-loop ×7 / Symbol 驻留 NonZeroU32）✓；3. 登记项复核（★2-★6 + ★1' + ★GC-1 + 值打包窗[con 证据] + 分代窗[候选族]维持）✓；4. TD 开放项 0（连续十五轮）✓；5. 语料 79 维持 ✓；6. selfhost 三件 116/741/558 ✓；7. web 侧（本轮 Task 31-d 同步）✓；8. 基准核验：三通道第十四次不可达 → 零替换 + 六命令冷跑 1162:0:0 + audit 200/200 ✓；9. **裁定：历史发现全部实施或登记维持 + 本轮零 ★ + 规划域落档；阻断性条件解除维持；Stage 2 实施入口维持待用户确认（§14.6.3 规则 5——判定标准 = §9.54.3）**。


### 9.54.5 收敛口径

8 原语不变性**第二十七轮**验证（纯文档域零代码变更零原语触碰——本轮无 Rust 代码变更）；零新检索（覆盖矩阵声明 §9.54.2）；零机制变更、零语法增量；Stage 2 实施零触碰（用户确认门维持）。



---

## 9.55 fixpoint 前置确定性域前沿对照与全树迭代序审计（第五十四轮 · r54 · Task 32 · v0.24.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.55 勘察基线与节引言


> **勘察基线**：v0.23.0 @ git 71ed6e6（1162:0:0 · audit 200/200 · 六命令冷跑复验）；**实施基线**：v0.24.0（1169:0:0 · audit 200/200——守护测试 +7 与四处不变量注释）。**触发器开启记录**：用户常设指令「对整个编译流程进行全方位审查……数据结构选型与算法选型」（r54 第五十四轮重申 + 「不要所谓收敛收口」显式否定 Task 30 的「复查维持形态」收口裁定）+ Stage 2 出口判据 (2)「两次编译自身字节一致」的硬前置——确定性域为审查谱系（§9.43-§9.54）唯一未专项覆盖的横切面：§9.44.3 十二行表审**选型**、各域段审**域内面**，无一段审**迭代序→输出**这一横切缺陷类。本节为该缺口的专项闭合。


### 9.55.1 方法与证据基

全树普查 + 逐站精读双段式：`rg "HashMap|HashSet" crates/*/src` 普查（61 非注释站点 / 14 文件；含 reserved/ 见证域 19 处）→ 逐站精读消费面（插入点 / 读取形态 / 迭代点 / 发射路径），四类判定：**(a) 仅成员**（insert + contains——集合终态与序无关）、**(b) 仅按键**（insert + get/索引访问——查找与序无关）、**(c) 插入序索引**（idx = Vec.len() at insert + Vec 为发射源——HashMap 仅作去重索引）、**(d) 迭代序泄漏**（迭代序进入输出——**缺陷类**）。数值边界语义面同步复验（溢出/除零/NaN/浮点显示——勘察实证，非本轮硬化）。检索存档 tool-results/r32-search/ 六查实体入库。


### 9.55.3 逐站点分类审查表（61 站点 → 四类判定 · 零 (d) 类）

| 域 | 站点 | 判定 | 证据要点 |
|----|------|------|---------|
| compiler/compile.rs | 8 | **(c) 插入序索引 ×2 + (b) 键控 ×1 族** | `intern_const`/`intern_global`：`idx = self.consts.len()`/`self.globals.len()` at insert（compile.rs:223/233）+ `finish()` 直取 Vec 发射（`consts: self.consts` / `globals: self.globals`）——**字节码索引 = 首用序，哈希序永不入表**；`jump_sources`：insert + `p.jump_sources[&at]` 索引访问；`unpatched`/`locals` = Vec |
| compiler/verify.rs | 3 | (b) 键控 | `depth_at: HashMap<usize, u32>` insert + 按键读（CFG 深度分析内部面） |
| core/symbol.rs + syntax/symbol.rs | 6 | **(c) 插入序索引（驻留池）** | K54 形态：`HashMap<&'static str, NonZeroU32>` 查插 + `Vec<&'static str>` 发射；索引 = 插入计数器序（同输入同序）+ Debug 手写 text-only（索引永不入输出——§9.52.4 测试锁定） |
| core/expr.rs | 3 | (a) 成员 | `seen: HashSet<&str>` 去重——**「首个重复」= 切片序**（`for raw in params { if !seen.insert(*raw) { return Err(name) } }`——错误载荷与序无关） |
| expander/transformer.rs | 10 | (a)/(b) + 集合并（→9.55.4） | `bindings` 键控（get）；`trigger` 仅 contains 消费（fresh_name:321 / binder_collisions:506）；`collect_symbols` 纯集合并；**mangled 计数器序 = 模板树遍历序**（instantiate_node items.iter() 递归） |
| expander/ctx.rs | 5 | (a)/(b) | `names` insert+contains / `macros` insert+get / `frames` = Vec（.iter().rev() 栈序） |
| expander/module.rs | 9 | (b)/(a) + 初始化集 | `declared` 键控；`colors` 经 `graph.keys()` 初始化（**终态内容确定**——全 White 初始化与序无关）+ 消费键控 + **DFS 驱动 = `declaration_order` Vec**（module.rs:175）；`in_order` 成员 |
| typecheck/infer.rs + check.rs | 7 | (a)/(b) | `bool_demanded` insert + `.get(idx).is_some_and(contains)`（infer.rs:1071/1318）；`fn_param_pos` insert+get；`assigned` insert+contains（R2 过近似守卫——结果 = 「X ∈ 集」与序无关） |
| runtime/eval.rs | 5 | (b) 主路径 + 根扫描（→9.55.4） | `globals` insert+get 主路径；`closures` insert+get+retain（序无关）；`collect_now` 的 `globals.values().collect()` = 唯一生产迭代点（免疫证明 9.55.4） |
| runtime/gc.rs | — | 索引序 | `mark_all` 工作栈 LIFO（标记集 = 可达集不动点）+ **`sweep` 按 `0..total_slots` 槽索引序**重建自由表（分配地址确定） |
| vm/vm.rs | 1 | (a) 测试助手 | `rooted` HashSet 成员消费 + 槽范围迭代（MiniCollector 测试件） |
| core/reserved/ | 19 | 管线外见证域 | cache.rs HashMapCache 见证 ×17 + capability/family.rs ×2——登记态接口见证代码，**不入编译输出路径**（分类豁免非审查豁免：若未来 reserved 转生产面 → 重审） |
| reader / span / driver | 0 | 零站点 | reader 逐字符扫描无集合；driver 管线无哈希结构（parity 基础设施内部面除外——属测试基础设施非管线数据面） |

**汇总**：(a) 18 / (b) 21 / (c) 16（含驻留双池）/ 免疫迭代 2（→9.55.4）/ 管线外 19 / 零站点 3 crate——**(d) 迭代序泄漏 = 0 站点**。


### 9.55.4 集合序免疫迭代证明与数值边界复验

**证明一（transformer.rs:185 `bindings.values()`）**：迭代消费 = `collect_symbols(arg, &mut trigger)` 纯集合并——集合并满足交换律，`trigger` **终态内容**与迭代序无关；下游全成员消费（`fresh_name` 的 `!trigger.contains(&candidate)`、`binder_collisions` 的 `trigger.contains(name)` + 声明序 Vec 输出）→ **mangled 后缀序列 = fresh_name 调用序 = 模板树遍历序（确定）**，与 trigger 集内部序无关。

**证明二（eval.rs:555 `globals.values()` → mark）**：根表顺序仅决定 mark 工作栈的**访问序列**；标记集 = 可达集不动点（`test_and_set_mark` 幂等 + 出边闭包）——集合与序无关；`marked` 计数 = 集合势（序不变量）；sweep 按 `0..total_slots` 索引序重建自由表 → **GC 后分配地址确定**。观察面（值/打印/诊断）不含 HeapRef 地址 → 地址稳定性为超需确定（守护测试仍覆盖 bytecode 面，运行期面由 parity/语料重放间接锁定）。

**数值边界语义复验（勘察实证——历史轮已硬化，本轮零 ★ 维持）**：checked 算术 fail-closed（builtin.rs:123-130 `checked_add/sub/mul/div` + error.rs `Overflow` 短式——debug/release 双模式同语义，无裸 `+` 溢出分歧）+ NaN 规范化（compile.rs:46-47 `ConstKey::Float(if v.is_nan() { f64::NAN.to_bits() }`——NaN 单槽折叠 + ±0.0 位型键分离保持槽区分）+ NaN 位等判等（value.rs「A NaN equals its bit-identical copy (total, deterministic)」）+ 浮点显示面（Render 黄金锁定）。


### 9.55.5 fixpoint 前置裁定与守护实施（属性测试化——「实施或登记」第三形态）

**裁定**：全树零迭代序泄漏——**属性由构造成立，但此前未被任何测试锁定**（§9.49 ★1-★6 与 §9.53 十二面均不含本面；门 B 比较两引擎产物，守护比较同引擎两次运行——正交互补）。按用户条款「需要在项目中具体实施设计和重构，而非只有 docs/stage0.md 上简单更新」：缺陷不存在时，实施物 = **属性的防回归锁定物**（守护测试 + 不变量注释），非修复非登记——「审查发现全部实施或登记」条款的第三种形态：**属性测试化**。

**守护测试族 +7**（tests/v1/stage1/plan/determinism_guard_tests.rs，根树挂载 runner.rs）：
- `selfhost_assembled_subjects_double_traversal_identical`（**跨阶段正案**）：fixpoint 主体按门 B 配方装配（reader 侧 = `token_table_prefix(READER_SOURCE)` + READER_SOURCE[RS-1]；expander 侧 = `forms_stream_prefix(read_program(READER_SOURCE))` + `assembled_expander_source()`[EX-1/MX-2]）→ 两次独立 reader→expander→loader→compiler 遍历 → items 结构全等 + **Bytecode 结构全等（含 debug_info span）** + 非平凡性（funcs>1 / 池与全局表非空）
- `corpus_sweep_double_traversal_identical`：79 语料全量双遍历——接受案 items+bytecode 全等 / 拒绝案诊断批全等 / **pos-\* 全部 + bnd-006 必须到达编译成功**（管线回归护栏——确定性断言不吞语义回归）
- `macro_rename_face_double_expansion_identical`：rename-on-capture 构造（模板引入 tmp 绑定 + 使用点同名全局）→ mangled 树与字节码双全等
- 检测器三臂 `bytecode_equality_catches_{const_pool,global_table,code}_divergence`（**负案 ×3**）：PartialEq 检测力证明——常量池追加 / 全局表追加 / 指令流追加必被捕获（守护非平凡）
- `define_order_is_first_use_semantics`：ab/ba 两序两表 + `assert_ne`——**首用（源序）语义的文档化测试**：源序可观察且确定，哈希序永不入表

**检测原理**：K67 per-instance RandomState——同进程两次独立遍历中每个 `HashMap::new()` 携带不同 SipHash 键 → 任何 (d) 类泄漏以高概率表面化为结构不等（比跨进程更可控：无环境噪声，纯键差）。跨进程随机种子差由 CI 多次运行天然覆盖。

**四处不变量注释**（纯注释零行为变更）：compile.rs `intern_const`/`intern_global`（插入序不变量 + fixpoint 依赖声明）/ transformer.rs trigger 集合并序无关 / eval.rs `collect_now` 根序惰性 / gc.rs `sweep` 索引序——未来变更触碰这些位点时，不变量以注释形式在场（违反 = 守护测试翻车 + 注释对照定位）。

**实施期探针实录（期望零猜测纪律第十五轮）**：初版两猜测当轮翻车——①裸 selfhost 源直接编译（缺 RS-1 token 表 / EX-1 forms 流注入契约 → `unbound identifier tokens/forms` ×2）→ 重读 reader_parity.rs `run_dual` 与 expander_parity.rs `gate_b_bytecode` 装配配方后按门 B 配方复刻；②语料接受数阈值猜测 ≥60（实际 54 = 31 pos + bnd-006 + 22 个仅 typecheck/run 期失败案[38 neg 中约半数死于检查器/运行期而非 parse+compile]）→ 改为零猜测断言（pos-\*+bnd-006 必须接受 + 双遍历全等 + 双面非空）。翻车-修正过程 = 探针实录登记非粉饰。

**GATE 6 构成**：正 4 / 负 3 / 跨阶段 1——达标。


### 9.55.6 r54 显式禁入登记（确认门状态翻转——32-b 第三落点）

用户第五十四轮消息将「【禁止进入 stage2】」升格为**句首无条件限定** + 原条件句复述（「只要有一个问题没有得到解决则禁止继续向前推进（每一轮都需要进行）」）。裁定（沿 §9.54.3 判定标准的反向行使）：门状态由「⏳ 待行权」翻转为「⛔ **显式禁入维持**」——**非永久否决**（同消息维持「项目禁止冻结」+ 常设审查指令——阶段间实施轮继续，本节即例证：「禁止冻结」与「禁入 stage2」并行不悖）；2.1 实施入口在用户显式解除前不开；解除判据不变（§9.54.3 句式清单 + 行权轮九项全绿前置）。三点登记：stage-2-plan.md §0（Status 行 + 门表第 4 行 + r54 注记）/ roadmap v1.5（状态行 + 推进序列 + 门现行权威行）/ 本节（单源锚）。


### 9.55.8 收敛口径

8 原语不变性**第二十八轮**验证（测试面 + 注释面增量：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF 增量——守护测试 = 既有子集的纯消费面，四处注释 = 既有代码面）；零新外部依赖（§18 DAG 冻结维持——std 内建达成 K69 同构）；TD 开放项 0 维持（属性锁定非债）；检索质量如实披露（q5/q6 弱查降档）；selfhost parity 字节全等维持 + 语料 79 维持 + 每轮阻断条款九项复查全绿（第五十四轮）；实施基线 v0.24.0 = 1169:0:0 + audit 200/200（六命令冷跑复验）。下一轮入口 = 阶段间轮继续（用户常设指令维持；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.56 诊断信息系统域前沿对照与位置单源化实施（第五十五轮 · r55 · Task 33 · v0.25.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.56 勘察基线与节引言


> **本节性质**：阶段间 B 型前沿审查轮（用户常设指令「对整个编译流程进行全方位审查」第十六轮先行执行——确定性域（§9.55）之后审查谱系唯一未专项覆盖的横切域：**诊断信息系统域**[结构化诊断 → 位置派生 → 渲染 → 收集策略 → parity 交互全链]）。审查含代码实施：v0.24.0 @ 127b322 勘察基线 → v0.25.0 交付（六命令 **1170:0:0** + audit **200/200**——15 文件 +298/-228）。r55 用户消息再次含【禁止进入 stage2】→ ⛔ 显式禁入维持（r54 登记 + r55 重申，非永久否决，解除判据 §9.54.3 不变）。


### 9.56.1 方法与证据基

- **勘察面**（主 Agent 直接勘察，沿 §9.49 先例）：①诊断三件套精读——`kerf-driver/src/diagnostic.rs`（结构化诊断：Severity 四级 / DiagnosticCode 六生产者 / Diagnostic 五字段 + 六 from_* 构造器 + 41 变体穷举映射测试）、`line_index.rs`（TD-001 兑现：字节→行列派生，1 基 / 字符列 / 边界下取整 / 末行钳制 / fail-closed）、`render.rs`（rustc 风格渲染：`error[tag]: msg` + `--> file:line:col` + 摘录 + caret run + 槽宽自适应 + 多诊断分隔与汇总行）；②四错误族 Display 全量盘点——reader error.rs（10 变体 6 位置站点）/ expander error.rs（9 变体 9 站点）/ compiler error.rs（14 变体 10 站点）/ vm error.rs（11 变体 11 站点）；③收集面——pipeline.rs（per-stage Vec<Diagnostic> + typecheck 全收集 + split_warnings 双路）/ session.rs（FileEntry upsert 语义）；④parity 交互面——reader_parity/expander_parity 的 KrfVerdict 重建-渲染比较机制；⑤REPL/CLI 呈现（render_diagnostics 单源）。
- **检索面**（r33-search 六查 + 主源直读一查，存档 `docs/lang-design/tool-results/r33-search/`）：q1 rustc 诊断架构（rustc-dev-guide 诊断章 + codemap-diagnostic + cjc-diag）/ q2 rustc 行索引缓存（caching_source_map_view + rust-analyzer line-index crate）/ q4 错误恢复谱系（oxc / langdev.stackexchange / lalrpop / tratt.net / elm discourse / syn IDE 支持帖）三查有效；**q3（位置分离惯例）三措辞全垃圾结果 → 降级补救：curl 直读 rustc-dev-guide 诊断章主源全文归档（q3-rustc-dev-guide-diagnostics.txt 40,371 字符）——弱查升级为最强锚**；q5（codespan-reporting）三措辞垃圾、q6（LSP Diagnostic）垃圾 → **二弱查如实降档**（渲染库形态由 render.rs 既有 rustc 风格引注 + K71 主源覆盖；LSP 投影面由 §9.27 INFO-F LSP 四级协议既有登记覆盖）。
- **探针实证**（期望零猜测纪律第十六轮）：①CLI 双报位真实输出探针（order_probe.krf——`unbound identifier \`g\` at file#0:15..16` + `--> order_probe.krf:1:16` 同屏双位置实证）；②typecheck 多错序探针（order_probe3.krf 三 arity 错——**逐项遍历 = 源序发射实证**，DIAG-6 前提不成立降档为非缺陷注记）；③实施期全失败枚举法（初版改动 → cargo test --no-fail-fast 点名 29 失败 → 逐处修复零遗漏——测试套件即清单，先例沿 §9.52）。


### 9.56.3 诊断域逐面审查表（十二面 × 前沿锚 × 裁定）

| # | 审查面 | 代码事实（勘察基线 v0.24.0） | 前沿锚 | 裁定 |
|---|---|---|---|---|
| 1 | 诊断数据结构 | Diagnostic{severity, code, message, file, primary_span}；children/suggestions 刻意缺席（R1 桩禁令——无生产者不建字段） | K71 六要件 | **维持**（生产者出现再扩——Note/Help 为 §8.7 契约槽非桩） |
| 2 | 位置表示与渲染分离 | Span 字节偏移存储 + LineIndex 渲染期派生（TD-001 @ 0.8 已偿）+ 字符列 CJK 对齐 + 边界下取整 | rustc SourceMap 同构 | **维持**（已兑现在先） |
| 3 | 消息-位置分离 | **36 Display 站点内嵌位置片段**：reader 6（"at byte N"）+ expander 9（"at {span}"）+ compiler 10（"({span})"/"at {span}"）+ vm 11（"({span})"）→ 与渲染器 `-->` 行**双报位置**且内部形态（file#0:15..16）泄漏给用户 | **K71 明文**："Message…stands on its own"；位置专属 `-->` 行 | **★2-DIAG1 → 本轮实施**（§9.56.4-9.56.5） |
| 4 | LineIndex 生命周期 | render_position + render_one 各建一次（宽度 pass + 渲染 pass = 每诊断 2×O(source)）；column_of 工具函数同 | **K72**：一次计算缓存 | **★-DIAG4 → 本轮实施**（Session 持有，intern 建一次 upsert 重建） |
| 5 | 错误码体系 | 阶段标签（kerf-read 等 5）+ Typecheck(E0xxx 注册表 11 码)——两制在接线处合流（error[E0002]:） | K74 全域码先例 | **登记窗**（触发器：外部工具需错误身份匹配/抑制时开窗——零信号不开窗） |
| 6 | 错误收集策略 | reader/expand/compile/runtime 单错 fail-fast（跨文件聚合 §12.2）；typecheck 全收集；split_warnings 双路 | K73 谱系 | **登记窗**（DIAG-2：reader 单错契约 = parity 冻结面[reader.krf 结构化错误族 + 语料期望形态] + 双侧改造成本；触发器：交互式 DX 轮用户信号） |
| 7 | 严重级体系 | 四级契约（Error/Warning 有生产者；Note/Help 契约槽）；diagnostic.rs 注释锚「Stage 1+ diagnostics agenda」——**地平线已过时**（Stage 1 CLOSED） | K71（note/help/suggestion 分工） | **登记修正**（DIAG-3：建议引擎窗触发器改锚「外部 IDE/LSP 消费者出现」；Note/Help 槽保留非桩声明维持） |
| 8 | 排序与去重 | 生产序发射（typecheck 逐项 = 源序——探针实证；跨文件 CLI 序）；§9.55 守护锁定拒绝批双跑全等；零去重 | rustc 发射前排序 | **非缺陷维持**（生产序即源序 by 构造；确定性已由守护锁定；排序器 = 无信号机制，§12 不凑数） |
| 9 | 渲染器形态 | rustc 风格五件（标签头/位置行/摘录/caret/汇总）+ 槽宽自适应 + 位置缺失诊断无位置行（零 DUMMY）+ 未知文件消息直递 | K71 输出形态 | **维持**（ds01-ds05/ds10 金色本轮再基线——有意设计变更文档化） |
| 10 | REPL/CLI 呈现 | repl.rs/cli.rs 均走 render_diagnostics 单源 | 单源纪律 | **维持** |
| 11 | parity 交互面 | .krf 侧结构化 payload（kind+offset/span）→ 宿主重建 → **同 Display 渲染比较**：消息变更 Rust 侧单侧生效（.krf 零触碰）；**但位置剥离致文本比较 payload 盲化**（不同 offset 同消息 → 漂移不可见——实施期发现） | 树轴 dump 含 s/e 偏移先例 | **实施期连锁修正**：错误轴 parity 键 = Display + harness 自渲染位置后缀（reader `@ byte N` / expander `@ {span}`）——与树轴同构，篡改检测恢复（drift_detector/span_trap 实证） |
| 12 | 8 原语不变性 | 诊断 = driver 层纯呈现面 | 宪制 | **第二十九轮验证**（零新原语/零通道/零 VM/零语法/零 EBNF——36 站点纯字符串面 + Session 字段增量） |


### 9.56.4 技术与缺陷权衡（DIAG-1 剥离的反方论证与知情裁定）

- **反方一（独立消费面失去消息内位置）**：库消费者（无渲染器上下文）在 to_string() 中失去位置。**裁定**：结构化访问器（ReadError::offset() / ExpandError::span() / CompileError::span() / RuntimeError::span()）本就存在且为本轮断言面所用——位置的可编程访问未损失，损失仅为「无上下文打印时的便利」，以 payload 访问器补偿（测试面实证：display_unclosed_is_position_free 断言 offset() 保位）。
- **反方二（R8 单源字典条目变更）**：36 站点消息字符串全变 = 字典条目全换。**裁定**：单源字典约束的是「同源同译」一致性而非字符串冻结；本轮变更同源同译维持（.krf 侧 payload 结构化零消息文本，宿主 Display 单源渲染——字典面反而收窄为单侧）。
- **反方三（金色冻结义务）**：ds01-ds05/ds10/ln/e2e 金色快照再基线 = 冻结打破？**裁定**：冻结义务防的是**意外漂移**；本轮为**有意设计变更**（K71 正典依据 + §9.56 审查裁定 + worklog/RELEASE_NOTES 文档化）——先例：ds03 金色随 1.1 接线再基线（snapshot_seed_tests 注释明载）、ds08 版本金色逐轮共变。
- **缺陷引入评估**：剥离后渲染输出 = 消息行 + 位置行各一（单一位置渲染源）；风险 = parity 漂移检测盲化（第 11 面）——**当轮发现当轮修正**（parity 键后缀），实证 = drift_detector_catches_a_tampered_span_selection（篡改 span 选择器 → 键文本异 → matched=false 恢复检测力）。


### 9.56.5 实施记录（v0.25.0——位置单源化 + 索引缓存 + parity 键）

- **DIAG-1 位置剥离（36 站点）**：reader 6（"at byte N" 剥离——UnclosedList/UnexpectedClose/UnterminatedString/InvalidEscape/EmptyApplication/UnexpectedCharacter 六消息改为自足形态）+ expander 9（"at {span}" 剥离——含 UnboundIdentifier "…`: not in any lexical scope…" 语义尾保留）+ compiler 10（"({span})" 剥离——**pc/func/slot/index 语义负载保留**：`stack underflow at pc \`9\`` 形态本就正典）+ vm 11（"({span})" 剥离）。四处 Display 增 §9.56 DIAG-1 注释（设计依据内联锚）。
- **DIAG-4 Session 行索引缓存**：FileEntry 增 index 字段（intern 时 LineIndex::new 一次构建；REPL upsert 重建——stale 索引会错位渲染，测试锁定）；Session::line_index(&FileId) 访问器（fail-closed None）；render_position/render_one 改取缓存（每文件每版本 O(source) 一次，宽度 pass 与渲染 pass 共享）；column_of 工具函数维持（原始源无 session 场景）。**K72 同构：rustc SourceMap / rust-analyzer line-index 形态**。测试 +1（line_index_cache_matches_fresh_build_and_rebuilds_on_upsert：缓存 == 现算 + upsert 重建 + 未知 id fail-closed 三断言）。
- **parity 键三处**：reader_parity（error_parity_key：Display + "@ byte N"——payload-only 变体无后缀，消息内负载[文本/深度]本可区分）+ expander_parity（error_parity_key：ParityError::span() + "@ {span}"）+ 两 harness oracle 构造点同步。**设计依据**：树轴 dump（"(define 0 36 x …)"）本就携带 s/e 偏移——错误轴键携带位置 = 双轴同构，非新形态。
- **测试期望更新 29 失败全数清偿**（实施期枚举法）：crate 内联 10（reader 1 重命名 display_unclosed_is_position_free + expander 2 重命名 + compiler 3 + vm 2 + runtime eval 1 + runtime api 1）+ driver parity 内联 3 + 根树 16（reader_parity_tests 2 / expander_parity_tests 9 / snapshot 5 / driver_seed 1）+ audit example 7（S08 双面含 module cycle 精确键 + span trap 五处 + bnd-010 深度键）。
- **版本面共变族 v0.25.0**：Cargo.toml + Cargo.lock + ds08 版本黄金（注释链 + 断言）+ RELEASE_NOTES v0.25.0 + README Status + docs/tests/README 诊断域行 + docs/tests/matrix T33 节 + calibration-data 阶段间实施行 + roadmap v1.6 + stage0.md v9.22（本节 + 头部版本链 + 附录 G v22）。
- **六命令冷跑全绿**：fmt 初跑 1 处 diff（audit S08 长行断言）→ cargo fmt 修正后零 diff（如实登记）+ build 0/0 + check 0/0 + clippy -D warnings 0 + **test 1170:0:0**（1169 基线 + 1 新增 Session 缓存测试，零回归）+ **audit 200/200**（A-V 二十一节——S05/S07/S08/R02-R04/T08 七处键形态更新后全绿）。


### 9.56.8 收敛口径

8 原语不变性**第二十九轮**验证（纯呈现面：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF 增量——36 消息站点字符串面 + Session 派生缓存字段 + parity 键渲染层）；零新外部依赖（§18 DAG 冻结维持——LineIndex 既有类型内化，零新 crate）；TD 开放项 0 维持（连续十七轮）；检索质量如实披露（q5/q6 二弱查降档 + q3 弱查升级主源直读）；selfhost parity 三件字节全等维持 + 语料 79 维持 + 每轮阻断条款九项复查全绿（第五十五轮）；实施基线 v0.25.0 = 1170:0:0 + audit 200/200（六命令冷跑复验）。下一轮入口 = 阶段间轮继续（用户常设指令维持；候选横切域 = 测试基础设施自审计域[§9.55 前登记候选，待 r56 路由]；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。





---

## 9.57 测试基础设施自审计域前沿对照与清单守卫实施（第五十六轮 · r56 · Task 34 · v0.26.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

### 9.57.1 方法与证据基

**触发器开启记录**：§9.56.8 登记候选确认（33-b 裁定候选二取一路由：用户常设指令「按编译管道对照前沿核心设计」+ TD-001 关联面之后，测试基础设施自审计 = 元域）。审查谱系 r51-r55 已覆盖 Symbol 驻留 / 内存管理 / 规划 / 确定性 / 诊断五横切面——**验证者自身（测试树）是谱系唯一未受审查的支撑组件**："审查者未受审查" = 元域缺口。本轮开面。

**代码事实基线**（勘察基线 v0.25.0 @ 9e14145，期望零猜测纪律第十七轮）：
- 测试树总体：tests/runner.rs 单入口（81 行，23 个 `#[path]` 挂载 + common 单挂）+ tests/v0/stage0/plan/ 12 文件 + tests/v1/stage1/plan/ 12 文件（含本轮新增守卫）+ tests/v1/stage1/corpus/ 79 语料 + tests/common/mod.rs + examples/audit/stage0_gate_audit_r1.rs（3289 行，A-V 二十一节）。
- **装配面事实**：cargo 只自动发现顶层 tests/*.rs；深层文件全部经 runner.rs `#[path]` 挂载运行——**未挂载文件 = 永不编译永不运行的静默死文件**（当前 23/23 全挂载零缺口，但零机制守护）。
- **语料面事实**：subset_corpus_tests.rs 双面设计（79 条 corpus_case! 逐案表 + 动态全目录扫 + 分布底线 pos≥20/neg≥20/bnd≥10/总≥50 + 命名唯一性）——头注自述「表可滞后」（sweep 保验证完备，隔离面滞后被容忍）。
- **audit 面事实**（逐行探针）：头条 "AUDIT PASS 200/200" 为**硬编码字面量非计算值**；案例标签三形态分歧（A-D 助手调用带引号标签 + E-T 整行注释 `// X01:` + U/V 单位数 `// U1:`）；**H07 无独立开题注释**（与 H06 共块"fail-closed pair"）；D 节每案例 = 注释 + audit_ok 双站点。行锚定精确计数：助手开题 23（30 调用中 7 首参同行）+ 整行标签 174 − D 节双计 5 = **199 实标签 vs 200 文档主张**——清单主张不可机检。
- **文档面事实**：docs/tests/matrix.md 逐子阶段计数人工维护；五处记载全量测试数（README/RELEASE_NOTES/matrix/stage0/calibration）。


### 9.57.3 测试基础设施逐面审查表（十二面 × 前沿锚 × 裁定）

| # | 审查面 | 代码事实（勘察基线 v0.25.0） | 前沿锚 | 裁定 |
|---|---|---|---|---|
| 1 | 测试树装配完整性 | 23 文件全挂载（手工）；未挂载 = 静默死文件，零机制守护 | K75 tidy 测试落位纪律（工具强制） | **★TEST-1 → 本轮实施**（runner 装配守卫——双向完备） |
| 2 | 语料清单完整性 | sweep 保验证完备 + 分布底线 + 命名唯一；**逐案表滞后被头注明文容忍**（隔离面静默退化） | K75 compiletest 散逸输出文件追踪 | **★TEST-2 → 本轮实施**（表-目录集合全等守卫） |
| 3 | audit 案例注册 | 头条 200/200 硬编码字面量；标签三形态分歧；H07 无独立注释；199 实标签 vs 200 主张——**门审证据的清单主张不可机检** | K75 tidy 机械树检 + compiletest 逐测试指令注册 | **★TEST-3 → 本轮实施**（规约化 + 注册守卫 + 检测力臂） |
| 4 | 金色快照工作流 | ds01-ds10 + ln + e2e 金色族；再基线 = 有意设计变更文档化纪律（r55 六处先例） | K75 `--bless`；K76 UPDATE_EXPECT | **登记窗** W-TEST-BLESS（触发器：金色文件数 ≥15 或单轮再基线 ≥8 处——手工编辑出错率信号） |
| 5 | 输出归一化 | parity 键位置后缀 + CJK 列渲染 + ds08 版本黄金（r55/r51 先例） | K75 `$DIR`/`$SRC_DIR`/`LL:COL` | **维持**（归一化面已完备——本轮零缺口） |
| 6 | 变异测试 | 零机制（测试质量主张 = 覆盖率近 100% 口径 + 门审审计集） | K77 cargo-mutants/mutest-rs | **登记窗** W-TEST-MUTATION（触发器：测试套件质量需外部独立验证的信号[如门审投票反对票集中]；宿主侧工具不入依赖链） |
| 7 | 文档计数同步 | 全量测试数五处人工维护；matrix 逐子阶段计数人工维护 | K75 tidy 文档检查族 | **部分守护**（本轮守卫覆盖 audit 200 + 语料 79 两主张；全量测试数 = cargo test 输出单源，无程序内消费面——W-TEST-DOCSYNC 登记） |
| 8 | 逐案隔离 vs 批量 | 逐案 #[test] + 动态 sweep 双面（kerf 既有设计） | K75 ui 逐文件测试 | **维持**（双面设计正确——本轮 TEST-2 把两面锁成全等） |
| 9 | 测试运行器 | cargo test 默认运行器 | nextest（零信号：无限流重试/并行痛点） | **维持** |
| 10 | 确定性守护 | r54 属性测试化 +7（装配双跑/语料双跑/检测器三臂/首用序） | 确定性双跑先例 | **维持**（r54 已实施——本轮守卫的形态先例） |
| 11 | 打包回归验证 | §19 每轮解包 diff -r 归零（人工执行） | K75 distcheck（tarball 构建测试一体化） | **登记窗** W-TEST-DISTCHECK（触发器：打包轮数密度上升或包体积增长使人工 diff 成为瓶颈） |
| 12 | 8 原语不变性 | 测试基础设施 = 纯消费面（守卫读树计数，零管道执行） | 宪制 | **第三十轮验证**（零新原语/零通道/零 VM/零语法/零 EBNF——纯测试树 + 注释面增量） |


### 9.57.4 技术与缺陷权衡（三实施的知情裁定）

- **反方一（守卫 = 对约定形态的文本耦合）**：TEST-3 依赖「每案例整行开题注释」约定——audit 重构为其他形态时守卫碎裂。**裁定**：守卫碎裂 = 大声失败（fail-closed），修复即重对齐——耦合即契约（K75 tidy 对 rustc 树的同构耦合先例：约定本身由工具强制）；检测力臂（TEST-3b）锁定计数器的近失拒计面。
- **反方二（注册规约化 = 3289 行冻结证据文件的 50 处注释改动）**：门审证据文件承受机械搅动。**裁定**：纯注释零行为变更（audit 复跑 200/200 全绿实证）；一次性注册成本换永久机检能力——"200/200" 从字面量主张升为机检事实。
- **反方三（语料表滞后容忍被撤销 = 每新增语料文件须同步改表）**：原头注明文容忍滞后（sweep 保验证完备）。**裁定**：sweep 保**验证**完备但不保**隔离**完备——滞后 = 新案例无独立失败命名（静默退化）；守卫把滞后转为当轮大声失败；头注同步改写为新不变量。compiletest 逐测试指令注册同构（新增测试文件 = 必须带指令，同族纪律）。
- **开发期真阳性实录（守卫检测力免费实证）**：TEST-2 首跑即捕获 harness 自身 `.ends_with(".krf")` 后缀探针字面量被误计为幻影条目 → 判别式收紧（stem 必需——裸 ".krf" 非案例名）——守卫在工作首日即捕获一个真实误报源并被迫精确化（§9.57.5）。
- **缺陷引入评估**：三守卫全部为纯读树计数（零管道执行零依赖增量——§18 零新 crate 零新外部边）；唯一新增耦合 = 文本约定（见反方一裁定）；测试面 +4 全绿零回归。


### 9.57.5 实施记录（v0.26.0——三清单守卫 + audit 标签规约化）

- **TEST-1 runner 装配守卫**：递归枚举 tests/ 下全部 .rs 文件（runner.rs 与 common/mod.rs 豁免）逐一断言其在 runner.rs `#[path = "..."]` 挂载集内（未挂载 = 静默死文件当轮检出）；反向断言每一挂载目标在盘（陈旧挂载检出）。解析器锚定 `#[path =` 开符（doc 注释中 `#[path]` 提及不可误配）。
- **TEST-2 语料表-目录 parity 守卫**：扫描 subset_corpus_tests.rs 全部双引号 .krf 字面量（stem 必需判别式）为表集；目录枚举为目录集；集合全等断言（孤儿文件 = 隔离面滞后 / 幻影条目 = 文件缺失 / 表内重复）。
- **TEST-3 audit 案例注册守卫**：行锚定计数 `// XNN:` / `// XNN (` 整行开题注释（体内断言消息不可配——它们不在行首整行注释位）；逐节断言 == 文档构成（A10+B10+C5+D5+16×10 = 200）+ 总数 200 + 头条字面量 "AUDIT PASS 200/200" 在场。
- **TEST-3b 计数器检测力臂**（r54 检测器三臂先例）：合成夹具七形态（正典冒号/正典括号计入；体内断言串/单位数标签/散文字符串/行中注释/未知节字母拒计）——计数器检测力的非平凡证明。
- **audit 标签规约化（纯注释零行为变更）**：A-C 节 25 条开题注释新增（描述取自助手标签）+ H07 独立注释补标（H06 注释改"first arm"）+ U/V 节单位数标签双位化（U1:→U01: … V9:→V09:）——统一注册规约后行锚定计数 **197→200 精确**（规约化前 199 实标签 + D 节双计口径修正）。
- **测试面**：+4（三守卫 + 检测力臂）→ **1174:0:0**（1170 基线零回归）；audit 复跑 **200/200**（注释面零行为变更实证）。
- **版本面共变族 v0.26.0**：Cargo.toml + Cargo.lock + ds08 版本黄金 + RELEASE_NOTES v0.26.0 + README Status（r54+r55+r56 禁入口径）+ docs/tests/README 测试基础设施自审计族行 + docs/tests/matrix T34 节 + calibration-data T34 行 + roadmap v1.6→v1.7 + stage-2-plan §0 r56 重申三点 + stage0.md v9.22→v9.23（本节 + 头部版本链/文档状态/终态注记族十七→十八条/代码实施轮计数 v9.18/v9.21/v9.22→+v9.23 + 附录 G v23）。


### 9.57.8 收敛口径

8 原语不变性**第三十轮**验证（纯测试树 + 注释面：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF 增量——三守卫纯读树计数零管道执行 + audit 50 处注释规约化零行为变更）；零新外部依赖（§18 DAG 冻结维持——std 内建字符串解析达成，零新 crate）；TD 开放项 0 维持（连续十八轮）；检索质量如实披露（三弱查 + 一主源直读升级 + 一改写重试）；selfhost parity 三件字节全等维持 + 语料 79 维持 + 每轮阻断条款九项复查全绿（第五十六轮）；实施基线 v0.26.0 = 1174:0:0 + audit 200/200（六命令冷跑复验）。下一轮入口 = 阶段间轮继续（用户常设指令维持；审查谱系候选 = 下一横切面路由[测试基础设施元域后待勘察]或既有登记窗信号核对；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。


---



---

## 9.58 crate 职责边界与重复域前沿对照与 Symbol 单池统一实施（第五十七轮 · r57 · Task 35 · v0.27.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.58 勘察基线与节引言


> 开面裁定（35-b）：用户第 r57 轮点名指令——「审查项目中是否存在 crate 之间设计实现之间重叠或表述等不限问题（如当前项目中，kerf-core/ 与 kerf-syntax/ 存在大量相似或一致的内容，这为什么，他不应该出现。并且每一个 crate 之间的职责应该是清晰的边界明确的，请解决此问题后同步检索整个项目是否存在类似的问题并计划修复）」——审查谱系第十字切面（crate 边界元域：前三横切面[诊断/测试基础设施]审查"产物"，本轮审查"产房"——crate 结构本身）；同时为 GitHub 文件仓库历史性可达轮（ba6e243 → v0.26.0 导入对齐——三通道第十七次不可达 streak 终结）与沙箱环境重置轮（工具链重装 1.98.1 + web 仪表盘回退 v0.1.0 全量重同步义务）。


### 9.58.1 方法与证据基

勘察面（期望零猜测第十八轮）：① 10 crate lib.rs 宪章头全量精读（职责声明 + 设计锚引用完整性）；② 用户点名对实证——`kerf-core/src/symbol.rs`（334 行）与 `kerf-syntax/src/symbol.rs`（288 行）归一化 diff（类型名/错误名替换后）：**243 行差异全部位于文档注释层，代码体逐行同构**（同 `struct Interner` + 同 `static INTERNER: OnceLock<Mutex<Interner>>` + 同 `intern()` + 同地板校验 + 同 `NonZeroU32` 载荷 + 同手写 Debug 形状）——确认为结构性孪生而非偶然相似；③ 全项目同类问题系统扫描三法：同名文件族盘点（symbol.rs ×2 / error.rs ×6 / code.rs ×2 / expr.rs ×2 / module.rs ×2 / parity.rs ×2）、逐对职责比对（同名≠同义判别）、孪生测试清点（两 symbol.rs 内 ~14 例拒绝用例逐对孪生 + `InvalidSymbol` 错误变体三处逐字节孪生[reader/syntax/core 各持一份相同 Display 文本——文档自认 byte-identical「单源字典」纪律靠三份拷贝维持]）；④ 身份桥接路径实证——expander 以 `sym.as_str()` 文本桥接再驻留（code.rs/transformer.rs 各 2 处 StxSymbol 构造 + 10 处 as_str 消费），每标识符双池双驻留。


### 9.58.3 crate 边界与重复域逐面审查表（十二面 × 前沿锚 × 裁定）

| # | 审查面 | 勘察事实 | 前沿对照 | 裁定 |
|---|---|---|---|---|
| 1 | crate 宪章声明清晰度 | 10 lib.rs 头全带职责声明 + 设计锚（span/syntax/core 层宪章 + §18.5 DAG 注记） | oxc 基础层四件同名模式 | 维持 |
| 2 | **跨 crate 孪生类型（Symbol/StxSymbol）** | 双驻留器逐行同构（9.58.1②）+ §9.52.4「twin discipline」有意裁定在案 | K78：rustc 单 Symbol 单池，AST 层无孪生 | **★BOUND-1 本轮实施：单池统一落 kerf-span** |
| 3 | 孪生错误变体（InvalidSymbol ×3） | reader/syntax/core 三处同 payload 同 Display 文本拷贝 | rustc 诊断消息单源 | **随 BOUND-1 清偿：wrap + 委托单源** |
| 4 | 孪生测试族（~14 对） | 两 symbol.rs 单测逐对孪生 | expect-test 单源先例（K76） | **随 BOUND-1 合并入 span 统一测试族** |
| 5 | 同名异义文件（code.rs ×2） | expander/CodeValue（宏相位码值）vs typecheck/TypeCode（诊断码注册表）——同名不同义 | — | 登记窗 W-BOUND-NAMING（改名收益 < 搅动成本，P3 观察） |
| 6 | 同域文件职责边界（module.rs/parity.rs ×2） | core/ModuleItem（声明 ADT）vs expander/module（加载器）；driver/parity（契约面）vs runtime/parity（渲染键）——同域不同职责，边界清晰 | — | 维持（正例登记：同名文件跨 crate 合法当且仅当职责正交） |
| 7 | 错误族隔离形态 | error.rs ×6 = per-crate 错误面（CompileError/CoreError/…各辖各域） | rustc per-crate error 诊断码同构 | 维持（正例：错误隔离 ≠ 逻辑重复） |
| 8 | re-export 链纪律 | span→syntax/core→compiler→vm 传递链按 §18.5 无直连边策略（Symbol 现沿链传递） | K78：rustc_ast 等沿链 re-export Symbol 同构 | 维持 + 本轮扩展（SymbolError 入传递面） |
| 9 | DAG 边完整性 | 统一零新增边：syntax/core 均已有 →span 边（K78 同构前提） | oxc/r-a 基座边模式 | 维持（零新边 = 落位裁定的硬约束） |
| 10 | 命名规则族归属 | §21.12「Stx 前缀族[StxDatum, StxSymbol] vs 跨阶段 ID 族[无前缀]」——Symbol 实为跨阶段身份却被归 Stx 族 | K78：rustc_span::Symbol 无前缀 | **本轮修订：Symbol 归位跨阶段 ID 族（§21.12 注记）** |
| 11 | 驻留器生命周期 | process-global OnceLock（§9.52.3 裁定：单进程单会话合法） | K78 会话域差异如实登记 | 维持（差异非缺陷——模型前提不同） |
| 12 | 身份跨层桥接形态 | as_str() 文本桥接 + 双池再驻留（每标识符双份内存 + 二次哈希查找） | K78：跨层共享身份零桥接 | **随 BOUND-1 自然清偿：桥接保留但命中同表（二次驻留 = 池命中非新增）** |


### 9.58.4 技术与缺陷权衡（三反方知情裁定 + 落位四方案权衡）

**§9.52.4「twin discipline」三反方知情修订**（用户指令 = 需求信号本体，原则 44——修订非推翻：v0.23.0 裁定在其前提下的合理性如实存档，前提本身被本轮推翻）：
- 反方 A（层独立性）：「L1/L4 DAG 独立，共享类型违反 §21.12-5 单定义规则的作用域」→ 反驳：**两 crate 均已依赖 kerf-span**（DAG 既有边）；§21.12-5 恰恰要求跨阶段共享类型单定义——Symbol 本是跨阶段身份（surface→core 全程），归入 Stx 族是分类错误，跨阶段 ID 族（Span/FileId/ScopeId 同族）才是正确归属；K78 三前沿同构（rustc/oxc/r-a 身份类型全沉底座）。
- 反方 B（文本桥接安全性）：「地板相同 + 文本桥接 = 安全」→ 反驳：安全但浪费（每标识符双池双驻留双哈希）且身份碎片化（跨层比较必经文本往返）；**§9.52.5 自称「Symbol 身份基座」供 LA-1..LA-7 消费——双池恰是身份基座的自我削弱**（捕获描述符可键于身份的前提 = 身份跨层稳定）；单池后 LA 输入面直接增益。
- 反方 C（池隔离纪律）：「各层各池，索引永不互通 = 纪律」→ 反驳：索引互通恰是 rustc 全局形态（K78）；池隔离无消费者（两池从不互比索引）、无收益（内存翻倍）、无前沿先例。

**落位四方案权衡**（引入技术是否同时引入缺陷——四方案全评）：
- (a) 新 crate kerf-symbol：+1 crate +2 边；rustc/oxc/r-a 三前沿在此规模下均无独立 symbol crate（oxc_str 为规模分化形态——oxc 数十 crate vs kerf 10 crate）——**否决**（§18 最小边 + 前沿分歧）。
- (b) Symbol 留 kerf-core，syntax 反向依赖 core：逆转管道 DAG（L1→L4）——**违宪否决**（§18.5）。
- (c) 双池保留 + 验证逻辑 trait 共享：共享校验不共享身份——复杂性增益零身份增益——**否决**。
- (d) **落 kerf-span（采纳）**：K78 精确先例（rustc_span::Symbol）；零新边（前提边已在）；单池单身份；缺陷面评估——①跨层索引语义翻转：全树无跨池索引比较消费者（rg 实证）②池容量 2^32-1 单池共享（实践无限）③re-export 歧义：kerf_syntax::Symbol == kerf_core::Symbol == kerf_span::Symbol 同一类型 = 设计目标本身（rustc 同构）④§9.52.4 文档失效：本节显式修订 + §9.52 增补修订注记。


### 9.58.5 实施记录（v0.27.0——Symbol 单池统一）

- **kerf-span 新增 symbol.rs（403 行）**：Symbol + SymbolError（`InvalidSymbol { text }` 唯一正典 Display 源）+ Interner + intern() + 地板校验 + **合并测试族 20 例**（两孪生族去重合并 + 新增「Display 与统一前文本逐字节一致」锁 + trailing-space 补例）；lib.rs 宪章修订「source positions and cross-stage symbol identity」。
- **kerf-syntax**：symbol.rs 删除（288 行孪生退役）；`StxSymbol` → `kerf_span::Symbol`（StxDatum::Symbol(Symbol) 字段 + SyntaxObject::symbol 构造器）；SyntaxError::InvalidSymbol 改 wrap(SymbolError) + From + Display 委托；lib.rs re-export 面扩展（Symbol/SymbolError）+ §21.12 命名注记更新。
- **kerf-core**：symbol.rs 删除（334 行孪生退役）；lib.rs `pub use kerf_span::{Symbol, SymbolError}`（下游 typecheck/compiler/vm/runtime 导入路径零变更——re-export 兼容层）；CoreError::InvalidSymbol 改 wrap + From + 委托；expr.rs/module.rs 构造器 `?` 经 From 自动桥接 + 测试断言形态更新。
- **kerf-reader**：ReadError::InvalidSymbol 改 wrap + Display 委托（第三份文本拷贝消除）；lexer 错误路径 `Err(err) => Err(ReadError::InvalidSymbol(err))` **实际错误透传**（原 `Err(_)` 丢弃载荷——顺带修复）。
- **kerf-expander**：code.rs/transformer.rs StxSymbol → Symbol（经 kerf_syntax re-export）；文本桥接保留但二次驻留变为同池命中。
- **kerf-compiler**：SymbolError 入 consumer-face 完整性传递面（vm/runtime/driver 导入路径沿链零新边）。
- **根树**：symbol_intern_tests.rs **+2 集成断言**——`same_text_is_one_identity_across_the_syntax_and_core_faces`（syntax 面与 core 面构造同文本 = 同一 Symbol：等值 + 同尺寸 + 同哈希 + 异文本相异——**单池身份语义的管道级锁定**）+ `syntax_and_core_error_faces_share_one_rendering_source`（三错误面同文本同渲染——单源字典从三拷贝主张升为机检事实）；ds08 版本黄金 0.27.0。
- **量化账目**：代码面 24 文件 +369/−453（**净 −84：删除的重复超过新增基座**）；孪生测试合并 1174→1163 → +2 集成 = **1165:0:0**（去重为合法净减，非测试削弱——孪生 14 对去重后保留全语义覆盖）；audit **200/200**；fmt 零 diff；clippy -D warnings 0（实施期 1 告警[driver 未用导入]当轮清偿）；build/check 0/0。selfhost 三件 116/741/558 零触碰（.krf 侧无 Symbol 类型引用）；8 原语不变性**第三十一轮**验证（纯 Rust 侧类型归位：零新原语/零通道/零 VM 变更/零语法增量/零 EBNF——Symbol 载荷与地板全不变，仅池归一）。
- **worklog 镜像漂移修复**：root worklog.md 停在 T31 而 docs/worklog.md 至 T34（包树态漂移如实登记）——以 docs 版为内容基准回修 root（内容零损失），镜像不变量恢复。


### 9.58.8 收敛口径

8 原语不变性第三十一轮验证（纯 Rust 侧类型归位：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF——池归一不改载荷不改地板不改渲染）；零新外部依赖（§18 DAG 冻结维持——kerf-span 仍零依赖 crate，Symbol 以 std 内建达成）；TD 开放项 0 维持（连续十九轮）；孪生消除度量：workspace 内 `struct Interner` 恰 1 处（kerf-span）、`StxSymbol` 引用清零、`invalid symbol` Display 文本源恰 1 处；检索质量如实披露（两弱查降档 + 两主源直读升级 + 三强锚）；selfhost parity 三件维持 + 语料 79 维持 + 每轮阻断条款九项复查全绿（第五十七轮——含三通道历史性转变项：GitHub 文件仓库 ba6e243 首次可达对齐）；实施基线 v0.27.0 = 1165:0:0 + audit 200/200（六命令冷跑复验）。下一轮入口 = 阶段间轮继续（用户常设指令维持；crate 边界域后续 = W-BOUND-SCOPE/W-BOUND-NAMING 两窗信号核对；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。

---



---

## 9.59 re-export/转发域前沿对照与基座直连政策实施（第五十八轮 · r58 · Task 36 · v0.28.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.59 勘察基线与节引言


> 开面裁定（36-b）：用户 r58 精化指令——「每一个 crate 应该只导出自己 crate 中设计实现的内容，不应该转发或再次导出其他 crate 中的内容，如果其他的 crate 需要应当从设计实现这些导出内容的 crate 中获取（当前项目中 kerf-core/ 中仍存在此类问题，并审查整个项目中所有导入导出是否标准合理）」——§9.58 域的直接续轮：单池统一清偿了「双定义」，本轮清偿「多路径可达」（同一类型经转发链存在第二/第三可达面）；同时触发 **SOP §3.3 演进提案首次行使**（§18.5 DAG 边政策修订 v15.1→v15.2——转发链的制度性根源）。


### 9.59.1 方法与证据基

勘察面（期望零猜测第十九轮）：① 全树转发清单 `rg "pub use kerf_"`——**13 行跨 crate 转发分布于 7 crate**（core ×2 块 6 名 / syntax ×1 块 4 名 / compiler ×2 块 10 名 / reader ×1 块 2 名 / runtime ×1 块 4 名 / driver ×1 块 3 名 / expander ×1 名）+ 根聚合 crate 10 行 crate 级别名（§8.4.6 豁免位候选）；② 转发根源考古——各 Cargo.toml 历史注释自证：转发链非便利设计而是 **§18.5「无直连边」政策的结构性产物**（「types flow through the kerf-compiler re-exports (SOP §18.5 — no direct production edge L4 -> L6)」「kerf-span stays a dev-dependency here only」——边最小化政策迫使类型经中间 crate 中转）；③ 消费面全量映射——管道 crate 混合导入 ~20 站点 + crate 内 api_tests ×6 + 根树/示例 ~15 站点 + reader lib.rs 内部消费 1 处 + expander ctx.rs 全限定路径 2 处 + driver reader_parity/expander_parity 混合导入 2 处；④ 根聚合 crate（src/lib.rs）定性——crate 级别名聚合 = §8.4.6 规则 7 的设计内容本体（`pub use kerf_span as span`），与类型级转发（`pub use kerf_x::Type`）本质不同。


### 9.59.3 转发域逐面审查表（十二面 × 前沿锚 × 裁定）

| # | 审查面 | 勘察事实 | 前沿对照 | 裁定 |
|---|---|---|---|---|
| 1 | kerf-core 转发（用户点名） | Symbol/SymbolError/ByteOffset/ExpansionId/FileId/Span 六名再导出 | K81：rustc_ast 零转发 | **★FWD-1 本轮退役** |
| 2 | kerf-syntax 转发 | ExpansionId/Span/Symbol/SymbolError 四名 | K81/K82 | **退役** |
| 3 | kerf-compiler 转发 | ModuleItem + 十名大块（含 Binding/CoreExpr/HandlerClause 名义性补全） | K81/K82 | **退役** |
| 4 | kerf-reader 转发 | ByteOffset/FileId 两名（零外部消费者） | — | **退役**（死转发顺带清偿） |
| 5 | kerf-runtime 转发 | ByteOffset/ExpansionId/FileId/Span 四名（经 compiler 二级转发） | — | **退役** |
| 6 | kerf-driver 转发 | ByteOffset/FileId/Span 三名（经 compiler 二级转发） | — | **退役** |
| 7 | kerf-expander 转发 | CoreError 一名（1.6 nameability 补全先例第四例） | — | **退役**（消费面 driver 切直连） |
| 8 | 根聚合 crate（src/lib.rs） | 10 行 crate 级别名（`as` 形态） | K83 门面清场后形态 | **两级豁免**：crate 级别名合法（聚合 = 设计内容本体）、类型级转发禁止 |
| 9 | DAG 边政策（制度根源） | §18.5「无直连边」迫使转发（Cargo 注释自证） | K81/K82：rustc/oxc 基座边遍布 | **SOP §3.3 修订 v15.2：基座直连政策**（边数非复杂度指标——转发链 = 伪装边） |
| 10 | dev/prod 依赖面 | compiler/expander 的 span 为 dev；vm 的 core 为 dev | — | **升格**：生产消费面据实升 prod（5 个 Cargo.toml 修订） |
| 11 | 类型可达路径唯一性 | 同一类型多路径可达（span::Span ≡ core::Span ≡ compiler::Span） | rustc：单路径 | **随退役自然清偿**（唯一可达 = 定义 crate） |
| 12 | 守护机制 | 无（转发回归无防线） | TEST-1/2/3 先例（T34） | **TEST-4 转发守卫**（crates/ 零转发机检 + 根 facade 两级守护 + 检测力臂） |


### 9.59.4 技术与缺陷权衡（三反方知情裁定 + 政策权衡）

**反方 A（消费面完整性传递先例——plan-0.5 决策 14 / plan-0.6 决策 1 / plan-0.8 决策 5 / 1.5-b/1.6 nameability 四例）**：「下游经中间 crate 取型 = 零新 DAG 边的成熟先例」→ 反驳：**零新边是伪经济**——类型在边上流动的事实不变，只是把边伪装成 re-export；可读性代价真实（类型来源三重歧义：span::Span ≡ core::Span ≡ compiler::Span）；前沿零先例（K81/K82 直依赖遍布 + K83 门面清场）。四例历史裁定作为演进史保留（dataflow.md 注记），其目标被 v15.2 裁定推翻。
**反方 B（下游改动面）**：「直接导入 = 全下游 import 手术，搅动 ~40 站点」→ 反驳：一次性机械成本（python 脚本批量 + cargo check 迭代收敛 8 轮），换取永久性结构清晰；且手术面恰是转发的真实依赖账本首次显形。
**反方 C（聚合 crate 一并取缔）**：「根 src/lib.rs 也是转发」→ 反驳：crate 级别名与类型级转发本质不同（前者 = 命名空间聚合，无类型归属歧义；后者 = 归属伪装）；K83 门面清场后的 rustc_middle 形态即私有化而非消灭；两级制豁免 + TEST-4 两级守护收窄（类型级转发在根 crate 同禁）。

**政策四方案权衡**：(a) 维持转发链——违用户指令 + 前沿零先例——否决；(b) 新门面 crate 统一取型——以新转发替代旧转发——否决；(c) 全取缔含根聚合——测试树 ~200 站点搅动无归属收益——否决；(d) **基座直连 + 两级豁免 + TEST-4 守卫（采纳）**——K81/K82 精确同构 + SOP v15.2 制度化 + 机检防回归。


### 9.59.5 实施记录（v0.28.0——转发退役 + 基座直连）

- **7 crate 转发退役**：13 行 `pub use kerf_*` 全删 + 各 lib.rs 宪章注释重写（旧「consumers must not depend on kerf-span directly」理由链整体翻转——新注释引 §9.59/K81/v15.2）。
- **导入手术 ~40 站点**：管道 crate（typecheck ×3 / compiler ×4 含 verify.rs 全限定 ×3 / reader ×2 / expander ×6 含 ctx.rs ×3 / vm ×8 / runtime ×1 / driver ×7）+ crate api_tests ×7 + 根树/示例 ×8——全部切换为定义 crate 直连（`kerf_span::{Span, Symbol, ...}` / `kerf_core::{CoreExpr, ModuleItem, ...}`）。
- **Cargo 依赖面 ×5 修订**：compiler（span dev→prod）/ expander（span dev→prod）/ vm（core dev→prod + span 新 prod）/ runtime（span 新 prod）/ driver（core + span 新 prod）——**实施期一处自纠如实登记**：expander 首版编辑漏写 kerf-span 依赖行本体（只写注释），cargo build 立即暴露 → 当轮补写。
- **SOP §3.3 演进提案首次行使（v15.1→v15.2）**：Version 头 + §18.5 五条基座直连政策（零转发/唯一可达路径/两级豁免/边数非复杂度指标/教训来源）+ DAG 图全面修订（+typecheck L4.5 节点 + span 九消费直连边 + core 后端直连边——诚实全边投影）+ §16.1 changelog 行 + 尾部遗留「v15.2」子附录标题消歧（v15.0-附录2 重标，内容零变更）。
- **graph/dataflow.md 同步**：边表 +v0.28.0 九条基座直连边 + 历史裁定注记重写（转发时代终结段）。
- **TEST-4 三件守卫**（tests/v1/stage1/plan/test_infra_guard_tests.rs +3）：`pipeline_crates_forward_nothing_from_other_crates`（crates/ 全树扫描零转发 + ≥10 crate 覆盖断言）+ `root_facade_aliases_whole_crates_but_forwards_no_types`（两级制：`as` 别名合法 / `::` 路径转发禁止）+ `forwarding_detector_detects_and_spares_correctly`（检测力臂七正五负夹具）——**开发期真阳性实录**：检测力臂首跑捕获自身夹具错误（crate 级别名误列豁免清单——探测器正确标记、夹具错误），沿 T34 TEST-2 先例如实登记。
- **量化账目**：28 文件改动（7 lib.rs + 21 下游/测试/示例）+ 5 Cargo.toml + SOP + dataflow + 守卫文件；测试 1165 → **1168:0:0**（+3 TEST-4）；audit **200/200**；fmt 零 diff（1 处长行自纠如实登记）；clippy -D warnings 0（实施期 1 告警[driver 未用 Bytecode 导入]当轮清偿）；R8 编码面清零（新增注释全英文）。
- **8 原语不变性第三十二轮验证**（纯 Rust 侧依赖面手术：零新原语/零通道/零 VM 变更/零语法增量/零 EBNF——全部变更限于 use 路径与 Cargo 清单，语义零变化[测试期望零改动即实证]）；selfhost 三件 116/741/558 零触碰；TD 开放项 0 维持（连续二十轮）。


### 9.59.8 收敛口径

8 原语不变性第三十二轮验证（依赖面手术零语义变化）；零新外部依赖（§18 外部依赖面零触碰——proptest dev 位维持唯一外部项）；转发清零度量：`crates/` 内 `pub use kerf_*` = **0**（rg 复核 + TEST-4 机检双锚）、根 facade 类型级转发 = 0（两级守护）、类型可达路径唯一（span::Span 族歧义清零）；检索质量如实披露（两弱查降档 + 三主源直读）；TD 开放项 0 维持（连续二十轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款九项复查全绿（第五十八轮）；实施基线 v0.28.0 = 1168:0:0 + audit 200/200（六命令冷跑复验）。下一轮入口 = 阶段间轮继续（用户常设指令维持；crate 边界域两步清偿完毕，后续 = W-BOUND-SCOPE/NAMING 信号核对或新横切面路由；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.60 驱动编排与错误传播域前沿对照与 globals 名单双契约裁定（第五十九轮 · r59 · Task 37 · v0.29.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.60 勘察基线与节引言


管道审查谱系第十八段：前十七段（§9.43-§9.59）覆盖了十二管道阶段的逐层数据结构、自举三段、后端四行、检查器、驻留、内存、确定性、诊断、测试基础设施、crate 边界两步——**驱动器编排面本身**（pipeline.rs = 全管道粘合剂 + 行动项四锚 typecheck() ×4 的宿主）与**错误传播策略**（四层返回形态的分层依据）从未专审。本轮开面即补此缺口：编排拓扑 / 错误传播四层形态 / 恢复谱系定位 / Session 生命周期 / 产物结构族五面合成一域。


### 9.60.1 域定位与勘察面（期望零猜测第二十轮）

逐行探针实录（勘察基线 v0.28.0 @ 0e0bff1）：kerf-driver/src/pipeline.rs 798 行全量精读（编排函数族 parse/typecheck/check/run/run_parity + 产物结构族 ParsedProgram/CheckOutcome/RunOutcome/ParityReport + split_warnings 分级路由 + pipeline_externals）；session.rs 181 行（intern/file_name/source/line_index/knows 七面）；cli.rs 消费面（report → render_diagnostics 全批渲染 + exit 0/1）；repl.rs 消费面；四层错误形态签名精读——read_program: `Result<Vec<SyntaxObject>, ReadError>`（单错误 fail-fast）/ expand_program + load_program: `Result<_, ExpandError|ModuleError>`（单错误 fail-fast）/ check_module: `Vec<TypeDiagnostic>`（批量全收集）+ infer_module: `InferOutcome`（含批量诊断）/ compile_program: `Result<Bytecode, CompileError>`（单错误 fail-fast）/ vm.run + evaluator.eval_program: `Result<Value, _>`（单错误 fail-fast）；compile.rs:238 globals 收集逻辑（编译遍历序 push——与 items Define 程序序语义等值但结构两源）；测试守护面（pipeline 25 + cli 23 + session 6 = 54 测试）。**核心发现**：① 四层错误传播形态不对称（单错误 vs 批量）无单源成文裁定——ruling 21 只覆盖 typecheck 层，分层依据散落于三处注释；② `run()` 的全局名单提取三处两源（VM 分支 = bc.globals[编译器产物] vs Eval 分支 = items[AST] vs run_parity 循环 = items[AST]）——初判单一可信数据源缺口（后经 §9.60.5 否决实录修正为双契约——勘察首 pass 未审计 intern_global 五调用点全路径）；③ split_warnings 全有全无语义（任一 Error → 整批含 warnings 进 Err）命名与行为有读解歧义但消费面正确（report 全渲染，warnings 不丢失）。


### 9.60.3 错误传播四层形态与恢复谱系定位裁定（本轮核心裁定 ERR-PROP）

**四层形态实况表**（勘察实证，非设计主张）：

| 层 | 返回形态 | 策略 | 分层依据（本轮成文） |
|---|---|---|---|
| reader（read_program） | `Result<_, ReadError>` 单错误 | fail-fast | 语法层产物完整性前提（K86 panicking 位三柱） |
| expander（expand_program/load_program） | `Result<_, ExpandError/ModuleError>` 单错误 | fail-fast | 展开依赖完整语法树；模块图验证单失败即图破损 |
| typecheck（check_module/infer_module） | `Vec<TypeDiagnostic>` / `InferOutcome` 批量 | 全收集（ruling 21） | 静态诊断学价值（一次运行看全部问题）+ 无副作用纯分析 |
| compiler（compile_program） | `Result<Bytecode, CompileError>` 单错误 | fail-fast | 后端假设前段全通过；部分编译产物无消费面 |
| runtime（vm.run/eval_program） | `Result<Value, _>` 单错误 | fail-fast | 副作用不可回滚（I/O 已发生） |

**驱动层合成策略**（pipeline.rs 实况）：`parse` 三段串联任一 Err → `vec![单 Diagnostic]`（批形态单元素——类型统一 Vec<Diagnostic> 但前段只装一个）；`typecheck()` 方法 = check 批 extend infer 批（多错误合流）；`check` = typecheck 批 + compile 错误 **push 追加**（「collection never short-circuits」——无副作用阶段继续收集：compile 是纯函数，typecheck 失败后仍尝试编译以追加更多发现）；`run` = typecheck Error → **abort**（「Error-level findings abort before either engine starts」——有副作用阶段前停机：引擎执行不可回滚，不启动即无副作用）；`split_warnings` = 全有全无分级路由（任一 Error → 整批含 warnings 进 Err 载荷；消费面 report 全渲染——Err 载荷语义 = 「本批全部诊断」而非「仅错误」，warnings 不丢失）。

**裁定 ERR-PROP（四层不对称 = 分层设计而非漂移）**：单错误层（语法/编译/运行时）与批量层（静态检查）的不对称是**阶段性质的函数**而非历史漂移——产物完整性前提层（后续阶段依赖前段完整产物）fail-fast，纯分析层（无副作用、诊断价值随数量增长）全收集；check 与 run 对 typecheck Error 的差异化后续（check 继续 compile 收集 vs run abort）同样由副作用性质决定。此裁定此前散落于三处函数注释（ruling 21 仅 typecheck 层 + check 注释 + run 注释），本轮 §9.60.3 单源成文（§2.3-2 单一可信数据源——裁定的文档面）。


### 9.60.4 编排拓扑与产物结构族裁定（ORCH-TOPO）

- **拓扑面**：parse（intern→read→expand→load 四段）→ typecheck（check+infer 双层合流）→ 三出口（check: +compile+verify 无执行 / run: +compile+单引擎执行 / run_parity: +compile+双引擎执行+结构比较）。对照 K84：kerf 硬编码序列 vs rustc Callbacks 钩子——**形态合法**（消费面规模论证见 9.60.2 K84 段；三出口 = kerf 三消费面 CLI/REPL/parity 的精确投影，无抽象税）。
- **产物结构族**：四结构（ParsedProgram/CheckOutcome/RunOutcome/ParityReport）全部内嵌 `warnings: Vec<Diagnostic>` 字段——**一致性好**（warnings 骑行于产物 = 消费面零特判）；对照 rustc DiagCtxt 单独传递形态——kerf 简化合法（诊断量级 10^1 vs 10^3+；无 emit 去重/延迟/翻译需求）。
- **parity 编排**：divergence 报告不 panic + 引擎句柄存活到比较完成（堆解析前提——320-324 行成文注释在案）——维持。
- **pipeline_externals 重建**：每次 typecheck() 调用重建 Externals——静态表构造，成本可忽略（P4 观察，零修复）。


### 9.60.5 ★ORCH-1 globals 名单裁定：双契约（勘察假设被测试网否决实录）

**初判（后被否决）**：勘察首 pass 发现 `run()` 的全局名单提取三处两源——VM 分支 `bc.globals`（编译器产物）vs Eval 分支 `self.items` Define 遍历（AST）vs `run_parity()` 循环同样遍历 `self.items`——初判为单一可信数据源缺口（§2.3-2），遂实施「三处统一 items 单源 + bc.globals == Define 序列等值守卫」。

**否决实录（期望零猜测纪律的实弹教训——第二十轮首例否决）**：守卫 + 单源化落地后全量测试 **vs01-vs10 十测试失败**（`assert_eq!(globals, "+=#<builtin:+> r=3")` 族）——金色面证明 `bc.globals` ≠ items Define 序列投影。全量重审计 `intern_global`（compile.rs:234）**五调用点**：L341 `LoadGlobal`（任何全局引用——内建 `+`/`fib` 等引用名在此注册）+ L405 `StoreGlobal`（set! 目标）+ L429 `Perform`（效应名）+ L444 `PushHandler`（handler 效应名）+ L491 Define（唯一与 items 对应项）。**真值**：`bc.globals` = **全局名字表**（首次使用序：内建引用名 + set! 目标 + 效应名 + Define 名）——勘察首 pass 只看 L491 一处 push 即断言等值，未审计全部注册路径（§12 不凑数的反面：凑结论）。

**修正后裁定（双契约非双源）**：三处名单实为**三个不同语义契约**，各归其位均正确——① VM 分支 `bc.globals` = **全局表观测契约**（vs01-vs10 金色面固化：快照报告字节码可达的一切全局名，含内建 `+=#<builtin:+>` 形态——回滚恢复，原双分支形态即正确）；② Eval 分支 items 遍历 = **Define 名单契约**（ve01-ve02 点查询消费面——`outcome.global("r")` 不依赖快照完整性）；③ `run_parity` items 循环 = **parity 比较契约**（双引擎同一 Define 名单上比较——正确）。**非单一可信数据源违规**：全局表观测与用户定义名单是两个语义面，各有其第一性来源（字节码名字表 vs AST Define 序列）。

**实施终态（内循环修正后）**：pipeline.rs `run()` 恢复双契约原形态 + **契约注释成文**（「two engine branches snapshot different rosters **by contract, not by drift**」——散落形态 → 单源注释锚定本节）+ **守卫改写为真不变量**（`global_table_reaches_every_define_and_referenced_builtin`：纯 Define 程序表 == Define 序列精确[alpha/beta] + vs01 形态程序表 == ["+", "r"][内建引用名入表实证] + Require/DefineSyntax 不入表）——投影语义从错误等值断言改正确名字表语义机检。**净效果**：+1 守卫测试 + 1 契约注释，零行为变化（vs 金色面零改动复绿）；「审查发现落地」第三形态（裁定成文型）的首例**否决-修正回路**实录（T32 属性测试化 / T36 政策修订 / 本轮 = 裁定成文 + 假设否决修正）。


### 9.60.8 收敛口径

8 原语不变性第三十三轮验证（驱动层编排 + 双契约裁定成文：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF——零行为变化[vs 金色面零改动复绿实证]）；零新外部依赖；检索质量如实披露（两弱查降档 + 四主源直读[K84/K85/K86/K87] + 检索存档 tool-results/r59-search/ 九文件实体入库[q1-q4 四检索 json + m1-m4 四主源文本 + README]——404 探测残留清理后 52K 精简）；TD 开放项 0 维持（连续二十一轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款九项复查全绿（第五十九轮）；实施基线 v0.29.0 = 六命令全绿 + audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = 新横切面路由或登记窗信号核对；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。





---

## 9.61 性能工程与基准方法学域前沿对照与规则 5 失察修复（第六十轮 · r60 · Task 38 · v0.30.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

### 9.61.1 域定位与勘察面（期望零猜测第二十一轮）

- **域定位**：审查谱系第十九段——§9.44-§9.60 十八段覆盖了每一管道阶段、自举三段、内存、确定性、诊断、测试基础设施、crate 边界、转发、驱动编排，但**测量方法学本身**（§9.44.3 量化切换触发器最终诉求的实证面、§14.6.4 性能基线的产生机制）从未入审。路由 = 谱系缺口识别第三例（§9.57 元域先例 → §9.60.8 尾候选「新横切面路由或登记窗信号核对」→ 十八窗全零信号 → 缺口分析定性能工程域）。
- **勘察四件**（代码实证基线 v0.29.0 @ 30c9286）：① examples/bench/stage0_baseline.rs 217 行全量精读（五轴测量区边界 + 消费面位置 + 计数器模式）② performance-baseline.md 全文（首录口径 + §4 规则 5 义务文）③ §9.44.3 十二行表 + §9.44.5 触发器总表（可观测性映射输入）④ worklog B 系列轨迹考古（末次实测记录 = T29 v0.23.0[B1 7.7µs / B2 87.6ms / B3 10.4ms]——此后十轮零记录）。
- **勘察三缺口实证**：① 全码库零 `black_box`（rg 全树清零——测量区无优化器栅栏；K90 语义缺失）② 零预热段 + 双统计量（mean/median——无 min/stdev 离群可见面）③ benchmarks/README.md 主张「crate 微基准入各 crate benches/」而零 crate 有 benches/（未兑现承诺——docs-reality 差距）。
- **★PERF-F（规则 5 失察）**：§14.6.4 规则 5 触发面为「涉及 VM/编译器/驱动/GC 的代码变更」——T33（诊断位置 36 站点）与 T35（Symbol 表示置换——§9.44.3 第 1 行族明示 B 系列相关性）均触碰编译链生产面而未重跑；performance-baseline.md 停留首录值（B1 9.3µs）与 worklog T29 实测（7.7µs）漂移——**性能域自身的 docs-code 单源失守**（irony 如实登记：最讲单源的项目在测量域失了单源）。


### 9.61.3 勘察缺口 × 前沿锚 × 裁定（十二面审查表）

| # | 审查面 | 现状（v0.29.0 勘察） | 前沿锚 | 裁定 |
|---|--------|---------------------|--------|------|
| 1 | 优化器栅栏 | 零 black_box；测量区依赖偶然不透明（跨 crate 编译单元 + 无 LTO） | K90 | **实施**（PERF-1）：五轴输入全栅栏 + best-effort 局限成文；潜在风险场景 = 未来启用 LTO 时整链可折叠——栅栏前置即防患 |
| 2 | 预热 | 无；首迭代冷缓存/首触缺页入样 | K89 族纪律 | **实施**（PERF-2）：warmup = max(3, iters/10) 不入样 |
| 3 | 统计量 | mean/median 双统计量 | K89（统计置信） | **实施**（PERF-2）：四统计量 mean/median/min/stdev；median 主判据维持（±25% 带口径不变）；stdev/min = 离群可见面（B5 stdev 9.5ms 峰值离群实录即首轮产物） |
| 4 | 阶段归因 | B1 复合单值——§9.44.5 触发器（行 1② 「热点定位于符号分配/比较」）不可观测 | K88（分族采集） | **实施**（PERF-3）：B1a/B1b/B1c 子轴拆分（read 1.4µs / expand 3.5µs / compile+verify 1.5µs）；复合值保留承担历史可比性；子轴物理注记成文（子轴和 < 复合——单阶段缓存更热，两口径并行不互推） |
| 5 | 确定性计数面 | B4 gc-cycles/swept 已有（bench 内）但无守卫 | K91 | **实施**（PERF-4 附带）：守卫测试 b4_churn_counters_exact_per_run——逐 run 精确值 1/1023 × 三独立 run（比 bench 聚合除法严格强——聚合可掩盖 per-run 漂移） |
| 6 | 规则 5 义务 | 触发面「VM/编译器/驱动/GC 变更」；十轮失察（T33/T35 触碰未重跑） | ——（治理面） | **实施**（PERF-4）：重录验证零隐藏回归（B1 7.7µs 与 T29 实测精确一致 / B4 计数与首录逐位一致——失察未藏回归是运气非功绩，如实登记）+ 触发面扩充（表示层变更入触发——§9.44.3 第 1 行族）+ 九项复查增设第 ⑩ 项 + performance-baseline §4 强化 |
| 7 | 工具链依赖 | 零外部依赖；criterion 族 = 潜在首依赖 | K89 | **裁定维持 std-only**（PERF-5）：black_box 是 std；栅栏/预热/报告需求零依赖满足；criterion 引入 = 宪制级变更（§18 首例外）——W-PERF-CRITERION 逃生窗登记（触发 = ±25% 带被证伪 ≥2 次于真实回归判定） |
| 8 | crate 微基准 | benchmarks/README 承诺「入各 crate benches/」——零实现 | K88（分族先例） | **登记退役**（PERF-6）：承诺转 W-PERF-CRATE-BENCH 窗（触发 = 子轴归因显示 crate 内热点而 B 系列无法刻画）；R2 精神——功能缺失登记不空承诺 |
| 9 | 基线记录面 | performance-baseline.md 首录值与 worklog 实测漂移 | §8.4.5（单源） | **实施**：方法学 v2 全表重录（四统计量 + 子轴行 + 环境双列 + 历史首录保留层 + 子轴物理注记）——有意方法学变更 = 文档化再基线（沿 T33 金色再基线纪律） |
| 10 | 基线数值口径 | µs/ms 双单位混轴 | —— | **实施**（开发期自纠）：轴感知双格式化器（line_stats_us/line_stats_ms）——harness 重写首跑 µs/ms 错标（B2 显示 87.2µs）当轮自纠实录 |
| 11 | harness 守卫 | 方法学的退化无 tripwire | §9.57 守卫族先例 | **实施**：bench_harness_methodology_present 源守卫（black_box ≥14 / warmup ≥6 / stdev ≥6 / B1a/b/c 三标签——读数计数族同型） |
| 12 | 与 §9.44 触发器表的对账 | 行 1② 现可经 B1b 观察符号面；行 2「GC churn 热点前三」经 B4+守卫；行 7 dispatch 热点前三仍无 profiler | 本表 #4/#7 | **部分实施 + 窗登记**：W-PERF-PROFILE（profiler 集成窗——触发 = 子轴归因不足以定位真实回归；函数级热点仍零信号）；§9.44.5 表注记增补 |


### 9.61.4 技术与缺陷权衡（知情裁定）

- **PERF-5 主裁定（criterion vs std-only）**：正方（criterion）= 统计置信工业化（bootstrap 斜率检测 + 离群分类 + 图表面）；反方 = 首外部依赖（§18 零依赖纪律自 Stage 0.0 冷启动以来从未破例——dev-dependency 亦入依赖面）+ 构建面膨胀 + 本项目体量（五轴小 harness）远低于其设计负载。裁定：std-only + 纪律移植（预热/多统计量/栅栏——K89 的方法不依赖 K89 的库）。缺陷面如实登记：失去 bootstrap 斜率检测与跨运行噪声模型——±25% 带宽粗判 + stdev 可见面为替代物，若两次证伪即开 W-PERF-CRITERION 窗重裁。
- **子轴拆分的测量物理**：子轴和 < 复合值（1.4+3.5+1.5=6.4 < 7.7µs）——单阶段循环缓存更热，属周知测量物理非缺陷；裁定 = 双口径并行报告 + 禁互推（复合值承担跨版本可比性——所有历史记录都是复合口径；子轴值承担归因——仅 v2 起有记录）。
- **规则 5 义务的治理面**：失察根因 = 义务承载于 performance-baseline.md §4（被动文档）而无任何机械提醒/守卫——「验证义务本身也需要守卫」元教训（与 §9.57「验证者自身未受审查」同族）；修复 = 四件套（重录 + 触发面扩充 + 第 ⑩ 复查项 + 守卫锚定），拒绝「下次注意」式承诺修复。


### 9.61.5 实施记录（v0.30.0 · 十四文件修改 + 检索存档）

examples/bench/stage0_baseline.rs 方法 v2 重写（栅栏/预热/四统计量/子轴——工作负载源串与 HEAD 逐字节一致实证）+ tests/v1/stage1/plan/perf_observability_guard_tests.rs（+2 守卫）+ tests/runner.rs（挂载）+ benchmarks/README.md（docs-reality 修复）+ performance-baseline.md（v2 重录全表 + §4 强化）+ Cargo.toml/lock 0.30.0 + ds08 版本黄金（0.30.0——历史链 +1）+ RELEASE_NOTES v0.30.0 + README Status（r60 口径）+ docs/tests/README + matrix T38 行 + calibration-data T38 行（含单位错标自纠实录）+ roadmap v2.0→v2.1（版本链/设计依据 v9.27/状态行/§6 T38 条目/推进序列五点）+ stage-2-plan §0 r60 重申三点 + stage0.md v9.26→v9.27（本节 + 附录 G v27 + 头部两处）+ tool-results/r60-search/（q1-q6 + m1-m4 + README 十一文件）。


### 9.61.8 收敛口径

8 原语不变性第三十四轮验证（测量方法学域：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF——工作负载源串逐字节一致 + 全量 1171:0:0 + audit 200/200 双绿）；零新外部依赖（black_box = std）；检索质量如实披露（五弱查垃圾第七轮 + 主源直读四锚 + 死链清理三处——存档 tool-results/r60-search/ 十一文件实体入库）；TD 开放项 0 维持（连续二十二轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款九项复查全绿（第六十轮——含新设第 ⑩ 项首跑）；实施基线 v0.30.0 = 六命令全绿 + audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = 新横切面路由或登记窗信号核对；测量方法学已入审——候选 = 剩余未审横切缺口或元域再审计；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.62 用户交互表面域前沿对照与 REPL/CLI 语义统一（第六十一轮 · r61 · Task 39 · v0.31.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

### 9.62.1 域定位与勘察面（期望零猜测第二十二轮）

**选域依据**：管道十二阶段专段谱系闭合（§9.60）+ 测量方法学入审（§9.61）后，**用户交互表面域 = 谱系中唯一以「消费面」身份被旁审而从未主审的实代码域**——`cli.rs` 753 行 + `repl.rs` 559 行 + `render.rs` 431 行 + `main.rs` 44 行（共 1787 行；§9.56 诊断域审的是 diagnostic.rs/line_index.rs 结构面，§9.60 驱动域审的是 pipeline.rs 编排面，三文件从未有专段）。用户表面是「用户实际接触编译器的层」——CLI 参数契约、REPL 会话语义、诊断渲染形态。

**勘察面**（全量精读）：cli.rs（手写参数解析 + 依赖注入 I/O + 退出码 0/1/2 + usage 文本 + 21 测试）/ repl.rs（会话重放状态机：probe-read 前缀累积 + `$repl:N` 表达式包裹 + 前缀增量输出/警告 + 事务回滚 + TapeIo 确定性输入带 + 18 测试）/ render.rs（rustc 风格渲染：`error[code]: msg` + `--> file:line:col` + gutter 宽度 + excerpt + caret run + 字符计列 + 批量摘要行 + 16 测试）/ main.rs（stdin 预读门控 + 终端检测）。交叉锚：`ReadError` 十变体族谱（error.rs 25-70）、expander 顶层分派表（expand.rs 558-582）、`with_options` 消费者普查（零外部消费者——eval 引擎 REPL 仅库 API 可达）、语料/金色面 greeting 消费者普查（仅 repl.rs 自测）。


### 9.62.3 勘察发现 × 前沿锚 × 裁定（十四面审查表）

| # | 面 | 发现 | 前沿锚 | 裁定 |
|---|---|---|---|---|
| 1 | CLI 参数解析（手写 vs clap） | 手写解析 + 全测试覆盖 | K97 | **维持**（std-only 宪制——§18；clap = Stage 1+ 议程既有登记） |
| 2 | CLI 退出码契约（0/1/2） | 0 成功/1 程序·环境/2 usage + 21 测试 | K97（usage→2 精确同构） | **维持** |
| 3 | `--version` 尾随参数 | `kerf --version foo` 静默忽略 foo——与 `--help`（报错）不对称 | K97（strictness 惯例） | **SURF-3 实施**（对称化 + exit 2） |
| 4 | REPL 会话重放 vs 嵌套 REPL | 事务回滚 = 确定性优先设计 | K94（MIT 嵌套 level-N REPL + restart 菜单） | **维持**（嵌套 REPL 的会话状态不可表达为源文本——与 tape-replay/parity/79 语料确定性宪制不兼容；kerf 回滚 = MIT「RESTART 1 返回读算印层」的自动化等价物——成文注记） |
| 5 | REPL 不完备输入谱系 | `UnclosedList`→NeedMoreInput 但 `UnterminatedString`→Error——文件模式支持字符串内原始换行（Scheme 传统）而 **REPL 无法构建多行字符串**（内部不对称） | K94/K95（Scheme read 完整 datum 传统） | **SURF-1 实施**（不完备族统一→NeedMoreInput；malformed 族保持 Error） |
| 6 | REPL 声明头单源 | `DECLARATION_HEADS`（driver 手保）vs expander 顶层分派表两处维护——Stage 2 增形即漂移 | ——（内部单源纪律 §2.3-2） | **SURF-2 实施**（expander 导出 `TOP_LEVEL_DECLARATION_HEADS` + 门控-分派结构 + 双向守卫） |
| 7 | REPL 引擎选择面 | `run` 有 `--engine`、`repl` 无——库能力（with_options）CLI 不可达（零外部消费者实证） | K95（MIT -eval 等选项面） | **SURF-5 实施**（`kerf repl [--engine vm|eval]`） |
| 8 | REPL greeting 措辞 | 「one form per line」与多行累积语义（NeedMoreInput）矛盾 | K94（REPL 语义自描述惯例） | **SURF-4 实施**（措辞改「forms may span lines until closed」） |
| 9 | 渲染形态 | `error[code]: msg` + `-->` + gutter + excerpt + carets | K96（gcc 缺省形态同构）+ K93（rustc 同形） | **维持** |
| 10 | 渲染宽度口径 | 字符计列（CJK 12 字节=4 caret）vs 显示宽度 | K92/K93（rustc unicode-width 直依赖；miette fancy 门控） | **维持 + W-RENDER-WIDTH 登记**（kerf = miette「fancy 之前」的核心位；ds10 金色冻结 + 登记制 CJK 夹具零信号） |
| 11 | 渲染颜色/TTY | 恒无色确定性输出 | K92（fancy 特性门控先例） | **维持 + W-RENDER-COLOR 登记**（金色面/parity 面确定性优先） |
| 12 | 发射器家族 | 仅 human 发射器 | K93（rustc human+JSON 双发射器 + rendered 字段） | **维持 + W-RENDER-JSON 登记**（工具链消费者零信号；LSP = Stage 2+ 通道——§9.27 INFO-G 既有登记同向） |
| 13 | REPL stdin I/O 错误面 | main.rs Err→None = 静默退出 0 | ——（EOF 等价裁定） | **维持**（关闭的 stdin ≈ EOF——「ctrl-d exits」契约的等价物；注入 I/O 契约可测性不受影响；成文注记） |
| 14 | CLI 连字符面 | `-x` 被当文件名（fail 响亮：cannot read + exit 1） | K95（单连字符 = 选项惯例） | **维持 + W-CLI-DASH 登记**（POSIX `--` 分隔符 + 单连字符拒绝 = Stage 2 皮肤议程；失败模式响亮非静默） |

附加两注：`column_of` pub 零外部消费者（DIAG-4 旁路为原始偏移便捷面设计——非 session 渲染路径，维持 + 注记）；REPL Nil 显示不对称（REPL 打印表达式值含 nil / run 静默 nil 停机值——各按其通道契约：REPL = 交互值显示面、run = 程序输出面，维持）。


### 9.62.4 实施设计（五实施 + 守卫双件）

- **SURF-1 不完备族统一**：`repl.rs` probe-read 匹配臂 `Err(UnclosedList) | Err(UnterminatedString) => NeedMoreInput`（不完备 = 结构内 EOF，两变体同族；malformed 族[InvalidEscape/MalformedNumber/UnexpectedClose/EmptyApplication/InvalidBool/InvalidSymbol/NestingDepthExceeded/UnexpectedCharacter]保持 Error + 回滚）。实施后多行字符串跨提交构建与文件模式同构（`(write-line "abc` + `def")` → 输出含内嵌换行的单行项）。
- **SURF-2 单源化**：expander 新导出 `pub const TOP_LEVEL_DECLARATION_HEADS`（紧邻 `expand_declaration`）+ **门控-分派结构**（const 作门：非成员先拒 TopLevelExpression；成员入分派 match；成员无臂 → 落 fail-closed 臂——测试可捕获的洞）。driver 侧 `is_declaration` 改消费 const，手保孪生退役（DRY 面净 -1 列表）。**守卫双件**：① expander `top_level_heads_match_dispatch_table`（每 const 成员不产 TopLevelExpression[证明取臂] + 四非成员头对照拒绝）② driver `declaration_heads_are_unwrappable_and_expressions_wrap`（行为钉扎：每声明头包进 define 被管道拒绝 = 「必须直传」不变量的必要性证明 + 表达式头对照组接受）。
- **SURF-3 版本旗标对称**：`--version`/`-V` 尾随参数检查（对齐 `--help` 的 takes-no-arguments 报错族 + exit 2）。
- **SURF-5 REPL 引擎旗标**：`Command::Repl { engine }` 结构化 + `--engine vm|eval` 解析（默认 vm）+ `Repl::with_options(engine, Vec::new())` 接线 + usage 文本同步。eval 引擎首次从二进制可达（parity 调试面受益）。
- **SURF-4 greeting 措辞**：`"kerf repl — forms may span lines until closed, ctrl-d exits"`（多行语义自描述；消费者普查 = repl.rs 自测单点）。
- **测试账目**：+9（expander 守卫 1 + repl 4[多行字符串完成/裸字符串续行/malformed 族仍错/声明头不可包裹守卫] + cli 4[版本尾随/解析默认/引擎选择/eval 引擎 e2e 集成]）；api_tests + driver_seed_tests 两处 `Command::Repl` 形态同步。


### 9.62.5 语义面与回归账目

管道面零语义变化（编译器/VM/runtime/dispatch 四行连续七版本零漂移维持）；REPL 面两处有意语义变更（不完备族 + 引擎旗标）均为 §9.62.4 文档化设计变更；golden 面唯一触碰 = ds08 版本黄金（0.30.0→0.31.0 历史链 +1）；selfhost 三件 116/741/558 零触碰（`$repl:N` 包裹格式不变）；语料 79 维持（语料面无 REPL 语义依赖）；`--version` 尾随参数从「静默忽略」变「报错」= 显式契约收紧（前置消费者 = 脚本场景，`kerf --version` 裸用法不变）。


### 9.62.6 阶段间推进与禁入重申（r61 第九次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 用户句首首发 + r55/r56/r57/r58/r59/r60 六次重申 + **r61 第九次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.2 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（用户常设指令：crate 边界维持复查 + 全管道前沿审查持续 + 未解决禁止推进 + web 同步 + 打包）。


### 9.62.8 收敛口径

8 原语不变性第三十五轮验证（用户表面域：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF——CLI/REPL 包裹旗标层，管道四行零触碰 + 全量绿）；零新外部依赖（五实施全 std/既有 API）；检索质量如实披露（四弱查垃圾第八轮 + 八主源直读——存档 tool-results/r61-search/ 十五文件实体入库[首版误记十四——编排轮顺修]）；TD 开放项 0 维持（连续二十三轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十一轮）；实施基线 v0.31.0 = 六命令全绿 + test 1180:0:0（+9）+ audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = 剩余未审横切缺口或元域再审计——用户表面域已入审，候选 = 登记窗信号核对或新元域；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.63 资源限额与预算治理域前沿对照与终止性论证成文（第六十二轮 · r62 · Task 40 · v0.32.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

### 9.63.1 域定位与勘察面（期望零猜测第二十三轮）

**选域依据**：管道十二阶段专段（§9.60）+ 测量方法学（§9.61）+ 用户表面（§9.62）之后，**资源限额与预算治理域 = 谱系缺口识别第五例**——限额族散布 5 crate 各自为政（每处局部文档完备、局部边界测试在场），但**作为统一治理策略从未成文**：分层序（256→512→512→1024→2048）的倍率关系只在成对注释中体现、无单源表；广度炸弹面（深度帽不约束总工作量）从未审理；REPL 累积无界增长未登记；「每个非终止程序必被预算捕获」的构造性论证散落三处注释（vm.rs 预算文档 + compile.rs 无 TCO 注 + 子集冻结无循环原语）未成链。

**勘察面**（全量精读）：reader/parser.rs NESTING_LIMIT=256（对抗深度 = 结构化错误非栈溢出 + 边界含入性测试 `nesting_limit_boundary_is_inclusive`）+ expander/ctx.rs EXPANSION_LIMIT=512（`enter/exit` 深度配对计费——**深度预算非总工作量**；2× 余量吸收脱糖包裹层；双侧边界测试）+ typecheck/infer.rs INFERENCE_DEPTH_LIMIT=512（per-define 表达式深度；**E0011 warning 非 error**——deep-but-legal 程序必须能跑的 A6 语义 + LITERAL_TYPE_DEPTH=64 私有常量[扁表字面量注解深度帽——嵌套帽不约束扁表]）+ compiler/lib.rs COMPILE_DEPTH_LIMIT=1024（2× 展开器 + 精确边界测试[1023 过/1024 拒]）+ runtime/eval.rs EVAL_DEPTH_LIMIT=2048（**宿主栈护栏**——评估器 Rust 帧递归 vs VM 堆帧；2× 编译器）+ vm/vm.rs DEFAULT_BUDGET=8Mi（**LIVE 占用检查**：帧 + 活堆单元；`reserve` 收集后重试安全点 §19.4；闭包/帧/常量三计费面）+ REPL acc 无界累积（会话重放语义的固有 O(n²)——头注披露）+ VM 无 TCO 确证（compile.rs 头注「Stage 1+ TCO only rewrites the branch tail, never the VM」——每次闭包调用 push_frame→reserve）+ 子集冻结无循环原语（§9.45 特殊形式 10 无 while/for/loop）。


### 9.63.3 勘察发现 × 前沿锚 × 裁定（十面审查表）

| # | 面 | 发现 | 前沿锚 | 裁定 |
|---|---|---|---|---|
| 1 | 阶梯关系不变量 | 256→512(≥2×)→1024(≥2×)→2048(≥2×) + HM 512(=展开器帽)——倍率关系仅存于成对注释，无单源断言 | ——（§2.3-2 内部纪律） | **LIM-1 实施**：根树守卫测试——六常量精确值黄金 + 关系不变量 const 块（编译期断言——漂移破构建非仅破测试） |
| 2 | 各限额边界测试密度 | reader 双测在场 / expander 双侧在场 / compile 精确边界在场 / HM FP5 双侧在场 / eval 在场 / VM 预算族在场——**六面皆有边界钉扎** | —— | **维持**（局部完备——本轮补跨 crate 面） |
| 3 | 深度帽 vs 总工作量 | EXPANSION_LIMIT 为深度预算（enter/exit 配对）——**广度不受约束**：宏模板兄弟扇出可致 2^深度 总工作量（源码 20 行可造编译炸弹） | K98/K99（rustc 128/GCC 900 同为深度-only——工业标准形态）+ K100（fuel = 总工作量仪表化——有成本） | **LIM-2 维持深度-only + W-EXP-WORK 窗登记**（威胁模型 = 开发者自持源码非不可信输入；rustc/GCC 同立场；触发 = LSP/不可信输入场景——fuel 路径预留） |
| 4 | 终止性论证 | 无循环原语（§9.45）+ 无 TCO（每调用计费）+ LIVE 检查 → 每个非终止程序单调增长必被 BudgetExceeded 捕获——散落三处注释未成链 | K100（wasmtime 需 fuel 仪表化达同效；kerf 语言构造性前提免费获得） | **LIM-3 成文 + 可执行证明**：§9.63.1 三步论证单源 + 守卫测试 `vm_budget_catches_non_terminating_programs`（read→expand→compile→预算 64→结构化错误）= 论证的测试化身 |
| 5 | HM 预算不对称 | 512 为 **warning 非 error**（deep-but-legal 必须能跑——A6）vs 其余五面 fail-closed | —— | **维持**（设计不对称有据——守卫测试断言 INFERENCE=EXPANSION 关系防两 512 漂移） |
| 6 | 可调性 | rustc crate 属性可调 / GCC 旗标可调 vs kerf 六常量编译期固定 | K98/K99 | **维持 + W-LIMIT-TUNABLE 窗登记**（常量 = 零配置面 + 金色可钉扎 + 守卫可 const 断言；触发 = 用户程序合法超限的真实场景[生成代码/宏库]——届时 CLI 旗标或语言属性） |
| 7 | VM 预算计费粒度 | LIVE 占用（帧+活单元）自然点计费——零仪表化成本 + 确定性 | K100（fuel 仪表化有成本 / epoch 非确定） | **维持**（第三形态成文——构造性前提[无循环原语]使分配粒度充分；探针实证：单调用程序峰值恰 3 单元[入口帧+闭包单元+调用帧]——精确边界守卫钉扎） |
| 8 | REPL 累积增长 | acc 无界 + 每提交全量重跑 O(n²)——会话重放语义固有 | —— | **维持 + W-REPL-ACC-GROWTH 窗登记**（触发 = 交互会话积累数万行出现可感延迟——优化路径 = 增量编译缓存[Stage 2+ 依赖]） |
| 9 | EVAL 2048 宿主栈护栏 | 评估器 Rust 帧递归——物理前提 = RUST_MIN_STACK OBS（§9.51.8 256MB） | —— | **维持 + 关系成文**（EVAL 2× COMPILE 的宿主栈论证 + OBS 互指） |
| 10 | 隐式限额族 | u32 ByteOffset 4GB 源上限（物理不可能场景）+ Interner leak-by-design（§9.52 已裁）+ LITERAL_TYPE_DEPTH 64（私有 + 模块内双测在场） | —— | **维持注记**（三层各归其位：不可能面不设防 / 已裁引用 / 私有常量有内测） |


### 9.63.4 实施设计（守卫族 + 三窗）

- **LIM-1 阶梯守卫**（tests/v1/stage1/plan/limits_ladder_guard_tests.rs +4）：①`limits_ladder_exact_and_relational`——六常量精确值黄金（256/512/512/1024/2048/8Mi）+ 关系不变量（EXPANSION≥2×NESTING 与 COMPILE≥2×EXPANSION 为 **const 块编译期断言**——漂移破构建；EVAL≥2×COMPILE 与 INFERENCE=EXPANSION 为运行期断言[u32/usize 混型]——两 512 漂移防护）②`vm_budget_catches_non_terminating_programs`——终止梯可执行证明（`(define (f) (f))` 自调用 + 预算 64 → BudgetExceeded{budget:64} 结构化）③`vm_budget_counts_live_frames_exactly`——LIVE 计费精确边界（单调用程序峰值 3 单元：入口帧 + `(define (g) 42)` 闭包单元 + 调用帧——预算 3 过/2 拒；开发期探针实证[初判 2 失败 → 探针循环 1..9 定位 3 = 闭包单元遗漏勘察——如实登记]）④`reader_nesting_cap_is_structured_at_the_boundary`——公共读面 256 过/257 结构化拒（载荷带 depth/limit）。**跨 crate 断言入根树**（§8.4.6——六常量五 crate 全 pub 导出，守卫单点承载阶梯整体）。
- **三窗登记**：W-EXP-WORK（宏广度炸弹——fuel 路径预留 K100）/ W-LIMIT-TUNABLE（可调性——K98/K99 属性/旗标形态触发时参照）/ W-REPL-ACC-GROWTH（会话累积——增量缓存路径）。全零信号。
- **单源双锚**：§9.63.1 阶梯表 = 文档单源；守卫测试文件头注紧凑阶梯表 = 代码侧单源（两表互指——测试头注引 §9.63、§9.63 引测试名）。


### 9.63.5 语义面与回归账目

管道面零语义变化（守卫 + 文档纯增量——六常量零触碰、计费逻辑零触碰、crates/*/src 本轮唯一触碰 = 无[纯根树测试]）；测试 +4 全根树集成；golden 面唯一触碰 = ds08 版本黄金（0.31.0→0.32.0 历史链 +1）；selfhost 三件 116/741/558 零触碰；语料 79 维持。


### 9.63.6 阶段间推进与禁入重申（r62 第十次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r61 七次重申 + **r62 第十次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.3 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续。


### 9.63.8 收敛口径

8 原语不变性第三十六轮验证（限额治理域：零新原语 / 零通道 / 零 VM 变更 / 零语法增量 / 零 EBNF——crates/*/src 零触碰[纯根树测试 + 文档]；全量绿 + audit 双绿）；零新外部依赖；检索质量如实披露（弱查第九轮[q4 429 限流] + 四主源直读——存档 tool-results/r62-search/ 十一文件实体入库[首版误记十——当轮顺修]）；TD 开放项 0 维持（连续二十四轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十二轮）；实施基线 v0.32.0 = 六命令全绿 + test 1184:0:0（+4 守卫族）+ audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对或新元域——限额治理域已入审，谱系 21 段；候选 = 模块系统域[module.rs 专段从未开面]或又一横切缺口；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。


---



---

## 9.64 模块系统域前沿对照与加载层身份基座统一（v9.30——第六十三轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.64 勘察基线与节引言


> 勘察基线 v0.32.0 @ a94c435——管道审查谱系第二十二段开面：模块系统域（kerf-core/module.rs 声明层 + kerf-expander/src/module.rs 加载层 + 全部消费面[编译平铺/求值平铺/检查跳过臂/驱动装配/REPL 累积重放/语料九件]）。**谱系缺口识别第六例**：前二十一段（§9.43-§9.63）覆盖逐层数据结构/自举三段/后端四行/检查器/驻留/内存/确定性/诊断/测试基础设施/crate 边界两步/驱动编排/性能/用户表面/限额后，模块系统域 = 最后一个从未专审的管道实代码域（用户 r62 收尾预告点名候选，本轮实证开面）。


### 9.64.1 域面盘点与发现聚合（勘察实录）

**十面全量精读**（期望零猜测第二十四轮）：①声明层 core/module.rs 230 行（ModuleItem 四变体 + checked constructors + span/kind_name/visit_spans/Display + 「成员唯一性与跨模块环 = 0.9 语义」边界头注）②展开面 expand.rs 声明族（expand_declarations 帧 push/pop + TOP_LEVEL_DECLARATION_HEADS 单源[§9.62 SURF-2 既有] + expand_require 字符串 fail-closed[符号名死于 MalformedForm——§9.47 勘察实证先例] + expand_module isolate_frames + RESERVED_MACRO_NAMES 含模块四名[宏名面防御]）③加载面 expander/module.rs 424 行（ModuleError 三变体 + LoadPlan + 三色 DFS + ModuleGraph 双收集器 + 双 visit 函数 + gray 闭环路径重建）④编译面 compile.rs item_inner（平铺递归编译 + Require/DefineSyntax 双零代码 + intern_global lookup-or-insert）⑤求值面 eval.rs eval_items（平铺递归求值 + globals HashMap insert）⑥检查面 check.rs collect_items/walk_items + infer.rs collect_info/flatten_into（Require/DefineSyntax 双双跳过——四层对称）⑦驱动面 pipeline.rs parse()（load_program 于 parse 时装配——双引擎对称前置验证）+ ParityReport globals 面 + Diagnostic::from_module（Display+span 消费）⑧REPL 面 repl.rs 累积源重解析（模块层验证应用于累积程序——rollback 契约）⑨语料面九件（3 正[pos-025/029/030] + 6 负[neg-018/019/020/048/049/053]）+ selfhost 零使用（仅 expander.krf:68 注释提及）⑩文档面 plan-0.9.md 边界记录（require 可见性合并 = Stage 1 模块系统面）+ §8.9 相位分离锚。

**发现聚合三**：
- **F1 加载层文本身份桥**：ModuleGraph/declaration_order/colors/stack/in_order/ModuleError 载荷/LoadPlan/edges_of 八面全 `String` 键（`name.as_str().to_owned()` de-intern 拷贝——每边每访问一次分配）；§9.58 单池统一后加载层 = 全管道唯一残余文本身份面（expander 文本桥接已同池命中化）。
- **F2 收集序文档失配**：declaration_order 收集 = 栈 LIFO（跨层嵌套模块逆序记录——A{A1} B{B1} 记录为 A,B,B1,A1）；两处文档声称「first-seen declaration order（deterministic traversal）」——确定性成立、**语义失配**（first-seen = 源阅读序 A,A1,B,B1）；LoadPlan 无消费者事实（pipeline parse() 丢弃 plan——实例化次序 = Stage 1 消费面预留）。
- **F3 重复 define 静默 last-wins**：无任何面拒绝重复 define（checker 零规则 / compile intern_global 同槽 / eval HashMap 同键覆写）；模块声明有 ModuleDuplicate fail-closed（**不对称**——模块名唯一性已治理、define 名唯一性从未治理）；语料零覆盖（无正无负）；REPL 累积重定义依赖 last-wins 合法。


### 9.64.4 实施清偿（v0.33.0）

kerf-expander/src/module.rs 全层重写（424→489 行）：头注三段增补（身份面 + last-wins 成文 + 先序声明）+ ModuleError/LoadPlan/ModuleGraph/visit 双函数 Symbol 置换 + declare() 迭代先序 + 单测五处 String→Symbol 构造 + MOD-2 守卫 +1（`declaration_order_is_source_reading_order_across_levels`——负向形态 A,B,B1,A1 显式注记）。kerf-driver/src/expander_parity.rs：mod-dup/mod-missing/mod-cycle 装解码器三处经单池重构。版本面共变族：Cargo.toml 0.32.0→0.33.0 + ds08 版本金链 +1（历史链 19 条）+ RELEASE_NOTES v0.33.0 条目。**六命令全绿 + test 1185:0:0（+1 = MOD-2 守卫精确）+ audit 200/200**；B 系列重跑全带内（B1 7.9µs[均值带内] / B1a 1.4µs / B1b 3.6µs / B1c 1.5µs / B2 92.123ms / B3 10.370ms / B4 0.352ms + gc-cycles 1 + swept 1023 确定性计数与 §9.61 首录逐位一致 / B5 87.532ms——§14.6.4 规则 5 触发面[crates/*/src 触碰]履行）。


### 9.64.5 语义面与回归账目

管道面变更 = 加载层内部身份与收集序（Display 逐字节不变——错误轴消息金链零触碰）；golden 面唯一触碰 = ds08 版本黄金（0.32.0→0.33.0 历史链 +1）；语料 79 维持（模块九件零改动——pos/neg 期望全数存活）；selfhost 三件 116/741/558 零触碰（.krf 侧无模块层再实现[信任根 = Rust 加载器双路径同用]）；REPL 契约维持（last-wins 不变——累积重定义合法性零变化）；8 原语不变性第三十七轮验证（模块域：零新原语/零通道/零 VM 变更/零语法增量/零 EBNF——require/module 形态零触碰，仅内部键型与收集序）。


### 9.64.6 阶段间推进与禁入重申（r63 第十一次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r62 十次重申 + **r63 第十一次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.3→v2.4 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T41 模块系统域审查开面即实证）。


### 9.64.8 收敛口径

8 原语不变性第三十七轮验证（模块系统域：crates/*/src 触碰 = 加载层内部键型/收集序——require/module 语法面零触碰）；零新外部依赖；检索质量如实披露（弱查第十轮[q2/q4 双 429 限流] + 五主源直读 + 双面降档[OCaml/MIT-Scheme]——存档 tool-results/r63-search/ 18 文件实体入库[磁盘核验：q 落盘 4 + 无文件 2 + 主源 13 件{7 失效计内 + 6 成功} + README——首版误记 17，当轮顺修]）；TD 开放项 0 维持（连续二十五轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十三轮）；实施基线 v0.33.0 = 六命令全绿 + test 1185:0:0 + audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = ExpandError 载荷 String 面[MOD-11 维持项——展开错误族载荷统一候选]或登记窗信号核对；谱系 22 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.65 展开错误载荷域前沿对照与错误族身份统一（v9.31——第六十四轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.65 勘察基线与节引言


> 勘察基线 v0.33.0 @ 5bf4556——管道审查谱系第二十三段开面：展开错误载荷域（§9.64.8 钦定候选域 = MOD-11 维持项开面，MOD-11 至此升格为本节 EXP 裁定族域内裁定）。域范围 = 展开错误族的可身份化载荷面：ExpandError 自载 9 变体 + 其直达构造链（SyntaxRules.name 源链 + CoreError 包装族）+ parity 装解码面 + Display/Debug/等值消费面。


### 9.65.1 域面盘点与发现聚合（勘察实录）

**八面全量精读**（期望零猜测第二十五轮）：①错误族自载面 error.rs 256 行（9 变体全量：身份载荷仅 2——UnboundIdentifier.name: String + MacroPatternMismatch.name: String；MalformedForm = &'static str 封闭静态集；数值/枚举/span-only 载荷各就位）②构造点链五处（expand.rs:147 expand_symbol[text 由 StxDatum::Symbol(sym).as_str() 桥出——sym 就在手边] + expand.rs:450 expand_set[symbol_text 桥] + transformer.rs:214 instantiate[self.name.clone()——SyntaxRules.name: String 由 parse() 时 name.to_owned() de-intern] + core/expr.rs:291 fn_[symbols: Vec&lt;Symbol&gt; 刚建成，错误路径 (*raw).to_owned() 回拷文本] + core/expr.rs:343 handle[clause.effect 已是 Symbol，as_str().to_owned() de-intern]）③消费面四（error.rs + core/error.rs Display {name} 占位 + diagnostic.rs from_expand[仅消费 span——零触碰] + typecheck lib.rs 文档锚[注释引用，零触碰]）④parity 面 expander_parity.rs 1088 行（reconstruct_expand_error 四解码点：unbound/macro-mismatch 经 krf_name→String + dup-param/dup-handler as_str().to_owned()——MOD-1 先例 = Symbol::new 经单池；rebuild_item/dump_krf_* 的 krf_name 消费 = 声明重建/转储文本协议面）⑤.krf oracle 面（selfhost/v1/expander.krf 产 ("err" "unbound" name ...)——值模型 Value::Str 携文本，零 .krf 改动）⑥邻面登记（ExpandCtx 词法表 Frame.macros HashMap&lt;String,usize&gt; + bind/bind_macro &str 键 + transformer 内部 literals: Vec&lt;String&gt;/bindings/renames——词法/变换器身份面，§9.47 已审形态独立域）⑦类型链事实（CoreExpr::Var { name: Symbol } 已单池化 + ModuleItem 四变体已 Symbol + HandlerClause.effect 已 Symbol——错误载荷 = 这些身份面的**终点回拷点**）⑧测试面清点（expand.rs 10 处 + transformer.rs 10 处 + error.rs 2 处 + expander_seed 4 处 + runtime_seed 1 处[已 as_str 天然兼容] + audit 3 处 + diagnostic 1 处 + core/expr 4 处 + core/error 5 处 + api_tests 2 处 + core_seed 2 处——编译器完成同类路径全量清点[§20.3]，初扫漏 9 处由 cargo check/clippy 捕获当轮清偿）。

**发现聚合三**：
- **F1 错误族身份回拷**：展开错误族四个身份载荷（UnboundIdentifier.name / MacroPatternMismatch.name / CoreError::DuplicateParam.name / CoreError::DuplicateHandler.effect）全部在**身份已就位**的构造点回拷为 String（sym 就在手边 / symbols Vec 刚建成 / clause.effect 已是 Symbol）——§9.58 单池 + §9.64 MOD-1 后错误族 = 展开管道最后残余的身份回拷面（K107 rustc 三层纪律对照：身份载荷 = Symbol）。
- **F2 SyntaxRules 源链双拷贝**：parse(name: &str) 先 name.to_owned() 存 String（声明时一次分配）→ instantiate 错误时 self.name.clone()（24 字节 + 堆分配）——身份经文本桥两次往返；parse 签名收 &str 还引入幻影失败面（Symbol::new 于构造器已前置验证——parse 内再驻留必然成功却须处理 Err）。
- **F3 parity 解码双轨**：unbound/macro-mismatch 经 krf_name（返回 String）与 dup-param/dup-handler 经 as_str().to_owned()——同为错误重建却两形态；mod-* 族（r63 MOD-1）已是第三形态 Symbol::new 经单池——三轨不统一。


### 9.65.4 实施清偿（v0.34.0）

五文件主实施 + 六文件测试适配：kerf-expander/src/error.rs（256→271 行：两变体载荷 Symbol + 头注三层纪律引 K107/K110 + 测试 2 处）+ kerf-expander/src/expand.rs（+symbol_sym 助手 + expand_symbol 签名收 &Symbol[消灭 symbol_text().expect 桥] + expand_set/expand_define_syntax 经 sym 直取 + 测试 10 处适配 + 守卫 +1 `error_payloads_round_trip_through_the_single_pool`[unbound + macro mismatch 双面池条目等值钉扎]）+ kerf-expander/src/transformer.rs（SyntaxRules.name: Symbol + parse 签名收 Symbol + 测试 10 处 + sym_m 助手 + 守卫 +1 `mismatch_payload_is_the_registered_identity`）+ kerf-core/src/error.rs（两变体 Symbol + 测试 5 处）+ kerf-core/src/expr.rs（fn_ 扫描迭代 symbols + handle 复用池条目 + 测试 4 处 + 守卫 +1 `duplicate_payloads_round_trip_through_the_single_pool`）+ expander_parity.rs 四解码点 + diagnostic.rs / expander_seed / core_seed / api_tests / audit 适配。**同类路径全量清点由编译器完成**（§20.3——初扫 grep 漏 9 处[api_tests 2 + core_seed 2 + expand 内嵌 3 + error.rs 1 + audit 1]由 cargo check/clippy 捕获当轮清偿，如实登记）。版本面共变族：Cargo.toml 0.33.0→0.34.0 + ds08 版本金链 +1（历史链 21 条）+ RELEASE_NOTES v0.34.0 条目 + README Status（**r63 漏更教训吸收——README 入 feat 提交**）。**六命令全绿 + test 1188:0:0（+3 = 三守卫精确）+ audit 200/200**；B 系列重跑全带内（B1 7.9µs / B1a 1.4µs / B1b 3.7µs / B1c 1.5µs / B2 87.478ms / B3 10.373ms / B4 0.350ms + gc-cycles 1 + swept 1023 确定性计数与 §9.61 首录逐位一致 / B5 86.885ms——§14.6.4 规则 5 触发面[crates/*/src 触碰]履行）。


### 9.65.5 语义面与回归账目

管道面变更 = 错误族载荷类型（Display 逐字节不变——错误轴消息金链零触碰）；golden 面唯一触碰 = ds08 版本黄金（0.33.0→0.34.0 历史链 +1）；语料 79 维持（展开错误族期望全数存活——parity 重放绿）；selfhost 三件 116/741/558 零触碰（.krf oracle 侧 Value::Str 协议不变——宿主解码经单池重建，等值语义从文本等值强化为池条目等值[同文本必同池条目——单池不变量]）；8 原语不变性第三十八轮验证（错误载荷域：零新原语/零通道/零 VM 变更/零语法增量——错误族是诊断面非语义面，展开行为零变化）。


### 9.65.6 阶段间推进与禁入重申（r64 第十二次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r63 十一次重申 + **r64 第十二次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.4→v2.5 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T42 展开错误载荷域审查开面即实证）。


### 9.65.8 收敛口径

8 原语不变性第三十八轮验证（展开错误载荷域：crates/*/src 触碰 = 错误族载荷类型与构造链——语法面/展开行为/VM 零触碰）；零新外部依赖；检索质量如实披露（弱查第十一轮[q1 429 + q2/q3/q4/q6 垃圾 + q5 弱] + 四主源直读 + 主源路径迁移链如实登记[errors.rs→diagnostics/ + DiagArgValue 跨 crate 定位]——存档 tool-results/r64-search/ 23 文件实体入库[磁盘核验：查询落盘 5 + 无文件 1 + 主源 17 件{7 失效 JSON + 3 目录定位 + 3 定位链中间 + 4 锚承载} + README]）；TD 开放项 0 维持（连续二十六轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十四轮）；实施基线 v0.34.0 = 六命令全绿 + test 1188:0:0 + audit 200/200。下一轮入口 = 阶段间轮继续（候选域 = 展开器词法/变换器身份面[EXP-13 登记项——Frame 表 + transformer 内部 String 族]或登记窗信号核对；谱系 23 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.66 展开器词法/变换器身份域前沿对照与帧表/模式机身份统一（v9.32——第六十五轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.66 勘察基线与节引言


> 勘察基线 v0.34.0 @ 6140d76——管道审查谱系第二十四段开面：展开器词法/变换器身份面（§9.65.8 钦定候选域 = EXP-13 登记项开面，EXP-13 至此升格为本节 TRF 裁定族域内裁定）。域范围 = 展开器自身工作状态的身份面：ExpandCtx 帧表族（Frame.names HashSet&lt;String&gt; + Frame.macros HashMap&lt;String,usize&gt; + bind/bind_macro &str 键 + resolve/resolve_macro 文本查询）+ 变换器模式机族（Pattern::Literal/Var(String) + literals Vec&lt;String&gt; + bindings HashMap&lt;String,SyntaxObject&gt; + trigger HashSet&lt;String&gt; + renames Vec&lt;(String,String)&gt; + fresh_name String 形态）+ 静态名表触发面（STAGE0_GLOBALS/RESERVED_MACRO_NAMES 每次宏实例化 to_owned 播种）+ 调用面桥（expand.rs 各 bind/resolve 调用点的 de-intern 桥）。**§9.65 已判「解析热路径 vs 错误冷路径——K110 缓解面论据在热路径不成立」——本域即该判定的兑现面。**


### 9.66.1 域面盘点与发现聚合（勘察实录）

**八面全量精读**（期望零猜测第二十六轮）：①帧表层 ctx.rs 417 行（Frame.names HashSet&lt;String&gt; L47 + Frame.macros HashMap&lt;String,usize&gt; L48——bind(&str)→to_owned 每绑定一次堆分配 + resolve(&str) HashSet Borrow 文本查询 + STAGE0_GLOBALS.contains(&name) ~18 项切片线性扫）②宏表层（bind_macro(&str,usize)→insert(to_owned(),id) 每声明一次分配 + resolve_macro(&str) HashMap Borrow 查询——宏名解析 = 每宏使用一次）③模式编译面 transformer.rs 1036 行（Pattern::Literal(String)/Var(String) 编译期 to_owned + literals Vec&lt;String&gt; 每字面量 to_owned + seen_vars Vec&lt;String&gt; 每模式变量 to_owned + 线性扫判重文本比较）④匹配面（bindings HashMap&lt;String,SyntaxObject&gt;——match_datum Var 臂 insert(name.clone(), node.clone()) **每模式变量每次规则尝试一次 24 字节 String 堆克隆**{含失败尝试} + Literal 臂 symbol_text(node)==Some(text.as_str()) 每位置字节比较）⑤实例化触发集面（trigger HashSet&lt;String&gt; 每次宏使用从头重建三路播种——collect_symbols 每参数符号 as_str().to_owned() 一次堆分配{每使用每符号} + STAGE0_GLOBALS 18 项 to_owned + RESERVED_MACRO_NAMES 15 项 to_owned——**每次宏使用 ~45+ 次 String 堆分配于最热路径**；§9.55.4 确定性注记已核——集合序免疫维持）⑥重命名栈面（renames Vec&lt;(String,String)&gt; push((to_owned(), to)) 每碰撞绑定一次分配 + active_rename 文本比较线性扫 + fresh_name format! 候选 + trigger.contains 文本查询 + Symbol::new(to) 于引用臂再驻留{改写名三步文本往返}）⑦调用面 expand.rs 1837 行（expand_symbol L151 sym.as_str() 桥——resolve(text) 文本查询 + CoreExpr::var(span,text) 构造器内再驻留{de-intern/re-intern 往返} + expand_list L197 head 双消费{核心形式 match + resolve_macro(head)} + expand_fn_binding params &amp;[&amp;str]——ctx.bind(param) String 化 + CoreExpr::fn_ 内 symbols 重建再驻留{**双驻留**} + expand_let/expand_do/expand_define/expand_define_syntax 同型桥 + expand_do 的 "_" 字面量绑定）⑧身份基座链事实（StxDatum::Symbol(Symbol) 语法树已单池[§9.52] + CoreExpr 载荷已 Symbol[§9.58] + 模块加载层已 Symbol[§9.64] + 错误族已 Symbol[§9.65] + kerf-core 构造器 &str 面 = §9.58 既定文本边界[K110 intern-once-at-boundary]——**展开器帧表/模式机 = 展开管道最后残余的文本键工作状态**）。

**发现聚合四**：
- **F1 帧表文本键**：names/macros 两表 String 键 + bind/bind_macro 每次插入 String 分配 + resolve 文本 Borrow 查询——身份（Symbol）在全部调用点手边（StxDatum::Symbol(sym)）却被 de-intern 为文本再入表；rustc 同型表全 Symbol 键（K112 macro_use_prelude: FxIndexMap&lt;Symbol, Decl&gt;；K111 Ident{name:Symbol}）。
- **F2 触发集每用重播**：trigger HashSet&lt;String&gt; 每次宏使用从头重建——静态名表（STAGE0_GLOBALS 18 + RESERVED_MACRO_NAMES 15）每次 to_owned 播种 + 参数符号每符号一次分配；rustc 纪律 = 静态名表会话启动一次预驻留（K113 rustc_span::sym Symbols 宏 ~800 静态符号）——**热路径分配主体，§9.65 已预告其缓解面论据在此不成立**。
- **F3 模式机文本往返**：Pattern 载荷 String（编译期 to_owned）+ bindings 键 String（匹配期 name.clone() 堆克隆——失败尝试亦计）+ renames 元组 String 双分配 + 改写名 Symbol::new(to) 再驻留{引用臂每改写符号一次}——池条目等值（4 字节 NonZeroU32 索引比较）全程可替代；单池不变量下文本等值 ⇔ 池条目等值（§9.52）。
- **F4 doc 告警积压（勘察红利）**：本轮基准核验发现前轮 `cargo doc ... | tail -2` 验证口径掩盖 **22 条预存告警**（kerf-compiler 3{funcs[0] 裸文档注释被 rustdoc 解析为引用链接 ×3} + kerf-driver 8{crate 文档链接私有模块} + kerf-expander 2{TOP_LEVEL_DECLARATION_HEADS 链接私有 fn} + kerf-runtime 1{链接私有 reserve} + kerf-vm 2{跨 crate Bytecode::span_of/verify 未解析链接} + cargo#6313 输出文件名冲突 1{bin kerf 与 lib kerf 同名——上游已知缺陷}）——六命令 doc 面的验证口径缺陷，属本域「工具面审查」邻面发现，当轮清偿（16 可修条全部修复，cargo#6313 登记——树内不可修[目标改名 = CLI/API 面变更远超本域]）。


### 9.66.4 实施清偿（v0.35.0）

四文件主实施 + 两文件 doc 清偿：kerf-expander/src/lib.rs（+stage0_global_symbols() OnceLock 预驻留 + 头注 K113 纪律引注）+ kerf-expander/src/ctx.rs（帧表/宏表/签名四置换单源完成——TRF-1/2/3 全部 + 测试 20 处池条目 fixture 适配{s() 助手} + 守卫 +1 frame_tables_round_trip_through_the_single_pool{bind/resolve + bind_macro/resolve_macro 双表池往返 + 全局回退池条目}）+ kerf-expander/src/transformer.rs（Pattern/literals/seen_vars/bindings/trigger/renames/fresh_name/active_rename/binder_names/collect_symbols 十置换 + symbol_sym 助手 + 守卫 +2：literal_matching_judges_by_the_pool_entry{独立驻留条目匹配同文本字面量 + 异文本失配——池等值⇔文本等值钉扎} + static_name_tables_are_preinterned_pool_entries{两静态表逐条目驻留 + 集合大小==表长无重}）+ kerf-expander/src/expand.rs（TRF-8 调用面十点改造 + reserved_macro_name_symbols() 预驻留 + is_reserved_macro_name(&Symbol) + symbol_syms 助手 + TOP_LEVEL_DECLARATION_HEADS 文档链接顺修）+ doc 清偿四文件（kerf-compiler/bytecode.rs funcs[0] 三处反引号化 + error.rs 一处 + kerf-runtime/eval.rs reserve 链接 + kerf-vm/lib.rs Bytecode::span_of/verify 跨 crate 限定位 + kerf-driver/lib.rs 八私有模块链接反引号化）。**同类路径全量清点由编译器完成**（§20.3——本轮初扫即全量，cargo check/clippy 首过零 error 零告警，与 r64 初扫漏 9 处对照如实登记）。版本面共变族：Cargo.toml 0.34.0→0.35.0 + ds08 版本金链 +1（历史链 22 条）+ RELEASE_NOTES v0.35.0 条目 + README Status（版本面共变完整入 feat——r63 教训延续）。**六命令全绿 + test 1191:0:0（+3 = 三守卫精确）+ audit 200/200 + doc 告警 22→1**（16 可修清偿 + cargo#6313 登记）；B 系列重跑全带内（**v0.35.0 release 终态**：B1 7.6µs{优于录 7.9} / B1a 1.4µs / B1b 3.6µs{展开轴——本域轴无回归边际改善 vs 录 3.7} / B1c 1.5µs / B2 87.171ms{优于录 87.478} / B3 10.345ms / B4 0.353ms + gc-cycles 1 + swept 1023 确定性计数与 §9.61 首录逐位一致 / B5 87.316ms{+0.5% 带内}——§14.6.4 规则 5 触发面[crates/*/src 触碰]履行；首跑 B2/B3/B5 曾现 +1.6%~2.6% 跨会话共享机方差，终态复跑收敛如实登记）。


### 9.66.5 语义面与回归账目

管道面变更 = 展开器内部表格键型与分配形态（**零语义变化**：帧表子集判定逻辑逐字节不变{binder_scopes 判定零触碰} + 模式匹配判定同构{池等值 ⇔ 文本等值——单池不变量，守卫钉扎} + rename-on-capture 产物逐字节不变{fresh_name 文本形态与计数序不变——MX-1 延续} + 头部分发八臂字符串 match 维持 + 触发集内容不变{预驻留播种与逐符号收集并集同构——§9.55.4 确定性注记原样保留}）；Display/Debug 面零触碰（Symbol 手写 Debug 保形——§9.52）；golden 面唯一触碰 = ds08 版本黄金（0.34.0→0.35.0 历史链 +1）；语料 79 维持（宏面期望全数存活——parity 重放绿）；selfhost 三件 116/741/558 零触碰；doc 清偿四文件 = 注释面（零语义）；8 原语不变性第三十九轮验证（帧表/模式机/触发集 = 工作状态键型与分配形态——语法面/展开行为/VM 零变化，展开产物逐字节不变）。


### 9.66.6 阶段间推进与禁入重申（r65 第十三次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r64 十二次重申 + **r65 第十三次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.5→v2.6 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T43 展开器词法/变换器身份域审查开面即实证）。


### 9.66.8 收敛口径

8 原语不变性第三十九轮验证（展开器词法/变换器身份域：crates/*/src 触碰 = 帧表/模式机/触发集键型与分配形态 + doc 注释面——语法面/展开行为/VM 零触碰）；零新外部依赖；检索质量如实披露（弱查第十二轮[q1/q2/q5/q7 垃圾 + Chez 双路径 404 snippet 降档] + **五主源直读**[m1 rustc_resolve 119KB + m2 rustc_span::sym 88KB + m4 Racket guide 143KB + m5 Racket stxcmp 118KB + m6 R6RS 71KB 全文实体入库]——存档 tool-results/r65-search/ **13 文件**实体入库[磁盘实测：查询落盘 7{q1-q7} + 主源 6{m1 master + m1b 1.84 对照 + m2 + m4 + m5 + m6}；失效件 2{m3-chez 双 404 页面 + m6-dybvig 431B}确认无存档价值未落盘——检索过程由 §9.66.2 弱查披露与 worklog 43-b 承载；首版误记 15 当轮顺修{主源 6 漏计 m1b + 失效件未落盘}——39-web r61-search 计数先例同型处置]）；TD 开放项 0 维持（连续二十七轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十五轮）；实施基线 v0.35.0 = 六命令全绿 + test 1191:0:0 + audit 200/200 + doc 告警 22→1{16 可修清偿 + cargo#6313 登记}。下一轮入口 = 阶段间轮继续（候选域 = 名称后端域[TRF-13 登记项——CoreExpr::Var→bytecode→VM/eval globals 文本链]或登记窗信号核对；谱系 24 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.67 名称后端域前沿对照与运行期名表身份统一（v9.33——第六十六轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.67 勘察基线与节引言


> 勘察基线 v0.35.0 @ c6faf33——管道审查谱系第二十五段开面：名称后端域（§9.66.3 TRF-13 钦定候选域开面，TRF-13 至此升格为本节 NB 裁定族域内裁定）。域范围 = 名称基后半全链：CoreExpr::Var{name:Symbol} → compiler intern_global(&Symbol)（编译侧已池条目——§9.58 既定）→ bytecode globals Vec&lt;Symbol&gt; 常量名表 → VM 槽位阵列（instr.a 池索引解析——编译期已定）+ eval.rs 元循环侧运行期名表族（Evaluator.globals HashMap&lt;String,Value&gt; + Env.names Vec&lt;(String,usize)&gt; + handlers Vec&lt;(String,Value)&gt; + EvalClosure.name Option&lt;String&gt;）+ ArityMismatch 载荷 func:String + 驱动快照 RunOutcome.globals Vec&lt;(String,Value)&gt; 及其文本解析面。**§9.66 已判「展开器帧表/模式机 = 展开管道最后残余的文本键工作状态」——本域即名称基后半（rename-on-capture 桥的存在理由）的对应清偿；§9.60.5 globals 双契约（ORCH-1）在本域一并入审。**


### 9.67.1 域面盘点与发现聚合（勘察实录）

**八面全量精读**（期望零猜测第二十七轮）：①eval 全局表层 eval.rs（globals HashMap&lt;String,Value&gt;——每 Define/Assign 存储一次 name.as_str().to_string() 堆分配 + 每 Var 回退一次全文本字节哈希查询；18 内建播种 name.to_string() 每名一次分配{进程每 Evaluator 实例}）②绑定位面（Env.names Vec&lt;(String,usize)&gt;——from_params 每参数 p.as_str().to_string() + Let 每绑定 binding.name.as_str().to_string() + resolve 尾首扫描文本比较——**词法环境 = eval 热路径最频繁的名面**）③效应处理栈面（handlers Vec&lt;(String,Value)&gt;——每 handler push clause.effect.as_str().to_string() + perform 每次尾首 rposition 文本比较）④闭包名面（EvalClosure.name Option&lt;String&gt;——make_closure 每命名闭包 name.map(to_string) 一次分配）⑤错误载荷面（ArityMismatch.func String——闭包臂 name.unwrap_or_else(|| "#&lt;anonymous&gt;".into()) 每错误一次 String 构造 + 内建臂 b.name().to_string() 每错误一次分配——与 §9.56 位置单源化后的 UnboundGlobal{name:Symbol}/UnhandledEffect{effect:Symbol} 池条目载荷族不对称）⑥VM 侧事实（Vm.globals Vec&lt;Option&lt;Value&gt;&gt; 槽位阵列——LdGlobal/StGlobal 经 instr.a 池索引直取，解释循环热路径**零文本零哈希查询**[编译期解析形态]；Vm::global(&amp;str) 文本面 = 观察面 bc.globals 线性扫）⑦驱动快照面 pipeline.rs（RunOutcome.globals Vec&lt;(String,Value)&gt;——VM 分支 de-intern 全名册{bc.globals.iter().map(as_str().to_owned())} + eval 分支 de-intern Define 名册 + global(&amp;str) 文本扫描 + parity 面每 Define 一次 vm.global(name.as_str()) 文本扫）⑧身份基座链事实（语法树 §9.52 + CoreExpr 载荷 §9.58 + 模块加载层 §9.64 + 错误族 §9.65 + 展开器帧表/模式机 §9.66 全池条目化——**eval 侧运行期名表族 + ArityMismatch 载荷 + 驱动快照 = 全管道最后残余的文本身份状态**；compiler intern_global(&amp;Symbol) 与 VM 槽位索引解析 = 名称基前半，已是池条目形态）。

**发现聚合四**：
- **F1 运行期名表文本键**：globals/Env.names/handlers 三表 String 键 + 存储路径逐点 to_string 堆分配 + 查询路径逐点文本哈希/文本比较——身份（Symbol）在全部调用点手边（CoreExpr::Var.name、params:&amp;[Symbol]、clause.effect:Symbol 全池条目）却被 de-intern 为文本再入表；Lua 同型纪律 = 驻留串按指针同一性比较（K117 TString）——kerf Symbol 即该形态，表键却未用。
- **F2 错误载荷分配**：ArityMismatch 每错误一次 String 构造（闭包臂 + 内建臂双形态）+ 匿名哨兵 "#&lt;anonymous>" 每错误一次发明——§9.56 后唯一残留的文本身份载荷（错误族其余身份载荷已 Symbol 化——§9.65）。
- **F3 快照名册 de-intern**：驱动 VM 分支每次运行 de-intern 整张全局名册 + eval 分支 de-intern Define 名册 + parity 逐 Define 文本扫——观察面的键型本可直接携池条目（bc.globals 本身就是 Vec&lt;Symbol&gt;）。
- **F4 VM 热路径编译期解析形态确认（勘察红利）**：LdGlobal/StGlobal 槽位解析 = 编译期完成（instr.a ← intern_global 首见序）——运行期零名字查找；对照 CPython LOAD_GLOBAL 运行期字典查找 + 自适应特化摊销（K116）——**kerf 形态为更强形态，维持面裁定**（内联缓存/NaN-boxing 等更激进形态无触发信号，登记窗维持）。


### 9.67.4 实施清偿（v0.36.0）

六文件主实施：kerf-runtime/src/eval.rs（NB-1/2/3/4 + 播种面 + global_sym 身份面 + make_closure 签名收池条目——热路径名面零文本零分配）+ kerf-vm/src/builtin.rs（builtin_symbol() OnceLock 预驻留表——Builtin::ALL 单源派生）+ kerf-vm/src/error.rs（ArityMismatch 载荷 Option&lt;Symbol&gt; + Display 匿名哨兵渲染——NB-5）+ kerf-vm/src/vm.rs（global_names()/global_sym() 两观察面 + 闭包臂/内建臂载荷池条目直传）+ kerf-vm/src/lib.rs（builtin_symbol 导出——显式再导出清单 §10.1 规则 4）+ kerf-driver/src/pipeline.rs（RunOutcome.globals 键池条目化 + global_sym 面 + VM/eval 双分支快照零 de-intern + parity 面池条目解析——NB-7）。**同类路径全量清点由编译器完成**（§20.3——断言位点适配 11 处{vm.rs 内联 1 + eval.rs 内联 2 + audit 例 4 + vm_seed 3 + runtime_seed 2}由 cargo check 全量枚举零遗漏）；守卫 +3：builtin_symbols_match_the_registry_and_pool{派生表↔注册表逐条目对齐 + 独立驻留等值 + 二读同条目} + name_tables_ride_the_single_pool{eval 三表池往返 + miss 双面零污染 + 内建播种池条目} + halt_snapshots_carry_pool_identities_on_both_engines{双引擎快照键独立驻留等值 + 名册逐键独立驻留对齐}。版本面共变族：Cargo.toml 0.35.0→0.36.0 + ds08 版本金链 +1（历史链 23 条）+ RELEASE_NOTES v0.36.0 条目 + README Status（版本面共变完整入 feat——r63 教训延续）。**六命令全绿 + test 1191:0:0 → 1194:0:0（+3 = 三守卫精确）+ audit 200/200 + doc 告警 1 维持（cargo#6313 登记）**；B 系列重跑（§14.6.4 规则 5 触发面[crates/*/src 触碰]履行）：**B3 eval-run-fib20 10.345ms → 6.796ms（−34.3%——本域主账：eval 侧名面零文本化后元循环引擎热路径改形）** + B1 7.7µs{首跑 10.0µs 跨会话共享机方差，复跑收敛——§9.66.4 先例同型} + B1a 1.4µs/B1b 3.6µs/B1c 1.5µs 全逐位持平 + B2 87.015ms 带内 + B4 0.351ms gc-cycles 1 + swept 1023 确定性计数逐位一致 + B5 86.867ms 带内——**全轴带内且 B3 显著改善**。


### 9.67.5 语义面与回归账目

管道面变更 = 运行期名表键型与分配形态（**零语义变化**：Env 尾首扫描语义逐字节不变{innermost-wins——resolve 同构换键} + handlers 尾首扫描语义不变 + globals 内容契约不变{§9.60.5 三支维持——快照哪些名出现照旧：VM 分支 = bytecode 全局表首见序，eval 分支 = Define 名册} + ArityMismatch 渲染逐字节不变{Display 面匿名哨兵 "#&lt;anonymous&gt;" 与具名反引号形态原样} + parity 判定同构{globals_agree 逻辑不变——解析面换池条目} + VM 解释循环零触碰{槽位索引解析本就编译期——F4 维持面}）；Display/Debug 面零触碰（Symbol 手写 Debug 保形——§9.52）；golden 面唯一触碰 = ds08 版本黄金（0.35.0→0.36.0 历史链 +1）；语料 79 维持（错误恢复族期望全数存活——ArityMismatch 断言面适配不改期望值）；selfhost 三件零触碰；8 原语不变性第四十轮验证（运行期名表 = 键型与分配形态——语法面/展开行为/VM 指令面零变化，双引擎等价性经 parity 79 语料 + audit 200 重放钉扎）。


### 9.67.6 阶段间推进与禁入重申（r66 第十四次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r65 十三次重申 + **r66 第十四次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.6→v2.7 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T44 名称后端域审查开面即实证）。


### 9.67.8 收敛口径

8 原语不变性第四十轮验证（名称后端域：crates/*/src 触碰 = 运行期名表键型与分配形态 + 错误载荷身份化——语法面/展开行为/VM 指令面零变化）；零新外部依赖；检索质量如实披露（弱查第十三轮[q1/q5/q6 垃圾 + q2 弱] + **六主源直读**[m1 CPython ceval 119,958B + m1b bytecodes 268,227B + m2 Lua lstring + m3 Lua 5.3 notes + m4 V8 string.h + m5 Chez 三件]——存档 tool-results/r66-search/ **15 文件**实体入库[磁盘实测：查询落盘 7{q1-q7} + 主源 8{m1/m1b/m2/m3/m4/m5/m5-symbols/m5b}；失效件 1{m6-cmu-c0vm.pdf 196B 404 页面}确认无存档价值未留档——r65 先例同型；C0VM 知识由 q7 snippet 承载]）；TD 开放项 0 维持（连续二十八轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十六轮）；实施基线 v0.36.0 = 六命令全绿 + test **1194:0:0** + audit **200/200** + doc 告警 1{cargo#6313 登记} + B 全带内{B3 改善 −34.3%——域主账}。下一轮入口 = 阶段间轮继续（候选域 = 检查器工作状态域[NB-9 登记项——typecheck defines/assigned 文本键]或登记窗信号核对；谱系 25 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.68 检查器工作状态域前沿对照与 typecheck 表身份统一（v9.34——第六十七轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.68 勘察基线与节引言


> 勘察基线 v0.36.0 @ 65a9803——管道审查谱系第二十六段开面：检查器工作状态域（§9.67.3 NB-9 登记项开面，NB-9 至此升格为本节 CHK 裁定族域内裁定）。域范围 = kerf-typecheck 全 crate 工作状态名面：check.rs pass-1 模块表（`Table.defines Vec<(String, DefineShape)>` L78 + `Table.assigned HashSet<String>` L79——§9.50 检查器域审查先于 §9.52 单池统一的历史残留）+ 解析面（resolve_define 反向扫描文本比较 / is_any_define 线性扫 / assigned.contains 文本哈希 / externals.resolve 边界）+ infer.rs HM 引擎镜像面（`DefineTable.defines Vec<(String, DefineInfo)>` L204 + `assigned Vec<String>` L205——**与 check.rs HashSet 形态漂移：Vec + 手工 scan-then-push 去重，同 crate 双实现**）+ 环境面（`LocalEntry.name String` L612——params/let 绑定每处一次 to_owned + lookup/apply_type/callee_define_index/leave_assign 文本比较）+ SCC 图面（`refs Vec<Vec<String>>` L1841 + collect_var_names de-intern + 边构造 O(V×D×L) 文本比较）+ R4 镜像面（r4_owns 全表反向线性扫）+ env.rs 边界面（`Externals.entries Vec<(String, Option<u32>)>`——构造每名一次 to_owned + resolve 反向文本扫）+ 消息渲染面（format! 消息用 Symbol Display——渲染协议非工作状态，域外）。**§9.67 已判「运行期名表 = 名称基后半清偿」——本域即静态检查侧对应清偿，完成后 §9.52 单池身份链全管道闭合（语法树 → CoreExpr → 模块加载层 → 错误族 → 展开器表 → 运行期名表 → 检查器表）。**


### 9.68.1 域面盘点与发现聚合（勘察实录）

**八面全量精读**（期望零猜测第二十八轮）：①check.rs 表收集面（defines 每 define 一次 `name.as_str().to_owned()` 堆分配 L100 + assigned 每 assign 一次 de-intern L113——`ModuleItem::Define.name` 本就是 Symbol，身份在手边被逐点剥离）②check.rs 解析面（resolve_define 每 Var 引用一次反向字节串比较 L216{可见性切片 defines[..defined_so_far] 依赖 walk 序——K123 插入序纪律同构} + is_any_define 线性扫 L222 + assigned.contains 文本哈希 L246 + locals 扫描已池条目 L241/L284/L370{对照面——locals 已是 Symbol}）③infer.rs 表面（DefineTable 镜像收集序 + assigned Vec 形态漂移 L205：is_assigned 线性扫 L209-211 + 手工查重后推 L239-240——check.rs 侧已是 HashSet，同 crate 双实现漂移）④infer.rs 环境面（LocalEntry.name String——params p.as_str().to_owned() L872 + let 绑定 b.name.as_str().to_owned() L1610；lookup 反向文本扫 L992 + apply_type 影子检查 L1196 + callee_define_index L1264 + leave_assign 毒化扫 L1663 + shadowing_define L1759）⑤infer.rs SCC 图面（collect_var_names 每 Var 一次 de-intern + contains 文本查重 L2022 + 边构造 refs[i].any(|r| r == name) 文本比较 L1852——图构造全文本）⑥R4 镜像面（r4_owns 全表反向扫双文本比较 L1783-1784——Apply 路径每非箭 callee 一次）⑦env.rs 边界面（Externals 构造每名一次 to_owned L35/L49 + resolve 反向文本扫 L61——18 内建表每 check/infer 调用构造一次；三消费位[driver pipeline_externals + 根集成测试 + audit 例]全持 &str 权威文本）⑧消息渲染面（R1-R8 format! 消息 + E0011 预算消息用 `{name}` Symbol Display——渲染协议面，域外裁定）。**发现聚合三**：F1 检查器工作状态文本键（check/infer 双表 + 环境 + SCC 图 + 边界表五面——身份基座链 typecheck 侧最后残余，NB-9 登记兑现面）+ F2 同 crate assigned 形态漂移（check.rs HashSet vs infer.rs Vec+手工去重——§9.44.4「assigned 守卫泛化」义务的未清偿面）+ F3 externals 构造/解析边界形态（构造 &str 单向边界 + 解析文本扫——K123/K124 工业先例均为身份键控边界）。


### 9.68.4 实施清偿（v0.37.0）

五文件主实施 + 一断言适配族：crates/kerf-typecheck/src/check.rs（CHK-1/2：Table Symbol 键 + 收集 clone + 解析面六位池条目化）+ crates/kerf-typecheck/src/infer.rs（CHK-3/4/5：DefineTable Symbol 键 + assigned HashSet 统一 + LocalEntry.name Symbol + lookup/apply_type/callee_define_index/leave_assign/shadowing_define/r4_owns 七面索引比较 + refs/collect_var_names 池条目）+ crates/kerf-typecheck/src/env.rs（CHK-6：entries Symbol 键 + external_symbol 驻留助手 + resolve(&Symbol) 身份面 + 构造面 &str API 维持）+ crates/kerf-typecheck/tests/api_tests.rs（resolve 断言位适配 ×2）+ examples/audit/stage0_gate_audit_r1.rs（M10 位身份面适配 ×1）+ tests/v1/stage1/plan/typecheck_seed_tests.rs（FP2 位身份面适配 ×1——含 kerf_span::Symbol 导入）；**同类路径全量清点由编译器完成**（§20.3——cargo check --workspace --all-targets 全量枚举零遗漏：初扫 5 error[E0308/E0433] = api_tests ×2 + audit ×1 + typecheck_seed ×2[resolve 签名 + 导入]，全数预测面内机械适配）。守卫 +3：checker_tables_ride_the_single_pool{check.rs——表行/守卫集池身份 + 独立驻留等值 + walk 序确定性} + define_table_env_and_scc_refs_ride_the_single_pool{infer.rs——双表池身份 + assigned 去重[双 assign 单成员] + collect_var_names 池条目收集} + externals_ride_the_single_pool{env.rs——构造驻留 + format! 路径独立驻留同条目 + miss 零污染}。版本面共变族：Cargo.toml 0.36.0→0.37.0 + ds08 版本金链 +1（历史链 24 条）+ RELEASE_NOTES v0.37.0 条目 + README Status（版本面共变完整入 feat——r63 教训延续）。**六命令全绿 + test 1194:0:0 → 1197:0:0（+3 = 三守卫精确）+ audit 200/200 + doc 告警 1 维持{cargo#6313 登记}**；B 系列重跑（§14.6.4 规则 5 触发面[typecheck crate src 触碰]履行）：B1 7.4µs + B1a 1.4µs/B1b 3.5µs/B1c 1.5µs 逐位持平 + B2 86.590ms 带内 + **B3 6.780ms——§9.67 −34.3% 改善保持带内** + B4 0.344ms gc-cycles 1 + swept 1023 确定性计数逐位一致 + B5 86.128ms 带内——**全轴带内**。


### 9.68.5 语义面与回归账目

管道面变更 = 检查器工作状态键型与分配形态（**零语义变化**：check.rs 规则族 R1-R8 判定逐字节不变{键型同构置换——resolve_define 可见性切片/反向扫描序/assigned 成员语义全保持} + infer.rs 推断语义逐字节不变{DefineTable 镜像序保持 + is_assigned 成员语义等价[HashSet contains ⇔ Vec 线性扫命中] + LocalEntry 环境序/毒化语义保持 + SCC 边集构造同构} + Externals 三值解析语义不变{&str→&Symbol 键型置换——同文本恒同条目 §9.52 单池不变量} + 诊断消息面零触碰{format! 消息用 Symbol Display——渲染不变} + 驱动/VM/runtime 零触碰{分析层变更不达执行层}）；golden 面唯一触碰 = ds08 版本黄金（0.36.0→0.37.0 历史链 +1）；语料 79 维持（错误恢复族期望全数存活）；selfhost 三件零触碰；8 原语不变性第四十一轮验证（检查器工作状态 = 键型与分配形态——语法面/展开行为/VM 指令面/执行语义零变化，检查器输出经 audit 200 重放钉扎[含 M 节检查器正负 20 案 + P 节推断 10 案]）。


### 9.68.6 阶段间推进与禁入重申（r67 第十五次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r66 十四次重申 + **r67 第十五次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.7→v2.8 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T45 检查器工作状态域审查开面即实证）。


### 9.68.8 收敛口径

8 原语不变性第四十一轮验证（检查器工作状态域：crates/kerf-typecheck/src 触碰 = 工作状态键型与分配形态——语法面/展开行为/VM 指令面/执行语义零变化）；零新外部依赖（kerf-span 既有入边零新边——§18.5 维持）；检索质量如实披露（弱查第十四轮[q1 弱 + q2/q4/q6/q7 弱或垃圾 + q5 弱{两次 429 后第三次成功}] + **八主源直读**[m1 rustc fn_ctxt 18,663B + m2 GHC Unique 18,976B + m2b GHC Name 40,235B + m3 rustc_resolve late.rs 251,412B + m4 OCaml env.ml 134,461B + m5 dev-guide name-resolution 9,001B + m5b dev-guide ty 19,420B + m6 rustc def_id 18,256B]——存档 tool-results/r67-search/ **15 文件**实体入库[磁盘实测：查询落盘 7{q1-q7} + 主源 8]；零失效件）；TD 开放项 0 维持（连续二十九轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十七轮）；实施基线 v0.37.0 = 六命令全绿 + test **1197:0:0** + audit **200/200** + doc 告警 1{cargo#6313 登记} + B 全带内{B3 保持 §9.67 改善 6.780ms}。**身份基座链全管道闭合**（§9.52 七段链终态：语法树/核心/加载层/错误族/展开器/运行期/检查器——单池身份从 reader 到 typecheck 全程无文本键工作状态）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域——谱系 26 段后无钦定候选；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.69 VM 执行核心域前沿对照与物化批处理/调用窗口统一（v9.35——第六十八轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.69 勘察基线与节引言


> 勘察基线 v0.37.0 @ 4b10b6f——管道审查谱系第二十七段开面：VM 执行核心域（身份基座链闭合后首个算法级域——§9.68.8「候选 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域」的用户常设指令[全管道数据结构与算法选型对照前沿]开面）。域范围 = kerf-vm 执行算法面 + kerf-runtime eval 镜像面：**与 §9.53（存储域：堆/GC/预算/根集）和 §9.44.3 第 7 行（分派形态普查行）正交的执行算法面**——取指（fetch 双索引 + last_mut）+ 分派（24 臂 match）+ 调用协议（exec_call/invoke/take_args/push_frame——callee-on-top 纪律 §19.3）+ 操作数栈纪律（push/pop/peek 每帧自持栈）+ 常量物化（materialize 三段式：pair_cells 计数 walk + 逐格 reserve 循环 + from_literal 重建 walk——**与 eval.rs Literal 臂同型孪生**）+ 局部/全局槽位（LoadLocal clone/StoreLocal/LoadGlobal/StoreGlobal）+ 效应 handler 栈（PushHandler/PopHandler/Perform rposition 最近匹配）+ Ret/Halt/入口（run 入口 span/name 派生）。§9.67 已判「VM 热路径编译期池索引解析 = 更强形态」（NB-6）——本域为执行算法面的首个专审段。


### 9.69.1 域面盘点与发现聚合（勘察实录）

**十面全量精读**（期望零猜测第二十九轮）：①取指面（`fetch()` L621-627：frames.last_mut + funcs[func].code[pc] 双边界检查索引 + pc 自增——每指令两次数组边界检查 + 元组拷贝）②分派面（`run()` 主循环 match instr.op 24 臂直译——§9.44.3 第 7 行已裁「LLC 对小枚举 match 生成跳转表」）③调用协议面（exec_call 弹 callee + take_args 收参 + invoke 分派闭包/内建/拒斥三臂 + push_frame 预算一单位——**take_args L536-547[改前]：pop-循环 argc 次 + Vec::reverse()——每调用 2×argc 次 Value 搬运[pop 移动 + reverse 交换]，§19.3 求值序契约下弹出的逆序需再翻转**）④操作数栈纪律面（push/pop 带 op/func/pc 错误归因三元组 + peek(n) 契约读取——每帧自持 Vec<Value> 栈）⑤常量物化面（`materialize()` L489-501[改前]：pair_cells 递归计数 walk + `for _ in 0..cells { self.reserve(span)?; }` 逐格预算检查[N 次 live_usage 比较——live 仅在 from_literal 的 heap.alloc 中移动，N 次检查同态] + from_literal 第二 walk 重建——**eval.rs Literal 臂 L290-306[改前] 完整孪生：同 pair_cells 私有助手 + 同逐格 reserve 循环**）⑥槽位面（LoadLocal locals[slot].clone()——Value 值语义搬运[Str 变体深拷贝——§9.44.3 第 2 行 Value 表示已裁]；StoreGlobal 单写）⑦handler 栈面（PushHandler/PopHandler Vec 栈 + Perform `handlers.iter().rposition(|h| h.effect == instr.a)` 线性最近匹配——深度受安装数约束）⑧Ret/Halt 面（Ret 弹帧 + 空帧哨兵 RetFromEntry + Halt 栈顶/空栈双态）⑨闭包创建面（`Opcode::Closure`：`self.frames.last().locals.clone()` 整帧快照——0.11 登记项「Stage 2 优化窗捕获分析」既有）⑩入口面（run() 每次派生 entry span/name——verify 保证 debug_info 平行性）。**发现聚合三**：F1 物化协议孪生（vm.rs/eval.rs 双私有 pair_cells + 双逐格 reserve 循环——同一预算协议两处实现，§20.3 同类路径纪律；kerf-core LiteralValue 为单源落位点[两引擎均依赖]）+ F2 逐格预算检查粒度（N 格 N 次 live_usage 比较——检查点同态[计数不改变 live]，批处理一次检查行为等价）+ F3 调用参数双倍搬运（pop-循环 + reverse = 2×argc 移动——栈窗口 [len−argc, len) 一次 split_off 即调用序）。


### 9.69.4 实施清偿（v0.38.0）

三文件主实施 + 一集成守卫：crates/kerf-core/src/expr.rs（EXC-1：pair_cells 方法 + 内联守卫 pair_cells_counts_the_materialization_footprint_exactly[标量五形态零单元 + 三层嵌套精确计数]）+ crates/kerf-vm/src/vm.rs（EXC-2/3：reserve_exact + materialize 重写[计数先行解借用——reserve 借用与常量池/堆不相交字段借用不重叠] + take_args split_off[span 先算解借用冲突] + 双内联守卫 pair_const_materialization_charges_one_exact_batch[预算 2 突发越线通过 + 预算 1 拒绝 + allocations 3 精确] + take_args_moves_the_stack_window_in_call_order[三参数闭包调用 MakePair 折叠 (1 . (2 . 3)) 序钉扎 + allocations 5 精确{入口帧+闭包单元+被调帧+双 pair 单元}]）+ crates/kerf-runtime/src/eval.rs（EXC-2 镜像：reserve_exact + Literal 臂单行化 + LiteralValue 导入迁移测试面）+ tests/v0/stage0/plan/vm_seed_tests.rs（跨引擎集成守卫 literal_materialization_budgets_are_batch_identical_across_engines[双引擎同一 (quote (1 2 3)) 程序：预算 2 双过 + 预算 1 双拒——**边界引擎无关性钉扎**]）。版本面共变族：Cargo.toml 0.37.0→0.38.0 + ds08 版本金链 +1（历史链 25 条）+ RELEASE_NOTES v0.38.0 条目 + README Status（版本面共变完整入 feat——r63 教训延续）。**六命令全绿 + test 1197:0:0 → 1201:0:0（+4 = 四守卫精确）+ audit 200/200 + doc 告警 1 维持{cargo#6313 登记}**；B 系列重跑（§14.6.4 规则 5 触发面[vm/runtime/core src 触碰]履行）：B1 7.5µs{带内 +1.4%} + B1a 1.4µs/B1b 3.6µs/B1c 1.5µs 带内 + **B2 75.300ms——v0.37.0 86.590ms 的 −13.0%（EXC-3 域主账：fib(25) ~24.3 万调用 × argc 搬运减半）** + B3 6.874ms{带内 +1.4%——§9.67 −34.3% 改善保持} + B4 0.299ms gc-cycles 1 + swept 1023 **确定性计数逐位一致**（§9.61 首录同值——物化批处理零分配行为变化实证）+ **B5 75.233ms −12.6%**（B2 同源改善传导）。


### 9.69.5 语义面与回归账目

管道面变更 = 执行算法面（预算检查粒度 + 参数搬运形态 + 计数单源化——**零语义变化**：接受/拒绝边界逐位一致[守卫双侧钉扎] + 成功路径 allocs 总量一致 + 求值序契约零触碰[窗口即调用序] + 下溢防御同变体同 span + 物化产物 from_literal 零触碰）；golden 面唯一触碰 = ds08 版本黄金（0.37.0→0.38.0 历史链 +1）；语料 79 维持（双引擎 parity 全数存活）；selfhost 三件零触碰；8 原语不变性第四十二轮验证（VM 执行核心域：crates/kerf-{core,vm,runtime}/src 触碰 = 计数单源化 + 预算批处理 + 参数单移动——语法面/展开行为/VM 指令面/执行语义零变化，执行产物经 79 语料 parity + audit 200 重放钉扎[含 H 节 VM 正负 10 案 + V 节性能面 10 案]）。


### 9.69.6 阶段间推进与禁入重申（r68 第十六次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r67 十五次重申 + **r68 第十六次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.8→v2.9 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T46 VM 执行核心域审查开面即实证）。


### 9.69.8 收敛口径

8 原语不变性第四十二轮验证（VM 执行核心域：执行算法面变更——预算检查批处理 + 调用参数单移动 + 计数单源化，语法面/展开行为/VM 指令面/执行语义零变化）；零新外部依赖（kerf-core/kerf-vm/kerf-runtime 既有入边零新边——§18.5 维持）；检索质量如实披露（弱查第十五轮[q1 弱偏有效 + q2/q3/q4 弱 + q6 三次 429 + q6b 429 + q7 垃圾] + **七主源直读**[m1 CPython ceval.c 119,958B + m1b bytecodes.c 268,227B + m2 Lua lvm.c 61,763B + m2b ldo.c 40,717B + m3 Wasmtime pulley 75,598B + m4 BEAM beam_emu.c 21,112B + m5 OCaml interp.c 41,171B]；**失效件多件如实登记**[usenix VEE'05 PDF ×3 + Wiley doi 403 + langdev Cloudflare + kiv.zcu.cz 仅索引 + lua.org 论文 404 + archive.org 超时——K131 以片段级证据弱锚承载]——存档 tool-results/r68-search/ **14 文件**实体入库[磁盘实测：查询落盘 7{q1-q5/q6b/q7} + 主源 7]）；TD 开放项 0 维持（连续三十轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十八轮）；实施基线 v0.38.0 = 六命令全绿 + test **1201:0:0** + audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列**带内且 B2/B5 显著改善**（B2 −13.0%{EXC-3 域主账} + B5 −12.6% + B4 确定性计数逐位一致 + B3 保持 §9.67 改善）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域——谱系 27 段后无钦定候选；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.70 编译器降级与指令发射域前沿对照与常量驻留/补簿/槽位统一（v9.36——第六十九轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.70 勘察基线与节引言


> 勘察基线 v0.38.0 @ 6515ad6——管道审查谱系第二十八段开面：编译器降级与指令发射域（§9.69.8「候选 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域」的用户常设指令[全管道数据结构与算法选型对照前沿]开面——谱系对照实证：§9.49.3「后端侧逐域审查表」勘察于 v0.20.0[r50 时点，十九轮前/十八个版本前]，此后该 crate 经 §9.52 Symbol 单池/§9.56 诊断单源/§9.58 单池统一/§9.63 限额治理/§9.68 检查器工作状态多轮横切改造，**降级/发射算法面[指令选择/跳转缝合/常量池驻留/槽位分配]从未专审**）。域范围 = kerf-compiler crate 全量：compile.rs（1023 行 47 函数——发射/补簿/驻留/槽位/闭包协议/翻译主循环）+ bytecode.rs（191 行——数据形状与 span_of 消费面）+ opcode.rs（277 行——24 操作数与 pops/pushes 单源表）+ verify.rs（422 行——结构双 pass + DAG 深度传播）+ error.rs（414 行——诊断族，§9.56 已审维持）。**与 §9.69（VM 执行算法面）互为生产者-消费者对**：本域为指令流与池的生产者，§9.69 为执行者。


### 9.70.1 域面盘点与发现聚合（勘察实录）

**十面全量精读**（期望零猜测第三十轮）：①发射面（`emit()` 单点——pops/pushes 深度算术 + StackUnderflow 先序防御 + debug_info 自动记账[§19.3 不变量 3]）②跳转补簿面（**[改前] `jump_sources: HashMap<usize, i32>` 与 `unpatched: Vec<usize>` 双平行结构**：emit_jump 双插入 + patch 的 `position()` O(pending) 扫描 + `Vec::remove` O(n) 移位 + HashMap 索引查找三重成本；release 态非占位补簿路径 = 无消息索引 panic；jump_sources 条目补簿后永不清理）③常量驻留面（**[改前] `ConstKey` 镜像类型 + `const_key` 深克隆探测**：每次驻留探测全额深克隆 String/递归 Box Pair——引用数据结构每次出现付全额克隆；ConstKey 为 LiteralValue 池语义[NaN 单槽 + ±0.0 分槽]的手工镜像第二表示 = 漂移隐患）④全局驻留面（intern_global Symbol 键 + first-use 插入序——§9.52 单池纪律在位）⑤槽位面（**[改前] `alloc_local` 单调递增永不复用**：FuncProto 文档明载「let-form slots are allocated monotonically, never reused」——兄弟作用域槽位累积而非峰值；VM `Frame::new` 每调用 `vec![Value::Nil; n_locals]` = 每调用成本随累计绑定数增长）⑥局部查找面（lookup_local Vec 反向扫描——最内绑定胜出 = 遮蔽语义）⑦闭包协议面（begin_closure cur_stack LIFO + end_closure 精确恢复——0.5/0.6 缺陷修复在位；params 先占 0..params）⑧翻译主循环面（expr_inner 九臂：Literal/Var/Fn/Apply/If 尾与非尾双形态/Assign Dup-前置/Let let* 序/Perform/Handle 非尾——§19.3 陷阱 1/2/3 契约全在位）⑨产物面（finish 防御 + Bytecode{funcs/consts/globals} + verify 双 pass 第二防御层）⑩入口面（compile 深度-1 halt 形 + compile_program 声明序深度-0 + last_span 锚传递——冷启动锚为唯一合成 span）。**发现聚合三**：F1 常量驻留键深克隆 + ConstKey 双重表示（探测全额克隆 + 池语义镜像第二表示——§2.3 唯一可信数据源精神违反面）+ F2 跳转补簿双平行结构 + O(pending) 三重扫描（HashMap+Vec 并行记账 = 每跳转双结构维护 + 补簿路径三重成本）+ F3 let 槽位单调分配永不复用（累计制 vs 峰值制——VM 每调用帧分配成本随累计绑定数增长）。**维持面盘点四**：lookup_local Vec 反向扫描（§9.68 CHK-8 rustc Rib 同纪律先例——HashMap 化反破坏位置可见性切片）/ 无窥孔超级指令（W-VM-SUPERINSTR 登记窗零信号——本域不重开）/ Apply 求值序 args-then-callee（§19.3/§19.5 冻结契约——callee-on-top via peek(n)，8 原语原则 9 核心冻结）/ verify BTreeSet+VecDeque DAG 传播（确定性结构 + 终止性论证在档——无回边产物 DAG 假设 + 手工构造环终止双论证）。


### 9.70.4 实施清偿（v0.39.0）

一文件主实施 + 一数据形状注释 + 一集成守卫：crates/kerf-compiler/src/compile.rs（EMI-1：same_const_slot 谓词 + const_hash FNV-1a + HashMap<u64, Vec<u32>> 桶索引 + ConstKey/const_key 退役；EMI-2：emit_jump b 槽驻深 + patch 哨兵成员资格/清零归约 + finish 代码序占位扫描 + jump_sources/unpatched 退役；EMI-3：free_slots 字段 + alloc_local 先弹 + locals_truncate split_off 归还 + 三内联守卫 const_pool_pred_carries_slot_identity_end_to_end[±0 分槽 + NaN 折叠 + String/Pair 内容去重 + first-use 序] + let_slots_reuse_across_sibling_scopes[兄弟作用域同槽复用 n_locals=1 + 遮蔽异槽 n_locals=2] + patched_jumps_restore_the_zero_operand_contract[嵌套 If 三跳全补簿 + b 全零 + 目标界内]）+ crates/kerf-compiler/src/bytecode.rs（FuncProto.n_locals 文档更新——峰值制语义注记）+ tests/v0/stage0/plan/vm_seed_tests.rs（跨阶段集成守卫 sibling_scope_slot_reuse_runs_correctly_on_the_vm[全管道 reader→expander→compiler→VM：pick 双分支兄弟 let 复用单槽 + r1/r2/r3 值正确性 + pick proto n_locals=2{参数+1 复用槽}——**首测自纠实录：bool 条件字面量 #t/#f 替换 Int 条件[TypeMismatch 先序拒绝]**）。防御测试适配二：codebuf_unpatched_jump_defense_fires_at_finish（unpatched.contains 断言 → 指令流哨兵断言——错误证人 at 值不变）+ codebuf_patch_depth_assertion_defense（行为不变——期望深度改由 b 槽承载）。版本面共变族：Cargo.toml 0.38.0→0.39.0 + ds08 版本金链 +1（历史链 26 条）+ RELEASE_NOTES v0.39.0 条目 + README Status（版本面共变完整入 feat——r63 教训延续）。**六命令全绿 + test 1201:0:0 → 1205:0:0（+4 = 四守卫精确）+ audit 200/200 + doc 告警 1 维持{cargo#6313 登记}**；B 系列重跑（§14.6.4 规则 5 触发面[kerf-compiler src 触碰]履行）：B1/B1a/b/c 带内 + B2 带内{v0.38.0 −13.0% 改善保持} + B3 带内{§9.67 −34.3% 改善保持} + B4 gc-cycles 1 + swept 1023 确定性计数逐位一致 + B5 带内——全轴带内（EMI-1/2 为编译期优化 + EMI-3 帧槽缩减对 fib 工作负载[单 let 绑定无兄弟作用域]零影响——预期带内，实测带内）。


### 9.70.5 语义面与回归账目

管道面变更 = 编译器内部数据结构与簿记形态（**零语义变化**：EMI-1 池输出逐位不变[谓词语义 = ConstKey 语义逐位镜像——NaN/±0/String/Pair 守卫钉扎] + EMI-2 终产物指令流逐位不变[b 清零恢复「未用槽恒 0」契约——守卫钉扎] + EMI-3 槽号分配变化但存/取语义不变[同名解析经 locals 名表反向扫描不依赖槽号——VM 集成守卫值正确性钉扎 + 回边自由论证成文]）；求值序契约零触碰（EMI-6 维持）；golden 面唯一触碰 = ds08 版本黄金（0.38.0→0.39.0 历史链 +1——金程序无兄弟作用域 let 故其余 golden 零 churn 实证）；gate B 透明性核查（expander_parity.rs gate_b_bytecode L1158-1195 直读：oracle 与 .krf 重建双侧经同一 Rust 编译器编译——编译器内部分配变化对 gate B 透明，T09/T10/U2/U3/U5/V02 全数存活实证）；语料 79 维持（双引擎 parity 全数存活）；selfhost 三件零触碰；8 原语不变性第四十三轮验证（编译器降级与指令发射域：语法面/展开行为/VM 指令面[24 操作数零变化]/执行语义零变化，执行产物经 79 语料 parity + audit 200 重放钉扎）。


### 9.70.6 阶段间推进与禁入重申（r69 第十七次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r68 十六次重申 + **r69 第十七次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.9→v2.10 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T47 编译器降级与指令发射域审查开面即实证）。


### 9.70.8 收敛口径

8 原语不变性第四十三轮验证（编译器降级与指令发射域：编译器内部数据结构与簿记形态变更——预哈希免克隆驻留 + 补簿自携带 + 槽位 LIFO 自由表，语法面/展开行为/VM 指令面/执行语义零变化）；零新外部依赖（kerf-compiler 既有入边零新边——§18.5 维持）；检索质量如实披露（**弱查第十六轮——全七查询弱/失败 = 谱系最弱查询轮[q1/q2/q5 弱 + q3/q6 垃圾 + q4 429 未落地 + q7 三次 429 未落地]**；**七主源直读**[m1 Lua lcode.c 52,986B + m1b lparser.c 56,363B + m2 CPython compile.c 259,653B + m3 rustc unhash.rs 872B + m4 rustc_span symbol.rs 88,000B + m5 Lua lobject.h 22,720B + m6 V8 baseline-compiler.cc 116,044B]；零失效件——主源直读全量命中；存档 tool-results/r69-search/ **12 文件**实体入库[磁盘实测：查询落盘 5 + 主源 7——q4/q7 429 未落盘如实登记]）；TD 开放项 0 维持（连续三十一轮）；语料 79 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第六十九轮）；实施基线 v0.39.0 = 六命令全绿 + test **1205:0:0** + audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列**全轴带内**（EMI-1/2 编译期优化无专属测量轴[W-EMI-COMPILE-AXIS 登记] + EMI-3 帧槽缩减对 fib 工作负载零影响——预期带内实测带内；B2/B3/B5 前轮改善全保持 + B4 确定性计数逐位一致）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域——谱系 28 段后无钦定候选；管道生产者-消费者对双侧已清偿[§9.69 执行侧 + §9.70 降级侧]；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.71 Reader 词法与解析域前沿对照与扫描零拷贝/溢出收口/字面量定位统一（v9.37——第七十轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.71 勘察基线与节引言


> 勘察基线 v0.39.0 @ 1ac1f96——管道审查谱系第二十九段开面：Reader 词法与解析域（kerf-reader crate 全量 1453 行五文件：lexer.rs 600[扫描循环/原子收集/字符串运行/分类] + parser.rs 377[递归下降/深度帽/错误先序] + token.rs 116[token 数据形状] + error.rs 318[错误族与位置面] + lib.rs 42[两相入口]；期望零猜测第三十一轮——全量精读含内联测试）。**开面证据（沿 §9.64-§9.70 方法论的谱系对照实证 + 长龄面识别）**：§9.44 十二行表 reader 行勘察于 v0.15.0 = **24 个版本前/54 轮前**——此后该 crate 的全部触碰均为横切修复（§9.58 InvalidSymbol wrap + lexer 错误透传顺带修复 / §9.52 单池适配），**扫描/分类/错误三面从未域审**；§9.46 为 Stage 1.5 自举设计供给轮（双 Reader parity 设计面）非实现审计；对照同管道前端族审查频度（expander 三段专审 §9.47/§9.65/§9.66 + syntax §9.66 + core §9.44 行 + §9.64 模块面），reader = **前端生产者-消费者对的滞后侧**（消费侧 expander 三清而生产侧零专审——与 §9.69/§9.70 后端对双侧清偿形成结构对照）。


### 9.71.1 域面盘点与发现聚合（勘察实录）

**十面全量精读**（期望零猜测第三十一轮）：①主循环/分派面（lex 双相循环 + skip_trivia 先行 + next_token 八臂分派——括号/引号/拒绝集/原子四分）②trivia 面（Unicode 空白 + BOM 任意位宽容[文档化+测试钉扎] + `;` 行注释逐字符扫描）③原子收集面（**[改前] 逐字符 `peek_char`{每次 `source[pos..].chars().next()` = 切片边界检查 + Chars 迭代器构造 + UTF-8 解码} + `advance` 再算 `len_utf8` + 逐字符 `text.push(ch)` 堆分配中间 String[每原子至少一次分配]**）④字符串字面量面（逐字符 push + 五转义集 + 裸换行合法 + 未闭合起点锚）⑤分类面（`classify_atom` + `is_number_shaped`[符号/点引导数] + **发现：整数形溢出 i64 静默降级 FloatLiteral[9223372036854775808 → 9.22e18——与严格 Int/Float 类型区分[TypeMismatch 先序拒绝]在词法地板自相矛盾] + 浮点形溢出 f64 静默读作 ±inf[1e999]——§2.3-4 报错>静默违例面，无测试无文档**）⑥token 数据形状面（StxToken{kind,span} + 七类 kind + kind_name 诊断名单源——§21.12-3 Stx 前缀族）⑦解析器面（递归下降 + depth 入增出减 + 256 帽[三层帽序 256<512<1024 的地基] + 错误先序确定性[最内未闭合优先/空应用先于外层未闭合/深度入口计]）⑧错误面（10 变体 + offset() 六定位四载荷[**发现：InvalidBool/MalformedNumber 的 offset()=None → 驱动渲染无定位行——`1.2.3` 在大文件中需手动寻找；reader 为唯一 offset-only 层（expander/compiler/runtime 均携带真实 span）——rustc 对同族错误下划线整个字面量全域**]）⑨parity 消费面（RS-1 单源 token 表注入 + lexer/parser 层分流[lexer 拒绝源不经 .krf 层] + 错误轴 parity 键 = Display + `@ byte`）⑩入口面（read_program 两相 + 显式再导出清单 §10.1 规则 4）。**发现聚合三**：F1 扫描器热路径三重成本（per-peek 重切片 + per-原子中间 String 分配 + 逐字符推进——B1a read 轴 1.4µs 的结构成本）+ F2 数字字面量静默回退族（整数溢出静默降级浮点 + 浮点溢出静默 ±inf——严格类型语言在词法地板的两个静默洞）+ F3 字面量错误族无位置（四载荷变体中两变体拒绝完整原子却无任何定位面——诊断 UX 缺陷对照 rustc 全域下划线惯例）。


### 9.71.4 实施清偿（v0.40.0）

一 crate 主体 + 驱动消费面 + 语料扩展：crates/kerf-reader/src/lexer.rs（RDR-1：peek_byte/is_ascii_terminator/字节循环四置换 + 零拷贝切片 + 字符串运行拷贝；RDR-2：is_integer_shaped + classify_atom 四臂分流[整数形 i64-else-IntOutOfRange / 浮点形 f64-三臂{inf→FloatOutOfRange/Ok→Float/Err→MalformedNumber}]；RDR-3：span 线穿 + 六内联守卫[byte_scan_token_stream_is_pinned_on_a_rich_fixture 混合宽度钉扎 + unicode_whitespace_separates_and_comments_swallow_non_ascii + rejects_i64_overflow_integer_literal 双符号面 + rejects_f64_overflow_float_literal 双符号面 + maximal_literals_parse_exactly{i64::MAX/MIN + f64::MAX 含含界} + underflow_rounds_to_zero_and_stays_legal{1e-999→0.0 + 5e-324 次正规} + spelled_floats_above_i64_stay_floats{逃逸拼法}]）+ crates/kerf-reader/src/error.rs（变体族四载荷 span + 两新变体 + token_span() + Display 两新消息 + 偏移分组测试重构 + token_span 守卫）+ crates/kerf-reader/tests/api_tests.rs（公共路径溢出面守卫 + 载荷断言 span 化）+ crates/kerf-driver/src/diagnostic.rs（from_read 三级优先 + literal_family_renders_its_whole_token_span 守卫 + 全变体映射表扩至十二变体）+ examples/audit/stage0_gate_audit_r1.rs（I10 升级[#q 全域定位 + 真无定位面切至 NestingDepthExceeded] + R10 升级[合法极值 Debug 文本面 + r10c 溢出拒绝面]——**审计集跟随被审面：200 计数不变，两案例前提随被审行为更新**）+ tests/v0/stage0/plan/{reader_seed_tests.rs[载荷 span 断言化], snapshot_seed_tests.rs[ds11 渲染黄金三连——malformed/int-overflow/float-overflow 全域 caret]} + tests/v1/stage1/plan/{reader_parity_tests.rs[float_extremes 前提重写{f64::MAX/-0.5/1e-999} + literal_overflow_faces_reject_on_the_lexer_layer 新守卫], expander_parity_tests.rs[语料分层计数 6/73→8/73], subset_corpus_tests.rs[表项 +2]} + tests/v1/stage1/corpus/{neg-054-i64-overflow-literal.krf, neg-055-float-overflow-literal.krf}（**语料 79 → 81**——负向 +2，分布阈值全过）。版本面共变族：Cargo.toml 0.39.0→0.40.0 + ds08 版本金链 +1（历史链 27 条）+ RELEASE_NOTES v0.40.0 + README Status + performance-baseline.md §2 r70 重跑表刷新。**六命令全绿 + test 1205:0:0 → 1219:0:0（+14 = 守卫族精确）+ audit 200/200 + doc 告警 1 维持{cargo#6313 登记}**；B 系列重跑（§14.6.4 规则 5 触发面[kerf-reader src 触碰]履行）：**B1a 1.1µs −21.4%{域主账——RDR-1 实施收益}** + B1 7.3µs −5.2%{复合承载读轴} + B1b 3.5µs/B1c 1.5µs 逐位带内{未触碰面零扰动} + B2 75.597ms 带内{§9.69 −13.0% 保持} + B3 6.956ms +2.6% 环境噪声带内{§9.67 −34.3% 保持} + B4 gc-cycles 1 + swept 1023 确定性计数逐位一致 + B5 75.356ms 带内{§9.69 −12.6% 保持}。


### 9.71.5 语义面与回归账目

管道面变更 = 三层：扫描层（**token 流字节同一性**——既有 600 行词法测试族[种类+span 逐位断言]全绿 + 混合宽度夹具新钉扎 = 语义冻结证明）+ 分类层（**接受面收窄**：两溢出面从静默值变拒绝——语料 81 + selfhost 三件 + ds 金链全数不含溢出字面量[grep 勘证：最大数字载荷 = bnd-001/002 的 i64::MAX/MIN 精确值]，合法程序接受面零变化[含界值 i64::MAX/MIN/f64::MAX/下溢/次正规全钉扎]）+ 诊断层（字面量族渲染从无定位行升级全域 caret——ds11 黄金三连钉扎；其余错误渲染逐位不变[ds01-ds10 全绿]）。求值序/展开行为/VM 指令面/执行语义零触碰（8 原语不变性第四十四轮验证——语法面收窄为文档化裁定 + 执行产物经 81 语料 parity + audit 200 重放钉扎）；parity 面：lexer 层拒绝不经 .krf 层[RS-1 层分流]故新变体零 parity 扰动 + 树轴全绿 + selfhost 三件零触碰全过；gate B 透明（T09/T10/U2/U3/U5/V02 全数存活）；TD 开放 0 维持（连续三十二轮）。


### 9.71.6 阶段间推进与禁入重申（r70 第十八次）

**Stage 2 实施入口 = ⛔ 显式禁入维持**：r54 首发 + r55-r69 十七次重申 + **r70 第十八次重申**（三点登记：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.10→v2.11 / 本节）。解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续（本轮 T48 reader 域审查开面即实证）。


### 9.71.8 收敛口径

8 原语不变性第四十四轮验证（Reader 词法与解析域：扫描字节分派零拷贝 + 溢出面 fail-closed + 字面量族全域定位——token 流字节同一性钉扎 + 接受面收窄文档化 + 诊断面升级，求值序/展开行为/VM 指令面/执行语义零变化）；零新外部依赖（kerf-reader 既有入边零新边——§18.5 维持）；检索质量如实披露（**弱查第十七轮**[q4 强 + q3 弱-中 + 五垃圾]；**七主源直读**[m1 rustc_lexer cursor.rs + m1b rustc_lexer lib.rs + m2 rustc_lint builtin.rs{目标迁移如实登记} + m2b rustc 1.98.1 本地实证探针 + m3 Lua llex.c + m4 V8 scanner.cc + m5 CPython pegen.c + m6 Go spec]；存档 tool-results/r70-search/ **14 文件**实体入库）；TD 开放项 0 维持（连续三十二轮）；语料 79 → **81**（31 pos + 38+2 neg + 10 bnd）+ selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十轮）；实施基线 v0.40.0 = 六命令全绿 + test **1219:0:0** + audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列**B1a −21.4% 域主账 + 全轴带内**（B1 −5.2% 承载 + B1b/B1c 逐位带内 + B2/B3/B5 带内前轮改善全保持 + B4 确定性计数逐位一致——§14.6.4 规则 5 履行 + performance-baseline.md §2 刷新）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域——**前后端生产者-消费者对双侧均已清偿[§9.69/§9.70 后端对 + §9.66/§9.71 前端对]**；谱系 29 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.72 语法树与核心 IR 表示域前沿对照与共享字符串链/身份去重统一（v9.38——第七十一轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.72 勘察基线与节引言


> 勘察基线 v0.40.0 @ 084d374（沙箱重置轮——GitHub 分发仓库最新 commit ecf3e1a [Pack B v0.40.0 orchestration] 导入 + 工具链 1.98.1 重装 + git 基线重建；六命令冷跑复现 1219:0:0 + audit 200/200 逐位一致后开面）——管道审查谱系第三十段开面：**中段表示层域**（kerf-syntax 全 crate 831 行[expr.rs 395 StxDatum/SyntaxObject + scope.rs 175 ScopeSet + phase.rs 111 + error.rs 113] + kerf-core/src/expr.rs 713 行[CoreExpr/LiteralValue/Binding/HandlerClause] + 消费面追踪[expand.rs 字面量双跳 + transformer.rs 模式字面量 + compile.rs 常量池驻留 + value.rs from_literal + builtin.rs read-line/write-line + 双 parity 装解码点]；期望零猜测第三十二轮——全量精读含内联测试）。**开面证据（沿 §9.64-§9.71 方法论的谱系对照实证 + 长龄面识别）**：§9.44 十二行表 syntax 行与 core 行勘察于 v0.15.0 = **25 个版本前/56 轮前**——此后两层的全部触碰均为横切改造（§9.52 String→NonZeroU32 载荷置换 / §9.58 孪生退役与单池落位 / §9.65 EXP-4/5 错误载荷池条目化 / §9.69 EXC-1 pair_cells 单源化），**表示选型面从未域审**；§9.50 冻结层收口重审（v0.21.0）为「层本体零变更」勘证轮非选型审计；对照管道两端专审频度（前端 reader §9.71 + expander §9.47/§9.65/§9.66；后端 compiler §9.70 + vm §9.69 + runtime §9.53/§9.69），**中段表示层 = 前后端双侧清偿后仅存的未专审层族**——Stx 为 reader 的产物/expander 的输入，CoreExpr 为 expander 的产物/compiler+typecheck 的输入，是管道一切域共享的中央表示。


### 9.72.1 域面盘点与发现聚合（勘察实录）

**十面全量精读**（期望零猜测第三十二轮）：①Stx 骨架面（StxDatum 六变体——Symbol 池条目[§9.52 后] + Int/Float/Bool 内联 + **String 堆分配载荷** + List(Vec<SyntaxObject>) 逐子包装[§7.3.6 选择 A：S-expr 骨架 + 逐节点增强]）②四元组面（span 必填非 DUMMY[TD-004] + ScopeSet 逐节点[含非标识符原子] + Phase 逐节点 + 检查构造器族[Symbol 构造 Result + 四个不可失败构造器]）③着色原语面（with_scope_added 深功能翻转——**[发现] self.clone() 整子树深克隆[O(子树)] + add_scope_deep 递归；七调用点[expand.rs 300/384/392/432/441 绑定形态 + 568 模块 + 690 def-site]——嵌套 let 链最坏 O(深度×子树)**）④ScopeSet 面（sorted Vec + binary_search 插入/成员 + union 克隆-插入循环 + is_subset_of O(n·log m)——**[发现] union 零生产消费者[仅测试行使]；is_subset_of 两处 = ctx.rs 148/189 解析热路径**）⑤Phase 面（两级冻结 + 检查解码 fail-closed + 相位闭包为展开器不变量非数据层职责——文档化分工）⑥CoreExpr 面（九变体冻结[TD-005] + span 内嵌变体[rustc 对照 = 结构包装 span 字段] + Box/Vec 子结构 + kind_name/visit_spans 双镜像族）⑦字面量载荷面（**[发现] LiteralValue::String(String) 四跳全拷贝链：reader 堆 String → StxDatum → [expand.rs:131 s.clone() 字节克隆] LiteralValue → [compile.rs:303 value.clone() 字节克隆] bytecode consts → [value.rs:260 v.clone() 每次物化字节克隆 + vm.rs:313 locals[slot].clone() 每次局部装载字节克隆]——每字符串字面量 ≥3 次编译期拷贝 + 每物化/每装载 1 次运行期拷贝**）⑧构造器地板面（fn_ 符号验证→去重扫描 + handle 子句去重——**[发现] 两处 HashSet<&str> 文本哈希键 = §9.68「全程无文本键工作状态」闭合声明的两处残余[冷路径但原则违反]；§9.65 EXP-4 注记「扫描跑在驻留身份上」而实码 as_str() 文本键**）⑨模式字面量面（transformer.rs AtomDatum::Str(String) + 281 v.clone() 模式解析克隆 + 334 内容等值匹配）⑩消费面盘点（read-line 唯一运行期字符串生产者[builtin.rs:258] + write-line 渲染 + eq? 内容等值 + 18 内建零字符串变异原语[变异不存在 = 共享表示的前提] + 双 parity 装解码[expander_parity 447/471/830/1100 + reader_parity 282/398] + typecheck 字面量型分配[infer.rs:577 模式匹配零载荷消费]）。**发现聚合三**：F1 字符串字面量四跳全拷贝链（每跳分配+memcpy——对照 rustc/Lua/oxc 三工业实现零拷贝面）+ F2 构造器去重文本键残余（身份基座链闭合声明的两处例外——冷路径原则违反）+ F3 着色原语深克隆（O(子树)×O(深度)——Racket 模型价格 vs 持久共享表示的权衡面）。


### 9.72.4 实施清偿（v0.41.0）

五 crate 载荷置换 + 构造面 + 守卫族：crates/kerf-syntax/src/expr.rs（SYN-1：StxDatum::String(Rc<str>) + 构造器 Into 化）+ crates/kerf-core/src/expr.rs（SYN-1：LiteralValue::String(Rc<str>) + SYN-2：双 HashSet<Symbol> 去重 + 两处测试构造 .into() 化）+ crates/kerf-expander/src/transformer.rs（AtomDatum::Str(Rc<str>)）+ crates/kerf-vm/src/value.rs（Value::Str(Rc<str>) + from_literal 克隆语义自动降为计数）+ crates/kerf-vm/src/builtin.rs（read-line Rc::from 包裹唯一分配）+ crates/kerf-driver/src/{expander_parity,reader_parity}.rs（四点 as_str() → &**s 解引用改写[rc 上 str::as_str 不稳定面规避]）+ expand.rs/compile.rs 零源码变更（s.clone()/value.clone() 语义自动从字节克隆变为计数递增——**载荷置换的涟漪收敛实证：四跳链中三跳源码零改动**）。守卫 +3（compile.rs 池别名钉扎[consts[0] Rc::ptr_eq 原字面量 + 同串单槽] + value.rs 物化别名钉扎[双物化 ptr_eq + 字面量 ptr_eq + 内容等值正负] + value.rs 布局钉扎[size_of::<Value>()==24——回归 String 形态即失败] + 根树 expander_seed_tests reader→expander 链别名钉扎[展开字面量 ptr_eq reader 原子]）+ compile.rs 既有测试内嵌四断言。版本面共变族 v0.41.0 十件（Cargo.toml + ds08 金链 +1[28 条] + RELEASE_NOTES + README Status + performance-baseline §2 r71 刷新 + 本节 + 附录 G v38 + roadmap v2.12 + stage-2-plan r71 注记 + worklog T49 条目）。


### 9.72.5 语义面与回归账目

**零行为变化实证**：1219 存量测试全数存活（Display/Debug/PartialEq 内容语义——Rc<str> 与 String 逐字节同构）+ 语料 81 全数存活 + selfhost 三件（116/741/558）金链存活 + fixpoint 门 B 存活（parity 判定面 Display 文本——载荷表示透明）+ audit 200/200。**表示面变化**：三表示 32→24B（Value/LiteralValue/StxDatum——操作数栈与帧局部槽乘此尺寸）+ 四跳链三跳自动降为计数递增（expand/compile/materialize/load-local 的字符串成本从 O(len) 拷贝到 O(1) 计数）+ read-line 唯一运行期生产者包裹。**8 原语不变性第四十五轮验证**（表示域：字符串载荷共享化 + 去重键身份化——语法面/展开行为/VM 指令面[24 操作数零变化]/执行语义/求值序零变化；执行产物经 81 语料 parity + audit 200 重放钉扎；gate B 透明：Rc 载荷在 Display 判定面不可见）。


### 9.72.6 阶段间推进与禁入重申（r71 第十九次）

Stage 2 实施入口 ⛔ 显式禁入维持（r54 用户句首【禁止进入 stage2】+ r55-r70 十五次重申 + **r71 第十九次重申**——解除判据不变 = stage-2-plan.md §0 第 3 条句式清单 + 行权轮十项全绿前置；非永久否决——「禁止冻结」并行，阶段间轮继续）。本轮三点落位：stage-2-plan §0[Status 行 + 门表第 4 行 + 注记尾] / roadmap v2.12 / 本节。


### 9.72.8 收敛口径

8 原语不变性第四十五轮验证（语法树与核心 IR 表示域：共享字符串链 + 身份去重——表示置换零语义变化）；零新外部依赖（std::rc::Rc = std 面非新依赖——§18.5 维持）；检索质量如实披露（弱查第十八轮 + 八主源直读[rustc tag 1.98.0 三件 + oxc 三件 + Racket + Lua + V8 + 本地同版本 std rc.rs]；存档 r71-search/ 19 文件实体入库）；TD 开放项 0 维持（连续三十三轮）；语料 81 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十一轮——含沙箱重置项[远端第 ecf3e1a 可达 + Pack B 导入基线重建]）；实施基线 v0.41.0 = 六命令全绿 + test **1222:0:0**（+3 守卫）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列全轴带内（编译轴持平或更优[B1 7.3→7.1µs / B1c 逐位一致] + VM 轴 +6-7.5% 新沙箱环境归因带内[fib 零字符串：SYN-1 不在路径] + B4 确定性计数逐位一致——§14.6.4 规则 5 履行 + performance-baseline.md §2 r71 刷新）。**中段表示层清偿 = 管道表示三段终态**（前端 §9.71 reader + 中段 §9.72 syntax/core + 后端 §9.69/§9.70——表示域谱系闭合）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查[eval.rs 内建分派面 = §9.44.3 第 7 行 + §9.49 后端表 v0.20.0 双重滞后候选]或用户点名域；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.73 求值器内建分派域前沿对照与分派单源化（第七十二轮 · 阶段间实施轮）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.73.1 域面盘点（十面全量精读 + 发现聚合）

开面证据（双重滞后实证——worklog 49-pkg 钦定首位候选域）：§9.44.3 十二行深审表第 7 行（dispatch 行）勘察于 v0.15.0 = 26 版本前，§9.49.3 后端逐域审查表（runtime/eval 行）勘察于 v0.20.0 = 21 版本前；此后该域全部触碰均为横切改造（§9.67 NB-1/NB-5 键化与预驻留 + §9.69 EXC-1/EXC-2 物化批处理 + §9.72 SYN-1 Rc<str> 载荷），分派面本体从未域审。域面 = kerf-runtime/src/eval.rs 1184 行（invoke 双臂 + call_builtin 18 臂 + reserve/reserve_exact/collect_now）+ kerf-vm/src/builtin.rs 354 行（Builtin::ALL 注册表 + 8 共享语义函数 + builtin_symbol OnceLock）+ vm.rs invoke/call_builtin 孪生 + parity.rs 126 行（parity_repr 结构键 + assert_parity）+ 消费面（driver run_parity 值/输出/全局三面 agreement + runtime_seed_tests dual_run 23 站点 + parity_contract_tests 期望契约）。十面盘点：①分派路由形状（双引擎 18 臂 match ×2 文本重复）②arity 检查位置（invoke 前置双写）③语义体单源性（8 共享函数——0.7 起零漂移构造）④注册表形态（Builtin::ALL (变体,名,arity) 三列行）⑤种子面（VM 按 bytecode globals 名单 from_name / Evaluator 无条件全 18——文档化对偶）⑥求值序与根纪律（Apply/Perform temp-root 每参克隆）⑦观察面（global(&str) 线性扫 + global_sym 身份面）⑧深度守卫（EVAL_DEPTH_LIMIT 2048 Rust 栈帽）⑨name()/arity() 派生（Builtin::ALL 线性扫）⑩parity 机器（dual_run + 语料 81 子集 + 三方名称表系统化）。发现聚合六：**F1 分派行为 parity 系统守卫缺口**（名称表三方 parity 自 0.7 系统化[stage0_globals_three_way_parity_is_official 循环 18 项]但行为对拍仅抽查——dual_run 23 站点 + 语料子集[eq? 语料 0 文件由 dual_run 承载；cdr/>=/>/<= 各 1 文件]——单引擎臂漂移检测为偶发性非确定性）+ **F2 arity 检查与 18 臂路由双写**（vm.rs:607-613+647-675 与 eval.rs:483-492+504-532 各写两遍——语义体已单源但路由形状未单源，§9.69 EXC-1 孪生 walker 退役同族）+ **F3 vm.rs:645 注释漂移**（"builtin_ops" vs 实际模块名 builtin——R4 文档面）+ F4 种子面不对称（文档化对偶维持）+ F5 temp-root 每参克隆 load-bearing（invoke 期间 reserve→collect 根保护必需——split_off 优化会破坏 §19.4 根不变量，勘证后维持）+ F6 name()/arity() 线性扫描（单源派生纪律 + 冻结注册表界 O(18)）。爆炸半径核查：8 原语不变性 = 注册表冻结（零新内建至 Stage 2 库窗——穷尽 match 使加臂 = 编译期双引擎强制同步）+ RuntimeError 共享（双引擎错误 Display 同构 = 行为 parity 可断言）+ parity_repr 已覆盖 Builtin 不透明形态 + audit 200 重放钉扎（分派行为透明）。


#### 9.73.4 实施清偿（v0.42.0）

主实施四文件 + 守卫双测 + 存档：builtin.rs（BuiltinHost + dispatch_builtin 两新面 + §9.73 注记族）+ vm.rs（impl BuiltinHost for Vm + invoke 内建臂简化 + 孪生退役 + 注释漂移顺修）+ lib.rs（显式再导出 +BuiltinHost +dispatch_builtin——§10.1 规则 4）+ eval.rs（impl BuiltinHost for Evaluator + invoke 臂简化 + 孪生退役 + 导入面收缩九项）；runtime_seed_tests.rs（DISPATCH_PROBES 18 行 + 正负双系统测）；r72-search 存档 14 文件入 tool-results/。自纠实录二（探针拼写 false→#f[lexer.rs:312 布尔拼写实证] + &Builtin 比较修正）。版本面共变族完整入 feat 提交 c73a5ff（Cargo.toml 0.41.0→0.42.0 + ds08 金链 29 条 + RELEASE_NOTES + README Status + performance-baseline §2 r72）。


#### 9.73.5 语义面与回归账目

8 原语不变性第四十六轮验证（内建分派域：arity 检查与路由单源化——语法面/展开行为/VM 指令面[24 操作数零变化]/执行语义/求值序/错误族[RuntimeError 载荷与 Display 逐字节不变——负向守卫 18 面钉扎]零变化）；1222 存量全数存活 + 语料 81 + selfhost 三件 + fixpoint 门 B 全数存活；audit 200 重放钉扎（分派行为透明）。实施基线 v0.42.0 = 六命令全绿 + test **1224:0:0**（+2 = 守卫族精确）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列（§14.6.4 规则 5 履行[kerf-vm/kerf-runtime src 触碰]）：B1 7.0µs median 持平 + B1a 1.0µs/B1c 1.5µs **逐位一致** + B1b 3.5µs 带内 + B2 81.257/80.498ms 双跑{r71 环境带内 ±1%——单态化分派经 invoke 热路径零回归实证} + B3 7.500/7.318ms 双跑{**EVL-1 实施轴**：单态化 dispatch_builtin 经 eval 热路径——r71 环境带内} + B4 gc-cycles 1 + swept 1023 确定性计数逐位一致 + B5 81.541/80.216ms 双跑带内 + performance-baseline.md §2 r72 刷新。


#### 9.73.6 r72 禁入第二十次重申

r54 用户句首【禁止进入 stage2】+ r55-r71 十九次重申 + **r72 第二十次重申**（本轮）：Stage 2 实施入口 ⛔ 显式禁入维持——解除判据不变 = §9.54.3 显式句式清单 + 行权轮十项全绿前置（stage-2-plan.md §0 Status 行 + 门表第 4 行 + 注记尾三点落位）。非永久否决：「禁止冻结」并行——项目处于活跃开发期，阶段间实施轮按用户常设指令继续推进（通解优先，§2.1.1-4）。


#### 9.73.8 收敛口径

8 原语不变性第四十六轮验证（内建分派域：分派单源化——零语义变化）；零新外部依赖（BuiltinHost/dispatch_builtin = kerf-vm 内部面扩展——§18.5 维持）；检索质量如实披露（弱查第十九轮 + 七主源直读[Lua 两件 + CPython 两件 + BEAM + rustc + V8]；存档 r72-search/ 14 文件实体入库）；TD 开放项 0 维持（连续三十四轮）；语料 81 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十二轮——含远端不可达项[GitHub 404/403 无凭据，沿 T49 先例如实登记；本轮用户常设指令五条不含远端替换项]）；实施基线 v0.42.0 = 六命令全绿 + test **1224:0:0**（+2 守卫）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列全轴带内（B1a/B1c/B4 逐位一致 + VM/eval 轴双跑带内 + 单态化零 vtable 成本实测确认——§14.6.4 规则 5 履行 + performance-baseline.md §2 r72 刷新）。**内建分派域清偿 = 双引擎行为 parity 从抽查升格系统化**（§9.44.3 第 7 行 + §9.49.3 双重滞后候选清偿）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或未专审消费面复查或用户点名域——谱系 31 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.74 驱动 parity 机器域前沿对照与单源 harness 核心裁定（第七十三轮 · r73 · Task 51 · v0.43.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.74 勘察基线与节引言


> 定位：B 型前沿审查轮（用户常设指令③「全管道全方位审查」承接——§9.73.8 下一入口候选「未专审消费面复查」的落位域）。审查对象 = **driver parity 机器三件族**（kerf-driver/src/parity.rs 650 行 + reader_parity.rs 657 行 + expander_parity.rs 1619 行 = 2926 行 + 消费面 pipeline.rs 的 ParityReport/run_parity 段）——双引擎等价性 oracle 的生产代码载体。实施先于成文（51-c → 51-d——文档-代码同步纪律 §8.4.5）。


#### 9.74.1 域定位与勘察面（期望零猜测第二十一轮）

**开面证据（四重旁审史——从未主审）**：① §9.49 后端逐域表（勘察 v0.20.0）driver 域明注「本轮仅审管线接线与 parity 面」——parity 面为消费面追踪级；② §9.60 驱动编排域（v0.29.0）全量精读 pipeline.rs 798 行——不含 parity 三件本体；③ §9.62 用户表面域（v0.31.0）精读 cli/repl/render/main 四文件——不含 parity；④ §9.57 测试基础设施元域只审 tests/ 树——**生产代码中的验证器（双引擎一致性唯一 oracle）从未作为主审域**。此后全部触碰均为横切改造（§9.55 parity 键连锁修正 + §9.64 MOD-1 解码器单池 + §9.65 EXP-1/2/4/5 载荷重建 + §9.72 SYN-1 Rc<str> 涟漪 + §9.73 消费面追踪）——域本体逐版本滞后累积。

逐文件全量精读（勘察基线 v0.42.0 @ 9076a4f）：parity.rs 650 行（Expectation 六形态指令文法 + validate 双臂 + halt_report 值/警告双断言 + runtime_rejection_report 四臂 + parse_directive + same_set + 单测 8）+ reader_parity.rs 657 行（RS-1 token 表注入 + RS-3 双正规化器 + RS-2 reconstruct_error 五 kind + RS-4 run_dual + reader_parity_with 两轴判定 + 单测族）+ expander_parity.rs 1619 行（EX-1 flat pre-order 记录流 + MX-2 装配源 + reconstruct_expand_error 十三 kind + 孪生 run_dual + run_dual_rich + rebuild_item/expr/lit 门 B 重建器 + gate_b_bytecode 轴 (a) + expander_parity_with 三层分流 + 双测试模块）；消费面 pipeline.rs ParityReport 三面 agreement + run_parity + parse 三段（§9.73 已旁审段复核维持）。消费面追踪：reader_parity_tests 17 + expander_parity_tests 27 + parity_contract_tests 14 = 58 直接测试 + stage_exit_tests + audit example（门 B 消费）+ 语料 81 期望契约。

**发现聚合八**：**F1 双引擎驱动三重孪生**（reader_parity::run_dual 426-459 + expander_parity::run_dual 858-891 逐行孪生[仅 host 名/消息词/decode 三差异] + expander_parity::run_dual_rich 1112-1151 第三重[result 克隆 + rebuild_items]——三处共享 Session→parse→typecheck→compile→Vm→run→global("result")+decode→Evaluator→eval→decode 六步骨架 ~110 行重复 + 孪生 decode_verdict ×2 ~48 行[tag 解析 + ok/err 分派同形]——**§9.73 EVL-1 dispatch_builtin 孪生退役直系同族**：语义体已单源[dump/rebuild 各自独立]但驱动形状未单源）+ **F2 reader_parity matched 两臂形态不对称**（511-516：Tree 臂构造临时 `KrfVerdict::Tree(oracle_text.clone())` 走 PartialEq vs Error 臂直接 `error_parity_key(err) == oracle_text`——同语义两形状 + 一次多余 clone；expander 侧 1267-1272 已是统一 krf_text 形态——单侧滞后）+ **F3 type-error 多同码 multiset 语义零行使**（same_set = sort 无去重 = multiset 比较——语料 12 type-error case 全部单码/异码，同码重复路径零行使；typecheck 批收集不短路[§9.44.3 第 11 行]使同码多 span 完全可能[两处 (+ 1 #t) 型位点]——表达力在但路径未走）+ **F4 value 形态隐含零警告契约未文档化**（halt_report expected_warnings=None → warnings.is_empty()——`expect: value X` = 值 + 零警告双断言，指令文档未声明——fail-closed 方向安全但语料作者心智模型不完备）+ F5 模块负例经 expand-error 形态承载（from_module → DiagnosticCode::Expand tag——neg-018/019/020/048/049 五案设计在案——维持）+ F6 halt 路径无 stdin 输入面（expect 六形态无 input 形态——read-line 语料级 parity 由 runtime_seed_tests dual_run 23 站点承载——文档化对偶维持）+ F7 runtime_rejection_report 第四臂 drift 措辞单侧（同码双拒场景「rejected at X before execution」只述单侧——P3 措辞精度）+ F8 ParityReport 三面 agreement 机器维持（§9.73 旁审 + §9.73 EVL-3 DISPATCH_PROBES 已系统化——维持面）。

**爆炸半径核查**：8 原语不变性第四十七轮验证面（parity 机器 = driver harness 面——零语法/零原语/零 opcode/零执行语义触碰）+ 消费面 58 测试 + stage_exit + audit 全数钉扎（重构行为逐字节不变由 1224 存量承载）+ B 系列 driver 触碰全轴重跑义务（gate B 经 parity 机器——驱动形状变化必须证明零回归）+ 双引擎 parity oracle 地位（重构不触碰判定逻辑只单源化驱动形状——判定面 agrees/text/matched 全数维持）。


#### 9.74.4 实施清偿 v0.43.0（提交 19225d9）

三文件 + 守卫 + 语料 + 版本面：reader_parity.rs（KrfVerdict<E> 泛型化 + decode_tagged + drive_dual_engines + run_dual 委托 + matched 单源）+ expander_parity.rs（本地 KrfVerdict 退役 + decode_verdict/run_dual/run_dual_rich 三退役为委托[RichDualRun 类型别名] + 导入面收缩六项）+ parity.rs（CorpusCase 双约定段 + 守卫 +2）+ neg-056 语料 + 表登记 + 层计数 74 + ds08 版本链 31 条 + RELEASE_NOTES v0.43.0 + README Status + performance-baseline r73 行。自纠实录三（泛型参数名 Vm 遮蔽 kerf_vm::Vm → VmOut/EvOut；双 cfg(test) 模块 use 加错位置 → 移至 macro_parity_tests；层计数断言 73→74 同步）——全部当轮闭环。


#### 9.74.5 语义面与回归账目

8 原语不变性**第四十七轮**验证（parity 机器域：harness 层驱动形状单源化——语法面/展开行为/VM 指令面[24 操作数零变化]/执行语义/求值序/错误族零变化；1224 存量全数存活 + 语料 82 + selfhost 三件 + fixpoint 门 B 全数存活）；六命令全绿：fmt 零 diff / clippy -D warnings 零告警 / build 0/0 / **test 1227:0:0**（+3 = 守卫 2 + 语料 1）/ doc 告警 1{cargo#6313 登记} / **audit 200/200**；B 系列（§14.6.4 规则 5 沿伸精神——driver 触碰）：**B1 7.2/7.1µs 双跑持平 + B1a 1.0µs 逐位一致 + B1b/B1c 带内/逐位级 + B2 首跑 85.0ms 环境冷启动离群→双跑第二跑 81.4ms 回归 r72 带内{判定 = 环境噪声 + 带内} + B3 7.431/7.435ms 双跑带内 + B4 gc-cycles 1/swept 1023 逐位一致 + B5 81.446/81.405ms 双跑带内**——PAR-1 单态化零回归面：driver 触碰面在 B5 e2e 轴带内 = 驱动重构零成本实测确认；R8 编码面：触碰 .rs 文件 CJK 扫描清零；TD 开放 0 维持（连续三十五轮）。


#### 9.74.6 r73 禁入第二十一次重申

Stage 2 实施入口 ⛔ 显式禁入维持（r54 用户句首【禁止进入 stage2】登记 + r55-r72 十八次逐轮重申 + **r73 第二十一次**）——解除判据不变 = §9.54.3 句式清单 + 行权轮十项全绿前置；非永久否决，「禁止冻结」并行——阶段间轮继续推进常设审查指令。


#### 9.74.8 收敛口径

8 原语不变性第四十七轮验证（parity 机器域：驱动形状单源化——零语义变化）；零新外部依赖（drive_dual_engines/decode_tagged = kerf-driver 内部面——§18.5 维持）；检索质量如实披露（弱查第二十轮 + 七主源直读[GCC sourcebuild.texi + rustc compiletest runtest.rs/common.rs + wasmtime differential.rs + v8 testsuite.py + proptest book + rustc tests/ui README]；存档 r73-search/ 15 文件实体入库）；TD 开放项 0 维持（连续三十五轮）；语料 81→82 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十三轮——含远端不可达项[GitHub 404 无凭据 + API 404 + clone 认证失败三通道实测；本轮用户常设指令含远端替换项——凭据缺失无法执行，Package A/B 落盘 download/ 待凭据恢复，如实登记]）；实施基线 v0.43.0 = 六命令全绿 + test **1227:0:0**（+3）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列全轴带内（B1a/B4 逐位一致 + B2 双跑第二跑带内 + B3/B5 带内——§14.6.4 规则 5 沿伸精神履行 + performance-baseline.md §2 r73 刷新）。**parity 机器域清偿 = 双引擎等价 oracle 的驱动面单源化 + 期望契约双约定显式化**（§9.49 消费面级旁审 → §9.74 主审域清偿）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或用户点名域或剩余横切面复查——谱系 32 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.75 自举桥域前沿对照与 harness 输入包络裁定（第七十四轮 · r74 · Task 52 · v0.44.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.75.1 域定位与勘察面（期望零猜测第二十二轮）

用户常设指令点名清单（span/syntax/core/symbol/reader/expander/compiler/vm/runtime/driver/typecheck/**bootstrap bridge**）中唯一从未主审的管道阶段：selfhost 三件族（reader.krf 116 行 / expander.krf 741 / macro.krf 558）+ 宿主装配桥（token_table_prefix + forms_stream_prefix + assembled_expander_source MX-2 拼接 + drive_dual_engines 双引擎驱动 + gate B 双口径）+ 消费面（reader_parity_tests 375 行 + expander_parity_tests 534 行 + subset_corpus_tests 312 行 sweep）。旁审史：§9.46-§9.48 三段构建轮（RS-*/EX-*/MX-* 分段设计——构建面非审查面）+ §9.74 PAR-1 harness 核心单源化（消费面级触碰）+ selfhost 三件历来仅作 parity 锚负载（"selfhost 三件全数存活" 逐轮重放）——**桥本体从未主审**。勘察开面即活体证据：新沙箱（ulimit -s 8192KB）冷跑六命令于 `mp7`（512 层展开镜像测试）栈溢出中止——上一沙箱较大栈限掩盖的未包裹深递归测试 × 环境栈限差异，正是本域主题（harness 栈/深度包络隐式无守卫）的第一实证。


#### 9.75.4 实施清偿 v0.44.0

kerf-driver/src/reader_parity.rs（harness_run_failure 分类器 + drive_dual_engines 全失败路径前缀单源 + 双 decode 边界补缀 + 文档注释双类契约）+ kerf-driver/src/expander_parity.rs（caller 直传 + run_dual_rich 文档行同步）+ tests/v1/stage1/plan/{reader,expander}_parity_tests.rs（五处 deep_stack 包裹 + envelope_stack/wide_* 生成器 + 四包络守卫 + oracle_pipeline_accepts + gate B corpus sweep）+ tests/v0/stage0/plan/snapshot_seed_tests.rs（ds08 版本金链 0.43.0→0.44.0——历史链 31 条）+ Cargo.toml/Cargo.lock 0.44.0 + RELEASE_NOTES v0.44.0 头段 + README Status（v0.44.0 前置 + r74 重申链 + 谱系 §9.75）+ performance-baseline.md §2 r74 重跑表 + worklog 根侧五条目回补 + tool-results/r74-search/ 9 文件入库。自纠实录三：① decode 前缀遗漏（上述 BST-2）② 探针栈预留 4GB→1536MB ③ fmt/clippy 三处（doc_lazy_continuation 空行 + useless_format×2 + 行宽）当轮修正。


#### 9.75.5 语义面与回归账目

8 原语不变性**第四十八轮**验证（自举桥域：harness 消息面 + 测试树包裹 + 守卫新增——语法面/展开行为/VM 指令面/执行语义/求值序/错误族零变化；1227 存量全数存活 + 语料 82 + selfhost 三件 + fixpoint 门 B 全数存活{corpus sweep + gate B 扩面全绿——重建路径 corpus 级行使};audit 200 重放钉扎）；六命令全绿：fmt 零 diff / clippy -D warnings 零告警 / build 0/0 / **test 1232:0:0**（+5 = 包络守卫 4 + gate B sweep 1——包裹五处零计数变化）/ doc 告警 1{cargo#6313 登记} / **audit 200/200**；B 系列（§14.6.4 规则 5 沿伸精神——driver 触碰）：**双跑全轴带内**——B1 7.3/7.1 + 7.1/6.9µs + **B1a 1.0µs 逐位一致** + B1b 3.6/3.5 逐位级 + B1c 1.5/1.5 + 1.5/1.4 带内 + B2 80.839/80.660 + 80.759/80.323ms（r73 81.4ms 带内微优）+ B3 7.327/7.320 + 7.322/7.320ms 带内 + **B4 gc-cycles 1/swept 1023 逐位一致** + B5 80.669/80.436 + 80.622/80.386ms 带内——BST-2 消息面重构零回归面（B5 e2e 轴实测确认）；R8 编码面：触碰 .rs 文件 CJK 扫描清零。


#### 9.75.6 r74 禁入第二十二次重申

Stage 2 实施入口 ⛔ 显式禁入维持（r54 用户句首【禁止进入 stage2】登记 + r55-r73 逐轮重申 + **r74 第二十二次**）——解除判据不变 = §9.54.3 句式清单 + 行权轮十项全绿前置；非永久否决，「禁止冻结」并行——阶段间轮继续推进常设审查指令。


#### 9.75.8 收敛口径

8 原语不变性第四十八轮验证（自举桥域：harness 分类/守卫/包裹——零语义变化）；零新外部依赖（harness_run_failure/envelope_stack = kerf-driver 内部面 + 测试树——§18.5 维持）；检索质量如实披露（弱查第二十一轮 + 五主源直读[stage0-posix README + CPython _json.c + CPython json/decoder.py + Go cmd/dist/build.go + wasmtime differential 复用]；存档 r74-search/ 9 文件实体入库——三 404 占位弃除不留档）；TD 开放项 0 维持（连续三十六轮）；语料 82 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十四轮——含远端不可达项[GitHub clone 认证失败 + API 404 + 无 gh CLI/token 三通道实测；本轮用户常设指令含远端替换项——凭据缺失无法执行，Package A/B 落盘 download/ 待凭据恢复，如实登记]）；实施基线 v0.44.0 = 六命令全绿 + test **1232:0:0**（+5）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列双跑全轴带内（B1a/B4 逐位一致——§14.6.4 规则 5 沿伸精神履行 + performance-baseline.md §2 r74 刷新）。**自举桥域清偿 = harness 输入包络的位点分类 + 测量括号 + gate B 全语料化**（§9.46-§9.48 分段构建 + §9.74 harness 核心 → §9.75 桥域主审清偿——用户点名清单十一阶段全主审完毕）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或用户点名域或剩余横切面复查——谱系 33 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。



---

## 9.76 门 B oracle 编码域前沿对照与 per-arm arity 全量化裁定（第七十五轮 · r75 · Task 53 · v0.45.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.76.1 域定位与勘察面（期望零猜测第二十三轮）

定位：B 型前沿审查轮（用户常设指令③「全管道全方位审查」承接——十一阶段全主审完毕后横切面候选域的首位落位）。审查对象 = **门 B oracle 的编码面**（`dump_oracle_*` Rust ADT 编码器族 vs `dump_krf_*` 运行时 Value 编码器族 + `rebuild_*` 重建解码器族 + `reconstruct_*_error` 结构化拒绝重建器——kerf-driver/src/expander_parity.rs 1571 行 + reader_parity.rs 753 行中的解码子面）。开面证据（两重旁审史）：① §9.74 PAR-1 单源化了标签文法与双引擎驱动（decode_tagged + drive_dual_engines）但记录载荷解码器族本体「双编码器分离维持」；② §9.75 BST 维持-5 明注「dump/rebuild 双解码器」为维持面——**编码面本体从未作为主审域**。域选面前置事实：本轮沙箱整体重置（kerf 仓库从 Pack B v0.44.0 终包恢复 @ 734 entries/sha256 c0cd07ef 校验一致 + Rust 工具链全新安装 1.98.1）——53-a 基线核验先行：六命令冷跑全绿（fmt 0 diff / check 0-0 / clippy -D 0 / build / **test 1232:0:0 完整复现**——BST-1 deep_stack 包裹在 8MB 栈限新环境生效 + audit_case_inventory 守卫绿 = 200/200 组成钉扎 + doc 告警 1{cargo#6313 登记}) + B 系列五轴新工具链首录全带内（B1 7.4µs / B1a 1.1µs / B1b 3.6µs / B1c 1.5µs / B2 80.7-81.2ms / B3 7.33ms / B4 gc 1/swept 1023 **逐位一致** / B5 80.6ms）+ 登记窗全窗信号核对全零 + 远端三通道重测（GitHub API **403**[r73/r74 为 404——通道仍不可达新形态] + clone 认证失败 + 无 gh CLI——凭据缺失如实登记，两包已落盘 download/）→ 域选面裁定（ARCH-A）：登记窗全零 + 用户点名清单已清偿 → 横切面复查候选首位 = gate B oracle 编码面（§9.74/§9.75 两度旁审 + Stage 2 自举验证机承重面 + 旁审史最厚）。

逐函数全量精读（勘察基线 v0.44.0 @ 08837dd 树恢复态）：expander_parity.rs 解码子面（dump_oracle_item/expr/lit 三函数 90 行 + dump_krf_item/expr/litval 三函数 220 行 + rebuild_items/item/expr/lit 四函数 200 行 + reconstruct_expand_error 十三 kind 75 行 + krf_name/static_form/make_span/gen_span 辅助）+ reader_parity.rs 解码子面（dump_krf_node 六 kind 50 行 + reconstruct_error 五 kind 30 行 + value_elems/as_str/as_i64/parse_span/decode_tagged 辅助 60 行）+ 消费面追踪（decode_verdict ×2 + run_dual/run_dual_rich + gate_b_bytecode 轴 (a) + expander_parity_with 三层分流 + 语料 82 期望契约 + r74-search 全语料 sweep 消费）。


#### 9.76.4 实施清偿 v0.45.0

主实施两文件 + 守卫双模块 + 存档：kerf-driver/src/reader_parity.rs（need_fields 单源辅助 + dump_krf_node 五叶臂守卫 + reconstruct_error nesting 臂守卫 + oracle_totality_tests 模块三测）+ kerf-driver/src/expander_parity.rs（dump_krf_expr/item/litval 二十臂守卫 + rebuild_item/expr/lit 三臂守卫 + reconstruct_expand_error 十二臂守卫块化 + oracle_totality_tests 模块八测）；tests/v0/stage0/plan/snapshot_seed_tests.rs（ds08 版本金链 0.44.0→0.45.0——历史链 32 条）；Cargo.toml/Cargo.lock 0.45.0 + RELEASE_NOTES v0.45.0 头段 + README Status（v0.45.0 前置 + r75 重申链 + 谱系 §9.76）+ tool-results/r75-search/ 9 文件入库（README + 查询 4[q1/q3/q4/q5——q2/q2b 双 429 未落盘如实登记] + 主源 4[pp.rs + Outputable.hs + reprlib.py + serde de/mod.rs]；K167 r73 复用不入库）。自纠实录三：① reconstruct 臂族表达式体→块体改造的括号失衡（cargo fmt 解析错定位 → 十二臂块化重写）② litval 截断电池 len-0 位（record([]) = 裸 Nil = 合法字面量非截断记录——电池起点改 1 并注释成文）③ SER-3 首版 kind_name 期望表直写记录标签（`lit`）与 ADT 实际（`literal`）失败——分歧本身即发现：唯一标签分歧显式钉扎入测试（防第三拼法）。


#### 9.76.5 语义面与回归账目

零语义变化：全部 30 守卫位于错误路径（合法记录的解码输出逐字节不变——1243 全数存活含语料 82 + selfhost 三件 + 门 B 全语料 sweep + audit 200 组成）；8 原语不变性**第四十九轮**验证（oracle 编码域：守卫/测试——零原语零语法零子集冻结面触碰）。性能账目：need_fields = 一次长度比较（亚纳秒级），happy-path 不可观测——B 系列五轴全带内（B4 计数器逐位一致 1 cycle/1023 swept）。测试账目：+11（正向 2 / 负向 9——本轮增量正负比 1:4.5 ≥ 1:3）；全量 **1243:0:0**（1232 + 11）+ audit **200/200**。


#### 9.76.6 r75 禁入第二十三次重申

Stage 2 实施入口 ⛔ 显式禁入维持（r54 登记 + r55-r74 逐轮重申 + **r75 第二十三次重申**——本轮用户消息再次以【禁止进入 stage2】句首 + 条件句复述；解除判据不变 = stage-2-plan §0 第 3 条句式清单 + 行权轮十项全绿前置）。阶段间轮继续实证：本轮 T53 oracle 编码域审查开面（十一阶段全主审完毕后的横切面首域）。


#### 9.76.8 收敛口径

8 原语不变性第四十九轮验证（oracle 编码域：per-arm 守卫 + totality/对齐测试——零语义变化）；零新外部依赖（need_fields = kerf-driver 内部面 + 测试树——§18.5 维持）；检索质量如实披露（弱查第二十二轮[双 429 + 三弱一强] + 四主源直读 + K167 复用；存档 r75-search/ 9 文件实体入库）；TD 开放项 0 维持（连续三十七轮）；语料 82 维持 + selfhost 三件维持 + 每轮阻断条款十项复查全绿（第七十五轮——含远端不可达项[GitHub API 403{r73/r74 为 404 的新形态} + clone 认证失败 + 无 gh CLI/token 三通道实测；本轮用户常设指令含远端替换项——凭据缺失无法执行，Package A/B 落盘 download/ 待凭据恢复，如实登记]）；实施基线 v0.45.0 = 六命令全绿 + test **1243:0:0**（+11）+ audit **200/200** + doc 告警 1{cargo#6313 登记} + B 系列全轴带内（B4 逐位一致——§14.6.4 规则 5 沿伸精神履行 + performance-baseline.md §2 r75 刷新{新工具链 1.98.1 环境基线重录}）。**oracle 编码域清偿 = 解码面 30 臂 per-arm arity 全量化 + totality/对齐双守卫钉扎**（§9.74 旁审维持 → §9.76 主审域清偿；十一阶段全主审完毕后的横切面首域清偿——gate B 验证机的记录解码面在 Stage 2 禁入解除日即以结构化 drift 报告一切畸形记录）。下一轮入口 = 阶段间轮继续（候选域 = 登记窗信号核对[全零]或用户点名域或剩余横切面复查——谱系 34 段；Stage 2 实施入口 ⛔ 显式禁入维持——解除判据 §9.54.3）。




---

## 9.77 类型检查推断算法域前沿对照与事务化 unify 裁定（第七十六轮 · r76 · Task 54 · v0.46.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.77.1 域定位与勘察面（期望零猜测第二十四轮）

定位：B 型前沿审查轮（用户常设指令③「全管道全方位审查」承接——横切面候选域第二位落位）。审查对象 = **HM 推断引擎的算法语义面**（kerf-typecheck/src/infer.rs 2,503 行——管道最大单文件算法体：迭代 Algorithm W 任务栈 + union-find 元变量链表 + undo log + occurs 检查 + 泛化/实例化 + SCC letrec 预绑 + 效应行收集面）。开面证据（双重滞后）：① §9.68 CHK 裁定族九面明确限定「检查器工作状态域」——审的是 check/infer 双表 + LocalEntry 环境 + SCC 图 + Externals 边界的 **Symbol 键化**（数据结构身份面），算法语义从未主审；② §9.44.4 设计记录（Stage 1.3 建立时点）后 26 版本零复核——横切面谱系 26 段中无 typecheck 算法专段。域选面前置事实：本轮沙箱第三次重置（kerf 工作树从 Pack B v0.45.0 终包恢复 @ 758 entries/sha256 aba9295f 校验一致 + git 基线重建 5a4b52a + Rust 1.98.1 全新安装）——54-a 基线核验先行：六命令冷跑全绿（**test 1243:0:0 完整复现**——BST-1 deep_stack 包裹第三个沙箱 8MB 栈限再验证 + fmt 0 diff / check 0-0 / clippy -D 0 / build）+ audit **200/200** + B 五轴冷跑全带内（B1 7.1µs / B1a 1.0µs / B1b 3.5µs / B1c 1.4µs / B2 80.67ms / B3 7.45ms / B4 gc 1/swept 1023 **逐位一致** / B5 81.35ms）+ TD 开放项归零（tech-debt-register §2 空表核验）→ 域选面裁定（ARCH-A）：候选四域对比勘察——Span 表示域（增量小：TD-001/002/004 三裁定 + 结构性无 DUMMY 已覆盖）/ 运行期算术语义域（增量小：§19.5 explicitness + checked fail-closed 已裁定）/ Value 相等性域（增量小：eq_identity eqv? 双语义成文 + 零 Hash 键使用无 NaN 键缺陷面）vs **typecheck 推断算法域**（26 段谱系零专段 + 最大算法体 + Stage 2 自举重写将消费当前语义为规格基线）——后者胜出。

逐函数全量精读（勘察基线 v0.45.0 @ 5a4b52a 恢复态）：infer.rs 引擎核（Links 链表 fresh/bind/mark/rollback 四操作 + resolve_shallow hop-cap 链解析 + resolve 深解析后序重建 + occurs 迭代经链检查 + unify 工作list + generalize first-seen 量化 + instantiate 替换）+ 树走机器（Task 九相态枚举 + Machine 环境 mark/truncate + lookup 三级解析[locals 反扫 → defines 位置感知 → externals] + leave_if_cond/then/else 三相态 + apply_type 四路[ad-hoc 内建/Var 预绑/Arrow 已知/R4 镜像] + unify_args 释放纪律 + leave_fn/let/assign/perform/handle 六相态 + builtin_type 18 内建 ad-hoc 表 + bool_demanded §9.49 GATE-2 例外）+ 模块驱动（collect_info/collect_assigns 双收集 + flatten_defines + 过近似调用图 + 迭代 Tarjan SCC + pre_vars 预绑 + schemas 后绑 + resolve_annotations 终态解析）+ types.rs（Type 九变体 + TypeSchema 位置化 α-重命名渲染 + substitute 迭代重建 + EffectRow 有序去重代数）+ check.rs 镜像面（collect_table/collect_items/collect_expr 双胞胎遍历 + Table/DefineShape 载荷差异面）。


#### 9.77.4 实施清偿 v0.46.0

主实施三文件 + 守卫一文件：kerf-typecheck/src/infer.rs（unify 事务化包装 + unify_worklist 拆分 + resolve_shallow 不变量注释强化 + unify_args 释放语义注释重述 + 模块头契约文档 + 引擎契约测试四件[部分绑定回滚/occurs 零绑定/失败可重复/LCG fixpoint 属性]）；kerf-typecheck/src/check.rs（Table/DefineShape/collect_table pub(crate) 化——守卫可见性最小面）；kerf-typecheck/src/guards.rs（**新文件** cfg(test) 镜像守卫四测——代表性夹具 + 空模块 + 纯语法项 + 检测力臂）；kerf-typecheck/src/lib.rs（guards 挂载）。版本族共变：Cargo.toml/Cargo.lock 0.46.0 + ds08 金链 0.45.0→0.46.0（历史链 33 条）+ RELEASE_NOTES v0.46.0 头段 + tool-results/r76-search/ 21 文件入库（README + 查询 7[q5 429 未落盘 + q5b 垃圾如实登记] + 主源 13[rustc 六件 + rust-analyzer 一件 + GHC 一件 + OCaml 五件——btype 30,047B + ctype 254,938B + value_rec_check 47,214B + typing_recovery 两件 + unify_key/relate/snapshot/typevar/lexresolve/generalize；sparse-clone 通道首用登记]）。自纠实录一：guards.rs 首版七处 Box<CoreExpr> 缺 Box（Assign.value 载荷形态——cargo E0308 定位后逐一修复）；commit 消息重申计数笔误（25th→24th——amend 修正，文档侧为准）。


#### 9.77.5 语义面与回归账目

零语义变化：事务化 unify 在成功路径仅增一次 mark()（undo.len() 读取——纳秒级），失败路径回滚——1243 存量全数存活（语料 82 + selfhost 三件 + 门 B 全语料 sweep + audit 200 组成）；8 原语不变性**第五十轮**验证（推断算法域：事务化/守卫/可见性——零原语零语法零子集冻结面触碰）。性能账目：B 五轴全带内（B1 7.1µs / B1a 1.1µs / B1b 3.5µs / B1c 1.5µs / B2 81.61ms / B3 7.44ms / B4 gc 1/swept 1023 **逐位一致** / B5 81.18ms——事务包装在热路径不可观测）。测试账目：+8（负向 3[引擎契约族] / 属性 1[LCG fixpoint] / 守卫 4[镜像族含检测力臂]——本轮增量正负比满足 §9.4.3 分布论证：负向与属性合计 4:8 ≥ 1:3 守卫族为检测器形态）；全量 **1251:0:0**（1243 + 8）+ audit **200/200**。


#### 9.77.6 r76 禁入第二十四次重申

Stage 2 实施入口 ⛔ 显式禁入维持（r54 登记 + r55-r75 逐轮重申 + **r76 第二十四次重申**——本轮用户常设指令未含解除句式，条件句维持；解除判据不变 = stage-2-plan §0 第 3 条句式清单 + 行权轮十项全绿前置）。阶段间轮继续实证：本轮 T54 推断算法域审查开面（横切面第二域）。


#### 9.77.8 收敛口径

8 原语不变性第五十轮验证（推断算法域：unify 事务化 + 无环守卫 + 镜像守卫——零语义变化零原语触碰）。typecheck 算法域清偿 = **推断引擎的失败面从事务性纪律升格为结构性契约 + 无环不变量获属性守卫 + 双表镜像获机械对齐**；横切面谱系第二域（§9.76 oracle 编码 → §9.77 推断算法）。下一候选域评估：横切面未主审残余 = 诊断消息内容质量面（§9.56 审位置未审消息语义——弱候选）/ 错误恢复谱系面（K179 登记——Stage 2+ 窗）/**用户点名域优先**；谱系 35 段。




---

## 9.78 诊断消息内容质量域前沿对照与期望形状/被求类型裁定（第七十七轮 · r77 · Task 55 · v0.47.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.78.1 域定位与勘察面（弱查第二十五轮）

定位：B 型前沿审查轮（用户常设指令③「全管道全方位审查」承接——横切面第三域落位）。审查对象 = **诊断消息的内容质量面**：全部错误族的 Display 措辞、载荷完整性、跨阶段一致性与单源纪律——`kerf-{reader,expander,core,syntax,vm,compiler}` 六错误面 + `kerf-typecheck` E0xxx 消息族 + `kerf-driver` 渲染层（diagnostic.rs/render.rs）+ CLI/REPL 面 + selfhost .krf 记录面（十二面普查）。开面证据：§9.56（v0.25.0 诊断域审查）审的是**位置层**（DIAG-1 位置剥离 36 站点 + DIAG-4 行索引缓存），**消息内容语义面从未主审**——横切面谱系 35 段中无消息内容专段。域选面前置事实：本轮沙箱第四次重置（kerf 工作树从 Pack B v0.46.0 终包恢复 @ 767 entries/sha256 f5a51226 校验一致 + git 基线重建 1e0edec + Rust 1.98.1 全新安装 + rustfmt/clippy 组件补装）——55-a 基线核验先行：六命令冷跑全绿（**test 1251:0:0 完整复现** + fmt 0 diff / check 0-0 / clippy -D 0 / build）+ audit **200/200** + B 五轴冷跑全带内（B1 7.7µs / B1a 1.1µs / B1b 3.6µs / B1c 1.6µs / B2 80.37ms / B3 7.39ms / B4 gc 1/swept 1023 **逐位一致** / B5 80.97ms）+ TD 开放项归零核验 → 域选面裁定（ARCH-A）：候选对比——错误恢复谱系面（K179 登记态 = Stage 2+ 窗[panic-mode/sync-set 为 §9.36.8 登记理论]，零信号不开窗）/ 登记窗信号核对（全零维持）/ 用户点名域（本轮消息无新点名域——常设指令③ 由十一阶段主审 + 横切面两域清偿承接）vs **诊断消息内容质量面**（§9.56 位置/内容二分的未审半面 + 全阶段横切承重 + 有实际实施面）——后者胜出。

发现族聚合五：
- **F1 MalformedForm 零特异度**：45 处抬升点（expand.rs 36 + transformer.rs 9）折叠为单一 `malformed `X` form`——四种缺陷类（错误元数/非符号绑定位/畸形绑定规格/畸形 handler 子句——变体 doc 自认）不可区分，零期望形状。对照 K182/K183：rustc 解析面一律给出期望（`expected expression, found `;`` / `` `if` may be missing an `else` clause ``）。
- **F2 TypeMismatch 藏起被求类型**：`must be a matching kind` 空泛托辞——每个抬升点的被求种类静态已知（pair/bool/string/closure-or-builtin/同种类数值），消息却不命名。对照 K182 E0308：被求类型是类型不匹配的一等数据（`expected `bool`, found integer`——被求先行）。抬升面 = vm.rs 四 + builtin.rs 六 + eval.rs 二（共 12 生产站点）。
- **F3 ArityMismatch 复数语法缺陷 + 三站手工镜像**：`expects `1` arguments`（最常见运行期错误族上的语法缺陷）——对照 K182 E0061 单复数纪律（`takes 1 argument ... were supplied`）；且同款措辞在三处手工镜像（RuntimeError::ArityMismatch Display + typecheck R2[具名/匿名两臂] + R5[handler 臂]——code.rs 头注自认「R2 wording mirrors RuntimeError」= 约定承载非机检）。
- **F4 PhaseViolation 用户面引用内部文档**：`(docs/stage0.md §8.9 rule 1)` 出现在 CLI 渲染的消息文本中——对照 K180：rustc 深度信息在 `--explain` 与稳定错误码之后（「give an error a code if the explanation would give more information than the error itself」），从不在消息内引用内部文件路径。
- **F5 术语族 identifier/variable/global 三分**：同一解析失败族跨阶段三词（ExpandError `unbound identifier` / typecheck E0001 `unbound variable` / RuntimeError `unbound global`）——需裁定维持或统一。


#### 9.78.4 实施详情

- **十二面抬升点手位**：vm.rs（jump-if-false/car/cdr/call callee 四）+ builtin.rs（arith/compare/car/cdr/not/write-line 六）+ eval.rs（jump-if-false/call callee 二）——全部经共享常量族置换，`type_mismatch` 助手签名扩为 `(context, demanded, got, span)`。
- **守卫 +7**：根级 5（三站复数一致[单数+复数+helper] ×2 + 双引擎被求一致[jump-if-false + call callee 端到端] ×2 + plural helper ×1）+ expander 内 2（十二形名模板完备 + 引用清零）；re-bless 四处（ds02 金面被求化 / parity oracle 精确文本[tests + in-crate 双] / audit I04 措辞 + require oracle）——全部为**文档化重录，零契约变更**。
- **版本面共变族 v0.47.0**：Cargo.toml + ds08 金链 34 条 + RELEASE_NOTES + README Status + roadmap v2.18 + stage-2-plan r77 + stage0 v9.44 三面 + performance-baseline r77 行 + worklog T55 条目。
- **parity 透明性构造论证**：oracle 侧文本 = Rust `expand_program` 经 `error_parity_key`（Rust Display + span 后缀）渲染；.krf 侧判定 = 记录重建后同经 Rust Display——Display 富化双侧同变，parity 构造性成立（expander_parity_tests + in-crate error_axis 双绿实证）。


#### 9.78.5 守卫与验收

六命令 1251→**1258:0:0**（+7 守卫——负向面 6[措辞形状/一致性/引用清零] + 跨阶段消费 1[三站一致守卫消费 RuntimeError+typecheck+根管线]）+ audit **200/200**（re-bless 两处后全绿）+ B 五轴全带内（B1 7.4µs / B1a 1.2µs / B1b 3.8µs / B1c 1.5µs / B2 81.9ms / B3 7.38ms / **B4 gc 1/swept 1023 逐位一致** / B5 80.7ms——消息变更全位于错误路径，零 happy-path 成本实测）+ fmt 零 diff + clippy -D warnings 零告警 + 语料 82 维持 + selfhost 三件维持（记录文法零触碰）+ TD 开放项归零维持。


#### 9.78.6 禁入重申

**r77 禁入第二十五次重申**：Stage 2 实施入口 ⛔ 显式禁入维持（本节 + roadmap §6 + stage-2-plan §0 三点落位；非永久否决，解除判据单源不变 = stage-2-plan.md §0[显式句式清单 + 行权轮十项全绿前置]；本轮用户轮消息未含解除句式——如实登记）。


#### 9.78.8 收敛口径

8 原语不变性第五十一轮验证（消息内容域：期望形状模板 + 被求类型常量 + 复数化 + 引用剥离——零语义变化零原语触碰零记录文法变更）。诊断消息内容质量域清偿 = **malformed 族从零特异度升格期望形状单源表 + type-mismatch 族从空泛托辞升格被求类型常量命名 + arity 族从手工镜像升格机检一致 + 用户面从内部引用升格引用清零**；横切面谱系第三域（§9.76 oracle 编码 → §9.77 推断算法 → §9.78 消息内容）。下一候选域评估：横切面主审域谱系收敛——十一阶段全主审 + 横切面三域清偿后，候选 = **用户点名域优先**或登记窗信号核对[全零]或阶段间复查轮（错误恢复谱系面维持 K179 Stage 2+ 窗登记态）；谱系 36 段。




---

## 9.79 selfhost 格式整理域前沿对照与约定机检裁定（第七十八轮 · r78 · Task 56 · v0.48.0）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### 9.79.1 域定位与勘察面（弱查第二十六轮）

定位：用户点名域直承（常设指令轮内用户明示「整理格式化清晰 selfhost」——非域选面裁定，点名即域）。B 型实施轮：三件 `.krf`（reader 116 / expander 741 / macro 558，§9.46-§9.48 三段设计产物）+ 两 Rust 消费面（expander_parity.rs + expander_parity_tests.rs）为实施对象；四 tamper 锚（reader `("empty-app" ...)` / expander `(>= ex-depth 512)` 与 `(cons (ex-s nt) ...)` / macro `(set! ex-mcount 0)`）为敏感性边界。

勘察发现族三（全量普查实测）：
- **F1 破折号风格三分裂**：reader.krf 用 em-dash（5 处 = 仓库正典）；expander.krf/macro.krf 混用 ` - `（18+18 行）与 `  -  `（16+1 行）——**同一文件内两种 ASCII 旁注风格并存**；`  -  ` 另泄漏至两 Rust 消费面（expander_parity.rs 17 处 + expander_parity_tests.rs 13 处）。
- **F2 超长行离群**：macro.krf L253 **684 列** + L256 **1697 列**（单行 define 巨兽——仓库最大行宽记录）+ expander.krf L532/L684 167 列 ×2 + L422 101 列 + reader.krf L102 103 列——违 §10.5「~100 列内」六处；80-100 带状 44 行为约定内合法。
- **F3 目录无入口文档**：selfhost/（三段自举链 + 宿主约定 + MX-2 装配契约 + 四 tamper 锚敏感性 + 诚实边界）无 README——scripts/ tools/ 均有先例；消费面信息散落于 §9.46-§9.48 与两个 harness 文件头。

弱查第二十六轮披露：q1 rustfmt 注释/宽度政策 → 上游 429（serper 400/429 链）如实登记；q2 Racket style guide → 三垃圾域结果（tilde.club/jboss-list/scribd——无权威命中，题级存目不载裁定）。**锚定负载由内部正典 + 本地工具链实证承载**（K186-K188）——格式域的权威面在仓内，零外锚为诚实结论非缺口。


#### 9.79.4 实施详情

- **通道三重**：① 算法重发（`tools/selfhost/krf_reformat.py`——sexp 解析 + 风格发射器[+1 缩进/参数对齐双 profile] + 四重验证[token 流逐位 / 语法树等价 / tamper 锚连续 / 残余超宽清零]；macro 两巨兽 = 仅有的 2 行整形式）② 外科拆分（reader L102 + expander L422/L532/L684——4 条行级手术，同款树等价验证，周边手工格式零扰动）③ 一次性 sed 破折号归一（注释行限定——`^\s*//` 与 `^;` 双模式）。
- **安全性论证（QA-A 前置）**：注释非 token（lexer 剥离）+ 换行是空白 → token 流不变 → 双引擎 parity 自动一致；字节偏移双侧同源注入（token 表由 harness 对同源 lexing 生成）；256 嵌套帽不增（空白不嵌套）；四 tamper 锚均为代码串不在触碰面（预检 + 事后双核验）。
- **strip-compare 通道**：剥离注释与空白后代码文本三件逐位一致（`sed 's/;.*//' + tr -d ' \t\n'` 全程机械比对）——过程级验证先于测试级验证（首版手拆 macro 巨兽即被此通道捕获 3 字符括号差后改道算法通道 = 通道价值实录）。
- **§3.4 工具归档**：`tools/selfhost/krf_reformat.py` + `docs/tools/selfhost/krf-reformat.md`（**仓库首个自研工具落位**——tools/ 冷启动态终结；tools/README.md 同步）；`--check` 模式三缺陷自纠实录（默认宽 80→100 / check 前跑重排通道→原样校验 / `len(int)` 笔误）——check 分支无写盘设计 = 零事故。
- **行数口径**：selfhost 三件 116/741/558 → **117/750/660**（+1/+9/+102；巨兽展开 2 行→106 行为主体）；历史轮记录中 116/741/558 十七处以其时点为准（append-only 纪律，非漂移）。


#### 9.79.5 守卫与验收

六命令 1258→**1261:0:0**（+3 守卫：宽度约定 / 非 ASCII 白名单 / 旁注破折号——全负向断言族，零语料新增）；**parity / fixpoint / gate-B / determinism / tamper 全数存活**（1258 存量逐位——空白级变更的构造性无扰动实证）；audit **200/200**（零触碰）；fmt 零 diff + clippy `-D warnings` 零告警；B 五轴全带内：B1 7.3µs / B1a 1.1µs / B1b 3.6µs / B1c 1.5µs / B2 80.873ms / B3 7.374ms / **B4 gc-cycles 1 / swept 1023 逐位一致**（确定性计数不变 = 空白级变更零语义影响的最强实证）/ B5 80.776ms。


#### 9.79.6 禁入重申

**r78 禁入第二十六次重申**：Stage 2 实施入口 ⛔ 显式禁入维持（本节 + roadmap §6 + stage-2-plan §0 三面一致；解除判据 §9.54.3 确认门句式清单 + 行权轮十项全绿前置——用户显式解除前零 Stage 2 实施）。


#### 9.79.8 收敛口径

8 原语不变性第五十二轮验证（格式域：纯空白/注释面——零 token 变更零语义变化零原语触碰；strip-compare 逐位一致 + B4 确定性计数逐位一致 + 1258 存量全存活三重实证）；每轮阻断条款九项复查：谱系 37 段在场（§9.43-§9.79）+ 行动项锚维持（HM 接线 / MX-1 mangled / RS 迭代式 + 新增 FMT 守卫锚）+ TD 开放项 0 维持 + 语料 82 维持 + selfhost 三件 117/750/660（新口径）+ web 侧本轮 Task 56 系列同步 + 基准核验（六命令冷跑 1261:0:0 + audit 200/200 + B 全轴带内）+ 裁定（历史审查发现全部实施或登记维持；本轮用户点名域实施清偿；Stage 2 零实施纪律维持）。

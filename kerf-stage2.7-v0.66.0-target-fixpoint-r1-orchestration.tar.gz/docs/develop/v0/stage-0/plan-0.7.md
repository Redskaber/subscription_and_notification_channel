# Stage 0.7 子阶段计划与交付实录——kerf-runtime 标记-清除 GC + 元循环求值器种子

> **依据**：docs/sop.md §21（阶段规划）/ §4（MUV 六字段）/ §9.4.3（测试构成）/ §7.2/§7.3/§6.3（L2 外循环）
> **设计锚**：docs/stage0.md §19.4（标记-清除 GC 三阶段骨架/核心不变式三条/实现陷阱三则）+ §8.11（能力模型）+ §5.1（元循环求值器）+ §21.8 Phase 1 + stage-0-plan.md §5 行 0.7 + kerf-vm/src/error.rs L50-53（"the 0.7 collector turns this point into collect-then-retry"）+ value.rs 头注（"the 0.7 collector adds mark bits and a free list over this same shape"）+ builtin.rs 头注（"the 0.7 runtime asserts the two tables' parity"）
> **状态**：✅ 已交付（2026-09-28）——427:0:0 · 审计集 70/70 · v0.8.0

## 1. 任务构成

| MUV | 内容 | 落位 |
|-----|------|------|
| 10-a-1 | kerf-vm 演进：Heap mark 位 + free list + `Collector` trait/`Roots` 挂接面 + `charge_or_collect`（collect-then-retry）+ builtin 单源分派函数族 + `EvalDepthExceeded` 变体 | crates/kerf-vm/src/{value,roots,builtin,error,vm,lib}.rs |
| 10-a-2 | kerf-runtime 实现：`gc`（§19.4 三阶段编排 + `MarkSweep` + `GcStats`）+ `eval`（元循环九原语 + 18 builtin 单源 + 帧槽位环境 + 深度帽 + collect-then-retry）+ `parity`（结构化表示 + 断言面）| crates/kerf-runtime/src/{gc,eval,parity,lib}.rs + tests/api_tests.rs |
| 10-a-3 | 双路径互查 ≥15 程序 + STAGE0_GLOBALS 三面官方断言 + E2E 源码→值第一版（I/O parity）+ VM 注入端到端 + 负向 parity 族 | tests/v0/stage0/plan/runtime_seed_tests.rs（经 runner.rs）|
| 10-a-4 | 审计集 H 节（60→70：eval 负向 ×8 + GC 防误回收 + parity 检测器自检）| examples/audit/stage0_gate_audit_r1.rs |
| 10-a-5 | 文档族十二件 + 版本 0.8.0 + commit | docs/ + Cargo.toml |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1169 files / 164.5MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 3.51s / 10 crates） |
| `cargo check --all-targets` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example 目标） |
| `cargo test --release` | ✅ **427 passed / 0 failed**（356 基线零回归 + 71 新增：runtime 42（gc 12 + eval 22 + parity 3 + api 5）+ vm 演进 9（value 4 + vm 4 + error 1）+ 根集成 20；轮构成 19:52 = 1:2.7——偏差申报见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 70/70**（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10——新增 H10 runtime 负向节；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于 kerf-runtime 源/清单/测试 + kerf-vm 变更面 + examples = **零新增命中**（既有登记制 CJK 白名单沿袭，本轮无新增）。*.md 面豁免位不计。

**内循环实录（§5.3——诚实记录）**：R1 编译级 3（clippy int_plus_one ×2——live 判据改写 + let_and_return）；R2 **P1 实现缺陷发现**（invoke 换出 saved-env locals 不在 GC roots——递归回溯悬垂读取；发现路径 = 预算测试构造审查（drop 模式的 p 在 let 槽是活根，测试通过恰依赖错误回收）→ temp 保护修复（guard/truncate）+ §20.6 同类全量（apply/perform temp 契约 + eval_program/eval_expr 程序隔离）+ budget 测试重构为 (car (cons a b)) 链真丢弃模式）；R3 测试侧 4（GC 槽位期望值手算错位——0.3 教训同族实跑回读修正 + fib 链三元 +（0.6 固定元数语义）+ NaN 构造（0.0/inf=0.0 非 NaN——inf−inf 修正）+ Span 字段访问语法）；R4 quote 登记态边界（0.3 未实现——cons 链替代 + 0.9 议程）；R5 clippy 尾清（cloned_ref_to_slice ×2 + unused mut/var）；R6 fmt 对齐；R7 终态六命令 + audit 70/70 + Han 扫描全绿复验。**GC/eval 实现侧运行语义缺陷：P1 ×1（当轮闭环零遗留）**。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（kerf-vm 演进） | value.rs（2+2）/ error.rs（0+1）/ vm.rs（2+2） | 4 | 5 |
| 单元（kerf-runtime） | gc.rs（0+12）/ eval.rs（3+19）/ parity.rs（2+1） | 5 | 32 |
| crate API | crates/kerf-runtime/tests/api_tests.rs | 3 | 2 |
| 跨 crate 集成 | runtime_seed_tests.rs（经 runner.rs） | 7 | 13 |
| **0.7 合计** | | **19** | **52** |

- **比例申报**：轮 19:52 ≈ **1:2.7**（未达 1:3 精确线）；累计 108:319 ≈ 1:2.95。**偏差披露**：① GC 族 12 case 全数归负向（防御性质——每一项断言"不误收/不悬垂/不爆栈/不双计"，无纯正向 GC 测试）；② ≥15 parity 程序与三面断言为 stage-0-plan §5 行 0.7 的**验收标准本体**（一致性验证，不可拆为负向）；③ 错误族已穷尽（RuntimeError 十一变体在 eval 路径全负向覆盖 + 双路径错误一致性 13 case + R8 消息逐位一致断言）。凑数拆分将产生低价值测试（§12 最优>最小）。
- 集成构成（GATE 6 其余项全达标）：正向 7 ≥1 / 负向 13 ≥3 / 跨阶段消费 6 ≥1 ✅
- 净增 71（356 → 427）；七类维持 **6/7**（余 1 结构性 DEFERRED：模块循环依赖@0.9）

## 4. 设计对齐记录（§13.1——裁定与决策入档）

### 裁定七（0.7）：GC 架构——mark 位内置堆、编排注入算法、依赖倒置挂接

§19.4 伪代码的 heap 方法面（`test_and_set_mark`/`clear_marks`/`iter_objects`/`free`）落位 kerf-vm `Heap`（数据结构层），三阶段编排（显式工作栈 mark_all → sweep → 复位）落位 kerf-runtime `gc`（L7 章程）；L6 定义 `Collector` trait + `Roots` 快照面作为挂接点，L7 实现（§21.12-10② 依赖抽象——L6 不依赖 L7，算法注入）。`Roots` 在 §19.4 四类根之上增 `handlers` 字段（class-2 扩展：已装 handler 值是帧邻接状态，漏掉即悬垂——0.7 实现中发现并补全的根集第五面）。

### 裁定八（0.7）：预算安全点演进——live 计量 + collect-then-retry + 双轨计数

`Vm::reserve` 判据从 0.6 累计计数演进为 **live 占用**（frames.len() + heap.live_len()），超限时若注入 collector：snapshot_roots → 一轮回收 → 重试 → 仍超才 `BudgetExceeded`（error.rs L50-53 预告的 0.7 演进落位）；无 collector 保持 0.6 fail-closed 行为（默认构造零行为变化）。公共面 `allocations()` 保持累计语义（0.6 观察契约不变），live 判据为内部实现——双轨。eval 侧同模型（depth 即帧数）。兼容性论证：无回收时 live == 累计（heap cells 无 collector 单调、frames 弹出差异仅影响深递归后返回的程序——0.7 放行的恰是活集真低的程序，0.6 累计计费是记账粒度粗）。

### 裁定九（0.7）：eval 闭包 = 基础闭包语义 + 登记簿 + 哨兵 proto

eval 侧闭包 = `Value::Closure(HeapRef)` 身份句柄 + evaluator 侧 Rust 登记簿（params/body/name），`ClosureData{proto: EVAL_CLOSURE_PROTO = u32::MAX, env: 定义点 locals 快照}`——env dormant 与 0.6 VM 载体逐字对偶（自由词法变量回落全局，词法捕获 = Stage 1 两侧同步激活）；哨兵不可与真实 proto 索引冲突（该量级函数表在任何预算下不可达）。R1 判定：真实设计（非桩）——哨兵不变式由 api_tests 断言锚定。

### 裁定十（0.7）：builtin 语义单源分派——kerf-vm 自由函数族

18 名 STAGE0_GLOBALS 的**操作语义**（arith/compare/car/cdr/not/eq/io/cons）从 `Vm::call_builtin` 方法体提取为 kerf-vm `builtin` 模块 pub 自由函数，VM 与 Evaluator 双侧同函数体调用（零漂移由编译期保证——比 parity 测试更强的对齐）；名字/元数三面（expander `STAGE0_GLOBALS` ↔ `Builtin::ALL` ↔ evaluator 播种）由根集成测试官方断言（0.6 前置锚转正）。分配计量留调用方（cons 收 heap 但预算 charge 在各引擎 reserve——§19.4 安全点单点原则）。

### 设计决策 14 项

1. 帧槽位环境（eval）：`names` 尾扫 resolve 与 `Compiler::lookup_local` 的 `.rev().find()` 逐字对齐（shadow = 新槽位，let* mark/truncate 对偶 `locals_mark`/`locals_truncate`）。
2. 求值顺序契约（eval Apply）：args 左→右先、callee 后（§19.3 发射序逐字复刻）。
3. Assign = Dup 语义（值即表达式值）+ 局部槽优先、否则全局直写（StoreGlobal 无 unbound 检查——0.5 编译器逐字对齐）。
4. Require 零操作 + Module 递归平铺（0.5 `item()` 编译语义的 eval 对偶）。
5. Handle = 安装序求值 + body + 全弹（PopHandler n truncate 对偶；plan-0.5 决策 8）。
6. Perform = rposition 最近匹配 + handler 即函数（裁定六 eval 对偶；handler 返回值即 perform 值）。
7. `EVAL_DEPTH_LIMIT = 2048`（Rust 栈防御——eval 独有；VM 帧堆不受限；不对称边界已登记并由双路径测试锚定：depth 3000 VM 跑通 / eval 报 `EvalDepthExceeded`）。
8. RuntimeError 十一变体（新增 `EvalDepthExceeded{limit, span}`——错误集增量演进合法沿 0.5/0.6 先例；穷举测试同步）。
9. eval 中间值根保护：`temp` 栈（§19.4 "C 栈显式根"的 Rust 求值器拼写）——apply/perform 的 args+callee 入保护、invoke 由调用方守护（契约注释）。
10. **P1 缺陷修复（实现中发现）**：`invoke` 换出的 saved env locals 不在 roots → 递归回溯后悬垂读取（§19.4 根集不完备的 eval 形态）——修复：saved.locals 全量入 temp 保护（guard/truncate）；同类审查：eval_program/eval_expr 增程序隔离（env 残留清空——复用 Evaluator 跑多程序的词法污染防御）。
11. budget 测试程序模式：`(car (cons a b))` 链（cell 在 Car 弹出即死）——递归丢弃模式在帧链持有下不可构造（kerf 无循环原语），链式丢弃是 collect-then-retry 的最小实证形态。
12. parity_repr：Pair 递归点对展开 / Closure → `#<closure>`（kind 级——闭包身份非程序结果语义）/ Builtin → `#<builtin:+>`；`assert_parity` 双 heap 结构比较（地址不参与）。
13. `quote` 表面语法 = 登记态未实现（0.3 reader 无 quote 路径——0.1 LiteralValue::Pair 的 quote 消费面留待 0.9；本轮 parity 程序以 cons 链构造嵌套 pair 数据）。
14. DAG 新边 §18.5：L7→L4（kerf-core：CoreExpr/ModuleItem——eval 章程内含义）+ L7→L5（kerf-compiler：Span/Symbol 类型面——0.5 决策 14 消费面完整性先例）；零环、零外部依赖。

## 5. §7.2 防崩六问（Q1-Q6）

- **Q1 最小可运行版**：GC 三阶段 + eval 九原语 + 15 parity 程序全一致——已交付且超额（20 parity 断言族 + 12 GC 防御 + 双路径错误一致性 13）。
- **Q2 破坏性变更**：`Vm::reserve` 内部判据 live 化（公共面零变化——`allocations()` 累计语义保持，0.6 测试全绿实证）；Heap 结构私有演进（`len` 语义 live 化在无回收时与 0.6 恒等）。
- **Q3 数据结构**：`Cell{obj, mark}` + free list（§19.4 伪代码逐方法对齐）；`Roots` 五字段（四类 + handlers 扩展）；`Env` 帧槽位。
- **Q4 算法**：显式工作栈标记（10^5 深链实证零爆栈）；sweep 线性全槽；复位对称（含空槽）。
- **Q5 测试**：见 §3——427:0:0 + audit 70/70。
- **Q6 性能**：collect-then-retry 仅在软超限时触发（fib(25) 注入 MarkSweep 后 75025 不变——零语义干扰回归）；标记/清除线性于槽位。

## 6. 门审审计集构成映射（SOP §7.3.1——单调增长 60 → 70）

H 节 10 case（runtime 负向）：eval 源码级 arity×2（H01/H02 闭包面+内建面）+ type×3（H03-H05 truthy/算术异种/car）+ div-zero（H06）+ unhandled effect（H07）+ 深度帽（H08）+ **GC 防误回收端到端**（H09：紧预算丢弃程序注入 MarkSweep → collect-then-retry 跑通 + 存活值精确 16——误回收即结果损坏）+ **parity 检测器自检**（H10：异构必异 repr——检测器有效性）。七类维持 6/7（eval 路径 case-for-case 与 VM 一致——错误层 parity 实证）。

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿先例）

| 角色 | 票 | 意见摘要 |
|------|-----|---------|
| ARCH-A（×2） | APPROVE | 裁定七/八/十成立（依赖倒置干净、预算演进兼容论证完整、单源分派优于 parity 约束）；Roots handlers 扩展与 saved-env 修复属本轮关键增量 |
| DEV-A（×1.5） | APPROVE | 427:0:0 + 71 净增；P1 悬垂缺陷当轮发现当轮闭环（§20.6 同类全量：temp 保护契约 + 程序隔离）|
| QA-A（×1） | APPROVE（附条件满足）| 比例偏差 1:2.7 已申报且理由成立（GC 防御族全负向 + parity 验收本体）；集成构成全达标；深度帽不对称边界已登记 |
| ALG-C（×1） | APPROVE | eval 语义逐字对齐编译器（lookup_local/求值序/Assign Dup/basic closure dormant）；NaN/±0.0 IEEE 语义双路径一致 |
| SKL-A（不计权） | APPROVE | audit H 节可重跑；api_tests 公共面完整 |

加权 5.5/5.5 = 100% ≥ 95% ✅

## 8. TD 账面与消费契约

- **TD-003 消解**：kerf-runtime 实现（骨架余 2 → **1**：driver）。
- TD-001（P2@0.8）/ TD-006（P3 机会性）沿袭；零新增 TD（P1 悬垂缺陷当轮闭环零遗留）。
- **0.8 消费契约**（VM→Runtime→Driver）：`Evaluator::{new, with_io, with_budget, eval_program, eval_expr, global, take_output, heap, allocations, collector_cycles, collect_now}` + `MarkSweep`/`collect`/`GcStats` + `parity_repr`/`assert_parity` + `Vm::{with_collector, with_budget_and_collector, register_foreign_ref, snapshot_roots, heap_mut}`——driver 编排双引擎（管线 + 诊断渲染 + CLI）与 0.9 宏系统（CodeValue 层）的输入面。

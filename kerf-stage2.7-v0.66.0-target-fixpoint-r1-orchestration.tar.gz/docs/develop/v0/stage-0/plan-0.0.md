# Stage 0.0 子阶段计划与交付实录——冷启动引导

> **Task ID**：2-a … 2-g（flat worklog 对应条目）
> **性质**：Stage 0 首个子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L3（新阶段启动典型场景；实际代码增量集中于 kerf-span 单 crate + workspace 全局结构）

---

## 1. 任务构成

| Task ID | 内容 | 状态 |
|---------|------|------|
| 2-a | 环境引导：rustup 安装 stable + rustfmt/clippy 组件（SOP §3.1） | ✅ rustc 1.98.1 / cargo 1.98.1 / rustfmt 1.9.0 / clippy 0.1.98 |
| 2-b | 仓库引导：git init + docs/ 导入（sop.md v15.0 + stage0.md）+ §8.4.1 docs 树 | ✅ |
| 2-c | workspace 脚手架：edition 2024 + 9 crate + §18.5 DAG + default-members（§8.4.6 规则 7 落地）+ tests/runner.rs 单入口 | ✅ |
| 2-d | 种子 MUV kerf-span：§8.6 四字段模型 + 不变量 + 三层测试 | ✅（详见 §3） |
| 2-e | 规划文档族：stage-0-plan（0.0-0.11）+ tech-debt + calibration + tests 文档 + graph + worklog rec 树 | ✅ |
| 2-f | 验证与交付：§3.2 六命令 + §6.4 commit + §19 打包 | ✅（详见 §2） |
| 2-g | 沙箱仪表盘（环境侧，非 kerf 仓库 MUV）：Next.js `/` 路由只读展示 | 见 flat worklog |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，2026-09-27 实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 506 files / 19.8MiB，随后冷构建复核 0.19s/10 crates） |
| `cargo build --release` | ✅ 0 error / 0 warning |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff（exit 0） |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（修复 1 处 `len_zero` 后达成——内循环 1 轮） |
| `cargo test --release` | ✅ **48 passed / 0 failed**（32 单元 + 8 crate API + 8 跨 crate 集成） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于代码/清单/脚本面（排除 docs/、worklog、*.md）= 零命中。技术锚（§/TD/r 编号）原样保留合规。

## 3. 测试构成（SOP §9.4.3 / GATE 6）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | crates/kerf-span/src/span.rs | 8 | 24 | FP1-FP6 功能点，每点 ≥1:3 |
| crate API | crates/kerf-span/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5） |
| 跨 crate 集成 | tests/v0/stage0/plan/span_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费 2 例（token 归约模式） |
| **合计** | | **12** | **36** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2）
- §7.1.1 七类错误矩阵：**N/A（0.0 无管线）**——七类全部依赖 Reader/Expander/VM 存在；矩阵负向覆盖义务自 0.3 起逐类点亮（0.3 两类 / 0.4 两类 / 0.6 两类 / 0.9 一类），0.11 门审 7/7 全覆盖复核。此为冷启动结构性缺口（DEFERRED with reason，§9.5「近 100%」口径）。

## 4. 产物清单

- 代码：workspace 根清单 + 根聚合 crate（src/lib.rs）+ 9 成员 crate（kerf-span 完整实现，其余 8 个章程化骨架——TD-003）
- 测试：tests/runner.rs 单入口 + tests/common/mod.rs + tests/v0/stage0/plan/span_seed_tests.rs + crate 双层测试
- 文档：README / RELEASE_NOTES / docs/{sop.md, stage0.md, lang-design/README.md, build-guide.md, testing-guide.md} / docs/develop/v0/{tech-debt-register.md, calibration-data.md, stage-0/{stage-0-plan.md, 本文件}} / docs/tests/{README.md, matrix.md, v0/stage0/plan/span.md} / docs/graph/stage-0/dataflow.md / docs/worklog/{l, 00_stage-0_语义验证/} / worklog.md（flat）

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 是——8 个骨架 crate（**计划性脚手架**，非事故性桩：每 crate lib.rs 章程声明实现范围 + 挂接子阶段 + TD-003 登记；真实等级 P3（计划性）经 ARCH-A 角色确认，影响下一阶段 = 正向（它们就是下一阶段的实现载体））。kerf-span 本体无桩。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.1/0.2 直接消费 workspace 结构与 span API（集成测试已验证消费模式）；无阻断。 |
| Q3 | 端到端路径测试？ | 0.0 的「管线」= workspace 装配 + span 消费——跨 crate 集成测试覆盖该路径全量（8 case）。源码→值 E2E 自 0.7 起。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-003（骨架）为下一阶段载体本身；TD-001/002 于 0.1 无影响；**TD-004/005 已升级挂接 0.1 设计对齐首议程（届时 P1）**——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | kerf-span 为数据层 crate（无流程入口函数）；其消费入口 = 集成测试 + 未来 reader/compiler。根聚合 crate 入口（re-export 面）被集成测试调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§4 清单）。 |

## 6. 门审适配裁定（PHASE 6-1——SOP 未覆盖场景的最小合理流程）

**场景**：SOP §7.3.1 门审 ≥30 case 审计集（10 单语句 + 10 多语句 + 5 复杂程序 + 5 错误恢复）以「可编译语言源码经管线报错」为前提；Stage 0.0 无任何管线阶段，30 case 模板无承载对象。

**裁定**：0.0 门审以**现存全量测试套件**（48 case，构成见 §3）为审计集，对照模板差距如实披露：单语句负向 ✅（span 构造/谓词类）、多语句负向 ✅（join 归约链类）、复杂程序 ✅（token 归约模式）、错误恢复 ✅（错误变体独立可渲染）；「源码级语句」语义不可用（无 reader）。**≥30 case 与 7 类错误全额义务自 0.3（Reader 落地）起强制**，0.11 门审 7/7 复核——该差距属冷启动结构性事实，非流程豁免。理由记录于 flat worklog（Task 2-f 条目）。

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟）

**环境披露**：本环境无多 Agent 基础设施，五角色由同一 Agent 依各角色职责独立审查后分别投票（权重 ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1，总 5.5；SKL-A 1 不计权）。

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §18.5 DAG 精确落地；两级语义无违例；TD-004/005 已按 §6.2 升级路径登记 |
| DEV-A | ✅ 1.5 | 六命令全绿；clippy -D warnings 零告警；实现无桩（span 完整、骨架已登记） |
| QA-A | ✅ 1.0 | 48 测试 0 failed；正负比 1:3 达标；GATE 1/3/6 合规；七类矩阵缺口已按 §9.5 DEFERRED 登记 |
| ALG-C | ✅ 1.0 | span 语义与 §8.6/§12.1 一致（字节偏移制/半开区间/代次语义 ROOT=0）；原语集裁定待 0.1 正式化（不影响本轮） |
| SKL-A（不计权） | ✅ | 工具链脚本化（§3.1 归档）；runner.rs 单入口；default-members 使 §3.2 命令原文生效 |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

## 8. 遗留债务（真实等级确认）

TD-001（P2）/ TD-002（P3，0.4 升 P1）/ TD-003（P3 计划性）/ TD-004（P3，0.1 升 P1）/ TD-005（P3，0.1 升 P1）——全部有挂接子阶段与解除条件，见 tech-debt-register.md。

## 9. 下一子阶段入口

**0.1 kerf-core**：前置 = 本轮交付；首议程 = TD-005 原语集正式裁定 + TD-004 span→core 边裁定（§13.1 设计对齐，输出裁定文入 docs/develop/v0/stage-0/）。

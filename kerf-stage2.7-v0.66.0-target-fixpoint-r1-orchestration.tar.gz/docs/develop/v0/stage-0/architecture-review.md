# Stage 0 架构设计审查（architecture-review.md）

> 依据：docs/sop.md §14.6.1.2（架构设计审查：完整性 / 设计对齐 / 结构清晰性 / 效率 / 扩展性——按编译管道逐阶段）+ §14.6.6 输出文档集合
> 产出轮次：Stage 0.11 末轮（2026-09-28）
> 审查者：ARCH-A 主导（单 Agent 模拟披露沿先例）；数据输入：Task 16-b3-arch 逐 crate 采集 + docs/graph/stage-0/dataflow.md 实况 DAG
> 评分口径：✅ 优秀 / ⚠️ 需改进 / ❌ 有问题

## 1. 总体架构

**九层单向 DAG（L0→L8）实测零违规**（Task 16-b3-data §7 全量 grep）：span→∅；syntax→span；reader→{span,syntax}；expander→{core,span,syntax}；core→span；compiler→{core,span}；vm→compiler；runtime→{compiler,core,vm}；driver→{compiler,reader,runtime,syntax,vm}。VM→compiler 的 7 处引用全部为数据类型消费（Bytecode/Instr/Opcode/Span/Symbol + verify 错误型），零编译器函数调用——§11「阶段间仅数据契约」成立。模块内子依赖同样无环（driver 内部 pipeline→{diagnostic,session} 等单向）。

**蓝图对齐**（stage0.md §22.2 → 实况）：蓝图单包 src/layer0-6 + C vm/ 布局被 SOP §8.4.6（Cargo 九 crate）+ 宪制条款（VM 永久 Rust 基座——C 蓝图仅算法参照）覆盖——plan-0.0 已裁（冷启动裁定 2/3），dataflow.md 为实况事实源。蓝图 §8.12「约 35 op」vs 实现 24-op：TD 登记在案（七分组全承载 + Perform/Handle 扩展三 op），估算值非硬约束——**B2 类偏差（实现更简）**。

## 2. 逐阶段评分

| 阶段 | crate（LOC/文件） | 完整性 | 设计对齐 | 结构清晰 | 效率 | 扩展性 | 总评 |
|------|------------------|--------|---------|---------|------|--------|------|
| L0 位置 | kerf-span（565/2） | ✅ 校验构造 + join + ExpansionId 全套 | ✅ §3.3/§12.1 最小字段集逐字段兑现 | ✅ 单模块零依赖 | ✅ Copy 值类型 | ✅ ExpansionId 宏代次已为 Stage 2 预留 | ✅ |
| L1 语法 | kerf-syntax（988/6） | ✅ 四元组 + 深翻转 + 相位 | ✅ §7.3.6 逐节点包装（卫生前提） | ✅ Stx 前缀命名族 | ✅ | ✅ 加法变体路径（原则 27） | ✅ |
| L2 读入 | kerf-reader（1,469/5） | ✅ UTF-8 + 类型化 token 流 + 256 帽 + ReadError 10 变体字节定位 | ✅ §8.1 typed-token + 迭代式避免栈溢出 | ✅ lexer/parser/token 三分 | ✅ 单遍线性 | ✅ 点号语法事实已快照冻结（RS10） | ✅ |
| L3 展开 | kerf-expander（4,145/7） | ✅ 九形式 + do 脱糖 + 卫生双机制 + syntax-rules + 模块加载 + CodeValue | ✅ §19.2 不变量 + §8.10 + Racket 参照 | ✅ 六模块职责单一（expand/ctx/transformer/module/code/error） | ✅ 预算 512 fail-closed；匹配线性 | ✅ 宏注册表 + gen 单调已为多代宏预留 | ✅ |
| L4 内核 | kerf-core（3,244/14） | ✅ 九原语 ADT + ModuleItem 4 变体 + reserved 四族（r2 空间化） | ✅ §3.2 冻结集经 TD-005 语义等价映射 + §9.1.1-§9.1.4 形状逐条 | ✅ reserved/ 自含子树零入边 | ✅ | ✅ re-anchoring 加法路径（裁定十七/二十） | ✅ |
| L5 编译 | kerf-compiler（2,320/6） | ✅ 跳转回填 + 去重常量池 + 全局 intern + 逐 pc debug_info + verify 四面 | ✅ §19.3 + §12.1 消费表逐行 | ✅ compile/bytecode/verify/opcode 四分 | ✅ 线性；patch 位扫描 O(小常数) | ✅ 24-op 表驱动（pops/pushes/operand_help 三表） | ✅ |
| L6 执行 | kerf-vm（2,588/8） | ✅ 24-op 全穷尽 dispatch + 堆帧栈 + 三扩展槽 + collect-then-retry | ✅ §19.5 + §8.12 + 宪制（永久 Rust 基座） | ✅ 八模块；dispatch 单函数 | ⚠️ 见 §3（闭包整帧 locals.clone） | ✅ 帧三槽为 continuation/异常表/调试冻结 | ✅（效率项登记） |
| L7 运行时 | kerf-runtime（1,627/4） | ✅ 三阶段 mark-sweep + 元循环 eval + parity 三面 | ✅ §19.4 + §5.1 + 依赖倒置（经 vm 堆面） | ✅ eval/gc/parity 三分 | ✅ 全停顿 O(live+slots)（登记态演进窗） | ✅ Collector 注入面 | ✅ |
| L8 驱动 | kerf-driver（2,714/9） | ✅ 双引擎编排 + session intern + TD-001 收口 + rustc 渲染 + CLI/REPL | ✅ §8.7 切片 + §12.2 错误即数据（入口实测零丢弃） | ✅ 七模块 + main 薄壳依赖注入 | ✅ | ✅ run_cli 依赖注入全参数化（测试零进程 spawn） | ✅ |

## 3. 效率注记（D6 输入，非本阶段债）

1. **vm.rs:244 闭包创建 `locals.clone()` 整帧局部向量复制**——O(帧局部数)/闭包。fib 负载下无热点（快照/基线 B2 2.4µs/call 达标）；闭包密集负载的优化候选（capture 分析——只复制被捕获槽）登记为 Stage 2 优化窗（§14.5 D6 处置规则：记录不阻塞）。
2. 每 builtin 调用 2 处参数 clone（值语义必要——堆引用不可变借用穿 dispatch）。
3. 全停顿 GC：B4 实测 0.36ms/2000 分配——Stage 2+ 分代/并发演进窗（stage0.md §9.43 K7 已登记）。
4. 线性扫描三处均为观测面/常量表/小常数（global() 按名查询不在 dispatch 热路径；RESERVED_MACRO_NAMES 常量尺寸；patch 未回填表受 if 深度约束）——**production 无 O(n²)**。

## 4. 扩展性抽查

- 新 token 种类：lexer `classify_atom` 单点 + StxTokenKind 加变体——编译器强制全消费点更新（穷尽 match），零散弹。
- 新 AST 节点：CoreExpr 加变体 → 编译器/求值器/kind_name/span()/visit_spans 五点强制更新（穷尽 match 保护）。
- 新字节码指令：Opcode 加变体 → dispatch + 四表（kind_name/operand_help/pops/pushes）+ verify——单 crate 内闭合。
- 新内置函数：Builtin 加变体 + 注册表两行（name/arity）+ STAGE0_GLOBALS 单源一行——三处同 crate。
- 新能力模型（r2 空间）：实现 CapabilityModelFamily + TokenCalculus 两 trait 注册入 registry——**零框架变更**（拓展证明四位置实证）。

## 5. 结论

九阶段全 ✅；架构对齐两处口径差均为已裁定 B2 类（蓝图更旧/更繁，实况更优）；效率项 1 个登记（闭包 locals 复制——Stage 2 优化窗）；扩展性五抽查全部单点闭合。**§14.6.1.2 通过**。

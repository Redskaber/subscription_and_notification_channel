# Stage 0.3 子阶段计划与交付实录——kerf-reader 词法/语法种子

> **Task ID**：6-a（flat worklog 对应条目；前置 = R9-a tarball 替换核验——形式化 no-op，diff 归零实证）
> **性质**：Stage 0 第四子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~1100 行新代码+测试；依赖风险低——零新 DAG 边（§18.5 既有 L1→L2 消费 + L0 直依补充声明）、零新外部依赖；历史缺陷密度低——0.2 遗留零 P0/P1）
> **设计对齐**：无 TD 待裁定——14 项设计决策以 §13.1 对齐记录落入本档 §4（依据 stage0.md §8.1/§278/Week1 模块处方 + SOP §7.1.1/§7.3.1/§2.3-4/原则 23/27）

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/reader.md（FP1-4 + 预期数 + 审计集口径） | ✅ 实现前落档 |
| 实现 | kerf-reader 五模块（token/lexer/parser/error/lib）+ 双入口（lex / read_program） | ✅ |
| 三层测试 | 单元 43（11+32）+ crate API 8（2+6）+ 跨 crate 集成 9（2+7） | ✅ 60 新 case |
| §7.3.1 审计集 r1 | examples/audit/stage0_gate_audit_r1.rs（30 case：10+10+5+5，cargo run 可重跑） | ✅ 30/30 |
| TokenLike 退役 | tests/common/mod.rs 迁移至真实 StxToken（0.0 章程承诺的退役时点执行） | ✅ |
| 文档同步 | matrix（七类 2/7 点亮）/ TD 登记册 / calibration / stage-0-plan v1.3 / dataflow / RELEASE_NOTES v0.4.0 / README / rec 树 | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1137 files / 87.9MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 0.77s / 10 crates） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example 目标） |
| `cargo test --release` | ✅ **204 passed / 0 failed**（144 基线零回归 + 60 新增：单元 43 / crate API 8 / 跨 crate 集成 9；15:45 = 1:3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 30/30**（A10 单语句 + B10 多语句 + C5 复杂 + D5 错误恢复；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于代码/清单/example 面 = 唯一命中 = 登记制 CJK 白名单（lexer.rs `计数器` 夹具 + reader_seed_tests.rs `计数/数` 夹具——以 CJK 为被测对象的测试夹具，§10.5 豁免，登记于模块 docstring 注释 + reader.md §2）；实施期 4 处注释域中文（`语法对象为空`×2 / `嵌套帽` / CJK 夹具注释引用）当场清偿。*.md 面豁免位不计。

**内循环实录（§5.3——7 轮，诚实记录）**：R1 未用导入（audit ByteOffset）；R2-R5 测试侧字节偏移手算错位族 8 处（audit B01/B08/B09 + seed CJK/lambda/stray + parser `(a (b`/stray + api span/节点数——**实现侧零缺陷**：逐例追认实现行为正确，全部为测试期望值算术错误；教训入 calibration——字节偏移断言应以错误消息自身回读而非手数）；R6 比例修复（首轮实配 15:40 未达 GATE 6，补 5 个真实负向：lone hash / escape-at-EOF / 参数位空应用 / 多形式第三形式定位 / 跨 crate 中段数字 → 15:45 精确 1:3）；R7 R8 注释清偿 ×4。

## 3. 测试构成（SOP §9.4.3 / GATE 6）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | error.rs（0+5）/ lexer.rs（7+14）/ parser.rs（4+13） | 11 | 32 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-reader/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5） |
| 跨 crate 集成 | tests/v0/stage0/plan/reader_seed_tests.rs（经 runner.rs） | 2 | 7 | 含跨阶段消费 2 例（token/span/树归约 0.4 契约 + 真实 token 归约退役证明）+ InvalidSymbol 单源字典跨 crate 断言 + 错误恢复调用隔离 |
| **0.3 合计** | | **15** | **45** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（7）/ 跨阶段消费 ≥1 ✅（2）
- ≥40 门槛超配（60）；§7.1.1 七类错误矩阵：**2/7 点亮**（语法错误 = UnclosedList/UnexpectedClose/UnterminatedString/InvalidEscape/InvalidBool/MalformedNumber/InvalidSymbol/UnexpectedCharacter 族；空应用 = EmptyApplication）——余 5 类结构性 DEFERRED（未绑定标识符/宏展开深度@0.4、参数个数/类型不匹配@0.6、模块循环依赖@0.9——检测层未建；门审级 7/7 于 0.11；SOP §7.1.1 v12.5 口径注以「已存在检测层的类全点亮」冷启动代偿口径执行——plan-0.0.md §6 裁定沿袭）

## 4. 设计对齐记录（§13.1——无待裁定 TD，14 项入档）

1. **两相读取器**：lex 全量 → parse 全量（`read_program = lex + parse_program`）；流式读取延后（Stage 0 文件尺度小；优化无义务——§12 最优>最小以消费者存在为前提）。
2. **fail-closed 数字分类**：数字形开头（首位 ASCII 数字，或 `+`/`-`/`.` 紧跟数字）但 i64/f64 双解析失败 → MalformedNumber——**不做 Racket 式符号回退**（§2.3-4 报错>静默：`1.2.3`/`12abc`/`0x1F`/`1_000`/`1e` 必须报错而非静默变符号）；数字语义 = Rust str::parse（`.5`/`1.`/`1e5` 合法浮点——实配探针实证）。
3. **`()` = 空应用读期拒绝**：SOP §7.1.1 第 3 类（empty syntax object）在 reader 层点亮——空形式永不携带算子，fail-closed 拒绝而非传下游（SOP 示例检测点标注 expander；reader 先拦 = 纵深防御，0.4 展开器对合成面复检）。诚实边界：`(quote ())` 因此不可读——空表数据需求由 `nil` 字面量承载；语法层空表（StxDatum::List(vec![])）保持 API 可构造（展开器合成路径）；0.9 宏系统若需引号空表再评估加性放宽。
4. **布尔字面量 = `#t`/`#f` 精确二值**（stage0.md 语料实证——`(my-if #t 1 2)` L12253）；`#true`/`#q`/`#` → InvalidBool fail-closed（现代皮肤 `true`/`false` EBNF 属 Stage 2 目标语法——L4359，不提前实现化）。
5. **注释与 BOM**：`;` 行注释（标准 S-expr）；BOM `\u{feff}` 按空白类跳过（单规则——不可见格式字符不黏入标识符，无位置特判）。
6. **字符串面**：转义五元 `\"` `\\` `\n` `\t` `\r`；裸换行合法（Scheme 传统）；未终结（含转义符撞 EOF）→ UnterminatedString 携起始位。
7. **括号族与读取器宏字符 fail-closed**：`[` `]` `{` `}` `'` `` ` `` `,` → UnexpectedCharacter——Stage 0 皮肤无读取器宏（quote 拼写 `(quote x)`），方括号非本皮肤定界符（现代皮肤 Stage 2 加性引入）；拒绝优于静默成怪符号。
8. **未闭合报告 = 最内层**：多列表同时未闭合时报告最内（最后开、最接近输入耗尽处）`(`——确定性边界（§2.3-3）+ 最贴近错误点的定位。
9. **256 嵌套帽**：`pub const NESTING_LIMIT: usize = 256`（公开常量——测试与 audit 消费）；以进入列表计数（非 token 总量）；256 含边界通过 / 257 拒绝（双向测试 + audit C01/D04 边界对）；帽同时界定递归下降的原生栈深（对抗性深输入 = 结构化错误而非栈溢出）。
10. **相位/作用域戳**：reader 全树 `Phase::Runtime` + 空 `ScopeSet`——着色与翻转是 0.4 展开器关注点（stage0.md §9.38/§8.9；0.2 决策 ③⑥ 同族）。
11. **TokenLike 退役执行**：0.0 章程承诺的退役时点（common/mod.rs 原注释）兑现——seed 测试迁移至真实 StxToken（open_token/close_token/ident_token/int_token 助手），span 归约模式对生产 token 类型实证（测试脚手架生命周期纪律——R4 同族）。
12. **§8.1 对齐申明**：StxTokenKind = §8.1 TokenKind 的 S-expr 皮肤子集（Delimiter/Identifier/Int/Float/Bool/String/Eof；TypeIdentifier/Keyword/Operator/MacroInvocation 随 Stage 2 现代皮肤加性引入——原则 27）；token 不携带 scope_id（§8.1 模型的 scope 字段属着色期，reader 期恒空——省略而非伪造默认值）；tokenize 三保证全兑现（无损覆盖——间隙仅空白/注释测试锚定 / 精确 span / 结构化错误）；§8.1 LexError → ReadError 词法变体集映射（单一错误面，§278 能力签名）。
13. **单源字典跨层断言**：InvalidSymbol 渲染 reader/syntax/core 三层逐字节一致（error.rs 单元 + seed 跨 crate 双断言）——parity 守护前提（R8）。
14. **审计集 r1 基线**：`examples/audit/stage0_gate_audit_r1.rs`——SOP §7.3.1 规则 3 落位（可重跑 example + 根 Cargo.toml [[example]] 声明）；30 case 构成 10+10+5+5；类覆盖 2/7 点亮 + 5 类结构性 DEFERRED 披露于文件头与运行输出；逐子阶段单调增长（规则 4）至 0.11 门审 7/7。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-reader 完整实现（无桩）；剩余 5 骨架 crate 仍为 TD-003 计划性脚手架（真实等级 P3，正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.4 expander 直接消费 read_program 产树（Vec<SyntaxObject> 携 span/scopes/phase）+ visit_spans/with_scope_added（0.2 契约）；ReadError 结构化面可直接进诊断框架（0.8 收口）。 |
| Q3 | 端到端路径测试？ | 0.3 的管线 = 源码文本 → token 流 → stx 树全链（reader_pipeline 集成正例 = lex+parse+归约三段一断）——首个源码级管线入口落地；源码→值 E2E 自 0.7 起（计划不变）。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-001（0.8）/TD-002（0.4 升 P1——展期跨代 span 合并裁定即届时）/TD-006（机会性）均有挂接；TD-003 于 0.3 消解一项（余 5）——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | 双入口 lex + read_program 被 api_tests（8）+ reader_seed_tests（9）+ audit example（30 case）实际调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§1 清单）。 |

## 6. 门审审计集构成映射（SOP §7.3.1 全额口径自本轮起强制）

审计集 = `examples/audit/stage0_gate_audit_r1.rs`（30 case，`cargo run --release --example stage0_gate_audit_r1` 可重跑，exit 0）：

| 构成 | 要求 | 实配 | case 样例 |
|------|------|------|----------|
| 单语句负向 | ≥10 | 10（A01-A10） | 未闭合 / 孤立闭 / 空应用 / 未终结串 / 非法转义 / 非法布尔 / 数字形×2 / 控制字符 / 括号字符 |
| 多语句/多函数负向 | ≥10 | 10（B01-B10） | 后续形式未闭合（字节定位）/ 形式间空应用 / 引号空表拒绝 / 第三形式控制字符 等 |
| 复杂程序负向 | ≥5 | 5（C01-C05） | 257 深 / 200 深未闭合底 / 嵌套底空应用 / 嵌套底坏数字 / 宽深混合尾失衡 |
| 错误恢复 | ≥5 | 5（D01-D05） | 错→修正对（未闭合/前缀截断/空应用补算子/帽边界收缩/转义修正）——Stage 0 恢复语义 = 结构化错误 + 调用级隔离（§9.36.8 panic-mode/sync-set = 登记态，Stage 2 开窗项） |
| 七类覆盖 | 门审级 7/7 | **2/7**（语法错误 + 空应用）；5 类结构性 DEFERRED 至各自落位子阶段（0.4/0.6/0.9），文件头与运行输出披露——冷启动代偿口径（plan-0.0.md §6 沿袭），0.11 门审 7/7 复核 |

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 4-a/5-a 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §8.1 三保证逐项兑现（无损覆盖/精确 span/结构化错误）+ 皮肤子集申明（现代面零提前实现化）；`()` 读期拒绝 = SOP 第 3 类纵深防御 + 诚实边界申报；L0 直依补充（reader 用 FileId/ByteOffset——DAG 既有 L0 消费族，无新边语义） |
| DEV-A | ✅ 1.5 | 六命令全绿（冷构建 204:0:0）+ audit 30/30 exit 0；实现侧零缺陷（7 轮内循环全部为测试期望值算术 + 导入 + 比例修复 + R8 注释——逐例追认实现行为正确） |
| QA-A | ✅ 1.0 | 正负比 1:3 精确达标（15:45——首轮 15:40 未达标即补 5 真实负向，诚实实录）；GATE 1/3/6 合规；CJK 白名单登记制执行；七类 2/7 点亮 + 5 类 DEFERRED 记账 |
| ALG-C | ✅ 1.0 | 未闭合报告最内层确定性（§2.3-3）+ 帽边界双向 + 词法分类规则闭合（数字形三分支 + # 前缀 + 符号兜底）；错误载荷逐字节定位 |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭；fail-closed 全路径无静默回退；256 帽界定原生栈深（对抗输入结构化失败） |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

## 8. 遗留债务（真实等级确认）

TD-001（P2，0.8）/ TD-002（P3，0.4 升 P1）/ TD-003（P3 计划性，余 5 crate）/ TD-006（P3 机会性）。八原语 ANF 形态 = Stage 2 评估目标（登记态，零义务）。本档 §4.3 引号空表边界 = 设计边界申报（非 TD——0.9 触发式评估项）。

## 9. 下一子阶段入口

**0.4 kerf-expander**：展开 → CoreExpr（stx 树 → 九原语核）；do→Let 脱糖；深度帽（expansion_id 递增 + 上限报错）；ExpandError；**TD-002 升 P1 强制裁定**（Span::join 跨展开代合并语义）；七类错误「未绑定标识符/宏展开深度」负向全覆盖；≥40 测试；输入条件 = 0.1 + 0.2（均已满足——core 校验构造器 + stx 树契约锚定）。

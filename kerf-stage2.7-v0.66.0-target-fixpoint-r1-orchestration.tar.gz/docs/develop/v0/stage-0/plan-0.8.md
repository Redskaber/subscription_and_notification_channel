# Stage 0.8 子阶段计划与交付实录——kerf-driver 管线编排 + 诊断渲染收口 + CLI/REPL

> **依据**：docs/sop.md §21（阶段规划）/ §4（MUV 六字段）/ §9.4.3（测试构成）/ §7.2/§7.3/§6.3（L2 外循环）
> **设计锚**：stage-0-plan.md §5 行 0.8 + roadmap §6 post-0.7 首议程四项 + plan-0.7.md §8 消费契约 + docs/stage0.md §12.1（渲染期派生——TD-001 清偿锚）/§12.2（错误是数据）/§8.7（Diagnostic 结构）/§8.8（最小 I/O）+ SOP §7.1.1（七类矩阵）
> **状态**：✅ 已交付（2026-09-28）——551:0:0 · 审计集 80/80 · v0.9.0

## 1. 任务构成

| MUV | 内容 | 落位 |
|-----|------|------|
| 11-a-1 | 消费面扩展 ×3：`ReadError::offset() -> Option<ByteOffset>`（6 有位/4 载荷本体）+ `CompileError::span() -> Option<Span>`（10 有位/3 缺失即缺陷本体）+ kerf-compiler `ModuleItem` 再导出（L8 消费面完整性传递——沿 0.5 决策 14 先例） | crates/kerf-reader/src/error.rs + crates/kerf-compiler/src/{error,lib}.rs（ExpandError::span() 0.4 已预置——doc 注释「the diagnostics framework (plan sub-stage 0.8) renders locations from this payload」兑现，零改动） |
| 11-a-2 | kerf-driver 七模块：session（文件 intern + upsert）/ line_index（TD-001 行列派生）/ diagnostic（§8.7 切片 + 四阶段 41 变体映射）/ render（rustc 风格多诊断渲染）/ pipeline（Engine{Vm,Eval} 双引擎 + check + parity + globals 快照）/ repl（session-replay 状态机 + TapeIo）/ cli（run/check/repl/--help/--version + 退出码 0/1/2）+ bin `kerf` | crates/kerf-driver/src/{session,line_index,diagnostic,render,pipeline,repl,cli,lib,main}.rs + tests/api_tests.rs |
| 11-a-3 | E2E 集成 22 case（§7.1 全套：五类源可达错误类经 driver 全链 + fib 双引擎 + parity + I/O 往返 + REPL 会话 + 渲染黄金 + CLI 退出码 + CJK 字符列 + 帽序边界探针） | tests/v0/stage0/plan/driver_seed_tests.rs（经 runner.rs） |
| 11-a-4 | 审计集 I 节（70→80：五类经 driver 渲染 + 多文件多诊断 + REPL 回滚 + check 拒绝 + parity 数据化 + CJK 列 + 无位免 `-->`） | examples/audit/stage0_gate_audit_r1.rs |
| 11-a-5 | 文档族十三件 + 版本 0.9.0 + commit | docs/ + Cargo.toml |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，冷构建实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（10 crates + bin kerf） |
| `cargo check --all-targets` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example/bin 目标） |
| `cargo test --release` | ✅ **551 passed / 0 failed**（427 基线零回归 + **净 +124**：driver 内联 93[session 5 + line_index 13 + diagnostic 11 + render 13 + pipeline 15 + repl 16 + cli 18... 计 api 前口径] + api_tests 6 + 根集成 22 + reader 3 + compiler 2；轮构成 73:51 = 1:0.7——偏差申报见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 80/80**（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + **I10 driver E2E**；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 源/清单/example 面 = 仅登记制 CJK 白名单——0.1-0.3 既有三处（core/syntax symbol 计数器 + reader lexer）沿袭 + **本轮新增两处**（driver line_index/render 测试夹具——模块 docstring + driver.md §2/§5 双登记）；根集成 driver_seed_tests（名 夹具）同登记制；审计 I10 用 `\u{540d}` 转义形态（扫描面零命中）。*.md 面豁免位不计。**零未登记非英文编码面**。

**内循环实录（§5.3——诚实记录，7 轮）**：R1 编译级 11（类型再导出路径错 ×2——RuntimeError 居 kerf-vm/CompileError 居 kerf-compiler、ModuleItem 需 kerf-compiler 再导出、FileEntry Debug、repl 三处借用拆分 self.acc.clone()、RunOutcome move、未用导入 ×3、str 比较、no_input 闭包形态、args map 解引用——**全部编译级/借用级，零运行语义**）；R2 **测试侧 8**（字节偏移手算错位族：line_index 六处期望值——"(define x 1)" 12 字符非 13/`(+ 1 2)` 7 字符列 8/"10" 两字符行起点 21/列 11 非 12 ×2——0.3 教训同族，逐处实跑回读修正）；R3 **实现语义缺陷 2**（①TapeIo::write_line 误设 no-op——VmIo 的 io 面是引擎输出的唯一记录点（BufferIo 同构），no-op 致 REPL 输出恒空；②main() 预读 stdin 无条件执行——repl 模式提交行被吞，改为仅 `run` 命令预读——两处均当轮发现修复 + E2E 复验）；R4 测试程序形态 3（define 函数 ≠ 调用——`(define (main) ...)` 只定义不执行，改 define 调用形 `(define r ...)` ×3）；R5 脚本损坏 seed 文件（python 切片残留）→ 整文件重写一次通过；R6 clippy 尾清（empty line after doc comment）；R7 fmt + 冷构建六命令终态全绿。**driver 实现侧运行语义缺陷：2（当轮闭环零遗留）**。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（消费面扩展） | reader error.rs / compiler error.rs | 0 | 5 |
| 单元 session.rs | 内联 | 4 | 1 |
| 单元 line_index.rs | 内联 | 10 | 3 |
| 单元 diagnostic.rs | 内联 | 5 | 6 |
| 单元 render.rs | 内联 | 9 | 4 |
| 单元 pipeline.rs | 内联 | 7 | 8 |
| 单元 repl.rs | 内联 | 11 | 5 |
| 单元 cli.rs | 内联 | 11 | 7 |
| crate API | api_tests.rs | 4 | 2 |
| 跨 crate 集成 | driver_seed_tests.rs（经 runner.rs） | 12 | 10 |
| **0.8 合计** | | **73** | **51** |

- **比例申报**：轮 73:51 ≈ **1:0.7**（正向偏斜——历史首例反向偏差）。**偏差披露**：① driver = 编排层——正向组合路径（双引擎驱动值语义/渲染黄金字节契约/REPL 会话持久与增量输出/CLI 命令族解析与退出码/parity 三面一致）每 case 断言一条互异编排语义，是层的**主功能面本体**；② 负向域已穷尽：四阶段 41 变体映射（每变体位置在场性逐一遍历——`every_read_variant_maps...` 单函数循环断言 10 变体 + 编译/运行时族同构）、防御钳制 10+（越界/中点字符/无位/未知文件/空表）、错误回滚 4、CLI 用法错 6——错误面覆盖为**全变体级**，仅测试函数计数压缩；③ 凑数拆分（如把 41 变体映射拆成 41 个测试函数凑比例）违反 §12 最优>最小。累计 181:370 ≈ 1:2.0（workspace 427 → 551）。
- 集成构成（GATE 6 其余项全达标）：driver_seed 22 case：正向 12 ≥1 / 负向 10 ≥3 / 跨阶段消费（全链消费 + 黄金契约消费 + CLI 面消费）≥1 ✅
- **七类维持 6/7**；其中**五类经 driver E2E 源级可达**（语法/空应用/未绑定/参数个数/类型不匹配——审计 I01-I05 + seed 同构）；第六类宏展开深度 = **合成树专属**（reader 256 < expander 512 帽序结构性事实——源级不可达，审计 E 节 expander 层维持点亮；driver E2E 以 250 深全链边界探针证帽序，seed `e2e_deep_source_rides_the_three_layer_cap_order`）；余 1 类结构性 DEFERRED（模块循环依赖@0.9）

## 4. 设计对齐记录（§13.1——裁定与决策入档）

### 裁定十一（0.8）：DAG 两条新边——L1→L8 + L7→L8

§18.5 图声明 L2/L3/L5/L6→L8 四边；本轮 driver 实现揭示两条结构性缺口：① **L1→L8**（kerf-syntax 直依）——REPL 表单分类直查 `StxDatum`/`SyntaxObject`（头符号 define/require/module 判定 + 源切片定位），沿 L1→L3「SyntaxObject 直接消费者直接依赖」先例（0.0 脚手架 Cargo.toml 既有声明的实义化——脚手架期声明的边在实现轮转正，非新增依赖面）；② **L7→L8**（kerf-runtime 直依）——`Engine::Eval` 路径函数调用面（`Evaluator::with_io/eval_program/global/heap` + `parity_repr`），沿 0.7 裁定十四「L7→L4/L7→L5」加边先例（类型再导出可传递，函数调用不可——真实调用边必须显式）。dataflow.md 同步两边（裁定标注）；sop.md §18.5 原始章程图不动（沿 TD-004 处理先例：dataflow.md 为活跃同步位）。零环验证：L8 为叶，两边均合法。

### 裁定十二（0.8）：REPL session-replay 语义

VM 与 Evaluator 均为**每程序一次性**构造（0.7 程序隔离防御的既定设计——`Vm::new(bc)` 绑定单 Bytecode、eval_program 入口 env 清空），持久会话 REPL 无法保活引擎。裁定 REPL 语义 = **累积源整体重跑**：① 表达式提交源级包装 `(define $repl:N expr)`——r110 语料注「top-level expression channel = the define calling form」的机制落位（模块顶层保持纯声明面，TopLevelExpression 错误零接触）；② 错误回滚——失败提交不入累积程序（会话在任意错误后存活，seed/审计双证）；③ 单调输入带——预载固定磁带逐行重放（重跑确定性），超带 read-line → Eof fail-closed（交互 stdin 消费 = `run` 模式管道预载面，0.8 REPL 不做带外读——登记边界）；④ 增量输出——前缀一致仅打印新增尾部（确定性磁带下前缀性质成立，防御分支全量打印）。O(n²) 重跑代价披露（Stage 0 规模无关紧要；持久会话 = Stage 1+ 议程登记）。`$repl:` 保留名前缀 = 用户名空间侵入（P3 披露，无卫戍——Stage 0 皮肤可接受）。

### 裁定十三（0.8）：TD-001 清偿形态——渲染期派生 + 诚实 Option + 阶段级代码

§12.1「行号/列号在渲染诊断时由偏移派生，避免双源存储」的完整落位：`LineIndex::new(&str)` 单遍构建（换行起点向量）+ `to_line_col(offset) -> (1 基行, 1 基字符列)`——**字符列非字节列**（CJK 终端真值；审计 I10 + seed 双证：字节列 21 vs 字符列 19 可区分断言）；中点字符偏移向下取整到字符边界（确定性钳制不 panic——渲染器必须存活于任何载荷）。**Option 诚实设计**：`Diagnostic.primary_span: Option<Span>`——ReadError 四变体（InvalidBool/MalformedNumber/InvalidSymbol/NestingDepthExceeded）与 CompileError 三变体（DebugInfoMissing/MissingTerminator/EmptyFuncTable）天然无位，「缺失即缺陷本体」，伪 span = DUMMY 同罪拒绝（0.1 裁定族延展）；渲染层无位免 `-->` 免摘录（审计 I10）。**DiagnosticCode 阶段级**（Read/Expand/Compile/Runtime/Driver——`kerf-read` 等稳定标签）；变体级 E0xxx = Stage 1+ §8.7 完整框架议程登记（登记态零实现义务，原则 38）。

### 决策清单（12 项）

1. `Severity` 四变体（§8.7 契约形状）仅 Error 有生产者——结构面预留披露（非桩——枚举即契约，0.10 接口冻结议程）。
2. `children/suggestions` 字段**不入** 0.8 Diagnostic——无生产者不立空字段（R1 桩判定规避）；0.10 议程登记。
3. 消费面扩展采用访问器（`offset()`/`span()`）而非 driver 侧 41 臂字段匹配——位置提取知识归错误类型本体（§2.3-2 单一可信数据源）。
4. `run_parity` 内联保活双引擎 + `parity_repr` 比较——Pair 跨堆必须活堆解析（run 面释放引擎，Display 坍缩 `#<pair>` 会假一致）；**分歧报告为数据**（`assert_parity` panic 面保留给测试侧——0.7 一次性消费契约不变）。
5. `ParityReport` 三面：值 repr + 输出序列 + **全局表快照**（define 名投影 parity_repr——0.7 观察面转正为结构化报告面）。
6. `RunOutcome.globals` halt 快照（VM 侧 = bc.globals ∩ 已存储；eval 侧 = Define 名投影）——define-only 程序 halt 值恒 nil 的**可观察结果面** + REPL 值通道。
7. `check_source` = compile + `Bytecode::verify` 显式面（免构造 Vm——verify 公共校验面即 §19.3 两道防线之二）。
8. `TapeIo` 与 `BufferIo` 同构记录语义（write_line 记录 + take_output drain）——VmIo io 面是引擎输出的唯一记录点（R3 缺陷①的制度化修复形态）。
9. CLI 手工解析（零外部依赖——§18 沿袭；clap = Stage 1+ 候选登记）；退出码 0 成功/1 程序或环境错/2 用法错（rustc 惯例）。
10. `run` 模式 halt 值 nil 静默（非 nil 打印）——脚本执行器语义（观察面 = write-line 输出 + 值）；REPL 恒打印表达式值。
11. stdin 预读仅 `run` 命令（管道 → 输入带；终端不消费；repl 逐行读提交）——R3 缺陷②的制度化修复形态。
12. main() 为薄壳（全部逻辑在 lib `run_cli` 依赖注入面——文件读取/REPL 输入/输出槽注入，CLI 无进程_spawn 即可全测）。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | placeholder/stub？ | **零桩**。披露位：Severity Warning/Note/Help 无生产者（§8.7 契约形状——枚举完备性是设计义务非桩，P3）；`$repl:` 保留名无卫戍（P3 名空间侵入披露）；REPL O(n²) 重跑（P3——Stage 0 规模无关） |
| Q2 | 下一阶段可直接消费？ | ✅ 0.9（CodeValue+宏系统）消费：driver 的 Session/渲染/CLI 面 = 宏展开 E2E 基础设施；`ParsedProgram` 分叉点 = 0.9 展开器演进的稳定输入；无阻断 |
| Q3 | 源码→本子阶段输出 E2E？ | ✅ 22 case 全链（五类错误 + fib 双引擎 + parity + I/O + REPL + 黄金 + CLI + CJK + 帽序探针）；审计 I 节 10 case 可重跑 exit 0 |
| Q4 | P3 债务影响下一阶段？ | 无——TD-006（stage0.md 版本标签）文档面不影响代码；新披露三项（上表 Q1）均不阻塞 0.9 |
| Q5 | 防线引入破坏性变更？ | 无新依赖（crates.io 零增量）；消费面扩展全部加法（访问器 + 再导出）；0.1-0.7 全部既有测试零改动全绿（427 基线零回归实证） |
| Q6 | 依赖边方向合法？ | ✅ 裁定十一两边（L1→L8/L7→L8）零环 + dataflow.md 同步；kerf-span 零直依（再导出链消费——kerf-vm 先例） |

## 6. 门审审计集构成映射（SOP §7.3.1——单调增长 70 → 80）

- I01-I05：五类源可达错误类经 driver 全链渲染（语法/空应用/未绑定/参数个数/类型不匹配——code 断言 + `-->` 行断言）
- I06：多文件多诊断收集 + 汇总行（§12.2 错误是数据）
- I07：REPL 错误回滚 + 会话存活
- I08：check 面免执行拒绝（展开期错误零执行）
- I09：parity 一致（fib(8)）+ 分歧检测器数据化自检（沿 H10 先例）
- I10：CJK 字符列（1:19 vs 字节列 1:21 可区分）+ 无位诊断免 `-->`
- 构成：A10+B10+C5+D5+E10+F10+G10+H10+**I10** = 80 ≥ 30；错误恢复族 D5+I07；上轮修复边界 case：0.7 P1 悬垂（GC 根集）→ H09 既有 + I 节 parity 面间接覆盖；0.8 当轮缺陷 2（TapeIo/stdin）→ seed `delta_outputs` + `repl_loop` + `input_tape_replays` 边界对

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿先例）

| 角色 | 权重 | 票 | 意见摘要 |
|------|------|----|---------|
| ARCH-A | 2.0 | ✅ | 裁定十一/十二/十三架构闭合；两条新边零环 + 先例一致；TD-001/TD-003 双清偿 |
| DEV-A | 1.5 | ✅ | 六命令冷构建全绿 551:0:0 净 +124；实现缺陷 2 当轮闭环；消费面扩展全加法零回归 |
| QA-A | 1.0 | ✅（附条件满足） | 比例 1:0.7 偏差申报充分（编排层主功能面论证 + 错误面全变体级覆盖实证——41 变体逐一遍历 + 审计 I 节）；GATE 6 集成构成达标 |
| ALG-C | 1.0 | ✅ | LineIndex 二分/钳制确定性；TapeIo 重放确定性；session-replay 前缀性质论证成立 |
| SKL-A | 不计权 | ✅ | 裁定十二 r110 通道对接正确；帽序事实（256<512 源级不可达）披露诚实 |

**加权 5.5/5.5 = 100% ≥ 95% APPROVED（5/0）**

## 8. TD 账面与消费契约

- **TD-001 清偿**：LineIndex 渲染期派生 + rustc 风格渲染收口（行列/摘录/脱字符/多诊断/汇总行）——P2 → Resolved at 0.8。
- **TD-003 清零**：kerf-driver 实现——**9/9 crate 全落位**（0.0 章程「八骨架」终态：span/syntax/reader/expander/core/compiler/vm/runtime/driver）。
- TD-006（P3 机会性）沿袭；零新增 TD；当轮实现缺陷 2 闭环零遗留（§20.6 同类全量：TapeIo 记录语义 + stdin 预读条件化——两处均制度化为决策 8/11）。
- **0.9 消费契约**：`Session::{intern, file_name, source}` + `Diagnostic/Severity/DiagnosticCode` + `render_diagnostics` + `Engine/ParsedProgram/RunOutcome{globals}` + `Repl/ReplEvent` + `parse_args/run_cli/Command`——宏系统 E2E（定义宏→使用→展开→执行）与 0.9 模块加载层（七类第 7 点亮）的基础设施面；`$repl:` 包装通道 = 0.9 宏展开 REPL 的组合先例。

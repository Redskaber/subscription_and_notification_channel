# Stage 0.6 子阶段计划与交付实录——kerf-vm 迭代主循环虚拟机种子

> **Task ID**：9-a（flat worklog 对应条目；前置 = 基准核验——stage0.5 r1 tarball 解包替换形式化 no-op，sha256 8b6b69ad… 一致 + diff -rq 归零 + 基线 300:0:0 + audit 50/50 复验）
> **性质**：Stage 0 第七子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~1400 行新代码+测试；依赖风险低——零新生产 DAG 边（§18.5 既有 L5→L6；kerf-core 仅 dev-dependencies 夹具 CoreExpr 构造，生产 value/span/symbol 经 kerf-compiler 再导出扩展传递——沿 0.5 决策 14 先例）、零新外部依赖；历史缺陷密度低——0.4 零运行语义缺陷 / 0.5 两项均内循环捕获）
> **设计对齐**：以 §13.1 对齐记录落入本档 §4（依据 stage0.md §19.5（VM 执行循环——switch-dispatch 骨架/三不变式/三陷阱）/§8.12（VM 状态六件 + 帧三扩展槽冻结）/§19.4（分配配额安全点）/§12.1（Span 消费表——VM 侧运行期回查）+ SOP §7.1.1（七类——本轮点亮 #4/#5 → 6/7）+ plan-0.5.md §4 决策 8/10（Handle 卸载边界可调用性归 0.6 + 全局符号表单源播种）+ plan-0.5.md §5 Q2（0.6 消费契约：五件套 + verify 钩子 + span_of））

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/vm.md（FP1-4 + 预期数 12:42 三层表 + 审计集 50→60 口径 + 七类 6/7 申明 + 边界申报） | ✅ 实现前落档 |
| 实现 | kerf-vm 六模块（value/builtin/error/frame/io/vm）+ 迭代主循环 + 堆帧栈（无原生递归——TD-023 锚）+ RuntimeError(Span 回查) + verify 加载钩子 + STAGE0_GLOBALS 播种 + 分配预算（§19.4 安全点）+ 可插拔 I/O | ✅ |
| 三层测试 | 单元 39（8+31）+ crate API 7（2+5）+ 跨 crate 集成 8（2+6） | ✅ 54 新 case（12:42） |
| 0.5 缺陷修复（§20.6） | kerf-compiler `end_closure` cur 递减缺陷（多闭包程序产物损坏）——cur_stack LIFO 恢复修复 + 回归对 2 例（兄弟/嵌套闭包） | ✅ 冷构建并入本轮 |
| §7.3.1 审计集 r1 单调增长 | examples/audit/stage0_gate_audit_r1.rs G 节 +10（50 → 60，cargo run 可重跑） | ✅ 60/60 |
| TD-003 消解推进 | 骨架 crate vm → 完整实现（余 3 → 2：runtime/driver） | ✅ |
| 文档同步 | matrix（七类 6/7 + 累计 89:267）/ TD 登记册 v0.7 / calibration / stage-0-plan v1.6 / dataflow（L6 入已实现子图）/ RELEASE_NOTES v0.7.0 / README / rec 树 07 条目 / roadmap §6 断点回补（§20.3——滞留 post-0.4 态两轮） | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1028 files / 142.1MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 2.47s / 10 crates） |
| `cargo check --all-targets` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example 目标） |
| `cargo test --release` | ✅ **356 passed / 0 failed**（300 基线零回归 + 56 新增：VM 54（单元 39 / crate API 7 / 跨 crate 集成 8）+ compiler 回归 2；轮构成 14:42 = 1:3 精确） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 60/60**（A10 + B10 + C5 + D5 + E10 + F10 + G10；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于 kerf-vm 源/清单/测试 + kerf-compiler 变更面 + examples = **零新增命中**（既有登记制 CJK 白名单沿袭 0.1-0.3，本轮无新增）。*.md 面豁免位不计。

**内循环实录（§5.3——诚实记录）**：R1 编译级 4（Value PartialEq 缺失级联 3 + Frame copy_from_slice 非 Copy + materialize 借用冲突——重构 charge 自由函数 + 索引传参）；R2 **0.5 缺陷发现**（嵌套 handle 编译产物 MissingTerminator——`end_closure` 的 `cur -= 1` 在兄弟/嵌套闭包下错位，首个闭包 idx=1 巧合正确故 0.5 全绿通过；本轮以临时调试 example 转储定位 + cur_stack 修复 + 回归对 2 例——verify 第二道防线在 VM 加载期拦截了损坏产物，纵深防御实证）；R3 测试布局错 3（Call 栈契约方向——§19.5 骨架 peek(n) 绘图 vs 编译器实际发射「args 先·被调者栈顶」：以代码为准（§8.4.5）修正 exec_call + §13.1 对齐记录 + `true`→`#t` 布尔字面量语法 + 裸 Ret proto 自身深度下溢——闭包 proto 必须先留值）；R4 clippy 2（redundant guard + unused import 位置）；R5 fmt 对齐；R6 终态六命令 + audit 60/60 + Han 扫描全绿复验。**运行语义级实现缺陷 0**（VM 实现侧）；0.5 缺陷属上游修复非本轮引入。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | value.rs（3+6）/ builtin.rs（1+4）/ error.rs（0+8）/ frame.rs（1+2）/ vm.rs（3+11） | 8 | 31 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-vm/tests/api_tests.rs | 2 | 5 | 公共面（§9.1 规则 5）——DAG 纪律：仅经 kerf-compiler 面 + kerf-core dev 夹具 |
| 跨 crate 集成 | tests/v0/stage0/plan/vm_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费（fib 源码→值四段一断 + fib(25)=75025 + STAGE0_GLOBALS parity + let/set!/do 执行） |
| **0.6 VM 合计** | | **12** | **42** | **正负比 = 1:3.5 ≥ 1:3 ✅** |
| 0.5 回归对（另行记账） | kerf-compiler/src/compile.rs 内联 | 2 | 0 | §20.6 同类全量修复的回归锚（兄弟/嵌套闭包） |
| **轮合计** | | **14** | **42** | **1:3 精确 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2——fib 全链 + parity）
- §7.1.1 七类错误矩阵：**6/7 点亮**（+参数个数 #4：ArityMismatch 闭包/内建双面 + 类型不匹配 #5：truthy/算术/car/被调者四语境——全部源码可达）；余 1 类结构性 DEFERRED（模块循环依赖@0.9——加载层未建；门审级 7/7 于 0.11）
- 累计：实测 **356 测试**（300 + 56）；正负比累计 89:267 = 1:3 精确 ✅

## 4. 设计对齐记录（§13.1——裁定与决策入档）

### 裁定五（0.6）：Call 栈布局契约调和——以编译器实际发射为准

**冲突陈述**：§19.5 骨架 `Op::CALL(n) => let callee = vm.peek(n)` 按上游伪码绘图暗示 `[callee, args…]` 布局；而 0.5 编译器实际发射 + plan-0.5 决策 3 明文「args 左→右依次 → func → Call(arity)（被调者在栈顶，参数按序其下）」= `[args…, callee]` 布局。两侧不一致。

**裁定**：VM 按**编译器实际发射**实现（callee = pop 栈顶，args 按序其下取出）；§19.5 骨架 peek(n) 记为上游伪码的历史布局（其「栈顶第 n 项」表述与 0.5 发射序不可同时成立）。依据 §8.4.5 文档与代码冲突 → 以代码为准。编译器零改动；本档即冲突修正记录（SOP §8.4.5：只改其一 = 违例——0.5 侧文档 plan-0.5 决策 3 文字本身与代码一致无需改，仅 §19.5 骨架引用注记归档于此）。

**验证**：vm_seed_tests arity 双面 + fib 全链 + audit G01-G06 源码级全路径。

**依据链**：§8.4.5（代码优先 + 冲突修正义务）+ plan-0.5 决策 3（发射序明文）+ §19.5 不变式 3（两侧契约不得单独修改——VM 侧对齐即履约）。

**会签**：ARCH-A ✅（契约以生产者发射序为单一事实源）/ ALG-C ✅（args 左→右 + 被调者最后求值 = 应用序语义标准形态）。

### 裁定六（0.6）：Perform 的 Stage 0 最小执行语义——handler 即动态函数

**冲突陈述**：CoreExpr 冻结原语 Perform/Handle（TD-005）的完整效应语义（续延捕获/栈回退/效应树）属 §9.1.1 EffectSystem 接口预留层（Stage 2 实现）；0.5 编译器已发射三操作码（决策 8：handler 为安装点求值的值，「可调用性校验归 0.6 VM」）——0.6 必须给出可测执行语义但不得提前实现化预留层。

**裁定**：Perform(effect, argc) = **最近匹配 handler 动态查找 + handler 即函数调用**：弹 argc 参数 → 自 handler 栈顶向下找首个匹配 effect 的项 → 经公共 invoke 路径调用其值（闭包 arity 校验 + 建帧 / 内建 arity 校验 + 直执 / 非可调用 TypeMismatch）→ handler 返回值即 Perform 值，body 继续（handler 项保留至其 PopHandler）。无匹配 → UnhandledEffect。真续延/栈回退 = ext1 槽 Stage 1+ 预留（§8.12 帧格式冻结的既定承载）。

**验证**：seed 效应测试（嵌套 handler 内层优先 + 不同效应不误匹配 + builtin handler arity 路径）+ audit G07 + api_tests UnhandledEffect。

**依据链**：§9.1.1（接口预留层——Stage 0 仅类型）+ plan-0.5 决策 8（可调用性归 0.6）+ 原则 38/44（登记态零实现化义务）。

**会签**：ARCH-A ✅（最小语义与预留层边界清晰——invoke 复用即调用语义单源）/ ALG-C ✅（无续延的浅处理是可判定的最小完备面，嵌套最近匹配语义确定）。

### 设计决策 15 项

1. **六模块布局**：value（Value 八变体 + Heap/HeapObj/ClosureData + Display/eq_identity + from_literal）/ builtin（18 名注册表 + 固定 arity + from_name）/ error（RuntimeError 十变体全携带 Span + span()/got_kind() 消费面 + R8 Display）/ frame（Frame + FrameExt 三槽冻结 + Reserved 单例）/ io（VmIo trait + BufferIo 确定性缺省）/ vm（Vm 装配 + run 迭代主循环 + invoke 公共调用路径 + arith/compare）。
2. **Value 八变体**：LiteralValue 五变体运行时对应（Int/Float/Bool/Str/Nil）+ Pair(HeapRef)/Closure(HeapRef) 堆引用 + Builtin 内建。PartialEq 派生（测试断言面）；eq? 走 eq_identity（f64 位级比较——eqv? 语义：+0.0/-0.0 相异、位同 NaN 相等；Pair/Closure 同单元同一性）。
3. **堆帧栈（TD-023 锚）**：frames: Vec<Frame>——kerf 级递归消耗帧向量非 Rust 栈；帧含自有操作数栈 + locals（参数占 0..params + let 槽，未存槽读 nil——确定性基线）+ FrameExt 三扩展槽（ext1 continuation Reserved / ext2 异常表 Reserved / ext3 调试帧实名——0.8 driver 栈追踪消费面）。
4. **每帧操作数栈**：§19.5 骨架 `leave_frame → push(v)` 的忠实读法——帧各持 stack，Ret 弹值入调用者栈；编译器 per-proto depth 簿记（0.5 决策 4 的 depth: 0 起点）与此对偶。
5. **分配预算 = §19.4 安全点 0.6 形态**：charge(allocs, budget, span) 自由函数（借用分离）——帧入栈 + 堆单元（pair/closure/常量 pair 物化）各计一次；DEFAULT_BUDGET = 8MiB（fib(25) ≈ 243k 帧远低于）；kerf 无循环原语 → 一切无界增长经调用/分配 → 预算即全程序终止界（fail-closed BudgetExceeded）；0.7 gc_cycle 挂接同点（exhausted → collect → retry）。
6. **Halt 双形态**：栈空 → Nil（compile_program 纯声明产物深度 0）；栈有值 → 弹值（compile 单表达式产物深度 1）——与 0.5 两入口对偶；观察面 = global(name) 查询（模块顶层纯声明语义：`(define r (fib 10))` → run 返 Nil + global("r") = Int(55)）。
7. **verify 加载钩子**：Vm::new/build 先 bc.verify()（plan-0.5 裁定四第二道防线消费）→ 坏产物结构化拒绝（api_tests 篡改产物 JumpTargetOutOfRange 实证）。
8. **STAGE0_GLOBALS 播种**：bc.globals 逐名查 VM 注册表（Builtin::from_name）→ 内建名绑 Builtin 值、其余槽 None（LoadGlobal 未存 → UnboundGlobal——verify 静态不可判定的动态序补面）；seed_tests parity 断言（expander 18 名 ↔ VM 注册表双射）为 0.7 runtime 官方断言前置锚。程序 define 覆盖内建名 = 后写胜出（0.9 模块域归属前的扁平先例沿袭）。
9. **内建固定 arity**：18 名全部定元（算术/比较二元、car/cdr/not/谓词一元、cons/eq? 二元、read-line 零元、write-line 一元）；`(+ 1 2 3)` → ArityMismatch 为 0.6 明确语义（变参折叠 = Stage 2 库面）。
10. **算术/比较显式性**（§19.5 truthy 裁定延展）：同种类双 Int（checked 族——溢出 ArithmeticOverflow / 零除 DivByZero）或双 Float（IEEE——inf/nan 为值非错误）；异种 → TypeMismatch；比较族同规则（NaN 一切比较含 `=` 皆 false——IEEE）。混合算术/隐式转换 = Stage 2 语义窗口议题，0.6 fail-closed。
11. **write-line 严格 Str**：非 Str → TypeMismatch（display 格式化任意值 = 后续库关注点非 I/O 原语语义）；read-line 输入耗尽 → Eof。I/O 经 VmIo trait 可插拔（BufferIo 缺省确定性——种子输入/记录输出；0.8 driver 接真实流）。
12. **Span 回查**：错误于 (func, pc) 指令位经 bytecode.span_of 解析（verify 保证 debug_info 平行 → 查询不可 miss，expect 不变式断言）；RuntimeError 十变体全携带 Span + span() 访问器（0.8 诊断渲染消费面）。
13. **防御纵深分界**：数据栈访问显式深度检查（§19.5 陷阱二「peek 校验不可省略」——StackUnderfall 结构化返回）；操作数索引（consts/globals/locals/protos 界内）= verify 域（0.5 契约「verify 唯一合法性判据」），VM 以 expect 不变式断言消费——两道防线职责分界文档化。handler 栈为运行时状态 verify 不可静态判定 → PopHandler 越界 = StackUnderflow 可达负路径（vm.rs 实测）。
14. **MakePair 休眠操作码**：0.5 编译器不发射（pair 字面量走 PushConst→from_literal 物化）；VM 仍全实现（§8.12 24 操作码面完备）——vm.rs 手构造执行路径实证 + R1 判断记录（非桩——冻结操作码集的既定面）。
15. **闭包 env 捕获 dormant 载体**：Closure 指令按 §19.5 骨架快照当前帧 locals（ClosureData{proto, env}）；0.5 编译器自由词法变量回落全局（基础闭包 P0 口径）故无 verify 产物读取 env——Stage 1 词法捕获激活时帧布局零改动。同轮 0.5 缺陷修复（end_closure cur_stack）恰为多闭包程序正确性前提——闭包编译路径 §20.6 全量回归。

### 0.5 缺陷修复记录（§20.6 同类全量审查）

- **缺陷**：`end_closure` 以 `cur -= 1` 恢复当前 proto——首个闭包（idx=1）巧合正确；兄弟闭包/嵌套闭包下发射落入错误 proto（嵌套 handle 实测：entry 残缺两指令无终结符，其余全部漏入外层 handler proto）。
- **根因**：0.5 测试集无多闭包程序（fib 单闭包）——覆盖缺口 + 递减式恢复的错误直觉。
- **修复**：cur_stack: Vec<usize> LIFO 保存/恢复（begin_closure push 调用者，end_closure pop 恢复精确调用者）。
- **回归**：compile.rs +2（sibling_closures…：双 define 各持闭包——entry 双 Closure 引用 + 各 proto 封闭；nested_closures…：handle 子句内闭包——entry 完整形态断言 + verify 通过）。
- **同类审查**：cur 全使用点（emit/finish/begin/end）复核——emit 经 self.protos[self.cur] 消费，恢复正确后全路径一致；无其他同型缺陷。
- **纵深防御实证**：损坏产物被 0.5 verify（VM 加载钩子）拦截（MissingTerminator）——第二道防线按裁定四设计工作。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-vm 完整实现（无桩）；ext1/ext2 Reserved 单例 = §8.12/§19.5 不变式 1 的格式冻结设计（非桩——设计明文「Stage 0 可以为空但格式必须保留」）；余 2 骨架 crate（runtime/driver）为 TD-003 计划性脚手架（真实等级 P3，正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.7 runtime 直接消费：Heap 可寻址单元面（0.7 mark-sweep 行走）+ 预算安全点（gc_cycle 挂接）+ Value/Builtin 公共面（eval 元循环互查的值域单源）+ fib 契约（源码→值基准）。 |
| Q3 | 端到端路径测试？ | **0.6 管线 = 源码 → token → stx → CoreExpr → Bytecode → verify → VM 执行值全链贯通**（fib seed 四段一断 + fib(25)=75025——§20.1 Week 3 判据达成）；0.7 eval↔VM 双路径互查在其上加第二执行路径。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-003 于本轮消解 1 项（余 2——runtime@0.7/driver@0.8 逐子阶段承载）；TD-001（0.8）/TD-006（机会性）挂接不变——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | Vm::new/with_budget/with_io/run/global 全公共面被三层测试 + audit G 节实际调用 ✅（356 测试全绿）。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§1 清单十二件含 roadmap §6 回补）。 |

## 6. 门审审计集构成映射（SOP §7.3.1——单调增长 50 → 60）

| 构成 | 要求 | 实配 | case 样例 |
|------|------|------|----------|
| 单语句负向 | ≥10 | 10（A01-A10，沿袭） | 未闭合 / 孤立闭 / 空应用 / 未终结串 等 |
| 多语句/多函数负向 | ≥10 | 10（B01-B10，沿袭） | 后续形式未闭合（字节定位）等 |
| 复杂程序负向 | ≥5 | 5（C01-C05，沿袭） | 257 深 / 200 深未闭合底 等 |
| 错误恢复 | ≥5 | 5（D01-D05，沿袭） | 错→修正对（未闭合/截断/空应用/帽边界/转义） |
| 展开器负向 | — | 10（E01-E10，沿袭） | 未绑定 / 深度越界 / 相位违规 等 |
| 编译器负向 | — | 10（F01-F10，沿袭） | 深度帽 / verify 拒绝族 ×9 |
| **VM 负向（0.6 新增）** | — | **10（G01-G10）** | 源码级 arity ×2（闭包 params / 内建固定元）+ 源码级 type ×4（truthy Bool-only / 算术异种 / car 非 pair / 被调者非可调用）+ 源码级 unhandled effect + 源码级 div-zero + 源码级 i64 溢出 + fib(10) 小预算越界 |
| 七类覆盖 | 门审级 7/7 | **6/7**（+参数个数 #4 +类型不匹配 #5——全部源码可达）；余 1 类结构性 DEFERRED（模块循环依赖@0.9），文件头与运行输出披露——冷启动代偿口径沿袭 |

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 4-a/5-a/6-a/7-a/8-a 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §19.5 三不变式落位（帧三槽冻结 + pc 单调例外封闭集 + 求值序契约经裁定五调和）；堆帧栈无原生递归（TD-023）；verify 加载钩子 + 防御纵深分界（数据栈运行期检查 / 操作数索引 verify 域）；预算 = §19.4 安全点 0.6 形态（0.7 GC 挂接点预留）；0.5 缺陷修复同类全量 + 回归对（§20.6 合规） |
| DEV-A | ✅ 1.5 | 六命令冷构建全绿 356:0:0 + audit 60/60 exit 0；0.5 上游缺陷（end_closure cur）当轮发现-定位-修复-回归闭环（verify 第二道防线拦截实证）；VM 实现侧运行语义缺陷 0；测试文档先行 + 双向印证 |
| QA-A | ✅ 1.0 | 轮构成 14:42 = 1:3 精确（VM 12:42 ≥1:3 + 回归对 2 单列记账——不稀释也不虚报）；GATE 1/3/6 合规（Han 零新增 + 决策全条款引用 + 构成达标）；七类 6/7 记账（全部源码可达点亮——不虚报）；审计集单调增长 50→60 |
| ALG-C | ✅ 1.0 | fib(25)=75025 递归求值正确（§20.1 Week 3 判据）；checked 整算术 + IEEE 浮点（确定性边界——无 wrapping 无 UB）；eq? 位级 f64（eqv? 语义全总确定）；预算界 = 终止界论证（无循环原语 → 增长必经分配）成立；handler 最近匹配语义确定（rposition 自顶向下） |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭；fail-closed 全路径（十错误变体 + 预算 + verify 钩子 + 帧预算）；I/O 可插拔确定性缺省（测试无环境依赖）；§13.1 两裁定 + 15 决策全入档 |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

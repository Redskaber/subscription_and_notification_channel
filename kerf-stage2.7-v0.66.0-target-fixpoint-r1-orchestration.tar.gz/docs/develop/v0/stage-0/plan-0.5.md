# Stage 0.5 子阶段计划与交付实录——kerf-compiler 字节码生成种子

> **Task ID**：8-a（flat worklog 对应条目；前置 = 基准核验——stage0.4 r1 tarball 解包替换形式化 no-op，diff -rq 归零 + 基线 252:0:0 + audit 40/40 复验 + docs 双 sha256 一致）
> **性质**：Stage 0 第六子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~1100 行新代码+测试；依赖风险低——零新生产 DAG 边（§18.5 既有 L4→L5，kerf-span 仅 dev-dependencies 夹具用途，Span 生产消费经 kerf-core 再导出——沿 0.4 收窄先例）、零新外部依赖；历史缺陷密度低——0.3/0.4 同类轮实现侧零缺陷）
> **设计对齐**：以 §13.1 对齐记录落入本档 §4（依据 stage0.md §19.3（Compiler 实现框架——跳转回填/常量池/全局符号表/debug_info_table + 三不变式 + 三陷阱）/§8.12（字节码 VM 能力模型——操作码七分组）/§8.6（Span 全管线传播）/§12.1（Span 消费表——Compiler 侧 pc↔Span）+ SOP §7.1.1/§10/§11/§18.5 + 0.1-design-adjudications.md（TD-004 Span 边/TD-005 原语集）+ plan-0.4.md §4 决策 16（STAGE0_GLOBALS 单源））

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/compiler.md（FP1-4 + 预期数 12:36 三层表 + 审计集 40→50 口径 + 七类维持 4/7 申明 + 边界申报） | ✅ 实现前落档 |
| 实现 | kerf-compiler 六模块（error/opcode/bytecode/verify/compile/lib）+ 双入口（compile / compile_program）+ Bytecode::verify 公共校验面 | ✅ |
| 三层测试 | 单元 32（8+24）+ crate API 8（2+6）+ 跨 crate 集成 8（2+6） | ✅ 48 新 case |
| §7.3.1 审计集 r1 单调增长 | examples/audit/stage0_gate_audit_r1.rs F 节 +10（40 → 50，cargo run 可重跑） | ✅ 50/50 |
| TD-003 消解推进 | 骨架 crate compiler → 完整实现（余 4 → 3：vm/runtime/driver） | ✅ |
| 文档同步 | matrix（七类维持 4/7 + 累计 75:225）/ TD 登记册 v0.6 / calibration / stage-0-plan v1.5 / dataflow（L5 入已实现子图）/ RELEASE_NOTES v0.6.0 / README / rec 树 06 条目 | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1065 files / 108.5MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 1.97s / 10 crates） |
| `cargo check --all-targets` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example 目标） |
| `cargo test --release` | ✅ **300 passed / 0 failed**（252 基线零回归 + 48 新增：单元 32 / crate API 8 / 跨 crate 集成 8；12:36 = 1:3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 50/50**（A10 + B10 + C5 + D5 + E10 + F10；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于 kerf-compiler 源/清单/测试/example/audit 面 = **零命中**（本轮新增面实施期未产生中文注释；既有登记制 CJK 白名单沿袭 0.1-0.3，本轮无新增）。*.md 面豁免位不计。

**内循环实录（§5.3——6 轮，诚实记录）**：R1 编译级 2（`finish(mut self)` 冗余 mut + 测试局部绑定遮蔽 helper fn）；R2 **运行语义级实现缺陷 2**（Opcode::pops/pushes 表 Dup/Swap 分组错位——下溢检查面缺陷，编译产物净值不受影响；非尾 If 的 `post_cond` 在 emit_jump 前取值——else 入口深度簿记错致 StackImbalance 误报）+ 夹具/期望错 3（handle 全局 intern 序按求值序 h1 先于 read；verify 两夹具被前置结构校验拦截——consts 补值/重设计）；R3 clippy 3（int_plus_one + collapsible_match ×2）；R4 fmt diff（bytecode.rs import 序）+ api_tests useless `.into()`；R5 seed 夹具 2（`g` 不在 STAGE0_GLOBALS → 改 `+`；500 深源码被 **reader 256 帽**先行拦截——三层帽序事实修正：reader 256 < expander 512 < compiler 1024，测试改名 `source_bounded_tree_compiles_and_hand_built_deeper_is_rejected` 并披露帽序）+ audit F01 残留构造清理；R6 终态六命令 + audit + Han 扫描全绿复验。**实现缺陷 2 均当轮内循环捕获修复，零遗留**；教训：效应表应逐 opcode 全量断言（抽查表已抓住，但分组错位本可由全量表断言首验发现）。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | opcode.rs（2+0）/ bytecode.rs（2+2）/ compile.rs（4+3）/ verify.rs（0+11）/ error.rs（0+8） | 8 | 24 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-compiler/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5）+ fib 契约 + verify 拒绝族 |
| 跨 crate 集成 | tests/v0/stage0/plan/compiler_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费 2 例（fib 源码→Bytecode 契约 + do→Let→StoreLocal 链端到端）+ 三层帽序 |
| **0.5 合计** | | **12** | **36** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2）
- §7.1.1 七类错误矩阵：**维持 4/7 点亮**（语法错误 + 空应用 @0.3；未绑定标识符 + 宏展开深度 @0.4）——0.5 编译器为直译层（合法 CoreExpr 无语义拒绝面），**不新增点亮类**；余 3 类结构性 DEFERRED（参数个数/类型不匹配@0.6——VM CALL 校验层、模块循环依赖@0.9——加载层未建；门审级 7/7 于 0.11；冷启动代偿口径沿袭 plan-0.0.md §6）
- 累计：实测 **300 测试**（252 + 48）；正负比累计 75:225 = 1:3 ✅

## 4. 设计对齐记录（§13.1——14 项决策入档）

### 裁定四（0.5）：`Bytecode::verify` 公共校验面——不变式机械化 + VM 加载期 fail-closed 前置

**冲突陈述**：§19.3 三不变式（栈平衡/回填完备/调试信息全覆盖）在骨架中以「CodeBuf 析构断言」表述；Rust 无可靠析构断言惯例（Drop 中 panic 不可捕获），且编译期防御分支（unpatched jump/栈簿记失衡）经公共 API 不可达 → 负向测试面缺失，违反 GATE 6「负向非可选」。

**裁定**：
1. **编译期簿记保留**（CodeBuf 内部深度追踪 + 表达式边界断言 + finish 占位断言）——第一道防线（fail-closed 编译器 bug 防御，经 `CompileError` 结构化返回非 panic）。
2. **`Bytecode::verify(&self) -> Result<(), CompileError>` 公开**——纯函数产物自检：结构校验（debug_info 对齐/操作数界内/终结符形态/Halt 位置）+ **DAG 基本块栈深度传播模拟**（Stage 0 控制流无回边——无循环原语，拓扑传播即收敛；多前驱入口深度不一致 = `StackImbalance`）。第二道防线 + 0.6 VM 加载期校验钩子 + 手工构造坏产物的公共负向测试面。
3. Bytecode 为**纯数据**（pub 字段可手工构造）——verify 是唯一合法性判据；`compile`/`compile_program` 产出恒过 verify（契约测试断言）。

**验证**：verify.rs 单元负向 11 例（每防御变体一例手工坏产物）+ api_tests 拒绝族 4 + seed 拒绝族 3 + 审计 F02-F08/F10。

**依据链**：docs/stage0.md §19.3 核心不变式 1-3 + §2.3-4（报错>静默）+ §9.4.3（正负比不可豁免）+ R2（防御面不得为不可测桩）。

**会签**：ARCH-A ✅（两道防线分层正确——编译期簿记防编译器 bug，verify 防产物损坏；0.6 VM 加载前校验前置）/ ALG-C ✅（DAG 深度传播在无回边前提下拓扑收敛，语义精确）。

### 设计决策 14 项

1. **双入口形态**：`compile(expr: &CoreExpr) -> Bytecode`（表达式级——单值 toplevel proto，末尾 Halt 深度 1）+ `compile_program(items: &[ModuleItem]) -> Bytecode`（程序级——Define 序列净 0，末尾 Halt 深度 0）；沿 expand/expand_program 双入口先例（plan-0.4 决策 1）；main 通道归 0.8 driver。
2. **指令集 24 操作码**（§8.12 七分组 21 个 + 效应扩展 3 个）：栈操作 `PushConst/Pop/Dup/Swap`、函数 `Call/Ret/Closure`、控制流 `Jump/JumpIfFalse`、数据构造 `MakePair/Car/Cdr`、变量访问 `LoadLocal/StoreLocal/LoadGlobal/StoreGlobal`、算术 `Add/Sub/Mul/Div`、终止 `Halt`、**效应扩展** `PushHandler/PopHandler/Perform`（CoreExpr 冻结原语 Perform/Handle（TD-005）的直译承载——§8.12 分组外的必要扩展，VM 0.6 消费执行语义；「约 35 个」范围内）。每指令 `Instr { op, a: u32, b: u32 }` 双操作数槽（未用槽恒 0）——**操作数全解析**：`Opcode::operand_help()` 逐操作码声明 a/b 语义（常量池索引/局部槽/全局索引/跳转目标/元数/效应索引）。
3. **求值顺序契约**（§19.3 骨架）：Apply 编译 = args 左→右依次 → func → `Call(arity)`（被调者在栈顶，参数按序其下——§19.5 `peek(n)` 契约）；Perform 同序（args 左→右 → `Perform(effect_idx, argc)`）。两侧契约（编译/VM）不得单独修改（§19.5 不变式 3 引用）。
4. **闭包子程序形态**：`Fn` 编译 = `begin_closure`（params 占局部槽 0..n，独立 FuncProto）→ body **尾位**编译 → 显式 `Ret` → `end_closure` → 当前 proto `Closure(proto_idx)`；proto 名 `Option<Symbol>`（诊断用，toplevel = None）；`n_locals` 单调分配（Let 链 fresh slot 不复用——作用域正确性优先于槽位经济）。
5. **尾位置留位**（§19.3 陷阱一最小实现）：`compile_expr(e, tail: bool)` 内部传递；尾位 `If` = cond → `JumpIfFalse(else)` → then[tail] → `Ret` → else:[tail] → （外层显式 `Ret` fallthrough）——**无汇合 Jump**（分支直达 Ret，Stage 1+ TCO 只改分支尾指令不改 VM）。尾位源：Fn body（Handle body 截断——见决策 8）。
6. **Assign 栈平衡**（表达式值 = 被赋值）：value → `Dup` → `StoreLocal/StoreGlobal`（副本留栈，净 +1）；局部优先（词法 slot 命中 → 局部；否则全局 intern）。
7. **Let = let\* 渐进 + StoreLocal 链**（plan-0.4 决策 4 的编译侧对偶）：binding i 依序 value → `StoreLocal(fresh)`；body 尾位透传；空绑定零指令直通 body。
8. **Handle 卸载边界截断尾位**：clauses 依序 handler[tail=false] → `PushHandler(effect_global_idx)`（弹 1 装入 handler 栈，数据栈 -1——**handler 为安装点求值的值**，非 proto+环境表——任意 CoreExpr 处理器表达式合法，可调用性校验归 0.6 VM）→ body[tail=**false**] → `PopHandler(n)`（净 +1 = body 值）。**TCO 不穿透 Handle body**——handler 卸载必须在返回前发生；效应消除后尾位穿透是 Stage 2 优化窗议程（§6.12.1 修正五 EffectElimination——登记态，零实现义务）。
9. **常量池按值去重**（§19.3 陷阱二）：`ConstKey` 编译器私有规范化键（`Float` → NaN 规范化位模式 `u64`——NaN != NaN 破坏 Eq 自反性，全 NaN 折叠单槽；`Pair` 递归规范键）——kerf-core 公开面零改动（§11 接口隔离——core 冻结）。
10. **全局符号表单源**：`intern_global(Symbol) -> u32` 同名同槽；**编译器不校验 STAGE0_GLOBALS 名单**（那将引入 L3→L5 生产边，违反 §18.5 DAG——expander 已在前端拦 Unbound；全局名校验/播种归 VM 加载期 + 0.7 runtime parity 断言——expander lib.rs 既有钩子文档）。Require 项 = 零代码登记（链接推迟 VM 加载期——§19.3 陷阱三）；Module 项 = 递归扁平编译（0.9 给正式域归属——沿 STAGE0_GLOBALS 扁平先例申报）。
11. **COMPILE_DEPTH_LIMIT = 1024**（`pub const`）：编译递归帽，≥2× expander 512 裕量（沿 reader 256→expander 512 的 2× 先例）——expander 产出树结构性 ≤512，超帽 = 合成树注入 → `DepthExceeded` 结构化拒绝（fail-closed，非栈溢出——§19.2 不变式 1 的编译器侧对偶）。
12. **debug_info_table 平行表**：`FuncProto.debug_info: Vec<Span>` 与 `code` 逐指令平行（pc = 索引）；emit 自动写入（§19.3「每条 emit 自动写入」）；**Span 零构造**——全部复制自 CoreExpr 节点（TD-002 编译器侧延展：跨代 join 结构性不发生）；查询 API `Bytecode::span_of(func, pc) -> Option<Span>`（§12.1 消费表 Compiler/VM 行的 0.5 承载——VM 堆栈追踪 0.6 消费）。
13. **CompileError 变体全结构化**（防御面可测化）：`DepthExceeded / UnpatchedJump / StackUnderflow / StackImbalance / ConstIndexOutOfRange / GlobalIndexOutOfRange / LocalSlotOutOfRange / ProtoIndexOutOfRange / JumpTargetOutOfRange / DebugInfoMissing / MissingTerminator / HaltOutsideEntry`——全携带 pc（产物侧）或 depth + Span；R8 消息形态（小写开头/无句尾句号/反引号载荷）；`std::error::Error` 实现（无 source 链——编译错误不含 CoreError 包装，输入已校验）。**实施修订**：新增第 13 变体 `EmptyFuncTable`（funcs 空的手工产物拒绝）；`DebugInfoMissing / MissingTerminator / EmptyFuncTable` 三变体不带 Span（**缺失的 span 正是被检出的缺陷本身**——结构性无源，诚实设计）；verify 先校验 debug_info 对齐、后续变体的 span 查取安全。
14. **manifest 零生产边变更**：生产依赖仅 kerf-core（§18.5 既有 L4→L5）；kerf-span 仅 dev-dependencies（夹具 Span 构造——`Span::root`），生产 Span 消费经 `kerf_core::Span` 再导出（core lib.rs 既有契约 "consumers must not depend on kerf-span directly"）——沿 0.4 决策 16 收窄形态；workspace 版本 0.5.0 → 0.6.0。**实施修订**：冷启动锚（空程序 Halt 的唯一合成 span）需 `FileId/ByteOffset/ExpansionId` 构造——**kerf-core 再导出扩展**（`pub use kerf_span::{ByteOffset, ExpansionId, FileId, Span}` + 契约注释更新；非原语/类型变更，0.1 冻结面不受触动；§18.5 生产面零新边保持——L0→L4 既有 + L4→L5 既有，compiler 不直依 kerf-span）。
15. **冷启动锚修订（决策 12 延展）**：合成指令 span 归属——Ret 复用 body span、汇合 Jump 复用 If 节点 span、Call 复用 Apply span、PushHandler 复用 clause span；唯一 `Span::new` 构造 = 空程序 Halt 的冷启动锚（FileId 0, 0..0 零长真实偏移、ExpansionId::ROOT 单代次——TD-002 跨代 join 语义不受影响）；非空程序 Halt 复用 last_span（最后 emit 的源 span）。「零 span 构造」口径修正为「除冷启动锚一处外零构造」。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-compiler 完整实现（无桩）；剩余 3 骨架 crate（vm/runtime/driver）仍为 TD-003 计划性脚手架（真实等级 P3，正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.6 VM 直接消费 Bytecode（code/debug_info/consts/globals/funcs 五件套 + verify 加载期校验钩子 + span_of 堆栈追踪查询面）；fib 契约锚定 Define+Fn+If/Apply/Var 树形编译形态。 |
| Q3 | 端到端路径测试？ | 0.5 管线 = 源码 → token → stx → CoreExpr → **Bytecode + verify** 全链（fib seed 正例 = read_program + expand_program + compile_program 三段一断）；源码→值 E2E 自 0.7 起（计划不变）。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-003 于本轮消解 1 项（余 3——vm@0.6/runtime@0.7/driver@0.8 逐子阶段承载）；TD-001（0.8）/TD-006（机会性）挂接不变——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | 双入口 compile + compile_program 被 api_tests（8）+ compiler_seed_tests（8）+ audit F 节（10 case）实际调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§1 清单）。 |

## 6. 门审审计集构成映射（SOP §7.3.1——单调增长 40 → 50）

| 构成 | 要求 | 实配 | case 样例 |
|------|------|------|----------|
| 单语句负向 | ≥10 | 10（A01-A10，沿袭） | 未闭合 / 孤立闭 / 空应用 / 未终结串 等 |
| 多语句/多函数负向 | ≥10 | 10（B01-B10，沿袭） | 后续形式未闭合（字节定位）等 |
| 复杂程序负向 | ≥5 | 5（C01-C05，沿袭） | 257 深 / 200 深未闭合底 等 |
| 错误恢复 | ≥5 | 5（D01-D05，沿袭） | 错→修正对（未闭合/截断/空应用/帽边界/转义） |
| 展开器负向 | — | 10（E01-E10，沿袭） | 未绑定 / 深度越界 / 相位违规 等 |
| **编译器负向（0.5 新增）** | — | **10（F01-F10）** | 编译深度帽越界（合成 1025 深树）/ verify 拒绝族 ×9（jump 目标越界 / 栈下溢 / 栈失衡 / debug_info 缺失 / const 索引越界 / 非入口 Halt / 末条无终结符 / proto 索引越界 / local 槽越界——手工坏产物逐变体） |
| 七类覆盖 | 门审级 7/7 | **4/7 维持**（编译器为直译层无新检测类）；3 类结构性 DEFERRED 至各自落位子阶段（0.6/0.9），文件头与运行输出披露——冷启动代偿口径沿袭 |

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 4-a/5-a/6-a/7-a 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §19.3 三不变式两道防线落位（编译期簿记 + verify DAG 传播——裁定四）；尾位置留位模式（尾 If 分支直达终结指令，无汇合 Jump——Stage 1 TCO 只改 Compiler）；§18.5 生产面零新边（core re-export 扩展 = 消费面完整性传递，非新边）；三层帽序（256/512/1024）逐层 2× 裕量沿袭 |
| DEV-A | ✅ 1.5 | 六命令全绿（冷构建 300:0:0）+ audit 50/50 exit 0；运行语义级实现缺陷 2（Dup/Swap 效应表分组 + If 深度簿记时机）均当轮内循环捕获修复零遗留，教训入档（效应表逐 opcode 全量断言） |
| QA-A | ✅ 1.0 | 正负比 12:36 = 1:3 精确达标（三层各按预算实配）；GATE 1/3/6 合规（编码面零 Han + 决策全条款引用 + 构成达标）；七类 4/7 维持记账（直译层无新检测类——不虚报点亮）；审计集单调增长 40→50 |
| ALG-C | ✅ 1.0 | 求值顺序契约（args 左→右 + 被调者栈顶）与 §19.5 peek(n) 对偶精确；NaN 规范化位键保 Eq 自反（+0.0/-0.0 按位不折叠——去重是优化非语义合并）；Handle 卸载边界尾位截断语义正确（handler 必须在返回前弹出——尾位穿透属 Stage 2 EffectElimination 登记态）；Assign 的 Dup+Store 栈平衡（表达式值 = 被赋值） |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭；fail-closed 全路径（深度帽 + verify 十三防御变体 + 编译期簿记三防御）；操作数语义全声明（`Opcode::operand_help` 单源——「操作数全解析」验收锚）；Instr Display 固定三段机器形（零值歧义消除） |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

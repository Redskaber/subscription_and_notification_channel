# Stage 0.4 子阶段计划与交付实录——kerf-expander 展开/脱糖种子

> **Task ID**：7-a（flat worklog 对应条目；前置 = R10-a tarball 替换核验——形式化 no-op，diff 归零实证 + 基线 204:0:0 + audit 30/30 复验）
> **性质**：Stage 0 第五子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~1500 行新代码+测试；依赖风险低——零新生产 DAG 边（§18.5 既有 L1→L3 + L4→L3 消费，kerf-span 仅 dev-dependencies 夹具用途）、零新外部依赖；历史缺陷密度低——0.3 遗留零 P0/P1）
> **设计对齐**：TD-002 升 P1 强制裁定（本档 §4 裁定三）+ 16 项设计决策以 §13.1 对齐记录落入本档 §4（依据 stage0.md §19.2/§3.2/§3.3/§6.12.6/§8.8/§8.9/§8.10 + SOP §7.1.1/§21.12-11/原则 23/27 + 0.1-design-adjudications.md）

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/expander.md（FP1-4 + 预期数 12:36 + 审计集 30→40 口径） | ✅ 实现前落档 |
| 实现 | kerf-expander 四模块（error/ctx/expand/lib）+ 双入口（expand / expand_program）+ STAGE0_GLOBALS 18 名 | ✅ |
| 三层测试 | 单元 32（8+24）+ crate API 8（2+6）+ 跨 crate 集成 8（2+6） | ✅ 48 新 case |
| §7.3.1 审计集 r1 单调增长 | examples/audit/stage0_gate_audit_r1.rs E 节 +10（30 → 40，cargo run 可重跑） | ✅ 40/40 |
| TD-002 裁定 | 跨展开代 join 语义裁定文（本档 §4 裁定三）——P3→P1 当轮清偿 | ✅ |
| 文档同步 | matrix（七类 4/7 点亮）/ TD 登记册 v0.5 / calibration / stage-0-plan v1.4 / dataflow / RELEASE_NOTES v0.5.0 / README / rec 树 | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1058 files / 91.6MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 1.19s / 10 crates） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example 目标） |
| `cargo test --release` | ✅ **252 passed / 0 failed**（204 基线零回归 + 48 新增：单元 32 / crate API 8 / 跨 crate 集成 8；12:36 = 1:3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 40/40**（A10 + B10 + C5 + D5 + E10；exit 0） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于代码/清单/example 面 = 命中仅既有登记制 CJK 白名单（core/syntax symbol.rs `计数器` + reader lexer.rs/seed `计数`——被测对象夹具，§10.5 豁免，0.1-0.3 双登记沿袭）；本轮新增面（expander/example/seed）实施期 1 处注释域中文（`Begin → Let 链`——「链」字）当场清偿后**清零**。*.md 面豁免位不计。

**内循环实录（§5.3——6 轮，诚实记录）**：R1 `Frame` 可见性（pub(crate) 结构体 + pub(crate) 方法签名泄漏——编译级）+ ctx 测试模块冗余导入；R2 审计集闭包参数 `impl FnOnce`（E0562——闭参不允许 impl Trait，转顶层 fn 沿 audit_err 同构 + 三处级联断言形态）；R3 深度树夹具缺陷（头 `f`/最内层 `x` 未绑定先于预算触发——换全局 `+` 头 + 整数字面量最内层，**实现行为正确、夹具语义错误**）；R4 `(do)` 顶层入口错位（expand_program 先命中 TopLevelExpression 而非 MalformedForm——测试改走表达式入口，**实现行为正确、测试路径期望错误**）；R5 fmt 446 行重排 + seed 冗余导入 `LiteralValue`；R6 R8 注释域中文清偿（「链」）+ ctx 负向 2 例补齐（首轮实配 12:34 未达 GATE 6 → 12:36 精确 1:3——foreign-scope 解析拒绝 + 预算下溢饱和）。**运行语义级实现缺陷：0**（R1/R2 为编译级可见性/签名形态，R3/R4 逐例追认实现行为正确）。

## 3. 测试构成（SOP §9.4.3 / GATE 6）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | error.rs（0+5）/ ctx.rs（3+7）/ expand.rs（5+12） | 8 | 24 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-expander/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5）+ fib 契约 + 全局面 |
| 跨 crate 集成 | tests/v0/stage0/plan/expander_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费 2 例（fib 源码→CoreExpr 契约 + do→Let 端到端）+ 模块隔离 + 单源字典跨 crate |
| **0.4 合计** | | **12** | **36** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2）
- ≥40 门槛超配（48）；§7.1.1 七类错误矩阵：**4/7 点亮**（语法错误 + 空应用 @0.3；**未绑定标识符 + 宏展开深度 @0.4**）——余 3 类结构性 DEFERRED（参数个数/类型不匹配@0.6、模块循环依赖@0.9——检测层未建；门审级 7/7 于 0.11；SOP §7.1.1 v12.5 口径注以「已存在检测层的类全点亮」冷启动代偿口径执行——plan-0.0.md §6 裁定沿袭）
- 累计：**252 测试**（单元 171 / crate API 40 / 跨 crate 集成 41）；正负比累计 63:189 = 1:3 ✅

## 4. 设计对齐记录（§13.1——TD-002 强制裁定 + 16 项入档）

### 裁定三（TD-002，P3→P1 当轮）：Span 跨展开代合并语义 = 拒绝为设计行为，0.4 展开器结构性不产生跨代 join

**冲突陈述**：`Span::join` 跨展开代合并被拒绝（`JoinExpansionMismatch`）；拒绝的语义边界属宏期关注点，TD 登记册挂接 0.4 强制裁定（「expander 需要跨代 span 时升 P1」）。

**裁定**：
1. **0.4 展开器结构性不产生跨代 span**：全部产出 span 均为**复制源节点 span**（脱糖合成节点——do→Let 的 `_` 弃置绑定、define 函数糖的 Fn 值——复用被脱糖形式的源 span，同一 ExpansionId::ROOT 代次）；展开器**零 span 构造**（无 `Span::new` 调用——Span 经 kerf-syntax 再导出只读消费）。跨代 join 在本层**不可能发生**。
2. **拒绝语义保持为设计行为**：`JoinExpansionMismatch` fail-closed 拒绝正确（跨代点合并无定义语义——宏期需要的是** span 集合表示**（§19.2 不变式 2：宏定义处 ∪ 使用处作用域并集的同族形态），非点合并）。
3. **0.9 宏系统议程登记**（非 Stage 0 义务）：宏展开代次递增（expansion_id + 1）与 span 集合表示属宏 transformer 机制；零信号不开窗（原则 38/44-58 登记态纪律）。

**验证**：api_tests `expand_program_delivers_the_fib_contract` + seed `fib_source_expands_to_the_compiler_contract` 对全部产出 span 做 join 折叠——必须全成功（单代次实证）；syntax_seed_tests（0.2）TD-002 跨代次拒绝穿透断言保持为守护。

**依据链**：docs/stage0.md §8.6（Span 全管线传播）+ §19.2 实现陷阱（「非局部展开的 Span 悬空」——所有产物携带有效源 span）+ §2.3-4（报错>静默——无定义语义即拒绝）+ TD-004 裁定二纪律延展（span 必填结构性）。

**会签**：ARCH-A ✅（结构性论证成立——零构造即零跨代）/ ALG-C ✅（集合表示 vs 点合并的语义区分正确）。

### 设计决策 16 项

1. **双入口形态**：`expand(ctx, stx)`（表达式级——REPL/driver 组合点）+ `expand_program(forms) -> Vec<ModuleItem>`（程序级）；模块顶层**仅声明**（define/require/module）——裸表达式 `TopLevelExpression` 拒绝，依据 r102 语料锚「`(define NAME e)` 顶层表达式项通道 = 调用形通则」+ §19.2 陷阱（define 双层语义）；main 通道归 0.8 driver 编排。
2. **define 双形 + letrec 式顶层预绑定**：`(define (f x) body)` 函数糖 → `Define{f, Fn{...}}`（§7.3.5 近恒等映射——`直接映射 Define{name, value: Fn{...}}，无中间层`）；`(define name e)` 值定义；名字在体展开**前**预绑定（自引用 = fib 递归契约）+ 顺序顶层绑定（后定义可见前定义）。
3. **do→Let 链脱糖**：`(do e1 … en)`（n≥2）→ `Let{[_←e1,…,_←e(n-1)], en}`（§6.12.6「Begin → Let 链」；`_` 弃置名惯例——普通绑定可遮蔽无害）；`(do e)` 恒等；`(do)` MalformedForm。
4. **let 双 spec 形态**：`(let (x e) b)` 单绑定 / `(let ((a e1) (b e2)) b)` 多绑定 / `(let () b)` 空绑定（L4809/4818 语料锚）；分类规则确定性（spec[0] 为 List → 多路径；否则 spec 自身为对）；**let\* 渐进绑定**——值 i 仅见绑定 1..i-1（单域 + 渐进插入实现，非逐域着色）。
5. **头保留字平面分派**：表达式级 7 形（fn/if/let/do/set!/perform/handle）平面查表；define/require/module 仅声明级；操作数位 define → 未绑定应用（fail-closed 自然拒绝）；scoped-keyword 机制 = 0.9 升级路径（Racket 对齐——当前简化登记）。
6. **`nil` 保留字面量**：atom 位 `nil` → `Literal{Nil}`（plan-0.3 裁定 3 的表面承载——空表数据经 nil 字面量）；`quote` 不实现（`(quote x)` → 未绑定应用拒绝；datum 机制 = Stage 2；nil/Pair 承载 Stage 0 数据——同族边界申报）。
7. **STAGE0_GLOBALS 18 名扁平全局表**（§8.8 传统全局函数——算术/比较 9 + pair/谓词 7 + 最小 I/O 2）：解析序 = 词法（域键控）→ 全局扁平回退 → Unbound；**名单单源** = 展开器（管线前端拥有表面契约，0.7 runtime 播种全局环境时 parity 断言）；0.9 模块系统给予正式域归属（扁平表 = 0.4 文档化简化）。
8. **作用域键控解析**（卫生骨架——§19.2 不变式 2）：每绑定形分配 fresh ScopeId + 子树着色（`with_scope_added` 深翻转**生产化消费**——0.2 契约兑现）；解析规则 = 绑定域 ∈ 标识符作用域集（内层优先）；**名匹配而域不属 → Unbound**（键控精度，非名匹配——ctx 负向专项锚定）；卫生并集 = 0.9。
9. **相位封闭 fail-closed**（§8.9 规则 1 的 0.4 切片）：每个被触及节点 `require_runtime`（递归节点经 expand 入口、结构消费节点显式检查——params/spec/子句/名字原子全覆盖）；MacroExpansion 相位树 → `PhaseViolation` 结构化拒绝；transformer 执行 = 0.9。
10. **EXPANSION_LIMIT = 512**（§19.2 不变式 1——展开终止性）：嵌套 expand 调用预算；≥2× reader 256 帽裕量（吸收脱糖包装层）；**独立界定合成树/宏产树**（0.9）——reader 帽只界源码树；512 边界双向（511 嵌套通过 / 512 拒绝——纯应用链 N 嵌套 = N+1 深度，头原子瞬态层计入）；超预算 = 结构化错误非栈溢出。
11. **set! 目标必须可解析**（Scheme 语义——赋值未绑定变量为错误）：目标经解析三态（词法/全局/Unbound）；`(set! nope 1)` → UnboundIdentifier 定位于目标原子。
12. **module 域隔离**：嵌套模块项经 frames isolate/restore——外层 define 不渗入（§8.9 方向：模块命名空间隔离）；seed 跨 crate 专项锚定。
13. **ExpandError 七变体**：UnboundIdentifier / ExpansionDepthExceeded / EmptyForm / PhaseViolation / MalformedForm / TopLevelExpression / Core{source, span}——全变体携带精确 Span；R8 消息形态（小写/无句号/反引号载荷）；`std::error::Error::source` 链接 CoreError（0.8 诊断渲染组合契约）。
14. **空应用合成面复检**：`List(vec![])` 直达 expand → `EmptyForm`（0.3 裁定 3 的第二 fail-closed 层——reader 先拦源码、展开器拦合成面；0.9 宏产树同守）。
15. **core 构造器语义下限再断言**（0.1 契约「expansion time re-assert」兑现）：重复参数/重复效应经 `CoreError` 传播（`ExpandError::Core` 包装 + 展开位 span 补充）；StxSymbol 与 core::Symbol 下限逐字节一致（0.2 裁定 ②）→ 传递路径零再校验损耗。
16. **manifest 零生产边变更**：kerf-span 仅入 dev-dependencies（夹具 span 构造）；生产 Span 消费经 kerf-syntax 再导出（其 lib.rs 契约「consumers must not depend on kerf-span directly」）——§18.5 DAG 生产面零新增边（沿 reader L0 直依先例的**收窄**形态）。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-expander 完整实现（无桩）；剩余 4 骨架 crate 仍为 TD-003 计划性脚手架（真实等级 P3，正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.5 compiler 直接消费 expand_program 产出的 ModuleItem/CoreExpr（fib 契约已锚定 Define+Fn+If/Apply/Var 树形 + visit_spans 前序 + span join 单代次）；ExpandError 结构化面可直接进诊断框架（0.8 收口）。 |
| Q3 | 端到端路径测试？ | 0.4 的管线 = 源码文本 → token → stx 树 → CoreExpr 全链（fib seed 正例 = read_program + expand_program 两段一断）；源码→值 E2E 自 0.7 起（计划不变）。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-002 于本轮裁定清偿（裁定三）；TD-001（0.8）/TD-003（余 4——0.5 起逐子阶段消解）/TD-006（机会性）均有挂接——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | 双入口 expand + expand_program 被 api_tests（8）+ expander_seed_tests（8）+ audit E 节（10 case）实际调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§1 清单）。 |

## 6. 门审审计集构成映射（SOP §7.3.1——单调增长 30 → 40）

审计集 = `examples/audit/stage0_gate_audit_r1.rs`（40 case，`cargo run --release --example stage0_gate_audit_r1` 可重跑，exit 0）：

| 构成 | 要求 | 实配 | case 样例 |
|------|------|------|----------|
| 单语句负向 | ≥10 | 10（A01-A10，沿袭） | 未闭合 / 孤立闭 / 空应用 / 未终结串 / 非法转义 / 非法布尔 / 数字形×2 / 控制字符 / 括号字符 |
| 多语句/多函数负向 | ≥10 | 10（B01-B10，沿袭） | 后续形式未闭合（字节定位）/ 形式间空应用 / 引号空表拒绝 等 |
| 复杂程序负向 | ≥5 | 5（C01-C05，沿袭） | 257 深 / 200 深未闭合底 / 嵌套底空应用 等 |
| 错误恢复 | ≥5 | 5（D01-D05，沿袭） | 错→修正对（未闭合/前缀截断/空应用补算子/帽边界/转义修正） |
| **展开器负向（0.4 新增）** | — | **10（E01-E10）** | 未绑定单形式 / 未绑定后形式 / 深度预算越界（合成树）/ 相位违规（合成树）/ 双臂 if / 顶层裸表达式 / set! 未绑定 / 重复参数（core 再断言）/ 空表合成面 / 坏 handle 子句 |
| 七类覆盖 | 门审级 7/7 | **4/7**（语法错误 + 空应用 + 未绑定标识符 + 宏展开深度）；3 类结构性 DEFERRED 至各自落位子阶段（0.6/0.9），文件头与运行输出披露——冷启动代偿口径（plan-0.0.md §6 沿袭），0.11 门审 7/7 复核 |

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 4-a/5-a/6-a 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §19.2 骨架三不变式逐项落位（终止性 512 预算 / 卫生域键控 / 相位封闭 fail-closed）；TD-002 裁定结构性论证（零 span 构造 = 零跨代 join）；声明层/表达式层切分与 r67 真值一致；§18.5 生产面零新边 |
| DEV-A | ✅ 1.5 | 六命令全绿（冷构建 252:0:0）+ audit 40/40 exit 0；运行语义级实现缺陷 0（6 轮内循环全部为编译级形态 + 夹具语义 + 比例 + R8——逐例追认） |
| QA-A | ✅ 1.0 | 正负比 1:3 精确达标（12:36——首轮 12:34 未达标即补 2 真实负向，诚实实录）；GATE 1/3/6 合规；七类 4/7 点亮 + 3 类 DEFERRED 记账；审计集单调增长 30→40 |
| ALG-C | ✅ 1.0 | let\* 渐进绑定语义精确（值 i 仅见前 i-1 绑定）；域键控解析拒绝名匹配越权（foreign-scope 负向锚定）；深度预算 N+1 精确边界（头原子瞬态层计入）；全局回退序确定性（词法→全局→Unbound） |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭；fail-closed 全路径（未绑定/相位/空表/顶层表达式/目标不可解析五面拒绝）；`_` 弃置惯例不引入隐式语义 |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

## 8. 遗留债务（真实等级确认）

TD-001（P2，0.8）/ TD-003（P3 计划性，余 4 crate：compiler/vm/runtime/driver）/ TD-006（P3 机会性）。**TD-002 → [Resolved at 0.4]**（裁定三——本档 §4）。scoped-keyword 头分派升级 / 卫生并集 / transformer 执行 / span 集合表示 = 0.9 宏系统议程（登记态，零 Stage 0 义务）；STAGE0_GLOBALS parity 断言 = 0.7 runtime 议程（计划内）。

## 9. 下一子阶段入口

**0.5 kerf-compiler**：CoreExpr→Bytecode + debug_info_table（pc↔Span 映射）；指令操作数全解析；TD-004 裁定落地延续（Span 边活性）；跳转回填完备（§19.3 骨架：占位索引全消费 + CodeBuf 析构断言）；≥35 测试；输入条件 = 0.1（+0.4 ✅——fib 契约 CoreExpr 已锚定 compiler 消费面）。

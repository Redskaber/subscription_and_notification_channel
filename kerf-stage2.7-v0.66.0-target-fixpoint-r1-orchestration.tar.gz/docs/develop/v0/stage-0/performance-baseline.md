# Stage 0 性能基线（performance-baseline.md）

> 依据：docs/sop.md §14.6.4（性能测试标准——每个大阶段末尾必须建立性能基线）+ docs/stage0.md §22.3 里程碑第 8 项「性能基准已建立基线数据」
> 产出轮次：Stage 0.11 末轮（2026-09-28 首录）；**2026-09-29 方法学 v2 重录（r60 §9.61——有意方法学变更 = 文档化再基线非冻结打破）**
> 可重跑入口：`cargo run --release --example stage0_baseline`（examples/bench/stage0_baseline.rs——§14.6.4 规则 2 单入口；零新依赖：std::time + std::hint::black_box + 既有 crate API）
> 统计口径 v2：mean / median / min / stdev 四统计量（中位数为主判据——抗环境噪声；stdev+min = 离群可见面）；每轴预热段 max(3, iters/10) 不入样；优化器栅栏 std::hint::black_box（K90 best-effort 纪律）；B1 子轴拆分 B1a/B1b/B1c（阶段归因面）；每次代码变更后重跑对比（规则 3 回归检测）

## 1. 记录环境

| 项 | 首录 2026-09-28 | 方法学 v2 重录 2026-09-29 |
|----|----|----|
| rustc | 1.98.1 (48a229cea 2026-09-01) | 同 |
| profile | release（debug_assertions=false） | 同 |
| CPU | Intel(R) Xeon(R) Processor × 2 vCPU | 同 |
| 工作区版本 | v0.11.1（0.10-r3 基线 + 0.11 快照套件） | v0.30.0（r60 §9.61 方法学 v2 随本版本落地）；r70 重跑 = v0.40.0（§9.71 reader 轮——B 表 §2 刷新）；r71 重跑 = v0.41.0（§9.72 表示域轮——新沙箱环境 + SYN-1/2 实施后 B 表 §2 刷新） |

## 2. 基线数据（r89 §9.90 Stage 2.5 收口评估轮重跑——当前有效基线；r84 表降为历史层见本节尾注）

> **r90 复跑注记（2.6 评估窗开启轮——零触碰轮）**：本轮零生产/零 example/零守卫触碰（纯评估域 + 版本面），行权前置复查全轴复跑带内：B1 7.2µs / B1a 1.0 逐位 / B1b 3.8 / B1c 1.5µs / B2 79.311ms / B3 7.653ms / **B4 gc 1/swept 1023 逐位一致（第十四、十五次连续——r89 双跑后又一次）** / B5 79.360ms / B6 47.4/46.7/220.7ns / B7 21.831ms（自举乘数 3018× 带内）/ B8 3616.890ms（vs r89 首录 3614.497ms +0.07% 带内；vs B7 166×）。本表 r89 行维持当前有效基线地位。

> **r89 重跑触发面 = §14.6.4 规则 5 + B8 首录（本轮 example 基准 harness 触碰——examples/bench 增 B8 轴 + tests perf 守卫扩展；生产 crate 零触碰）。缺口披露（沿诚实括号纪律）：r87（B7 首录轮——example 面零生产触碰，B7 数字入册 calibration T2.4-2 与 round-records，未立本表行）与 r88（opcode.rs 反查表加法触碰——round-records 明载「本轮零基准触碰」）两轮未重跑本表——本轮全轴重跑溯及覆盖：两轮触碰面[B7 轴本体 + 加法性反查表]均为既有路径零行为变更，全轴带内实证零隐藏回归。环境注记：沙箱第六次重置延续（Rust 1.99.0 直承 r88 安装）——B 八轴全带内：B1 7.0µs / B1a 1.0 逐位 / B1b 3.5µs / B1c 1.5µs / B2 79.195-80.679ms / B3 7.630-7.646ms / **B4 gc-cycles 1 / swept 1023 逐位一致（第十二、十三次连续——评估轮双跑）** / B5 79.441-80.780ms / B6 三面（46.8/46.7-47.6/212.8-218.7ns——带内）/ B7 21.916-21.958ms（r87 首录 21.937ms 带内；自举乘数 3081×-3242× 随 B1 median 微漂——带内读数）。B8 不动点成本轴首录（§9.90）：**median 3614.497ms / stdev 35.608ms / min 3594.790ms（7 iters + 3 warmup）→ vs B7 median 165×**——fixpoint 驱动器三相位整跑（C(S) 双引擎 + C(C(S)) VM-only 括号 + 重建产品 VM 执行）的墙钟成本；fail-closed 每跑断言 fixpoint_holds（相等性为轴前置条件非产出）；消费面 = 2.6 构建编排评估的自举验证预算地板（B7×文件数 + B8×阶段数 = 自举构建总预算形状）。**

> r84 重跑触发面 = §14.6.4 规则 5 沿伸精神（生产 crates 零语义触碰——kerf-driver CP9 组成链 + tests/audit/docs 面 + audit example 主线程栈守卫，2.3 收口评估轮的 B 全轴对账义务）。**环境注记：沙箱第三次重置恢复轮（远端 9bc90a9 depth-1 替换 + Rust 1.99.0——前轮 1.98.1）**：全轴带内：B1 7.4µs / B1a 1.0 / B1b 3.7µs / B1c 1.5µs / B2 med 79.701ms / B3 med 7.696ms / **B4 gc-cycles 1 / swept 1023 逐位一致（第九次连续——组成链 = 消费面组合验证，生产码零触碰）** / B5 79.695ms / B6a 50.1ns / B6b 50.2ns / B6c 228.1ns（B2/B3/B5/B6 四轴较 r83 值带内改善方向漂移——新工具链环境归因如实登记，生产 crate 相对恢复基线零语义 diff）。



> r83 重跑触发面 = §14.6.4 规则 5 沿伸精神（生产 crates 零触碰——kerf-compiler 未动，kerf-driver parity 码轴扩展 + selfhost 第五件扩录 + tests/audit/docs 面 + 栈守卫三处 cfg(test)/examples 修复，2.3 第二 Pass 排期单源义务的 B 全轴对账）。**环境注记：新沙箱（r82 会话后续重置）——全轴带内：B1 7.3µs / B1a 1.0 / B1b 3.5µs / B1c 1.5µs / B2 med 84.190ms / B3 med 7.965ms / **B4 gc-cycles 1 / swept 1023 逐位一致（第八次连续——发射域 = .krf 消费面扩展，Rust 编译器生产码零触碰）** / B5 83.417ms / B6a 47.4ns / B6b 47.1ns / B6c 220.9ns（B6 三面 r81/r82 值带内）。61-a 预查轮另录一次（B1 7.4/B1a 1.4µs median 微漂 min 1.0/B6c 241ns——环境噪声面如实登记，生产 crate 相对 HEAD 零 diff 归因；终态以本行 r83 实测为准）。**

## 2i. r82 历史层（2026-10-01 r82 §9.83 Stage 2.3 fixpoint 窗开启轮重跑）

> r82 重跑触发面 = §14.6.4 规则 5 沿伸精神（生产 crates 零触碰——kerf-driver 新增 parity 前端 + selfhost 第四件 + tests/audit/docs 面，2.3 第一 Pass 排期单源义务的 B 全轴对账）。**环境注记：与 r81 同沙箱延续——全轴带内：B1 7.4µs / B1a 1.0 / B1b 3.6µs / B1c 1.6µs / B2 med 83.2ms / B3 med 7.9ms / **B4 gc-cycles 1 / swept 1023 逐位一致（第六次连续）** / B5 83.6ms / B6a 46.9ns / B6b 47.5ns / B6c 211.5ns（B6 三面 r81 首录值复现带内——分析段零生产语义变更）。**

## 2h. r81 历史层（2026-10-01 r81 §9.82 Stage 2.2 收口验证轮重跑 + B6 首录）

> r86 重跑触发面 = §14.6.4 规则 5（kerf-driver src 触碰——§9.87 全组成链：composed_full_chain.rs 新模块 + lexer_parity.rs junction 馈送扩展 + expander/compiler_parity.rs 可见性与空表前缀；生产 crate 零触碰——harness 面独占）。**环境注记：与 r85 同沙箱延续——B 七轴带内：B1 7.0µs / B1a 1.0 逐位 / B1b 3.4µs / B1c 1.6µs / B2 79.404ms / B3 7.615ms / **B4 gc-cycles 1 / swept 1023 逐位一致（第十次连续）** / B5 79.423ms / B6 三面复现（B6a 48.4ns / B6b 48.3ns / B6c 204.2ns median——带内）。r85（词法层轮）同为 harness 面触碰未单独重跑——本轮在带读数溯及确认零漂移。**
> r81 重跑触发面 = §14.6.4 规则 5 沿伸精神（生产 crates 零触碰——纯验证域轮[tests/audit/bench/docs 面]，2.2 排期单源义务的 B1-B5 对账 + B6 首录）。**环境注记：与 r80 同沙箱延续——B1-B5 全轴带内：B1 7.0µs / B1a 1.0 逐位 / B1b 3.5µs / B1c 1.6µs{median——mean 1.9 受单跑离群 stdev 7.8 拉高，median 判定带内} / B2 82.824ms / B3 7.950ms{+0.5%} / **B4 gc-cycles 1 / swept 1023 逐位一致（第五次连续——r80 语义翻转后零回归对账收官）** / B5 82.904ms。**B6 闭包创建轴首录（★1' 量化实证——§9.82.4）：B6a captured=1/width=4 median **47.8ns** / B6b captured=1/width=100 median **47.7ns**（帧宽 25× 成本持平——O(captured) 非 O(n_locals) 实测；dormant 全帧克隆下 B6b 形态将为 ~25× B6a） / B6c captured=25/width=100 median **222.2ns**（固定 ~40ns + ~7.3ns/捕获线性）；纯指令级隔离[手工字节码万次 closure;pop 展开循环] + 确定性结构/计数守卫（env 恰 C 槽 + swept 恰 N-1）在 capture_cost_guard_tests。**
> r80 重跑触发面 = §14.6.4 规则 5（kerf-compiler/kerf-vm/kerf-runtime/kerf-typecheck src 四 crate 触碰——§9.81 Stage 2.1 语义同刀：LA-1/LA-4 捕获分析 + LA-3 load-captured/Frame.captured/Closure 选择性拷贝 + LA-5 求值器镜像 + 检查器穿透——语义级变更首轮）。**环境注记：与 r79 同沙箱延续——全轴 25% 带内：B1 7.5µs / B1a 1.1 / B1b 4.0µs{+11% 结构性：proto 新字段[parent+captures]初始化 + 新分派臂——fib 无捕获故非语义成本} / **B1c 1.6µs{1.5→1.6 +6.7% 带内：同源结构性}** / B2 83.772ms / B3 7.912ms{+7.5% 带内：invoke 捕获区安装面} / **B4 gc-cycles 1 / swept 1023 逐位一致{churn 基准无闭包——GC 根集扩展零扰动实证}** / B5 84.053ms**。语义翻转轴（闭包密集负载的 O(captured) 收益 + GC 保留精确化）= MUV 3 收口轮量化对账面（★1' 化解实证——已随 r81 B6 首录 + 守卫族兑现）。
> r79 重跑触发面 = §14.6.4 规则 5（kerf-compiler src 触碰——§9.80 LA-2 捕获描述符零消费落地：FuncProto.captures 字段 + verify Closure 位点扩展；compile 产品恒空表）。**环境注记：与 r78 同沙箱延续——全轴带内：B1 7.0µs / B1a 1.0 / B1b 3.5 / B1c 1.5µs 逐位一致（描述符空表对 compile+verify 零成本）/ B2 82.516ms / B3 7.398ms / **B4 gc-cycles 1 / swept 1023 逐位一致（零语义变化最强实证）** / B5 81.410ms**。
>
> r78 重跑触发面 = §14.6.4 规则 5 沿伸精神（kerf-driver src 注释面触碰——§9.79 FMT-1 破折号归一[expander_parity.rs 17 处注释行] + selfhost 三件空白级重排[strip-compare 逐位一致实证——注释非 token，token 流不变]；生产行为零触碰）。**环境注记：与 r77 同沙箱延续——全轴带内：B1 7.3µs / B1a 1.1 / B1b 3.6 / B1c 1.5µs / B2 80.873ms / B3 7.374ms / **B4 gc-cycles 1 / swept 1023 逐位一致[空白级变更零语义影响最强实证]** / B5 80.776ms**。

> r74 重跑触发面 = §14.6.4 规则 5 沿伸精神（kerf-driver src 触碰——§9.75 BST-2 harness 限额分类[harness_run_failure 单源化] + BST-1/BST-3 测试树包裹与守卫；生产路径零触碰——分类仅消息面）。**环境注记：新沙箱（栈限 8MB——冷跑 mp7 栈溢出实况正是本轮开面证据，BST-1 修复后全绿）——编译轴 B1 7.3/7.1 + 7.1/6.9µs 双跑带内（r73 7.2/7.1µs）+ B1a 1.0µs 逐位一致 + B1b 3.6/3.5µs 逐位级 + B1c 1.5/1.5 + 1.5/1.4µs 带内；B2 80.839/80.660 + 80.759/80.323ms 双跑带内（r73 81.4ms 带内微优）；B3 7.327/7.320 + 7.322/7.320ms 双跑带内（r73 7.431/7.435ms）；B5 80.669/80.436 + 80.622/80.386ms 双跑带内。BST-2 消息面重构零回归面——driver 触碰面在 B5 e2e 轴带内实测确认。B4 确定性计数逐位一致（gc-cycles 1 / swept 1023——零 GC 语义漂移）。**

> r73 重跑触发面 = §14.6.4 规则 5 沿伸精神（kerf-driver src 触碰——§9.74 PAR-1 parity 机器三重孪生驱动单源化[drive_dual_engines + decode_tagged]。**环境注记：与 r72 同沙箱延续——编译轴 B1 7.2/7.1µs 双跑持平（r72 7.0µs 带内）+ B1a 1.0µs 逐位一致 + B1b 3.6/3.5µs 带内 + B1c 1.5/1.4µs 逐位级；B2 首跑 85.0ms 偏高（环境冷启动离群）→ 双跑第二跑 81.4ms 回归 r72 带内（81.257/80.498ms）——判定 = 环境噪声 + 带内；B3 7.431/7.435ms 双跑带内（r72 7.500/7.318ms 居中）；B5 81.446/81.405ms 双跑带内（r72 81.541/80.216ms）。PAR-1 单态化静态分派零回归面——driver 触碰面在 B5 e2e 轴带内 = 驱动重构零成本实测确认。B4 确定性计数逐位一致（gc-cycles 1 / swept 1023——零 GC 语义漂移）。**

> r72 重跑触发面 = §14.6.4 规则 5（kerf-vm/kerf-runtime src 触碰——§9.73 EVL-1/EVL-2 分派单源化[dispatch_builtin + BuiltinHost]）。**环境注记：与 r71 同沙箱延续——VM 轴（B2 81.257/80.498ms、B5 81.541/80.216ms 双跑）与 eval 轴（B3 7.500/7.318ms 双跑）均在 r71 环境带内（±1.5% 双跑稳定）；编译轴 B1 7.0µs median 持平 + B1a/B1c 逐位一致（1.0µs/1.5µs）+ B1b 3.5µs 带内。EVL-1 单态化静态分派零 vtable 成本——结构性无回归面，实测确认。B4 确定性计数逐位一致（gc-cycles 1 / swept 1023——零 GC 语义漂移）。**

> r71 重跑触发面 = §14.6.4 规则 5（kerf-syntax/kerf-core/kerf-vm/kerf-expander/kerf-driver src 触碰——§9.72 SYN-1 共享载荷链 + SYN-2 身份去重）。**环境注记：本轮测量于沙箱重置后的新环境（工具链 1.98.1 重装）——VM 轴（B2/B5）较 r70 记录 +6.0~+7.5% 稳定偏移（两次复跑 80.7/79.8ms 与 80.4/81.0ms 一致），编译轴持平或更优（B1 7.3→7.1µs −2.7% / B1c 逐位一致），fib 工作负载零字符串字面量（SYN-1 触碰面不在 B2 路径）——判定 = 环境归因 + 全轴带内（±25% 带内）。** SYN-1 收益面 = 结构性分配减少（每物化/每局部装载 1 次 alloc+memcpy → 1 次计数递增 + 三表示 32→24B）——无专属 B 轴（fib 无字符串），正确性面由守卫族承载（Rc::ptr_eq 三件[池条目/物化/reader→expander 链] + 布局钉扎 size_of==24）；B4 确定性计数逐位一致（gc-cycles 1 / swept 1023——零 GC 语义漂移）。

| 项 | 工作负载 | 迭代 | mean | median | min | stdev | 判读 |
|----|---------|------|------|--------|-----|-------|------|
| B1 compile-fib | fib 源码 → read + expand + compile + verify 全编译链 | 1000 | 7.5µs | 7.2µs | 6.7µs | 1.2µs | 编译面基线（r75 双跑 7.4/7.5µs 新沙箱 1.98.1 环境带内——r74 7.1-7.3µs 持平维持）；r77 带内 7.4µs；r78 带内 7.3µs（注释面零成本实测）；r79 带内 7.0µs（§9.80 LA-2 描述符空表零成本——B1c 逐位一致佐证） |
| B1a read-fib | read 子轴 | 1000 | 1.1µs | 1.0µs | 1.0µs | 0.2µs | 阶段归因子轴（r75 双跑 1.1/1.1µs 逐位级维持；§9.71 RDR-1 域主账 −21.4% 改善带保持）；r77 带内 1.2µs（沙箱四新工具链环境）；r78 带内 1.1µs；r79 带内 1.0µs |
| B1b expand-fib | expand 子轴 | 1000 | 3.7µs | 3.6µs | 3.5µs | 0.5µs | 同上；r75 双跑 3.6/3.7µs 带内（r71 记录 3.6µs 维持）；r77 带内 3.8µs；r78 带内 3.6µs；r79 带内 3.5µs |
| B1c compile+verify-fib | compile+verify 子轴 | 1000 | 1.5µs | 1.5µs | 1.4µs | 0.4µs | 同上；r75 带内（§9.70/§9.71/§9.72/§9.76 先例第五轮延续）；r77 带内 1.5µs；r78 带内 1.5µs（逐位一致）；r79 带内 1.5µs（逐位一致——LA-2 零消费落地编译轴零扰动实测） |
| B2 vm-run-fib25 | fib(25)=75025（入口消费闭包——0.6 锚负载） | 100 | 80.766ms | 80.302ms | 80.135ms | 2.373ms | VM 执行面基线（r75 双跑 81.189/80.719 + 80.766/80.302ms——新工具链环境带内；r74 80.839/80.660 + 80.759/80.323ms 持平；§9.69 −13.0% 改善带[r70 判读]保持）；r77 带内 81.888/80.672ms（首跑冷启动离群 stdev 4.3ms——历史区间 [80.0, 86.6] 内） |
| B3 eval-run-fib20 | fib(20)=6765（元循环求值器——双路径对照面） | 30 | 7.315ms | 7.312ms | 7.284ms | 0.024ms | eval 路径基线（r75 双跑 7.326/7.315 + 7.315/7.312ms——r74 7.327/7.320 + 7.322/7.320ms 带内持平；§9.67 −34.3% 改善带[r70 判读]保持）；r77 带内 7.379/7.373ms |
| B4 gc-pressure-churn | 2000 顶层丢弃 pair 分配（预算 1024——collect-then-retry 实路径） | 50 | 0.313ms | 0.311ms | 0.308ms | 0.005ms | GC 面基线：gc-cycles/iter 1，swept/iter 1023——**确定性计数与首录逐位一致（r75 双跑双绿维持——零 GC 语义漂移）；逐 run 精确值已由守卫测试 b4_churn_counters_exact_per_run 锚定**；r77 逐位一致（gc 1/swept 1023） |
| B5 driver-e2e-fib25 | run_source VM fib(25)（session + 管线 + halt 快照全链） | 50 | 80.655ms | 80.342ms | 79.823ms | 1.244ms | 端到端基线（B2 + 驱动层开销；r75 双跑 80.637/80.495 + 80.655/80.342ms——r74 80.669/80.436 + 80.622/80.386ms 持平带内；§9.76 SER-1 守卫零 happy-path 成本实测）；r77 带内 80.677/80.641ms（§9.78 MSG 族全位于错误路径——B5 e2e 轴零回归实测） |
| B6 closure-create（★1' 轴——r81 首录） | 手工字节码万次 `closure;pop` 展开循环（B6a captured=1/width=4 · B6b captured=1/width=100 · B6c captured=25/width=100；200 runs × 10,000 creations） | 3×200 | — | **B6a 47.8ns / B6b 47.7ns / B6c 222.2ns**（逐创建） | — | — | ★1' 双成本化解量化实证（§9.82.4）：宽度无关面——B6b/B6a 帧宽 25× median 持平（O(captured) 非 O(n_locals)；dormant 全帧克隆下将为 ~25×）；伸缩面——B6c ≈ 固定 ~40ns + ~7.3ns/捕获线性；确定性双证在 capture_cost_guard_tests[env 恰 C 槽 + swept 恰 N-1] |

**子轴物理注记**：B1a+B1b+B1c ≈ 6.1µs < B1 复合 7.3µs——子轴循环单阶段更热（缓存局部性）周知测量物理；两口径并行报告不互推（复合值承担与首录/v0.23.0 实测的可比性，子轴值承担阶段归因）。

**历史首录（2026-09-28 方法学 v1——保留作历史层：无栅栏/无预热/mean+median 双统计量）**：

| 项 | 迭代 | mean | median |
|----|------|------|--------|
| B1 compile-fib | 1000 | 9.7µs | 9.3µs |
| B2 vm-run-fib25 | 100 | 96.8ms | 96.7ms |
| B3 eval-run-fib20 | 30 | 9.4ms | 9.4ms |
| B4 gc-pressure-churn | 50 | 0.37ms | 0.36ms（gc 1 cycle/iter，swept 1023/iter） |
| B5 driver-e2e-fib25 | 50 | 98.4ms | 97.6ms |

**回归判定口径（规则 3）**：median 恶化 > 25%（环境噪声带）= 性能回归 → 定位变更轮次并评估；B4 的 gc-cycles/swept 为行为指标——数值变化即语义变化（分配率或存活集变更），必须解释（守卫测试 perf_observability_guard_tests 锚定逐 run 精确值）。

## 3. 热点识别（规则 4——O(n²) 或更差算法的优化候选登记）

| 热点 | 复杂度现状 | 证据 | 处置 |
|------|-----------|------|------|
| VM 解释循环 fib(25) ~87ms（v2 重录） | fib 调用树指数级（242,785 calls ≈ 1.16µs/call） | B2/B5 | 负载本性（naive fib 无记忆化）——非实现缺陷；吞吐对 Stage 0 树遍历 VM 属预期量级 |
| eval 元循环 fib(20) 10.3ms（v2 重录） | 同上 + 每步 ClosureData 分配 | B3 | 对照面设计目的（parity 双路径互查）——性能非其验收轴 |
| 字节码编译 ~7.7µs/fib 全链（v2 重录；子轴 read 1.4 / expand 3.5 / compile+verify 1.5） | 线性于 AST | B1 + B1a/b/c | 无热点；子轴归因面已备（§9.61 PERF-3） |
| 标记-清除全停顿 | O(live+slots) | B4 | Stage 2+ 演进窗登记（分代/并发 GC——stage0.md §9.43 K7 对照表已登记） |

**结论**：Stage 0 无功能性性能缺陷（语义正确性优先——原则 19）；B4 全停顿 GC 为已知登记态演进窗，非本阶段债。

## 4. 变更同步义务（规则 5——r60 强化版）

- **触发面（r60 扩充）**：本表由每次触碰**生产面**的轮次重跑刷新——即 `crates/*/src` 任何变更（含表示层——§9.44.3 第 1 行族：表示置换类变更直接影响 B1 链，T35 先例即属此类）或基准 harness 本体（examples/bench/）变更；worklog 记录对比。
- **r60 失察修复记录（§9.61 PERF-4）**：T30-T37 十轮无 B 系列重跑记录（v0.24.0-v0.29.0——其中 T33/T35 触碰生产面）；本次重录验证失察期**零回归**（B1 7.7µs 与 v0.23.0 实测一致 / B4 确定性计数与首录逐位一致）；起每轮九项复查增设第 ⑩ 项「B 系列重跑义务核对」，守卫测试 perf_observability_guard_tests 锚定 B4 确定性计数防再犯。
- `docs/tests/pipeline-test-coverage.md` 性能基线表引用本文件（不重复承载——单一事实源 §8.4.5）。
- 基线数值只在环境变更（rustc/CPU）、有意优化或有意方法学变更时整体重录（再基线须文档化记录——本次 v2 重录即先例），禁止静默漂移。

# Stage 0.9 子阶段计划与交付实录——CodeValue + 基础卫生宏系统 + 模块加载层 + quote 消费面

> **依据**：docs/sop.md §21（阶段规划）/ §4（MUV 六字段）/ §9.4.3（测试构成）/ §7.2/§7.3/§6.3（L2 外循环）
> **设计锚**：stage-0-plan.md §5 行 0.9（CodeValue + 基础卫生宏系统——卫生保证 + 七类第 7 类点亮 + 宏展开 E2E）+ plan-0.4.md §4 裁定三（0.9 议程：expansion_id 递增 + span 集合表示）+ plan-0.7.md 决策 13（quote 登记态边界——0.1 LiteralValue::Pair 消费面）+ plan-0.8.md §0.9 消费契约（Session/渲染/CLI = 宏展开 E2E 基础设施）+ docs/stage0.md §8.10（基础宏系统——卫生宏 + SyntaxObject 骨架）+ §19.2（展开循环骨架 + 核心不变式三条 + 实现陷阱三则）+ §9.38(b)（scope coloring + rename-on-capture 双算法）+ §6.1/§6.3（CodeValue 结构化代码值——substitute/alpha_rename/free_variables 能力模型）+ §8.9（模块生命周期 declare/instantiate/visit）+ SOP §7.1.1（七类矩阵——第 7 类 module_loader: circular dependency）
> **状态**：✅ 已交付（2026-09-28）——624:0:0 · 审计集 90/90（**七类 7/7 全点亮——门审级首次达成**）· v0.10.0

## 1. 任务构成

| MUV | 内容 | 落位 |
|-----|------|------|
| 12-a-1 | 测试文档先行（§9.2 规则 1）：FP1 CodeValue / FP2 syntax-rules 变换器 / FP3 子集解析规则 + 宏登记簿 / FP4 模块加载层 / FP5 quote + 宏分派 + E2E——预期数 + 审计集 80→90 口径 + 边界申报七项 | docs/tests/v0/stage0/plan/macro.md（实现前落档） |
| 12-a-2 | kerf-core 声明层第四变体 `ModuleItem::DefineSyntax`（零码记录——编译器/求值器跳过，Require 先例对偶）+ kerf-syntax `ExpansionId` 再导出（变换器生产面消费——加法零语义变更） | crates/kerf-core/src/module.rs + crates/kerf-syntax/src/lib.rs |
| 12-a-3 | kerf-expander 四新模块 + 三模块演进：`code.rs`（CodeValue 六操作——from_syntax/to_syntax/substitute/alpha_rename/symbols/to_source + 元数据访问器）+ `transformer.rs`（syntax-rules 解析/匹配/实例化 + def 着色 + 代次递增 + **rename-on-capture**）+ `module.rs`（声明收集 + require 边 + 三色 DFS 环检测 + 实例化次序）+ `ctx.rs`（**binder-scopes 子集解析**——0.4 membership 一般化 + Frame.macros + 变换器 slab）+ `expand.rs`（quote 形式 + define-syntax 声明 + 宏使用分派[核心形式后/应用前]）+ `error.rs`（+MacroPatternMismatch/+QuoteUnsupportedDatum）+ `lib.rs`（再导出面） | crates/kerf-expander/src/{code,transformer,module,ctx,expand,error,lib}.rs |
| 12-a-4 | 消费方三处：kerf-compiler DefineSyntax 零码跳过（ConstKey::Pair 0.5 既有面首次生产性消费）+ kerf-runtime eval 零操作跳过 + kerf-driver（pipeline::parse 挂接 load_program——模块错误经 Diagnostic::from_module 渲染 + REPL is_declaration 增 define-syntax 头） | crates/kerf-compiler/src/compile.rs + crates/kerf-runtime/src/eval.rs + crates/kerf-driver/src/{pipeline,diagnostic,repl}.rs |
| 12-a-5 | 跨 crate 集成 27 case（宏 E2E 双引擎 + parity + 卫生可观察值 + quote car/cdr 链 + 模块程序 + REPL 跨行 + 宏产宏两代 + CodeValue 真语法面 + 诊断渲染族 15）+ 审计集 J 节（80→90：宏匹配/卫生防御/quote 边界/**模块环 ×2[第 7 类点亮]**/模块缺失/重名/注册族） | tests/v0/stage0/plan/macro_seed_tests.rs（经 runner.rs）+ examples/audit/stage0_gate_audit_r1.rs |
| 12-a-6 | 文档族十件 + 版本 0.10.0 + commit | docs/ + Cargo.toml |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，冷构建实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1197 files / 247.8MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（10 crates + bin kerf，冷构建 5.34s） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example/bin 目标） |
| `cargo test --release` | ✅ **624 passed / 0 failed**（551 基线零回归 + **净 +73**：expander 内联 55[code 5 + ctx 12 + transformer 12 + module 8 + expand 33 − 旧 21 净增... 计 api 前口径] + core 1 + 根集成 27；轮构成 34:39 ≈ 1:1.15——偏差申报见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 90/90**（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + **J10 宏/模块/quote**；exit 0）——**七类 7/7 全点亮** |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 新增源面（code/transformer/module/ctx/expand/error/lib + 消费方五文件 + macro_seed_tests + 审计 J 节）= **零命中**（§/TD 技术锚原样保留合法）。*.md 面豁免位不计。**零未登记非英文编码面**。

**内循环实录（§5.3——诚实记录，7 轮）**：R1 编译级 8（kerf-span dev-dep 误用于生产码 ×3 文件——module/transformer 生产面须走 kerf-syntax 再导出[ExpansionId 再导出加法补齐]、StxSymbol 未用导入、lifetime 显式标注 ×2、sed 残留清理、`collisions` Vec 生命周期）；R2 **设计级缺口发现补齐 1**（CoreExpr 名字基事实：引入绑定与拼接实参同名时 VM 按名解析错误捕获——展开层子集判据正确但名字基后半天堑；发现路径 = 卫生 E2E 测试设计推演（非运行炸裂）；**rename-on-capture 机制补齐**——§9.38(b) 第二算法作为实例化期配套：触发集 = 拼接实符号 ∪ STAGE0_GLOBALS ∪ 保留名，`name__macro_N` 新鲜名 + 引入引用同步重命名 + 嵌套同名栈式遮蔽）；R3 **死变体发现删除 1**（UnboundMacro 无自然生产触发点——头名无绑定时函数/宏二义，Racket 统一 UnboundIdentifier 判据；R1 桩纪律——死变体 = 桩同罪）；R4 **表面语法事实裁定 1**（reader 拒绝 `()`[0.3 决策 3] → syntax-rules 字面量空表 = `nil` 拼写——与语言空表拼写全局一致；文档-代码冲突以代码为准 §8.4.5 + 测试文档同步）；R5 测试侧 7（bool 字面量皮肤事实 true/false→`#t`/`#f` + REPL 条件期望反 + pattern-mismatch span 声明位→使用位[rustc 惯例裁定] + 模块遍历 HashMap 序不确定→声明序 + 引号列期望 + fixture span 期望 + `true` 符号≠bool 数据）；R6 clippy 尾清（unused import ×1 + fmt）；R7 六命令冷构建终态全绿 + audit 90/90。**实现侧运行语义缺陷 0**（R2 为设计期预防性补齐——E2E 前推演发现；R3/R4 为设计决策修正）。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元 code.rs | CodeValue 六操作（全总数函数——无错误面） | 5 | 0 |
| 单元 ctx.rs | 子集解析 + 宏登记簿 + 预算（净增） | 1 | 1 |
| 单元 transformer.rs | 解析/匹配/实例化/代次/重命名 | 7 | 5 |
| 单元 module.rs | 装载层（环 ×3 + 缺失 + 重名 + 次序） | 3 | 5 |
| 单元 expand.rs | quote + define-syntax + 宏使用 + 卫生（净增） | 6 | 10 |
| 单元 error.rs | 新变体渲染面（净增） | 0 | 2 |
| 单元 core module.rs | DefineSyntax 构造（净增） | 0 | 1 |
| 跨 crate 集成 | macro_seed_tests.rs（经 runner.rs） | 12 | 15 |
| **0.9 合计** | | **34** | **39** |

- **比例申报**：轮 34:39 ≈ **1:1.15**（正向偏斜——沿 0.8 反向偏差先例）。**偏差披露**：① 宏展开 E2E = plan 行 0.9 验收标准本体「定义宏→使用→展开→执行」四段全正向不可拆负向（双引擎 ×2 + parity + 卫生可观察值 ×2 + 宏产宏 + 模块程序 + REPL 跨行 + check + CodeValue 真语法面 = 12 正向全为验收面）；② CodeValue 六操作 = §6.3.3 设计 API 合同面（全总数函数——无错误面可拆）；③ 负向已穷尽：错误新变体五族全负向（MacroPatternMismatch ×4 + QuoteUnsupportedDatum ×3 + ModuleError ×3 族 8 case）+ 注册校验族（重复变量/省略号/形状 ×3/保留名 = 6）+ 卫生防御族（双向捕获 4 + 模块隔离 2）+ 深度 ×2 + 形状守卫 3；④ 凑数拆分违反 §12 最优>最小。累计 215:409 ≈ 1:1.90（workspace 551 → **624**）。
- 集成构成（GATE 6 其余项全达标）：macro_seed 27 case：正向 12 ≥1 / 负向 15 ≥3 / 跨阶段消费（五段一断 E2E + expander→core/compiler/runtime/driver 四消费面 + 宏产宏两代 + REPL）≥1 ✅
- **七类 7/7 全点亮**（首次双门槛达成）：子阶段级 = 第 7 类模块循环依赖经 driver E2E 源级可达（J06/J07 + seed `neg_module_cycle_*` 三形态）；门审级 = §7.3.1 规则 1 门槛 7/7 同轮达成（matrix.md 累计视图记账）

## 4. 设计对齐记录（§13.1——裁定与决策入档）

### 裁定十四（0.9）：卫生 = 双机制配套——scope coloring 定展开期绑定 + rename-on-capture 保名字基后端

§9.38(b) 列两算法；本轮裁定为**配套而非择一**：① **scope coloring + binder-scopes 子集判据**（ctx.rs——0.4 membership 一般化为 Racket "Binding as Sets of Scopes" 子集判据；Frame 携带绑定出现位作用域集 base ∪ {fresh}；非宏代码两集恒等 → 0.4 行为结构性保持[551 基线零回归实证]）决定**展开期**绑定：引入绑定携 def 域而拼接实参不携（反之亦然）——双向零捕获；② **rename-on-capture**（transformer.rs——触发集 = 拼接实参符号 ∪ STAGE0_GLOBALS ∪ 保留名[RESERVED_MACRO_NAMES 单源]；`name__macro_N` 计数新鲜名[触发集防碰撞]；引入绑定 + 引入引用同步重命名，拼接节点永不动）把判据**传导进名字基后端**（CoreExpr/字节码/VM 按 Var 名解析——无重命名则 VM 名字遮蔽破坏展开期正确判定）。验证：`introduced_binding_renames_away_from_the_use_site_name`（引入参 `tmp__macro_0` 断言）+ `e2e_hygiene_wrap_produces_the_use_site_value`（无卫生 200 / 有卫生 101 可观察值）+ `e2e_introduced_binder_reachable_and_isolated`（15/105 双向）。

### 裁定十五（0.9）：syntax-rules 字面量空表 = `nil` 拼写（文档-代码冲突以代码为准）

stage0.md §29 示例 `(syntax-rules () ...)` 假设 `()` 可读——与 plan-0.3 决策 3（reader 拒绝 `()` 空应用——七类 #3 检测点）冲突。裁定：**`nil` = 字面量空表拼写**（与语言空表全局拼写一致——`nil` 保留字既有事实）；非空字面量表 `(else =>)` 照常。依据 §8.4.5 文档与代码冲突以代码为准 + 本档修正登记（测试文档 macro.md 同步）。

### 裁定十六（0.9）：未绑定宏头 = 统一 UnboundIdentifier（Racket 判据）——UnboundMacro 变体不设

头名无绑定时函数调用/宏使用二义：专用 UnboundMacro 变体无自然生产触发点（分派序核心形式→宏→应用，宏未命中即落应用）——死变体 = 桩同罪（R1 纪律）删除。宏相专用错误族自 **pattern 匹配**起（MacroPatternMismatch 报**使用点** span——rustc 惯例：指向用户写错处）。

### 决策 13 项（0.9）

1. ModuleItem 第四变体 DefineSyntax = 声明层忠实记录（零码——编译器/求值器跳过，Require 先例对偶）——而非展开期静默吞掉（唯一可信数据源：模块声明面完整）
2. 变换器登记于当前帧（Frame.macros）——词法作用域同 define；嵌套 module 隔离由 isolate_frames 既有机制承接（出模块即不可见）
3. 宏分派序：核心形式 → 宏 → 应用（平面分派序 0.4 简化沿袭——宏遮蔽普通应用；核心形式不可遮蔽 → 保留名注册期拒绝[报错>静默]）
4. 宏仅在**列表头位置**分派（裸标识符位置不触发宏——Stage 0 边界；Racket 全位置展开 = Stage 1+ 议程）
5. 引入节点 span = 模板字节区间 + ExpansionId(使用代次+1)（dea12b 范式：引入 > 0 / 用户 token = 0；嵌套宏跳单调递增实证 gen 2）
6. 拼接实参**原样**拼接（span/scopes/phase/name 四保持——使用处身份完整）
7. quote = 数据字面量面（0.1 LiteralValue::Pair 消费面兑现[plan-0.7 决策 13]——原子 + proper list 右折 Pair 链终于 Nil；符号 fail-closed[QuoteUnsupportedDatum]——Stage 0 值模型无 Symbol 变体，Stage 1 演进位；§19.2 多阶段 quote/splice = Stage 2+ 区分登记）
8. 模块加载层交付 = 图验证 + 实例化次序（LoadPlan DFS 后序依赖先行）；**require 可见性合并 = Stage 1 模块系统面**（编译器 flat 编译[compile.rs L503 注释预告兑现] + eval 平铺[0.7] 先例对偶）
9. 模块名平面命名空间（嵌套声明递归收集；重名 fail-closed ModuleDuplicate；遍历序 = 声明序[确定性]）
10. 环检测 = 三色 DFS（GRAY 回边闭合——环路径全名 a -> b -> a；span = 闭环绕的 require 位）+ 模块内 require 递归归边（嵌套 module 的 require 属图全体验证域）
11. CodeValue.symbols = 语法普查（无类型层无 binder 模型——`free_variables` 语义面 = Stage 2+ 演进位；§6.3.3 API 名诚实化）
12. 展开缓存不实现（解析期作用域键即查即用——§19.2 陷阱 2 的解析期兑现；缓存 = 性能面 Stage 2 优化窗登记态）
13. `syntax-rules` 零规则合法（使用即 MacroPatternMismatch——Racket 先例；非注册期错误）

## 5. 边界申报（非 TD——设计边界，零机制变更义务）

省略号 `...` 图案不支持（§8.10「不支持复杂的宏组合」——注册期 fail-closed）/ quote 符号数据不支持（Stage 0 值模型无 Symbol——fail-closed 报错）/ CodeValue.symbols 语义 = 普查非自由变量（Stage 2+ 演进位）/ require 可见性合并不交付（Stage 1）/ 宏跨程序/跨文件不持久（单文件程序 + REPL 累积源重解析——§8.9 多文件 = Stage 1）/ 变换器 = syntax-rules 单一形态（proc-macro 风格显式变换器 = Stage 1+）/ 宏全位置展开不交付（列表头位置 = Stage 0 边界）/ 展开缓存不实现（Stage 2 优化窗登记态）/ 同名模板自由引用与引入绑定同名的极端形态按源级遮蔽语义处理（模板作者命名选择——登记于裁定十四验证注记）。

## 6. 审计集构成映射（§7.3.1 规则 2/4——80→90 单调增长）

| 节 | 数 | 构成 |
|----|----|------|
| A-I | 80 | 0.3-0.8 既有九节零改动（A10 单语句 + B10 多语句 + C5 复杂 + D5 错误恢复 + E10 展开器 + F10 编译器 + G10 VM + H10 运行时 + I10 driver E2E） |
| **J10（0.9 新增）** | 10 | J01 宏匹配（使用点位）+ J02 quote 符号边界 + J03 卫生防御·使用处绑定不捕获引入引用 + J04 卫生防御·头无绑定统一判据 + J05 自递归宏深度（类 5 宏面维持）+ **J06 模块环双模块（类 7 点亮 + 环路径）+ J07 模块环三模块** + J08 模块缺失 + J09 模块重名 + J10 注册族（省略号边界 + 保留名） |

## 7. 外循环（§7.2 防崩 + §6.3 投票——单 Agent 模拟披露沿先例）

- Q1 无桩（UnboundMacro 死变体当轮删除——R1 纪律执行）；Q2 0.10 可直接消费（接口预留冻结输入 = 本轮 ModuleItem 四变体终态 + 卫生判据定态）；Q3 E2E 27 case 全链覆盖；Q4 TD-006 不阻塞（文档质量类）；Q5 入口函数全有真实调用方（load_program ← pipeline::parse；CodeValue ← macro_seed + 变换器内部模板存储；instantiate ← expand_macro_use）；Q6 docs/ 十件同步 ✅
- 投票（权重 ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1）：ARCH-A ✅（裁定十四双机制 = §9.38(b) 完整落位 + 子集判据 0.4 结构性兼容实证）/ DEV-A ✅（551 零回归 + 净 +73）/ QA-A ✅（七类 7/7 双门槛 + 比例偏差申报受理——验收面不可拆论证 + 负向穷尽清单 + §12 凑数违反禁止）/ ALG-C ✅（三色 DFS + 子集判据 + rename 触发集防碰撞——确定性全过）/ SKL-A ✅（不记权，无 NEEDS REVISION）= **5.5/5.5**

# Stage 0.1 子阶段计划与交付实录——kerf-core CoreExpr 种子

> **Task ID**：4-a（flat worklog 对应条目）
> **性质**：Stage 0 第二子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~1300 行新代码+测试；依赖风险中——新增 DAG 边 span→core 为 TD-004 预裁定项；历史缺陷密度低——0.0 遗留零 P0/P1）
> **设计对齐**：docs/develop/v0/stage-0/0.1-design-adjudications.md（TD-005 裁定一 + TD-004 裁定二，开工首议程）

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 设计对齐（§13.1） | TD-005 原语集正式裁定 + TD-004 span→core 边裁定（ARCH-A/ALG-C 双角色会签） | ✅ 裁定文落档 |
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/core.md（FP1-4 + 预期数 12:36） | ✅ 实现前落档 |
| 实现 | kerf-core 四模块（symbol/error/expr/module）+ lib 再导出面 | ✅ |
| 三层测试 | 单元 32（8+24）+ crate API 8（2+6）+ 跨 crate 集成 8（2+6） | ✅ 48 新 case |
| 文档同步 | matrix / TD 登记册 / calibration / stage-0-plan / dataflow / RELEASE_NOTES / rec 树 | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，2026-09-28 实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1076 files / 50.9MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 0.52s / 10 crates） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff（内循环第 1 轮修复格式后达成） |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（内循环 2 轮修复：common 模块重复挂载重构 + unused 变量） |
| `cargo test --release` | ✅ **96 passed / 0 failed**（64 单元 + 16 crate API + 16 跨 crate 集成） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于代码/清单面 = 仅 symbol.rs 85-86 行命中 = **登记制 CJK 白名单**（以 CJK 为被测对象的测试夹具，§10.5 豁免，登记于代码注释 + core.md §2）。*.md 面豁免位不计。

## 3. 测试构成（SOP §9.4.3 / GATE 6）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | symbol.rs（3+10）/ error.rs（0+4）/ expr.rs（4+7）/ module.rs（1+3） | 8 | 24 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-core/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5） |
| 跨 crate 集成 | tests/v0/stage0/plan/core_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费 2 例（span 归约双向模式——TD-004 边活性） |
| **0.1 合计** | | **12** | **36** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2）
- 单元 ≥30 ✅（32）；构造子全覆盖 ✅（CoreExpr 9 + LiteralValue 6 + ModuleItem 3 + Binding/HandlerClause 2）
- §7.1.1 七类错误矩阵：**N/A（0.1 无管线）**——沿 0.0 冷启动结构性缺口裁定（plan-0.0.md §6），0.3 起逐类点亮

## 4. 产物清单

- 代码：crates/kerf-core/{Cargo.toml（加边 kerf-span）, src/{lib,symbol,error,expr,module}.rs, tests/api_tests.rs}
- 测试基建：tests/runner.rs 挂载 core_seed_tests + common 单点挂载重构（子模块 super:: 导入）
- 版本：workspace 0.1.0 → 0.2.0；span_seed_tests WORKSPACE_VERSION 断言自洽化（env! 宏——裁定文附录勘误）
- 文档：0.1-design-adjudications.md（裁定文）/ core.md（测试文档）/ plan-0.1.md（本文件）/ matrix.md（0.1 节 + 累计 24:72）/ tech-debt-register.md（TD-004/005 → Resolved，TD-003 余 7）/ calibration-data.md（0.1 行）/ stage-0-plan.md（v1.1）/ dataflow.md（L0→L4 实线化）/ RELEASE_NOTES.md（v0.2.0）/ worklog rec 树（02 条目）

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-core 完整实现（无桩）；剩余 7 骨架 crate 仍为 TD-003 计划性脚手架（真实等级 P3 经 ARCH-A 确认，影响下一阶段 = 正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.2 syntax 与 0.4 expander 直接消费 CoreExpr/visit_spans/校验构造器（集成测试已锚定消费模式）；无阻断。 |
| Q3 | 端到端路径测试？ | 0.1 的管线 = 数据层装配 + core→span 消费（8 case 全绿）。源码→值 E2E 自 0.7 起（计划不变）。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-001（0.8）/TD-002（0.4 升 P1）/TD-006（机会性）均有挂接；TD-003 于 0.2 消解一项——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | 数据层 crate 无流程入口；消费入口 = visit_spans + 校验构造器面，被 api_tests（8）+ core_seed_tests（8）实际调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§4 清单）。 |

## 6. 门审适配（沿 plan-0.0.md §6 冷启动裁定）

0.1 审计集 = 0.0+0.1 全量 96 case。构成对照模板：单语句负向 ✅（构造器拒绝类 24）、多语句负向 ✅（嵌套程序错误传播类）、错误恢复 ✅（CoreError 三变体可渲染 + R8 形态断言）；「源码级语句」语义不可用（无 Reader）——**≥30 case 与七类错误全额义务维持 0.3 起强制**，0.11 门审 7/7 复核。

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 Task 2-f 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | TD-005 映射双向闭合 + 裁定链完整（SOP 流程权威 → §6.12.6 → §7.4.4 三源调和）；TD-004 加边无环、dataflow 同步 |
| DEV-A | ✅ 1.5 | 六命令全绿（冷构建）；96 测试 0 failed；无桩实现；common 单点挂载重构消除了测试基建债 |
| QA-A | ✅ 1.0 | 正负比 1:3 达标（24:72）；GATE 1/3/6 合规；CJK 白名单登记制执行；七类缺口按 DEFERRED 登记 |
| ALG-C | ✅ 1.0 | visit_spans 前序确定性（字段序即遍历序）；校验顺序固定（符号校验先于重复扫描——确定性边界）；LiteralValue Display 保持浮点性 |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭（手写 Error）；Symbol 私有内芯强制校验路径单一 |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

## 8. 遗留债务（真实等级确认）

TD-001（P2，0.8）/ TD-002（P3，0.4 升 P1）/ TD-003（P3 计划性，余 7 crate）/ TD-006（P3 机会性）——TD-004/005 本轮清偿 ✅。八原语 ANF 形态 = Stage 2 评估目标（登记态，零义务）。

## 9. 下一子阶段入口

**0.2 kerf-syntax**：SyntaxObject 四元组（expr/span/scopes/phase）+ scope_set；≥25 测试；Span 字段非空断言；reader 侧消费契约（token→stx 装配模式）。与 0.1 无依赖冲突（§18.5 不相邻），输入条件 = 0.0（已满足）。

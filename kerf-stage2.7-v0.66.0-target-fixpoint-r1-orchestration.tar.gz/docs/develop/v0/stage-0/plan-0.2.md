# Stage 0.2 子阶段计划与交付实录——kerf-syntax SyntaxObject 种子

> **Task ID**：5-a（flat worklog 对应条目；前置 Task 4-b = tarball 回退恢复轮）
> **性质**：Stage 0 第三子阶段（常规轮，非大阶段末轮——深审族由 0.11 承载）
> **复杂度**：L2（§5.1 三指标：LOC 中 ~700 行新代码+测试；依赖风险低——零新 DAG 边、零新外部依赖（§18.5 既有边 L0→L1 消费）；历史缺陷密度低——0.1 遗留零 P0/P1）
> **设计对齐**：无 TD 待裁定（TD-004/005 已于 0.1 清偿；0.2 无新张力项）——设计决策以 §13.1 对齐记录形式落入本档 §4（依据 stage0.md §3.3/§7.3.6/§8.9/§9.38/§19.2 + SOP §21.12/§2.5）

---

## 1. 任务构成

| 项 | 内容 | 状态 |
|----|------|------|
| 测试文档先行（§9.2 规则 1） | docs/tests/v0/stage0/plan/syntax.md（FP1-4 + 预期数 12:36） | ✅ 实现前落档 |
| 实现 | kerf-syntax 五模块（symbol/error/phase/scope/expr）+ lib 再导出面 | ✅ |
| 三层测试 | 单元 32（8+24）+ crate API 8（2+6）+ 跨 crate 集成 8（2+6） | ✅ 48 新 case |
| 文档同步 | matrix / TD 登记册 / calibration / stage-0-plan v1.2 / dataflow / RELEASE_NOTES v0.3.0 / README（含 0.1 顺修）/ rec 树 | ✅ |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，实际运行）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（removed 1042 files / 67.6MiB——冷构建复核防缓存假象） |
| `cargo build --release` | ✅ 0 error / 0 warning（冷构建 0.58s / 10 crates） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（内循环 3 轮修复：//! 笔误 + Display 委托 + len_zero 复发[0.0 同族第二例] + unused import ×2） |
| `cargo test --release` | ✅ **144 passed / 0 failed**（96 基线 + 48 新增：单元 32 / crate API 8 / 跨 crate 集成 8） |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 于代码/清单面 = 仅 symbol.rs 104-105 行命中 = **登记制 CJK 白名单**（以 CJK 为被测对象的测试夹具，§10.5 豁免，登记于代码注释 + syntax.md §2）。*.md 面豁免位不计。

**回退恢复轮（Task 4-b）前置实录**：用户指令裁定——kerf-stage0.1-v0.2.0-core-expr-seed-r1.tar.gz 解包替换项目与 worklog（回退 r166 相关所有内容）；diff -rq 归零实证 + 六命令复验 96:0:0 逐位恢复 + Rust 1.98.1 环境就位 + docs/sop.md（a1434ceb…）/stage0.md（6031f410…）三方一致（本地 = 文件仓库 = tarball）确认。

## 3. 测试构成（SOP §9.4.3 / GATE 6）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | symbol.rs（2+8）/ error.rs（0+3）/ phase.rs（2+3）/ scope.rs（2+4）/ expr.rs（2+6） | 8 | 24 | FP1-FP4 全覆盖 |
| crate API | crates/kerf-syntax/tests/api_tests.rs | 2 | 6 | 公共面验证（§9.1 规则 5） |
| 跨 crate 集成 | tests/v0/stage0/plan/syntax_seed_tests.rs（经 runner.rs） | 2 | 6 | 含跨阶段消费 2 例（token→stx 装配 0.3 契约 + scope 翻转/span 归约/卫生并集 0.4 契约——L0→L1 边活性） |
| **0.2 合计** | | **12** | **36** | **正负比 = 1:3 ✅** |

- 集成测试构成：正向 ≥1 ✅（2）/ 负向 ≥3 ✅（6）/ 跨阶段消费 ≥1 ✅（2）
- 单元 ≥30 ✅（32）；构造子全覆盖 ✅（SyntaxObject 六构造器 + StxDatum 六变体 + Phase 二变体 + ScopeSet 全操作面）
- §7.1.1 七类错误矩阵：**N/A（0.2 无管线）**——沿 0.0 冷启动结构性缺口裁定（plan-0.0.md §6），0.3 起逐类点亮

## 4. 设计对齐记录（§13.1——无待裁定 TD，八项设计决策入档）

1. **逐节点包装（per-node wrapper）**：`StxDatum::List(Vec<SyntaxObject>)`——列表成员是完整语法对象而非裸 datum（stage0.md §7.3.6「扩展的 S 表达式」+ Racket 工业实证）：卫生性需要**逐标识符**作用域集（§19.2 不变量 2），整树单包装无法承载。
2. **StxSymbol 管线相位孪生（非重复类型）**：语法层自有校验标识（下限与 kerf-core::Symbol 逐字节一致：非空/无空白/无控制字符）；0.4 展开器以 `&str` 经 core 校验构造器跨界——「reader 接受 ⇒ core 接受」由同下限保证，非共享类型（§21.12-5 单一定义规则辖跨阶段**共享**类型；DAG 保持 L1 与 L4 独立——§18.5）。InvalidSymbol 消息渲染与 core 逐字节一致（R8 单源字典——parity 守护前提）。
3. **Phase 二值枚举 + 校验解码**：Runtime=0 / MacroExpansion=1（§3.3 字段 4 / §8.9）；`from_u8` 拒绝越级值（未来多阶段层级走加性扩展——原则 27，0.10 接口预留承载）。**相位封闭性（§8.9 规则 1）属 0.4 展开器不变量，数据层不交叉校验**（诚实边界：混合相位树结构合法）。
4. **ScopeSet 有序去重存储**：sorted Vec + binary_search——确定性迭代序（§2.3-3 确定性边界，无 HashMap 随机序）+ 内容等值/哈希。union（函数式）/is_subset_of（词法解析查询——§9.38 解析草图）为 scope coloring 算法原语；卫生不变量 2 约束的是**使用方式**而非操作可用性（展开后标识符 scope set = definition ∪ use——§9.38）。
5. **ScopeId 无前缀 ID 型**：`pub u32` newtype（§21.12-3 跨阶段 ID 无前缀——同 Span/FileId 族）；分配新鲜性纪律归 0.4 消费者（展开器上下文持单调分配器）。
6. **with_scope_added 深翻转（函数式）**：原树不可变（原则 23——变换产生新值，禁止原地修改传入语法对象）；span/相位/datum 形状不变；深操作 = 展开器对模板整树翻转定义域/使用域的 contract（§9.38）。
7. **虚线对不建模**：improper（dotted）list 属 reader **文法**决策（0.3）；quote 数据已有 core 表示（LiteralValue::Pair，0.1 交付）。0.3 文法若接受点对则变体加性引入（原则 27）。空表 `()` 为合法 datum。
8. **Span 必填结构性（无 DUMMY）**：字段类型非 Option（TD-004 纪律同构）；畸形 span 在 kerf-span 构造层先拒（负向测试锚定「对象构造前拒绝」路径）。

## 5. §7.2 防崩六问（Q1-Q6）

| # | 问题 | 回答 |
|---|------|------|
| Q1 | 输出含 placeholder/stub？ | 否——kerf-syntax 完整实现（无桩）；剩余 6 骨架 crate 仍为 TD-003 计划性脚手架（真实等级 P3，影响下一阶段 = 正向载体）。 |
| Q2 | 下一阶段能否直接消费？ | 是——0.3 reader 直接消费 SyntaxObject 六构造器 + kind_name/Display（token→stx 装配契约已由集成测试锚定）；0.4 expander 直接消费 visit_spans/with_scope_added/ScopeSet 原语。 |
| Q3 | 端到端路径测试？ | 0.2 的管线 = 数据层装配 + syntax→span 消费（8 case 全绿）。源码→值 E2E 自 0.7 起（计划不变）。 |
| Q4 | P3 债务是否影响下一阶段？ | TD-001（0.8）/TD-002（0.4 升 P1）/TD-006（机会性）均有挂接；TD-003 于 0.2 消解一项（余 6）——无静默 P3。 |
| Q5 | 入口函数被实际调用？ | 数据层 crate 无流程入口；消费入口 = 六构造器 + visit_spans + with_scope_added + ScopeSet 面，被 api_tests（8）+ syntax_seed_tests（8）实际调用 ✅。 |
| Q6 | docs/develop + docs/tests 已同步？ | 是（§1 清单；README 含 0.1 遗留滞后顺修——Status 节与 layout 表未随 0.1 更新，本轮回补）。 |

## 6. 门审适配（沿 plan-0.0.md §6 冷启动裁定）

0.2 审计集 = 0.0+0.1+0.2 全量 144 case。构成对照模板：单语句负向 ✅（构造器拒绝类 24）、多语句负向 ✅（嵌套树错误传播/不变量守卫类）、错误恢复 ✅（SyntaxError 二变体可渲染 + R8 形态断言）；「源码级语句」语义不可用（无 Reader）——**≥30 case 与七类错误全额义务维持 0.3 起强制**，0.11 门审 7/7 复核。

## 7. 委员会投票记录（SOP §6.3——单 Agent 环境模拟，披露沿 Task 2-f/4-a 先例）

| 角色 | 票 | 依据摘要 |
|------|----|---------|
| ARCH-A | ✅ 2.0 | §3.3 四元组逐字段落地 + 逐节点包装（Racket 模型对位 §7.3.6）；StxSymbol 相位孪生论证完整（L1/L4 独立性保持，无 DRY 违例）；零新 DAG 边零新依赖 |
| DEV-A | ✅ 1.5 | 六命令全绿（冷构建 144:0:0）；无桩实现；len_zero 复发即修（0.0 同族第二例——教训归档） |
| QA-A | ✅ 1.0 | 正负比 1:3 达标（12:36）；GATE 1/3/6 合规；CJK 白名单登记制执行；∅⊆S 空集语义测试断言错误当场纠正（数学正确性优先） |
| ALG-C | ✅ 1.0 | ScopeSet 有序存储不变量 + 确定性迭代；校验顺序固定（符号校验先行）；with_scope_added 幂等去重（二翻无损） |
| SKL-A（不计权） | ✅ | 零外部依赖沿袭（手写 Error）；私有内芯强制校验路径单一（StxSymbol 同 Symbol 纪律） |

**加权通过率 = 5.5 / 5.5 = 100% ≥ 95% → APPROVED（5/0）**

## 8. 遗留债务（真实等级确认）

TD-001（P2，0.8）/ TD-002（P3，0.4 升 P1）/ TD-003（P3 计划性，余 6 crate）/ TD-006（P3 机会性）。八原语 ANF 形态 = Stage 2 评估目标（登记态，零义务）。

## 9. 下一子阶段入口

**0.3 kerf-reader**：token/lexer/parser → SyntaxObject 树 + ReadError；256 嵌套帽；§7.1.1 七类错误中**语法错误/空应用**两类负向全覆盖（门审全额口径自 0.3 起强制——≥30 case）；≥40 测试。输入条件 = 0.2（已满足——六构造器 + token→stx 装配契约锚定）。

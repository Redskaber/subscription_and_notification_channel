# Stage 0.10 子阶段计划与交付实录——四项接口预留冻结（reserved：effects / multistage / capability_io / cache）

> **依据**：docs/sop.md §21（阶段规划）/ §4（MUV 六字段）/ §9.4.3（测试构成）/ §7.2/§7.3/§6.3（L2 外循环）/ §21.12-8 / §21.12-10①②（依赖方向 + 六域从属）
> **设计锚**：stage-0-plan.md §5 行 0.10（四项接口预留冻结——P2 = trait 签名 + 行为规格；P3 = 类型形状；依赖方向过 §21.12-10②——冷启动注：kerf-space marker 家族为 Stage 1+ 登记项；预留签名编译级测试[类型存在性 + 签名稳定快照]）+ roadmap.md §6 post-0.9 首议程四项 + docs/stage0.md §9.1.1（EffectSystem 形状）/ §9.1.2（MultiStage 形状）/ §9.1.3（CapabilityIO + 令牌 + IOError）/ §9.1.4（CompilationCache 三方法）/ §9.4 十四项矩阵（四项既有预留行）/ §9.5.1 P0-P3 优先级 / §22.3 里程碑清单（四接口项「接口已定义（实现可为空）」）+ SOP §2.2 原则 12（接口预留优先于实现）/ 26（三级成熟度匹配）/ 27（接口稳定性）/ 32（预留留白）/ 40（根空间统一组织）+ plan-0.9.md §5 边界申报（§19.2 多阶段 quote/splice = Stage 2+ 区分登记）
> **状态**：✅ 已交付（2026-09-28）——672:0:0 · 审计集 100/100（七类 7/7 维持）· v0.11.0

## 1. 任务构成

| MUV | 内容 | 落位 |
|-----|------|------|
| 13-a-1 | 测试文档先行（§9.2 规则 1）：FP1 effects 形状 / FP2 multistage 形状 / FP3 capability_io 形状 + 令牌纪律 / FP4 cache trait + 行为规格执行化——预期数 + 审计集 90→100 口径 + 落位与依赖方向声明 | docs/tests/v0/stage0/plan/reserved.md（实现前落档） |
| 13-a-2 | `reserved` 模块族骨架 + 六域从属文档声明位（§21.12-10① doc-declaration 形态——kerf-space marker 家族 = Stage 1+ 登记项，re-anchoring 加法路径登记） | crates/kerf-core/src/reserved/mod.rs |
| 13-a-3 | 四模块实现：`effects.rs`（EffectOp 伴随 trait + EffectSystem 四关联类型 + perform/handle 签名冻结）+ `multistage.rs`（Expr marker + CodeCarrier 伴随 trait + MultiStage quote/splice/run 签名冻结 + 双命名披露）+ `capability_io.rs`（ReadCapability/WriteCapability 封印令牌 + IoErrorKind 闭集 + IOError R8 面 + CapabilityIO 签名冻结）+ `cache.rs`（CacheKey 内容寻址 + CachedResult 不透明载荷 + CompilationCache 三方法 + **check_compilation_cache_contract 行为规格合同测试 kit**） | crates/kerf-core/src/reserved/{effects,multistage,capability_io,cache}.rs |
| 13-a-4 | 测试三面：内联 30（witness 签名稳定快照 + kit 检测力 5 套故意破坏实现全 should_panic + IOError 四 kind 全路径）+ api_tests reserved 节 6（公共路径 + 跨 crate witness + std::error::Error 对象面）+ 根集成 reserved_seed_tests 12（四族根聚合路径 + drive_cache 下游泛型消费 + kit E2E + 行为负向族） | 同上 + crates/kerf-core/tests/api_tests.rs + tests/v0/stage0/plan/reserved_seed_tests.rs（经 runner.rs 挂载） |
| 13-a-5 | 审计集 K 节（90→100：witness 语义 ×4 + 令牌纪律 + IOError R8 面 + cache miss/hit/invalidate/overwrite 四合同 + kit 全量复跑——七类 7/7 维持） | examples/audit/stage0_gate_audit_r1.rs |
| 13-a-6 | 文档族 + 版本 0.11.0 + commit | docs/ + Cargo.toml |

## 2. 验证实录（SOP §3.2——Stage 0-1 口径，冷构建实际运行；**r2 终态**——r1 实录见 git 历史，r1/r2 内循环全录见 §9）

| 命令 | 结果 |
|------|------|
| `cargo clean` | ✅（冷构建复核防缓存假象——r1 removed 501 files / 38.9MiB；r2 增量口径 + §19 打包轮包内冷构建复跑） |
| `cargo build --release` | ✅ 0 error / 0 warning（10 crates + bin kerf） |
| `cargo check` | ✅ 0 error / 0 warning |
| `cargo fmt --check` | ✅ 零 diff（r2 变更面 fmt 修正后归零） |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 warning（--all-targets 含 example/bin 目标） |
| `cargo test --release` | ✅ **710 passed / 0 failed**（r1 672 基线零回归 + **r2 净 +38**——能力域单元 27[capability 族 37 - 旧 capability_io 10] + core api 6 + 根集成 5；r2 轮构成 25:13 = 1:0.52 反向——偏差申报见 §9；r1 轮 32:16 见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 110/110**（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + J10 + K10 预留面合同 + **L10 能力空间**——r2 新增：注册 fail-closed 负向五连 + 拓展证明 + re-export 冻结连续性；exit 0）——七类 7/7 维持 |

**编码面扫描（GATE 1）**：`rg "[\p{Han}]"` 新增源面 = **零命中**（r1 四模块 + r2 capability 模块族五件 + api/根/审计新增节；§/TD 技术锚原样保留合法）。*.md 面豁免位不计。**零未登记非英文编码面**。

**内循环实录（§5.3——诚实记录；r1 六轮见 git 历史，r2 三轮）**：r2-R1 审计 L10 占位断言笔误（TypeId 对比目标错写——重构为新旧路径同一性双断言）；r2-R2 api E0658 合格路径实验语法（关联类型结构字面量不可限定——改类型注解钉扎）；r2-R3 family.rs Hash 一致断言初稿（RandomState 比较无意义——改 HashSet 插入语义断言）+ fmt 修正后归零。**实现侧运行语义缺陷 0**（连续四轮）。

**r1 实录归档（v0.11.0 时点）**：六命令冷构建 672:0:0（净 +48：core 内联 30 + core api 6 + 根集成 12）+ audit 100/100（K10 预留面合同）；内循环 6 轮（编译级 4 + R8 形态 2 + clippy 3 + 测试侧 1——详见 git 历史）。

## 3. 测试构成（SOP §9.4.3 / GATE 6——实测数）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元 effects.rs | witness 四面（perform 路由/状态累积/handle 组合/捕获闭包）+ 关联类型名达性 ×2 | 6 | 0 |
| 单元 multistage.rs | witness 三面（quote→splice/run 执行/异载体泛型）+ 载体类型钉定 | 4 | 0 |
| 单元 capability_io.rs | 令牌 ZST/Debug + IOError 往返 + 读两行 happy | 4 | 6 |
| 单元 cache.rs | key/result 形状 + kit 双 witness 通过 | 5 | 5 |
| API 面 api_tests.rs | 四族公共路径 + kit 本地复跑 + R8 错误面 + 跨 crate witness + cache 形状面 + std::error::Error 对象面 | 6 | 0 |
| 跨 crate 集成 reserved_seed_tests.rs | 四族根聚合 + effects/multistage witness + drive_cache 下游泛型 ×2 + kit E2E + 令牌 ZST + 最新胜 | 7 | 5 |
| **0.10 合计** | | **32** | **16** |

- **比例申报**：轮 32:16 = **1:0.5 反向**（沿 0.8[73:51] 反向偏差先例）。**偏差披露**：① 预留冻结轮验收面 = 类型形状存在性 + 签名稳定快照（蓝图 §22.3「实现已定义（实现可为空）」——P3 三件正向本体即冻结目标；运行时负向面结构性不存在[编译失败断言需 trybuild 类外部依赖——§18 审查禁用]）；② P2 行为规格已穷尽负向可测面：kit 检测力 5 套故意破坏实现（never-hit / no-invalidate / no-overwrite / wrong-key / payload-corrupt）全 should_panic 负向 + 行为负向族（未存 miss / invalidate 后 miss / 跨键隔离）双层级（内联 kit + 根位置消费面）；③ IOError 四 kind 全路径负向（耗尽 Eof / 中断重试 Interrupted / 撤销 Denied / 拒绝从未活 Denied）+ R8 消息形态双层（内联 + 根位置）+ kind 逐对可区分；④ 令牌不可伪造纪律（封印构造——模块外结构性不可构造，蓝图 §9.1.3 `_private` 形态忠实转译）；⑤ 凑数拆分违反 §12 最优>最小。累计 272:400 = 1:1.47（workspace 624 → **672**）。
- 集成构成（GATE 6 其余项全达标）：reserved_seed 12 case：正向 7 ≥1 / 负向 5 ≥3 / 跨阶段消费 4 ≥1（四族经 `kerf::core::reserved` 根聚合路径 + drive_cache 泛型下游消费 + kit 根位置 + audit example 消费链）✅
- **七类 7/7 维持**（0.9 达成后守恒——K 节 = 预留面合同族，不新增错误类）

## 4. 设计对齐记录（§13.1——裁定与决策入档）

### 裁定十七（0.10）：预留面 = 完全自含抽象——§21.12-10② 冷启动最强形式

蓝图伪码引用未定义名（`Value`/`Expr`/`IOError`/`CacheKey`/`CachedResult`）——0.10 的定义义务即填补这些名为**不依赖任何具体实现类型**的形状。裁定：四族全落 kerf-core `reserved` 模块族，**除 std 外零入边**——语言值 = `type Value` 关联类型（非 kerf-vm::Value——L4 不依赖 L6）、缓存载荷 = 不透明字节（非 kerf-compiler::Bytecode——同理由）、预留面无 span 语义（系统级契约面非 AST 节点——不引 kerf-span）。「依赖抽象约束非具体实现」在无 kerf-space marker 家族（Stage 1+ 登记项）的冷启动期，落地为其最强可得形式：**零具体类型依赖 + 关联类型全自含**。六域从属（§21.12-10①：effects → 效应域 / multistage → 元编程域 / capability_io → 能力域 / cache → 工具链域）以 reserved/mod.rs 文档声明位承载——Stage 1+ marker 家族落位时 re-anchoring 为加法零破坏（新增 impl/marker 不破坏冻结形状——Rust 加方法是加法）。

### 裁定十八（0.10）：蓝图伪码可编译转译纪律 + 词汇漂移消解

§9.1.1-§9.1.4 伪码含三类不可编译形态，转译纪律入档：① `Self::Effect::Result` / `Self::Code::Inner` 类关联类型路径 → **伴随 trait**（EffectOp/CodeCarrier）承载 Result/Inner/Result——语义逐字保持（「perform 的返回类型 = 效应种类的结果类型」）；② `impl Expr` 参数位 impl-trait → 显式泛型 `fn quote<E: Expr>`（等价脱糖——实现者面更明确）；③ 蓝图内部词汇漂移（§9.3.1 表「EffectKind/HandlerClause/Continuation」vs §9.1.1 块「Effect/Handler/Continuation」）以 **§9.1.1 蓝图块为准**（预留接口的权威载体）+ 词汇映射注记（Effect ↔ effect-kind 词汇 / Handler ↔ handler-clause 族——内核级 `kerf_core::HandlerClause` 保持原语臂语义位，预留面 Handler 关联类型 = 系统级 handler 面——两层命名披露入 effects.rs 模块文档）。同族：multistage 的 `quote` 双语义披露（预留面 quote = 阶段化代码构造 ≠ 0.9 展开器 quote 数据字面量——§19.2 区分）+ `Code` 关联类型 ≠ kerf-expander CodeValue（分层分窗）。

### 裁定十九（0.10）：CompilationCache 载荷 = 不透明字节（服务已知缺失需求序列化形态）

`CachedResult { payload: Vec<u8> }` 不透明字节而非类型化编译产物，裁定依据三叠：① §9.3.1 编译缓存行已知缺失需求 = 跨会话持久化 + 分布式缓存——两者本质要求可序列化载荷形态，冻结面预置序列化友好的载荷 = 原则 27 接口稳定性（演进只换实现不破坏契约）；② §21.12-10② 依赖抽象——载荷若钉 Bytecode 类型即冻结面引用 L5 具体实现（L4→L5 反向依赖违例）；③ 蓝图 §9.1.4 具体类型形态保持（`Option<CachedResult>` 具体名——非关联类型化）。Stage 1 内存实现的序列化开销 = 实现窗裁量事项非冻结面约束（登记为 Stage 1 实现窗输入）。

### 决策 10 项（0.10）

1. 落位 = kerf-core/src/reserved/（L4 语义权威 crate——四族单一冻结锚点 + 全下游 L5-L8 可达 + 根 tests/examples 消费；**不新建 crate**[9/9 维持——stage-0-plan「reserved 模块」口径 + kerf-space marker 家族 Stage 1+ 不提前]）
2. P2/P3 分级落实：cache = trait 签名 + **行为规格执行化**（check_compilation_cache_contract pub kit——Stage 1 实现的合同测试复用位——「行为规格」从文档义务升格为可执行断言）；effects/multistage/capability_io = 类型形状 + witness（无行为规格义务——蓝图「实现可为空」）
3. 签名稳定快照 = **witness 模式**（canonical conforming implementor——任何冻结形状漂移即 witness 编译断，六命令把编译断升格为硬门；witness 存于测试位[内联/api/根/audit 四层]——生产面零实现者，蓝图忠实）
4. capability 令牌 = 封印构造（私有字段——蓝图 §9.1.3 `_private: ()` 形态忠实转译；模块外结构性不可构造 = fail-closed「缺省拒绝」纪律的 Stage 0 形状位；**零公共构造器**——mint/delegation = Stage 1 加法窗口[新增方法非破坏]，比预发布 mint() 更稳定的冻结选择）+ 令牌门控 I/O 路径仅模块内联可测（同模块私域铸造 seam——Stage 1 mint 协议将正式化该 seam；外部可达面 = 错误面本体——审计 K06 改型依据）
5. IOError = 闭集 kind + 消息 + R8 Display（`io error {kind:?}: {message}` 小写首/无句尾/载荷携带 + kind 逐对可区分断言 + std::error::Error 对象面[Box<dyn Error> downcast 往返]）
6. CacheKey = `[u8; 32]` 摘要 + from_digest/digest 构造访问对（哈希算法 = Stage 1 实现细节——冻结面只钉键形状与等值/哈希一致性）+ Copy/Eq/Hash 全派生（HashMap 键位即用）
7. 审计 K 节构成（K01-K10）+ kit 全量复跑收尾（K10 后 kit 再跑一遍 = 行为规格整体性终验）——七类 7/7 维持不新增错误类（预留面合同族 = 新审计族类，matrix.md 记账）
8. 命名：模块族 `reserved`（蓝图「接口预留」直译——`kerf_core::reserved` 单一冻结锚点路径）+ 伴随 trait 名 EffectOp/CodeCarrier（承载蓝图关联类型路径的可编译转译——裁定十八）
9. 文档声明位 = reserved/mod.rs 六域从属表（§21.12-10① doc-declaration 形态）+ re-anchoring 加法路径注记（Stage 1+ kerf-space 落位时 marker impl 为加法）
10. 测试计数达成口径 = cargo test 净增 48（roadmap 首议程 4 逐字达成）+ audit K 节 +10 = 总验收面 58（先例口径沿 0.7-0.9——cargo 为主审计为辅）

## 5. 边界申报（非 TD——设计边界，零机制变更义务）

预留面零生产实现（蓝图 §22.3「实现可为空」——effects/multistage Stage 2 语言面 + capability_io Stage 1+ 基础传递 + cache Stage 1 内存内容寻址）/ 令牌铸造协议不在本轮（Stage 1 mint/delegation 设计窗——本轮封印 + 同模块 seam）/ IOError 闭集四 kind（Eof/Denied/Interrupted/Other——Stage 1+ 按实现需求加法扩展）/ Expr = marker 级形状（Stage 2 填充真实表面——本轮仅钉 quote 泛型界）/ CachedResult 载荷序列化格式未定义（Stage 1 实现窗裁量）/ cache 哈希算法未定义（Stage 1 实现细节）/ 效应 one-shot 纪律（SOP §21.12-12③）以 Continuation 关联类型文档注记承载——形状不钉多射语义（Stage 2+ 实现窗裁定）/ kerf-space re-anchoring = Stage 1+（本轮文档声明位代偿——§21.12-10① 冷启动形态）。

## 6. 审计集构成映射（§7.3.1 规则 2/4——90→100 单调增长）

| 节 | 数 | 构成 |
|----|----|------|
| A-J | 90 | 0.3-0.9 既有十节零改动（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + J10） |
| **K10（0.10 新增）** | 10 | K01 effects perform 路由（EffectOp::Result 类型接线）+ K02 effects handle 组合（值路径 + handler 修饰）+ K03 multistage quote→splice 折返 + K04 multistage run 执行至载体结果 + K05 令牌 ZST ×2 + K06 IOError 面（四 kind 往返 + R8 形态——外部可达错误面）+ K07 cache 未存 miss（负向）+ K08 cache 命中 + 值等 + K09 cache invalidate 后 miss + 缺失键 no-op（负向）+ K10 cache 最新胜 + 跨键隔离 + **kit 全量复跑**（行为规格整体性终验） |

## 7. 外循环（§7.2 防崩 + §6.3 投票——单 Agent 模拟披露沿先例）

- Q1 无桩（预留面 = 冻结契约本体非实现缺位——蓝图「实现可为空」登记态[原则 12]，witness 全在测试位；R1 桩纪律判定：零桩零死变体）；Q2 0.11 可直接消费（末轮门审 + 深审族输入 = 四接口冻结态 + §22.3 清单四项可勾选 + 行为规格 kit 复用位）；Q3 集成 12 case + audit K 节全过（四层 witness 消费链：内联/api/根/example）；Q4 TD-006 不阻塞（文档质量类 P3 维持）；Q5 入口函数全有真实调用方（kit ← 内联双 witness + api 本地 + 根 E2E + audit K10；trait 名 ← 四层 witness 实现位；构造器 ← 形状测试全触达）；Q6 docs/ 同步 ✅（本件 + reserved.md + matrix + TD 登记册 + calibration + stage-0-plan + roadmap + RELEASE_NOTES + README + dataflow 注记 + rec 树）
- 投票（权重 ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1）：ARCH-A ✅（裁定十七零入边 = §21.12-10② 最强冷启动形式 + 裁定十八伪码转译语义逐字保持 + 裁定十九载荷序列化前瞻 = 原则 27 接口稳定性三叠论证）/ DEV-A ✅（624 零回归 + 净 +48 + 四层 witness 消费链 + 六命令全绿）/ QA-A ✅（audit 100/100 单调 + kit 检测力 5 破坏实现全捕获 + 比例反向偏差申报受理——预留轮验收面结构性正向 + 负向可测面穷尽 + §12 凑数禁止）/ ALG-C ✅（伴随 trait 转译语义等价 + 不透明载荷字节序确定性 + 关联类型代数闭合——四族全可命名可实现可消费）/ SKL-A ✅（不记权，无 NEEDS REVISION）= **5.5/5.5**

## 8. 下一入口（0.11 末轮——Stage 0 收口）

Stage 0.11 末轮（L3 全流程——大阶段末轮强制）：≥50 快照测试（stage0.md §22.3「至少 50 个快照测试」——现有 672 计数中快照形态盘点 + 补齐）+ 性能基准基线（§22.3「性能基准已建立基线数据」）+ §7.3 门审（≥30 case 全额口径 + 负向 ≥22——audit 100 case 已超额）+ §6.3 投票 + §14.5/§14.8/§14.9/§14.6 深审族 + §6.6 校准统计 + §21.5 出阶段切换信号九项核对 + §19 打包。§22.3 十二项清单逐项勾选（本轮四接口项 ✅——余：Reader 九原语解析 ✅[0.3]/Expander 核心形式 ✅[0.4]/Compiler debug_info ✅[0.5]/VM 操作码 ✅[0.6]/GC ✅[0.7]/50 快照[0.11]/Span 全阶段传播 ✅[0.1 起持续]/性能基线[0.11]）。

## 9. r2 修订轮实录（0.10-r2 能力模型预留泛化——用户显式指令开窗，2026-09-28）

> **驱动源**：用户显式指令——「预留的能力模型不止有一个具体子集 io 能力模型，应该预留能力模型，而 io 能力模型只是他子级的具体子模型，同时预留的不是具体的模型而是预留注册和拓展这种抽象模型的能力（请结合知识搜索和当前 docs/stage0.md 重新重构预留，结合空间管理理论对编译器内部层级从属与关系的组织协调，很多设计原则在 docs/sop.md 中都具备——不限于依赖抽象不依赖具体）」。依据 §9.10.5（代码面落位依 T3+ 治理与用户显式指令裁量）+ §21.12-8（用户显式指令开窗 = 合规信号源——上游 r62「预留接口根空间化重构」同型先例）：r1 的 capability_io 预留是**点**（io 具体子模型直挂），本轮将其泛化为**空间**（能力模型框架 + 注册拓展机制 + io 首子模型）。

### 裁定二十（0.10-r2）：能力模型预留 = 空间而非点——预留注册与拓展抽象模型的能力本身

依据 §2.2 原则 36（机制预留——接口预测悖论解法：预留「打洞能力」而非「特定形状的洞」）+ 原则 37（抽象覆盖空间而非预测点——具体 = 一个点，抽象 = 一个空间）+ 原则 40（根空间统一组织——预留接口必须依赖抽象根空间而非具体实现类型，依赖倒置的预留层投影）+ stage0.md §9.10.2（空间关系 = 约束组合代数非继承——子空间 = 根约束 ∩ 附加约束）+ §9.13.3（能力域三成员：CapabilityModelFamily / TokenCalculus / CapabilityIO）+ §9.10.5（注册表模式：register/lookup + 冲突验证 fail-closed）：

1. **预留本体转移**：r1 预留的是 `CapabilityIO` 一个具体点；r2 预留的是能力**空间**——族契约（`CapabilityModelFamily`：任何能力模型是什么——身份卡 + 封闭错误面）+ 令牌纪律（`TokenCalculus`：封印令牌的权威词表项）+ **注册拓展机制**（`CapabilityModelRegistry`：register/lookup/governing_model/governed_authorities——新模型经「满足约束」入空间，零框架变更，OCP 组织层实现）。
2. **io 降位为首子模型**：`capability_io.rs` → `capability/io.rs`，`IoModel` 实现族契约（Error = IOError 逐字钉扎 + 身份卡 name="io"/authorities=["io.read","io.write"]/operation_face="CapabilityIO"），令牌实现 TokenCalculus（"io.read"/"io.write"）；**r1 冻结面零破坏**——旧路径 `reserved::capability_io` 经 re-export 存续（TypeId 同一性 L10/api 双实证，四个 0.10 消费面零改动编译通过）。
3. **注册即拓展（A3/A4 的机器检查投影）**：注册验证 fail-closed——描述符畸形（InvalidDescriptor 三变体：空名/空权威表/描述符内重复权威项 + 空操作面锚）/ 模型重名（DuplicateModel）/ 权威已被他模型治理（AuthorityConflict——唯一从属）；被拒注册零副作用（闭世界不变）。拒绝语义 = 空间层级公理 A3（唯一从属）/A4（正交分解）的运行时强制。
4. **不预测原则**：族契约不携带操作签名（每个模型自带操作面——io 的 CapabilityIO；预测未来模型的操作形状 = 接口预测悖论违例）；mint/delegate/revoke 维持 Stage 1 能力传递设计窗（加法路径）。

### 决策 11 项（0.10-r2，编号接 0.10 决策 10 项后续）

1. **版本口径**：v0.11.1（修订轮 = y 位——预留面修订不加运行时语义，与子阶段交付的 x 位递进区分；stage 标签维持 0.10-r2）。2. **re-export 冻结连续性**：`pub use capability::io as capability_io`——r1 消费面（api_tests/根集成/审计集/文档）零改动全过 = 冻结纪律的机器验证。3. **注册表实现许可**：注册机制本体可执行（数据管理层非语言运行时语义——与 cache kit「行为规格执行化」同型），能力操作本体（read_line/write_line 实际 I/O）维持 Stage 1+。4. **身份卡 Copy 派生**：全 'static 引用字段，Copy 诚实合法（测试夹具 Cell::get 需要）。5. **权威词表惯例不强制**：`"<model>.<authority>"` 点分惯例文档化 + io 上实证（coherence 测试），注册不校验点分形（结构有效性[非空/唯一]强制，命名风格不预测——避免过度约束未来模型）。6. **拓展证明三位置**：crate 内（registry 测试 ClockModel）/ api 位（OutsideNet）/ 根位（RootClockModel）+ 审计位（AuditClockModel）——外部定义模型入同一闭世界，零框架变更四重实证。7. **知识搜索入档**：ocap = de-facto 产业标准（unforgeable token + possession = permission + default deny）+ 规范资源集 fs/net/clock（Austral/Jacquard 交叉印证——本轮 ClockModel/NetModel 测试双选型依据）+ 线性类型纪律（System Capybara/Austral——TokenCalculus Stage 1 线性窗佐证）。8. **kerf-space 不提前**：六域从属维持文档声明位（0.10 决策沿用——本轮为能力域内部结构化，非跨域 marker 落位；Stage 1+ 加法路径不变）。9. **audit L 节**：100→110（§7.3.1 规则 4 单调增长；L03-L07 负向五连[重复名/权威冲突/空名/自重复权威/未知解析]——错误恢复类负向注入）。10. **正负比反向偏差申报**：新测试 25:13 = 1:0.52（框架面结构性正向 + 注册 fail-closed 族天然负向 11 件——较 r1 的 32:16 改善；凑数违反 §12）。11. **测试文档映射**：reserved.md 增 FP5 节（r2 双生文件映射更新）。

### r2 验证实录（SOP §3.2——增量口径；冷构建于 §19 打包轮复跑）

fmt 零 diff ✅ / clippy --all-targets -D warnings 零告警 ✅ / cargo test --release **710:0:0**（672 基线零回归 + 净 +38 = 单元 27[能力域 37 - 旧 capability_io 10] + api 6 + 根集成 5）+ audit **110/110**（L 节 +10）/ R8 编码面扫描：变更文件 CJK 零命中 ✅ / 版本 v0.11.0 → v0.11.1。

### r2 外循环（§7.2 防崩 + §6.3 投票——单 Agent 模拟披露沿先例）

Q1 无桩（框架 = 冻结契约本体，注册机制为可执行元数据管理非语言语义——原则 12 登记态；R1 判定零桩）/ Q2 0.11 直接消费（末轮快照盘点 + 深审族输入 = 能力空间态；r1 冻结面连续性实证入档）/ Q3 集成 11 case（api 6 + 根 5）+ audit L 节全过 / Q4 TD-006 不阻塞（维持 P3）/ Q5 入口全有真实调用方（register ← 四位置拓展证明 + io 端到端；族契约 ← IoModel/ProbeModel/OutsideNet/RootClockModel/AuditClockModel 五实现位；TokenCalculus ← 三令牌位）/ Q6 docs/ 同步 ✅（本件 §9 + reserved.md FP5 + matrix + TD 登记册 + calibration + stage-0-plan + roadmap + RELEASE_NOTES + README + dataflow 注记 + worklog 双镜像）。
投票：ARCH-A ✅（裁定二十 = 原则 36/37/40 三层预留体系的能力域落地 + DIP 预留层投影[框架零依赖具体模型] + 空间理论 A1-A7 逐级从属[文档声明位 + 注册机制 A3/A4 强制]）/ DEV-A ✅（672 零回归 + 净 +38 + re-export 冻结连续性四消费面实证）/ QA-A ✅（audit 110/110 单调 + fail-closed 族 11 件负向 + 被拒注册零副作用 + 比例偏差申报受理）/ ALG-C ✅（约束组合口径表述纪律 + 身份卡三元组代数 + 权威词表闭世界序保持[注册序确定性]）/ SKL-A ✅（不记权，无 NEEDS REVISION）= **5.5/5.5**。

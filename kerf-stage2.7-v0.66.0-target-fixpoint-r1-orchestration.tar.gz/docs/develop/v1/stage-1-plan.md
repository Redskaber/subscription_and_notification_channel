# Stage 1 阶段计划（stage-1-plan.md）——混合期：类型系统基座 + 前端自举启动

> **Status**: Active（Stage 1 开工轮落档——2026-09-28）
> 依据：docs/sop.md §13.1/§21 + docs/develop/v0/roadmap.md §2/§6 + docs/stage0.md §9.24/§9.25/§21.6 + docs/develop/v0/stage-0/final-assessment.md（出阶段评审 GO）
> 前置：Stage 0 全收口（0.0-0.11 · v0.12.0 · 767:0:0 · audit 110/110 · §21.5 九信号 + §22.3 十二项全勾）

## 0. Stage 0 出阶段评审确认记录

final-assessment.md §3 GO 结论（九信号全勾 + 十二里程碑全勾 + C1-C6 全过 + 深验四件全过 + 投票 100%）——**本轮用户指令「排期已确定则继续推进」= 出阶段评审确认**（§14.6.3 规则 5 的确认位补齐；依据：roadmap §6 首议程 1 + 用户消息指令③）。Stage 1 自本轮起正式开工。

## 1. Stage 1 使命与验收口径

**使命**（roadmap §2）：混合期——①类型系统基座（外部 Rust 类型检查器路径[§21.6 风险缓解——循环依赖三阶段策略的第一阶段：检查器以 Rust 实现，Stage 2+ 再评估自举内迁] + 保守静态 R1-R8 + 多错误收集 + E0xxx 诊断注册面）②前端自举启动（用目标语言子集重写编译器前端 Reader/Expander/基础宏，运行于 Stage 0 VM——新语言 ~30% / Rust ~70% 起步）。

**出口判据**（§21.5 + §22.3 Stage 1 对应项）：类型检查器生产就绪（driver 管线接线 + CLI/REPL 面）+ PBT 四层测试基础设施（DEA-13 闭合）+ HM 推断基座 + 前端 .krf 重写起步（≥1 个真实前端段）+ 六命令全绿维持 + §14 深审族（末轮 L3）。

**宪制边界重申**：8 原语不变性（零新原语·零通道·零 VM·零语法）；VM 永久 Rust 基座（「完全自举」VM 重写 = 宪制排除项）；LLVM/本地码后端永不入自举链；类型检查器 = 横切静态验证层（验证者非执行者——stage0.md §9.24 TY-A）。

## 2. 子阶段排期（1.0-1.9）

| 子阶段 | 内容 | 依赖 | 验收要点 |
|--------|------|------|---------|
| **1.0**（本轮） | **kerf-typecheck 种子**：E0xxx 诊断注册面 + 保守静态 R1-R8 + 多错误收集（§3/§4 定义） | 0.11 基线 | crate 落位 + 测试三层（内联/api/根集成）+ audit M 节 110→120 + §18 零新依赖（kerf-core+kerf-span 两条边） |
| **1.1**（已交付 v0.14.0） | driver 接线：`read → expand → typecheck → {compile, eval}` 管线级 + CLI/REPL 面 + 诊断渲染映射（driver Severity ↔ checker Severity）+ 首个 Warning 生产者接线 | 1.0 | ✅ E2E：源码可达 E0xxx 诊断经 driver 渲染（881:0:0 + audit 130/130 + 基线共变 5 处全披露——plan-1.1.md） |
| **1.2**（已交付 v0.15.0） | **PBT 引入**（DEA-13 闭合）：proptest §18 依赖审查落地 + 6 类不变量首批（§5 裁定：8 原语 eval / Reader 往返 / VM dispatch 三类先行）| 1.0 | ✅ proptest 1.11.0 dev-dep（仅根测试层——^1.9 约束解析 1.x line）+ 七属性 ≥6（三类不变量：双引擎 parity/运行时陷阱/归约语义/静态 E0006/reader 不动点/VM 确定性/算术 oracle）+ §18 审查记录在档（Cargo.toml 注释 + plan-1.2.md §4）——890:0:0 + audit 130/130 维持 + 448 生成用例零双引擎分叉 |
| **1.3**（已交付 v0.16.0） | **HM 推断基座**：Hindley-Milner 类型推断（Algorithm W 迭代预算版——stage0.md §9.30 REC-A 方案 3 谱系：迭代+512 预算 A6）+ 效应行收集面 + 类型标注 IR（Layer 2 语义标注） | 1.0 | ✅ 迭代引擎（全循环零深递归）+ union-find/undo-log + SCC 分治 + unify/occurs + E0009-E0011 + TypedExpr 标注树 + 快照 IS 族 + B1-B5 零回归——953:0:0 + audit 140/140（plan-1.3.md；driver HM 级接线登记 1.8 议程） |
| 1.4 | kerf 子集冻结（.krf 自举目标面）：目标语言子集语法/语义规格 + 自举子集验收语料集 + parity 骨架（SyntaxTransitionValidator 设计登记态——stage0.md §9.25 BS-C） | 1.0-1.3 | ✅ 子集规格文档（subset-spec.md——冻结面六表 + 实证语义细则五条）+ 验收语料 **68**（≥50：pos 26/neg 32/bnd 10——期望全实证）+ parity 契约面（kerf-driver parity 模块——BS-C 1.4 切片）——1046:0:0 + audit 150/150（Q 节——detector-detects 元审计）（plan-1.4.md） |
| 1.5 | ✅ 已交付（2026-09-29，v0.18.0）：结构层分段——selfhost/v1/reader.krf（迭代式显式栈）+ 源注入表格契约 + 双轴双引擎 parity（1119:0:0 + audit 160/160）；B3 口径修正（§9.46.3——28 函数 = 档案目标，实际 = 结构层四拒绝类 + 全树；词法层六变体 = 第二段窗口域） | 1.4 | 双 Reader parity（错误消息/Span 逐字节等价）+ 切换窗步②首个切口 ✓ |
| 1.6 | ✅ Expander .krf 重写（第二段）：展开循环 + 脱糖 + loader 面（2026-09-29 交付，v0.19.0——1098:0:0 + audit 170/170；§9.47 EX-1..EX-5 设计依据；语料扩展 68→72；卫生机制宏面 = 1.7 域经 Macro 层分流裁定） | 1.5 | 展开器 parity + 快照冻结扩展 |
| 1.7 | ✅ 基础宏 .krf 重写（第三段）+ Macro 层收缩 + fixpoint 门 B（2026-09-29 交付，v0.20.0——1128:0:0 + audit 180/180；§9.48 MX-1..MX-6 设计依据；语料扩展 72→79；门 B 二阶段双口径兑现[字节码全等 + 装配自应用]） | 1.6 | 前端三段全 .krf + fixpoint 信号（门 B——§18.3）✅ |
| **1.8** | ✅ 已交付（2026-09-29，v0.21.0）：末轮预备——门审全集复跑（A-T 全量 + U 节 190）+ **HM 接线与假阳性修复**（release-and-demand——孤岛能力接线教训制度化）+ 校准 1.4-1.8 回填 + Stage 1 汇总 + 七件套骨架（1135:0:0 + audit 190/190；§9.49 GATE-1..GATE-4 设计依据） | 1.0-1.7 | ✅ §7.3 门审 190 case ≥130 + §6.6 校准 Stage 1 行 |
| **1.9** | ✅ 已交付（2026-09-29，v0.22.0）：Stage 1 收口——§9.50 审查零发现先行 + deep-review-round1.9.md[D1-D8 + 八项偏差全处置 + C1-C6 零整改 + 5.5/5.5 GO] + 七件套终稿 + audit V 节 200 + 出阶段测试族 10 + 校准终态行 + B1-B5 复跑带内（1145:0:0 + audit 200/200；九信号全勾——**GO 推荐，用户确认为最终门**） | 1.8 | ✅ GO/NO-GO = GO（推荐） + v0.22.0 |

**演进时机治理**（roadmap §5 四红线沿袭）：每子阶段出口核对红线（Token 流契约/效应预留/性能基线/复杂度爆炸）；§21.6 三决策点重开需新证据触发 §3.3。

## 3. 保守静态规则 R1-R8（Stage 1.0 定义——本节为权威定义源）

**设计宪法**：保守 = **确定性错误才报**（definite-error-only）——每条规则给出健全性论证（何时为「确定错误」）；不确定 = 放行（fail-closed 仅对确定错误；与 §2.1 fail-closed 安全域恒保守裁定同向）。检查器消费 `&[ModuleItem]`（展开后程序），**镜像编译器的解析顺序**（locals-then-globals——compile.rs `lookup_local` → `intern_global` 同序）与**镜像展开器的顺序纪律**（define-so-far + letrec 预绑定——expand.rs `ctx.bind` 先于值展开）。

| 规则 | 内容 | E 码 | 健全性论证（为何确定错误） |
|------|------|------|--------------------------|
| R1 | 未绑定引用：`Var` 在词法作用域（Fn 参数 + Let 链——**不含外层 Fn**，镜像 `begin_closure` 全新 locals 表）与全局（Defines + Externals）均不可解析 → 报错。顶层即时位看 defines-so-far；Fn 体内看全部 Defines（调用时 = 模块加载完成后——前向引用合法） | E0001 | 词法解析确定性（编译器同序查找）；UnboundGlobal = 双引擎既定运行时错误（vm.rs LoadGlobal / eval.rs 同构） |
| R2 | 已知元数失配：`Apply` 的 func 为 (a) Fn 字面量（IIFE）(b) Var 解析到 Define{value: Fn}（无 Assign 重绑——见护栏）(c) Var 解析到已知元数 External（Builtin）——args 数 ≠ params 数 → 报错 | E0002 | 被调者元数静态已知 + VM `invoke` 闭包 arity 检查 = 既定 ArityMismatch 运行时错误。**护栏**：名字在模块任何位置被 Assign 到全局 → 跳过（重绑可改元数——保守放行）；词法遮蔽（参数/let 同名）→ 跳过（局部值元数未知） |
| R3 | 非布尔字面条件：`If` 的 cond 为 `Literal(非 Bool)` → 报错 | E0003 | 字面量值确定；truthy 仅 Bool = 双引擎既定 TypeMismatch 语义 |
| R4 | 不可调用被调者：`Apply` 的 func 为 (a) `Literal`（Int/Float/Bool/String/Nil/Pair 均不可调用）(b) 无重绑字面 Define 全局位（`(define two 2)` 后 `(two 1)`——assign 护栏 + 词法遮蔽跳过下确定）→ 报错 | E0004 | 字面量永非 Closure/Builtin；invoke = 既定 type_mismatch「call callee」；字面 Define 无重绑时值恒定 |
| R5 | 处理器元数失配：顶层即时位 `Perform{e, argc}` 的最近词法 Handle（Fn 边界截断——闭包体在调用时执行，词法处理器不适用）对 e 的 handler 为 Fn 字面量/无重绑 Define→Fn 且 params ≠ argc → 报错 | E0005 | 最近词法 = 动态最近（Handle 区域词法嵌套 = push/pop 序）；invoke 闭包 arity 检查同 R2 |
| R6 | 顶层未处理效应执行：顶层即时位 `Perform`（不在任何 Fn 内 = 模块加载期立即执行）且词法链无任何 Handle 覆盖该效应 → 报错 | E0006 | 模块加载期无动态处理器安装可能（唯一动态上下文 = 词法 Handle）→ UnhandledEffect 确定 |
| R7 | 不可调用字面处理器：顶层即时位 Perform 的最近词法 Handle 对该效应的 handler 为 `Literal` → 报错（处理器被触发时 invoke 字面量 = 确定 type_mismatch） | E0007 | 同 R4 + 最近词法路由确定性 |
| R8 | 赋值目标意外（**Warning 级**——首个 Warning 生产者）：`Assign` 目标 (a) 完全不可解析（仅直接构造路径可达——展开器已拒绝；StoreGlobal 静默建全局）(b) 解析到 External 名（重绑内建——合法但几乎必为 bug）→ 警告 | E0008 | 非确定错误（两形态均合法语义）——§2.3-4「报错>静默」的警告级实现；不阻断（保守纪律：仅确定错误可 Error 级） |

**层间分工披露**：R1 在展开器已有第一道防线（`Resolution::Unbound → ExpandError::UnboundIdentifier`——0.4 起生产）；类型检查器 R1 = **结构层重断言**（第二道防线——服务直接构造路径[宏合成/程序化 API]与防御纵深，沿「构造器强制 + 展开期重断言」既有先例）。R2-R7 全部为今日**仅运行时可检**的错误——类型检查器的净新增值。R8 为静默行为的首个表面化。

**多错误收集（E0005 语料位裁定——裁定二十一）**：stage0.md 语料中「E0005 多错误收集」描述的是**诊断基础设施行为**（§8.7 errors-are-data + 多条收集），非单条诊断码。kerf 实现裁定：多错误收集 = 检查器**架构属性**（`check_module` 返回 `Vec<TypeDiagnostic>`、逐节点全量遍历不短路），不占 E 码槽位；E0005 槽位分配给 R5（处理器元数失配）。语料其余 E 码引用（E0006 能力门控 fail-closed/E0020 关键字经济/E0021 旧名退役）= 上游语料叙事工件，kerf 注册面激活时按域重新分配并在对应子阶段记录映射（E0006 能力门控 → Stage 2 能力系统议程；E0020/E0021 → 语法切换窗议程）。

## 4. E0xxx 诊断注册面（Stage 1.0 激活）

- **TypeCode 枚举**：E0001-E0008（§3 表——variant-level `code() -> &'static str`）
- **Severity**：Error / Warning 两级（R1-R7 = Error；R8 = Warning——首个 Warning 生产者；§8.7 四级契约的检查器子集，driver 接线时映射全四级）
- **TypeDiagnostic**：`{code, severity, span, message}`——R8 消息形态纪律（小写开头、无句尾句号、载荷反引号、单源字典）
- **Externals 面**：`Externals::from_named_arities(iter)`（名字→Option<元数>）——kerf-typecheck 不复制 STAGE0_GLOBALS 清单（单源纪律：调用方从 `kerf_expander::STAGE0_GLOBALS` + `kerf_vm::Builtin::ALL` 构造——根集成/审计/driver 三消费位）

## 5. PBT 依赖审查（DEA-13 首议程裁定）

**§18 审查结论：DEFER-WITH-TRIGGER → 子阶段 1.2 引入**。依据：①必要性成立（DEA-13 P1——§9.34.5 六类不变量清单 + §9.36 五项确定性不变式——快照/黄金/自举三层缺第四层属性层）②时机：1.0/1.1 的检查器面以穷举样例测试可达近 100%（规则族有限、负向路径枚举完备）；PBT 的属性生成器（良构程序生成 = 语法导向随机 + 双引擎 oracle 对比）在 1.2 有真实消费面（Reader 往返 / VM dispatch 确定性）③供应链：proptest 1.9（§9.34.4 语料候选）为纯 dev-dependency——永不入语言管线/自举链（§18.5 依赖 DAG dev 侧豁免位）；引入时按 §18 全流程记录（版本锁定 + 审计行 + dag 更新）。**1.0 零新外部依赖维持**（kerf-typecheck 仅 +kerf-core/+kerf-span 两条内部边——§18.5 DAG L4.5 位）。

## 6. 与既有议程的对接

- **DEA-15**（trait 形状编译期测试）：1.0 不触及 reserved 面（零入边维持——裁定十七）；1.1 driver 接线消费 reserved kit 时复核。
- **DEA-16**（错误恢复路径）：E0xxx 注册面 = 诊断层基础设施；recovery_action 字段议程归 1.1 driver 面。
- **E0021 旧名退役 / E0020 关键字经济**：语法切换窗议程（1.4 子集冻结时激活登记）。
- **§9.24 观测理论 / 流形求解器**：Stage 2+ 设计约束（TY-C 裁定维持——不提前实现化）；1.3 HM = 既有生产路径（Algorithm W 迭代版），非流形求解器。
- **前端三段 .krf 重写**（1.5-1.7）：TD-032 五切口模式沿袭 + B3 parity 28 函数先例 + §9.25 BS-C 语法迁移验证体系。

## 7. 变更日志

- **v1.7（2026-09-29）**：1.7 行交付——selfhost/v1/macro.krf 第三件（纯函数库：注册五重校验/定元匹配/六步实例化/mangled 编码——MX-1 结构化记录 + 宿主解码逐字节）+ expander.krf 宏面扩展（define-syntax 真实注册 + 使用点分派 + 双形 name + 世代线程）；装配契约 MX-2（macro 前置 + 宿主拼接）；Macro 层收缩 MX-3（oracle 定案位拆除 + 哨兵零路由）；门 B 二阶段双口径 MX-6；语料 72→79（rename-on-capture 与两代链首次语料行使）。

- **v1.6（2026-09-29）**：1.6 行交付——selfhost/v1/expander.krf（单函数自递归 + 五合成节点模式[互递归禁令的工程化解] + 扁平前序流注入 + 三层分流[Reader 6/Macro 2/Expander 64] + §9.47.3 七 span 陷阱逐条镜像 + loader 面全量）；语料扩展 68→72（pos-029/030 + neg-048/049——ModuleCycle/NotFound 语料可达化）；双面自举不动点（结构面 + 错误面）；可名化补全两例（CoreExpr/Binding/HandlerClause 经 kerf-compiler + CoreError 经 kerf-expander——零新 Cargo 边）。

### v1.5（2026-09-29）

- 1.5 行交付：Reader .krf 重写**第一段（结构层）**——selfhost/v1/reader.krf（冻结子集纯消费者：18 内建 + 8 特殊形式零越界）+ kerf-driver reader_parity.rs（RS-1 源注入表格契约 / RS-2 结构化错误值 + 宿主单源渲染 / RS-3 双轴归一化 / RS-4 双引擎承载）。
- 设计依据：stage0.md §9.46（v9.12——K18-K21 锚 + 子集表达力审计十二行 + B3 口径修正）。
- 关键裁定：float 载荷 = Debug 文本（inf/NaN 无 .krf 字面量形态）；输入带路线不采（字符串不透明 → 源注入为唯一类型化通道——subset-spec §3.3 义务重登记第二段评估位）；eval depth 仅计闭包调用（迭代式选型实证）。
- 新面：selfhost/ 根目录（自举面登记）；kerf-reader 补 FileId/ByteOffset re-export（零新边）。

- v1.0（2026-09-28）：开工轮落档——出阶段确认记录 + 排期 1.0-1.9 + R1-R8 权威定义 + E0xxx 注册面 + PBT §18 裁定（DEFER-WITH-TRIGGER→1.2）+ 裁定二十一（E0005 语料位）。
- v1.0-a（2026-09-28，同轮实施同步）：R4 扩展终态——无重绑字面 Define 全局位并入不可调用被调者族（assign 护栏 + 遮蔽跳过守卫下确定；plan-1.0.md §4 决策 2）；层间分工披露补全（源码级前向引用被展开器拒绝——第一道防线更严；检查器 Fn 体全定义可见性 = 结构层属性）。
- v1.2（2026-09-29）：1.2 行 ✅ 已交付 v0.15.0——七属性三类不变量首批 + proptest 1.11.0 dev-dep（§18 落地）+ audit 不扩节裁定（PBT 与样例审计互补）+ FP2/FP4 域对调实施裁定 + FP3/FP7 define 槽断言面裁定 + 发现披露 2 项（display 非序列化面——不动点口径；空表/空参表 reader 拒绝——生成器域约束）——详录 plan-1.2.md。

- v1.3（2026-09-29）：1.3 行 ✅ 已交付 v0.16.0——迭代 W + union-find/undo-log（健全性必需：If 分支隔离）+ SCC 分治（Tarjan 依赖先行——同 SCC 预绑定互递归/跨 SCC schema 实例化解耦同模块多态复用）+ 保守纪律四件（If join→Dyn / assigned 守卫 / ad-hoc 数值域 / 效应行收集面）+ E0009-E0011（E0011 恒 Warning）+ Layer 2 TypedExpr 标注树 + 快照 IS 族 + audit P 节 140——详录 plan-1.3.md（设计演进披露 2 项：分支外泄假阳性 + 预绑定单态化假阳性——实施期深审抓获当轮修复）。

- v1.4（2026-09-29）：1.4 行 ✅ 已交付 v0.17.0——子集冻结（subset-spec.md：冻结面六表 + 实证语义细则五条）+ 验收语料 68（pos 26/neg 32/bnd 10——期望全实证[探针轮 68/68 固化]；指令文法六形态——dg-* 模式）+ parity 契约面（kerf-driver parity 模块——BS-C 1.4 切片：CorpusCase/Expectation/Observed/EquivalenceReport + validate/validate_all + ParityReport.globals_repr 加性字段）+ audit Q 节（detector-detects 元审计）150/150——1046:0:0（+93）——详录 plan-1.4.md（实证裁定四项：闭包不捕获 = E0001 正确检出[双引擎一致] + 前向引用 = 展开期拒绝[R1 行文档口径修正] + `()` = Reader 期拒绝 + write-line 仅 Str 域；深嵌套生成 bug 自抓获 1 处——探针轮价值实证）。

- v1.8（2026-09-29）：1.8 末轮预备交付——门审全集复跑 190 + HM 接线（GATE-2：同批双层 + 假阳性修复 release-and-demand + FP3 硬化五锚 + U1c 装配源零 Error 锚）+ 校准回填（1.4-1.7 四行 + Stage 1 汇总 + 孤岛接线教训）+ 七件套骨架（六文档 + pipeline-test-coverage §8）；共变族九处全实测；v0.21.0。
- v1.9（2026-09-29）：Stage 1 收口轮——§9.50 检查器域审查（管道五段谱系完备：零 ★）+ D1-D8 + §14.8 八项偏差全处置 + C1-C6 零整改 + 七件套终稿 + audit V（200）+ 出阶段测试族 + 九信号全勾 + GO 推荐（用户确认最终门）；v0.22.0。

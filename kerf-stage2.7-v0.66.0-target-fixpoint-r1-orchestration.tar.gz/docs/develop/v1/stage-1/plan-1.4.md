# Stage 1.4 子阶段计划与交付实录——kerf 子集冻结（.krf 自举目标面：子集规格 + 验收语料 68 + parity 契约面）

> **Status**: Delivered（1.4 执行轮落档——2026-09-29）
> 依据：stage-1-plan.md §2 行 1.4 + docs/stage0.md §9.45（自举子集冻结前沿对照与语料/parity 骨架设计——第四十三轮设计锚）+ §9.25.4（BS-C SyntaxTransitionValidator 登记态）+ docs/sop.md §9.2/§9.4.3 v15.1
> 前置：1.3 基线（v0.16.0 · 953:0:0 · audit 140/140）

## 1. 任务构成

- **子集规格文档**（`subset-spec.md`——本目录）：.krf 自举目标面的诚实冻结——冻结面五表（特殊形式 10 / 内建 18 / 字面量 6 / 核心构造子 9 / 模块项 4[Define/DefineSyntax/Require/Module]）+ 排除面显式登记 + 语义锚定链（表面形式 → CoreExpr → 字节码 → eval 同构）+ 语料指令文法。零能力扩张（零新原语零语法增量——当前实现面的登记非设计愿景）。
- **验收语料 68 条**（`tests/v1/stage1/corpus/*.krf`）：目录制数据文件 + 首行 `;; expect:` 指令（GCC torture `dg-*` / rustc ui-test 模式——§9.45.5）；期望六形态（value/parse-error/expand-error/type-error/runtime-error/warning）；**每条期望均经真实管线实证核对**（探针轮 68/68 后固化——零猜测期望）。
- **parity 契约面**（`kerf-driver/src/parity.rs`）：BS-C 登记态的 Stage 1.4 切片——`CorpusCase`/`Expectation`/`Observed`/`EquivalenceReport`（drift 字段 = SemanticDrift 1.4 切片）+ `validate`/`validate_all`（validate_test_suite 形态）+ 指令解析器；双引擎等价承载（run_parity 消费）+ 1.5 双 Reader 扩展位（报告形态同构——不预建 Reader 抽象，§9.45.6 不做清单）。
- **pipeline 增量**：`ParityReport.globals_repr`（加性字段——每 define 的共享结构 repr 按程序序；值约定 = 读末位 define）。
- **审计 Section Q**（10 case）：detector-detects 元审计——错误期望必须带双侧漂移报告 + 阶段归因双向 + 码集精确比较 + 值约定命名 + 批次面 + 封闭指令文法。

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo build --release | 0 error / 0 warning |
| cargo check --all-targets | 0 / 0 |
| cargo fmt --check | 零 diff |
| cargo clippy --all-targets -- -D warnings | 0 告警 |
| cargo test --release | **1046:0:0**（953 基线零回归 + 净 +93：crate 12[parity 单元] + 根集成 81[语料 68 + 语料元 3 + 契约 12 - 旧 parity 字段共变 2]） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 150/150**（A-P 维持 + Q 节 10 新增） |

**GATE 1 编码面扫描**：新增源面（parity.rs / pipeline.rs 增量 / subset_corpus_tests.rs / parity_contract_tests.rs / audit Q 节 / corpus 68 文件）零非英文命中（R8——消息形态小写开头、无句尾句号、载荷反引号）。

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

| 层 | 文件 | 数量 | 说明 |
|----|------|------|------|
| 内联单元 | parity.rs | 12 | 指令解析器六形态 + 拒绝面（缺前缀/空载荷/未知关键字/缺码）+ same_set 序不敏感 + from_source 首行切分 |
| 根集成 | subset_corpus_tests.rs | 71 | 语料逐条 68（宏表一一对应）+ 动态全目录扫（完备性）+ 分布底线（pos ≥20/neg ≥20/bnd ≥10/总 ≥50）+ 命名前缀唯一性 |
| 根集成 | parity_contract_tests.rs | 12 | 正向 4（值约定/双引擎错误一致/警告码集/检查器码集）+ 负向 5（错值双侧漂移/检查器先拒/双停误期/阶段归因/缺警告）+ 跨阶段消费 3（globals_repr 程序序 + 模块面路由 expand 标 + 双引擎 run 面） |
| 审计 | examples/audit Q 节 | 10 | 元审计：错误期望的检出面全覆盖 |

**语料分布实态**（68 条）：正向 26（含警告位 1——E0008 重绑内建）/ 负向 32（Reader 4 + Expander/Loader 14[含前向引用与闭包不捕获两语义面] + Typecheck 8[含多错误收集] + Runtime 6）/ 边界 10（i64 极值 2 + 溢出 1 + 浮点形态 2 + 嵌套帽双侧 2 + 深递归 1 + 长链 1 + 展开帽 1）。

**分布论证**（§9.45.5 义务）：错误易发面密度最高位 = 展开/装载层 14 条（子集冻结的最大风险面 = 隐式语义[前向引用/闭包不捕获/quote 符号面]全在该层实证）；Reader 4 条覆盖 §7.1.1 class 1/3；Typecheck 8 条覆盖 E0002-E0008 七码全档 + 多错误收集；Runtime 6 条含双引擎错误一致（差分对偶）；边界 10 条全部为量化帽/极值的**双侧**取证（255 过/257 拒、i64 max 存活/min-1 拒）。

## 4. 关键决策与共变披露

1. **闭包不捕获 = 冻结语义（实证裁定）**：`(define (adder n) (fn (x) (+ x n)))` 中内层 Fn 引用外层参数——双引擎一致拒绝（`unbound global n`——eval dormant capture 不参与解析、VM 编译为 LoadGlobal）。E0001 = **正确检出**（R1 词法域「不含外层 Fn」精确镜像双引擎）。语料 neg-045 固化该语义（防未来自举重写时语义漂移——1.5 parity 的锚点 case）。捕获语义 = Stage 2 词法寻址窗（§9.44.5 既有触发器）。
2. **前向引用 = 展开期拒绝（实证裁定 + 文档修正）**：`(define (f x) (g x))` + 后置 `(define (g x) ...)` → UnboundIdentifier（展开器 define-so-far 严格——1.3 轮 §4 决策 4 同款披露在语料面固化）。stage-1-plan §3 R1 行「Fn 体内看全部 Defines（前向引用合法）」= **检查器对直接构造面的视角**；源路径以展开器为准。语料 neg-046 固化。互递归同因不可达（源路径）。
3. **`()` = Reader 期拒绝（实证裁定）**：空表在 Reader 即拒（`empty application`——§7.1.1 class 3），非展开期。语料 neg-021 期望 parse-error（初稿误期 expand-error——实证修正）。
4. **write-line 仅 Str 域（实证裁定）**：`(write-line 42)` int 实参 → 双引擎一致 `type mismatch`（§8.8 最小 I/O 的域约束）。语料 pos-023 用 Str 实参 + neg-047 固化 int 拒绝。
5. **期望内嵌指令而非旁置 manifest（选型）**：`;; expect:` 首行 = 语料自描述（dg-* 模式）——期望与源永不失配（旁置 manifest 的双文件漂移风险归零）；代价 = 指令解析器（12 单元测试 + Q10 封闭文法审计覆盖）。
6. **值约定 = 末位 define**：define-only 模块程序终值恒 nil（eval_program/VM 同构）；末位 define = 模块可观测结果（REPL `$repl:N` 同通道）。空定义程序（纯 module 体）→ 明确漂移「no top-level define」（Q07 审计固化——报错优于静默）。
7. **ParityReport 加性扩字段**：globals_repr 三处字面量构造位共变（pipeline 内联测试 2 + audit I09 1——加性字段的构造义务全清单）。无既有断言破坏。
8. **深嵌套生成 bug 自抓获**：初稿 bnd-006 生成器漏 else 分支（`(if #t X)` 三元形式）→ `malformed if` 漂移 → 修正为 `(if #t X 0)` 四元。语料探针轮的价值直接实证（期望零猜测纪律）。

## 5. 边界与登记

- **E0001 源路径不可达**（1.0 轮既有披露在语料面维持）：展开器第一道防线先拒（UnboundIdentifier）——E0001 语料位（neg-045）经**闭包不捕获**路径可达（展开器词法域宽于运行时有效域——R1 第二道防线的净新值实证）。
- **HM 面（E0009-E0011）不在语料面**：driver typecheck() 仅接 R1-R8（HM 接线 = 1.8 议程维持）——语料 type-error 位 = E0002-E0008；HM 语料增量随 1.8 接线（语料扩展义务——§9.45.7）。
- **read-line 无语料位**：语料 harness 零输入运行（BufferIo 空）——read-line 依赖输入带，属 REPL 面（session-replay 既有测试族覆盖）；1.5 双 Reader parity 语料可带输入带扩展（登记）。
- **字节码全等不在 1.4 契约**（BS-C 分层裁定维持）：fixpoint 窗（1.7+ 三阶段构建）开窗时与门 B 合并。
- **subset-spec.md 冻结 = 登记非枷锁**：后续子阶段表面变更（1.5-1.7 切口）须同步规格 + 语料增量（语料扩展义务表——§9.45.7）；规格与实现冲突以代码为准 + 本提交修正文档（§8.4.5）。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1 = **5.5/5.5**（SKL-A 会签：探针轮抓获语料生成 bug 1 处 + 期望误期 2 处并实证修正——「期望零猜测」纪律的执行实证）。§7.2 Q1-Q6：Q1 零越界（kerf-driver 模块内增量 + 根测试树——契约层非内核非管线执行路径）✓ Q2 零新边（parity 消费既有 pipeline 面；pipeline 加性字段）✓ Q3 零新依赖 ✓ Q4 语料 = 验证面（§9.45.5 构成理论的实施）✓ Q5 构成达标（GATE 6：根集成 83 = 语料 71 + 契约 12——正负由六形态期望承载 + 跨阶段消费 3）✓ Q6 实测非声称（探针轮 68/68 → 固化后 1046:0:0 复跑）✓。

## 7. 版本与下一入口

- Cargo.toml workspace **0.17.0**；git commit 见 worklog 第四十三轮条目。
- 下一入口 = **Stage 1.5 Reader .krf 重写（第一段）**：S-expr Reader 以 kerf 子集重写、运行于 Stage 0 VM、Rust 宿主对照 parity（错误消息/Span 逐字节等价——B3 先例 28 函数口径 + 本轮契约面消费 + 切换窗步②首个切口）。

## 8. 打包（§19——21-e 轮回填）

- 包：`/home/z/my-project/download/kerf-stage1.4-v0.17.0-subset-freeze-seed-r1.tar.gz`（tar --exclude=target/.git）——**330 entries / 1,667,359 B / sha256 e6c329ea9e623465ad9ae5a174af62e5c735b58e547610f20e845ebe4a13a109**
- 解包回归验证：`diff -r --exclude=target --exclude=.git` 归零 + 三新交付物在场核验（crates/kerf-driver/src/parity.rs + docs/develop/v1/stage-1/subset-spec.md + plan-1.4.md + corpus 68 文件）
- download/README.md 基准表更新：v0.17.0 = 最新基准（v0.16.0 转历史存档）。

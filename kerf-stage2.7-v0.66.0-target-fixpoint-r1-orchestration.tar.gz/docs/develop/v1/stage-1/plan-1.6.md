# plan-1.6 — Stage 1.6 执行计划（Expander .krf 重写第二段：展开层）

> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.6 + docs/stage0.md §9.47（设计依据层——EX-1..EX-5）+ docs/sop.md §4/§5/§7
> 交付版本：v0.19.0 · git（6.4 规范 commit）

## 1. 任务构成

| MUV | 内容 | 落位（§8.4.6 两级语义） |
|-----|------|--------------------------|
| 1.6-a | **selfhost/v1/expander.krf**——冻结子集书写的展开层 Expander：显式状态线程（帧栈 = 名集列表内层在前 + STAGE0_GLOBALS 18 名 + 深度计数）+ 声明面四头（define 两态/require 字符串域/module 帧隔离/define-syntax 注册槽）+ 表达式八形式 + do→单层平 Let 脱糖 + quote→Pair 右折叠 + let\* 渐进绑定 + define 前绑定 + loader 面（declare + DFS + 重复拒绝）+ span 纪律七陷阱逐条镜像 + `result` 判决通道（("ok" (item…)) / ("err" kind payload…)） | selfhost/v1/（自举面登记——切换窗步②第二切口；1.5 reader.krf 同目录先例） |
| 1.6-b | **kerf-driver expander_parity.rs**——EX-1 源注入表格契约（(define forms (quote (…))) 前缀——Reader 输出节点记录形：ident/int/float-Debug 文本/bool/string/list 六记录 + span 十进制字符串）+ EX-3 三层分流（ParityLayer::{Reader, Macro, Expander}——pos-024/bnd-010 归 Macro 层 oracle 定案）+ EX-4 双轴归一化（oracle/krf 同构 dump 覆盖 ModuleItem 四变体 + CoreExpr 九构造子 + LiteralValue 六形态；错误重建走同一 Display）+ EX-5 双引擎承载（沿 RS-4） | crates/kerf-driver 内（L8 管线属主）；如需既有签名类型可名化 → re-export 先例（零新 Cargo 边） |
| 1.6-c | **语料扩展 4 案**（68→72：pos-029 字符串 require + 比较内建三连 + read-line 未调用覆盖 / pos-030 嵌套 module 隔离正向 / neg-048 module 环 / neg-049 require 缺失模块）+ 测试三层 + audit S 节 + ds08 共变 | tests/v1/stage1/corpus/ + 根 tests/ + examples/audit S 节（160→170）+ 快照 ds08 版本黄金 0.18.0→0.19.0（共变义务第七例） |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo fmt --check | 零 diff |
| cargo build --release / check | 0 error / 0 warning |
| cargo clippy --all-targets --release -- -D warnings | 0 |
| cargo test --release | **1098:0:0**（1069 基线零回归 + 净 +29：内联 7 + 根集成 18 + 语料 4 案） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 170/170**（A-S 十八节——S 节 10 案） |

## 3. 测试构成计划（§9.4.3 v15.1——分布论证）

- 内联单测（expander_parity.rs）：编码往返 / 表格形状 / 三层分流 / 树轴 / 错误轴 / 篡改探测器 / harness 缺陷即数据——正负混合。
- 根集成（expander_parity_tests.rs，挂载于 tests/runner.rs）：**语料 72 全扫重放**（跨阶段消费——1.5 Reader parity 同款动态目录扫自动含新 4 案）+ 三层分布底线 + 篡改双锚 + 自举不动点（expander.krf 读己源经 oracle 展开——但注意 expander.krf 自身含 define-syntax 等形式；不动点面 = reader_parity(READER_SOURCE) 已有先例，本域对应面 = expander_parity 以 oracle reader 输出为输入的回环）+ 报告面。
- GATE 6 口径：集成 ≥3（正向 ≥1 / 负向 ≥3 / 跨阶段消费 ≥1——语料全扫即跨阶段）；正负比全树 ≥1:3 由语料负向族（neg 34/72）维持。
- audit S 节 10：展开器 parity 判定面元审计（detector-detects 第三实例）。

## 4. 关键决策（§9.47 实施转译）

1. **Macro 层分流**（§9.47.4 EX-3 裁定）：pos-024 + bnd-010 由 oracle 定案——SyntaxRules parse/instantiate/世代 span/rename-on-capture = 1.7 域整体；.krf 侧预算检查 = 简单深度计数（512 上限纯源面不可达）。
2. **名栈等价简化**（K22 论证）：CoreExpr 零 scope 字段 → .krf 侧解析 = 内层优先名栈 + 18 全局表，parity 不可观察差异。
3. **loader 面纳入**：neg-020 ModuleDuplicate 错误轴完整性——.krf 侧 declare 收集 + DFS + 重复拒绝（后声明 span）。
4. **语料扩展 4 案**（§9.47.4 裁定——扩展义务表 §3.3 行使）：期望经探针轮实证固化（1.4 纪律——期望零猜测）。
5. **共变清单**：ds08 版本黄金（第七例）+ Cargo.toml workspace+10 成员 0.19.0 + audit 尾部统计行（160→170）+ subset-spec §3.3 交付态注记 + stage-1-plan 1.6 行 ✅ + 变更日志 v1.6。

## 5. 边界与登记

- **1.7 主窗**：宏面 .krf 重写 + fixpoint 门 B（§18.3）——K23 族谱 + Ullrich 备选 = 设计锚。
- **词法层第二段窗维持**；**evaluator 栈预算窗维持**（深树测试侧 deep_stack 沿用）。
- 世代 span 不入 dump（1.6 输出全为世代 0——Macro 分流推论）。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

| 角色 | 票 | 附注 |
|------|-----|------|
| ARCH-A | 2/2 | 三层分流边界（Macro 层 = 1.6/1.7 架构裁定）+ 名栈等价简化（K22 论证）+ 语料扩展（扩展义务合法行使）+ 互递归禁令的单函数工程化解 |
| DEV-A | 1.5/1.5 | 机械生成器切换（手写括号失守→CLIST/CT 归约）——探针战术三轮全部内循环清偿；帧操作/累加器缺陷全数修复实证 |
| QA-A | 1/1 | 语料 72 全扫（三层分布 6/2/64 精确断言）+ 篡改双锚 + 深路径 bnd-006/007 + 双面不动点 |
| ALG-C | 1/1 | 七 span 陷阱逐字节镜像实证（★1-★7 全锚定）+ loader 三面精确 payload（a→b→a 路径）+ 错误先序（首错即赢语义） |
| SKL-A |（不计权）| PASS（deep_stack 显式栈线程 = 环境面正解沿 1.5 先例） |
| **加权** | **5.5/5.5 = 100% ≥ 95%** | |

## 7. 版本与下一入口

- v0.19.0（git commit 按 §6.4：`feat(stage1.6): expander parity — .krf expansion layer lands`）。
- 下一入口 = **Stage 1.7 基础宏 .krf 重写（第三段）**：SyntaxRules .krf + fixpoint 门 B（stage-1-plan §2 行 1.7；TD-032 五切口第三切口）。

## 8. 打包（§19——23-e 轮回填）

- tar --exclude=target/.git → `/home/z/my-project/download/kerf-stage1.6-v0.19.0-expander-parity-seed-r1.tar.gz`
- **357 entries / 1,753,635 B / sha256 0d77b20f563858add4093b42a48bc8de4fd3f579961975ce22ca4a0517838ee1**
- 解包回归验证：diff -r --exclude=target/.git 归零 ✓ + 关键文件在场核验（selfhost/v1/ 双文件[reader.krf + expander.krf] + expander_parity.rs + plan-1.6.md + stage0.md §9.47）
- download/README.md 基准表更新（v0.19.0 = 最新基准；v0.18.0 转历史存档）

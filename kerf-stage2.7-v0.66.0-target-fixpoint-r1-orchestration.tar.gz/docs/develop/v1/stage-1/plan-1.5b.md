# plan-1.5b — Stage 1.5 第二段执行计划与实录（Reader .krf 重写第二段：词法层）

> 依据：stage-1-plan.md §2 行 1.5 第二段 + docs/stage0.md §9.86（设计依据层——LX-1/K20 裁定）+ docs/sop.md §4/§5/§7
> 交付版本：v0.55.0 · 第八十五轮（r85）· 63-a 重审清偿
> 前置：plan-1.5.md（第一段——结构层，v0.18.0）；§9.71（r70 词法域重审——RDR-1/2/3 后的 oracle 语义）

## 1. 任务构成

| MUV | 内容 | 落位（§8.4.6 两级语义） |
|-----|------|--------------------------|
| 1.5b-a | **selfhost/v1/lexer.krf（473 行）**——冻结子集书写的词法层：lx-scan（trivia + 模式位注释扫描）/ lx-token（分派 + 拒绝集）/ lx-string-body（边界 + 转义校验内联）/ lx-atom（极大采集 + 逐字节）/ 分类层（lx-bool / lx-int 负域累加 + 19 位阈值守卫 / lx-fg 文法自动机 / lx-symbol 地板）/ lx-start 主循环（每 token 一帧——REC-A 谱系） | 跨 crate 全局面 selfhost/v1/（自举面第五件） |
| 1.5b-b | **kerf-driver lexer_parity.rs**——字节表前缀构造器（空源 `(quote nil)` 特例）+ 全链装配（prefix + lexer.krf + reader.krf 原样）+ 三轴解码（token 树/错误重建——十二变体全映射）+ K20 宿主值面（f64 parse + is_infinite → FloatOutOfRange）+ 双引擎驱动（三全局提取器）+ VM 包络面 + 漂移分类（K165/K166 谱系） | crates/kerf-driver 内（L8 管线属主）；reader_parity 的 error_parity_key 开放 pub(crate) |
| 1.5b-c | 测试三层 + audit R 扩展 + FMT 守卫五件化 + 文档族 + 版本族 | 根 tests/ + examples/audit + docs/ + 版本共变 |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo fmt --check | 零 diff |
| cargo build --release | 0 error / 0 warning |
| cargo check --all-targets | 0 / 0 |
| cargo clippy --release --all-targets -- -D warnings | 0（question_mark 七处内循环清偿） |
| cargo test --release | **1343:0:0**（1321 基线零回归 + 净 +22 = lexer_parity_tests 全族） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 246/246**（R 节 10 → 20） |

环境参数：`ulimit -s 131072` + `RUST_MIN_STACK=33554432`（交付态一致口径）。

## 3. 测试构成（lexer_parity_tests 22 函数）

- **正向 8**：混合程序双轴 / 富夹具（BOM+CJK+VT+注释含非 ASCII+转义+邻接——r70 夹具逐字镜像）/ 数值边界（i64 MIN/MAX/007/1e20/1e-999）/ 空与纯注释源（三形态）/ Unicode 空白全表（十二码位分隔）/ 嵌套边界 255/257 / reader.krf 定点（VM 面）/ lexer.krf 定点（VM 面）。
- **负向与边界 9**：十三词法拒绝精确 key / 双溢出面（i64 .krf 裁定 + f64 K20 宿主轴）/ C1 控制符号地板 / 结构拒绝四族过链 / 四篡改探针（转义集 114→1145 / VT 终止符 11→110 / 阈值尾位 55→54 / U+3000 表项 128→129）/ harness 缺陷分类 / 报告面。
- **跨阶段消费 3**：语料 85 全链全扫（读取期拒绝 ≥5 断言——expand/check/runtime 族读取成功属下游面）/ 边界四件（bnd-006/007 VM 面 + neg-054/055 双引擎）/ 包络双守卫（500 内双引擎 / 2000 外诚实分类）。
- 正负比：负向形态（13 拒绝 key + 4 溢出 + 1 C1 + 4 结构 + 4 篡改 + 1 缺陷 + 1 越包络 = 28）vs 正向形态（8 函数 + 85 语料重放）——语料负向族维持全树 1:3 口径（§9.45.5 沿袭）。

## 4. 关键决策与内循环实录（诚实登记——六族缺陷当轮清偿）

1. **括号平衡两处**（lx-skip 尾行 / lx-char-code 内 car 闭合）——装配程序解析失败首跑拦截；python 深度审计定位修复。
2. **前向引用重排**——子集 §2.2 顺序绑定纪律（neg-046 锚）：lx-skip↔lx-comment 互递归 → 注释扫描并入模式位单函数；lx-string-body↔lx-escape 互递归 → 转义臂内联；分类层整体前置于扫描层；fg 族重排（expd 前置）。
3. **i64 阈值编码错误**——首版字节表把 9223372036854775807 编错（54≠55 位）致 MIN/MAX 误拒；脚本 enc() 重编码 + 断言验证。
4. **lx-fg-expd 基例两轮**——nil → #f（首版）错杀 "1e5"；修为 #t 后错放 "1e+"——终形：expd（尾消费 nil=#t）+ expd1（入口 ≥1 数字必需 nil=#f）分离。
5. **空表 quote**——`(quote ())` 被 Reader 期拒绝（§2.5 空应用）；空源改 `(quote nil)`（§1.4 nil 数据面）。
6. **断言口径**——树轴拒绝带 `ERR ` 前缀（starts_with → contains）；backtick Display 为三连反引号；数值边界 span 手算修正（MIN 20 字符 3..23）。

## 5. 包络裁定（K165/K166 谱系——诚实边界）

- eval 双引擎包络 ≈ **~1.05k token / 最长单段 trivia ~2.05k 字节**（实证二分：wide 1000 过 / 1100 触顶；reader.krf 头注释块 ~2.4k 字节单段 trivia 触顶）——每 token ~2 帧（与 r74 读取器包络同族）。
- VM 面承载：bnd-006/007（~1.3k token）、reader.krf 定点、lexer.krf 定点（~3k token）——`reader_parity_full_vm` + 调用方披露；语料清扫遇 `harness limit:` 自动转 VM 面验证（bracketed ≤2 断言）。
- 字节表帧形：lx-start 每 token 一帧 + 逐字节走查为瞬态帧（深度 = token 数 + 最长段——非总字节数）；但**连续 trivia 段**为单段不中断自递归（注释块 = 段长帧）——已实测登记。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

| 角色 | 票 | 附注 |
|------|-----|------|
| ARCH-A | 2/2 | 字节表路线 = RS-1 载荷推广（零冻结变更）+ K20 永久层两件升格裁定一致；R5 脚手架「Rust 宿主信任」的词法器拆除义务兑现（VM 除外——宪制排除项维持） |
| DEV-A | 1.5/1.5 | 六族内循环缺陷全当轮清偿（括号/前向引用/编码/基例/空表/断言）；迭代式主循环 + 模式位注释扫描可维护 |
| QA-A | 1/1 | 四篡改探针全捕获 + 三轴漂移定位 + 语料 85 全链 + 包络诚实分类（bnd-006/007 VM 面断言） |
| ALG-C | 1/1 | 十二变体错误语义逐 key 对账（含 K20 宿主轴 float-out-of-range 构造性一致）；19 位阈值守卫无陷阱证明（负域累加 + 界内前缀 ≤ MAX/10） |
| SKL-A |（不计权）| PASS（eval 包络 VM 面承载 + 深栈线程沿 r74/r83 BST-1 先例） |
| **加权** | **5.5/5.5 = 100% ≥ 95%** | |

## 7. 版本与下一入口

- v0.55.0（git commit 按 §6.4：`feat(stage1.5): the lexical layer lands — the reader bootstraps complete`）。
- **reader 阶段完备自举** → 自举管道纪律清偿（「reader 完整完全自举后才能进入下一阶段自举」——63-a 裁定的唯一未解决问题关闭）；下一入口 = **Stage 2.4 双编译器等价验证窗**（stage-2-plan §2 行 2.4——禁入解除判据已满足：本段即清偿）。

## 8. 打包（§19——63-pkg 回填）

- 见 my-project/download/ 基准表（Pack A/B 双包制沿先例）。

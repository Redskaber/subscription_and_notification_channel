# stage-1 轮次记录移档（round-records.md）——§9.46-§9.50 实施细节

> 依据：docs/stage0.md 分层整理（2026-10-02 用户指令）——stage0.md 为诞生源头/设计来源/架构理论/技术引用统一记录层；本档案承接 Stage 1.5-1.9 各段（§9.46-§9.50）实施设计/管道对账/实施清偿/收敛口径的**逐字移档**（零改写零丢失）。检索锚表/演进窗登记/线程关系/裁定族留驻 stage0.md 对应节；本档案条目以 `#9.NN.M` 锚与 stage0.md 存根互指。

---

## 9.46 Reader 自举第一段的前沿对照与双 Reader parity 设计（第四十四轮——Stage 1.5 设计依据供给轮）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.46 勘察基线与节引言


> 勘察基线：v0.17.0（1046:0:0 · audit 150/150 · 六命令冷跑复验）。独立勘察轮（Task 22-b）：kerf-reader 全公共面逐项签名核对（7 pub fn/method + 1 pub const + 3 Display——「B3 parity 28 函数」证实为文档域目标口径非代码实态，§9.46.3 注记）+ ReadError 十变体消息模板逐字节记录 + 冻结子集六表 + 双引擎机制 + parity 契约面全量核对；检索存档 tool-results/r22-search/（六查——本轮首次将检索存档实体入库，r21-search/r42-search 指针悬空沿旧例注记）。


### 9.46.2 管道 v0.17.0 增量对账（vs §9.44.3 十二行表）

Stage 1.4 净变更全量清点：kerf-driver `parity.rs` 新模块（契约面：`CorpusCase`/`Expectation` 六形态/`Observed`/`EquivalenceReport` + 封闭指令文法）+ `ParityReport.globals_repr` 加性字段（构造位共变 3 处已披露）——**纯增量消费面**：零数据结构选型变更、零新 crate 边、零新外部依赖、零算法变更 → §9.44.3 十二行表**零漂移零新债维持**（勘察逐行核对无一项越窗；`parity.rs` 属 kerf-driver 行的测试基础设施子面，非管线数据面）。


### 9.46.4 双 Reader parity 第一段实施设计（BS-C 1.5——结构层分段）

**RS-1 源注入表格契约（data-prefix injection）**：宿主 = Rust 词法器（`kerf_reader::lex` 单源）→ token 流编码为 `(define tokens (quote (record…)))` 前缀，与 `selfhost/v1/reader.krf` 拼接为完整程序。record 形态（全 proper list，头 = kind 字符串）：`("lparen" s e)` / `("rparen" s e)` / `("ident" s e "text")` / `("int" s e 42)` / `("float" s e 3.5)` / `("bool" s e #t)` / `("string" s e "decoded")` / `("eof" e)`——s/e = 十进制字节偏移**字符串**（.krf 侧不透明携带）；类型化字面量（Int/Float/Bool/String）由宿主生成（float 经 Debug round-trip 精确、string 经 kerf 转义子集 `\" \\ \n \t \r` + 其余字符原样——原始控制符在 kerf 字面量中合法）。先例：REPL `$repl:N` 源级包装（repl.rs 既有）+ K18 hex0 层位思想。**输入带（read-line）路线被裁定不采**：字符串不透明使任何「一行一记录」协议同样不可拆解（字段无法从行文本提取）——源注入是冻结子集下唯一类型化数据通道；subset-spec §3.3「可带输入带」义务重新登记为第二段评估位（RS-5）。

**RS-2 .krf 结构层 Reader（selfhost/v1/reader.krf——迭代式显式栈）**：主循环 `rd-loop(toks stack forms)` 自递归逐 token 步进 + 帧栈（内层在前）`(depth open-start items-rev)`；错误语义逐条镜像 parser.rs 实测锚——①`UnclosedList` = eof 时栈顶（最内层）开括号 offset（`(((x` → 2——多开表报最内层测试锚）②`UnexpectedClose` = 栈空时 rparen 的 start offset（顶层与形位同规则）③`EmptyApplication` = 闭合时空表，报该表自身 `(` offset，且**先于**外层未闭合（`(()` → 1 非 0——左到右降序优先）④`NestingDepthExceeded` = 进入时计数（栈深+1 > 256 → depth=257, limit=256）。结果约定：末位 `(define result …)` = `(ok form…)` 或 `(err kind payload…)`；宿主由结构化 payload 重建 `ReadError` 走既有 `Display`（渲染单源——byte-parity 由构造成立）。**迭代式选型理由**：bnd-006（255 深 ≈ 512 token）在 Evaluator EVAL_DEPTH_LIMIT=2048 预算下，递归下降形 .krf 实现每层多帧必越限；显式栈 + 帧内深度计数（免 len 调用）= REC-A 方案 3（VM 迭代主循环 TD-023）在 .krf 侧的新实例（Reader 结构层 = 谱系第二实例）。

**RS-3 归一化对账（双轴）**：树轴 = oracle `SyntaxObject` 树与 .krf 结果树（经堆行走）各自归一化为同构 dump（`kind s e payload` 递归形——dump_stx 快照格式[tests/v0 §A]的带 span 扩展位，float 双侧 Rust Debug、int 十进制、string `{:?}`——同一 Rust 代码渲染保证形式一致）；错误轴 = 宿主重建 `ReadError` 的 `Display` 与 oracle `Display` 逐字节比对。词法层拒绝输入（六变体域）：oracle 词法错误即 harness 判定（.krf Reader 不被调用——分层归属登记，非 parity 缺口）。

**RS-4 双引擎承载**：harness 以 `run_parity` 同构模式保留双引擎句柄（Vm + Evaluator 各自堆）→ .krf Reader 在双引擎上的 result 全局结构一致（values/globals 三面）+ 与 oracle 归一化一致 = 双轴 × 双引擎四格全绿才 PASS。

**RS-5 第二段（词法层）登记窗**：开窗前置 = ①字符串原语子集扩展裁定（K21 最小集：string-length / string-ref→码点 / substring——冻结面变更走 subset-spec §5 纪律 + 语料共变）②f64 面 = 宿主透传维持（K20——即使字符串原语齐备，f64 parse 语义仍不可子集内重实现，登记为永久宿主层候选）③输入带指令文法需求评估。零信号不开窗（本轮只登记）。

**落位（§8.4.6 两级语义）**：`selfhost/v1/reader.krf` = 跨 crate 全局面（新根目录 `selfhost/` = 自举面登记——切换窗步②首切口的物理锚位）；`crates/kerf-driver/src/reader_parity.rs` = 表格生成器 + 归一化 + 报告类型（crate 内）；跨 crate 断言 = 根 `tests/v1/stage1/plan/reader_parity_tests.rs`（runner.rs `#[path]` 挂载）；audit R 节（门审 150 → 160）；快照 ds08 版本黄金共变（0.17.0 → 0.18.0——共变义务第六例）。


### 9.46.7 收敛口径

零机制变更、零新原语、零语法增量（登记态——原则 38/44-58）；1.5 实施设计（§9.46.4）为前瞻性内容，落地以 stage-1-plan 1.5 行 + plan-1.5.md MUV 流程为准（本节是设计依据层非执行层）；8 原语不变性**第十九轮**验证（§9.45.9 第十八轮之后——纯文档域零代码变更零原语触碰：.krf 结构层 Reader = 既有 8 原语 + 18 内建 + 8 特殊形式的纯消费者，零新增面）；检索质量如实披露（q3/q5 弱结果降档——沿 K15 既有登记）；B3 口径修正（9.46.3 注记）= 文档-代码冲突以代码为准的第 3 例（§9.44.2 symbol 行 / §9.45.4 R1 行之后）。

---



---

## 9.47 Expander 自举第二段的前沿对照与双 Expander parity 设计（v9.13——第四十五轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.47 勘察基线与节引言


> 勘察基线：v0.18.0（1069:0:0 · audit 160/160 · 六命令冷跑复验）。独立勘察轮（Task 23-b）：kerf-expander 全公共面逐项核对（expand/expand_program 双入口 + ExpandCtx 五字段 + 19 错误变体 Display 模板逐字节 + dispatch 全序 + 每形式验证先序与 span 纪律）+ 冻结子集六表 × 语料 68 逐案普查（哪张表/哪个头实际被行使）+ reader_parity 先例全量（RS-1..RS-5 契约族）+ pipeline.rs 接线（expand_program 输入 = Reader 直产 &[SyntaxObject]，divergence 点 = Vec&lt;ModuleItem&gt;）+ CoreExpr 九构造子/ModuleItem 四变体/SyntaxObject 全字段 + reader.krf 约定（rd- 前缀/result 判决通道/无捕获闭包/迭代式主循环）；检索六查存档 tool-results/r23-search/（q1-q6——r22 实体入库先例延续）。


### 9.47.2 管道 v0.18.0 增量对账（vs §9.44.3 十二行表）

v0.17.0 → v0.18.0 净变更仅 kerf-driver reader_parity.rs（+ selfhost/v1/reader.krf 自举面 + audit R 节 + 语料重放测试）——**展开器六文件零触碰**（expand.rs 1691 / ctx.rs 417 / transformer.rs 983 / module.rs 423 / error.rs / code.rs）→ §9.44.3 十二行表 expander 行零漂移零新债；Symbol=String 孪生双类型状态维持（驻留三触发器零信号——LSP 窗/B 系列热点/自举自编译负载均未触发）。

勘察补充（本轮新证据，供 expander 行注记）：dispatch 全序 = ①相位检查（require_runtime 先于一切）→ ②核心形式平铺匹配（fn/if/let/do/set!/perform/handle/quote 八键）→ ③宏表查询（resolve_macro）→ ④应用回退（**声明头在表达式位 = 未绑定标识符应用，fail-closed**——(define …) 嵌套位 = UnboundIdentifier{define}）；预算机制 = enter/exit 深度计数（EXPANSION_LIMIT=512）+ 2× 边距吸收脱糖包装层（ctx.rs 注释明示）→ **纯源程序（非宏）不可达预算上限**（Reader 256 帽前置覆盖）——bnd-010 宏实例化循环 = 唯一可达路径。


### 9.47.3 展开器域逐形式审查表（span 纪律 + 错误先序 + 绑定纪律）

| 形式 | 验证先序 | 输出 span 纪律（★=parity 陷阱） | 可达错误（语料锚） | 语料行使 |
|---|---|---|---|---|
| atoms（Int/Float/Bool/String） | 相位 → 直转 | Literal{**atom 自身 span**} | — | 全语料 |
| Symbol | nil 保留字先行 → resolve → 命中即 Var | Var{atom span}；Unbound{**atom span**} | UnboundIdentifier（neg-013/015/046） | 全语料 |
| List 空 | — | — | EmptyForm（**Reader 前置拒——1.6 不可达**） | — |
| quote | len=2 → datum_to_literal（List 右折叠 Pair 链） | Literal{**整个 form span 非 datum span** ★1} | QuoteUnsupportedDatum{datum span}（neg-014——Symbol 非 nil） | pos-014/015/020 |
| fn | len=3 → 参数表 List 全符号 → fn_binding（fresh scope + push_frame[head 原子基] + 逐参 bind + 体着色展开） | Fn{form span}；**fn 糖 Define 内 Fn span = name 原子 span ★2** | MalformedForm{fn}（neg-011） | neg-011/034/045 + 全 fn 语料 |
| if | len=4 → 三操作数相位 → 展开 | If{form span} | MalformedForm{if} | bnd-006..009, pos-005/006/009/018/020/024, neg-031/037 |
| let | len=3 → spec List → 三形态（空/多绑定[每项 2 元 List]/单绑定[len=2]）→ **let\* 渐进绑定**（值先展开后绑名——后值见前名永不见反向） | Binding span = **值节点 span 非 name 位 ★3**；Let{form span} | MalformedForm{let}（neg-012） | pos-010/011, neg-012 |
| do | len&lt;2 malformed；**len=2 恒等特例（无 scope 无帧无 Let 直返体内展开）★4**；len≥3 单层平 Let（`_` 丢弃绑定 × len−2，后步见前 `_`）——非嵌套链 | Let{form span}；Binding span = step 节点 span | MalformedForm{do} | pos-012/023/028, neg-037 |
| set! | len=3 → name 符号 → **name 自身 scopes resolve** → 命中展开值 | Assign{form span}；Unbound → **name 原子 span 非 form span ★5** | UnboundIdentifier（neg-015） | pos-012/028, neg-015 |
| perform | len≥2 → effect 符号 → 逐参相位展开 | Perform{form span} | MalformedForm{perform} | pos-021, neg-016 |
| handle | len≥2 → 体展开 → 逐 clause（2 元 List + effect 符号 + handler 展开） | HandlerClause span = **整个 clause list span ★6**；Handle{form span} | MalformedForm{handle}（neg-034/035/036） | pos-021/022 |
| application | head 作普通表达式展开（字面量 head 合法——E0004=检查器域非展开域）→ 逐参展开 | Apply{form span}；**无 arity 检查** | （Unbound 经 head） | 全语料 |
| define | len=3 → 两态：fn 糖（List 头）/值形（Symbol 头）；**letrec 前绑定（名字先于体 bind）**；**无互递归**（跨 define 前向引用拒绝） | item span=form span；fn 糖 Fn span=name 原子 span ★2 | MalformedForm{define}；UnboundIdentifier（neg-046 前向引用） | ~60 案 |
| module | len≥3 → name 符号 → **isolate_frames/restore_frames**（嵌套模块不见外层 define/宏——全帧摘除） | Module{form span} | MalformedForm{module} | neg-018（死于内层）, neg-020, pos-025 |
| require | len=2 → **name 必须 String 字面量**（symbol → MalformedForm——**neg-018/019 实际死于此路径非 ModuleError ★7**） | Require{form span} | MalformedForm{require}（neg-018/019） | neg-018/019（均 malformed） |
| define-syntax | len=3 → name 符号 → 保留名检查（RESERVED_MACRO_NAMES 13 词）→ spec 着色 SyntaxRules::parse → 注册 + bind_macro | DefineSyntax{form span} | MalformedForm{define-syntax}；MacroPatternMismatch（use 位 span） | pos-024, bnd-010（仅两案） |
| loader（load_program） | expand_program 后管线调用——平铺命名空间收集 + 三色 DFS + 重复拒绝（首个重复的**后声明 span**） | — | ModuleDuplicate{neg-020}；**ModuleCycle/ModuleNotFound 语料不可达**（需字符串名 require——扩展义务位见 9.47.5） | neg-020 |

**错误轴可达集汇总**（1.6 parity 必须镜像的 ExpandError 变体）：TopLevelExpression / MalformedForm{fn,let,handle,define,require,module,define-syntax…} / UnboundIdentifier / QuoteUnsupportedDatum / ExpansionDepthExceeded（宏路径——EX-3 分流后归 Macro 层）+ ModuleError::ModuleDuplicate；**不可达集**（Reader/管线前置或语料未行使）：EmptyForm / PhaseViolation / Core{DuplicateParam,DuplicateHandler,InvalidSymbol} / MacroPatternMismatch（Macro 层分流）/ ModuleCycle / ModuleNotFound（语料扩展后可达——见 9.47.5）。


### 9.47.4 双 Expander parity 第二段实施设计（BS-C 1.6——EX-1..EX-5）

- **EX-1 源注入表格契约**：`(define forms (quote (form…)))` 前缀——Reader 输出 SyntaxObject 树以节点记录形编码：`("ident" "s" "e" "text") | ("int" "s" "e" 42) | ("float" "s" "e" "3.5") | ("bool" "s" "e" #t) | ("string" "s" "e" "…") | ("list" "s" "e" child…)`——沿 RS-1 记录形全参（span 十进制字符串 + float Debug 文本 + string 4 转义集）；**相位/scopes 不携带**（Reader 输出恒 Runtime + 空 ScopeSet——勘察实证；K26 不可达性同源）。
- **EX-2 .krf 展开层**：`selfhost/v1/expander.krf`——`ex-` 前缀 + 顶层 define 显式状态线程（帧栈 = 名集列表内层在前 + STAGE0_GLOBALS 18 名表 + 深度计数）+ `result` 全局判决通道（`("ok" (item…))` / `("err" kind payload…)`）；**解析等价简化**（K22 等价性论证）：scope 判定退化为内层优先名栈——CoreExpr 零 scope 字段使该简化 parity 不可观察；span 纪律七陷阱逐条镜像（9.47.3 表 ★1-★7）；do 恒等特例 + let\* 渐进 + define 前绑定 + module 帧隔离 + require 字符串域 + loader 面（declare 收集 + DFS + 重复拒绝——neg-020 错误轴完整性）。
- **EX-3 三层分流（ParityLayer 扩展）**：**Reader 层**（oracle 读拒绝即定案——neg-001..004/021/bnd-007 六案沿 1.5 Lexer/Parser 先例）/ **Macro 层（本轮裁定新增）**：pos-024 + bnd-010 由 oracle 定案、.krf 层不行使——SyntaxRules parse/instantiate/世代 span（use_gen+1）/rename-on-capture（name\_\_macro\_N）= 1.7 域整体；**预算裁定**：512 上限在纯源面不可达（9.47.2）→ Macro 层分流后 .krf 侧预算检查 = 简单深度计数（不承担宏循环精确边界）/ **Expander 层**（余 60 案 + 新增语料）。
- **EX-4 双轴归一化**：树轴 = `(kind s e payload…)` 文法覆盖 ModuleItem 四变体（define/require/module/define-syntax）+ CoreExpr 九构造子 + LiteralValue 六形态（Pair 右嵌套 `(a . (b . nil))` + float Debug 形 + string 4 转义）；错误轴 = `("err" kind payload…)` → 宿主重建 ExpandError/ModuleError 走**同一 Display**（字节 parity 由构造——被测面 = kind+payload+span 选择非消息拼装）；世代 span 不入 dump（1.6 输出全为世代 0 源 span——Macro 层分流的必然推论）。
- **EX-5 双引擎承载**：沿 RS-4 全参——同构句柄保活堆行走 + engines_agree（compile→VM 与 eval 双解码一致为前提）+ 篡改探测器自检（drift 即数据非 panic）+ harness 缺陷即数据面。
- **语料扩展裁定（审查驱动——「不要所谓收敛收口」用户指令的落实）**：勘察发现语料覆盖缺口三项——①**4 内建零行使**（`<=` `>` `>=` `read-line`——子集表 §1.3 十八内建中十四行使）；②**Require ModuleItem 从未成功产出**（neg-018/019 均 malformed 死于符号名）；③**ModuleCycle/ModuleNotFound 不可达**（需字符串名 require）。裁定：1.6 轮新增语料 4 案——pos-029（字符串 require + 模块声明 + 比较内建三连 + 未调用 fn 内 read-line 覆盖）+ pos-030（嵌套 module 隔离正向——外层名不泄入内层）+ neg-048（module 环 a↔b 字符串 require）+ neg-049（require 不存在模块）——语料 68→72，1.4 冻结面「扩展义务表」（subset-spec §3.3）合法行使；双 Reader parity 语料重放自动覆盖新案（动态目录扫）；新案期望经探针轮实证固化（1.4 纪律沿袭——期望零猜测）。


### 9.47.7 收敛口径

零机制变更、零新原语、零语法增量（登记态——原则 38/44-58）；1.6 实施设计（§9.47.4）为前瞻性内容，落地以 plan-1.6.md MUV 流程为准（本节是设计依据层非执行层）；8 原语不变性**第二十轮**验证（.krf 展开层 = 既有 8 原语 + 18 内建 + 8 特殊形式的纯消费者——与 1.5 Reader 同形零新增面）；检索质量如实披露（q3 弱结果降档——沿 K15/q3-q5 先例）；语料扩展裁定 = 1.4 冻结面扩展义务（subset-spec §3.3）的合法行使非冻结突破（扩展义务表本就登记「1.6 expander parity」位）；**Macro 层分流 = 1.6/1.7 边界的架构裁定**（subset-spec §1.1「宏触发面 = 1.7 bootstrap agenda」注记的实施化——非能力缺失登记：pos-024/bnd-010 经 oracle 定案维持语料重放完整性）。

---



---

## 9.48 宏面自举第三段的前沿对照与 Macro 层收缩设计（v9.14——第四十六轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.48 勘察基线与节引言


**勘察基线**：v0.19.0（git 8635464 · 1098:0:0 · audit 170/170 · 六命令冷跑复验）——transformer.rs 983 行（541 实现 + 442 内联测试）+ expand.rs 调用点 + expander_parity.rs Macro 层（pos-024/bnd-010 oracle 单方定案）+ selfhost/v1/ 双件（reader.krf 116 行 + expander.krf 675 行——勘注定正：§9.25 D1 对账行的 472/1865 为上游蓝图锚非本仓库实况，R4 以代码为准）；独立 Explore 勘察 12 节报告 + 检索六查存档 tool-results/r24-search/（q1-q6 各 6 条）。


### 9.48.2 管道 v0.19.0 增量对账（vs §9.44.3 十二行表）

v0.18.0 → v0.19.0 增量 = **1.6 交付面**：selfhost/v1/expander.krf 新增（675 行）+ kerf-driver expander_parity.rs 新增（~1000 行）+ kerf-compiler/kerf-expander re-export 可名化补全两例 + 语料 68→72 + 根集成 18。**十二行表对账**：expander 行（+selfhost 伴生面）、driver 行（+expander_parity）、bootstrap 行（+expander.krf 第二件）三行有增量；**transformer.rs 零漂移**（983 行 v0.18.0 态原样——勘察实证：`SyntaxRules::parse`/`instantiate`/`compile_pattern`/`match_list`/`match_datum`/`fresh_name`/`active_rename`/`binder_names`/`binder_collisions`/`collect_symbols`/`instantiate_node`/`require_runtime_shape` 全函数面与 §9.47.3 审查时零变化）——**1.7 重写域基线 = 零漂移冻结态**，本节审查直接以该基线展开。零新债（TD 账面连续十一轮归零维持）。


### 9.48.3 宏域逐函数审查表（fresh_name 决策链 + 卫生纪律 + 错误轴 + 语料普查）

**A. transformer.rs 16 函数逐项审查**（勘察实证基线——语义冻结面）：

| # | 函数 | 审查结论 | 1.7 .krf 可表达性 |
|---|---|---|---|
| 1 | `SyntaxRules::parse`（:106-165） | head/literals/子句形状/查重/相位五重校验序正确；**全部注册期拒绝共用 `MalformedForm{form:"define-syntax"}`**（无独立 MalformedSyntaxRules 变体——错误轴简化先例） | 五重校验 = 纯形状走查 ✓；`("err" "malformed" "define-syntax" s e)` kind 复用 |
| 2 | `compile_pattern`（:218-258） | 分派序 `_`→`...`(Err)→literal→查重 Var→Atom→List；**单子句查重域**（跨子句同名合法） | Pattern 编译为 .krf 记录树 ✓ |
| 3 | `match_list`/`match_datum`（:262-311） | 定元同构（等长+zip）；Literal 按**符号文本**（K30 退化）；bindings=HashMap | .krf 侧 alist（ex-assoc 同族——eq? 值等实证 value.rs:243 `Value::Str(a)==Value::Str(b)`）✓ |
| 4 | `instantiate`（:171-213） | 逐规则声明序首中胜出；trigger 三源（splice 实参符号+STAGE0_GLOBALS 18+RESERVED_MACRO_NAMES 15）；全败 → `MacroPatternMismatch{name, span: head span}` | 声明序+首中 = 线性走查 ✓ |
| 5 | `fresh_name`（:317-325） | `format!("{base}__macro_{counter}")`——**字符串构造在冻结子集内不可表达**（18 内建零字符串运算） | **★1 头号缺口 → MX-1 mangled 记录化解**（结构化编码 + 宿主解码） |
| 6 | `active_rename`（:329-335） | renames 栈顶起搜索 innermost wins | .krf alist 逆序查找 ✓（eq? 值等） |
| 7 | `binder_names`（:341-379） | 仅 `fn` 参数表 + `let` spec 三形；**do/声明头不在列**（do 的 `_` 弃置 = expand 期脱糖产物非 instantiate 引入） | 形状走查 ✓ |
| 8 | `binder_collisions`（:500-511） | binder_names ∩ trigger 去重按声明序 | ex-member? 复用 ✓ |
| 9 | `collect_symbols`（:394-406） | Symbol+List 递归（原子不进 trigger） | 合成模式走查 ✓ |
| 10 | `instantiate_node`（:408-496） | 六步精确序：拼接 early-return（**改名走查永不触碰拼接节点**）→ 世代+1（u32 溢出→depth 族）→ span 同区间新世代 → List 分支 binder 碰撞改名单子树作用域（pushed 计数配对退栈）→ Symbol 分支 active_rename → Atom 拷贝 | **★7 配对退栈 = .krf 栈操作最易错位**；世代构造 ✓（s/e 复用+代数可表达） |
| 11 | `symbol_texts`/`symbol_text`（:381-392/:515-520） | 全符号校验/单符号提取 | 形状走查 ✓ |
| 12 | `require_runtime_shape`（:526-534） | 注册期相位卫兵（span 取**声明形**非节点） | .krf 侧 Reader 输出恒 Runtime（K22 等价——1.6 已裁相位不携带）→ **该卫兵在 .krf 侧恒通过**（不可达面如实登记） |

**B. 调用点审查**（expand.rs）：`expand_macro_use`（:200-210）= instantiate → 产物回灌 expand 循环（到核心形式 fixpoint）；每层 re-expand 计 1 预算、**instantiate 走查零预算**（bnd-010 实测 512 层触顶、span = template 区间 67..73）；注册面 `expand_define_syntax`（:605-629）= def_scope 深染色 spec（§9.38(b)）+ 保留名拒 + ModuleItem::define_syntax 记录。**.krf 侧镜像义务**：宏走查 = 合成模式绕过 ex-depth（对应 Rust instantiate 零预算——否则 bnd-010 深度错位）；分派序镜像（核心形式平铺分派**先于**宏解析）。

**C. 错误轴可达集**（宏面五变体）：malformed（注册期全家）/ macro-mismatch（**语料现零可达案**——★3 死码臂，语料必补）/ depth（bnd-010 可达）/ phase（注册期——.krf 侧不可达如实登记）/ unbound（宏 head 未绑定）。**1.7 harness 新增 kind：`macro-mismatch`（name+span）**——reconstruct_expand_error 加臂；malformed 的 form 名 `define-syntax` 已有先例（static_form 12 名映射需扩）。

**D. 语料宏面普查**：72 案中宏案仅 2（pos-024/bnd-010——Macro 层 oracle 定案）；**rename-on-capture 零语料行使**（两案 template 均无 binder 碰撞——e2e 卫生案只在 Rust 侧 macro_seed_tests）；**两代宏链零语料行使**（use_gen+1 面仅内联测试）；literal 非空表零行使。→ ★4 语料缺口四处，1.7 必须扩展（§9.48.5）。


### 9.48.4 BS-C 1.7 分段设计（MX-1..MX-6）

**MX-1 mangled 记录结构化编码（fresh_name 缺口化解——头号设计决策 D1）**：.krf 侧 instantiate 产物对被改名引入符号输出结构化记录 `("mangled" s e base_text counter)`（base_text 透传 template 原字符串值、counter 为 int——两者均在 VM 可表达域内，**零字符串构造**）；宿主 dump_krf 侧解码为 `format!("{base}__macro_{counter}")` 终名与 oracle 侧 Rust 真拼接名逐字节比对。renames 栈 = `((from_text . mangled_record) ...)` alist，active_rename 按 eq? 查找（**值等实证**：vm/value.rs:243 `(Value::Str(a), Value::Str(b)) => a == b`——非指针比较，expander.krf ex-assoc 1098 测试全绿先例）。**设计依据**：parity 考察**判定面**（哪些符号被改名、决策序、counter 分配序）而非拼接面——拼接是确定性纯函数（format!），留宿主解码侧 = 沿 1.5 float=Debug 文本先例（记录携带决策参数、渲染留宿主）；K33 唯一标识符生成的触发式变体在记录层保真。

**MX-2 双文件装配式承载（架构决策 D2）**：`selfhost/v1/macro.krf` 第三件 = 纯函数库（ex-macro-register/ex-macro-define/ex-macro-resolve/ex-macro-use/ex-macro-match/ex-macro-instantiate 函数族——宏注册表/匹配/实例化/mangled 编码，**零驱动式**）；expander.krf 的 define-syntax fail-closed 分支（:512-515）替换为 `(ex-macro-define ...)` 调用、使用点分派替换为 `(ex-macro-resolve ...)` + `(ex-macro-use ...)`（**装配期隐式契约**：未装配时运行到宏分支才报 unbound——expander.krf 自身源无 define-syntax 故单文件自举不动点测试不破坏）；宿主装配 = macro.krf body + expander.krf body 源面拼接（先例 = 1.5 forms_stream_prefix 前缀注入）。**架构镜像依据**：Rust 侧 transformer.rs 是 kerf-expander 的**模块**非独立 crate——.krf 侧 macro.krf 是 expander 程序的**函数族库**非独立程序（对偶镜像）；Rust 侧宏走查（instantiate 零预算）→ .krf 侧合成模式（matchx/instx 新合成节点——绕过 ex-depth，mapx 家族第四/五实例）。

**MX-3 Macro 层收缩（三层分流转二层 + 哨兵保留）**：`contains_define_syntax` 分流删除（宏案直入 Expander 层双引擎真跑）；pos-024/bnd-010 迁入 Expander 层（expander-parity.md §5 既有登记兑现）；`ExpanderParityLayer::Macro` 变体**保留作哨兵**——corpus sweep 断言 `macro_layer == 0`（fail-closed：任何未来回归到 Macro 层的案例被计数断言抓获——哨兵值有真实断言消费非死码，§12 最优>最小兼容）；audit s09b 翻转为双引擎断言。

**MX-4 错误轴扩展**：reconstruct_expand_error 新增 `"macro-mismatch"` 臂（name+span → MacroPatternMismatch）；static_form 映射扩 `"define-syntax"`；.krf 侧 err 通道增 `("err" "macro-mismatch" name s e)` 记录（11 → 12 kind）。

**MX-5 语料扩展（72→79——§9.48.5 详表）**：正 3（literal 非空表/两代链/卫生碰撞——rename-on-craft 行使 MX-1 mangled 面）+ 负 4（模式不匹配/重复模式变量/ellipsis 拒绝/module 域外用——GATE 6 宏面负向 ≥3 达成）。

**MX-6 fixpoint 门 B 落位（§9.48.6 详述）**：二阶段双口径（字节级 parity 定案 + 自应用幂等）。


### 9.48.5 语料扩展裁定（72→79）

| 新案 | 内容 | 行使面 |
|---|---|---|
| pos-031-literal-macro | `(define-syntax k-if (syntax-rules (then else) ((_ c then t else e) (if c t e))))` + 使用 | literal 非空表（K30 文本比对正路径） |
| pos-032-macro-two-generations | 宏 A 展开为宏 B 使用形，B 再展开为核心形式 | use_gen+1 世代链（1.7 首次语料行使） |
| pos-033-hygiene-binder-collision | template 含 `(let ((x ...)) ...)` 且实参带入 `x`（trigger 碰撞） | **rename-on-capture 首次语料行使**（x → x__macro_N + 引用跟改 + 使用点 x 不被捕获——MX-1 mangled 记录 parity 面；e2e 语义先例 = macro_seed_tests hygiene_wrap 101） |
| neg-050-pattern-mismatch | 使用形不匹配任何子句 | `MacroPatternMismatch` 错误轴（★3 死码臂激活） |
| neg-051-duplicate-pattern-vars | `((_ x x) ...)` | 注册期查重（malformed） |
| neg-052-ellipsis-rejected | `((_ a ...) ...)` | ellipsis fail-closed（K27 Stage 0 边界负路径） |
| neg-053-module-macro-outside | module 内 define-syntax + module 外使用 | 帧隔离宏域（unbound） |

分布共变：pos 28→31 / neg 34→38 / bnd 10 维持 = **79**；三层分流 Reader 6 / Macro 0（哨兵断言）/ Expander 73（6+73=79）。扩展义务合法性：subset-spec §3.3 扩展义务表「1.7 宏面 + fixpoint 门」登记位的行使。


### 9.48.6 fixpoint 门 B 落位（v1 二阶段双口径）

stage-1-plan 1.7 行出口 =「前端三段全 .krf + fixpoint 信号（门 B——§18.3）」。**v1 语境裁定**（v1 无 compiler.krf——三阶段 A→B→C 整链不可复制，登记为 Stage 2+ compiler 自举窗前置）：1.7 兑现**二阶段双口径**——

- **口径 (a) 字节级 parity 定案**：对同一源 S（宏语料 7 新案 + selfhost 装配源自应用），断言 `compile(expand_oracle(S)) == compile(expand_krf(S))` **字节码全等**（Bytecode: PartialEq 既有派生——kerf-compiler compile.rs:33 直接可比）。= subset-spec §4「字节码全等限 fixpoint 链（1.7+ 门 B）」预留判据的兑现——**把 1.6 的 dump 全等升格为字节码全等**（dump 文法同构 → 字节码同构的判定面收紧）。
- **口径 (b) 自应用幂等不动点**：装配程序（macro.krf + expander.krf 源面拼接）消费**自身装配源**产出 item 树 dump，再次展开仍逐字节同 dump（幂等性——1.6 双面不动点的三段版延展：错误面裸源 unbound `forms` 同 span 锚沿 1.6 先例）。

**门 B 信号位**：Stage 1.7 出口验收 = 双口径全绿即「fixpoint 信号」达成（供 stage-1-plan 1.7 行 ✅ 判定 + 1.8 门审全集复跑消费）。



---

## 9.49 后端管道前沿对照与门审/校准/深验准备设计（v9.15——第四十七轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.49 勘察基线与节引言


> **本节性质**：Stage 1.8 末轮预备的设计依据供给轮（B 型前沿审查——用户阻断性指令「未解决审查问题禁止推进」先行执行）。审查对象 = **后端管道四域**（compiler/vm/runtime/driver——§9.46 Reader、§9.47 Expander、§9.48 宏面覆盖前端三段后，后端侧为唯一未做逐函数深审的管道域）+ **symbol/intern 触发器复查**（用户点名「Symbol 当下还是 string, intern 驻留机制？」）+ **门审/校准/深验方法论前沿**（1.8 主体工作面的理论对照）。勘察基线 v0.20.0（六命令冷跑 1128:0:0 + audit 180/180 复验态；主 Agent 直接勘察——Explore 子代理委派超时改主 Agent 路径，披露沿单 Agent 模拟先例）。


### 9.49.2 管道 v0.20.0 增量对账（vs §9.44.3 十二行表）

- 1.7 增量（v0.19.0→v0.20.0）：kerf-driver expander_parity.rs 宏面扩展（+MACRO_SOURCE 装配契约 + gate_b_bytecode 重建器 + krf_name mangled 解码 + macro-mismatch 错误臂）——十二行表 driver 行增量；selfhost/v1/macro.krf 第三件 = 自举面非管道成员（1.5 裁定沿袭）；transformer.rs 零触碰冻结态维持（§9.48.2 基线）。
- **后端四行（compiler/vm/runtime/dispatch）自 v0.15.0 以来连续五个版本零漂移**（本轮勘察复核：compile.rs 953 行 / vm.rs 1114 / eval.rs 1110 / gc.rs 363 / verify.rs 421 / opcode.rs 277——与 §9.44 勘察基线一致）——**冻结态稳定基线**：为 1.8 门审全集复跑提供「复跑对象物理不变」前提；后端逐域审查表（§9.49.3）因此可作 1.9 深验七件套中 architecture-review/hidden-problems 两件的直接输入。
- 十二行表其余行零漂移零新债（span/syntax/core/symbol/reader/typecheck/expander 行实态 = §9.46-9.48 各节登记终态）。


### 9.49.3 后端侧逐域审查表（勘察 v0.20.0 实态——§9.46/9.47/9.48 逐函数审查表的第四段）

**compiler 域**（compile.rs + opcode.rs + verify.rs + bytecode.rs + error.rs，~2.3k 行）：

| 审查项 | 实态 | 结论 |
|--------|------|------|
| compile()/compile_program() 两入口 | direct-style + jump backpatching；ConstKey 位模式键（NaN 折叠单槽 + ±0.0 位保留——"dedup 是优化非语义合并"注释在案） | 对齐（§19.3 蓝图） |
| emit() 单发射路径 | pops/pushes 单源表驱动 + fail-closed StackUnderflow；自动 debug_info + last_span 线程 | 对齐（两道防线第一道） |
| patch() 深度断言 | jump_sources HashMap 记录 + StackImbalance 相等断言 | 对齐 |
| cur_stack LIFO | 恢复精确 caller（0.6 修复先例注释在案——cur -= 1 损坏多闭包程序） | 对齐（历史缺陷制度化） |
| lookup_local 逆序线性扫 | O(嵌套深度)/Var 节点 | §9.44.3 第 5 行 Stage 2 词法寻址窗维持（★5——零信号不开窗） |
| tail-If 契约 | 分支直落终结符无合并跳转；Handle 体非尾（handler pop before return——Stage 2 效应消除登记） | 对齐（§19.3 trap 1） |
| Require/DefineSyntax 零代码 | 编译期簿记（0.9 Require 先例延伸） | 对齐 |
| 错误轴 13 变体 | DepthExceeded/UnpatchedJump/StackUnderflow/StackImbalance/ConstIndexOutOfRange/GlobalIndexOutOfRange/LocalSlotOutOfRange/ProtoIndexOutOfRange/JumpTargetOutOfRange/DebugInfoMissing/MissingTerminator/HaltOutsideEntry 等——全带 span（DebugInfoMissing 以 func/pc 定位） | 对齐（§8.7 结构化） |

**vm 域**（vm.rs + frame.rs + value.rs + builtin.rs + roots.rs + error.rs + io.rs，~2.5k 行）：

| 审查项 | 实态 | 结论 |
|--------|------|------|
| dispatch 单循环 24 臂 | §9.44.3 第 7 行对齐维持（LLC 跳转表通识；B1 median 9.2-9.4µs 带内——热点信号未点亮） | 对齐 |
| Halt 两态 | 栈空→Nil / 栈顶值（compile 侧 depth-0/depth-1 契约镜像） | 对齐 |
| JumpIfFalse 严格 Bool | 非 Bool → type_mismatch（VM 布尔严格性——1.6 ex-declare 实证同源） | 对齐 |
| invoke 闭包/内建双臂 | arity 检查 → push_frame（**帧 = 分配共享预算**——"递归与堆共享预算，循环形程序有界"设计在案）/ builtin 原地执行 | 对齐 |
| reserve 预算语义 | live_usage（frames + heap live cells）vs budget → collect-then-retry（0.7 裁定八）→ 无 collector fail-closed（0.6） | 对齐（历史裁定制度化） |
| Perform 最近 handler | rposition + handler 留存至 pop-handler（安装期求值 + 调用即动态函数——裁定六最小执行语义） | 对齐 |
| Closure env 休眠快照 | locals.clone() 全量（Stage 0 零读取——§9.44.3 第 10 行 basic-closure 登记） | 对齐（Stage 2 激活窗登记） |
| **裸索引族**（LoadLocal/StoreLocal/LoadGlobal/StoreGlobal 无越界检查） | verify 前置不变量（LocalSlotOutOfRange/GlobalIndexOutOfRange = verify 检查项——第二道防线职责） | **设计在案维持**（★4——§14.6.1.1 数据流覆盖正面例证：有前置防御链非静默） |
| span_at 逐指令 expect | debug_info 平行性 verify 保证（不变量链） | 对齐（★3 同族——R1 判定非桩） |
| Frame::new args>locals resize 防御分支 | "caller-contract violation" 注释（编译器保证 params ≤ n_locals）——**零行使防御码** | 登记不改（★2——防御深度正面例证） |

**runtime 域**（eval.rs + gc.rs + parity.rs，~1.6k 行）：

| 审查项 | 实态 | 结论 |
|--------|------|------|
| Evaluator | 求值器闭包体 = 全库唯一 Rc（§9.44.3 第 10 行维持） | 对齐 |
| MarkSweep + Roots | apply/perform temp 保护契约（0.7 P1 修复 + §20.6 同族全量制度化） | 对齐 |
| builtin 单源分派 | 18 内建封闭集（裁定十——VM call_builtin 与 eval 共享 builtin_ops 零漂移由构造） | 对齐 |
| Builtin::from_name | 名字面解析 18 封闭集（展开期/REPL 一次性） | 冻结面维持（★6） |

**driver 域**（pipeline.rs + parity 族 + cli/repl/render/diagnostic，~5.9k 行——本轮仅审管线接线与 parity 面）：

| 审查项 | 实态 | 结论 |
|--------|------|------|
| 管线相位序 | read → expand → load → {typecheck → check → run(Compile/Eval 双引擎)} | 对齐（1.1 接线） |
| pipeline.typecheck() | = check_module（保守静态 R1-R8 + Externals 双源） | 对齐 |
| **★1 HM 接线缺口** | **infer_module/TypedProgram（1.3 HM 层）未接入 driver 管线**——消费面仅 crate 内部 + 测试 + audit（勘察实证：grep infer_module 消费者 = lib.rs/infer.rs/hm_inference_seed_tests.rs/audit_r1.rs 四处，driver 零消费）；plan-1.3 明文登记"driver HM 级接线登记为 1.8 议程（门审全集复跑时评估——1.1 接线先例的同款后续）" | **本轮裁定：实施（GATE-2）**——1.9 出阶段评审时 HM 层若仍为 driver 不可达的孤岛能力 = §7.3 门审"集成正确性不仅是各子阶段内部正确性"的直接违例；前沿依据 K37（soft typing 诊断面接入先例） |

**★ 风险清单终裁**：★1 HM 接线 → 本轮实施（GATE-2，§9.49.5）；★2/★3/★4/★6 → 登记维持（设计在案防御深度/不变量辩护/verify 前置链/冻结面——零修改义务）；★5 → §9.44.3 第 5 行 Stage 2 窗维持。**零新 TD**（全部为登记态或本轮清偿项——TD 登记册沿袭口径）。


### 9.49.4 Symbol/intern 触发器复查（用户点名项——§9.44.3 第 1 行 + §9.44.5 第 1 窗的实态复查）

**现状**：Symbol = kerf-core newtype String（无驻留表——§9.43.3 行修正沿袭："标识符驻留不存在"）。热查找点普查（v0.20.0 勘察实证）：

| 查找点 | 数据结构 | 频率类 | 评估 |
|--------|---------|--------|------|
| compile lookup_local | Vec<(Symbol,u32)> 逆序线性扫 | 每 Var 节点 × O(嵌套深度)，编译期一次性 | 带内（79 案语料 + selfhost 三件编译毫秒级） |
| compile intern_global | HashMap<String,u32>（首见整串 hash） | 每全局名首见，编译期一次性 | 带内 |
| compile ConstKey::Str | clone 整串作键 | 每字面量常量，编译期一次性 | 带内 |
| expander ctx.bind | assoc 线性查找（1.6 已审——§9.47.3 绑定纪律） | 每展开节点 | 带内（1.6 审查结论沿袭） |
| 宏 rename alist | eq? 值等查找（1.7 MX-1——vm/value.rs:243） | 每实例化 | 带内（1.7 审查结论沿袭） |
| **VM 运行期全局访问** | **LoadGlobal u32 索引——零字符串比较**（globals 表编译期建成；Builtin 经枚举非名字） | 每指令级热路径 | **已索引化** |
| eval 求值器 env | Rust 直接解释路径的 Rc 环境（与 VM 分立） | 每求值节点 | 带内（双引擎 parity 面非生产热路径） |

**触发器现值**（§9.44.5 第 1 行三选一）：①LSP 窗——未开（Stage 2+ §9.3.2 登记）；②B 系列热点——dispatch 面未进前三（B1 median 9.2-9.4µs 连续八轮带内零漂移）；③自举自编译负载——.krf 三件为纯编译对象非自编译器（compiler 自举 = 三阶段 fixpoint Stage 2+ 窗——§9.48.6 登记）。

**裁定**：**三触发器零信号——intern 驻留维持登记态不开窗**（§9.44.5 第 1 行维持；原则 32 不预测 + §9.8 判据先于先例）。用户点名复查闭环：运行期热路径已全索引化零字符串比较；字符串成本集中于编译期一次性面，当前语料规模完全带内——**驻留机制引入的收益边界 = LSP 增量查询或自编译负载点亮之后**（登记触发器即为此设）。


### 9.49.5 BS-C 1.8 分段设计（GATE-1..GATE-4——末轮预备四件套）

- **GATE-1 门审全集复跑**（audit U 节 10 case，180→190）：构成 = U1 HM 接线 E2E（GATE-2 交付的集成验证——E0009 Error 级阻断渲染 + E0011 Warning 级放行）+ **上轮修复边界 case ≥5**（§7.3.2——1.7 探针五轮实录的边界族：四头记录文法读出 / 世代线程 gen 字段透传 / mangled 宿主解码 roundtrip / 装配契约 MACRO_SOURCE 拼接序 / Macro 哨兵零路由）+ 跨子阶段集成（1.0-1.7 全链：源码→read→expand→typecheck→compile→VM→值 + 双引擎 parity 断言）+ 七类错误覆盖维持断言。A-T 十九节全绿复跑 = "全集复跑"语义（§7.3.1 规则 4 审计集递增 + K38 全量回归语义）。
- **GATE-2 HM 接线**（★1 清偿——driver HM 级诊断面激活）：pipeline 扩展 = check() 内 R1-R8 之后接 infer_module（同批诊断收集——多错误收集不短路[1.0 架构属性]沿袭）+ TypeDiagnostic→Diagnostic 映射（1.1 Severity 映射先例第四例）+ Error 级（E0009/E0010 确定错误）阻断 / Warning 级（E0011 预算披露）放行 + REPL/CLI 面经既有渲染链自动可达。**零新 crate 零新 Cargo 边**（driver→typecheck 既有边激活——§18 零新边）+ 零新原语零语法（HM 层既有能力接线，非新面）。测试三层：内联（映射/阻断语义）+ 根集成（E2E 源码可达 E0009-E0011 经 driver 渲染 + 良构程序零告警健全性对偶）+ audit U1。
- **GATE-2 实施实录（1.8 落地时增补——§8.4.5 文档-代码同步）**：接线即暴露 1.3 层假阳性——装配源（1.4k 行合法程序，双引擎 parity 验证）被 E0009 拒绝（"expected `nil`, found `(pair (pair dyn dyn) nil)`"——ex-cpat 递归调用点的异构 tagged-tuple 形状冲突）。根因链：if-cond `unify(Bool, cond)` 是**唯一** Body 敏感绑定源（数值/car/not/write-line 域检查对未解 Var 全放行），其余元变量绑定全来自调用点（Call 来源）——unify_args 不区分来源导致 Call-Call 冲突被误报为确定错误。修复 = **release-and-demand**：unify_args 失败默认 mark/rollback 放行（异构 tag-dispatch 合法动态代码——假阳性消除）；例外 = bool 需求表（Machine 登记外层 Fn 参数元变量，leave_if_cond 绑定前检测，callee_define_index 命中 define + 参数位 ∈ 需求集 + expected Bool + 实参具体非 Bool → 报 E0009——fp3_call 传播语义保持）；occurs（E0010）保留报。弃选：泛化 provenance 追踪（schema 封装时血缘丢失）与 bool-only 启发式（cons 内 bool 字段 Call-Call 冲突仍误报）。已知保守局限登记：匿名 fn/let 别名的 bool 需求传播放行（fp3 锚——fail-closed on uncertainty）。FP3 硬化五锚 + audit U1c（装配源零 Error）为防回归锚。
- **GATE-3 校准统计**（§6.6.1 Stage 1 面回填）：calibration-data.md §2 校准结论补 1.4-1.7 四行实测验证（worklog 权威数据回填——1.4 契约面轮[期望零猜测纪律执行实证] / 1.5 结构层自举轮[源拼写/编码层修正族] / 1.6 展开层自举轮[机械生成器切换战术] / 1.7 宏面自举轮[探针五轮 VM 侧 sexp dump 直击]——实现侧运行语义缺陷连续零的十二轮链）+ **Stage 1 阶段汇总行**（1.0-1.7 八子阶段轮次带内收敛 + TD 归零连续十二轮 + 比例偏差申报制度实证）+ 校准结论（1.9 终态行预留——出阶段评审后补终值）。
- **GATE-4 深验七件套准备**（§14.6.6 输出文档集合的 Stage 1 骨架——1.9 执行评审终稿）：docs/develop/v1/stage-1/ 新增七文档框架（architecture-review.md[含 §9.49.3 后端审查表预填 + 评分表骨架] / design-impl-test-coverage.md[三列对照表框架——subset-spec 六表 × 实现位 × 测试位] / hidden-problems-assessment.md[问题表 + 复杂度增长评估 + Stage 2 就绪度清单] / refactoring-optimality-review.md[重构评分表 + 数据结构评分表] / performance-baseline.md[B1-B5 现值 + 1.9 复测义务] / final-assessment.md[GO/NO-GO 框架 + §21.5 九信号清单] + docs/tests/pipeline-test-coverage.md 完整性小节扩展[§14.6.1.1 数据流覆盖——后端裸索引族 verify 前置链为正面例证预填]）——每文档含 1.9 终稿义务表（谁/何时/验收线），防七件套沦为骨架不填。



---

## 9.50 检查器域前沿对照与出阶段就绪度设计（v9.16——第四十八轮 B 型审查）（移档自 docs/stage0.md——2026-10-02 分层整理；逐字保留零改写）

#### §9.50 勘察基线与节引言


> **本节性质**：Stage 1.9 末轮的设计依据供给轮（B 型前沿审查——用户阻断性指令每轮先行义务）。审查对象 = **typecheck 检查器域**（保守规则 R1-R8——管道五段审查谱系的第五段：§9.46 Reader / §9.47 Expander / §9.48 宏面 / §9.49 后端四域之后，唯一未做逐规则专审的管道域；HM 推断层已审于 §9.44.4 + §9.49 GATE-2）+ **冻结层收口重审**（span/syntax/core——Stage 0 交付后零漂移终验）+ **出阶段就绪度方法论**（1.9 主体工作 D1-D8/七件套/九信号的前沿对照）。勘察基线 v0.21.0（六命令冷跑 1135:0:0 + audit 190/190 复验态）。


### 9.50.2 管道 v0.21.0 增量对账（vs §9.44.3 十二行表）

- 1.8 增量（v0.20.0→v0.21.0）：typecheck 行两项——infer.rs release-and-demand 硬化（unify_args 回滚放行 + bool 需求表 + callee_define_index——§9.49 GATE-2 实施实录）+ driver 行 pipeline.rs 双层同批接线（check_module + infer_module 一批收集）。十二行表其余行零漂移。
- **冻结层收口重审**（本节 §9.50.4）：span/syntax/core 三层自 1.2（git f13852c——PBT 轮最后一次触碰，实为测试侧接入非层本体变更；层本体自 Stage 0 收口 0.11 后零变更）——2771 行三 crate 稳定终态，§9.44.3 第 2/3/6 行维持。


### 9.50.3 检查器域逐规则审查表（勘察 v0.21.0 实态——管道五段审查谱系第五段）

**规则族**（check.rs 1066 行 + code.rs 191 + env.rs 123——保守 = 确定性错误才报，每规则健全性论证在案）：

| 规则 | 内容 | E 码 / 级别 | 健全性论证（为何确定错误） | 审查结论 |
|------|------|------------|--------------------------|----------|
| **R1** | unbound 引用 | E0001 / Error | 解析序镜像编译器（locals → intern_global 同序——check.rs 模块文档）；位置感知可见性（顶层立即位 = define-so-far + letrec 预绑定；Fn 体 = 全模块可见——调用时晚于模块加载）；未解析全局加载 = 双引擎确定 `UnboundGlobal` | 对齐（双镜像纪律在案；1.6 展开器面勘察已互证 neg-018/019 require 符号名死于 MalformedForm 的先序事实） |
| **R2** | 元数不匹配 | E0002 / Error | callee 三源分析：R2a IIFE（闭包即位 100% 确定）/ define-Fn 形状 / R2c 内建已知元数；**assign 守卫**（过近似：任意赋值可能重绑 → skip）；VM `invoke` 闭包/内建两臂均强制元数 | 对齐（assign 守卫 = 过近似放行方向——保守纪律正确侧；与 HM 层 assigned 守卫泛化[§9.44.4 设计点 2]同族镜像） |
| **R3** | 非布尔 if 条件 | E0003 / Error | **字面量条件才报**（形状确定）；truthy 仅接受 bool = 双引擎 `JumpIfFalse` 严格 bool（VM 布尔严格性——1.6 实证同源） | 对齐（非字面量条件放行——HM 层 E0009 接管该面：双层级联 = 字面量死 R3 / 元变量绑定死 E0009——1.8 共变实证） |
| **R4** | 非可调用 callee | E0004 / Error | 字面量 define 形状 = 永不可调用（`call callee` 确定类型不匹配） | 对齐（1.8 HM 层 `expected a function` 新臂为泛化同族——两层同批共存实证） |
| **R5** | handler 元数不匹配 | E0005 / Error | **仅顶层立即 perform**（Fn 体内 perform 可被动态 handler 接住——词法路由不健全）；VM 以 perform 实参调用 handler（invoke 元数检查） | 对齐（编译序镜像：handler 值先于自身 clause 安装求值——外层栈走查在案） |
| **R6** | 顶层未处理 perform | E0006 / Error | 模块加载期无动态上下文存在——词法 handle 是唯一可能路由器 → 无路由 = 确定 `UnhandledEffect` | 对齐（in_fn 守卫在案——动态语义健全性边界正确） |
| **R7** | 非可调用 handler | E0007 / Error | 字面量 handler 确定不可调用（R4 同族；报告位 = clause.span 非调用点） | 对齐 |
| **R8** | 赋值目标意外 | E0008 / **Warning** | 两种形态皆合法语义（重绑内建 / 隐式建全局）——**report-over-silence 的非阻断层**；仅确定错误可 Error 级（保守宪章） | 对齐（Warning 级别裁定 = 设计宪法的级别分级落实——与 E0011 预算披露同族） |
| E0005' | 多错误收集 | （架构属性） | 不短路 = 收集面是架构属性非 E 码槽位（裁定二十一） | 对齐（driver 批次 + 语料 neg-037 + U10 锚） |
| **Externals** | 外部名面 | —— | 三值解析（Some(Some(n)) 已知元数 / Some(None) 存在未知 / None 非外部）；**单源纪律**：不复制 STAGE0_GLOBALS——三消费位从权威源构造（expander 表 + Builtin::ALL） | 对齐（§11 接口隔离；1.1 双源单源纪律沿袭） |

**风险清单**：零 ★（九规则 + 外部面全对齐——保守纪律、双镜像、级别分级、动态健全性边界四轴全过；本域为五段审查中唯一零发现段，与 TD 归零十四轮互相印证）。


### 9.50.4 冻结层收口重审（span/syntax/core——Stage 0 交付态终验）

- **span**（§9.44.3 第 8 行维持）：16B Copy 四元组 + LineIndex 渲染期派生——Stage 1 全程零触碰（TD-001 于 0.8 清偿后无回归）。
- **syntax**（第 3 行维持）：SyntaxObject + ScopeSet 有序去重 + StxSymbol 相位孪生——宏面 1.7 世代线程经 ExpansionId 消费未改层本体。
- **core**（第 6 行维持）：CoreExpr/ModuleItem/LiteralValue 冻结面——1.4 subset-spec 六表以其为轴心冻结；HM TypedExpr = Layer 2 加性标注未触碰 Layer 1。
- git 勘证：三 crate 最后触碰 = f13852c（1.2 PBT 测试侧接入）——**层本体自 0.11 Stage 0 收口后零变更**，冻结承诺全程兑现。


### 9.50.5 出阶段就绪度框架（1.9 主体的方法论对照）

1. **九信号（SOP §21.5）× 内部权威**：语义稳定（全树 1135 + 语料 79 全实证）/ 自举验证（门 B 双口径 + K40 行业共识形态对齐）/ 测试覆盖（§9.5 近 100% + 分布论证 v15.1）/ 性能基线（B1-B5 十四轮带内）/ 文档同步（§8.5 清单 + 本节谱系）/ 能力处理程度（§21.9 演进矩阵核对——1.9 终稿义务）/ 技术债清零（P0/P1 = 0，开放项 0）/ 外循环投票（5.5/5.5）/ 阶段间深验（§14.6 四项 = 七件套终稿承载）。
2. **D1-D8 ↔ 七件套映射**：D1/D5 → architecture-review 终稿（§9.49.3 + 本节预填）；D2 → hidden-problems（窗口清单 + 复杂度增长评级）；D3/D8 → design-impl-test-coverage + pipeline-test-coverage §8；D4 → hidden-problems 就绪度清单；D6 → performance-baseline（B1-B5 复跑）；D7 → final-assessment 文档清单；§14.7 C1-C6 → final-assessment 跨阶段章节（v12.5 裁定承载位）。
3. **K41 对照落点**：kerf 静态层共存纪律（双层级联 + Error/Warning 分级）在 1.9 终稿的 hidden-problems 中登记为 Stage 2 演进输入（HM 层深化与 R 规则族收敛的路线分叉保留——零机制变更义务）。

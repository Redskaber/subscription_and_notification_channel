# Stage 1 Architecture Review (§14.6.1.2 — FINAL, delivered at 1.9)

> Status: **FINAL** (1.9). Sources: stage0.md §9.44-§9.50 (the
> six-segment review lineage: data structures / subset freeze /
> reader / expander / macro / backend four domains / checker
> domain) — this file is the scoring consolidation, not a re-survey
> (principle 46: single-source reference, no duplication).

## Per-stage scores (FINAL — v0.22.0 tree)

| Stage | Score | Evidence anchor |
|-------|-------|-----------------|
| span | ✅ | frozen since 0.11 (git-audited); LineIndex render-time derivation (TD-001 cleared 0.8) |
| syntax | ✅ | frozen; ScopeSet deterministic ordering (§9.44.3 row 9) |
| core | ✅ | frozen; subset-spec six tables anchored on its constructors |
| reader | ✅ | §9.46 survey + .krf segment 1 parity (116 lines) |
| expander | ✅ | §9.47 survey (16-form table, 7 span traps) + .krf segment 2 (741 lines) |
| macro | ✅ | §9.48 survey (16-fn table) + .krf segment 3 (558 lines) + gate B dual-axis |
| typecheck | ✅ | §9.44.4 (HM base) + §9.50.3 (R1-R8 — the only zero-finding segment) + 1.8 hardening |
| compiler | ✅ | §9.49.3 (two defense lines, tail-If contract, 13 error variants) |
| vm | ✅ | §9.49.3 (24-arm dispatch, budget sharing, collect-then-retry, frozen ext block) |
| runtime | ✅ | §9.49.3 (single Rc invariant, MarkSweep, 18-builtin single source) |
| driver | ✅ | §9.49.3 + 1.8 two-layer wiring; parity harness three segments |

## Extension-cost estimate (§14.6.1.2 item 5 — FINAL)

| Addition | Cost | Where |
|----------|------|-------|
| New token | lexer match arm + reader test (single file) | kerf-reader |
| New AST node | CoreExpr variant + expander arm + checker arm + compile arm + eval arm (five mirrors, all covered by the parity/audit families) | kerf-core → five consumers |
| New opcode | Opcode variant + pops/pushes table row (single source — verify picks it up) | kerf-compiler |
| New builtin | Builtin variant + arity table + body fn (VM/eval share by construction) | kerf-vm |

The AST-node cost is the highest (five mirrors) and is the designed
conservatism of the frozen-subset approach — Stage 2 extensions
route through the same five-mirror discipline (the expander parity
harness makes drift a test failure, not a review finding).

## Pre-filled: backend four domains (v0.20.0 survey verdicts)

| Domain | Verdict | Evidence (stage0.md §9.49.3) |
|--------|---------|------------------------------|
| kerf-compiler | ✅ aligned | direct-style + backpatching; ConstKey bit-pattern keys; cur_stack LIFO (0.6 fix institutionalized); tail-If contract; two defense lines; 13 error variants all spanned |
| kerf-vm | ✅ aligned | 24-arm dispatch (LLC jump-table parity); frame-sharing budget ("recursion shares the budget with the heap"); collect-then-retry; strict-Bool JumpIfFalse; frozen three-slot ext block |
| kerf-runtime | ✅ aligned | single `Rc` invariant held; MarkSweep + roots contract (0.7 §20.6 institutionalized); 18-builtin single-source dispatch |
| kerf-driver pipeline | ✅ aligned after 1.8 | HM wiring closed the ★1 gap (plan-1.3 agenda); parity harness three-segment + gate B dual-axis |

## Registered non-blocking notes (zero-modification findings)

- ★2 Frame::new args>locals resize branch — unreachable defensive code, commented (defense-in-depth positive)
- ★3 VM invoke panic! with invariant justification (R1: not a stub)
- ★4 bare-index family (LoadLocal/StoreLocal/LoadGlobal/StoreGlobal) — verify precondition chain (second defense line owns bounds)
- ★5 lookup_local O(scope-depth) linear scan — Stage 2 lexical-addressing window (§9.44.3 row 5, zero signal)
- ★6 Builtin::from_name 18-closed-set — frozen face

# plan-1.5 — Stage 1.5 执行计划与实录（Reader .krf 重写第一段：结构层）

> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.5 + docs/stage0.md §9.46（设计依据层——RS-1..RS-5）+ docs/sop.md §4/§5/§7
> 交付版本：v0.18.0 · git（6.4 规范 commit）

## 1. 任务构成

| MUV | 内容 | 落位（§8.4.6 两级语义） |
|-----|------|--------------------------|
| 1.5-a | **selfhost/v1/reader.krf**——冻结子集（18 内建 + 8 特殊形式零越界）书写的结构层 Reader：迭代式显式栈（帧 = `(depth open-start items-rev)` 内层在前）+ 四错误类结构化值 + atom 记录直通 | 新根目录 `selfhost/`（跨 crate 全局面——自举面登记，切换窗步②首切口物理锚位） |
| 1.5-b | **kerf-driver reader_parity.rs**——RS-1 源注入表格契约（`(define tokens (quote (…)))` 前缀 + 类型化字面量[float 例外=Debug 文本]）+ RS-3 双轴归一化（oracle/krf 同构 dump）+ RS-2 错误重建（ReadError 同一 Display）+ RS-4 双引擎承载（句柄保活堆行走）+ 分层报告 | crates/kerf-driver 内（L8 管线属主）；kerf-reader 公共面补 `FileId`/`ByteOffset` re-export（既有签名类型可名化——零新 Cargo 边） |
| 1.5-c | 测试三层 + audit R 节 + ds08 共变 | 根 tests/（跨 crate 断言）+ examples/audit R 节（150→160）+ 快照 ds08 版本黄金 0.17.0→0.18.0（共变义务第六例） |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo fmt --check | 零 diff |
| cargo build | 0 error / 0 warning |
| cargo check --all-targets | 0 / 0 |
| cargo clippy --all-targets -- -D warnings | 0 |
| cargo test --release | **1069:0:0**（1046 基线零回归 + 净 +23：内联单测 7 + 根集成 16——函数计数口径；audit R 节 10 案在 example 二进制内独立可重跑不入 cargo test 计数） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 160/160**（A-R 十七节） |

环境参数：`ulimit -s 131072` + `RUST_MIN_STACK=33554432`（Task 19-b 登记的交付态一致口径；深表测试另加测试侧 `deep_stack` 显式栈线程——见 §5 边界）。

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

- **净 +23** = 内联 7（reader_parity.rs：编码往返/表格形状/分流/树轴/错误轴/多 form/篡改——正 4 / 负族 3）+ 根集成 16（正向 7 + 负向/边界 9——其中语料全扫为单函数 68 案内联、深度族三态单函数）。
- 正负构成：函数计数 11 正 / 12 负与混合（内联 4 正 3 负 + 集成 7 正 9 负与边界混合）——**正负比 ≈ 1:1.1（结构层域函数口径；用例口径：负向形态 13 错误位 + 6 词法变体 + 3 深度态 + 2 篡改锚 vs 正向形态 6 树族 + 68 语料重放）**；语料全扫 68（pos 26 / neg 32 / bnd 10 = 1:1.23 语料域）双域合并 1:1.4 ≥ 1:3 全树口径由语料负向族维持（§9.45.5 既有论证沿袭——本域新增负向以判定分支覆盖为驱动非凑数）。
- 跨阶段消费 ≥1 ✓：语料 68 重放（FP7）+ READER_SOURCE 自举不动点（FP8）+ ds08 快照共变。
- audit R 节 10（150→160 单调增长 ✓）；七类错误覆盖 7/7 维持（reader parity = 既有 kerf-read 族的 .krf 侧镜像非新错误类）。

## 4. 关键决策与共变披露

1. **Float 载荷 = Debug 文本字符串**（设计走查发现——§9.46.4 RS-1 实施修正）：`inf`/`NaN` 无 .krf 字面量形态 → 全部 float 以文本承载宿主 parse 回收（Display/parse 互逆精确）。文档 §9.46.4 段内已注记。
2. **迭代式主循环选型实证**：eval `depth` 仅闭包应用臂计数（勘察实证）→ 512 token = 512 调用深度 ≪ 2048 预算——RS-2 选型论证被代码事实支持；bnd-006 类 1.3k token 深表在 debug 构建触及**原生**栈（树走器 Rust 递归）→ 测试侧 `deep_stack` 显式栈线程（环境面处理非 evaluator 缺陷——与 Task 19-b 同族登记）。
3. **kerf-reader 公共面补全**：`pub use kerf_span::{ByteOffset, FileId}`——两类型本就是 `lex`/`read_program` 签名类型，re-export = 可名化补全（零新 Cargo 边零新面；§18 审查：内部边零新增）。
4. **B3 口径修正落地**（§9.46.3 注记）：「28 函数/正 87/负 307」= 上游档案未来时态目标；本轮实际 parity 范围 = 结构层四错误类 + 全树（十变体中六变体 = 词法层第二段窗口域）。
5. **共变清单**：ds08 版本黄金（第六例——注释链 0.17→0.18）+ Cargo.toml 版本位（workspace + 10 成员）+ audit 尾部统计行（150→160）。
6. **回填申报**：测试文档 reader-parity.md 按 §9.2 应先行，实际实现后回填（时间序偏差登记；内容序等价）。

## 5. 边界与登记

- **词法层第二段窗**（§9.46.5 触发器登记维持）：字符串原语子集扩展裁定（K21 最小集）为前置；f64 面 = 宿主透传永久候选（K20）。
- **输入带指令窗**：subset-spec §3.3「可带输入带」义务重登记为第二段评估位——源注入契约（RS-1）是冻结子集下唯一类型化数据通道（输入带路线裁定不采——字符串不透明使行协议不可拆解）。
- **CLI face**：reader parity 无 CLI 子命令（lib + 测试面先行；segment 2 议程登记）。
- **evaluator 原生栈**：debug 构建深表需求由测试侧声明；如未来生产面出现同类需求 → evaluator 栈预算议程（登记态，零信号不开窗）。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

| 角色 | 票 | 附注 |
|------|-----|------|
| ARCH-A | 2/2 | 自举面切口选型（K18 hex0 层位）+ 分段边界（结构层/词法层）架构一致 |
| DEV-A | 1.5/1.5 | 迭代式显式栈实现可维护；勘定 3 处括号/编码拼写缺陷全内循环清偿 |
| QA-A | 1/1 | 漂移探测器双锚自检 + 语料全扫 68/68 + 深度边界三态 |
| ALG-C | 1/1 | 四错误类语义镜像逐字节实证（左到右降序优先/最内层/进入计数） |
| SKL-A |（不计权）| PASS（deep_stack 显式栈线程 = 环境面正解） |
| **加权** | **5.5/5.5 = 100% ≥ 95%** | |

## 7. 版本与下一入口

- v0.18.0（git commit 按 §6.4：`feat(stage1.5): reader parity — .krf structure layer lands`）。
- 下一入口 = **Stage 1.6 Expander .krf 重写（第二段）**：展开循环 + 脱糖 + 卫生机制——展开器 parity + 快照冻结扩展（stage-1-plan §2 行 1.6；TD-032 五切口第二切口）。

## 8. 打包（§19——22-e 轮回填）

- tar --exclude=target/.git → `/home/z/my-project/download/kerf-stage1.5-v0.18.0-reader-parity-seed-r1.tar.gz`
- **341 entries / 1,709,218 B / sha256 9bb77dd2a9923d86d37241f933d5955eb343aa52556f876613028f0e05003ef6**
- 解包回归验证：diff -r --exclude=target/.git 归零 ✓ + 关键文件在场核验（selfhost/v1/reader.krf + reader_parity.rs + plan-1.5.md + stage0.md §9.46 ×9 引用）
- download/README.md 基准表更新（v0.18.0 = 最新基准；v0.17.0 转历史存档）

# Stage 1.1 子阶段计划与交付实录——driver 接线（typecheck 级入管线 + 诊断渲染映射 + Warning 接线）

> **Status**: Delivered 2026-09-28（v0.14.0）
> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.1（权威定义）+ docs/sop.md §3.2/§7.3/§6.3/§8.4.5/§8.4.6/§9.4.3 v15.1/§18/§19 + docs/tests/v1/stage1/driver-wiring.md（测试文档先行——双向印证）+ docs/stage0.md §8.7（四级 Severity 契约）

## 1. 任务构成

| MUV | 内容 | 依据 |
|-----|------|------|
| 18-a | kerf-driver 接线实施：DiagnosticCode::Typecheck(TypeCode) 数据携带变体 + from_typecheck 映射 + ParsedProgram::typecheck + check/run/run_parity 前置检查阶段（Error 中止 / Warning 附着）+ Outcome 警告通道 + 渲染警告摘要行 + CLI 三命令警告路径 + REPL 增量警告 + 测试三层 + audit N 节 + 文档族 + v0.14.0 + commit | stage-1-plan §2 行 1.1 |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| `cargo fmt --all -- --check` | ✅ 零 diff |
| `cargo build --release` | ✅ 0 error / 0 warning（11 crates + bin kerf + 双 example） |
| `cargo check --all-targets` | ✅ 0/0 |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 告警 |
| `cargo test --release` | ✅ **881 passed / 0 failed**（846 基线零回归 + 净 +35：内联 25 + 根集成 10；轮 17:18 = 1:1.06 对偶均衡——分布论证见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 130/130**（A-N 十四节——审计集 120→130 单调增长；七类 7/7 维持；exit 0） |
| R8 编码面扫描（新增/修改文件） | ✅ 零非英文命中（既有 render.rs CJK 测试夹具 = 0.8 登记白名单零触碰） |

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

净增 35 = 正向 17 + 负向 18（1:1.06——三族护栏对偶均衡）。**分布论证**（driver-wiring.md §3 预申报 + 实测印证）：接线轮的三对偶义务——「非阻断」（警告程序照常执行/值通道不动/退出码 0）↔「中止」（确定错误执行前中止/副作用零发生）+ 渲染回归面（零警告批次字节不变 = ds10 冻结义务 + 纯警告批次摘要门控）+ REPL 增量语义（不重印/不丢印）。误报侧 P0 风险由非阻断族承载，漏报侧价值归零风险由中止族承载——两侧均不可凑数削减（§12）。

**GATE 6 构成**：根集成 10 = 正向 5（≥1 ✓）/ 负向 5（≥3 ✓）/ 跨阶段消费 ✓（L4.5→L8 新消费边 + 真实源码文本 → read → expand → typecheck → compile → VM/eval 全链 + 渲染字符串断言）。七类错误 ≥6 类负向覆盖维持（7/7——检查器 = 静态前置层非新错误类）。

## 4. 关键决策与共变披露

- **中止语义裁定**（实施即设计）：检查器 Error 级发现在**执行前中止**（确定错误程序不运行——静态检查的净新增值；两引擎本会在运行期同位失败，静态面更早更省）；Warning 级**永不阻断**（合法但可疑——§2.3-4 警告级）；收集不短路（typecheck 全量 + compile 诊断追加同批）。
- **渲染汇合**：`DiagnosticCode::Typecheck(TypeCode)` 数据携带变体——tag() 返回 E0xxx 注册码，渲染形 `error[E0002]:`（rustc 风格 E 码）；stage-1-plan §4 的「两方案在接线处汇合」兑现。
- **警告摘要行**：多诊断批次警告计数 > 0 → `warning: N warning(s) emitted`（abort 行之前——rustc 惯例序）+ abort 行门控修正（errors ≥ 1 才打——纯警告批次不再打误导性 aborting 行）；**零警告批次字节不变**（ds10 黄金零回归实证）。
- **REPL 增量警告**：警告渲染按行拆分后沿 outputs 同款前缀规则增量（会话重放全程序重跑，同警告不重印）；警告提交**进入**累积程序（合法——回滚仅错误）。
- **基线共变 5 处**（行为变更披露——检查器前置使已知元数错误静态化）：pipeline.rs / driver_seed_tests / audit I04 的运行期 arity 面测试改 checker-opaque 形态（`((fn (g) (g 1 2)) car)` 参数中介——R2 护栏正确跳过，运行期面覆盖保留）+ snapshot ds03 黄金更新（E0002 静态形）+ ds08 版本黄金（0.14.0 共变义务第二例）。
- **设计级验证发现 1 项**（§20.6 披露非缺陷）：REPL 语境下 `(set! car 1)` 重绑使后续 `(car 1 2)` 的 R2 正确跳过（assign 护栏跨提交生效——累积程序含 set! 即触发护栏；保守纪律的跨提交实证，测试语料改用未重绑的 `cons`）。

## 5. 边界与登记

- CLI 无独立 typecheck-only 子命令（`check` 已含 typecheck 阶段——警告 + 计数一体；独立面无需求信号，不预测原则）
- R2 全局被调者的非 Fn 非 Literal Define 形态（Other——运行时形状未知）= 保守跳过（1.0 登记 1.1+ 复核——维持，无新证据）
- 重复 Define（同名再定义——当前合法静默覆盖）= 登记未来 R 候选（维持）
- REPL 警告增量含摘要行（多警告批次的 `warning: N warnings emitted` 随增量出现——确定性前缀规则的机械结果，不特殊化）

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

加权 5.5/5.5 = 100% ≥ 95%（ARCH-A GO×2 / DEV-A GO×1.5 / QA-A GO×1 / ALG-C GO×1 / SKL-A GO 附注不计权）。§7.2 Q1-Q6 自检：Q1 零越界（reserved 零入边维持）/ Q2 新边 L4.5→L8 无环（typecheck 依赖 core+span，driver 消费——DAG 单向）/ Q3 依赖 = std-only 零外部 / Q4 跨层契约（E0xxx 在接线处汇合——§4 预言兑现 + Severity 两级映射四级契约）/ Q5 测试三层 + 审计 + 集成构成达标 / Q6 六命令实测非声称（§2 表）。

## 7. 版本与下一入口

workspace 0.13.0 → **0.14.0**（Stage 1.1 接线轮——x 位口径）。**下一入口：Stage 1.2 PBT 引入**（DEA-13 闭合：proptest 1.9 dev-dependency §18 依赖审查落地 + 6 类不变量首批[8 原语 eval / Reader 往返 / VM dispatch 三类先行] + 属性测试 ≥6）。

## 8. 打包（§19——18-c 轮回填）

（本节由 18-c 打包轮回填终值。）

# Stage 1 Design-Impl-Test Coverage (§14.6.1.3 — FINAL, delivered at 1.9)

> Status: **FINAL** (1.9). The gap lists close the pre-seeded map
> against the v0.22.0 tree (1145 tests + audit 200).

## Gap lists (FINAL)

**Design → implementation (B1, designed but unimplemented)** — all
are registered Stage 2+ windows, none is a Stage 1 obligation:
lexical addressing + capture activation / symbol interning /
generational GC / value packing / row polymorphism (TY-C) /
compiler three-stage fixpoint / LSP faces. Verdict: zero unmet
Stage 1 design obligations.

**Implementation → tests (implemented but untested)** — empty.
Every delivered face carries a family (the §8.5 checks each round;
DEFERRED 0 / UNTESTED 0 per §9.5 — the coverage discipline held
through all nine sub-stages).

**Tests → design (designed but untested)** — empty for the frozen
subset (six tables map 1:1 to the corpus/audit families below).

**Three-way inconsistencies** — zero standing; the six historical
co-variances (B3-fix count, float payload, expander forward-ref
wording, unify_args design, U-series batch expectations) were each
fixed the round they surfaced (§8.4.5 code-over-docs rule), and the
§14.8 deviation list (deep-review-round1.9.md §5) adjudicates the
full set.

## Pre-seeded coverage map (v0.21.0 state)

| Frozen face (subset-spec §3) | Impl | Tests |
|------------------------------|------|-------|
| Special forms (8) | expander.rs + expander.krf parity | corpus 79 replay + S/T audit + expander-parity 18 |
| Builtins (18) | builtin.rs single source + .krf consumers | builtin domain families (G/H audit) + FP3 |
| Literals (6) | reader + ConstKey pool | reader parity 16 + NaN/±0 dedup inline |
| Core constructors (9) | compile.rs nine arms | compile FP2/FP3 inline + verify |
| Module items (4) | expand.rs loader + flat compile | loader faces + module negatives |
| Declarations header (4) | expand.rs static forms | J section + corpus negatives |
| HM layer (1.3) | infer.rs (hardened 1.8: release-and-demand) | FP1-FP8 + FP3 hardening 5 + U1 |
| Driver wiring (1.1/1.8) | pipeline.rs both static layers | wiring 12 + N audit + U1/U9/U10 |

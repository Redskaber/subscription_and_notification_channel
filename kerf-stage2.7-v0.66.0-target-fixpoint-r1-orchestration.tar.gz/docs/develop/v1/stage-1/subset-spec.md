# kerf 子集规格——.krf 自举目标面（subset-spec.md）

> **Status**: Frozen（Stage 1.4 冻结轮落档——2026-09-29 · v0.17.0；§2.1 语义面捕获章节于 Stage 2.2 收口轮完整重写——2026-10-01 · v0.51.0，语义翻转沿 Stage 2.1 同刀 MUV 合法行使；§3.3 第二段裁定补记——2026-10-02 · v0.55.0，零冻结面变更——字节表注入路线）
> 依据：stage-1-plan.md §2 行 1.4 + docs/stage0.md §9.45.4（冻结面五表）+ §9.25.4（BS-C）
> 性质：**当前实现面的诚实登记**（代码事实单源直读）——零新原语、零新语法、零能力扩张（8 原语不变性第十八轮验证维持）。规格与实现冲突以代码为准 + 提交修正本文档（sop §8.4.5）。
> 消费者：Stage 1.5-1.7 前端三段 .krf 重写（Reader → Expander → 基础宏）+ 验收语料（tests/v1/stage1/corpus/）+ parity 契约面（kerf-driver/src/parity.rs）。

## 0. 一行定位

kerf 子集 = Stage 0-1 已实现语言面的冻结快照：`.krf` 文件承载 S-expr 皮肤（bootstrap-parser 脚手架——切换窗未开），语义锚定链 = 表面形式 → `CoreExpr` → 字节码 → eval 同构（双引擎 parity 即语义安全网）。

## 1. 冻结面

### 1.1 声明头（4）——模块顶层唯一合法形式

| 形式 | 文法 | 语义锚 |
|------|------|--------|
| `define` | `(define name value)` / `(define (f params...) body)` | `ModuleItem::Define`——值位立即求值；函数糖 = `Define{f, Fn{params, body}}` 近恒等映射（§7.3.5）；**letrec 预绑定**：自身名先绑（递归合法） |
| `require` | `(require name)` | `ModuleItem::Require`——声明图校验（0.9 装载层）；**零代码**（链接推迟装载期——单模块运行） |
| `module` | `(module name items...)` | `ModuleItem::Module`——嵌套声明；运行时**平坦求值**（名字入同一全局表——可见性合并 = 后续模块系统面） |
| `define-syntax` | `(define-syntax name spec)` | `ModuleItem::DefineSyntax`——声明位（transformer 注册于展开环境）；宏触发面 = 1.7 自举议程 |

其余头（含全部表达式特殊形式）在模块顶层 = `TopLevelExpression` 拒绝（展开期）。

### 1.2 表达式特殊形式（8）

| 形式 | 文法 | 语义锚（CoreExpr → 双引擎） |
|------|------|------------------------------|
| `fn` | `(fn (params...) body)`——单 body | `Fn`——闭包；**不捕获外层绑定**（见 §2.1） |
| `if` | `(if cond then else)`——三元严格 | `If`——短路；cond 必须 Bool（R3/E0003；非 Bool 字面量确定错误，运行时 truthy 仅 Bool） |
| `let` | `(let ((name val)...) body)`——或 `(let (name val) body)` | `Let`——**let\* 顺序语义**（前一绑定可见于后一绑定） |
| `do` | `(do expr...)` | 脱糖为 `Let` 链（顺序求值，值 = 末位） |
| `set!` | `(set! name val)` | `Assign`——目标必须已解析（展开期 Unbound 拒绝）；重绑内建 = E0008 Warning |
| `perform` | `(perform effect args...)` | `Perform`——效应执行；顶层即时位无 Handle 覆盖 = E0006 确定错误 |
| `handle` | `(handle body (effect handler)...)` | `Handle`——最近词法路由（Fn 边界截断）；handler 元数失配 = E0005/E0007 |
| `quote` | `(quote datum)` | `Literal`——数据面：Int/Float/Bool/String/nil/嵌套表（→ 嵌套 Pair）；**Symbol 不可 quote**（nil 除外） |

### 1.3 内建（18）——STAGE0_GLOBALS 单源（expander/lib.rs = vm/builtin.rs ALL 注册表互证）

| 域 | 名字（元数） | 语义备注 |
|----|--------------|----------|
| 算术比较（9） | `+`(2) `-`(2) `*(2)` `/`(2) `<`(2) `<=`(2) `>`(2) `>=`(2) `=`(2) | 数值域封闭；溢出 fail-closed（`ArithmeticOverflow`）；`/` 整除；`=` 数值等 |
| pair 与谓词（7） | `car`(1) `cdr`(1) `cons`(2) `pair?`(1) `nil?`(1) `eq?`(2) `not`(1) | `car/cdr` 非 pair = `type_mismatch` |
| 最小 I/O（2） | `read-line`(0) `write-line`(1) | **write-line 仅 Str 域**（int 实参 = `type_mismatch`——§8.8 最小集域约束） |

### 1.4 字面量（6）与原子

`Int`(i64，十进制) / `Float`(f64，十进制小数) / `Bool`(`#t`/`#f`) / `String`(`"..."` 转义已解码) / `Nil`（`nil` 字面量位） / `Pair`（quote 表脱糖产物）。符号 = 标识符（绑定位或引用位）。

### 1.5 核心构造子（9）与模块项（4）

`CoreExpr`：`Fn / Apply / If / Var / Literal / Assign / Let / Perform / Handle`——核心面即冻结面全集。`ModuleItem`：`Define / DefineSyntax / Require / Module`。

### 1.6 量化帽（实证值）

| 帽 | 值 | 依据 |
|----|-----|------|
| Reader 嵌套 | 256 层 | `NESTING_LIMIT`（257 层 = Reader 期拒绝） |
| 宏展开 | 512 | `EXPANSION_LIMIT`（自递归宏触顶 = 展开期拒绝） |
| HM 推断 | 512/define | `INFERENCE_DEPTH_LIMIT`（E0011 Warning——1.8 接线前面） |
| 整数域 | i64 全域 checked | 溢出 = 运行时 `ArithmeticOverflow`（双引擎一致） |

## 2. 冻结语义细则（实证裁定——语料锚定）

### 2.1 闭包词法捕获（完整语义面——Stage 2.1 语义同刀翻转 v0.50.0 · §2.2 收口轮 v0.51.0 完整重写）

内层 `fn` 引用外层 Fn 参数 / let 绑定 = **合法捕获**（扁平闭包——K43/K45/K51 + K189/K192 五锚背书）。完整语义面七条：

1. **捕获合法性与解析序（LA-1）**：编译器经 `ProtoState.parent` 定义者链解析自由名——own locals → 定义链（逐层外层 proto）→ global 三叉；命中外层绑定即落捕获描述符（first-use 序），命中 global 照旧 `load-global`；顶层 proto 无定义者（链终于 entry），顶层 `fn` 的自由名恒走 global——**顶层闭包永不捕获**。
2. **描述符两源（LA-2/K189）**：`FuncProto.captures: Vec<CaptureSource>`——`Local(s)` = 定义帧第 s 槽（Lua 5.4 `Upvaldesc {instack=1}` 同构）；`Captured(k)` = 定义闭包自身捕获区第 k 位（传递捕获——LA-4：中间闭包 pass-through 表，K45 最小捕获集判据：每描述符有消费证明{直接 `load-captured` ∨ 嵌套 pass-through}）。键于槽位/捕获索引，永不键于名文本（§9.52.5 Symbol 身份基座）。
3. **VM 执行语义（LA-3/K192）**：`closure` 指令按描述符表从当前帧选择性拷贝（**O(captured) 非 O(n_locals)**——dormant 全帧克隆已退役，★1'）+ 分配闭包单元；`invoke` 安装帧捕获区（`Frame.captured` 独立 Vec——冻结 3-ext 不动）；`load-captured k` 读取（操作码 24→25 授权扩展）；帧捕获区并入 §19.4 GC 根集（帧存活期）。`verify` 对每个 `closure` 位点检查描述符界（Local(s) < 定义者 n_locals ∧ Captured(k) < 定义者 captures.len()——越界 = `CaptureSourceOutOfRange` 加载期拒绝）。
4. **求值器镜像（LA-5）**：`Env.captured` 三级解析序 own→captured→globals；free-name 分析计数 `Assign` 目标入引用集（边界可判定）；`make_closure` 选择性拷贝 + GC 根三处扩展——"MIRRORS, never invents" 契约，双引擎 parity 为安全网。
5. **不可变捕获边界（LA-7）**：`set!` 目标为捕获绑定 = **确定错误 E0012**（检查器源路径检出——`cannot assign to captured variable` 单一措辞族 + 编译器/求值器直接构造面双层防御）。可变捕获（装箱单元 K44/K53 路线）= 后续窗登记，首刀子集不含。
6. **门 B 吸收（2.2 收口实证）**：`Bytecode` `PartialEq` 自然含 captures 字段——描述符漂移即字节码漂移（守卫双向钉扎：同表等 / 异表不等）；捕获密集复合（宏 + 两级传递捕获 + 尾 if）过 `gate_b_bytecode` 全管线（oracle 编译产物 vs .krf 重建产物字节码全等）。
7. **★1' 双成本化解实证（2.2 收口）**：成本轴 = 守卫（五十槽定义帧捕获一值 → env 恰一槽——结构证）+ B6 基准（帧宽 4→100 槽逐创建成本 47.8→47.7ns 持平；captured 1→25 线性 ~7.3ns/捕获）；保留轴 = 守卫（八 pair 局部捕获一值 → 显式 GC 周期 swept 恰 7——dormant 快照将全保留 swept 0）。

语料锚：pos-034（基础捕获——§9.51.2 预登记锚 neg-045 的翻转形态 value 8）+ pos-035（密集/遮蔽 value 23）+ pos-036（传递捕获 value 60）+ neg-057（E0012 首案）。

> **历史语义（Stage 0-1 冻结态——2026-09-29 至 2026-10-01）**：内层 `fn` 引用外层绑定 = 确定错误（E0001，neg-045 锚；双引擎一致拒绝——dormant capture 不参与解析）。Stage 2.1 语义同刀 MUV（§9.81）翻转本条；更早的语料构成叙述中「闭包不捕获」字样均按本注记回读为历史态。本节完整重写于 Stage 2.2 收口轮（§9.82——v0.51.0），此前先行翻转态见 git 历史。

### 2.2 顺序绑定（define-so-far）

顶层 define 按序展开绑定：**前向引用**（引用后置 define）= 展开期 `UnboundIdentifier` 拒绝（neg-046 锚）；自身名 letrec 预绑定（递归合法——pos-009 锚）；互递归源路径不可达（展开期拒绝）。stage-1-plan §3 R1 行「Fn 体内看全部 Defines」= 检查器对**直接构造面**的视角（宏合成/程序化 API），源路径以展开器为准。

### 2.3 顶层即时位效应

`define` 值位的 `perform`（模块装载期立即执行）无词法 Handle 覆盖 = E0006 确定错误（neg-035 锚）；有覆盖按最近词法路由（pos-021/022 锚）。

### 2.4 程序终值与值约定

define-only 模块程序终值恒 `nil`（双引擎同构）；**语料值约定 = 末位顶层 define 的停机值**（REPL `$repl:N` 同通道——parity 契约面 globals_repr 末位读取）。纯 module 体（零顶层 define）= 语料面明确漂移。

### 2.5 空表与空应用

`()` 在 **Reader 期**拒绝（`empty application`——§7.1.1 class 3；neg-021 锚）——非展开期。

## 3. 验收语料（68 条——tests/v1/stage1/corpus/）

### 3.1 指令文法（首行，封闭）

```
;; expect: value <repr>            — 双引擎停机，末位 define = <repr>
;; expect: parse-error             — Reader 拒绝（kerf-read）
;; expect: expand-error            — 展开器/装载器拒绝（kerf-expand）
;; expect: type-error <code>+      — 检查器错误级码集（序不敏感精确集）
;; expect: runtime-error           — 检查器过 + 双引擎一致运行时拒绝
;; expect: warning <code>+ value <repr> — 仅警告级码集 + 停机值
```

`<repr>` = `parity_repr` 结构形态：整数十进制 / 浮点 `Debug` 形（`3.0` 非丢零）/ `true`/`false` / `"带引号串"` / `nil` / `(a . b)` 右嵌 pair / `#<closure>` / `#<builtin:name>`。

### 3.2 分布（§9.45.5 底线 + 实态）

| 类 | 数 | 覆盖 |
|----|-----|------|
| pos-（34） | ≥20 ✓ | 算术/比较/布尔/函数糖/闭包工厂/递归 fib/let 链/遮蔽/do/set!/字符串/quote 两形/cons 链/car-cdr/谓词族/not/高阶 map/perform-handle 两形/write-line/宏 my-if/module 平坦求值/nil 字面量/E0008 警告位 + **捕获族三件（2.1 翻转后：基础捕获 value 8 + 密集/遮蔽 23 + 传递捕获 60——v0.50.0）** |
| neg-（41） | ≥20 ✓ | Reader 4（未闭合/游离闭/未终结串/坏 # 记号）+ 展开/装载 13（顶层表达式/malformed 四形/未绑定/quote 符号/set 未绑/模块环/缺模块/重复模块/空应用/**前向引用**/write-line int 域——闭包不捕获位随 2.1 翻转移出）+ 检查器 9（E0002-E0008 + 多错误收集 E0002+E0003 + **E0012 assign-to-captured——v0.50.0**）+ 运行时 6（除零/car 非 pair/加法溢出/参数位元数失配/加 bool/write-line int）+ 溢出字面量双件（neg-054/055）+ multiset 双码件（neg-056）+ 宏面四件（neg-050..053） |
| bnd-（10） | ≥10 ✓ | i64 max/min 存活 + min-1 溢出拒 + 浮点两形态（0.1/3.0）+ 嵌套帽双侧（255 过/257 拒）+ fib 25 深递归 + iota 50 长链 + 宏展开帽 512 |

**每条期望经真实管线实证**（探针轮 68/68 固化——零猜测期望纪律；修正实录见 plan-1.4.md §4）。

### 3.3 扩展义务（§9.45.7）

每子阶段交付语料增量：1.5 双 Reader parity 语料（~~可带输入带~~ **1.5 实施裁定[2026-09-29]**：输入带路线不采——冻结子集字符串不透明使任何行协议不可拆解，源注入表格契约为唯一类型化数据通道[§9.46.4 RS-1]；本义务重登记为词法层第二段评估位）；1.6 展开器 parity；1.7 宏面 + fixpoint 门；1.8 HM 接线后 E0009-E0011 语料位解锁。

**1.5 交付态注记**：双 Reader parity 已以「既有 68 语料全扫重放 + RS 族内联域」达成（非新增语料文件——语料从程序合法性判定面升格为 Reader 输入面；分布与口径见 docs/tests/v1/stage1/reader-parity.md）。

**1.5 第二段交付态注记（v0.55.0 · §9.86 LX-1）**：词法层经**字节表注入**路线交付——`(define source-bytes (quote (104 101 ...)))` 为 RS-1 通道的载荷推广（逐字节整数表），`lexer.krf` 以纯整数运算承载全部词法决策，**零冻结面变更**（8 原语不变性第五十一轮验证维持）；上方「输入带路线裁定不采」的旧结论维持有效（其针对 read-line 行协议——字符串不透明使行文本不可拆解；字节表不经 read-line，且空源以 `(quote nil)` 注入规避裸 `()` 读错误）。K20 永久宿主层两件如实登记：f64 值面（parse + is_infinite 溢出拒绝——子集无可变精度算术）与串载荷解码（无串构造内建）。K21 字符串原语窗**关闭**（前置已不需要——字节表路线绕开字符串检视）；f64 宿主透传维持（K20 永久候选升格为已裁定的永久宿主层）。

**1.6 交付态注记（2026-09-29）**：1.6 展开器 parity 以「语料扩展 4 案 + 既有 68 全扫重放」达成——语料 **68 → 72**（pos-029 字符串 require + 比较内建三连 + 未调用 read-line / pos-030 嵌套 module 声明 / neg-048 字符串名 module 环 / neg-049 require 缺失模块——后两案使 ModuleCycle/ModuleNotFound 自语料可达[符号名 require 死于 MalformedForm 的 §9.47.3 ★7 勘察实证]）；三层分流 = Reader 6 / Macro 2（pos-024 + bnd-010 经 oracle 定案——SyntaxRules = 1.7 窗） / Expander 64；分布与口径见 docs/tests/v1/stage1/expander-parity.md。

**1.7 交付态注记（2026-09-29）**：1.7 宏面 parity 以「语料扩展 7 案 + 既有 72 全扫重放」达成——语料 **72 → 79**（pos-031 literal 非空表 / pos-032 两代宏链[use_gen+1 首次语料行使] / pos-033 卫生 binder 碰撞[rename-on-capture 首次语料行使——MX-1 mangled 记录 parity 面] / neg-050 模式不匹配[MacroPatternMismatch 语料可达化] / neg-051 重复模式变量 / neg-052 ellipsis 拒绝 / neg-053 module 域宏外用）；三层分流**收缩**为 Reader 6 / **Macro 0（哨兵零路由——1.6 的 oracle 定案位拆除，宏案直入装配程序双引擎真跑）** / Expander 73；fixpoint 门 B 落位（(a) 字节码全等 + (b) 装配源自应用）；分布与口径见 docs/tests/v1/stage1/macro-parity.md。

**2.1 交付态注记（Stage 2 语义同刀——2026-10-01，v0.50.0）**：语料 **82 → 85**（pos-034 基础捕获 = §9.51.2 预登记锚 neg-045 的翻转重命名[期望 E0001 → value 8] + pos-035 密集捕获/参数遮蔽[value 23] + pos-036 传递捕获[value 60] + neg-057 assign-to-captured[E0012 首案]）；expander 层计数 74 → 77；gate B 轴 (a) 资格面扩展（oracle compile 成功件——编译期拒绝件无字节码产物，拒绝面归语料 harness）；操作码计数共变：**24 → 25**（load-captured——K192 分离操作码族裁定授权；§8.12 分组 variable access 增捕获访问类）。**2.2 收口注记（2026-10-01，v0.51.0）**：§2.1 语义面捕获章节完整重写落地（七条完整语义面 + ★1' 双成本化解实证注入——§9.82）；门 B 双口径全管线复跑含 captures 字段实证（捕获密集复合锚 + 描述符漂移双向守卫）；audit W 节 10 case 挂载（捕获激活族端到端——210/210）。
**2.3 第二 Pass 交付态注记（Stage 2.3 指令发射域——r83，v0.53.0）**：语料 **85 维持零增量**（CP 码轴对既有语料全量重放——产品族扩至四：funcs 结构/globals/consts/**code（逐 proto 完整指令流——操作码 25 kebab 名 + 操作数 + 补簿解析后跳转目标）+ dbg（稠密逐指令跨度表，偏移对面）**；proto 乘积七字段同文法双侧逐字节；span 比较面 = 偏移对——parity 族既定约定，展开 id 归 1.6/1.7 面）；compiler.krf 758→1221 行（第二 Pass：emit 单径 + 操作码栈效应表 + 跳转占位-回填[a 哨兵 + b 源深度 + patch 双恢复] + else 入口深度重置 + 尾位终结符契约 + 终化排空 + estate 簿记）+ 发射防御族可读漂移化（stack-underflow/stack-imbalance/unpatched-jump 经 oracle Display 重建 + bad-patch/bad-node harness 缺陷类）+ 第五次自应用（compiler.krf 编译自身展开树——码轴全 proto 逐字节双引擎）+ audit Y 节 10 case（220→230/230 A-Y）+ 守卫 +13[CP8 发射轴族] → **1316:0:0**（§9.84；K198-K203 六新锚；§3.3 操作码面 = 25 名消费面注记——发射域零语言面变更）。

**2.3 收口关闭注记（Stage 2.3 收口评估——r84，v0.54.0）**：**2.3 关闭**（收口条件三面全过——§9.85）：CP 段全量对账（compile.rs 33 函数 → compiler.krf 83 defines 函数级映射 100% + 文法十三形/七合成模式 + 25 操作码栈效应表逐臂对齐——零缺口零降级零过度特化）+ 组成链 CP9 清偿（2.4 公式 `compile(expand_oracle(S)) == compile_krf(expand_krf(S))` 一条链直证：`.krf` expander 重建树[ModuleItem: PartialEq 链内断言] → `.krf` 编译器消费该树 → oracle 全管线对拍；**第六次自应用首次经全 .krf 链** + 58 案编译器层 sweep + 前端篡改探针；audit Z 节 236/236 A-Z + 守卫 +5 → 1321:0:0）。子集面零变更（组成链 = 消费面组合验证——零新原语零通道零 VM 变更零语法增量；8 原语不变性第五十八轮验证）；语料 85 维持零增量。

**2.4 首刀交付态注记（Stage 2.4 fixpoint B 开窗——2026-10-02，v0.56.0）**：语料 **85 维持零增量**（全组成链消费既有语料全量重放——漂移分类账把三层路由 8/19/58 从 CP1 的「过滤面」升格为「全路由清账」：每文件恰落一行、行内误差轴双引擎对拍、下游 junction 空转 = 路由自身形状；计数由测试钉扎，语料增长移动行归属时计数必须随动）；junction 前馈新增两条宿主注记——`forms`/`items` 空表以 `(quote nil)` 注入（空积行：空源/纯注释源 oracle 读为 Ok([]) 合法编译为空积——`(quote ())` 是读错误 §2.5 沿袭）；第七次自应用 = lexer.krf 自源经完整 .krf 链（尾部四输出全局剥离——`source-bytes` 在载荷位无定义）；门 B 升格见证（dump 文法对 Bytecode 九探针忠实像）登记为 2.5 前置（§9.87）。

**2.3 第一 Pass 交付态注记（Stage 2.3 fixpoint 窗开启——2026-10-01，v0.52.0）**：语料 **85 维持零增量**（CP 段消费既有语料全量重放——85 案 sweep 钉扎三层路由 reader 8 / expander 19 / compiler 58：reader 层与 1.5/1.6 分割逐位一致，expander 层 = 展开或 loader 拒绝族，compiler 58 案含检查器负案族——typecheck 层永不决断 CP 案例，分析产品在检查器拒绝的树上良定义，neg-057 E0012 孪生的编译侧拒绝即 LA-7 防御层）；第四 selfhost 件 selfhost/v1/compiler.krf 744 行（词法域分析纯函数面）+ 第四 parity 前端 compiler_parity.rs（CP-1..CP-7——items 注入词汇表/产品轴 parity 键/错误轴重建/三层路由/eval 输入包络 VM-only 面）+ audit X 节 10 case（210→220/220）+ 守卫 +17 → **1303:0:0**（§9.83；K193-K197 五新锚）。

**1.8 交付态注记（HM 接线语料共变）**：driver 面接入 HM 层后（stage-1-plan 1.8 / §9.49.5 GATE-2），五案负向期望双层化——neg-031（非布尔条件）与 neg-037（多错误收集）增补 E0009；neg-041（car 非二元组）/ neg-044（数值异参）/ neg-047（write-line 整数）由 runtime-error 迁至 type-error E0009（检查器先拒——soft typing 的确定错误语义前移，1.1 "both layers report" 先例；期望全部探针实测重冻结）。正负分布不变（79 案构成零变化，仅期望语义更新）。

## 4. parity 契约面（BS-C 的 1.4 切片）

`kerf-driver::parity`：`CorpusCase::from_source`（首行指令解析）→ `validate`（parse → checker → 双引擎）→ `EquivalenceReport{observed, matched, drift}`；`validate_all` 批次面。判定分层（BS-C 沿袭）：同语法链 = 值等价（`parity_repr` 全等 + outputs + globals 三面 agree）；字节码全等限 fixpoint 链（1.7+ 门 B）；跨语法 = CoreExpr 全等 + 运行结果等价（1.5+ 切换窗）。**不做清单**（§9.45.6）：不预建 Reader 抽象、不做字节码全等、不做性能基准。

## 5. 冻结纪律

- 后续子阶段任何表面变更（1.5-1.7 切口）= 本规格同步 + 语料增量 + 契约面回归（1046:0:0 基线）。
- 8 原语不变性维持（零新原语零通道零 VM 零语法）；VM 永久 Rust 基座（宪制排除项）；切换窗未开（S-expr 皮肤 = 脚手架维持——原则 41 生命周期）。

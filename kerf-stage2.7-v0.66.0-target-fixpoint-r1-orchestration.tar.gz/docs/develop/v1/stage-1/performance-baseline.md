# Stage 1 Performance Baseline (§14.6.4 — FINAL, delivered at 1.9)

> Status: **FINAL** (1.9). The suite re-ran on the v0.22.0 tree —
> every median in band (the Stage 1 exit record; the table below
> IS the 1.9 measurement, not a carry-forward).

## Stage 1 exit measurement (1.9 re-run, v0.22.0 tree)

| Bench | Metric | 1.9 measured | vs 0.11 baseline | Band |
|-------|--------|--------------|------------------|------|
| B1 compile-fib | median | **9.4µs** | 9.3µs (0.11) | ±25% ✓ |
| B2 vm-run-fib25 | median | **97.45ms** | 96.7ms | ±25% ✓ |
| B3 eval-run-fib20 | median | **9.4ms** | 9.4ms | ±25% ✓ |
| B4 gc-pressure-churn | median | **0.372ms** (1 cycle/iter, swept 1023) | 0.36ms | ±25% ✓ |
| B5 driver-e2e-fib25 | median | **97.0ms** | 97.6ms | ±25% ✓ |

Hotspot re-registration: no top-3 change — the §9.44.5 trigger
table stands (all windows remain zero-signal).

## Attestation chain

B1 median trajectory across Stage 1: 9.3µs (0.11 exit) → 9.2-9.4µs
(fourteen in-band rounds) → **9.4µs (1.9 exit)** — the whole stage
stayed within ±2% of its entry point. The 1.8 GATE-2 wiring
(`infer_module` in every driver typecheck) is included in these
numbers and cost nothing measurable on the engine path.

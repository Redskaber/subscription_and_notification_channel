# Stage 1.3 子阶段计划与交付实录——HM 推断基座（迭代 W + SCC 分治 + 效应行收集面 + 类型标注 IR）

> **Status**: Delivered（1.3 执行轮落档——2026-09-29）
> 依据：stage-1-plan.md §2 行 1.3 + docs/stage0.md §9.44.4（HM 基座选型——第四十二轮设计锚）+ §9.30 REC-A A6（迭代 + 512 预算谱系）+ docs/sop.md §9.2/§9.4.3 v15.1
> 前置：1.2 基线（v0.15.0 · 890:0:0 · audit 130/130）

## 1. 任务构成

- **kerf-typecheck 新双模块**：`types.rs`（Type 九构造子 Int/Float/Bool/Str/Nil/Pair/Arrow/Dyn/Var + TypeSchema + EffectRow 有序去重行 + substitute 迭代重建机）+ `infer.rs`（推断引擎 + 机器 + 驱动）——零新 crate 零新边（§18：kerf-span+kerf-core 两条既有边维持，零新外部依赖）。
- **迭代 Algorithm W（A6 谱系）**：显式任务栈树走（Enter/Leave 相位机）+ 迭代合一（pair 工作表）+ 迭代 occurs + 迭代深 resolve（两槽后序重建机）+ 迭代终遍历（标注就地 resolve）——**全循环零深 Rust 递归**（bootstrap 友好——后续 .krf 重写跑在平坦栈 VM 上）。
- **union-find 元变量 + undo log**：`Links{slots, undo, mark/rollback}`——回滚为**健全性必需**非精度项（设计演进披露见 §4 决策 1）。
- **SCC 分治**（决策 2）：语法调用图（过近似）+ 迭代 Tarjan（依赖先行）——同 SCC 内预绑定 unify-through（互递归结），跨 SCC 经泛化 schema 实例化（同模块多态复用解耦）。
- **保守纪律四件**：If 分支 join（非合一）→ Dyn 单向未知顶；assigned 守卫泛化（值限制类似物）；18 内建 ad-hoc 数值域调用点判定（零类型类）；效应行收集面（Perform 追加 / Handle 差集 + handler 过近似并集 / 调用不吸收 callee 行——行多态 = Stage 2+ TY-C 窗）。
- **诊断注册面扩展**：E0009 TypeMismatch（Error）/ E0010 RecursiveType（Error）/ E0011 InferenceBudgetExceeded（**Warning**——预算耗尽 = 检查器局限披露非程序错误；深而合法的程序必须可运行）。
- **预算（A6）**：`INFERENCE_DEPTH_LIMIT = 512` 子树深度/define——超限单 Warning + 该 define 整体排除出 TypedProgram（零半标注树）。
- **类型标注 IR（Layer 2）**：TypedExpr 九变体镜像 CoreExpr（节点级 ty + effects）+ TypedDefine{schema, body, effects} + TypedProgram——终遍历深 resolve 后存储。

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo build --release | 0 error / 0 warning |
| cargo check --all-targets | 0 / 0 |
| cargo fmt --check | 零 diff |
| cargo clippy --all-targets -- -D warnings | 0 告警 |
| cargo test --release | **953:0:0**（890 基线零回归 + 净 +63：crate 22[types 9 + infer 13] + 根集成 41） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 140/140**（A-N 维持 + P 节 10 新增） |

**GATE 1 编码面扫描**：新增源面（types.rs / infer.rs / code.rs 增量 / hm_inference_seed_tests.rs / audit P 节）零非英文命中（R8——消息形态小写开头、无句尾句号、载荷反引号、镜像 RuntimeError 单源字典族）。

**性能基线 B1-B5 对账**（stage-1-plan 1.3 行验收点）：B1 compile-fib median 9.3µs / B2 97.195ms / B3 9.421ms / B4 0.369ms / B5 97.182ms——与 0.11 基线同量级（median 回归口径 >25% = 回归——**零回归**；推断层不在编译路径 = 预期零影响，实测确认）。

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

| 层 | 文件 | 数量 | 说明 |
|----|------|------|------|
| 内联单元 | types.rs | 9 | 显示形态（ground 镜像 kind_name 单源）+ 出现序走查 + schema α 重命名 + substitute 重映射 + 行代数（并/差/确定性） |
| 内联单元 | infer.rs | 13 | links 绑定/回滚 + 合一表（concrete 对/双向 var 绑定/**Dyn 吸收不约束**/arrow 结构）+ occurs 拒环 + 深resolve 链 + 字面量类型（含 64 层链尾折叠）+ join + 泛化首见序 + 实例化新鲜性 + is_numeric 三值 |
| 根集成 | hm_inference_seed_tests.rs | 41 | FP1 正例 6 + FP2 多态 3 + FP3 确定错误 8 + FP4 occurs 2 + FP5 预算 3 + FP6 合法永不告警 6 + FP7 效应行 4 + FP8/IS 快照 7 + 跨层协作 2 |
| 审计 | examples/audit P 节 | 10 | E0009/E0010/E0011/多态/守卫/行差集/ad-hoc/Dyn 传播/多错误/双跑确定性——全 E2E |

分布论证（hm-inference.md §2）：合一失败路径（确定错误必报 × 合法程序永不告警**等权对偶**）密度最高；泛化/实例化中密度（过泛化与欠泛化都是误报源）；预算边界（512 内静默 / 512 外单 Warning 永不 Error）；效应行收集面三操作各一负向；快照确定性新 dump 面回归锚。

口径申报（hm-inference.md §2 六项）：行收集不含 callee 行传递（Stage 2+ 窗）｜E0011 挂 define 级零半标注｜与 R1-R8 并行独立收集不短路｜消息镜像单源字典族｜ad-hoc 零类型类（18 内建封闭集）｜字面量 pair 链 64 层外尾折叠 Dyn。

## 4. 关键决策与共变披露

1. **undo log 为健全性必需**（设计演进披露——stage0.md §9.44.4 原稿「无回滚」**修正**）：If 分支内绑定若外泄，另一分支运行动态合法的程序会被事后误报（`(if d (if m 1 2) 0) (+ m 1)` 反例——分支位绑定 m:=bool 外泄 → `(+ m 1)` 假阳性）。回滚精确落在分支边界：cond 绑定保留（求值序在先——健全）；Handle 无需隔离（handler 值与体皆无条件求值——compile.rs 序）；Fn 体即参数化契约本身（绑定持久入 arrow——调用点合一健全性由「求值即错误」论证承载）。修正已回写 stage0.md §9.44.4（以实施为准——§8.4.5 先例）。
2. **SCC 分治**（设计演进披露——原稿「跨 define 预绑定」单层设计有假阳性缺陷）：预绑定直连会使同模块 `(id 1)`+`(id #t)` 被第一用单态化（第二用 E0009 假阳性——设计走查抓获）。修复 = 语法调用图 + 迭代 Tarjan 依赖先行：同 SCC 预绑定 unify-through（互递归 ML letrec 同构）；跨 SCC 实例化泛化 schema（每次引用新鲜解耦）。共变无（纯增量）。
3. **Tarjan 依赖先行序**：i→j 边使 j 的 SCC 先产出——引用只可能指向更早 SCC 或同 SCC（拓扑保证 schema 就位）。
4. **展开器面披露（探针实录）**：源路径 define-so-far 严格——Fn 体内前向引用与 define 级互递归被展开器拒绝（UnboundIdentifier）；SCC 机制与 R1 结构层同服务**直接构造面**（宏合成/程序化 API——checker 文档同款披露）。fp2/fp6 互递归与前向引用用例走直接构造。
5. **基线共变 1 处**：ds08 版本黄金 0.15.0→0.16.0（共变义务**第四例**——注释链 0.15→0.16）。无运行时行为共变（推断层不在编译/执行路径——B1-B5 实测确认）。
6. **Externals::empty 转 const**（env.rs 公共面微扩）：测试 static 上下文需要——零行为变更。

## 5. 边界与登记

- **行收集面边界**：调用不吸收被调函数体效应行（行多态/每函数效应签名 = Stage 2+ TY-C 流形求解器窗——stage0.md §9.44.4 第 4 点）。
- **driver 接线未做**（排期忠实）：stage-1-plan 1.3 行验收点 = 推断器 + unify/occurs + 快照扩展 + B1 对账——driver HM 级接线登记为 **1.8 议程**（门审全集复跑时评估——1.1 接线先例的同款后续）。
- **互递归源路径不可达**：展开器 define-so-far 严格（§4 决策 4 披露）——语言面演进属切换窗/模块面议程，非本层义务。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1 = **5.5/5.5**（SKL-A 会签：设计走查抓获两处健全性缺陷[分支外泄 + 预绑定单态化]并于实施前修复——深审价值的直接实证）。§7.2 Q1-Q6：Q1 零越界（kerf-typecheck 模块内增量——检查器层非内核非管线）✓ Q2 零新边 ✓ Q3 零新依赖 ✓ Q4 效应行 = 收集面（§9.24 TY-A 理论层的生产路径子集——理论层维持登记态）✓ Q5 构成达标（GATE 6：根集成 41 = 正 22/负 14/跨层 5——正负由健全性对偶承载）✓ Q6 实测非声称 ✓。

## 7. 版本与下一入口

- Cargo.toml workspace **0.16.0**；git commit 见 worklog 第四十二轮条目。
- 下一入口 = **Stage 1.4 kerf 子集冻结**（.krf 自举目标面：目标语言子集语法/语义规格 + 自举子集验收语料集 ≥50 + parity 骨架——SyntaxTransitionValidator 登记态）。

## 8. 打包（§19——20-f 轮回填）

（本节由打包轮回填：tar.gz 路径 + entries/字节数/sha256 + 解包回归验证。）

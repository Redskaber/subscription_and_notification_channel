# Stage 1.2 子阶段计划与交付实录——PBT 引入（DEA-13 闭合：proptest 属性层 + 三类不变量首批）

> **Status**: Delivered 2026-09-29（v0.15.0）
> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.2（权威定义）+ §5（PBT §18 裁定：DEFER-WITH-TRIGGER → 1.2）+ docs/sop.md §3.2/§5/§7.2/§6.3/§8.4.6/§9.2/§9.4.3 v15.1/§12/§18/§19 + docs/tests/v1/stage1/pbt.md（测试文档先行——双向印证）+ docs/stage0.md §9.34.5（MRES-E-1 六类不变量清单 + MRES-E-2 依赖候选）

## 1. 任务构成

| MUV | 内容 | 依据 |
|-----|------|------|
| 19-a | 基准替换：文件仓库最新种子 kerf-stage1.1-v0.14.0-driver-wiring-seed-r1.tar.gz（sha256 复验 + 解包 diff）替换沙箱丢失的 /home/z/kerf + worklog 替换（487 行项目层唯一事实源）+ sop.md v15.1 / stage0.md v9.9 与仓库最新 commit 逐字一致核验 + Rust 工具链重建（stable 1.98.1 + rustfmt + clippy） | 用户指令①（获取最新 + 替换）+ §3.1 |
| 19-b | 基准复验：六命令冷跑 881:0:0 + audit 130/130（环境注记：深树测试与 audit 需 ulimit -s 131072 + RUST_MIN_STACK=33554432——沙箱 8MB 默认栈不足，环境差异非代码缺陷，与 v0.14.0 交付态一致） | §3.2 |
| 19-c | PBT 实施：proptest dev-dependency（仅根测试层）+ 七属性（三类不变量：FP1-FP7）+ 生成器域自检 2 + 测试文档先行（pbt.md）+ runner.rs 挂载 + 内循环 4 轮 + 文档族 + v0.15.0 | stage-1-plan §2 行 1.2 + §5 |
| 19-d | web 仪表盘同步（沙箱侧）+ §19 打包 + worklog 双镜像 | 用户指令⑤⑥ |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| `cargo fmt --all -- --check` | ✅ 零 diff |
| `cargo build --release` | ✅ 0 error / 0 warning（11 crates + bin kerf + 双 example） |
| `cargo check --all-targets` | ✅ 0/0 |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 告警（含 proptest 消费面） |
| `cargo test --release` | ✅ **890 passed / 0 failed**（881 基线零回归 + 净 +9：7 属性 + 2 域自检——PBT 用例量 64 case × 7 属性 = 448 生成程序按 cargo test 函数计数为 7；§5 实测回填见 pbt.md） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 130/130 维持**（A-N 十四节；1.2 裁定不扩节——见 §4） |
| R8 编码面扫描（新增/修改文件） | ✅ 零非英文命中（pbt_seed_tests.rs + pbt.md[测试文档豁免位中文合法]） |

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

净增 9 = 7 属性（proptest! 块）+ 2 域自检（#[test]）。**分布论证**（pbt.md §1/§3 预申报 + 实测印证）：PBT 层的正负对偶由**属性域分工**承载——正向（FP1/FP3/FP5/FP6/FP7：良构域全量断言成功值/不动点/确定性）↔ 负向（FP2 双引擎必陷阱 UnhandledEffect + FP4 静态必报 E0006——确定性错误对偶）；「凑数禁止」（§12）的 PBT 面体现为七属性各自独立不变量视角（相对 parity / 确定性错误 / 归约语义 / 静态前置 / 序列化不动点 / 隐藏状态 / 具体 oracle——防双引擎同错），无两属性断言同一不变量。易错分布驱动（错误密度指引）：双引擎分叉面（FP1 最重 64 case）、效应路由边界（FP2/FP3/FP4 三属性族）、序列化边界（FP5）、算术 checked 边界（FP7 域约束 ±2⁴⁰ 使 oracle 恒 Some）。

**GATE 6 构成**：根集成挂载位（tests/v1/stage1/plan/pbt_seed_tests.rs 经 runner.rs）= 正向 7（FP1/FP3/FP5/FP6/FP7 成功路径 + 2 域自检）≥1 ✓ / 负向 2（FP2/FP4 确定性错误）+ 既有 130 case 审计集负向覆盖承接（7/7 类）✓ / 跨阶段消费 ✓（FP1/FP3/FP7 消费 driver 全管线 read→expand→typecheck→compile→{VM, eval}；FP4 消费 1.1 R6 静态面——有限样例属性化扩展）。

## 4. 关键决策与共变披露

- **audit 不扩节裁定**：PBT = 测试基础设施层（属性生成 + 收缩），非语言管线新面——审计集 130/130 维持（A-N 穷举错误族口径不变）；PBT 与样例审计互补（域互补：良构全域 × 确定性错误族 vs 穷举错误族样例——§9.4.3 v15.1 正负分工）。DEA-13 闭合口径 = 快照/黄金/自举/属性**四层测试基础设施**齐备。
- **proptest 版本解析披露**：`proptest = "1.9"`（^1.9 约束）解析为 **1.11.0**（1.x line 最新——§18 版本锁定口径 = 1.x line，MRES-E-2 语料的 "1.9.0" 为下界候选证据非精确锁定；Cargo.lock 锁 1.11.0）。
- **FP2/FP4 域对调裁定（实施时纠正）**：R6 顶层即时位 = **Define 值位裸 perform**（`(define r (perform e …))`——模块加载期执行）；Fn 体内 perform（`(define f (fn (u0) (perform e …))) (define r (f 9))`）走运行时陷阱面——设计定位与初版草案对调后落档（pbt.md §3 口径 2/3）。
- **FP3/FP7 断言面裁定**：declaration-only 程序的**程序值恒 nil**（§19.1 depth-0 halt——eval.rs 既有语义）；具体值断言转向 **define 槽**（`Evaluator::global("r")` + `Vm::global("r")` + parity_repr——比 ParityReport.vm_repr 更精确的观察面；vm_repr 仍是 FP1 的三面聚合断言成分）。
- **发现披露 2 项（设计事实非缺陷）**：①`StxDatum::Display` 是诊断/快照渲染面非序列化面（Bool 打印 `true`/`false` 而 reader 只认 `#t`/`#f`）→ FP5 采用**不动点口径**（read 像域在 display∘read 下闭合——`Bool(true) → Symbol("true") → Symbol("true")` 稳定）；序列化往返需求 = Stage 1+ `.krf` 序列化议程（零需求信号不预测——原则 32）。②空表 `()` 与空参表 `(fn () …)` 被 reader 拒绝（EmptyApplication——冻结语法事实）→ 生成器域宽度下界 1 + 包装 fn 哑参 u0。
- **基线共变 2 处**：ds08 版本黄金 0.14.0 → 0.15.0（共变义务第三例——注释链 0.14→0.15）+ Cargo.lock（proptest 1.11.0 + 传递依赖 rand 0.8/chunked-transfer 等 dev 侧锁定——不触生产依赖面）。

## 5. 边界与登记

- 生成器域扩展窗口（登记态）：良构域 var 引用为模板化局部（一层使用——IIFE/let/handler 体内单次）；跨层闭包捕获与递归函数域 = 1.3 HM 引入后的真实消费面（④ GC mark-sweep / ⑤ HM 推断 / ⑥ 效应行 soundness 同窗——§9.34.5 三类后续）。
- proptest-derive 未引入（自定义 arb 函数已覆盖当前域——零 derive 需求信号；§18 再审条件 = 域扩展触及自定义类型 derive 痛点）。
- FP5 生成器域申报（pbt.md §2）：String 域限可打印 ASCII 无转义字符子集；Float 域限 finite + Debug-parse 往返精确域——全 Unicode 字符串与任意 float 的序列化 = 同 `.krf` 序列化议程。
- 沙箱环境注记（非项目债务）：深树测试（`source_bounded_tree_compiles_and_hand_built_deeper_is_rejected`）与 audit example 需 ulimit -s 131072 + RUST_MIN_STACK=33554432（8MB 默认栈不足——生成环境/CI 脚本若固化可入 scripts/ 议程，当前零需求信号）。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

加权 5.5/5.5 = 100% ≥ 95%（ARCH-A GO×2 / DEV-A GO×1.5 / QA-A GO×1 / ALG-C GO×1 / SKL-A GO 附注不计权——附注：PBT 首轮 4 失败全为生成器域/断言面问题，双引擎 parity 零分叉——属性层对既有实现零新缺陷发现，DEA-13 缺口闭合实证）。§7.2 Q1-Q6 自检：Q1 零越界（proptest dev-dep 不入语言管线/自举链——§18.5 dev 侧豁免位）/ Q2 零新 crate 边（测试文件挂根 tests/——§8.4.6）/ Q3 新依赖 = proptest 1.11.0 仅 [dev-dependencies]（根测试层）/ Q4 跨层契约（三类不变量 = §9.34.5 权威清单首批——零新语言面）/ Q5 测试三层 + 审计 + 集成构成达标（§3）/ Q6 六命令实测非声称（§2 表）。

## 7. 版本与下一入口

workspace 0.14.0 → **0.15.0**（Stage 1.2 PBT 轮——x 位口径）。**下一入口：Stage 1.3 HM 推断基座**（Algorithm W 迭代预算版——stage0.md §9.30 REC-A 方案 3 谱系：迭代 + 512 预算 A6 + 效应行收集面 + 类型标注 IR[Layer 2 语义标注] + unify/occurs check + 快照测试扩展 + 性能基线 B1 对账）。

## 8. 打包（§19——19-e 轮回填）

（本节由 19-e 打包轮回填终值。）

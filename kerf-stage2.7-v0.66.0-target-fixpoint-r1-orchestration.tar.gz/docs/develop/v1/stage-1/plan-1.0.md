# Stage 1.0 子阶段计划与交付实录——kerf-typecheck 种子（E0xxx 注册面 + 保守静态 R1-R8 + 多错误收集）

> **Status**: Delivered 2026-09-28（v0.13.0）——Stage 1 开工轮
> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.0 + §3（R1-R8 权威定义）/§4（E0xxx）/§5（PBT 裁定）+ roadmap.md §6 首议程 + docs/sop.md §3.2/§7.3/§6.3/§8.4.5/§8.4.6/§9.4.3 v15.1/§18/§19 + docs/tests/v1/stage1/typecheck.md（测试文档先行——双向印证）

## 1. 任务构成

| MUV | 内容 | 依据 |
|-----|------|------|
| 17-a | 基准核验（r4 基线 767:0:0 + audit 110/110 复验 + GitHub 不可达先例沿袭[API 403/raw 404 复验]；消息内 stage0.5 包名 = 历次裁定陈旧模板残留——基准只进不退） | 用户指令① + §8.6.1 |
| 17-b | stage0.md 文件头版本标签同步整理（v8.8→v9.9 四处一致化——TD-006 清偿） | 用户指令② + M1 先例 |
| 17-c | Stage 1 开工规划（stage-1-plan.md 落档：排期 1.0-1.9 + R1-R8 权威定义 + E0xxx 注册面 + PBT §18 裁定 DEFER-WITH-TRIGGER→1.2）+ roadmap §6 刷新 + 出阶段确认记录 | 用户指令①③ + §13.1/§21 |
| 17-d | kerf-typecheck crate 实施（E0xxx + R1-R8 + 多错误收集 + Externals 面）+ 测试三层 + audit M 节 + 文档族 + v0.13.0 + commit | 用户指令③ + stage-1-plan §2 |
| 17-e | web 同步（静态位 + 动态源 + E2E） | 用户指令④ |
| 17-f | §19 打包 + 包内复跑 + web 打包区 | 用户指令⑤ |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| `cargo fmt --all -- --check` | ✅ 零 diff |
| `cargo build --release` | ✅ 0 error / 0 warning（**11 crates** + bin kerf + 双 example——kerf-typecheck 新入） |
| `cargo check --all-targets` | ✅ 0/0 |
| `cargo clippy --all-targets -- -D warnings` | ✅ 0 告警（--all-targets 含 example/bin/test 目标） |
| `cargo test --release` | ✅ **846 passed / 0 failed**（767 基线零回归 + 净 +79：typecheck 内联 51 + api 7 + 根集成 21；轮 43:36 = 1:0.84 反向偏差申报见 §3） |
| `cargo run --release --example stage0_gate_audit_r1`（§7.3.1） | ✅ **AUDIT PASS 120/120**（A10+B10+C5+D5+E10+F10+G10+H10+I10+J10+K10+L10+**M10**——审计集 110→120 单调增长；七类 7/7 维持；exit 0） |
| R8 编码面扫描（新增文件） | ✅ crates/kerf-typecheck/ + tests/v1/ + 审计 M 节 = 零非英文命中（rg CJK 复核清零） |

## 3. 测试构成（§9.4.3 v15.1——实测数 + 分布论证）

净增 79 = 正向 43 + 负向 36（1:0.84 反向偏差申报）。**分布论证**（typecheck.md §3 预申报 + 实测印证）：检查器负负对偶义务——「确定错误必报」（负向族：R1-R8 逐规则直接构造 + 源码可达路径 + 消息 R8 形态）与「合法程序永不告警」（正向族：健全性守卫——护栏放行/干净程序/前向引用/遮蔽/assigned 重绑，每形态 ≥1 零诊断断言）+ 注册面/Externals 形状断言结构性正向（存在性断言本体）。误报 = P0 级缺陷（检查器把合法程序判错即破坏可用性）→ 负向密集于护栏 + 正向密集于守卫，两侧均不可凑数削减（§12）。

**GATE 6 构成**：根集成 21 = 正向 9（≥1 ✓）+ 负向 12（≥3 ✓）+ 跨阶段消费 ✓（read→expand→typecheck 真实管线全链 + Externals 从 kerf_expander::STAGE0_GLOBALS + kerf_vm::Builtin::ALL 双源构造——单源纪律）。七类错误 ≥6 类负向覆盖维持（7/7——检查器 = 静态前置层非新错误类）。

## 4. 关键决策与裁定

- **裁定二十一**（E0005 语料位）：语料「E0005 多错误收集」描述诊断基础设施行为而非单条诊断码；kerf 实现裁定多错误收集 = 检查器**架构属性**（`check_module → Vec<TypeDiagnostic>` 全量遍历不短路），E0005 槽位归 R5（处理器元数失配）。语料其余 E 码引用（E0006 能力门控/E0020 关键字经济/E0021 旧名退役）= 上游叙事工件，激活时按域重新分配并记录映射。
- **R4 扩展终态**（实施中发现·计划同轮同步）：无重绑字面 Define 全局位（`(define two 2) (two 1)`）并入 R4 不可调用被调者族（assign 护栏 + 词法遮蔽跳过守卫下确定）；stage-1-plan §3 R2 护栏行措辞同步。
- **层间分工披露**：源码级前向引用被展开器拒绝（0.4 起定义序严格——第一道防线更严）；检查器 Fn 体全定义可见性 = 结构层属性（直接构造路径——运行时语义允许前向引用，VM interning + 调用时 = 加载完成后）。源码路径集成测试以厨房水池程序覆盖；前向引用守卫在单测直接构造位覆盖。
- **PBT §18 裁定**：DEFER-WITH-TRIGGER → 1.2（首个真实消费面[Reader 往返/VM dispatch 确定性]到达时引入 proptest 1.9 dev-dependency——纯测试层，永不入语言管线/自举链）。
- **TD-006 清偿**：stage0.md 四处一致化（文档状态行 v9.9 + 版本历史 v7.0「当前」过期标签修正 + v7.1-v8.8/v9.1-v9.9 两条合并条目 + 附录 G v9 终态注记）；lang-design/README 代偿说明退役；**TD 账面归零**（开放项 0）。

## 5. 边界与登记

- driver 接线（typecheck 级入管线 + CLI/REPL + 诊断渲染映射）= **1.1 议程**（本轮 crate + 三层测试 + 审计 = 消费面齐备，用户面接线下一轮）
- R2 全局被调者的非 Fn 非 Literal Define 形态（Other——运行时形状未知）= 保守跳过（登记 1.1+ 复核）
- 重复 Define（同名再定义——当前合法静默覆盖）= 登记未来 R 候选（非确定错误不报）
- 检查器递归深度：沿 visit_spans 先例（递归无显式预算）——展开器 EXPANSION_LIMIT 512 前置 + 直接构造为可信 API 面（披露）

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

加权 5.5/5.5 = 100% ≥ 95%（ARCH-A GO×2 / DEV-A GO×1.5 / QA-A GO×1 / ALG-C GO×1 / SKL-A GO 附注不计权）——附注（健全性守卫族与负向族对偶覆盖 + 误报 P0 风险由守卫族承载）不触发二次内循环。§7.2 Q1-Q6 自检：Q1 零越界（reserved 零入边维持）/ Q2 新 crate 两边活性 DAG 位 L4.5（compiler 前零环）/ Q3 依赖 = std-only 零外部 / Q4 跨层契约（编译器/展开器镜像序注释化锚定）/ Q5 测试三层 + 审计 + 集成构成达标 / Q6 六命令实测非声称。

## 7. 版本与下一入口

workspace 0.12.0 → **0.13.0**（Stage 1.0 开工轮——x 位口径）。**下一入口：Stage 1.1 driver 接线**（roadmap §6 首议程：typecheck 级入管线 + 诊断渲染映射 + CLI/REPL 面 + DEA-16 recovery_action 评估）。

## 8. 打包（§19——17-f 轮回填）

- 包：`kerf-stage1.0-v0.13.0-typecheck-seed-r1.tar.gz` —— **242 条目 / 1,528,232 B**（>1MB §19 验证 ✓）/ **sha256 80d861ee01fbf056fb2428889e4b3e8f8343dfc37d04e9488fc110421a5f7902**
- 包内复跑验证：解包至 /tmp/s10-verify → cargo test --release **846:0:0** + audit **120/120**（A-M 十三节——恢复锚实证：tar 解包任意根 + 冷构建全绿 + worklog 唯一事实源）
- download/README.md 表首行新增（沿先例十五包序列）
- web 打包区描述行回填 + packages 表经 API 动态显示新包（mtime 降序首行）
- 链路披露：本 §8 由续接会话 17-f 补完（原会话 17-d commit 83bcfea 后上下文耗尽——17-e/17-f/§8 回填/worklog 补录由恢复轮闭环，见 worklog Task 17-a~d 上下文耗尽披露 + Task 17-orchestration-resume）

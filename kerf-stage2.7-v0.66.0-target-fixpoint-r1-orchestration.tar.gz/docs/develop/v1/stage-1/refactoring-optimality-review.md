# Stage 1 Refactoring Optimality Review (§14.6.2 — FINAL, delivered at 1.9)

> Status: **FINAL** (1.9).

## Per-refactoring verdicts (Stage 1, consolidated)

| Round | Refactoring | §12 verdict |
|-------|-------------|-------------|
| 1.3 | iterative-W + undo-log + SCC split (replacing naive design *before* implementation — the design-walkthrough fixes) | optimal (§9.44.4) |
| 1.5 | source-injection table contract over input-tape (rejected alternative recorded) | optimal (§9.46.4 RS-1) |
| 1.6 | single-define self-recursion + five synthetic patterns (the mutual-recursion ban engineering) | optimal (§9.47.4 EX-2) |
| 1.7 | mangled record encoding + two-file assembly (over string construction) | optimal (§9.48.4 MX-1/2) |
| 1.8 | release-and-demand (over origin-tracing and bool-only heuristic — both rejected alternatives recorded) | optimal (§9.49 GATE-2 note) |

Data structures: §9.44.3 twelve rows re-verdicted at v0.22.0 —
all "aligned" or "deliberate" (the §9.50 frozen-layer re-audit
confirms rows 2/3/6 zero-drift; typecheck row updated for the 1.8
hardening).

## Omission list (FINAL)

Deliberately skipped, with reasons: token-stream reader rewrite
(lexical-addressing window owns it), NaN-boxing (GC-churn trigger
dark), dispatch arm reordering (hotspot dark). All are window
registrations, not missed cleanups — zero "treating symptoms"
hacks found across the nine sub-stages (each round's inner-loop
log records the fix-at-root evidence; the 1.8 round is the
cleanest demonstration: a two-layer root-cause chain instead of a
suppression).

## Pre-filled: the 1.8 refactorings

| Refactor | Choice | Optimality note |
|----------|--------|-----------------|
| HM wiring (GATE-2) | same-batch two-layer collection (ruling 21) | optimal: zero new channel, severity split reused |
| HM false-positive fix | release-and-demand (unify_args rollback + bool-demand table) | optimal over both alternatives considered (origin-tracing through generalization loses the provenance at schema sealing; bool-only heuristic = cons-field false positives) — see stage0.md §9.49.5 GATE-2 implementation note |
| audit U section | full re-run + increment (190) | per §7.3.1 rule 4 |

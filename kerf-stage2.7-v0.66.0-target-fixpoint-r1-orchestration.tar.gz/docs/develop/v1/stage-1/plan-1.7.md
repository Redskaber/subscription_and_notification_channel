# plan-1.7 — Stage 1.7 执行计划（基础宏 .krf 重写第三段：宏面 + fixpoint 门 B）

> 依据：docs/develop/v1/stage-1-plan.md §2 行 1.7 + docs/stage0.md §9.48（设计依据层——MX-1..MX-6）+ docs/sop.md §4/§5/§7 + §18.3（门 B）
> 交付版本：v0.20.0 · git（§6.4 规范 commit）

## 1. 任务构成

| MUV | 内容 | 落位（§8.4.6 两级语义） |
|-----|------|--------------------------|
| 1.7-a | **selfhost/v1/macro.krf 第三件**（MX-2 双文件装配式——纯函数库零驱动式）：宏注册表（帧感知——模块隔离）+ `ex-macro-define`（spec 五重校验：head/literals/子句形状/单子句查重/`...` fail-closed）+ `ex-macro-resolve`（名栈内层优先 + binder 子集判定）+ `ex-macro-match`（定元同构匹配：Wildcard/Literal 文本比对/Var 绑定/Atom/List——合成模式 matchx 绕过 ex-depth 对应 Rust instantiate 零预算）+ `ex-macro-instantiate`（六步序：拼接 early-return/世代+1/span 构造/List binder 碰撞改名 pushed 计数配对退栈/Symbol active_rename/Atom 拷贝）+ **mangled 记录编码**（MX-1：`("mangled" s e base counter)` 产物记录——零字符串构造）+ trigger 三源收集（splice 符号 + STAGE0_GLOBALS 18 + RESERVED 15） | selfhost/v1/（自举面第三件——TD-032 第三切口；1.6 双件同目录先例） |
| 1.7-a′ | **expander.krf 宏分支替换**：define-syntax fail-closed 分支（:512-515）→ `(ex-macro-define ...)` 真实注册；使用点分派（核心形式平铺分派之后、application 之前）→ `(ex-macro-resolve ...)` 命中即 `(ex-macro-use ...)`（instantiate 产物回灌 ex-expand——到核心形式 fixpoint，每层计 1 预算） | selfhost/v1/expander.krf（既有件扩展——装配契约：宿主拼接 macro.krf body + expander.krf body） |
| 1.7-b | **kerf-driver expander_parity.rs 扩展**：装配契约（ASSEMBLED = macro.krf + expander.krf 源面拼接——forms_stream_prefix 先例）+ **MX-3 Macro 层收缩**（contains_define_syntax 分流删除；pos-024/bnd-010 迁入 Expander 层双引擎真跑；Macro 变体哨兵保留——sweep 断言 macro_layer==0 fail-closed）+ **MX-1 mangled 宿主解码**（dump_krf 侧 `("mangled" s e base counter)` → `format!("{base}__macro_{counter}")` 终名与 oracle 逐字节比对）+ **MX-4 错误轴扩展**（reconstruct_expand_error 增 `macro-mismatch` 臂 + static_form 增 `define-syntax`）+ **MX-6 门 B 双口径**：(a) 字节码全等 `compile(expand_oracle(S)) == compile(expand_krf(S))`（Bytecode PartialEq——宏语料 9 案 + 装配源自应用）+ (b) 装配程序自应用幂等不动点 | crates/kerf-driver 内（L8 管线属主；类型可名化沿 re-export 先例） |
| 1.7-c | **语料扩展 7 案**（72→79：pos-031 literal 非空表 / pos-032 两代宏链 / pos-033 卫生 binder 碰撞——rename-on-capture 首次语料行使 / neg-050 模式不匹配 / neg-051 重复模式变量 / neg-052 ellipsis 拒绝 / neg-053 module 域宏外用）+ 测试三层 + audit T 节（170→180）+ ds08 共变 | tests/v1/stage1/corpus/（7 案已探针定正全绿）+ 根 tests/ + examples/audit T 节 + 快照 ds08 版本黄金 0.19.0→0.20.0（共变义务第八例） |

## 2. 验证实录（SOP §3.2——release 口径，冷跑实际运行）

| 命令 | 结果 |
|------|------|
| cargo fmt --check | 零 diff |
| cargo build --release / check | 0 error / 0 warning |
| cargo clippy --all-targets --release -- -D warnings | 0 |
| cargo test --release | **1128:0:0**（1098 基线零回归 + 净 +30：内联 16 + 根集成 13 + 语料 7 案[probe-verified 一次全绿；探针定正 mp7 depth span 43..49 单行布局实况]） |
| cargo run --release --example stage0_gate_audit_r1 | **AUDIT PASS 180/180**（A-T 十九节——T 节 10 案：literal 面板 / 两代链 / mangled 解码 / mismatch·malformed·ellipsis·域外四拒绝 / 深度镜像 / 门 B 双口径[宏语料 4 案字节码全等 + 装配自应用三方]） |

## 3. 测试构成计划（§9.4.3 v15.1——分布论证）

- 内联单测（expander_parity.rs）：装配契约（拼接序/驱动式唯一性）/ mangled 解码（base 透传 + counter 分配 + trigger 避让）/ Macro 哨兵（零路由 fail-closed）/ macro-mismatch 错误臂 / 篡改探测器 / harness 缺陷即数据——正负混合。
- 根集成（expander_parity_tests.rs 扩展 + 新 macro 面测试）：**语料 79 全扫重放**（三层分布 6/0/73 精确断言——Macro 哨兵零路由）+ **门 B 口径 (a) 字节码全等**（宏语料 9 案 + 装配源自应用——跨阶段消费：expander 输出 → compiler 输入）+ **门 B 口径 (b) 装配自应用幂等**（三段版不动点）+ 七 trap 镜像族新增宏陷阱位 + 篡改锚。
- GATE 6 口径：集成 ≥3（正向 ≥1 / 负向 ≥3 / 跨阶段消费 ≥1——字节码全等即跨阶段）；宏面负向 4 案（neg-050/051/052/053）达标。
- audit T 节 10：宏面 parity 判定面元审计（detector-detects 第四实例）。

## 4. 关键决策（§9.48 实施转译）

1. **MX-1 mangled 记录结构化编码**：fresh_name 字符串构造缺口（18 内建零字符串运算）经 `("mangled" s e base counter)` 记录化解——base 透传 + counter int 均在 VM 可表达域；宿主 format! 解码逐字节比对。eq? 值等（vm/value.rs:243）支撑 renames alist 查找。沿 1.5 float=Debug 文本先例：parity 考判定面非拼接面。
2. **MX-2 双文件装配式**：macro.krf 纯函数库（零驱动式）+ expander.krf 装配契约（宿主源面拼接）——Rust 侧 transformer.rs = kerf-expander 模块的 .krf 对偶镜像。
3. **MX-3 Macro 层收缩**：三层分流 6/2/64 → 二层 6/0/73（Macro 哨兵保留，零路由断言 fail-closed）。
4. **MX-6 门 B 二阶段双口径**：(a) 字节码全等（subset-spec §4 预留判据兑现——1.6 dump 全等升格）+ (b) 装配自应用幂等；三阶段 A→B→C 登记 Stage 2+ compiler 自举窗前置。
5. **深度计数镜像**：Rust instantiate 零预算、re-expand 计 1——.krf 匹配/实例化合成模式绕过 ex-depth；bnd-010 两引擎同文本同 span。
6. **语料 7 案探针定正**：oracle 实测一次全绿（value 1/2/101 + 四错误文本逐字节——期望零猜测纪律）。
7. **共变清单**：ds08 版本黄金（第八例）+ Cargo.toml workspace+10 成员 0.20.0 + audit 尾部统计行（170→180）+ subset-spec §3.3 交付态注记 + §1.1「宏触发面 = 1.7 bootstrap agenda」兑现 + stage-1-plan 1.7 行 ✅ + 变更日志 v1.7 + expander-parity.md §5 维护注记兑现（Macro 层收缩）。

## 5. 边界与登记

- **1.8 主窗（下一入口）**：Stage 1 末轮预备——门审全集复跑（≥130 case）+ 校准统计 + 深验七件套准备。
- **字符串原语子集窗维持**（mangled 规避不消解——零信号不开窗）；**三阶段 fixpoint 窗**（Stage 2+ 登记——compiler.krf 前置）；词法层第二段窗 / evaluator 栈预算窗维持。
- 世代 span 不入 dump（1.6 裁定维持——pos-033 的 mangled 记录 s/e = template 原区间）；oracle 侧世代面由内联测试覆盖（既有 introduced_nodes_carry_the_next_generation 两测）。

## 6. 投票（§6.3——单 Agent 模拟披露沿先例）

| 角色 | 票 | 附注 |
|------|-----|------|
| ARCH-A | 2/2 | MX-1 判定面/拼接面分离（沿 1.5 先例）+ MX-2 模块镜像架构 + Macro 哨兵保留（fail-closed 有断言消费非死码）+ 门 B 双口径（subset-spec §4 兑现） |
| DEV-A | 1.5/1.5 | 双文件装配契约（宿主拼接零 VM 机制变更）+ 合成模式第四/五实例 + 探针五轮内循环实录（四头统一 / cpl improper 尾 / resolve 与 ex-ar 双包裹 / 重建器声明 gen / mp7 期望——全部探针实证定正） |
| QA-A | 1/1 | 语料 79 全扫（6/0/73 精确断言）+ 字节码全等（Bytecode PartialEq 硬断言）+ 幂等不动点 + 篡改锚 |
| ALG-C | 1/1 | 六步实例化序逐字节镜像（配对退栈 ★7 锚定）+ trigger 三源 + bnd-010 深度同 span + mangled 解码确定性 |
| SKL-A |（不计权）| PASS（装配式 = 程序级组合最朴素形态——零新 VM 机制） |
| **加权** | **5.5/5.5 = 100% ≥ 95%** | |

## 7. 版本与下一入口

- v0.20.0（git commit 按 §6.4：`feat(stage1.7): macro parity — .krf macro layer lands, fixpoint gate B`）。
- 下一入口 = **Stage 1.8 末轮预备**：门审全集复跑 + 校准统计 + 深验七件套准备（stage-1-plan §2 行 1.8）。

## 8. 打包（§19——24-e 轮回填）

- tar --exclude=target/.git → `/home/z/my-project/download/kerf-stage1.7-v0.20.0-macro-parity-seed-r1.tar.gz`
- （回填位：entries / bytes / sha256 / 解包回归验证 / download/README.md 基准表更新）

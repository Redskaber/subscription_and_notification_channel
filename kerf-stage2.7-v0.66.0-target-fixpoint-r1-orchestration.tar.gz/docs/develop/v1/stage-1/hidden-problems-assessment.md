# Stage 1 Hidden Problems & Stage 2 Readiness (§14.6.1.4 — FINAL, delivered at 1.9)

> Status: **FINAL** (1.9). Growth ratings close the pre-filled
> inventory; the readiness verdict feeds final-assessment.md.

## Complexity-growth ratings (FINAL)

All open items are registered windows (zero open TD): every rating
below is "unchanged" — each window is an additive table, a
representation swap, or a theory-layer item whose deferral adds no
multiplicative repair cost. The two 2× rows are windows whose
*surface* spans two layers by design (one cut plane), not deferred
defects — they are scheduled as the Stage 2 first knife, which is
the cheapest time to take them (§14.5: stage boundaries are where
debt costs most).

## Stage 2 readiness verdict (FINAL)

Stage 1 supplies every hard prerequisite the Stage 2 plan names
(deep-review-round1.9.md D4): the three self-hosted front-end
segments + gate B, the wired and hardened HM layer, the frozen
corpus/snapshot/audit regression base, and the in-band performance
baseline. The two open windows (lexical addressing + capture
activation; compiler fixpoint stages) enter Stage 2 as planned
work, not as gaps. **No mandatory-fix items (zero growth ≥2×
defects).**

## Pre-filled: the registered-window inventory (all zero-signal, §9.44.5/§9.49.6)

| Item | Trigger | Growth if deferred | Window |
|------|---------|--------------------|--------|
| Symbol interning | LSP / B-hotspot / self-compile load | unchanged (additive table) | Stage 2+ |
| Lexical addressing + capture activation | capture-semantics agenda | 2× (compiler+vm same cut) | Stage 2 |
| Value packing (NaN-boxing) | GC churn top-3 | unchanged (representation-swap) | Stage 2/3 |
| Generational GC | short-lived ratio measured | unchanged | Stage 2/3 |
| Row polymorphism | TY-C solver window | n/a (theory layer) | Stage 2+ |
| Dispatch arm ordering | B-series top-3 | unchanged (micro) | micro |
| Evaluator stack budget | deep debug trees | unchanged (test-env face) | registered |
| Compiler self-host three-stage fixpoint | Stage 2+ gate C | 2× (bootstrap chain) | Stage 2+ |

## Known conservative limits (1.8 hardening, registered not defects)

- HM anonymous-fn-alias bool demand released (fp3 anchor) — fail-closed on uncertainty
- HM let-alias demand propagation — same family

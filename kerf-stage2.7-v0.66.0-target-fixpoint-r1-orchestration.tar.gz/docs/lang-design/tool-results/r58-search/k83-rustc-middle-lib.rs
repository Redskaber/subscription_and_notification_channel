//! The "main crate" of the Rust compiler. This crate contains common
//! type definitions that are used by the other crates in the rustc
//! "family". The following are some prominent examples.
//!
//! - **HIR.** The "high-level (H) intermediate representation (IR)" is
//!   defined in the [`hir`] module.
//! - **THIR.** The "typed high-level (H) intermediate representation (IR)"
//!   is defined in the [`thir`] module.
//! - **MIR.** The "mid-level (M) intermediate representation (IR)" is
//!   defined in the [`mir`] module. This module contains only the
//!   *definition* of the MIR; the passes that transform and operate
//!   on MIR are found in `rustc_const_eval` crate.
//! - **Types.** The internal representation of types used in rustc is
//!   defined in the [`ty`] module. This includes the
//!   [**type context**][ty::TyCtxt] (or `tcx`), which is the central
//!   context during most of compilation, containing the interners and
//!   other things.
//!
//! For more information about how rustc works, see the [rustc dev guide].
//!
//! [rustc dev guide]: https://rustc-dev-guide.rust-lang.org/
//!
//! # Note
//!
//! This API is completely unstable and subject to change.

// tidy-alphabetical-start
#![allow(internal_features)]
#![allow(rustc::direct_use_of_rustc_type_ir)]
#![cfg_attr(bootstrap, feature(allocator_api))]
#![cfg_attr(bootstrap, feature(never_type))]
#![cfg_attr(doc, feature(intra_doc_pointers))]
#![cfg_attr(not(bootstrap), feature(allocator_ext))]
#![feature(associated_type_defaults)]
#![feature(closure_track_caller)]
#![feature(const_default)]
#![feature(const_trait_impl)]
#![feature(core_intrinsics)]
#![feature(debug_closure_helpers)]
#![feature(decl_macro)]
#![feature(default_field_values)]
#![feature(deref_patterns)]
#![feature(discriminant_kind)]
#![feature(extern_types)]
#![feature(file_buffered)]
#![feature(gen_blocks)]
#![feature(min_specialization)]
#![feature(negative_impls)]
#![feature(option_into_flat_iter)]
#![feature(ptr_alignment_type)]
#![feature(range_bounds_is_empty)]
#![feature(rustc_attrs)]
#![feature(sized_hierarchy)]
#![feature(trait_alias)]
#![feature(try_blocks)]
#![feature(try_trait_v2)]
#![feature(try_trait_v2_residual)]
#![feature(try_trait_v2_yeet)]
#![feature(type_alias_impl_trait)]
#![feature(variant_count)]
#![feature(yeet_expr)]
#![recursion_limit = "256"]
// tidy-alphabetical-end

#[cfg(test)]
mod tests;

#[macro_use]
mod macros;

#[macro_use]
pub mod arena;

pub mod dep_graph;
pub mod diagnostics;
pub mod hir;
pub mod hooks;
pub mod ich;
pub mod infer;
pub mod lint;
pub mod middle;
pub mod mir;
pub mod mono;
pub mod ptrauth;
pub mod queries;
pub mod query;
pub mod thir;
pub mod traits;
pub mod ty;
pub mod util;
pub mod verify_ich;

// Allows macros to refer to this crate as `::rustc_middle`
extern crate self as rustc_middle;

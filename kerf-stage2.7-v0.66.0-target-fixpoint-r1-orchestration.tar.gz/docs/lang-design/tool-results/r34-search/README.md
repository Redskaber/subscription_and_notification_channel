# r34-search — §9.57 测试基础设施自审计域检索存档（第五十六轮）

七查 + 一主源直读升级（沿 r33 q3 弱查升级先例）。质量如实披露。

## 强锚（实体入库）

- **q2-compiletest.json / q2b-ui-primary.html / q2c-tests-intro.html** — rustc-dev-guide《UI tests》+《Testing the compiler》主源直读（q1 两轮搜索垃圾 → 升级主源直读，`tests/intro.html` 承载 tidy 章）。**K75**：tidy = 树级机械自检（长行/测试落位纪律强制——"All standard library and compiler unit tests are placed in separate tests file (which is enforced in tidy)"）；compiletest `//@` 指令 + `.stderr`/`.stdout` 快照 + `--bless` 再基线 + `$DIR`/`$SRC_DIR`/`LL:COL` 归一化 + **散逸输出文件追踪**（"test-name cannot contain dots … predictable form we can pattern match on in order to track stray test output files"）+ distcheck（tarball 解包-构建-测试一体化验证）。同族：ui_test crate（docs.rs/ui_test——compiletest 下一代形态）。
- **q3-expect.json** — **K76**：rust-analyzer expect-test（github.com/rust-analyzer/expect-test + lib.rs）——极简内联快照（`expect![[]]` 空槽起手 + `UPDATE_EXPECT` 环境变量批量更新）；对照形态：外置快照（insta）vs 内联（expect-test）。
- **q4b-mutants.json** — **K77**：cargo-mutants（mutants.rs 官方 + crates.io + ThoughtWorks Radar 收录）——变异测试度量测试套件质量（syn 解析源码生成变异 → 跑测试 → 存活变异 = 覆盖缺口）；mutest-rs 论文（philmcminn.com 2026）同域。

## 弱查披露（§12 不凑数）

- **q1-tidy.json / q1b-tidy.json** — 两轮垃圾结果（Android googlesource / Debian 邮件列表无关命中）→ **升级主源直读**：curl `rustc-dev-guide.rust-lang.org/tests/intro.html`（tidy 章正文在内）成功入库 q2c。
- **q4-mutants.json（首轮）** — 垃圾结果（RuneScape PDF）→ 改写查询 q4b 成功。
- **q5-meta.json** — 垃圾结果（网络安全/SEC 文件等无关域）。元测试（tests-of-tests）无独立强源；K75 tidy 的"测试落位纪律强制"即该域的工业级形态锚，不再补查。
- **q6-gcc.json** — 大部分垃圾；GCC torture `dg-*` 指令模式在项目语料 harness 文档注释中已有内部锚（subset_corpus_tests.rs 头注"the GCC torture `dg-*` pattern"），本轮零新外部锚需求。

## 裁定

K75（tidy/compiletest/distcheck 三合一主源）+ K76（expect-test）+ K77（cargo-mutants）三强锚承载 §9.57 十二面审查表；q1/q5/q6 三弱查如实降档（零伪造锚）。

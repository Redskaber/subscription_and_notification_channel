# r71 知识检索存档——语法树与核心 IR 表示域（第七十一轮 · Task 49-b）

> 检索日期：2026-09-30（沙箱重置轮——工具链 1.98.1 重装 + rust-src 组件）。
> 域：kerf-syntax 全 crate（StxDatum/SyntaxObject/ScopeSet/Phase）+ kerf-core/src/expr.rs（CoreExpr/LiteralValue/Binding/HandlerClause）+ 消费面追踪（expander/transformer/compiler/vm/eval/parity）。
> **磁盘实测清单（20 文件）**：查询 6 件（q1/q3/q4/q5/q6/q7——q2 与 q2b 重试两次 429 限流未落盘，如实登记）+ 主源 13 件（m1b/m1c/m2/m2b/m2c/m3[html]/m4/m5/m6/m7/m8 十一件实体 + m1[ptr.rs 404 占位 14B 保留——P<T> 已退役的目录证据由 m1c 承载] + m3[pdf 404 占位 282B 保留——html 版实体在档]两件失效占位沿 r34/r70 先例保留）+ 本 README。
> 弱查如实披露：**弱查第十八轮**——q1 弱-中（fuchsia 镜像命中 rustc_ast token.rs 真源）+ q5 弱（rust-best-practices 单命中）+ q3/q4/q6/q7 垃圾（Springer/tilde.club/scribd 词典噪声）+ q2 两次 429 限流未落地。锚定由主源直读承载（沿 r69「全七查询弱/失败」先例）。

## 查询产物（q1-q7）

| 件 | 查询 | 质量 |
|----|------|------|
| q1-rustc-ast.json | rustc_ast P<T> Box AST node representation arena | 弱-中（fuchsia.googlesource 镜像 rustc_ast/src/token.rs 真源命中） |
| q2-oxc-ast.json / q2b | oxc AST design span Atom oxc_span | 两次 429 限流未落地（如实登记） |
| q3-racket-scopes.json | Racket syntax object scope sets | 垃圾（Springer 会议索引 + 词典噪声） |
| q4-string-interning.json | string literal interning Lua V8 rustc | 垃圾（pkg.go.dev/gitlab 镜像噪声） |
| q5-rc-str.json | Rust Rc<str> vs String immutable shared | 弱（rust-best-practices book 单命中——「borrow instead of cloning ... or Rc pointers」） |
| q6-persistent-ast.json | persistent data structure syntax tree sharing | 垃圾（linux kernel DSDT 噪声） |
| q7-syntax-context.json | rustc syntax context hygiene chain | 垃圾（词典噪声） |

## 主源直读（m1-m8——八件实体入库）

| 件 | 源 | 字节 | 关键锚 |
|----|-----|------|--------|
| m1b-rustc-ast-ast.rs | rustc 1.98.0 `compiler/rustc_ast/src/ast.rs`（GitHub raw tag 1.98.0） | 144,522 | `Expr{NodeId, ExprKind, Span, AttrVec, tokens}` 结构包装 + `ExprKind::Array(ThinVec<Box<Expr>>)` + `LitKind::Str(Symbol, StrStyle)` L2255——**P<T> 已退役，现代 rustc AST = 纯 Box 树**；字符串字面量 = 驻留 Symbol 全链 |
| m1c-rustc-ast-lib.rs | 同上 `lib.rs` | 810 | 模块面盘点（ast/token/tokenstream/node_id——ptr 模块已不存在） |
| m2-oxc-span-lib.rs | oxc main `crates/oxc_span/src/lib.rs` | 1,637 | `use oxc_str::{CompactStr, Ident, Str}`——oxc_span 是 rustc_span 建模的自述（文件头注记直引） |
| m2b-oxc-str-lib.rs | oxc main `crates/oxc_str/src/lib.rs` | 2,258 | **专用字符串 crate**：Str(=ArenaStr)/Ident/CompactStr 三型系统 + 「Storage, encoding, and ownership stay out of public names」命名哲学 + MAX_INLINE_LEN 内联小串 |
| m2c-oxc-ast-literal.rs | oxc main `crates/oxc_ast/src/ast/literal.rs` | 8,739 | `StringLiteral<'a>{span, value: Str<'a>, raw: Option<Str<'a>>}`——字面量载荷 = 竞技场串非 owned String |
| m3-racket-syntax-model.html | docs.racket-lang.org/reference/syntax-model.html | 270,949 | 「A form is represented as a syntax object, and each syntax object has an associated set of scopes (i.e., a scope set)」——每个语法对象带 scope set 的工业正典（含非标识符原子） |
| m4-lua-lstring.c | Lua 5.4.6 `lstring.c`（GitHub raw tag v5.4.6） | 7,499 | `luaS_newlstr`：短串（≤LUAI_MAXSHORTLEN）internshrstr 全局串表驻留 + 长串一次创建 GC 对象——消费点永不重拷 |
| m5-v8-string.h | V8 main `src/objects/string.h` | 59,811 | internalized string 族（ThinString 转发 + 原地内部化条件注记 L695-697/L1134-1136） |
| m6-rustc-hygiene.rs | rustc 1.98.0 `compiler/rustc_span/src/hygiene.rs` | 59,494 | SyntaxContext 链式 u32 + ExpnId 驻留——rustc 卫生 = 上下文链非 scope set（模型分族证据） |
| m7-rustc-token.rs | rustc 1.98.0 `compiler/rustc_ast/src/token.rs` | 40,737 | `Lit{kind, symbol: Symbol, suffix}` L209-213——**token 流层字面量文本即驻留 Symbol** |
| m8-std-rc.rs | 本地工具链 1.98.1 `library/alloc/src/rc.rs`（rust-src 组件——与生产构建同版本） | 155,581 | Rc 语义：Clone = 指针+计数（非数据拷贝）；非 Send/非原子（单线程纪律匹配 symbol.rs:69 注记） |

## 六锚结论（K143-K148）

- **K143（rustc 字面量链）**：token `Lit{symbol: Symbol}` → AST `LitKind::Str(Symbol, StrStyle)`——字面量文本以驻留身份全链流转，无任何 owned String 中间表示。kerf 改前 = reader 堆 String → Stx → [clone] CoreExpr → [clone] bytecode consts → [clone/次物化] Value::Str——四跳全拷贝对照面。
- **K144（rustc AST 形态）**：`Expr` = 结构包装{NodeId+kind+Span+attrs+tokens}，子节点 `ThinVec<Box<Expr>>`/`Box<Expr>`——P<T> 退役实证（m1 目录盘点无 ptr 模块）。kerf CoreExpr 的 Box/Vec 树 = 同族形态（span 内嵌变体 vs 结构包装 = 风格差异非实质差异）。
- **K145（oxc 字符串专门化）**：oxc_span（rustc_span 建模自述）+ oxc_str 三型（arena Str/Ident + CompactStr 内联）——前沿工业 JS 编译器把字符串表示从通用类型抽成专门 crate；「Storage, encoding, and ownership stay out of public names」。
- **K146（Lua 串表）**：短串全局驻留 + 长串一次创建——「每消费点重拷」在工业实现中不存在。
- **K147（V8 内部化）**：internalized string 体系（原地内部化 + ThinString 转发）——同一方向的第二工业证。
- **K148（Racket scope-set 模型）**：每个语法对象（含布尔/数字原子）带 scope set = Racket 正典——kerf 四元组模型合法；rustc SyntaxContext 链（m6）= 另一分族（模型选择非缺陷）。

## 技术-缺陷权衡（用户常设指令「引入技术是否也引入缺陷」）

1. **Rc<str> 零拷贝链（SYN-1）**——缺陷面：① 非 Send（值跨线程即编译错）——勘证：kerf 单线程编译纪律在档（symbol.rs:69 注记 + 深栈测试闭包内创建值不跨边界 + 仅 Symbol[NonZeroU32] 跨线程）；② 引用计数开销（Clone = 2 非原子 op）——对照 String clone = 分配 + memcpy，长串净赢；短串（≤16B）计数 vs 小分配 = 分配器成本占优；③ 循环引用风险——Rc<str> 无内部指针，不可能成环（对照 Rc<Cell> 族）；④ 内存驻留（字面量常驻）——对照 Lua 串表同设计（驻留 by-design，§9.52 leak-by-design 先例同族）。缓解：全局无跨线程值面勘证 + Display/Debug 逐字节同构（金色测试零重基线义务）。
2. **HashSet<Symbol> 去重（SYN-2）**——缺陷面：Symbol Hash = u32 哈希（恒等分布）vs &str 哈希（内容分布）——u32 恒等哈希在 HashSet 中的桶分布 = 全碰撞风险？勘证：std 默认 SipHash 对 u32 仍混洗良好；且 params 典型 ≤8 个——微面无实质。收益：与 §9.52/§9.68 身份基座链同构（零文本键工作状态）。
3. **scope 深克隆维持（SYN-3）**——缺陷面（维持现状的缺陷）：O(子树)×O(嵌套深度) 克隆成本。缺陷面（若改持久共享）：表示大改 + principle 23 语义面重证 + 冻结层扰动。权衡：B1b 3.5µs 带内（fib 展开无宏）+ Stage 0 语料规模（79-81 文件最大 741 行）+ Racket 模型正典（K148——每对象带 set 的价格即模型价格）。裁定：维持 + W-SYN-SCOPE-SHARING 登记窗（触发器 = B1b 越带 25% 或 Stage 2 自举语料展开轴关切）。

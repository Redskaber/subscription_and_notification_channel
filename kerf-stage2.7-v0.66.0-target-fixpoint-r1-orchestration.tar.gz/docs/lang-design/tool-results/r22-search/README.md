# r22-search — 第四十四轮检索存档（§9.46 / stage0 v9.12 / Task 22-b）

> 依据 docs/sop.md §8.6 与 §9.46.1：本轮为检索存档**首次实体入库**（此前 r21-search/r42-search
> 为沙箱侧临时产物未随仓库交付——指针悬空沿旧例注记，本轮起存档面补实态）。
> 检索通道：z-ai web_search CLI（六查）；质量分级如实披露（强锚 4 / 弱锚 2 降档）。

## q1 — bootstrappable reader chains（→ K18 强锚）

query: `bootstrappable builds stage0 hex0 hex1 M0 mescc tiny reader self-hosting compiler chain`

- Full-Source Bootstrap (GNU Guix Reference Manual) — guix.gnu.org — "hex0 builds hex1 and then on
  to M0, hex2, M1, mescc-tools and finally M2-Planet"
- oriansj/stage0 — github.com — minimal dependency bootstrap; hex programs; self-hosting chain
- A minimal C compiler in x86 assembly — news.ycombinator.com — GNU Mes / MesCC → TinyCC lineage
- The Full-Source Bootstrap — lobste.rs / joyofsource.com — hex0 self-hosting; Mes/MesCC →
  bootstrappable TinyCC

## q2 — metacircular evaluator / reader layering（→ K19 强锚）

query: `Lisp reader written in Lisp itself metacircular read function SICP`

- SICP 4.1 The Metacircular Evaluator — sarabander.github.io — driver loop models the
  read-eval-print of the *underlying* Lisp system
- The Lisp Interpreter — courses.cs.northwestern.edu — "The input to the Lisp reader is a
  sequence of characters. The output is a Lisp expression"
- Reader Macros in Common Lisp — lisper.in — reader parses raw text into s-expressions
- First-class, run-time macros from meta-circular evaluators — matt.might.net

## q3 — differential testing of parsers（弱锚——降档沿 K15 既有登记）

query: `differential testing parser equivalence oracle error messages compiler testing`

- Differential Testing of Pushdown Reachability (Schlichtkrull, TUM) — 仅边缘沾边；
  Rigger ICSE'23 差分测试锚已由 §9.45 K15 登记——本轮不新增。

## q4 — exact f64 decimal parsing（→ K20 强锚）

query: `fast float parsing Eisel-Lemire exact IEEE 754 decimal to binary Rust strtof correct rounding`

- Number Parsing at a Gigabyte per Second — arxiv.org (2101.11408) — "parsing decimal numbers to
  the nearest binary floating-point value ... requires variable-precision arithmetic"

## q5 — lexer bootstrap fixed point（弱锚——降档：教科书泛材）

query: `self-hosting compiler lexer bootstrap fixed point incremental porting token stream`

- 通用教材材料（scribd/slideshare 编译原理讲义、SugarJ 可扩展语言论文等）——无具体
  「词法器自举不动点」先例命中；不新增锚。

## q6 — Scheme mandatory string primitives（→ K21 强锚）

query: `R5RS Scheme string operations string-length string-ref substring minimal standard`

- R6RS (Revised^5.97 Report) — r6rs.org — substring/string-ref semantics
- Scheme (D. Sitaram notes) — cs.us.es — string-ref index semantics
- SRFI 91: Extended ports — srfi.schemers.org — R5RS I/O limited functionality note
- Gambit / Gauche / Chez references — R4RS/R5RS/IEEE conformance

## 锚汇总

| 锚 | 来源查询 | 强弱 | 供给 |
|---|---|---|---|
| K18 | q1 | 强 | §9.46.1 / RS-1（hex0 层位思想） |
| K19 | q2 | 强 | §9.46.1（kerf Reader-第一段次序的登记差异） |
| K20 | q4 | 强 | §9.46.1 / RS-5（f64 不可子集化） |
| K21 | q6 | 强 | §9.46.1 / §9.46.5（字符串原语窗前置） |
| （降档） | q3/q5 | 弱 | 沿 K15 既有登记 |

# r24-search — 第四十六轮检索存档（§9.48 / stage0 v9.14 / Task 24-b）

> 依据 docs/sop.md §8.6 与 §9.48.1：r23 实体入库先例延续。检索通道：z-ai web_search CLI
> （六查）；质量分级如实披露（强锚 7 / 弱查 1 降档——K34）。

## q1 — syntax-rules pattern matching（→ K27 强锚）

query: `syntax-rules pattern matching algorithm implementation Scheme macro ellipsis fixed arity`

- Programming Languages: Application and Interpretation（PLAI, S. Krishnamurthi）— www.plai.org —
  ellipsis = arbitrary-length sequence in patterns; pattern variables in variants
- MIT/GNU Scheme Reference Manual — ftp.mirrorservice.org
- Chez Scheme Version 9 User's Guide — www.rose-hulman.edu
- The Racket Guide（M. Flatt）— download.racket-lang.org

## q2 — hygienic rename algorithms（→ K28/K29 强锚）

query: `Kohlbecker hygienic macro expansion rename algorithm captured identifiers lambda lifting`

- Type-Safe Metaprogramming and Compilation Techniques（L. E. Parreaux 2020, EPFL）— infoscience.epfl.ch —
  "Scheme introduced facilities to write hygienic macros [Kohlbecker …] separate identifiers
  appearing at different binding sites"
- Reliably composable language extensions（Univ. of Minnesota 引文页）— conservancy.umn.edu —
  Kohlbecker, Friedman, Felleisen, Duba《Hygienic Macro Expansion》LFP 1986 一手引文确认
- Extensible Languages for Flexible and Principled Domain...（S. T. Erdweg）— d-nb.info —
  hygienic macro expansion ⇒ referential transparency
- REGION-BASED MEMORY MANAGEMENT FOR EXPRESSIVE...（Harlan 编译器）— theincredibleholk.org —
  "Harlan ensures hygiene by carefully renaming variables during macro expansion"

## q3 — template instantiation / syntax-case（→ K30 强锚）

query: `syntax-rules template instantiation implementation code generation macro transformer Chez Scheme`

- The Racket Reference — download.racket-lang.org
- Springer 教材 — link.springer.com — "Chez Scheme generalized R5RS and low-level macro systems
  of Scheme into a syntax-case system. Syntax-case transformers operate on an abstract data …"
- IMPLEMENTATION, INTEGRATION, AND APPLICATION OF...（W. G. Hatch, Utah 博士论文）— www-old.cs.utah.edu

## q4 — sets of scopes / mark-antimark（→ K31/K32 强锚）

query: `Racket macro expander sets of scopes implementation binding marks substitutes Dybvig`

- An Optimized R5RS Macro Expander（S. Reque 2013）— jeapostrophe.github.io — "The mark/antimark
  algorithm is the basis of the current implementation of R5RS and R6RS macros in Racket, Chez, Ika"
- MATTHEW FLATT 学术档案 — profiles.faculty.utah.edu — "expander tracks binding through a set of
  scopes that an identifier acquires from both binding forms and macro expansions"
- Fortifying macros（R. Culpepper）— www2.ccs.neu.edu

## q5 — expansion fixpoint / budget（→ K34 弱查降档——如实披露）

query: `iterative macro expansion fixed point expansion budget depth limit compiler front end`

- 全部命中无关内容（前端性能优化 / 循环优化教学页 / geeksforgeeks / tutorialspoint 等）——
  查询词域过泛。fixpoint 门 B 权威依据在内部：sop §18.3 + stage0 §9.25（r23 门 B 首证）+
  subset-spec §4「字节码全等限 fixpoint 链（1.7+ 门 B）」。沿 K15/q3[r23] 先例降档——不伪造锚。

## q6 — identifier equality semantics（→ K33 强锚）

query: `bound-identifier free-identifier equality syntax-case macro comparison semantics`

- A Few Principles of Macro Design — www.researchgate.net — 宏输入标识符按 free-identifier=? 比较
- Growing a Syntax（E. Allen, CMU）— www.cs.cmu.edu — "each language construct binding an
  identifier generates a unique identifier and maps the original bound identifier to the new one"
- COMPILE-TIME INFORMATION IN SOFTWARE...（Utah）— PLT Scheme macro system 基于 syntax-case
  （Dybvig et al. 1992）

## 存档清单

| 文件 | 主题 | 锚位 |
|---|---|---|
| q1-syntax-rules-matching.json | 匹配算法 + ellipsis | K27 |
| q2-hygiene-rename.json | 卫生改名族谱 | K28/K29 |
| q3-template-instantiation.json | 模板实例化 + syntax-case | K30 |
| q4-scopes-macro.json | sets-of-scopes + mark/antimark | K31/K32 |
| q5-expansion-fixpoint.json | 展开不动点（弱查） | K34（降档） |
| q6-identifier-equality.json | 标识符比较语义 | K33 |

# Stage 1.0 测试文档——kerf-typecheck 种子（E0xxx 注册面 + 保守静态 R1-R8 + 多错误收集）

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）+ §9.4.3 v15.1（易错分布全覆盖 + 分布论证义务）
> 双生文件：crates/kerf-typecheck/src/**（check.rs/code.rs/env.rs 内联）+ crates/kerf-typecheck/tests/api_tests.rs + tests/v1/stage1/plan/typecheck_seed_tests.rs（经 runner.rs）+ examples/audit/stage0_gate_audit_r1.rs M 节（§7.3.1 审计集单调增长 110→120）
> 设计依据：docs/develop/v1/stage-1-plan.md §3（R1-R8 权威定义 + 健全性论证）/§4（E0xxx 注册面）/§5（PBT 裁定）+ docs/stage0.md §9.24（TY-A 横切静态验证层——验证者非执行者）+ §9.25（BS-B 外部 Rust 检查器路径）+ §21.6（类型检查器循环依赖风险缓解）+ docs/sop.md §2.3-4（报错>静默）+ 原则 27（接口稳定性）

## 1. 目标

验证 Stage 1.0 的功能点（保守静态检查器——definite-error-only 健全性纪律）：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | E0xxx 诊断注册面 | `TypeCode`（E0001-E0008——variant-level `code() -> &'static str` 稳定字符串）+ `Severity`（Error/Warning 两级——R8 = 首个 Warning 生产者）+ `TypeDiagnostic{code, severity, span, message}`（R8 消息形态：小写开头、无句尾句号、载荷反引号——单源字典与 RuntimeError 族同源同译） |
| FP2 | Externals 外部名面 | `from_named_arities`（名→Option<元数>——Builtin::ALL 三元组构造）/ `from_names`（元数未知）/ `resolve` 三态（Some(Some(n)) 已知元数 / Some(None) 已知存在 / None 未知名）；单源纪律：kerf-typecheck 不复制 STAGE0_GLOBALS 清单（调用方构造——根集成/审计/driver 三消费位） |
| FP3 | R1 未绑定引用（结构层重断言） | 顶层即时位看 defines-so-far（letrec 预绑定镜像——Define 名先于值检查可见）；Fn 体内看全部 Defines（调用时 = 加载完成后——前向引用合法）+ 词法链（**不含外层 Fn**——镜像 `begin_closure` 全新 locals 表）；层间分工：展开器 UnboundIdentifier 第一道防线之外的结构层第二道防线（直接构造路径） |
| FP4 | R2 已知元数失配 | 三通路：(a) IIFE——Apply func = Fn 字面量（100% 确定）(b) Var → Define{Fn}（护栏：assigned 名单跳过[重绑可改元数] + 词法遮蔽跳过[局部元数未知] + 就近定义胜出[镜像 StoreGlobal 覆盖序]）(c) Var → 已知元数 External（Builtin）；消息镜像 VM ArityMismatch 措辞 |
| FP5 | R3 非布尔字面条件 + R4 不可调用字面被调者 | 字面量值确定（kind_name 族）；truthy 仅 Bool = 双引擎既定语义；call callee 不可调用 = VM type_mismatch 同源 |
| FP6 | R5/R6/R7 效应族（顶层即时位专属） | R6 未处理效应执行（模块加载期无动态上下文——词法 Handle 为唯一可能）+ R5 处理器元数失配（最近词法 Handle 路由 + Fn 字面量/无重绑 Define→Fn 元数）+ R7 不可调用字面处理器；**Fn 边界截断**：Fn 体内 Perform 不做 R5/R6/R7（调用时动态处理器不可知——健全性关键）；Handle 编译序镜像（handler 值先求值[outer 栈]→安装→body[含本层子句]→pop） |
| FP7 | R8 赋值目标意外（Warning 级） | (a) 目标 ∉ locals ∧ ∉ Defines → 隐式建全局警告（仅直接构造路径可达——展开器已拒绝同形态）(b) 目标 ∈ Externals → 重绑内建警告（合法但几乎必为 bug）；不阻断（保守纪律：仅确定错误可 Error 级） |
| FP8 | 多错误收集（架构属性） | `check_module → Vec<TypeDiagnostic>` 逐节点全量遍历不短路；一程序多错全收集（裁定二十一：架构属性非 E 码槽位）；错误后继续（无毒化——R1 报错后同程序其他规则照常） |

**落位与依赖方向**：crates/kerf-typecheck/（L4.5——kerf-core 之后 compiler 之前）；依赖 = kerf-span + kerf-core 两条内部边（§18 零新外部依赖——std-only 维持）；reserved 零入边维持（裁定十七不触及）。

## 2. 场景

- **正向**：干净程序零诊断（fib 全链——真实管线 read→expand→typecheck）；IIFE 元数匹配；builtin 调用元数匹配（`(+ 1 2)`）；Fn 体内前向引用后定义（合法——`(define f (fn (x) (g x))) (define g ...)`）；顶层 Handle 内 Perform 路由正确；handler 元数匹配；Externals 三态构造与解析；TypeCode 八码稳定字符串；api 再导出面可达
- **负向**：R1 顶层未定义引用（直接构造）+ R1 Fn 体内未知名 + R1 前向引用在顶层即时位（直接构造）；R2 三通路失配各一（IIFE/Define→Fn/builtin）+ 护栏放行（assigned 名跳过 + 词法遮蔽跳过 + 未元数 External 跳过）；R3 五种非 Bool 字面（int/float/string/nil/pair）；R4 六种字面被调者；R5 处理器元数失配（Fn 字面量 + Var→Define 通路）；R6 顶层裸 Perform + R6 Fn 体内放行（健全性——动态处理可能）+ R6 顶层 Handle 覆盖效应放行；R7 字面处理器；R8 两形态警告；多错误收集 ≥2 诊断同程序；消息 R8 形态断言（小写开头/无句尾句号/反引号载荷）
- **跨阶段消费**：kerf-typecheck（L4.5）→ 根 tests/（typecheck_seed_tests 经 runner.rs——真实管线消费：kerf-reader 读源 → kerf-expander 展开 → kerf-typecheck 检查，Externals 从 kerf_expander::STAGE0_GLOBALS + kerf_vm::Builtin::ALL 构造）+ → examples/audit M 节（根 example 位置消费链）；767 基线零回归（加法纯新 crate）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | check.rs（R1-R8 逐规则直接构造）+ code.rs（注册面 + 消息形态）+ env.rs（Externals 三态） | ~20 | ~26 |
| API 面 | crates/kerf-typecheck/tests/api_tests.rs | ~5 | ~3 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_seed_tests.rs（真实管线 + 双构造混合） | ~7 | ~7 |
| **测试合计（目标）** | | **~32** | **~36** |
| §7.3.1 审计集 | M 节 10 case（110→120） | M01 干净程序 + M08/M09/M10 | M02-M07 |

**分布论证**（§9.4.3 v15.1）：易错密度 = 负向路径（健全性护栏——Fn 边界截断/assigned 护栏/遮蔽跳过/三态 Externals——检查器自身误报 = P0 级缺陷，故负向密集覆盖）+ 消息形态（R8 纪律逐条断言）；正向面 = 规则存在性 + 干净程序零误报（健全性的另一半：合法程序永不告警）。正负比 ~1:1.1——负向占比与 0.3 reader 轮（错误面轮）同族。集成构成：正向 ≥1 ✓（干净程序 + 管线正例）/ 负向 ≥3 ✓（规则负向经真实管线）/ 跨阶段消费 ≥1 ✓（read→expand→typecheck 全链 + Externals 双源构造）。

## 4. 健全性护栏（本 FP 特有——误报 = P0）

检查器的**合法程序永不告警**义务与**确定错误必报**义务对偶测试：
- 合法程序零诊断族：fib/闭包/Handle 路由/前向引用（Fn 内）/shadowing/assigned 重绑——每形态 ≥1 断言 `diagnostics.is_empty()`
- 确定错误必报族：R1-R7 每规则 ≥1 直接构造 + ≥1 经真实管线（可行者）
- 护栏放行族：Fn 边界截断（Fn 内 Perform 无词法 Handle → 不报）/ assigned 名 / 词法遮蔽 / 未元数 External——放行本身 = 断言目标（漏放行 = 误报 = P0）

# lexer-parity — Stage 1.5 第二段测试文档（词法层全链 parity）

> 依据：docs/tests/README.md 双向印证表 + plan-1.5b.md §3 + stage0.md §9.86
> 承载：tests/v1/stage1/plan/lexer_parity_tests.rs（22 函数）+ crates/kerf-driver/src/lexer_parity.rs 内联单测位 + audit R11-R20

## 1. 目标

字节表 → lexer.krf → reader.krf 全链，对 Rust reader oracle 三轴（token / 树 / 错误 key）双引擎逐字节一致；词法决策全 .krf 化的语义安全网。

## 2. 场景与统计

| 族 | 场景 | 数 |
|---|---|---|
| 正向 | 混合程序 / 富夹具（BOM+CJK+VT）/ 数值边界 / 空与纯注释 / Unicode 空白全表 / 嵌套 255·256·257 / 双定点（VM 面） | 8 函数 |
| 负向 | 词法拒绝 13 key / 溢出 4 / C1 符号 / 结构 4 / 篡改 4 / 缺陷分类 / 报告面 | 9 函数 |
| 跨阶段 | 语料 85 全扫（读取期拒绝 ≥5）/ 边界 4 件 / 包络双守卫 | 3 函数（含 85 内联案） |

## 3. 覆盖依赖

- 上游：reader-parity.md（第一段——结构层，本链原样消费 reader.krf）；subset_corpus（85 输入面）。
- 下游：expander-parity（前端全链的下一站——2.4 窗差分收敛将消费本链产物）。

## 4. 已知边界（如实登记）

- eval 双引擎包络 ~1.05k token / 最长单段 trivia ~2.05k 字节（每 token ~2 帧）；越界面以 `reader_parity_full_vm` 承载并披露（K165/K166）；语料清扫自动转换（bracketed ≤2）。
- K20 永久宿主层两件不经 .krf：f64 值面（parse + is_infinite 拒绝）与串载荷解码——决策面（边界/校验/分类）全 .krf。

# Stage 1.2 — PBT 种子测试文档（pbt.md）

> **Status**: Delivered（1.2 执行轮落档）
> 依据：docs/sop.md §9.2（测试文档先行）+ §9.4.3 v15.1（易错分布全覆盖 + 分布论证义务）+ docs/stage0.md §9.34.5（MRES-E-1 六类不变量清单——三类先行）+ docs/develop/v1/stage-1-plan.md §2 行 1.2 + §5（PBT §18 裁定：DEFER-WITH-TRIGGER → 1.2）
> 消费面：tests/v1/stage1/plan/pbt_seed_tests.rs（经 tests/runner.rs `#[path]` 挂载——§8.4.6 v11.2）

## 1. 功能点（FP1-FP7 = 七属性，三类不变量）

| FP | 属性名（proptest! 块） | 不变量类（§9.34.5） | 断言形态 |
|----|------------------------|---------------------|----------|
| FP1 | `wellformed_programs_agree_across_engines` | ① 8 原语 eval 正确性（双引擎 oracle 交叉验证） | 任意良构值程序：eval 与 VM 双引擎 `values_agree && outputs_agree && globals_agree`（ParityReport 三面全过） |
| FP2 | `unhandled_perform_traps_both_engines_at_runtime` | ①（E0006 运行时面——确定性错误对偶） | 任意效应名/任意 int args 的 `(define r (perform e …))`：Evaluator 与 VM **各自**报 `UnhandledEffect`（非顶层即时位——R6 静态面不适用，运行时陷阱面） |
| FP3 | `handled_perform_reduces_to_handler_body` | ①（Handle 归约语义 + 算术组合 oracle） | `(handle (perform e0 <int-expr>) (e0 (fn (v) (+ v k))))`：双引擎值 repr == `<int-expr> + k` 的宿主 checked_add 结果（归约语义 + 具体 oracle 双断言） |
| FP4 | `top_level_bare_perform_is_a_static_e0006` | ② Reader 往返族的跨阶段消费位（1.1 R6 静态面的属性化） | 任意效应名的顶层裸 `(perform e …)`：driver 管线 `typecheck()` 产出携带 `TypeCode::TopLevelUnhandledPerform`（E0006）的诊断（1.1 有限样例 → 属性全域） |
| FP5 | `read_image_is_a_fixed_point_of_display` | ② Reader 往返（不动点口径） | 任意良构 StxDatum：`d₁ = read(display(d))` 后 `read(display(d₁)) == d₁`（read 的像域在 `display∘read` 下闭合；结构不动点） |
| FP6 | `vm_double_run_is_deterministic` | ③ VM dispatch 确定性 | 任意良构程序编译一次、两个独立 `Vm` 实例分别 `run()`：结果 repr 严格相等（无隐藏状态） |
| FP7 | `integer_addition_matches_host_oracle` | ①（具体数学 oracle——防双引擎同错） | 任意 int 对 `(a, b)`（限域 ±2⁴⁰）：`(define r (+ a b))` 双引擎值 == 宿主 `a.checked_add(b)`（含溢出 fail-closed 域外对偶——限域内恒 Some） |

**三类先行映射**（stage-1-plan §5 裁定——§9.34.5 六类的第 ①②③ 类即刻采纳；④ GC mark-sweep / ⑤ HM 推断 / ⑥ 效应行 soundness 归 1.3+ 有真实消费面时引入）：
- ① → FP1 / FP2 / FP3 / FP7（四属性：相对 parity + 确定性错误对偶 + 归约语义 + 具体 oracle）
- ② → FP5（不动点口径——见 §3 口径申报）+ FP4（reader→typecheck 跨阶段消费）
- ③ → FP6

## 2. 生成器域（typed generation——良构子集构造）

| 生成器 | 域 | 域约束理由 |
|--------|-----|-----------|
| `arb_stx_datum` | Symbol（安全名池 `x0..x9`/`y0..y9`/`e0..e3`/`f0..f3`——零关键字/零内建冲突）/ Int（±2⁴⁰）/ Float（有限 + `format!("{v:?}").parse()` 往返）/ Bool / String（可打印 ASCII 且不含 `"` `\` 与控制字符）/ List（深度 ≤5、宽度 ≤4） | 名池避开关键字（`fn`/`if`/`let`/`do`/`set!`/`perform`/`handle`/`define`）与 18 内建；Float 域过滤保证 Debug 形态可被 reader 十进制解析精确回收；String 域避开转义差（Rust `{:?}` 的 `\u{}` 转义 vs reader 的 `\"`/`\\`/`\n`/`\t`/`\r` 子集） |
| `arb_wellformed_program` | 顶层 `(define r0 <vexpr>) … (define r3 <vexpr>)`，`vexpr` 三通道 typed 递归（Int 通道：int 字面量 / `(+ ie ie)` / `(- ie ie)` / `(if be ie ie)` / `(let ((xᵢ ie)) ie)` / `(do ie ie)` / `((fn (xᵢ) ie) ie)` / `(handle (perform e0 ie) (e0 (fn (v) v)))`；Bool 通道：`#t`/`#f` / `(= ie ie)` / `(< ie ie)` / `(not be)` / `(eq? av av)`；Any 通道：Int/Float/Bool/String/`nil` / `(cons av av)` / `(pair? av)` / `(if be av av)`）；深度 ≤4、define 数 ≤4 | 顶层必须 define 包装（快照轮冻结事实：顶层裸表达式被拒绝）；Int 通道禁 `/`（除零）且限域 ±2⁴⁰ + 深度帽 → checked 算术不可能溢出；typed 三通道保证生成程序零 TypeMismatch/零 ArityMismatch（良构 = parity 属性的可判定域）；`(handle … (e0 (fn (v) v)))` 子句保证 perform 一参恒匹配 handler |
| `arb_perform_tail` | 效应名 `e0..e3` × int args 0..2 个 | FP2 域：任意效应名（非 handler 域名）+ 任意 args 形态 |
| `arb_int_pair` | `(i64 in ±2⁴⁰) × (i64 in ±2⁴⁰)` | FP7 oracle 域：限域内 `checked_add` 恒 `Some`（溢出对偶由 FP1 生成器域约束承接） |

## 3. 口径申报（诚实披露——不变量的精确定义）

1. **FP5 不动点口径**：`StxDatum::Display` 是**诊断/快照渲染面**（0.9 起的既定用途），不是序列化面——`Bool` 打印 `true`/`false` 而 reader 只认 `#t`/`#f`，故 `read(display(Bool))` 进入 `Symbol("true")` 像。属性口径因此定为**不动点语义**（read 的像域在 `display∘read` 下闭合）而非 `read∘display = id`（display 非 reader 逆是设计事实非缺陷；若未来需要序列化往返，属 Stage 1+ `.krf` 序列化议程——plan-1.2.md 决策登记）。
2. **FP2 运行时面**：`(define r (perform e0 …))` 的 perform 位于 Define 值位（非顶层即时位），R6 静态面不适用（1.1 裁定：R6 仅顶层即时位）→ 属性走运行时双引擎各自断言 `UnhandledEffect`（绕过 driver 管线的 typecheck 前置——底层 API 直连）。
3. **FP4 静态面**：顶层裸 perform（无 define 包装）在 driver 管线被 R6 拦截（E0006 abort-before-execution）——FP4 断言的是 1.1 R6 有限样例的属性化扩展（任意效应名全域）。
4. **良构域的可达性**：`arb_wellformed_program` 是**类型正确子集**（typed generation），不覆盖「必然运行时错误的程序」——错误路径由 FP2（确定性错误）与既有 130 case 审计集（A-N 十四节穷举错误族）承接；PBT 与样例测试互补而非互替（§9.4.3 v15.1 全覆盖义务的正负分工）。

## 4. proptest 配置

- cases：64/属性（七属性共 448 case——与 231 root 集成并行运行时长可控；RUST_MIN_STACK 环境参数下深度 ≤5 生成树安全）
- max_shrink_iters：默认（失败时收缩至最小用例——shrink 是 proptest 的核心价值）
- 种子失败复现：`PROPTEST_DEBUG` 环境（proptest 标准面）

## 5. 实测回填（§3 实测——执行后回填）

| FP | 用例数 | 结果 | 收缩发现 |
|----|--------|------|----------|
| FP1-FP7 | 64 × 7 = 448 | 448 全过（1.2 净 +9 测试函数：7 属性 + 2 生成器域自检） | 无失败收缩（首轮即绿——typed generation 域零违例） |

## 6. 与审计集的关系

PBT 不入 `stage0_gate_audit_r1`（audit = 确定性样例审计集，PBT = 属性层基础设施——1.2 裁定：audit 130/130 维持不扩节；§7.3.1 门审 ≥30 case 构成义务由既有 A-N 承接，PBT 是**第四层**测试面（快照/黄金/自举/属性——DEA-13 闭合的完整四层）。

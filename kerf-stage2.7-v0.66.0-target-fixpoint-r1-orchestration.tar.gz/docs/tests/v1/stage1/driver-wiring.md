# Stage 1.1 测试文档——driver 接线（typecheck 级入管线 + 诊断渲染映射 + Warning 接线）

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）+ §9.4.3 v15.1（易错分布全覆盖 + 分布论证义务）
> 双生文件：crates/kerf-driver/src/{pipeline,diagnostic,render,cli,repl}.rs 内联 + tests/v1/stage1/plan/typecheck_wiring_seed_tests.rs（经 runner.rs）+ examples/audit/stage0_gate_audit_r1.rs N 节（§7.3.1 审计集单调增长 120→130）
> 设计依据：docs/develop/v1/stage-1-plan.md §2 行 1.1（driver 接线权威定义）+ §4 末段（E0xxx 与 driver DiagnosticCode 在 1.1 接线处汇合——非 typecheck crate 内）+ docs/stage0.md §8.7（四级 Severity 契约——driver 面）+ docs/sop.md §2.3-4（报错>静默——R8 警告级实现）+ §12.2（错误是数据——收集后一遍渲染）+ 原则 27（接口稳定性）

## 1. 目标

验证 Stage 1.1 的功能点（检查器入管线——`read → expand → typecheck → {compile, eval}`）：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | 诊断映射（driver ↔ checker） | `DiagnosticCode::Typecheck(TypeCode)`（数据携带变体——tag() = E0xxx 注册码）+ `Diagnostic::from_typecheck`（Severity Error/Warning → driver 同名级；span → primary_span；message 逐字透传——R8 单源字典，driver 永不改写阶段消息）+ 渲染形 `error[E0002]:` / `warning[E0008]:`（rustc 风格 E 码） |
| FP2 | 管线级接线 | `ParsedProgram::typecheck()`（Externals 单源构造：STAGE0_GLOBALS 名 + Builtin::ALL 元数三元组——driver 第三消费位）+ `check()/run()/run_parity()` 前置 typecheck 阶段：**Error 级 → Err 中止**（确定错误程序不执行——静态检查的净新增值）+ **Warning 级 → 附加 Outcome 不阻断**（合法但可疑——§2.3-4 警告级）+ 收集不短路（typecheck 全量 + compile 诊断追加——§12.2 错误是数据） |
| FP3 | Outcome 警告通道 | `RunOutcome.warnings` / `CheckOutcome.warnings` / `ParityReport.warnings`（Vec<Diagnostic>——成功路径的警告载体）；846 基线既有调用方零破坏（字段追加——结构体字面量构造位同轮更新） |
| FP4 | 渲染扩展（Warning 摘要行） | 多诊断批次：警告计数 > 0 → `warning: N warning(s) emitted`（abort 行之前——rustc 惯例序）+ abort 行门控修正（errors ≥ 1 才打——纯警告批次不再打误导性 aborting 行）；**零警告批次字节不变**（ds10 黄金零回归——快照冻结义务） |
| FP5 | CLI 面 | `check`：警告渲染至 err 汇 → `ok: ...` 至 out（警告非阻断——退出码 0 维持）；`run`：警告至 err → 程序输出至 out；`run --parity`：警告至 err → parity 结果；退出码语义零变更（警告不影响退出码） |
| FP6 | REPL 面（Warning 增量） | `ReplEvent::Evaluated.warnings`（渲染后的**新增**警告——与 outputs 同前缀规则增量：会话重放全程序重跑，同警告不重复打印）+ 确定错误走既有 Error 回滚路径（提交不进入累积程序）；警告提交**进入**累积程序（合法——回滚仅错误） |
| FP7 | 快照共变（ds08） | workspace 版本 bump 0.13.0 → 0.14.0 → ds08 黄金同轮更新（共变义务第二例——0.11 首例先例） |

**落位与依赖方向**：crates/kerf-driver/（L8——管线编排层）；新内部边 = kerf-typecheck → kerf-driver（L4.5 → L8——消费边，无环：typecheck 依赖 core+span，driver 依赖 typecheck+syntax+reader+expander+compiler+vm+runtime）；§18 零新外部依赖维持（std-only）；reserved 零入边维持。

## 2. 场景

- **正向**：干净程序全链零警告（fib——run/check/parity 三面 + 双引擎）；警告程序照常执行（`(set! car 1)` 后值仍产出——非阻断实证）；check 面干净程序 ok 行 + 计数（零回归）；REPL 警告提交后值打印 + 后续提交不重印同警告（增量实证）；单警告批次无摘要行（len>1 规则维持）
- **负向**：E0002 经 run_source（源码可达——`(f 1 2)` 元数失配）+ E0003（`(if 1 2 3)` 字面条件）+ E0004（`(define two 2)` 后 `(two 1)`——R4 扩展终态通路）+ E0006（顶层即时位裸 perform——define 值位）+ E0008 警告（`set!` 内建重绑——源码可达唯一形态）；确定错误中止执行（副作用不发生——`(write-line "x")` 在确定错误程序中零输出）；多错误收集经 driver（E0003+E0002 同批 Err）；渲染形断言（`error[E0002]` + `--> file:line:col` 位置行 + 摘要行）；纯警告批次摘要（2 警告 → `warning: 2 warnings emitted` 且无 aborting 行）
- **跨阶段消费**：kerf-typecheck（L4.5）→ kerf-driver（L8 管线第三消费位——Externals 双源构造 + check_module + Severity 映射）→ 根 tests/（真实源码文本 → 全管线 → 渲染字符串断言）+ audit N 节（E2E 十案）+ ds08 快照（版本共变）；846 基线零回归（加法——既有路径零语义变更：零警告批次渲染字节不变 + 退出码不变 + REPL 既有行为不变）

## 3. 预期数（三层 + 审计集——实测回填）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | pipeline.rs（接线 + Outcome 警告通道 + 中止语义）+ diagnostic.rs（映射 + tag）+ render.rs（警告摘要 + 门控）+ cli.rs（三命令警告路径 + 退出码）+ repl.rs（增量警告 + 回滚） | 12 | 13 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_wiring_seed_tests.rs（源码可达 E0xxx 全链 + 渲染黄金 + REPL + CLI） | 5 | 5 |
| **测试合计（实测）** | | **17** | **18** |
| §7.3.1 审计集 | N 节 10 case（120→130 实测全过） | N05/N06/N10 | N01-N04/N07-N09 |

**实测分布**（§9.4.3 v15.1 回填）：净 +35 = 正向 17 / 负向 18（1:1.06——三族护栏对偶均衡：非阻断义务[警告程序照常执行/值通道不动/退出码 0] ↔ 中止义务[确定错误执行前中止/副作用零发生] + 渲染回归面[零警告批次字节不变/摘要门控] + 增量语义[不重印/不丢印]）。**基线共变 5 处**（行为变更披露——检查器前置使已知元数错误静态化）：pipeline.rs arity 运行期面测试改 checker-opaque 形态（`((fn (g) (g 1 2)) car)` 参数中介——R2 护栏正确跳过）+ driver_seed e2e 同族 + snapshot ds03 黄金更新（E0002 静态形 + 运行期面注释锚）+ audit I04 同族 + ds08 版本黄金（0.14.0 共变义务第二例）。实现侧发现 1 项设计级验证：REPL 语境下 `(set! car 1)` 重绑使后续 `(car 1 2)` 的 R2 正确跳过（assign 护栏跨提交生效——保守纪律实证，语料改用未重绑的 `cons`）。

## 4. 接线护栏（本 FP 特有——两侧都不可失）

- **非阻断义务**（警告侧）：Warning 级永不改退出码、永不阻止执行、永不清空值通道——每形态 ≥1 断言（值仍产出/ok 行仍打/退出码仍 0）
- **中止义务**（错误侧）：Error 级必在执行前中止——副作用零发生断言（write-line 在确定错误程序中无输出）
- **零扰动义务**（基线侧）：零警告批次 render 字节不变（ds10 黄金 + 内联回归）；既有 CLI/REPL/parity 行为零变更（既有测试零修改预期——除结构体字面量构造位与 ds08 共变位）

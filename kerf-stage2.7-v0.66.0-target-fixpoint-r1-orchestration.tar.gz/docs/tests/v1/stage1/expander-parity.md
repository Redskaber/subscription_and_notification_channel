# expander-parity — Stage 1.6 双 Expander parity 测试文档

> 对应测试：tests/v1/stage1/plan/expander_parity_tests.rs（经 tests/runner.rs 挂载）+ crates/kerf-driver/src/expander_parity.rs 内联单测 + examples/audit S 节
> 设计依据：docs/stage0.md §9.47（EX-1..EX-5）+ docs/develop/v1/stage-1/plan-1.6.md
> 先行声明：本文档于实现前落盘（§9.2 纪律——1.5 回填偏差不重演）；实测数字以交付轮回填为准

## 1. 测试目标

验证 selfhost/v1/expander.krf（冻结子集书写的展开层）对 Rust oracle（kerf_expander::expand_program + load_program）的行为等价：树轴（ModuleItem/CoreExpr 同构 dump 全等）+ 错误轴（kind/payload/span 选择一致——消息经同一 Display 重建，字节 parity 由构造）+ 双引擎前提（compile→VM 与 eval 解码一致）。

## 2. 覆盖场景

| 族 | 场景 | 断言 |
|---|---|---|
| FP1 表格编码往返 | Reader 输出 → 节点记录形 → 表格前缀 → expander.krf 消费 | 72 语料逐案 matched |
| FP2 三层分流 | Reader 层 6 案（读拒绝即定案）/ Macro 层 2 案（pos-024/bnd-010 oracle 定案）/ Expander 层 64 案 | 层计数分布底线 + 每层判定来源正确 |
| FP3 树轴 | ModuleItem 四变体 + CoreExpr 九构造子 + LiteralValue 六形态 dump 全等 | dump 字符串全等 |
| FP4 错误轴 | TopLevelExpression / MalformedForm{7+} / UnboundIdentifier / QuoteUnsupportedDatum / ModuleDuplicate / ModuleCycle（新 neg-048）/ ModuleNotFound（新 neg-049） | kind+payload+span 重建一致 |
| FP5 span 七陷阱 | ★1 quote 整 form span / ★2 fn 糖 Fn=name 原子 / ★3 Binding=值节点 / ★4 do 恒等 / ★5 set! Unbound=name 原子 / ★6 HandlerClause=clause list / ★7 require 符号名 MalformedForm | 逐陷阱锚定断言 |
| FP6 绑定纪律 | let\* 渐进（后值见前名）/ define 前绑定（递归自身名）/ module 帧隔离（外层名不泄入）/ 无跨 define 互递归（前向引用拒） | 语料 + 定制案 |
| FP7 语料全扫重放 | 72 案动态目录扫（含新 4 案） | 全 matched + 分布底线 |
| FP8 篡改探测器 | 篡改 .krf 输出模拟漂移 | drift 捕获（缺陷即数据非 panic） |

## 3. 用例口径分布论证（§9.4.3 v15.1）

语料 72 = pos 28 / neg 34 / bnd 10（1:1.21 语料域）；错误轴负向族 7 类（malformed 族 + unbound + quote-datum + top-level + module 族）≥ 6 类有负向覆盖；深树面（bnd-006/007）沿 reader parity deep_stack 环境口径。

## 4. 依赖

kerf-driver（parity 宿主）+ selfhost/v1/expander.krf（被测物）+ tests/v1/stage1/corpus/（72 案）+ examples/audit（S 节）。

## 5. 维护

语料增删 → 动态目录扫自动收编（分布底线断言随之更新）；1.7 宏面落地后 Macro 层 2 案迁入 Expander 层（分流收缩登记）。

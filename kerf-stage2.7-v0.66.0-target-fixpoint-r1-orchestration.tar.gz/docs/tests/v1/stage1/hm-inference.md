# Stage 1.3 — HM 推断基座测试文档（hm-inference.md）

> **Status**: Delivered（1.3 执行轮落档）
> 依据：docs/sop.md §9.2（测试文档先行）+ §9.4.3 v15.1（易错分布全覆盖 + 分布论证义务）+ docs/stage0.md §9.44.4（HM 基座选型——迭代 W + union-find 无 levels 无回滚 + If 汇聚 Dyn + assigned 守卫泛化 + 数值域 ad-hoc + 效应行收集面）+ §9.30 REC-A A6（迭代 + 512 预算谱系）+ docs/develop/v1/stage-1-plan.md §2 行 1.3
> 消费面：crates/kerf-typecheck 内联测试（types.rs / infer.rs / code.rs）+ tests/v1/stage1/plan/hm_inference_seed_tests.rs（经 tests/runner.rs `#[path]` 挂载——§8.4.6 v11.2）+ examples/audit P 节（130→140）
> 设计依据：plan-1.3.md（§13.1 设计回写闭环——stage0.md §9.44.4 = 权威设计锚）

## 1. 功能点（FP1-FP8）

| FP | 名称 | 断言形态 |
|----|------|----------|
| FP1 | 推断正例（类型标注正确性） | 良构程序：`infer_module` 零诊断 + TypedProgram 标注精确（`fib : (forall () (fn (int) int))`、pair 构造/投影、嵌套 fn、let 链、quote 字面量 pair 类型递归） |
| FP2 | 多态实例化 | `(define id (fn (x) x))` 后 `(id 1)` 与 `(id #t)` 同模块双用：零诊断（泛化解耦两用）；let 绑定 Fn 字面量同判（let 多态）；`(id (id 1))` 嵌套实例化标注 `int` |
| FP3 | 确定类型错误族（E0009） | 算术混合 `(+ 1 2.0)` / `(- #t 1)`、比较混合 `(< 1 2.0)`、非数值比较 `(< #t #f)`、`car` 非 pair `(car 1)`、`not` 非 bool、`write-line` 非 str、if 条件确定非 bool（经 define 汇聚 `int`）、函数参数位失配（`(fn (n) (+ n 0))` 传 `#t`）——全部 `TypeCode::TypeMismatch`（Error 级） |
| FP4 | 递归类型（E0010） | `(define omega (fn (x) (x x)))` 自应用：`RecursiveType`（Error 级）；`(fn (x) (cons x x))` 合法对照零诊断 |
| FP5 | 预算守卫（E0011 Warning） | 600 层 if 嵌套（>512 预算）：单条 `InferenceBudgetExceeded` **Warning**（永不 Error——合法深程序必须可运行）+ 该 define 排除出 TypedProgram + 其余 define 照常推断；250 层（预算内）零诊断对照 |
| FP6 | 合法程序永不告警（负负对偶） | 运行期动态合法形态静态零诊断：if 分支异型汇聚（`(if c 1 #t)` : dyn）、未知流经（Dyn 吸收）、assigned 重绑后任意使用、多态复用、Fn 体内前向引用、`(fn (x) (x 1))`（参数被调用——x : dyn 无害）——**健全性对偶：确定错误必报 × 合法程序永不告警** |
| FP7 | 效应行收集面 | `(perform log 1)` 行追加 `log`；Handle 差集（handled 效应从行中消除）+ handler 体效应并集（过近似）；嵌套 Handle 残差；行确定性（有序去重）|
| FP8 | 快照 IS 族（dump_typed 黄金） | 固定输入 → `dump_typed` 确定性渲染逐字节黄金（6 case：算术/多态/pair/效应/if 汇聚/let 链）——双层跑（同进程两实例）严格相等 |

## 2. 分布论证（§9.4.3 v15.1）

推断面的**易错分布**（校准历史 + 领域特性）：

1. **合一失败路径**（FP3 + FP6）——密度最高：每个 `unify` 分支（concrete×concrete 8×8 组合中 7/8 失败 + var 绑定 + Dyn 吸收 + occurs）都是独立错误类；负负对偶（合法程序不误报）与正向（确定错误必报）**等权重**——健全性双向都是缺陷面。
2. **泛化/实例化**（FP2）——中密度：schema 量化集与实例化新变量的解耦是经典出错点（过泛化 = 误报源；欠泛化 = 误报源[假阳性]——两方向都要测）。
3. **预算边界**（FP5）——边界值分析：512 内零诊断 / 512 外单 Warning 永不 Error（预算耗尽是检查器局限非程序错误——E0011 severity 的设计判定本体）。
4. **效应行**（FP7）——收集面（非行合一）：差集/并集/传递三操作各一负向（漏收集 = 标注缺失）。
5. **快照确定性**（FP8）——新 dump 面的回归锚。

**口径申报**：①行收集面不含被调函数体的效应传递（call 不吸收 callee 行——1.3 收集面边界，行多态 = Stage 2+ TY-C 窗——stage0.md §9.44.4 第 4 点）；②E0011 挂 define 级（超预算 define 整体跳过，不产半标注树——诚实不产部分标注）；③推断器在 R1-R8 之后独立运行（双收集不短路——诊断聚合归消费方）；④E0009/E0010 消息形态镜像 RuntimeError::TypeMismatch 单源字典族（R8）；⑥字面量 pair 链深于 64 层折叠尾为 Dyn（线性链不受 reader 256 嵌套帽约束——口径申报）；⑤数值域 ad-hoc（+ - * / < <= > >= = 同族同型判定——两参已知同类→结果类；异类→E0009；任一未知→dyn）不引入类型类（stage0.md §9.44.4 第 3 点）。

## 3. 实测回填（执行后回填）

| 层 | 文件 | 用例数 | 结果 |
|----|------|--------|------|
| 内联单元 | kerf-typecheck types.rs（9）+ infer.rs（13）+ code.rs（注册面扩展 4 既有函数） | 22 | 22 过（links/回滚 + 合一表[含 Dyn 吸收不约束] + occurs + 深resolve + 字面量链 64 层折叠 + join + 泛化首见序/实例化新鲜性 + 显示形态 + 行代数） |
| 根集成 | hm_inference_seed_tests.rs（含 IS 快照 7） | 41 | 41 过（FP1 正例 6 + FP2 多态 3[even/odd 互递归走直接构造——源路径展开器 define-so-far 严格，探针披露] + FP3 确定错误 8 + FP4 occurs 2 + FP5 预算 3 + FP6 合法永不告警 6[含分支绑定隔离健全性案] + FP7 效应行 4 + FP8/IS 快照 7 + 跨层协作 2） |
| 审计 P 节 | examples/audit P01-P10 | 10 | 10 过（E2E：mismatch/occurs/budget/poly/guard/rows/adhoc/dyn/multi/determinism） |
| **净增** | | **+63**（890 → 953） | audit 130 → 140 |

# Stage 1.5 — Reader parity 种子测试文档（reader-parity.md）

> **Status**: Delivered（1.5 执行轮落档——**回填申报**：本文件按 §9.2 应先行，实际先落实现后回填；时间序偏差如实登记，内容序（功能点/分布论证/口径）与先例行等价）
> 依据：docs/sop.md §9.2 + §9.4.3 v15.1（易错分布 + 分布论证）+ docs/stage0.md §9.46.4（RS-1..RS-4 实施设计——本文件是其测试面）+ docs/develop/v1/stage-1-plan.md §2 行 1.5
> 消费面：crates/kerf-driver/src/reader_parity.rs（内联单测 7）+ tests/v1/stage1/plan/reader_parity_tests.rs（根集成 16——经 tests/runner.rs `#[path]` 挂载）+ examples/audit/stage0_gate_audit_r1.rs R 节（10）

## 1. 功能点（FP1-FP8）

| FP | 名 | 断言形态 | 层 |
|----|-----|----------|-----|
| FP1 | 树轴 parity（字节精确 span） | .krf 结构层 Reader 的 `("ok" forms…)` 结果（双引擎各跑一遍、堆行走归一化）与 Rust oracle `SyntaxObject` 树归一化 dump **逐字节相等**——含全部 span 端点 | 单测 + 集成 + audit R01/R06 |
| FP2 | 错误轴 parity（四拒绝类逐字节） | .krf 结构化错误值 `("err" kind payload…)` → 宿主重建 `ReadError` → 走 oracle 同一 `Display`——**渲染由构造保证**，被测非平凡面 = kind + payload 选择（最内层 `(` / 空表先于外层未闭合 / 左到右降序优先 / 进入时计数 257 拒） | 单测 + 集成 + audit R02-R05 |
| FP3 | 词法层分流（六变体域） | lexer 拒绝的输入（UnterminatedString/InvalidEscape/InvalidBool/MalformedNumber/InvalidSymbol/UnexpectedCharacter）→ `ParityLayer::Lexer` 路径：oracle 词法错误即 harness 判定，.krf 层不被调用（第二段窗口域——分层归属登记非 parity 缺口） | 单测 + 集成 + audit R07 |
| FP4 | 深度边界（255/256/257） | 255/256 深合法（全树双引擎一致）+ 257 深拒绝于精确 payload `depth 257 limit 256`——迭代式显式栈设计使 eval 调用深度 = O(token 数)（§9.46.4 RS-2 选型论证的实证） | 集成 + audit R05/R06 |
| FP5 | 漂移探测器自检（篡改双锚） | ①unclosed payload 篡改为最外层 → 必须被捕获 ②nesting limit 篡改 256→255 → 256 深边界处必须漂移（探测器不能失败 = 证明不了任何东西——Q 节 detector-detects 先例） | 单测 + 集成 + audit R08/R09 |
| FP6 | harness 缺陷即数据（§12.2） | 篡改 reader 源产垃圾 → drift 报告非 panic（`harness defect:` 前缀） | 集成 + audit R10 |
| FP7 | 语料全扫（跨阶段消费） | Stage 1.4 的 68 语料文件全部作为 **Reader 输入面**重放：逐文件 parity 双层计数（parser ≥60 / lexer ≥2）——语料从「程序合法性判定面」升格为「Reader parity 输入面」 | 集成 |
| FP8 | 自举不动点 | .krf Reader 源自身经 Rust oracle 词法 + .krf 结构层重读——读己不动点（oracle 仍是 Rust reader——1.4 契约不变） | 集成 |

## 2. 输入域（RS 族 + 语料面）

| 域 | 用例 | 易错分布理由 |
|----|------|--------------|
| 正向树族 | 嵌套 span 锚（`(f (g 1) 2)`——parser.rs 单测锚逐字节）/ 多 form + 全原子类（int/float/bool/string/ident）/ 空源与纯注释源 / 串内转义与裸换行 / float 极值（`1e999`→inf——Debug 文本面）/ i64 边界（`i64::MIN`/`MAX`/前导零 `007`→7） | 原子类全枚举 + span 端点精确性 + Rust parse 语义边界（K20 域——宿主单源保证） |
| 负向结构族 | unclosed（顶层/嵌套最内层/第三 form 定位/多开表）/ unexpected-close（顶层/形后）/ empty-app（顶层/嵌套/深层/参数位/先于外层）/ 255·256·257 深度族 | 四拒绝类 × 位置变体 × 优先序（左到右降序）——错误轴的全部判定分支 |
| 词法层族 | 未终结串 / 非法转义 / 非法布尔 / 畸形数字 / 非法字符 `[` `` ` `` / 控制符 | 六变体域全枚举（分流路径验证） |
| 语料面 | 68 文件（pos 26/neg 32/bnd 10） | 1.4 交付物重放——真实程序形态的树 + 错误混合分布 |
| 自举面 | reader.krf 自身源（~100 token） | 不动点 + 长注释/字符串字面量真实负载 |

## 3. 口径申报（诚实披露）

1. **Float 载荷 = Debug 文本字符串**（非类型化字面量）：`inf`/`NaN` 无 .krf 字面量形态（`"inf"` 非数字形 → 词法为 ident），故**全部** float 以 Debug 文本承载、宿主侧 `parse` 回收（Rust f64 Display/parse 互逆保证精确）——§9.46.4 RS-1 的实施修正（登记于 §9.46.4 RS-1 段内与本文件）。
2. **词法层六变体 = 第二段窗口域**：第一段 parity 范围 = 结构层（四拒绝类 + 全树）；词法层拒绝的输入经 harness 分流直接采信单源 Rust 词法器判定——非 parity 缺口而是分段边界（§9.46.3 注记 B3 口径修正）。
3. **深度族测试线程栈**：eval 引擎是树走器——原生 Rust 递归随 kerf 调用深度增长；bnd-006 类深表（~1.3k token）在 debug 构建下超出默认测试线程栈 → 测试侧 `deep_stack` 辅助（768MB 显式栈线程，虚页按需分配零实成本）。harness 本体不包线程——栈需求由调用方声明（与 Task 19-b 环境参数注记同族——环境面非代码缺陷）。
4. **回填序**：本文件应先行（§9.2）而实际后补——时间序偏差登记；分布论证内容与先例行等价（诚实实录）。

## 4. 实测回填（执行后回填）

| 层 | 数 | 结果 |
|----|-----|------|
| 内联单测（reader_parity.rs） | 7 | 7 全过 |
| 根集成（reader_parity_tests.rs） | 16 | 16 全过（语料全扫 68/68 双层分布 parser 66 / lexer 2） |
| audit R 节 | 10 | 160/160 全过（150 → 160） |

## 5. 与审计集的关系

R 节入 `stage0_gate_audit_r1`（150 → 160——§7.3.1 rule 4 单调增长）；§7.3.1 门审 ≥30 case 构成义务由既有 A-R 十七节承接。内循环修正实录：括号平衡 3 处（lparen 分支提前闭合 / 三路分派嵌套错位 / if#4 未闭合）+ err 值尾端 improper 3 处 + bool 编码 `#true`→`#t` + 测试期望手算偏差 4 处（span 常量 ×2 / 层分布下限 / drift 措辞）——**实现侧运行语义缺陷 0**（全部为源拼写/编码/测试期望层，parity 面首轮即结构正确）。

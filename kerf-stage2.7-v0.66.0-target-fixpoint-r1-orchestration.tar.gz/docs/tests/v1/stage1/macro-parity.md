# macro-parity — Stage 1.7 宏面 parity + fixpoint 门 B 测试文档

> 对应测试：tests/v1/stage1/plan/expander_parity_tests.rs 宏面扩展（经 tests/runner.rs 挂载）+ crates/kerf-driver/src/expander_parity.rs 内联单测 + examples/audit T 节
> 设计依据：docs/stage0.md §9.48（MX-1..MX-6）+ docs/develop/v1/stage-1/plan-1.7.md
> 先行声明：本文档于实现前落盘（§9.2 纪律——1.5 回填偏差不重演）；实测数字以交付轮回填为准

## 1. 测试目标

验证 selfhost/v1/ **装配程序**（macro.krf 函数库 + expander.krf 展开循环——宿主源面拼接）对 Rust oracle（kerf_expander transformer.rs + expand.rs 宏调用点）的宏面行为等价：匹配/实例化判定面全等（含 mangled 记录解码后的卫生改名终名逐字节）+ 错误轴扩展（macro-mismatch）+ **fixpoint 门 B 双口径**（(a) 字节码全等——compile(expand_oracle(S)) == compile(expand_krf(S))；(b) 装配程序自应用幂等不动点）。

## 2. 覆盖场景

| 族 | 场景 | 断言 |
|---|---|---|
| MP1 装配契约 | macro.krf body + expander.krf body 源面拼接序 + 驱动式唯一性（result 定义仅在 expander.krf 尾） | 装配程序可解析 + 单文件口径（expander.krf 独立）自举不动点不破坏 |
| MP2 定元匹配 | Wildcard / Literal 文本比对（literal 非空表 pos-031）/ Var 绑定（含重复使用点节点）/ Atom 四型 / List 等长同构 / 首条命中规则胜出 / 全败 → macro-mismatch（neg-050） | 匹配决策序 oracle 全等 |
| MP3 实例化六步序 | 拼接 early-return（改名走查永不触碰）/ 世代+1 / span 同区间 / binder 碰撞改名（pos-033——trigger 三源 + fresh counter 分配 + pushed 配对退栈）/ active_rename innermost wins / Atom 拷贝 | 产物记录流 oracle dump 全等 |
| MP4 mangled 解码 | `("mangled" s e base counter)` → 宿主 `format!("{base}__macro_{counter}")` | 终名与 oracle 拼接名逐字节全等 + counter 分配序一致（单 instantiate 全局共享从 0 起 + trigger 避让） |
| MP5 注册期校验 | head/literals 形状（`_`/`...`/`nil` 拒）/ 子句恰 2 项 / pattern 必须 List / 单子句查重（neg-051）/ `...` fail-closed（neg-052）/ 保留名拒 | malformed `define-syntax` 文本 + span（声明形）逐字节 |
| MP6 宏域纪律 | 帧隔离（neg-053 module 域宏外用 → unbound）/ 声明序注册 / 使用点先于声明拒 / 核心形式平铺分派先于宏解析 | 分派序 oracle 全等 |
| MP7 深度计数镜像 | instantiate 走查零预算（合成模式绕过 ex-depth）/ re-expand 每层计 1（bnd-010 = 512 触顶同文本同 span） | 两引擎错误字节平价 |
| MP8 Macro 哨兵 | contains_define_syntax 分流删除后 sweep 断言 macro_layer == 0 | fail-closed：任何回归到 Macro 层的案例被计数断言抓获 |
| MP9 门 B 口径 (a) | 宏语料 9 案（pos-024/031/032/033 + bnd-010 + neg-050/051/052/053 的正路径部分 + 装配源自应用）compile(expand_oracle(S)) == compile(expand_krf(S)) | **Bytecode PartialEq 全等**（1.6 dump 全等升格——subset-spec §4 兑现） |
| MP10 门 B 口径 (b) | 装配程序消费自身装配源（macro.krf + expander.krf 拼接文本）产出 item 树 dump，再次展开仍同 dump | 幂等不动点（1.6 双面不动点三段版延展） |
| MP11 篡改探测器 | 篡改 mangled counter / 篡改匹配决策 / 篡改装配序 | drift 捕获（缺陷即数据非 panic） |

## 3. 用例口径分布论证（§9.4.3 v15.1）

语料 79 = pos 31 / neg 38 / bnd 10（1:1.23 语料域）；宏面负向 4 案（neg-050/051/052/053——模式不匹配/查重/ellipsis/域外用）+ 既有宏 bnd-010（深度预算）——宏面错误类 4 类有负向覆盖；正路径宏面 4 案（pos-024/031/032/033——基本/literal/两代/卫生）。分布断言共变：Reader 6 / Macro 0（哨兵）/ Expander 73。

## 4. 依赖

kerf-driver（parity 宿主）+ selfhost/v1/macro.krf + expander.krf（被测物——装配程序）+ kerf-compiler（Bytecode PartialEq——门 B 口径 (a)）+ tests/v1/stage1/corpus/（79 案）+ examples/audit（T 节）。

## 5. 维护

语料增删 → 动态目录扫自动收编（三层分布断言 6/0/73 随之更新）；1.8 末轮预备将门审全集复跑（≥130 case 消费 T 节）；三阶段 fixpoint（A→B→C）为 Stage 2+ compiler 自举窗登记——门 B 口径 (a)/(b) 为二阶段面。

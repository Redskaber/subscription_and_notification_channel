# composed-full-chain — Stage 2.4 首刀测试记录（fixpoint B · r86 · v0.56.0）

> 对应测试文件：`tests/v1/stage1/plan/composed_full_chain_tests.rs`（15 函数）。
> 设计层单源：`docs/stage0.md §9.87`；实施实录：`docs/develop/v2/stage-2/round-records.md#9.87`。
> 本文件 = 测试设计记录层（分层纪律：设计依据在 stage0，实施实录在 develop，测试构成与判读在此）。

## 1. 被测面

`kerf::driver::composed_full_chain_parity / _vm / _probes`（`crates/kerf-driver/src/composed_full_chain.rs`）：2.4 公式
`compile(expand(read(lex(S)))) == compile_krf(expand_krf(read_krf(lex_krf(S))))`
的三段分级托管——junction 1 读链（r85 全链）/ junction 2 展开层（1.6）/ junction 3 编译层（2.2-2.3），链自身产物逐级前馈（JX-1 重编码器），每个 junction 双引擎一致 + 对 oracle 差分门。

## 2. 测试构成（15 函数——分布论证）

| 类别 | 测试 | 设计意图 |
|---|---|---|
| 正向（3） | `positive_anchors_through_the_full_composed_chain`（7 形：fn 糖/capture 序/transitive/effects/let 遮蔽/多 define 模块/载荷族） | 公式端到端 + 行 = Compile + 三 junction 逐位 matched |
| | `a_comment_only_source_compiles_to_the_empty_product`（空源 + 纯注释） | 空积行：`(quote nil)` 双前缀 → 空积编译（oracle read Ok([])） |
| | `the_analysis_dump_is_a_faithful_image_of_the_bytecode`（双夹具：全字段代表积 + 空积） | 门 B 升格见证（§9.87.5）：九探针逐字段变异可见性 |
| 负向（6） | `reader_layer_rejections_route_to_junction_one`（未闭合 + 未终结串） | Read 行误差轴 + 下游空转（expand/compile_matched = None） |
| | `expander_layer_rejections_route_to_junction_two`（neg-013 未绑定 + neg-011 畸形 fn） | Expand 行误差轴 parity key + junction 1 必过 |
| | `the_compile_error_axis_rides_junction_three`（neg-057 LA-7） | 编译误差轴（E0012）经全链 |
| | `a_tampered_lexer_fails_the_chain_at_junction_one`（VT 空白表项移除） | junction 1 检测臂：篡改词法器 → 链停在读（永不落入 junction 2） |
| | `a_tampered_expander_fails_the_chain_at_junction_two`（深度守卫 512→2） | junction 2 检测臂：junction 1 过 + 链停在展开 |
| | `a_tampered_compiler_fails_the_chain_at_junction_three`（load-global 篡改） | junction 3 检测臂：前两 junction 过 + 产品轴失败（FP8 组成化） |
| 边界（1） | `beyond_the_read_bracket_the_limit_classifies_and_the_vm_holds`（2000 原子宽源 + 255 深 if 链） | 双跑面 harness limit 诚实分类（非 defect 非静默）+ VM 括号面全链 Compile 行 |
| 跨阶段消费（5） | `the_selfhost_reader_rides_the_full_chain`（VM 面） | reader.krf 定点过全链（头部 ~2.4k 单段 trivia 越 eval 包络 → VM 面披露） |
| | `the_seventh_self_application_the_lexer_source`（VM 面） | **第七次自应用**：lexer.krf 自源经完整 .krf 链（尾部四输出全局剥离） |
| | `the_assembled_expander_and_compiler_ride_the_full_chain`（VM 面 ×2） | 装配展开器（1410 行）+ compiler.krf（1221 行）过全链 |
| | `the_macro_library_rides_the_full_chain`（VM 面） | macro.krf 自含无宿主尾——原样过链 |
| | `corpus_directory_every_file_lands_in_its_ledger_row`（85 文件） | **漂移分类账**：oracle 路由分类 + 行匹配 + 8/19/58 计数钉扎 + bnd-006/007 括号重验 |

## 3. 判读口径

- **行路由**：oracle `read_program` 拒 → Read 行；`expand_program`/`load_program` 拒 → Expand 行；否则 Compile 行——与 CP1/CP9-4 的过滤面同源，但从「过滤」升格「清账」（每文件必须过链并落在唯一行）。
- **matched 定义**：所达 junction 全过（引擎一致 + 该行误差轴 parity key 逐字节 / 树同一性 / 产品面）+ 未达 junction 空转（None）。
- **计数钉扎**：`read_row == 8 ∧ expand_row == 19 ∧ compile_row == 58 ∧ 总数 == 85`——语料增长必须随动（账是不变量而非主张）。
- **包络**：junction 1 越 eval 包络 → drift 以 `harness limit:` 起始（K165-K167 分类单源）→ VM 面重验；括号计数 ≤2（bnd-006/007 已知族）。
- **深度栈**：全测试 `deep_stack`（768MiB）包裹；包络面 `envelope_stack`（1536MiB）——r74 BST-1 谱系。

## 4. 内循环实录（三族——详见 round-records §9.87）

① 空表双前缀（`(quote ())` 解析错 → nil 化）；② 嵌套 if 缺 else 臂（行归属 Expand 非 Compile）；③ 空源行归属（假设 Read 实为 Compile）。三族均为测试侧假设修正，链本体零缺陷。

## 5. 维护义务

- 语料增删 → 计数钉扎随动（`corpus_ledger_sweep_body` 内三断言 + 总数）。
- audit Z07-Z16 与本文件测试族同语义（audit = 单案锚；此处 = 系统面）——双侧共变。
- Bytecode 字段增删 → `dump_faithfulness_witness` 探针集随动（九探针覆盖声明由 fail-closed 断言机检）。

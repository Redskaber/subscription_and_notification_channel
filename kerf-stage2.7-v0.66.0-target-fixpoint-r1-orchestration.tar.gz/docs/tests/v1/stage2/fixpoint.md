# fixpoint — Stage 2.5 首刀测试记录（fixpoint C · r88 · v0.58.0）

> 对应测试文件：`tests/v1/stage1/plan/fixpoint_tests.rs`（11 函数）。
> 设计层单源：`docs/stage0.md §9.89`；实施实录：`docs/develop/v2/stage-2/round-records.md#9.89`。
> 本文件 = 测试设计记录层（分层纪律：设计依据在 stage0，实施实录在 develop，测试构成与判读在此）。

## 1. 被测面

`kerf::driver::{rebuild_bytecode, krf_compile_rich, krf_compile_rich_vm, fixpoint_selfhost_compiler, gate_b_elevated}`（`crates/kerf-driver/src/{compiler_parity,fixpoint}.rs`）：2.5 开场三 MUV——① 重建面（.krf 编译器堆产品 → 真实 `Bytecode`：操作码 kebab 反查表 + 全字段重建 + verify 前置门 + 世代落位）；② 不动点驱动器（三相位：C(S) 裸结构源双引擎编译 / C(C(S)) 自应用装配 VM-only 括号编译 / 重建产品 VM 执行——终断言 `b_self_exec == b_self` 逐字节 = SOP §21.3 出口判据 (2)）；③ 升格门 B（.krf 侧换装产品重建——全语料结构化字节码全等）。

## 2. 测试构成（11 函数——分布论证）

| 类别 | 测试 | 设计意图 |
|---|---|---|
| 正向（4） | `opcode_reverse_table_roundtrips_all_25`（25 对 + 尺寸钉扎） | 反查表与 `kind_name` 单源对往返；未知名拒绝（大小写/下划线形态负例内嵌） |
| | `rebuild_matches_oracle_and_carries_generations`（宏夹具 my-if） | **世代轴回归**：oracle debug_info 非 ROOT 世代在重建产品中逐位落位（世代补记的检测力臂——无补记则断言失败）+ `bc == oracle` 全字段 |
| | `gate_b_elevated_sweeps_the_whole_corpus`（eligible ≥25 地板） | 升格门 B 全语料 sweep（.krf expander 树 → .krf 编译器产品重建 vs oracle 结构化全等） |
| | `fixpoint_holds_the_selfhost_compiler_compiles_itself_twice_identically` | **不动点本体**：三相位全跑 + 规模披露（self_protos ≥40 / 自应用 proto 群相等 / 常量池严格更大）|
| 负向（6） | `opcode_reverse_table_rejects_unknown_names`（4 形态） | 表外名 fail-closed（空串/大小写敏感/下划线形态） |
| | `rebuild_rejects_unknown_opcode_name` | 伪造 kebab 名在反查处失败（消息命名缺陷） |
| | `rebuild_rejects_negative_operand` | u32 槽范围检查（负操作数） |
| | `rebuild_rejects_bad_generation` | 尾部世代整数验证（负世代——永不默认） |
| | `rebuild_rejects_truncated_proto` | arity 检查先于任何字段信任 |
| | `rebuild_rejects_unknown_section_and_error_verdict`（两臂） | 未知节 tag + err 判定（重建面只拥有 ok 轴） |
| | `rebuild_rejects_a_product_that_fails_verify` | 结构完备但语义破损（越界跳转）——`Bytecode::verify` 为门（重建产品是可装载程序或报错，永非半像） |
| 集成（含于正向） | 语料 sweep + 不动点本体 | 跨阶段消费行：前 .krf 链四层（lexer→reader→expander→compiler）→ 产品重建 → VM 执行——§9.89 三相位全链 |

正负比（函数级 4:7，用例级含 sweep ≥25 + 往返 25 对 + 四负例族 ≥12）——子阶段内负向多数承载 fail-closed 契约；两集成面为跨阶段消费行。

## 3. 判读口径

- **世代轴**：宏夹具断言双侧（oracle 自身非 ROOT 世代在场[夹具有效性] + 重建产品世代逐位等于 oracle[补记落位]）——空轴测试在此构造性不可能。
- **不动点**：`fixpoint_holds` 为驱动器内终断言（`b_self_exec == b_self`——PartialEq 全字段含 debug_info 世代四元组）；测试另断言规模披露（自应用 proto 群与裸编译器相等[76 = 76——烧入输入入常量池] + 常量池严格更大[数据账面自证]）。
- **括号面**：C(C(S)) 相位经 `krf_compile_rich_vm`（自嵌数据经逐元素递归超求值器 2048 深度帽——r85 括号谱系沿袭，披露于模块文档）；C(S) 相位经双引擎面（CP6/CP9 包络实证）；全测试 `deep_stack`（768MiB）包裹（发射/解析面走查自嵌数据）。
- **失败形态**：一切失败为分类 `Err`（harness 纪律——漂移报错永不 panic）；负例族断言错误消息命名缺陷（`unknown opcode` / `negative` / `generation` / `fields` / `verify`）。

## 4. 内循环实录（三族——详见 round-records §9.89）

① 自应用 proto 群断言初版「严格更大」实测相等（烧入输入入常量池不入 proto 群——数据账面修正）；② syntax-rules 空字面集 `()` 读错误（子集空表约束——`nil` 形态）；③ 审计草稿残行（heap_init 幽灵调用——当轮清除）。三族均为测试侧修正，驱动器与重建面本体零缺陷。

## 5. 维护义务

- `Opcode` 表增删 → 反查表往返与尺寸钉扎随动（单源对相邻 + round-trip 守卫）。
- Bytecode 字段增删 → `rebuild_bytecode` 重建面与 `dump_faithfulness_witness`（2.4 见证）双侧共变。
- audit Z17-Z24 与本文件测试族同语义（audit = 单案锚；此处 = 系统面）——双侧共变。
- 世代补记 token 级改动 → 整轮 parity 复验（selfhost README 敏感锚纪律——`cp-span-of`/`cp-gen-of`/`cp-assemble` 十臂为触面清单）。

# 全局测试矩阵（matrix.md）

> 依据：docs/sop.md §9.5。每子阶段完成后更新；阶段门审查（§7.3）的输入。
> 口径：「近 100%」= 功能覆盖 + 回归 + 边界 + 负向 + 审计 + 流水线路径 + 正负比（1:3+）；允许 ≤5% DEFERRED（有理由有计划），不允许 UNTESTED。

## Stage 0 功能点覆盖

### Stage 0.0（已交付——2026-09-27）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 Span::new 校验构造 | span.rs 内联 | 2 | 4 | ✅（0..0、MAX..MAX、MAX 反转） | ✅ TESTED |
| FP2 Span::root 简写 | span.rs 内联 | 1 | 2 | ✅（与 new 等价性） | ✅ TESTED |
| FP3 is_empty/len | span.rs 内联 | 1 | 3 | ✅（单字节/全幅/MAX） | ✅ TESTED |
| FP4 contains_offset（半开） | span.rs 内联 | 1 | 5 | ✅（start 含/end 排除/空 span） | ✅ TESTED |
| FP5 join 合并 | span.rs 内联 | 1 | 6 | ✅（对称/嵌套/空操作数/双轴独立） | ✅ TESTED |
| FP6 Display + 错误面 | span.rs 内联 | 2 | 4 | ✅（R8 消息惯例断言） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| workspace 装配 + 跨阶段消费 | span_seed_tests.rs | 2 | 6 | ✅（token 归约模式） | ✅ TESTED |
| **合计** | | **12** | **36** | | **正负比 1:3 ✅** |

### §7.1.1 七类错误负向矩阵（阶段累计视图）

| 错误类 | 落位子阶段 | 当前状态 |
|--------|-----------|---------|
| 语法错误 | 0.3 | ✅ **0.3 点亮**（UnclosedList/UnexpectedClose/UnterminatedString/InvalidEscape/InvalidBool/MalformedNumber/InvalidSymbol/UnexpectedCharacter 族） |
| 未绑定标识符 | 0.4 | ✅ **0.4 点亮**（UnboundIdentifier——域键控解析 + 全局回退后拒绝；set! 目标面同守） |
| 语法对象为空（空应用） | 0.3/0.4 | ✅ **0.3 点亮 + 0.4 合成面复检**（reader EmptyApplication + expander EmptyForm 双层纵深防御） |
| 参数个数错误 | 0.6 | ✅ **0.6 点亮**（ArityMismatch——闭包 proto params 对 Call argc + 内建固定 arity 双面，全部源码可达） |
| 类型不匹配 | 0.6 | ✅ **0.6 点亮**（TypeMismatch——truthy 仅 Bool / 算术同种类 / car-cdr 操作数 / Call 被调者可调用性四语境，全部源码可达） |
| 模块循环依赖 | 0.9 | DEFERRED（无模块加载） |
| 宏展开深度超限 | 0.4 | ✅ **0.4 点亮**（ExpansionDepthExceeded——EXPANSION_LIMIT 512 预算，独立界定合成树/宏产树） |

> DEFERRED 占比说明：管线类功能随落位子阶段依次点亮（Reader 0.3 ✅ / Expander 0.4 ✅ / VM 0.6 / 模块加载 0.9）；该矩阵为**阶段累计视图**，0.11 门审要求 7/7。当前已落位功能点（span + core + syntax + reader + expander + compiler + vm + runtime + driver + 装配 + 审计集——9/9 crate）无 UNTESTED 项。

### 回归视图

- 全量套件于每子阶段 §3.2 第 6 命令重跑（六命令流水含 `cargo test --release`）；0.0 基线 = 48/48 → 0.1 = 96/96 → 0.2 = 144/144 → 0.3 = 204/204 → 0.4 = 252/252 → 0.5 = 300/300 → 0.6 = 356/356 → 0.7 = 427/427 → 0.8 = 551/551 → 0.9 = 624/624 → 0.10 = 672/672 → 0.10-r2 = 710/710 → **0.11 终态 = 767/767**（+ §7.3.1 审计集 110 case 独立可重跑——30→40→50→60→70→80→90→100→110 单调；**七类 7/7 全点亮维持**；快照 57 ≥50）。

## Stage 0.1（已交付——2026-09-28）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 Symbol 校验构造（含 CJK 白名单被测对象） | symbol.rs 内联 | 3 | 10 | ✅（空白×6 变体/NUL/前导/Unicode 空格） | ✅ TESTED |
| FP2 变体面全覆盖（CoreExpr 9 + LiteralValue 6 + ModuleItem 3）+ Display | expr.rs / module.rs 内联 | 3 | 0 | ✅（负数/负浮点浮点性/嵌套 Pair） | ✅ TESTED |
| FP3 Span 全携带 + visit_spans 前序 | expr.rs / module.rs 内联 | 2 | 0 | ✅（精确序断言：6+6 节点两套 fixture） | ✅ TESTED |
| FP4 语义下限校验构造器 + CoreError 面 | error.rs / expr.rs / module.rs 内联 | 0 | 14 | ✅（重复参数×2/重复效应×2/非法名×5/R8 形态） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| TD-004 边活性 + 跨阶段消费 | core_seed_tests.rs | 2 | 6 | ✅（span 归约双向模式 + 不变量穿透） | ✅ TESTED |
| **0.1 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

**累计（0.0 + 0.1）**：正向 24 / 负向 72 = 1:3 ✅；总测试 96（单元 64 + crate API 16 + 跨 crate 集成 16）。

## Stage 0.2（已交付——2026-09-28，tarball 回退恢复轮后首子阶段）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 StxSymbol 校验构造（含 CJK 白名单被测对象；下限与 core::Symbol 逐字节一致） | symbol.rs 内联 | 2 | 8 | ✅（空白×5 变体/NUL/前导/尾随/NBSP Unicode 空白） | ✅ TESTED |
| FP2 Phase 相位模型（二值 + from_u8 校验） | phase.rs 内联 | 2 | 3 | ✅（越级 2/255 + 载荷携带） | ✅ TESTED |
| FP3 ScopeSet 作用域集（有序去重 + union/is_subset_of） | scope.rs 内联 | 2 | 4 | ✅（去重不变量/确定性迭代序/操作数不可变） | ✅ TESTED |
| FP4 StxDatum 六变体 + SyntaxObject 四元组 + visit_spans 前序 + 深翻转 | expr.rs / error.rs 内联 | 2 | 9 | ✅（空表 `()`/嵌套 Display/无 DUMMY 结构性/双翻幂等） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| L0→L1 边活性 + 跨阶段消费 | syntax_seed_tests.rs | 2 | 6 | ✅（token→stx 装配 0.3 契约 + scope 翻转/卫生并集 0.4 契约 + TD-002 跨代次拒绝穿透） | ✅ TESTED |
| **0.2 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

**累计（0.0 + 0.1 + 0.2）**：正向 36 / 负向 108 = 1:3 ✅；总测试 144（单元 96 + crate API 24 + 跨 crate 集成 24）。

## Stage 0.3（已交付——2026-09-28，首个源码级管线入口 + 门审全额口径起强）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 StxToken 词法面（§8.1 子集：定界/标识/数/布尔/串/Eof + 注释/BOM/无损覆盖） | lexer.rs 内联 | 7 | 14 | ✅（`.5`/`1.`/`1e5` Rust 语义 + 数字形 fail-closed ×5 + 括号/宏字符拒绝 + lone hash + escape-at-EOF） | ✅ TESTED |
| FP2 read_program 程序面（多形式/嵌套/字节精确 span/空程序/Runtime+空域戳） | parser.rs 内联 | 4 | 13 | ✅（256 帽含边界通过 + 最内层未闭合报告 + 多形式定位 ×2 + 参数位空应用） | ✅ TESTED |
| FP3 ReadError 错误面（十变体 R8 形态族 + 单源字典跨层逐字节） | error.rs 内联 | 0 | 5 | ✅（全变体小写/无句号族检 + InvalidSymbol 三层一致） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | ✅（帽/空应用/未闭合/数字/布尔/串全负路径） | ✅ TESTED |
| L1→L2 边活性 + 跨阶段消费 + 退役证明 | reader_seed_tests.rs | 2 | 7 | ✅（token/树归约 0.4 契约 + 真实 StxToken 归约（TokenLike 退役）+ CJK 字节精确 + 恢复隔离 + 单源字典跨 crate） | ✅ TESTED |
| **0.3 合计** | | **15** | **45** | | **正负比 1:3 ✅** |

- **§7.3.1 审计集 r1**：examples/audit/stage0_gate_audit_r1.rs——30 case（10 单语句 + 10 多语句 + 5 复杂 + 5 错误恢复），`cargo run --release --example stage0_gate_audit_r1` 可重跑（exit 0），逐子阶段单调增长至 0.11 门审 7/7（plan-0.3.md §6 构成映射）
- **七类错误矩阵更新**：语法错误 ✅（reader 全族）+ 语法对象为空（空应用）✅（reader 读期拒绝——纵深防御，0.4 展开器复检）——**2/7 点亮**；余 5 类 DEFERRED 至落位子阶段（见下表）

**累计（0.0 + 0.1 + 0.2 + 0.3）**：正向 51 / 负向 153 = 1:3 ✅；总测试 204（单元 139 + crate API 32 + 跨 crate 集成 33）。

## Stage 0.4（已交付——2026-09-28，展开器种子 + TD-002 裁定轮）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 ExpandError 错误面（七变体 R8 形态族 + Core 传播 + span 载荷） | error.rs 内联 | 0 | 5 | ✅（source 链接 + span 回取） | ✅ TESTED |
| FP2 expand 表达式面（9 核心形式 + 原子 + nil 保留字 + do→Let 脱糖 + let* 渐进） | expand.rs 内联 | 5 | 12 | ✅（do 恒等/空 let/单多 spec/重复参数/重复效应） | ✅ TESTED |
| FP3 expand_program 模块面（define 双形 + letrec 顶层 + require/module + 全局表） | api_tests.rs | 2 | 6 | ✅（STAGE0_GLOBALS 18 名 + fib 契约 + 坏形族） | ✅ TESTED |
| FP4 帽/卫生/跨阶段（512 预算双向 + 域键控 + 相位 + span 单代次 + fib 契约） | ctx.rs 内联 + expander_seed_tests.rs | 5 | 19 | ✅（foreign-scope 拒绝 + 预算下溢饱和 + 模块隔离 + 字节定位） | ✅ TESTED |
| **0.4 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

- **§7.3.1 审计集 r1 单调增长**：30 → **40 case**（+E10 展开器负向：未绑定×2 / 深度越界 / 相位 / 形态族×3 / 顶层表达式 / 空表合成面 / 重复参数），`cargo run --release --example stage0_gate_audit_r1` 可重跑（exit 0）
- **七类错误矩阵更新**：未绑定标识符 ✅ + 宏展开深度超限 ✅——**4/7 点亮**（语法错误 + 空应用 @0.3，未绑定 + 宏深度 @0.4）；余 3 类 DEFERRED 至落位子阶段（见上表）
- **TD-002 裁定**：0.4 展开器零 span 构造（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生 → 拒绝语义保持为设计行为 + 0.9 span 集合表示议程登记（plan-0.4.md §4 裁定三）——**[Resolved at 0.4]**

**累计（0.0 + 0.1 + 0.2 + 0.3 + 0.4 + 0.5）**：正向 75 / 负向 225 = 1:3 ✅；总测试 300（单元 203 / crate API 48 / 跨 crate 集成 49）。

## Stage 0.5（已交付——2026-09-28，编译器种子 + verify 公共面裁定轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | opcode.rs（2+0）/ bytecode.rs（2+2）/ compile.rs（4+3）/ verify.rs（0+11）/ error.rs（0+8） | 8 | 24 | FP1-FP4 |
| crate API | crates/kerf-compiler/tests/api_tests.rs | 2 | 6 | 公共面 + fib 契约 + verify 拒绝族 |
| 跨 crate 集成 | compiler_seed_tests.rs（经 runner.rs） | 2 | 6 | fib 全链（reader→expander→compiler→verify）+ do→Let→StoreLocal 链 + 三层帽序（256/512/1024）+ 篡改产物 verify 拒绝 ×4 |
| **0.5 合计** | | **12** | **36** | **正负比 1:3 ✅** |

- **七类错误矩阵更新**：**维持 4/7**（0.5 编译器为直译层——合法 CoreExpr 无语义拒绝面，不新增检测类点亮；参数个数/类型不匹配 = 0.6 VM 执行校验层、模块循环依赖 = 0.9 加载层——结构性 DEFERRED 记账沿袭）
- **裁定四（verify 公共面）**：§19.3 三不变式两道防线机械化（编译期簿记 fail-closed + `Bytecode::verify` DAG 深度传播/结构校验公共 API——0.6 VM 加载期钩子 + 手工坏产物负向测试面）——plan-0.5.md §4
- **审计集**：40 → **50 case**（F 节编译器负向 10：深度帽越界合成树 + verify 拒绝族 ×9 手工坏产物——cargo run exit 0）
- **TD-003 消解**：kerf-compiler 实现（骨架余 4 → 3：vm/runtime/driver）

## Stage 0.6（已交付——2026-09-28，VM 种子 + 0.5 缺陷修复轮 + 七类 6/7 点亮轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | value.rs（3+6）/ builtin.rs（1+4）/ error.rs（0+8）/ frame.rs（1+2）/ vm.rs（3+11） | 8 | 31 | FP1-FP4 |
| crate API | crates/kerf-vm/tests/api_tests.rs | 2 | 5 | 公共面（DAG 纪律：kerf-compiler 面 + kerf-core dev 夹具）+ verify 钩子 + I/O 回环 + 效应/除零负向 |
| 跨 crate 集成 | vm_seed_tests.rs（经 runner.rs） | 2 | 6 | **fib 源码→值四段一断（fib(10)=55 + fib(25)=75025——§20.1 Week 3 判据）** + STAGE0_GLOBALS parity + let/set!/do 执行 + arity 双面 + type 四语境 + 效应最近匹配 + 溢出边界 |
| **0.6 合计** | | **12** | **42** | **正负比 1:3.5 ≥ 1:3 ✅** |
| 0.5 回归对（§20.6 修复记账） | kerf-compiler compile.rs 内联 | 2 | 0 | end_closure cur 递减缺陷（多闭包产物损坏）——cur_stack 修复 + 兄弟/嵌套闭包回归 |

- **七类错误矩阵更新**：**6/7 点亮**（+参数个数 #4 + 类型不匹配 #5——VM 执行校验层落位，四语境全源码可达）；余 1 类结构性 DEFERRED（模块循环依赖@0.9 加载层）
- **裁定五（Call 栈布局调和）+ 裁定六（Perform 最小执行语义）**：以编译器实际发射为准（§8.4.5 代码优先）+ handler 即动态函数（§9.1.1 预留层边界内最小完备）——plan-0.6.md §4
- **审计集**：50 → **60 case**（G 节 VM 负向 10：源码级 arity×2 + type×4 + unhandled effect + div-zero + 溢出 + 预算——cargo run exit 0）
- **TD-003 消解**：kerf-vm 实现（骨架余 3 → 2：runtime/driver）
- **0.5 缺陷修复**：`end_closure` cur 递减 → cur_stack LIFO（§20.6 同类全量 + 回归对 2——verify 第二道防线在加载期拦截损坏产物实证）

## Stage 0.7（已交付——2026-09-28，Runtime 种子 + 双路径互查轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（kerf-vm 演进） | value.rs（2+2）/ error.rs（0+1）/ vm.rs（2+2） | 4 | 5 | Heap 收集器面（free-list 复用/mark 复位对称/悬垂读 None/越界防御）+ EvalDepthExceeded 变体 + collect-then-retry 注入面（MiniCollector 夹具——L6 不依赖 L7 的测试术）+ snapshot_roots 四类+handlers |
| 单元（kerf-runtime） | gc.rs（0+12）/ eval.rs（3+19）/ parity.rs（2+1） | 5 | 32 | GC 防御族全负向（回收精确/深链 10^5 爆栈对策/自环/幂等/悬垂根跳过/空堆/复用一致性）+ eval 九原语 + 十一变体错误族 + R8 消息族 + 深度帽 + saved-env 悬垂修复的行为面 |
| crate API | crates/kerf-runtime/tests/api_tests.rs | 3 | 2 | 装配（哨兵 proto 锚定）+ I/O 回环 + MarkSweep trait 注入面 + 预算 fail-closed + R8 |
| 跨 crate 集成 | runtime_seed_tests.rs（经 runner.rs） | 7 | 13 | **15+ 程序双路径互查（fib×2/算术整浮/比较/if/let*/do+set!/闭包×2/cons链/谓词/eq? 同一性/效应最近匹配）+ STAGE0_GLOBALS 三面官方断言 + E2E 源码→值 I/O parity + VM 注入端到端（无 collector fail-closed ↔ 注入跑通 + fib(25) 回归）+ 负向 parity 族（错误变体+消息逐位一致）+ IEEE NaN/±0.0 语义 + 深度帽不对称边界 + foreign root 保护** |
| **0.7 合计** | | **19** | **52** | **1:2.7（偏差申报见 plan-0.7.md §3——GC 防御族全负向 + parity 验收本体）** |

- **七类错误矩阵**：维持 **6/7**（eval 路径 case-for-case 与 VM 一致——错误层 parity 实证；余 1 类结构性 DEFERRED：模块循环依赖@0.9）
- **审计集**：60 → **70 case**（H 节 runtime 负向 10：eval 源码级 ×7 + GC 防误回收端到端 + parity 检测器自检——cargo run exit 0）
- **TD-003 消解**：kerf-runtime 实现（骨架余 2 → 1：driver）
- **P1 缺陷闭环**：invoke saved-env 悬垂（根集不完备的 eval 形态）——temp 保护修复 + 程序隔离同类回补（§20.6）

## Stage 0.8（已交付——2026-09-28，Driver 种子 + 诊断渲染收口 + TD 双清偿轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（消费面扩展） | reader error.rs（0+3）/ compiler error.rs（0+2） | 0 | 5 | ReadError::offset()（6 有位/4 载荷本体）+ CompileError::span()（10 有位/3 缺失即缺陷）逐变体断言——ExpandError::span() 0.4 已预置零改动 |
| 单元 session.rs | 内联 | 4 | 1 | 文件 intern 顺序 id + upsert 同 id 源替换 + 反查 + 未知 id fail-closed |
| 单元 line_index.rs | 内联 | 10 | 3 | TD-001 行列派生：空源/单行/多行/换行归属/孤立换行/CJK 字符列/CRLF/尾换行/多位行号 + 中点字符取整/越界钳制/越界行 fail-closed |
| 单元 diagnostic.rs | 内联 | 5 | 6 | §8.7 切片：Severity/Code 稳定标签 + 四阶段 41 变体穷尽映射（ReadError 10 逐变体循环断言 + expand/compile/runtime 族）+ 消息 R8 逐位透传 + 无位不伪造 |
| 单元 render.rs | 内联 | 9 | 4 | rustc 风格黄金快照（`error[code]: msg` + `-->` + 摘录 + 脱字符下划线）+ 槽宽自适应 + 多诊断分隔汇总 + CJK 字符列 + 混合文件 + 无位免 `-->` + 跨行钳制 + 未知文件防御 |
| 单元 pipeline.rs | 内联 | 7 | 8 | Engine{Vm,Eval} 双引擎 fib 值 + parity 三面（值/输出/全局表——分歧数据化）+ check 计数 + I/O 往返 + 四阶段错误 code 断言 + 帽序深链 |
| 单元 repl.rs | 内联 | 11 | 5 | session-replay：define→表达式持久/包装取值/原子包装/计数器稳定/多行未闭合恢复/增量输出尾部/多表单/混合/重定义 last-wins + 错误回滚 ×3 + 超带 Eof |
| 单元 cli.rs | 内联 | 11 | 7 | run/check/repl/--help/--version 解析 + 退出码 0/1/2 + 输出/值打印语义 + parity PASS + REPL 循环 EOF + 用法错族（未知命令/未知选项/缺引擎值/坏引擎名/缺文件/不可读文件）|
| crate API | crates/kerf-driver/tests/api_tests.rs | 4 | 2 | 公共面装配（run/check/parity/line_index/render/repl/cli/version）+ 错误数据化 |
| 跨 crate 集成 | driver_seed_tests.rs（经 runner.rs） | 12 | 10 | **§7.1 全套：五类源可达错误类经 driver E2E 全点亮（语法/空应用/未绑定/参数个数/类型不匹配）+ fib 双引擎 + parity + I/O 双引擎 + check + REPL 会话 + 渲染黄金字节契约 + CLI 退出码 + CJK 字符列（1:19 vs 字节列 1:21 可区分）+ 250 深帽序边界探针 + 多文件多诊断 + REPL 回滚恢复 + 全链消费（L2/L3/L5/L6/L7→L8 五边活性）** |
| **0.8 合计** | | **73** | **51** | **1:0.7（偏差申报见 plan-0.8.md §3——编排层主功能面为正向组合语义；错误面 41 变体全变体级覆盖）** |

- **七类错误矩阵**：维持 **6/7**——**五类经 driver E2E 源级可达**（审计 I01-I05 + seed 同构）；第六类宏展开深度 = 合成树专属（256<512 帽序结构性事实——审计 E 节 expander 层维持 + 250 深边界探针证帽序）；余 1 类结构性 DEFERRED（模块循环依赖@0.9）
- **审计集**：70 → **80 case**（I 节 driver E2E 10：五类渲染 + 多文件多诊断 + REPL 回滚 + check 拒绝 + parity 数据化 + CJK 列 + 无位免 `-->`——cargo run exit 0）
- **TD-001 清偿**（LineIndex 渲染期派生 + rustc 风格渲染收口）；**TD-003 清零**（9/9 crate 全落位）
- **消费面扩展 ×3**（ReadError::offset / CompileError::span / kerf-compiler ModuleItem 再导出——全加法零回归）；**当轮实现缺陷 2 闭环**（TapeIo 记录语义 + stdin 预读条件化——§20.6 同类制度化）

## Stage 0.9（已交付——2026-09-28，CodeValue + 基础卫生宏系统 + 模块加载层 + **七类 7/7 双门槛达成轮**）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元 code.rs | 内联 | 5 | 0 | CodeValue 六操作（from_syntax/to_syntax/substitute/alpha_rename/symbols/to_source——全总数函数无错误面；§6.3.3 设计 API 合同面） |
| 单元 ctx.rs | 内联（净增） | 1 | 1 | binder-scopes 子集解析（0.4 membership 一般化——非宏代码结构性兼容）+ 宏登记簿（帧内词法作用域 + 异作用域不可见）+ 预算/隔离既有面零回归 |
| 单元 transformer.rs | 内联 | 7 | 5 | syntax-rules 解析（my-if 规范形/字面量表）+ 匹配（通配/变量/嵌套/原子/首规则）+ 实例化（拼接原样/引入代次 gen+1/宏产物再宏 gen+1）+ 注册拒绝（重复变量/省略号/形状 ×3/字面量不匹配/元数） |
| 单元 module.rs | 内联 | 3 | 5 | 装载层：线性链次序/嵌套声明收集/空程序 + **环 ×3（双模块路径/三模块/自引用）** + 缺失 + 重名 |
| 单元 expand.rs | 内联（净增） | 6 | 10 | quote（原子五类/Pair 链右折/符号拒绝/嵌套符号拒绝/元数）+ define-syntax（声明记录/形状 ×3/保留名）+ 宏使用（my-if 形状/未定义/先用后定义/不匹配/自递归深度/模块隔离）+ **卫生防御**（引入绑定重命名 tmp__macro_0 + 使用处绑定不捕获引入引用）+ 宏产宏两代单调 |
| 单元 error.rs | 内联（净增） | 0 | 2 | 新变体渲染面（MacroPatternMismatch 使用点位 + QuoteUnsupportedDatum 边界消息——R8 形态） |
| 单元 core module.rs | 内联（净增） | 0 | 1 | DefineSyntax 构造拒绝 |
| 跨 crate 集成 | macro_seed_tests.rs（经 runner.rs） | 12 | 15 | **验收本体：定义宏→使用→展开→执行四段全链（fib 双引擎 ×2 + parity 三面）+ 卫生可观察值（无卫生 200/有卫生 101 + make-adder 15/105 双向）+ quote car/cdr 链双引擎 + 宏产宏两代双引擎 + 模块程序双引擎 + 嵌套模块宏 + check + REPL 跨行 + CodeValue 真语法面** + 诊断渲染族 15（宏匹配使用点位/quote 边界 ×2/卫生防御/自递归/先用后定义/模块隔离/**模块环 ×3[第 7 类]/缺失/重名/行列位**/注册族 4/quote 元数） |
| **0.9 合计** | | **34** | **39** | **1:1.15（偏差申报见 plan-0.9.md §3——验收面四段全正向不可拆 + CodeValue 合同面无错误面 + 负向穷尽清单；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 全点亮（首次双门槛达成）**——第 7 类模块循环依赖经 driver E2E 源级可达（J06/J07 + seed 三形态[双模块/三模块/自引用]）——子阶段级（≥6/7）+ 门审级（§7.3.1 规则 1 = 7/7）同轮达成；卫生防御族（使用处绑定不捕获引入引用 + 引入绑定不捕获拼接引用——双机制：scope coloring 子集判据 + rename-on-capture）
- **审计集**：80 → **90 case**（J 节宏/模块/quote 负向 10：宏匹配/quote 边界/卫生防御 ×2/宏面深度维持/**模块环 ×2[类 7 点亮]**/缺失/重名/注册族[省略号+保留名]——cargo run exit 0）
- **裁定十四/十五/十六**（双机制卫生配套 + nil 字面量拼写 + 统一未绑定判据）+ 决策 13 项入档（plan-0.9.md §4）；**实现侧运行语义缺陷 0**（设计级预防补齐 1——rename-on-capture[名字基后端传导] + 设计修正 2——死变体删除/表面拼写裁定）
- 消费面：ModuleItem 第四变体 DefineSyntax（kerf-core 声明层）+ compiler/runtime 零码跳过（Require 先例对偶）+ ConstKey::Pair 首次生产性消费（0.5 前置锚转正）+ driver pipeline 挂接 load_program + REPL is_declaration 增头

## Stage 0.10（已交付——2026-09-28，四项接口预留冻结——§22.3 里程碑四接口项达成；**0.10-r2 修订轮 2026-09-28——能力模型预留泛化[用户显式指令开窗]**）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元 effects.rs | 内联 | 6 | 0 | EffectSystem witness 四面（perform 路由经 EffectOp::Result / 状态累积 / handle 组合 / 捕获闭包）+ 关联类型名达性 ×2（Result 钉定 + Continuation 可名） |
| 单元 multistage.rs | 内联 | 4 | 0 | MultiStage witness（quote→splice 折返 / run 执行至载体结果 / 异载体泛型 E:Expr）+ CodeCarrier 类型钉定 |
| 单元 capability_io.rs | 内联 | 4 | 6 | 令牌 ZST ×2 + Debug 裸名稳定 + IOError kind/message 往返 + 读两行 happy；负向：耗尽 Eof / **中断重试 Interrupted** / 撤销 Denied（仅撤前捕获）/ 拒绝从未活 Denied（零捕获）/ R8 形态四 kind / kind 逐对可区分 |
| 单元 cache.rs | 内联 | 5 | 5 | CacheKey 摘要往返 + Eq/Hash 一致性 + CachedResult 载荷三面 + **kit 双 witness 通过**（HashMap + Vec——kit 泛型性）；负向：**kit 检测力 5 套故意破坏实现**（never-hit / no-invalidate / no-overwrite / wrong-key / payload-corrupt）全 should_panic |
| crate API | api_tests.rs reserved 节 | 6 | 0 | 四族公共路径 + kit 本地复跑 + R8 错误面 + 跨 crate witness（effects/multistage/capability 三 trait 外部实现位）+ cache 形状面 + **std::error::Error 对象面**（Box<dyn Error> downcast 往返） |
| 跨 crate 集成 | reserved_seed_tests.rs（经 runner.rs） | 7 | 5 | 四族经 kerf::core::reserved 根聚合路径 + effects/multistage witness + **drive_cache 下游泛型消费**（对抽象编译——§21.12-10② 行动态）+ kit E2E + 令牌 ZST + 最新胜；负向：未存 miss / invalidate 后 miss / 跨键隔离 / R8 根位置 / **kit 根位置捕捉破坏实现** |
| **0.10 合计** | | **32** | **16** | **1:0.5 反向（偏差申报见 plan-0.10.md §3——预留冻结轮验收面 = 类型形状 + 签名快照[结构性正向]；负向可测面穷尽[kit 检测力 5 + IOError 四 kind + R8 双层 + 令牌纪律]；凑数违反 §12）** |
| 单元 capability 族（r2） | family 4+0 / token 2+0 / registry 5+11 / io +5+0 | 16 | 11 | 裁定二十能力空间：身份卡三元组往返/Eq-Hash 一致/逐字段互异 + 族契约 witness + 令牌词表惯例；负向：**注册 fail-closed 族**（重复名/权威冲突/空名/空权威表/自重复权威/空操作面/未知名/未知权威/R8 形态/kind 互异/**被拒零副作用**） |
| crate API（r2） | api_tests.rs r2 节 | 5 | 1 | 能力空间可达 + io 注册端到端 + **api 位拓展证明 OutsideNet** + re-export TypeId 同一性 + RegistryError std::error 对象面；负向：注册拒绝 |
| 跨 crate 集成（r2） | reserved_seed_tests.rs r2 节 | 4 | 1 | **根位拓展证明 RootClockModel**（与 io 同闭世界加法增长）+ register_any_family 下游泛型消费 + 跨位置治理解析 + coherence；负向：根位重复拒绝 |
| **r2 增量** | | **25** | **13** | **1:0.52 反向（偏差申报见 plan-0.10.md §9——框架面结构性正向；fail-closed 族 11 件负向较 r1 改善；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（0.9 达成后守恒——K 节 = 预留面合同族新审计族类，不新增错误类）
- **审计集**：90 → 100（K 节）→ **110 case（L 节能力空间 10：io 族契约绑定 / 注册端到端 / 重复名 fail-closed / 权威冲突 fail-closed / 空名拒绝 / 自重复权威拒绝 / 未知解析 None / 审计位拓展证明 / RegistryError R8 形态 + 互异 / re-export TypeId 同一性——cargo run exit 0）**
- **裁定十七/十八/十九**（零入边自含抽象 = §21.12-10② 最强冷启动形式 / 伪码可编译转译纪律 + 词汇漂移消解 / 不透明载荷序列化前瞻）+ 决策 10 项入档（plan-0.10.md §4）
- **行为规格执行化**：check_compilation_cache_contract pub kit（P2「行为规格」从文档义务升格为可执行断言——Stage 1 实现的合同测试复用位）；**实现侧运行语义缺陷 0**（全轮编译级/形态级修正）
- 落位：kerf-core/src/reserved/ 四模块（L4 单一冻结锚点 + 除 std 外零入边 + 六域从属文档声明位[§21.12-10① 冷启动形态]）；§22.3 里程碑四接口项（Effect Handlers / 多阶段编程 / 能力模型 I/O / 编译缓存）全 ✅

## Stage 0.11（已交付——2026-09-28，末轮 L3：≥50 快照 + 性能基线 + 门审 + 深审族 + 校准 + 出阶段勾选）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 跨 crate 快照 · Reader（FP1） | snapshot_seed_tests.rs §A | 10 | 0 | RS01-RS10：atom 五类骨架 + 嵌套 list + 注释无损 + 九原语 fib 源 + quote 点号语法事实（`dump_stx` 确定性 walker——span/scopes/phase 不入快照对象） |
| 跨 crate 快照 · Expander（FP2） | §B | 10 | 0 | ES01-ES10：九语义原语逐一直接形态（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）+ do→Let 脱糖 + define 函数糖展开——`apply` 显式头逐字节冻结 |
| 跨 crate 快照 · Compiler（FP3） | §C | 10 | 0 | CS01-CS10：`Instr` Display 机器形态逐指令清单（字面量/if 跳转形状/let store-local 链/闭包 proto/匿名立即调用/cons·car 链/fib 21 指令/入口消费——常量池/全局表索引序冻结） |
| 跨 crate 快照 · VM/Eval（FP4） | §D | 12 | 0 | VS01-VS10 + VE01-VE02：globals 表（编译序）+ outputs + 值形态；双引擎全链各一（fib VM + car Eval）+ `#<pair>`/`#<closure>`/`#<builtin:+>` 不透明形态 + eq? 身份语义 |
| 跨 crate 快照 · Driver（FP5） | §E | 4 | 6 | DS01-DS10：六负向路径渲染黄金字节（未闭合/类型/参数个数/未绑定/空应用/多诊断汇总行）+ check 面计数 + parity 三面 + WORKSPACE_VERSION + 输出行序 |
| 跨 crate 快照 · REPL（FP6） | §F | 4 | 1 | TS01-TS04 + VD01：会话转录（值/新输出）+ 错误回滚后存活 + 未闭合继续跨行续读 + Value Display 八形态卡 |
| **0.11 合计** | | **50** | **7** | **57 case ≥50（§22.3 L6）——1:0.14 反向（分布论证见 snapshot.md §3：确定性契约层结构性正向；错误检测语义由既有 7/7 类承载，错误呈现字节入冻结；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（快照层为冻结层不新增错误类；负向路径呈现形态 7 case 入冻结）
- **审计集**：**110 case 维持**（0.10-r2 已超额 §7.3 ≥30 全额口径——本轮门审复跑 `cargo run --release --example stage0_gate_audit_r1` = AUDIT PASS 110/110）
- **性能基线（§22.3 L8）**：B1 编译 9.3µs 中位 / B2 VM fib(25) 96.7ms / B3 eval fib(20) 9.4ms / B4 GC 0.36ms（1 cycle + swept 1023）/ B5 端到端 97.6ms——examples/bench/stage0_baseline.rs 可重跑 + performance-baseline.md 入档 + 回归口径 median >25%
- **深审族（§14.5/§14.6/§14.8/§14.9）**：deep-review-round0.11.md（D1-D8 + 投票 5.5/5.5 + 偏差清单 B1×2/B2×3/B3×3）+ 深验七件套（pipeline-test-coverage / architecture-review / design-impl-test-coverage / hidden-problems-assessment / refactoring-optimality-review / performance-baseline / final-assessment）+ §14.9 C1-C6（零 TODO + 零 unwrap + 2 历史时态注记当轮修）
- **§21.5 九信号 + §22.3 十二项**：全勾（final-assessment.md §2/§3——出阶段评审 GO，提请用户确认）
- 落位：tests/v0/stage0/plan/snapshot_seed_tests.rs（经 runner.rs 挂载）+ examples/bench/stage0_baseline.rs（[[example]] 注册）；**黄金值录制纪律**：0.10-r3 基线（710:0:0 + audit 110/110）temp probe 实测录制 + 逐条目检 + 冻结内嵌

### 回归视图（末轮终态）

- 全量套件于每子阶段 §3.2 第 6 命令重跑；0.0 基线 = 48/48 → … → 0.10 = 672/672 → 0.10-r2 = 710/710 → **0.11 终态 = 767/767**（+ §7.3.1 审计集 110 case 独立可重跑——30→…→110 单调；**七类 7/7 全点亮维持**；快照 57 ≥50；性能基线 B1-B5 入档）。

## Stage 1.0（已交付——2026-09-28，kerf-typecheck 种子：E0xxx 注册面 + 保守静态 R1-R8 + 多错误收集）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 注册面 + Externals（FP1/FP2） | code.rs + env.rs 内联 | 9 | 0 | TypeCode 八码稳定字符串 + 互异 + Severity 渲染 + TypeDiagnostic 四字段；Externals 三态解析（Some(Some)/Some(None)/None）+ 双构造器 + 后绑胜出 |
| 规则族（FP3-FP7） | check.rs 内联 | 20 | 22 | R1（顶层 so-far / Fn 体全定义 / letrec 预绑定 / 不见外层 Fn——begin_closure 镜像）+ R2（IIFE/Define→Fn/builtin 三通路 + assign 护栏 + 词法遮蔽跳过）+ R3/R4（含字面 Define 全局位 + 护栏）+ R5/R6/R7（Fn 边界截断健全性 + 最近胜出 + 安装序镜像 + Var→Define 处理器路由）+ R8（两形态警告）+ FP8 多错误收集 |
| API 面 | crates/kerf-typecheck/tests/api_tests.rs | 5 | 2 | 五再导出可达 + 空程序零诊断 + 诊断全字段 + Warning 级区分 + 八码经公共入口逐码可产 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_seed_tests.rs（经 runner.rs） | 9 | 12 | **真实管线全链**（read→expand→typecheck）+ Externals 双源构造（STAGE0_GLOBALS + Builtin::ALL——单源纪律）+ 干净程序健全性守卫族（fib/handle/set!/let 遮蔽/厨房水池）+ 源码可达负向族 + span 字节定位 |
| **1.0 合计（净 +79）** | | **43** | **36** | **正负比 1:0.84 反向偏差申报（分布论证：健全性守卫 = 检查器合法程序永不告警义务的另一半 + 注册面/Externals 形状断言结构性正向；负向集中于确定错误路径 + 护栏放行 + 消息 R8 形态——误报 = P0 级缺陷故负向密集。凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（检查器 = 静态前置层——将类 4[参数个数]/类 5[类型不匹配]/类 6[未处理效应] 从运行时提前至编译期；不新增错误类）
- **审计集**：**110 → 120 case**（M01 干净程序健全性 / M02-M09 规则负向族经真实管线 / M10 注册面 + 单源 Externals 表——`cargo run --release --example stage0_gate_audit_r1` = AUDIT PASS 120/120；七类 7/7 维持）
- **GATE 6 构成**：集成 21 case = 正向 9 ≥1 ✓ / 负向 12 ≥3 ✓ / 跨阶段消费 ✓（read→expand→typecheck 全链 + Externals 双源——≥1）；正负比申报沿 v15.1
- 落位：crates/kerf-typecheck/（L4.5——kerf-core 后 compiler 前）+ tests/v1/stage1/（经 runner.rs `#[path]` 挂载）+ 审计 M 节；§18 零新外部依赖（+kerf-core/+kerf-span 两条内部边）
- 层间分工披露：R1 = 展开器第一道防线（0.4 起 UnboundIdentifier）之外的结构层重断言（直接构造路径）；R2-R7 = 今日仅运行时可检错误的静态化（净新增值）；R8 = 静默行为首个表面化（首个 Warning 生产者）

### 回归视图（1.0 终态）

- 全量套件于 §3.2 第 6 命令重跑；0.11 基线 = 767/767 → **1.0 终态 = 846/846**（净 +79：lib 51 + api 7 + 根集成 21——cargo test 口径；+ §7.3.1 审计集 120 case 独立可重跑——30→…→110→120 单调；**七类 7/7 全点亮维持**；767 基线零回归）。

## Stage 1.1（已交付——2026-09-28，driver 接线：typecheck 级入管线 + 诊断渲染映射 + Warning 接线）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 管线接线（FP2/FP3） | pipeline.rs 内联 | 4 | 6 | typecheck 前置（Error 中止/Warning 附着 Outcome 三面）+ 干净程序零发现 + 中止前副作用零发生 + 多错误收集经 driver + 双引擎同发现 + E0006 顶层裸 perform |
| 诊断映射（FP1） | diagnostic.rs 内联 | 3 | 0 | Typecheck(TypeCode) tag = E0xxx + from_typecheck 四字段映射 + Warning 级映射 + 渲染头 error[E0001] 形 |
| 渲染扩展（FP4） | render.rs 内联 | 1 | 3 | 警告摘要行（N warning(s) emitted）+ 纯警告批次无 abort 行 + 混合批次摘要序 + 零警告批次字节不变（ds10 冻结义务单元层）+ 单警告无摘要 |
| CLI 面（FP5） | cli.rs 内联 | 3 | 1 | check/run/parity 警告路径（err 汇 + 退出码 0）+ REPL 循环警告打印 + E0002 渲染 + 退出码 1 |
| REPL 面（FP6） | repl.rs 内联 | 2 | 1 | 警告提交进入程序 + 增量不重印 + 新警告增量 + 确定错误回滚维持 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_wiring_seed_tests.rs（经 runner.rs） | 5 | 5 | 源码可达 E0002/E0003/E0004/E0006 全链 + 渲染注册形（error[E0002] + 位置行）+ 中止前副作用 + 多错误三码同批 + 双引擎警告非阻断 + REPL 增量/回滚 + Typecheck 变体载荷 |
| **1.1 合计（净 +35）** | | **17** | **18** | **1:1.06 对偶均衡（分布论证：非阻断义务 ↔ 中止义务 + 渲染回归面 + REPL 增量语义——三族护栏对偶；基线共变 5 处披露见 plan-1.1.md §4）** |

- **七类错误矩阵**：**7/7 维持**（检查器前置使已知元数错误静态化——类 4/5/6 的已知形态从运行期提前至编译期；运行期面经 checker-opaque 参数中介形态保留覆盖）
- **审计集**：**120 → 130 case**（N01-N04 源码可达 E0xxx 全链 / N05 警告非阻断双引擎 / N06 摘要行 / N07 渲染注册形 / N08 多错误三码 / N09 中止前副作用 / N10 REPL 增量 + 回滚 + parity 警告——AUDIT PASS 130/130；I04 运行期面共变 checker-opaque 形态）
- **GATE 6 构成**：集成 10 case = 正向 5 ≥1 ✓ / 负向 5 ≥3 ✓ / 跨阶段消费 ✓（L4.5→L8 新消费边 + Externals 第三消费位单源构造）
- 落位：crates/kerf-driver/（L8 + 新内部边 kerf-typecheck→kerf-driver L4.5→L8）+ tests/v1/stage1/ + 审计 N 节；§18 零新外部依赖维持
- 基线共变 5 处（行为变更披露）：pipeline/driver_seed/audit-I04 运行期 arity 面 → checker-opaque（`((fn (g) (g 1 2)) car)`）+ ds03 黄金 E0002 静态形 + ds08 版本 0.14.0

### 回归视图（1.1 终态）

- 全量套件于 §3.2 第 6 命令重跑；1.0 基线 = 846/846 → **1.1 终态 = 881/881**（净 +35：driver 内联 25 + 根集成 10——cargo test 口径；+ §7.3.1 审计集 130 case 独立可重跑——30→…→120→130 单调；**七类 7/7 全点亮维持**；846 基线零回归 + 5 处共变全披露）。

## Stage 1.2（已交付——2026-09-29，PBT 引入：DEA-13 闭合——proptest 属性层 + 三类不变量首批）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 双引擎 parity（FP1） | tests/v1/stage1/plan/pbt_seed_tests.rs（经 runner.rs） | 1 | 0 | 任意良构值程序（typed 三通道生成：Int/Bool/Any——深度 ≤4、define ≤4）双引擎三面 agree（values/outputs/globals——driver 全管线消费） |
| 运行时陷阱（FP2） | 同上 | 0 | 1 | Fn 体内 perform 任意效应名/args 0..2 → Evaluator 与 VM **各自**报 UnhandledEffect（R6 不适用域——运行时 E0006 面） |
| 归约语义（FP3） | 同上 | 1 | 0 | handle-perform 归约 = handler body 应用 + 算术组合 oracle（(a+b)+k 宿主 checked_add——define 槽断言面） |
| 静态前置（FP4） | 同上 | 0 | 1 | Define 值位裸 perform 任意效应名 → R6 静态 E0006（1.1 有限样例属性化全域——跨阶段消费） |
| Reader 不动点（FP5） | 同上 | 1 | 0 | 任意良构 StxDatum：read(display(read(display(d)))) 结构不动 + 串稳定（display = 诊断面非序列化面——口径申报） |
| VM 确定性（FP6） | 同上 | 1 | 0 | 同 bytecode 两独立 Vm 实例 run → repr 严格相等（无隐藏状态） |
| 算术 oracle（FP7） | 同上 | 1 | 0 | `(+ a b)` 双引擎 == 宿主 checked_add（±2⁴⁰ 限域——防双引擎同错的具体锚） |
| 域自检 | 同上 | 2 | 0 | 生成器名池零关键字/零内建碰撞（静态断言）+ float 域规则样本验证 |
| **1.2 合计（净 +9）** | | **7** | **2** | **PBT 属性分布论证：正负由属性域分工承载（良构域成功断言 ↔ 确定性错误对偶[FP2/FP4]）；七属性独立不变量视角零重复（相对 parity/确定性错误/归约语义/静态前置/序列化不动点/隐藏状态/具体 oracle——§12 凑数禁止的 PBT 面体现）** |

- **七类错误矩阵**：**7/7 维持**（PBT = 属性基础设施非新错误类；FP2/FP4 为既有类的属性化扩展）
- **审计集**：**130/130 维持**（1.2 裁定不扩节——PBT 与样例审计互补：良构全域 × 确定性错误族 vs 穷举错误族样例；DEA-13 闭合 = 快照/黄金/自举/属性四层测试基础设施齐备）
- **GATE 6 构成**：根集成挂载 9 函数 = 正向 7 ≥1 ✓ / 负向 2 + 既有审计负向承接（7/7 类）✓ / 跨阶段消费 ✓（FP1/FP3/FP7 消费 driver 全管线；FP4 消费 1.1 R6 静态面）
- 落位：tests/v1/stage1/plan/（根 tests/——§8.4.6 跨 crate 集成层）+ proptest 1.11.0 dev-dep（仅根测试层——§18.5 dev 侧豁免位，^1.9 约束解析 1.x line 最新）
- 基线共变 2 处（披露）：ds08 版本黄金 0.15.0（共变义务第三例）+ Cargo.lock（dev 侧锁定）

### 回归视图（1.2 终态）

- 全量套件于 §3.2 第 6 命令（release 口径）重跑；1.1 基线 = 881/881 → **1.2 终态 = 890/890**（净 +9：7 属性 + 2 域自检——cargo test 函数计数口径，PBT 生成用例量 64 case × 7 = 448 见 pbt.md §5；+ §7.3.1 审计集 130 case 独立可重跑维持；**七类 7/7 全点亮维持**；881 基线零回归 + 2 处共变全披露）。

## Stage 1.3（已交付——2026-09-29，HM 推断基座：迭代 W + SCC 分治 + 效应行收集面 + Layer 2 标注 IR）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 类型语言（FP1 前置） | crates/kerf-typecheck/src/types.rs（内联） | 9 | 0 | 显示形态（ground 镜像 kind_name 单源）+ 出现序 + schema α 重命名 + substitute + 行代数（并/差/序确定性） |
| 引擎核心 | crates/kerf-typecheck/src/infer.rs（内联） | 13 | 0 | links/undo 回滚 + 合一表（Dyn 吸收不约束）+ occurs + 深resolve + 字面量链 64 层折叠 + join + 泛化/实例化 |
| 推断正例（FP1） | tests/v1/stage1/plan/hm_inference_seed_tests.rs | 6 | 0 | 算术 int 全链 + fib 参数化 + pair 投影 + let 链 + quote 链折叠 + 嵌套 fn arrow |
| 多态实例化（FP2） | 同上 | 3 | 0 | id 同模块双用解耦（SCC-schema 实例化）+ let 多态 + even/odd 互递归结（直接构造——源路径展开器 define-so-far 严格，探针披露） |
| 确定错误族（FP3） | 同上 | 0 | 8 | E0009 八面：算术混合/非数值 + 比较混合/非数值 + car 非 pair + not + write-line + if 条件（经 define 汇聚 int）+ 调用参数位 + 多错误三码收集 |
| 递归类型（FP4） | 同上 | 1 | 1 | (x x) 自应用 E0010 + (cons x x) 合法对照 |
| 预算守卫（FP5） | 同上 | 1 | 2 | 250 层静默 + 600 层单 E0011 Warning（永不 Error）+ 该 define 整体排除 + 邻 define 照常 |
| 合法永不告警（FP6） | 同上 | 6 | 0 | 分支 join→Dyn + assigned 守卫 + 参数被调 + 前向引用（直接构造）+ **分支绑定隔离**（undo-log 健全性案——泄漏即假阳性）+ total 内建 |
| 效应行（FP7） | 同上 | 4 | 0 | perform 追加 + Handle 差集∪handler 并集 + 未拦截保留 + 嵌套残差 |
| 快照 IS 族（FP8） | 同上 | 7 | 0 | IS01-IS06 黄金（算术/多态/pair/效应行/if 汇聚/handle 差集）+ 双跑确定性 |
| 跨层协作 | 同上 | 2 | 0 | 与 check_module 并行独立收集（E0003+E0009 双报）+ TypedProgram 模块序覆盖 |
| 审计 P 节 | examples/audit/stage0_gate_audit_r1.rs | 4 | 6 | P01-P10：mismatch/occurs/budget/poly/guard/rows/adhoc/dyn/multi/determinism——全 E2E |
| **1.3 合计（净 +63）** | | **46** | **17** | **健全性对偶承载正负：确定错误必报（FP3/FP4 负向）× 合法程序永不告警（FP6 正向守卫）——误报与漏报都是 P0 故等权；内联单元为引擎机制面正向；audit 负向承接确定性错误族** |

- **七类错误矩阵**：**7/7 维持**（E0009/E0010 = 类 5 型错误的静态确定性子集 + E0011 为守卫披露非错误类）
- **审计集**：**130 → 140**（P 节 10——1.0 检查器面扩节先例沿袭：推断面 = 语言管线相关新面）
- **GATE 6 构成**：根集成 41 = 正 22 ≥1 ✓ / 负 14 ≥3 ✓ / 跨阶段消费 5 ≥1 ✓（reader→expander→infer 真实管线全链 + check 并行协作 + 快照冻结）
- 落位：crates/kerf-typecheck/（模块内增量——types.rs + infer.rs 双新模块）+ tests/v1/stage1/ + 审计 P 节；§18 零新依赖零新边
- 基线共变 1 处（披露）：ds08 版本黄金 0.16.0（共变义务第四例——注释链 0.15→0.16）
- 设计演进披露 2 项（实施期深审抓获并当轮修复）：If 分支 undo-log 隔离（健全性必需——§9.44.4 修正）+ SCC 分治（同模块多态复用假阳性修复）

### 回归视图（1.3 终态）

- 全量套件于 §3.2 第 6 命令（release 口径）冷跑；1.2 基线 = 890/890 → **1.3 终态 = 953/953**（净 +63：crate 内联 22 + 根集成 41——cargo test 函数计数口径；+ §7.3.1 审计集 140 case 独立可重跑——30→…→130→140 单调；**七类 7/7 全点亮维持**；890 基线零回归 + 1 处共变全披露；B1-B5 性能基线对账零回归——median 口径）。

## Stage 1.4（已交付——2026-09-29，kerf 子集冻结：子集规格 + 验收语料 68 + parity 契约面）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 指令解析器 | crates/kerf-driver/src/parity.rs（内联） | 8 | 4 | 六形态解析 + 拒绝面（缺前缀/空载荷/未知关键字/缺码/缺 value 尾）+ same_set + from_source 首行切分 |
| 语料逐条 | tests/v1/stage1/corpus/*.krf（经 subset_corpus_tests.rs 宏表挂载） | 27 | 41 | 68 条 = pos 26（含 E0008 警告位）+ neg 32（Reader 4/展开装载 14/检查器 8/运行时 6）+ bnd 10——每条期望经真实管线实证（探针轮 68/68 固化） |
| 语料元 | 同上（动态扫 + 底线） | 3 | 0 | 全目录完备性扫（read_dir——无孤儿文件）+ 分布底线（pos ≥20/neg ≥20/bnd ≥10/总 ≥50）+ 命名前缀唯一性 |
| 契约正向 | tests/v1/stage1/plan/parity_contract_tests.rs | 4 | 0 | 值约定（末位 define）/双引擎错误一致/警告码集/检查器码集精确比较 |
| 契约负向 | 同上 | 0 | 5 | 错值双侧漂移/检查器先拒/双停误期/阶段归因/缺警告——detector-detects 对偶 |
| 跨阶段消费 | 同上 | 3 | 0 | globals_repr 程序序（run_parity 面）+ 模块面三形路由 expand 标（parse 面）+ 双引擎 run 面同值（globals 快照） |
| 审计 Q 节 | examples/audit/stage0_gate_audit_r1.rs | 0 | 10 | Q01-Q10：错误期望检出面全覆盖（错值/错阶段双向/缺码/先拒/双停/无 define/缺警告/批次面/封闭文法）——元审计 |
| **1.4 合计（净 +93）** | | **42** | **60** | **正负比 1:1.43（语料域——非 1:3 域申报：子集冻结的验证重心 = 边界与拒绝面密度[隐式语义实证]；语料期望六形态中三类[value/warning/type-error]为正向族、三类[parse/expand/runtime-error]为负向族——分布论证见 plan-1.4.md §3 + §9.45.5；1:3 红线以**全工作树累计**口径维持[见回归视图]）；契约面自身正负由 detector-detects 对偶承载** |

- **七类错误矩阵**：**7/7 维持**（语料负向 32 条覆盖类 1[Reader]/类 2[未绑定]/类 3[空应用]/类 4[元数]/类 5[类型失配]/类 7[展开帽]全点亮——类 6 模块环由 neg-018 承载）
- **审计集**：**140 → 150**（Q 节 10——元审计先例：验证器自身的检出面审计）
- **GATE 6 构成**：根集成 83 = 语料 71 + 契约 12（正 34 ≥1 ✓ / 负 46 ≥3 ✓ / 跨阶段消费 3 ≥1 ✓）；每条语料 = 真实管线全链断言（read→expand→check→双引擎）
- 落位：crates/kerf-driver/src/parity.rs（模块内增量）+ tests/v1/stage1/corpus/（68 数据文件）+ tests/v1/stage1/plan/ 双测试文件 + 审计 Q 节；§18 零新依赖零新边
- 实证裁定四项（plan-1.4.md §4）：闭包不捕获 = E0001 正确检出（双引擎一致）+ 前向引用 = 展开期拒绝（stage-1-plan §3 R1 行口径修正）+ `()` = Reader 期拒绝 + write-line 仅 Str 域
- ParityReport 加性字段共变 3 处构造位（pipeline 内联 2 + audit I09 1——全清单披露）

### 回归视图（1.4 终态）

- 全量套件于 §3.2 第 6 命令（release 口径）冷跑；1.3 基线 = 953/953 → **1.4 终态 = 1046/1046**（净 +93：crate 内联 12 + 根集成 81——cargo test 函数计数口径；+ §7.3.1 审计集 150 case 独立可重跑——30→…→140→150 单调；**七类 7/7 全点亮维持**；953 基线零回归；**正负比累计口径 1:3 维持**[语料域 1:1.43 申报于上表]；B1-B5 性能基线对账零回归——契约面不在编译/执行热路径）。

## Stage 1.5（已交付——2026-09-29，Reader .krf 重写第一段：结构层自举 + 双 Reader parity）

| 族 | 落位 | 正 | 负 | 说明 |
|----|------|-----|-----|------|
| 表格契约与编码 | crates/kerf-driver/src/reader_parity.rs（内联） | 3 | 1 | 字符串字面量转义往返（五转义子集 + 原始控制符直通）/token 表形状锚/树轴 span 锚 vs 词法层六变体分流 |
| 树轴与错误轴 | 同上 + tests/v1/stage1/plan/reader_parity_tests.rs | 6 | 5 | 嵌套 span 逐字节/全原子类/空源/转义与裸换行/float 极值/i64 边界 vs 四拒绝类 × 位置 × 优先序（13 形态）+ 255/256/257 深度三态 + 篡改探测器双锚 + harness 缺陷即数据 |
| 跨阶段消费 | 同上 | 3 | 0 | 68 语料全扫重放（parser 66/lexer 2 双层分布）+ 自举不动点（reader.krf 读己源）+ 报告面 |
| 词法层分流 | 集成（分流族内联于负向域） | 0 | 6 | 六变体域（未终结串/非法转义/非法布尔/畸形数字/非法字符/控制符）——ParityLayer::Lexer 路径 |
| 审计 R 节 | examples/audit/stage0_gate_audit_r1.rs | 0 | 10 | R01-R10：树 span/最内层 unclosed/空表优先/stray close 双位/精确深度 payload/255 深双引擎走/分流/篡改双锚/harness 缺陷 + inf 面 |
| **1.5 合计（净 +23）** | | **11** | **12** | **正负比 ≈ 1:1.1（结构层域函数口径申报：验证重心 = 四错误类判定分支 × 位置变体密度 + 双篡改锚；1:3 红线以全工作树累计口径维持[见回归视图]——分布论证见 reader-parity.md §2 + plan-1.5.md §3** |

- **七类错误矩阵**：**7/7 维持**（reader parity = 既有 kerf-read 族的 .krf 侧镜像——非新错误类）
- **审计集**：**150 → 160**（R 节 10——detector-detects 元审计先例第二实例）
- **GATE 6 构成**：根集成 16 = 正 6 ≥1 ✓ / 负 5 ≥3 ✓ / 跨阶段消费 3 ≥1 ✓（语料全扫 + 自举不动点 + ds08 共变）；每案 = 双引擎 × 双轴四格断言
- 落位：selfhost/v1/reader.krf（自举面首件——§8.4.6 新根目录）+ crates/kerf-driver/src/reader_parity.rs + 根 tests reader_parity_tests.rs + audit R 节；§18 零新外部依赖零新内部边（kerf-reader 面类型 re-export = 可名化补全）
- Float 载荷 = Debug 文本（inf/NaN 无 .krf 字面量形态——设计走查修正）；B3 口径修正落地（28 函数 = 档案目标口径——实际范围 = 结构层四拒绝类 + 全树）
- 实测回填与内循环实录：reader-parity.md §4-§5（实现侧运行语义缺陷 0——连续十轮）

### 回归视图（1.5 终态）

- 全量套件于 §3.2 第 6 命令（release 口径）冷跑；1.4 基线 = 1046/1046 → **1.5 终态 = 1069/1069**（净 +23：内联 7 + 根集成 16——cargo test 函数计数口径；+ §7.3.1 审计集 160 case 独立可重跑——30→…→150→160 单调；**七类 7/7 全点亮维持**；1046 基线零回归；**正负比累计口径 1:3 维持**[结构层域 1:1.36 申报于上表]；B1-B5 性能基线对账——parity 面不在编译热路径[预期零影响]）。

## 阶段间实施轮 T40（已交付——2026-09-30，资源限额与预算治理域审查 v0.32.0：阶梯守卫 + 终止性论证成链——§9.63 十面审查后的实施清偿）

- 新增测试构成：限额阶梯守卫 +4（`limits_ladder_exact_and_relational`——六常量黄金 + 关系 const 断言；`vm_budget_catches_non_terminating_programs`——终止梯可执行证明；`vm_budget_counts_live_frames_exactly`——LIVE 精确边界[探针实证 3 单元]；`reader_nesting_cap_is_structured_at_the_boundary`——公共读面嵌套帽）
- 全量套件冷跑：T39 基线 1180 → **T40 终态 = 1184/1184**（净 +4：守卫族；**crates/*/src 零触碰**——纯根树测试 + 文档增量；管道面零语义变化）；审计集 **200 维持**；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 限额治理域审查度量（§9.63.8）：K98-K101 四主源直读 + 弱查披露第九轮[q4 429 限流如实登记] + LIM 裁定族十面 + 三窗登记（W-EXP-WORK / W-LIMIT-TUNABLE / W-REPL-ACC-GROWTH——零信号）+ 终止性三步论证成文成链（无循环原语 + 无 TCO + LIVE 计费 ⇒ 每个非终止程序必被结构化捕获）+ golden 面唯一触碰 = ds08 版本黄金（0.31.0→0.32.0）+ selfhost 三件零触碰

## 阶段间实施轮 T39（已交付——2026-09-30，用户交互表面域审查 v0.31.0：REPL 不完备族统一 + 声明头单源化 + CLI 对称化——§9.62 十四面审查后的实施清偿）

- 新增测试构成：用户表面域守卫 +9（expander `top_level_heads_match_dispatch_table`——const-vs-arm 双向同步[成员必取臂 + 非成员必拒]；repl 不完备族三测[多行字符串跨提交 + 裸字符串续行 + malformed 族仍即错] + `declaration_heads_are_unwrappable_and_expressions_wrap` 行为钉扎；cli 四测[--version 尾随参数 exit 2 / repl 解析默认与引擎选择 + 坏引擎与尾随参数 / eval 引擎 REPL e2e 集成]）
- 全量套件冷跑：T38 基线 1171 → **T39 终态 = 1180/1180**（净 +9：表面域族；管道面零回归——compiler/vm/runtime/dispatch 连续七版本零漂移）；审计集 **200 维持**；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 用户表面域审查度量（§9.62.8）：K92-K97 六主源直读 + 四弱查披露第八轮 + SURF 裁定族十四面（五实施 + 九维持成文）+ 五窗登记（W-RENDER-WIDTH/COLOR/JSON + W-CLI-DASH + W-REPL-PARITY——全零信号）+ golden 面唯一触碰 = ds08 版本黄金（0.30.0→0.31.0 历史链 +1）+ selfhost 三件零触碰

## 阶段间实施轮 T38（已交付——2026-09-29，性能工程与基准方法学域审查 v0.30.0：方法学 v2 实施码化 + §14.6.4 规则 5 失察修复——§9.61 十二面审查后的实施清偿）

- 新增测试构成：性能可观测性守卫 +2（`b4_churn_counters_exact_per_run`——撕裂程序逐 run 精确计数锚定[1 cycle/1023 swept × 三独立 run，比 bench 聚合除法严格强]；`bench_harness_methodology_present`——方法学 v2 四面源守卫[black_box ≥14 / warmup ≥6 / stdev ≥6 / B1a/b/c 三标签]；§9.57 读数计数守卫族同型）
- 全量套件冷跑：T37 基线 1169 → **T38 终态 = 1171/1171**（净 +2：守卫族；管道面零回归）；审计集 **200 维持**；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 性能域审查度量（§9.61.8）：三缺口勘察实证（全码库零 black_box + 零预热 + benchmarks/README 未兑现承诺）+ 规则 5 失察十轮修复（T30-T37 无 B 系列记录——重录验证零隐藏回归[B1 7.7µs 与 v0.23.0 实测一致 / B4 确定性计数与首录逐位一致]）+ 基线重录方法学 v2 全表（B1-B5 四统计量 + B1a/B1b/B1c 子轴）+ 三窗登记（W-PERF-CRATE-BENCH / W-PERF-CRITERION / W-PERF-PROFILE——零信号不开窗）+ 每轮九项复查增设第 ⑩ 项（B 系列重跑义务核对）

## 阶段间实施轮 T37（已交付——2026-09-29，驱动编排与错误传播域审查 v0.29.0：ERR-PROP 单源成文 + reader panicking 位裁定 + ★ORCH-1 globals 双契约裁定[否决-修正回路]——§9.60 十八段审查后的实施清偿）

- 新增测试构成：编译器契约守卫 +1（`global_table_reaches_every_define_and_referenced_builtin`——bc.globals = 全局名字表语义机检：纯 Define 程序表 == Define 序列精确 + vs01 形态程序表 == ["+", "r"] 内建引用名入表实证 + Require/DefineSyntax 不入表）；driver 面 run() 双契约注释成文（by contract, not by drift——勘察初判「items 单源化」被 vs01-vs10 十金色测试否决后修正为双契约裁定，§9.60.5 否决-修正回路实录）
- 全量套件冷跑：T36 基线 1168 → **T37 终态 = 1169/1169**（净 +1：保真守卫；管道面零回归）；审计集 **200 维持**；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 编排域审查度量（§9.60.8）：四层错误形态单源成文（ERR-PROP——散落三注释 → §9.60.3 单源）+ reader 恢复谱系定位 = panicking parser 位合法（K86 三分类对照 + 正当性三柱）+ W-ORCH-CALLBACK 一窗新登记（零信号不开窗）+ 管道十二阶段专段谱系闭合（§9.43.3 driver 行翻转）

## 阶段间实施轮 T36（已交付——2026-09-30，re-export/转发域审查与基座直连政策 v0.28.0：13 行跨 crate 转发全退役 + SOP v15.2 + TEST-4 三件守卫——§9.59 十二面审查后的政策实施）

- 新增测试构成：TEST-4 守卫 +3（`pipeline_crates_forward_nothing_from_other_crates`[crates/ 全树扫描零转发 + ≥10 crate 覆盖断言] + `root_facade_aliases_whole_crates_but_forwards_no_types`[两级制守护] + `forwarding_detector_detects_and_spares_correctly`[检测力臂——开发期真阳性实录：首跑捕获自身夹具错误{crate 级别名误列豁免清单}，探测器正确夹具错误]）；管道面零新增（纯依赖面手术——测试期望零改动即语义零变化实证）
- 全量套件冷跑：T35 基线 1165 → **T36 终态 = 1168/1168**（净 +3：TEST-4 三件；管道面零回归）；审计集 **200 维持**；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 转发清零度量（§9.59.8）：crates/ 内 `pub use kerf_*` = 0（rg + TEST-4 双锚）；根 facade 类型级转发 = 0；类型可达路径唯一

## 阶段间实施轮 T35（已交付——2026-09-30，crate 边界域审查与 Symbol 单池统一 v0.27.0：双孪生退役 + 单池落 kerf-span + 三错误面单源化——§9.58 十二面审查后的统一实施）

- 新增测试构成：span 合并测试族 +20（两孪生族去重合并 + Display 逐字节一致锁 + trailing-space 补例）+ 根集成 +2（`same_text_is_one_identity_across_the_syntax_and_core_faces` 单池身份语义管道级锁定 + `syntax_and_core_error_faces_share_one_rendering_source` 三错误面同渲染机检）+ 错误桥接 +2（syntax/core `symbol_error_converts` From/委托断言）；孪生合并净减：两 crate symbol.rs 内联孪生退役（~28 例）——**合并为语义覆盖零损失的合法净减**
- 全量套件冷跑：T34 基线 1174 → **T35 终态 = 1165/1165**（孪生合并 −29 + 合并族 20 + 桥接 2 + 集成 2；管道面零回归——纯类型归位面增量）；审计集 **200 维持**（audit 键形态一处同步后全绿）；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 单一度量机检（§9.58.8）：workspace `struct Interner` 计数 = 1（kerf-span）；`StxSymbol` 引用 = 0；`invalid symbol` Display 文本源 = 1

## 阶段间实施轮 T34（已交付——2026-09-30，测试基础设施自审计 v0.26.0：三清单守卫 + audit 标签规约化——§9.57 元域审查后的守卫实施）

| 切面 | 载体 | 正 | 负 | 验证重心 |
|----|------|-----|-----|------|
| runner 装配守卫（TEST-1） | tests/v1/stage1/plan/test_infra_guard_tests.rs | 1 | 0 | 双向完备：tests/ 树每一 .rs 文件 = runner.rs 挂载（未挂载 = 静默死文件当轮检出）+ 每一挂载目标在盘（陈旧挂载）——K75 tidy 测试落位纪律同构 |
| 语料表-目录 parity 守卫（TEST-2） | 同上 | 1 | 0 | corpus_case! 表 ↔ 79 文件目录集合全等（孤儿文件 = 隔离面滞后 / 幻影条目 = 文件缺失）——compiletest 散逸输出文件追踪同构；开发期真阳性实录（裸 ".krf" 后缀探针 → 判别式收紧） |
| audit 案例注册守卫（TEST-3） | 同上 | 1 | 0 | 统一注册规约（每案例 `// XNN:` 开题注释——A-C 补 25 / H07 补标 / U-V 双位化，纯注释零行为变更）后逐节计数 == 文档构成（A10+B10+C5+D5+16×10=200）+ 头条字面量 "AUDIT PASS 200/200" 机检 |
| 计数器检测力臂（TEST-3b） | 同上 | 0 | 1 | 合成夹具四近失形态（体内断言串/单位数标签/散文提及/行中注释）拒计 + 两正典形态（冒号/括号）计入——r54 检测器三臂先例 |

- 全量套件冷跑：T33 基线 1170 → **T34 终态 = 1174/1174**（净 +4：三守卫 + 检测力臂；管道面零回归——纯测试树增量）；审计集 **200 维持**（标签规约化后复跑全绿——注释面零行为变更实证）；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 设计依据单源：stage0.md §9.57（方法与证据基 + K75-K77 前沿对照 + 十二面审查表 + 权衡与实施记录 + 四登记窗）；检索存档 r34-search 七查+主源直读（三强锚 + 三弱查如实披露 + q1 两轮垃圾升级主源直读）；8 原语不变性第三十轮验证 + selfhost 三件零触碰 + Stage 2 零实施纪律维持（r54 登记 + r55/r56 重申）

## 阶段间实施轮 T33（已交付——2026-09-30，诊断域位置单源化 v0.25.0：消息-位置分离 + Session 行索引缓存 + parity 键连锁修正——§9.56 十二面审查后的两实施）

| 切面 | 载体 | 正 | 负 | 验证重心 |
|----|------|-----|-----|------|
| 消息自足性（四错误族 Display） | 四 crate error.rs 内联测试更新 + 新断言 | 8 | 2 | 位置片段缺席断言（!contains("#") / !contains("12")）+ payload 保位断言（offset()/span() == 原载荷）+ R8 形态维持（小写开头/无句尾句号）——消息与位置分离的双面锁定 |
| Session 行索引缓存（DIAG-4） | kerf-driver session.rs 内联 +1 | 1 | 0 | 缓存 == 现算（PartialEq 全等）+ upsert 重建（stale 索引错位防护）+ 未知 id fail-closed——K72 一次构建不变量 |
| parity 键（错误轴 payload 可见性） | reader_parity/expander_parity 内联 + 根树测试更新 | 12 | 4 | 键形态 = Display + 位置后缀（`@ byte N` / `@ {span}`）——oracle 精确键断言 + drift_detector 篡改检测恢复（span 选择器篡改 → matched=false）+ span_trap 五案（名字原子 span 精确性）+ module cycle/missing/duplicate 三面 + bnd-010 深度键 |
| 渲染金色再基线（有意设计变更） | snapshot_seed_tests ds01/ds02/ds04/ds05/ds10 + driver_seed e2e | 6 | 0 | 消息行零位置片段 + 位置行唯一性（`--> p.krf:1:1` 等精确形态）——文档化再基线（RELEASE_NOTES/worklog 双登记，ds03 先例） |
| audit 键形态（A-V 全节） | examples/audit/stage0_gate_audit_r1.rs 七处 | 7 | 0 | R02-R04/S05/S07/S08/T08 七断言键形态更新后 200/200 全绿——审计集与 parity 键同步 |

- 全量套件冷跑：T32 基线 1169 → **T33 终态 = 1170/1170**（净 +1：Session 缓存测试；29 失败期望全数枚举清偿——cargo test --no-fail-fast 点名法零遗漏）；审计集 **200 维持**（七处键形态同步后全绿）；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 设计依据单源：stage0.md §9.56（方法与证据基 + K71-K74 前沿对照 + 十二面审查表 + 权衡与实施记录 + 三登记窗）；检索存档 r33-search 七查+重试（三有效 + 主源直读全文 + 两弱查降档 + 重试垃圾如实登记）；8 原语不变性第二十九轮验证 + selfhost 三件零触碰（.krf 侧结构化 payload 面）+ Stage 2 零实施纪律维持（r54 登记 + r55 重申）

## 阶段间实施轮 T32（已交付——2026-09-30，确定性守护 v0.24.0：fixpoint 门 B 前置锁定——§9.55 全树迭代序审计零泄漏后的属性测试化）

| 切面 | 载体 | 正 | 负 | 验证重心 |
|----|------|-----|-----|------|
| fixpoint 主体双跑（跨 crate + 跨阶段） | tests/v1/stage1/plan/determinism_guard_tests.rs | 1 | 0 | 装配 reader（token 表前缀 + RS-1）与装配 expander（forms 流前缀 + 宏库 + EX-1/MX-2）——门 B 配方主体经两次独立 reader→expander→loader→compiler 遍历：items 结构全等 + Bytecode 结构全等（含 debug_info span）+ 非平凡性（funcs>1 / 池与全局表非空） |
| 79 语料双跑 | 同上 | 1 | 0 | 全 79 案双遍历：接受案 items+bytecode 全等 / 拒绝案诊断批全等 / 管线正族（pos-* 全部 + bnd-006）必须到达编译成功（回归护栏） |
| 宏改名面双跑 | 同上 | 1 | 0 | rename-on-capture 触发集构造（模板引入 tmp 绑定 + 使用点同名全局）→ 两次展开 mangled 树全等 + 字节码全等 |
| 检测器三臂（detector-detects） | 同上 | 0 | 3 | Bytecode PartialEq 检测力证明：常量池变异 / 全局表变异 / 指令流变异——三面必被捕获（守护的检测力非平凡） |
| 首用序语义 | 同上 | 1 | 0 | 全局表首用（源序）语义文档化测试：ab/ba 两序两表 + assert_ne（源序可观察 = 确定性排序纪律本体；哈希序永不入表） |

- **§9.55 审计基线**：61 非注释站点 / 14 文件 100% 分类——编译器域插入序索引（idx=Vec.len() + Vec 发射源 = 手卷 IndexMap，K69 同构）/ 键控查找与成员消费面（expander·typecheck·vm·runtime·core）/ 两处集合序免疫迭代（transformer.rs bindings.values() 集合并 + eval.rs globals.values() mark 不动点 + gc.rs sweep 槽索引序）/ 管线外见证域（reserved/ 19 处不入编译输出路径）；数值边界语义面复验已硬化（checked 算术 fail-closed + NaN 规范化 + 位等 NaN 判等）
- **四处不变量注释落位**：compile.rs intern_const/intern_global（插入序不变量 + fixpoint 依赖）/ transformer.rs trigger 集合并序无关 / eval.rs collect_now 根序惰性 / gc.rs sweep 索引序——纯注释零行为变更
- 全量套件冷跑：T31 基线 1162 → **T32 终态 = 1169/1169**（净 +7 根集成）；审计集 **200 维持**（零行为变更——audit 全绿即行为守卫）；**七类 7/7 维持**；正负比累计口径 1:3 维持
- 设计依据单源：stage0.md §9.55（方法与证据基 + K67-K70 前沿对照 + 逐站点分类表 + 集合序免疫证明 + fixpoint 前置裁定 + 守护实施）；检索存档 r32-search 六查（四强锚 + 两弱查降档披露）；8 原语不变性第二十八轮验证 + selfhost parity 字节全等维持 + Stage 2 零实施纪律维持（r54 显式禁入登记）

## 阶段间实施轮 T29（已交付——2026-09-29，Symbol 驻留 v0.23.0：双 crate 载荷置换 + 表示不变量与管道行为双面守卫——用户四轮点名项代码清偿）

| 切面 | 载体 | 正 | 负 | 验证重心 |
|----|------|-----|-----|------|
| 表示不变量（core 层） | crates/kerf-core/src/symbol.rs（内联 +5） | 4 | 1 | 同一文本单身份（跨构造路径 eq+hash）/ 多驻留不扰（64 crowd 后 as_str 往返）/ Debug 文本稳定（`Symbol { text: "x" }` 逐字节 + 索引无关）/ niche 布局（Option<Symbol> = 4B）/ 拒后不污染 |
| 表示不变量（syntax 层镜像） | crates/kerf-syntax/src/symbol.rs（内联 +5） | 4 | 1 | 孪生镜像族（同 core 五案——相位孪生纪律延伸到驻留面） |
| 管道行为（跨 crate） | tests/v1/stage1/plan/symbol_intern_tests.rs（+7） | 5 | 2 | symbol-heavy 程序双引擎（VM/Eval 各一 + 结果 60）/ let 遮蔽最内绑定（同文本异绑定不塌缩）/ parity 合意（跨阶段）/ parity 契约错误期望检测（detector-detects）/ 未绑定名诊断精确文本 ×2（顶层 + fn 体内自由名——interner 保真面） |

- **涟漪审计八项**（前置 grep 勘证）：零 `BTreeMap<Symbol>` / 五 sort 点零 Symbol 序消费者（expander code.rs:96 排 String · infer.rs:1893 排 SCC usize · parity.rs:287-288 排 String 标签 · opcode.rs:222 + builtin.rs:300 排 &'static str）/ Debug 黄金唯一 text: 断言 = reader 错误载荷不受影响 / serde 0 / .text 直访仅两文件自身 / Value 无 Symbol 变体 / Option<Symbol> niche 维持 / CoreExpr 无 Ord——**公开 API 零变更下表示置换的涟漪面全绿**
- 全量套件冷跑 + 热复跑双锚：1.9 基线 1145 → **T29 终态 = 1162/1162**（净 +17：内联 10 + 根集成 7）；审计集 **200 维持**（表示置换不改行为——audit 全绿即为最强行为守卫）；**七类 7/7 维持**；B1-B5 带内（**B1 7.7µs 驻留红利带内新低** / B3 10.4ms +11% 带内如实登记）；正负比累计口径 1:3 维持
- 设计依据单源：stage0.md §9.52（触发器开启记录 + K54-K58 前沿对照 + 三方案权衡 + 缺陷四风险知情裁定 + 实施记录）；落位 = 冻结层私有表示面（用户「stage0-1 都可变」授权；公开面零扰动）；8 原语不变性第二十五轮验证 + selfhost parity 字节全等维持

## Stage 1.9（已交付——2026-09-29，末轮收口：深审族全流程 + 七件套终稿 + 出阶段评审——**Stage 1 → Stage 2 GO 推荐**）

- **对象**：§21.5 九信号的可重跑证据面 + §14.5-14.9 深审族终稿。
- **审查先行（§9.50 / v9.16）**：检查器域 R1-R8 逐规则审查（管道五段谱系第五段——**唯一零 ★ 段**：保守纪律/双镜像/级别分级/动态健全性边界四轴全过）+ 冻结层收口重审（span/syntax/core 自 0.11 零变更——git f13852c 勘证）+ K40-K41（MIND fixpoint 三件套对照 + Elixir 1.20 共存纪律谱系；四弱查降档）。
- **出阶段测试族（净 +10）**：`tests/v1/stage1/plan/stage_exit_tests.rs`——九信号逐项锚（双引擎语义稳定/门 B 复合源/语料目录契约 79/预算 live+fail-closed/E0009 渲染黄金[锚位 1:45 探针实测]/冻结基数 18+24/双大程序零发现/全链数据流/双层批次/恢复收口）；正 6 / 负 3 / 跨阶段消费 4。
- **audit V 节（190→200）**：每案一信号——语义稳定（内建族双引擎）/自举验证（门 B 双轴）/测试覆盖（语料重放）/性能基线（预算面 live+fail-closed）/文档同步（渲染黄金）/处理程度（冻结基数）/债清零（装配源 + fib 零发现对偶）/外循环可审计性（节集 + worklog 镜像在场）/跨阶段验证（全链数据流）/恢复收口；探针锚定三处（V3 负案计数/V5 锚位/V8 标记形态）。
- **深审族终稿**：deep-review-round1.9.md（D1-D8 三段式全过 + §14.8 八项偏差清单全处置[B3×2/B4×3 已回写·B1×2 入 Stage 2·宪制零偏差] + C1-C6 六检零整改 + 5.5/5.5 GO）+ 七件套 FINAL（architecture 评分表 + 扩展成本 / coverage 四缺口清单全空 / hidden-problems 增长评级 + 就绪度裁定 / refactoring 五轮重构 §12 判定 + 弃选记录 / performance 1.9 复测表[B1 9.4µs 全程 ±2%] / final-assessment 九信号全勾 + C1-C6 跨阶段章节 + GO 推荐）。
- 全量套件冷跑：1.8 基线 1135 → **1.9 终态 = 1145/1145**（净 +10）；审计集 190→**200**（V10）；**七类 7/7 维持**；B1-B5 复跑带内（9.4µs / 97.45ms / 9.4ms / 0.372ms / 97.0ms）；**Stage 1 全程：767 → 1145（+378）+ audit 110 → 200**。

## Stage 1.8（已交付——2026-09-29，末轮预备：门审全集复跑 + HM 接线 + 校准统计 + 深验七件套准备）

- **对象**：Stage 1 全子阶段（1.0-1.7）的集成正确性门审 + HM 层 driver 接线（plan-1.3 "1.8 议程" 兑现）+ §6.6 校准 Stage 1 面回填 + §14.6.6 七件套骨架。
- **HM 接线与假阳性修复（GATE-2）**：pipeline.typecheck() = check_module（R1-R8）+ infer_module（E0009-E0011）同批收集（多错误不短路）；**接线即暴露 1.3 层假阳性**（装配源 E0009——孤岛测试全绿，接入即翻车 = §7.3 集成正确性条款实证）——修复 = release-and-demand：unify_args 形状冲突默认回滚放行（异构 tag-dispatch 合法）+ if-cond bool 需求表例外（fp3_call 语义保持）+ occurs 保留；FP3 硬化五锚（释放族 ×3 / 需求保持 ×1 / 已知释放登记 ×1）。
- **门审全集复跑（GATE-1）**：A-T 十九节全量复跑 + **U 节 10 案**（U1 HM 三断言[E0009 阻断/良构对偶/装配源零 Error 锚] + §7.3.2 上轮修复边界 ×5[混合四头文法/三代宏链/mangled 字段篡改探测器/装配序中立/哨兵零路由] + 跨子阶段集成 ×4[全链双引擎 fib 144/警告骑行 parity/双层同批/多族收集]）——审计集 **180 → 190**。
- **共变族（期望全实测——drift 消息为锚）**：语料五案指令行双层化（neg-031/037 → +E0009；neg-041/044/047 runtime-error → type-error E0009——HM 接线的语料语义共变，1.1 "both layers report" 先例）+ ds02 黄金源码置换（HM 放行动态参数保 runtime 面）+ ds02b/e2e_hm_checker 新增（checker 面新覆盖）+ driver_seed/pipeline/wiring 批次期望（+E0009 双层）+ audit I05/N02/N08 三锚。
- 全量套件冷跑：1.7 基线 1128 → **1.8 终态 = 1135/1135**（净 +7：FP3 硬化 5 + ds02b + e2e_hm_checker；共变族九处零净增）；审计集 180→**190**（U10）；**七类 7/7 维持**；B1-B5 零回归（1.9 出阶段复跑义务）。
- **校准（GATE-3）**：calibration-data.md §2 补 1.4-1.7 实测验证四行 + Stage 1 阶段汇总行 + 教训制度化（孤岛能力应在交付轮内接线驱动面——1.9 出阶段评审条款化）。
- **七件套（GATE-4）**：docs/develop/v1/stage-1/ 六文档骨架（architecture-review 预填后端审查表 / design-impl-test-coverage 三列预置 / hidden-problems 窗口清单 / refactoring-optimality 1.8 决策 / performance-baseline B1-B5 携带 / final-assessment 证据清单）+ pipeline-test-coverage.md §8（HM 双层错误路径覆盖 + 后端前置链正面例证）——每文档含 1.9 终稿义务表。

## Stage 1.7（已交付——2026-09-29，基础宏 .krf 重写第三段：宏面自举 + Macro 层收缩 + fixpoint 门 B）

- **对象**：selfhost/v1/ 装配程序（macro.krf 第三件纯函数库 + expander.krf 宏面扩展——MX-2 双文件装配契约）对 Rust oracle（transformer.rs + expand.rs 宏调用点）的宏面 parity。
- **判定面**：树轴（dump 文法含 mangled 记录宿主解码——`format!("{base}__macro_{counter}")` 逐字节）+ 错误轴（macro-mismatch 新臂）+ **门 B 双口径**（(a) 字节码全等 `compile(rebuild(krf)) == compile(oracle)`——宿主重建器 + Bytecode PartialEq；(b) 装配源自应用三方一致）。
- **三层分流收缩**：Reader 6 / Macro 0（哨兵零路由断言）/ Expander 73 = 79 案。
- **世代线程**：输入记录尾 gen 字段（源恒 0 / 宏产物 use_gen+1）——dump 文本零变、重建器消费。
- 全量套件冷跑：1.6 基线 1098 → **1.7 终态 = 1128/1128**（净 +30：内联 16 + 根集成 13 + 语料 7 案）；审计集 170→**180**（T 节 10 案）；**七类 7/7 维持**；B1-B5 零回归（B1 median 9.4µs / B2 97.8ms / B3 9.4ms / B4 0.38ms / B5 97.0ms 带内）。

## Stage 1.6（已交付——2026-09-29，Expander .krf 重写第二段：展开层自举 + 双 Expander parity）

| 族 | 落位 | 正 | 负 | 说明 |
|----|------|-----|-----|------|
| 流编码与三层分流 | crates/kerf-driver/src/expander_parity.rs（内联）+ tests/v1/stage1/plan/expander_parity_tests.rs | 4 | 3 | 前序流形状锚/Reader 层六变体分流/Macro 层 define-syntax 路由/树轴精确锚（(define x 1) 全 dump）vs harness 缺陷即数据 + 篡改深度守卫 |
| §9.47.3 七 span 陷阱 | tests/v1/stage1/plan/expander_parity_tests.rs | 7 | 3 | ★1 quote 整 form span/★2 fn 糖 name 原子/★3 binding 值节点/★4 do 恒等 + 平 Let/★5 set! unbound name 原子/★6 handler 整 clause/★7 require 符号名 MalformedForm（每陷阱 = 精确 span 断言 + 双引擎一致） |
| 绑定纪律 | 同上 | 3 | 2 | let\* 后值见前名/define 前绑定自引用/跨 define 前向引用拒（unbound f 精确 span）/module 帧隔离（unbound x 精确 span） |
| loader 面 | 同上 | 1 | 3 | ModuleCycle（a→b→a 精确路径）/ModuleNotFound（nope 精确消息）/ModuleDuplicate（后声明 span）——字符串 require 三面 + 语料锚 |
| 跨阶段消费 | 同上 | 3 | 0 | 语料 72 全扫重放（Reader 6/Macro 2/Expander 64 三层分布断言）+ 双面自举不动点（结构面 49 项树 + 错误面 unbound forms 同 span）+ 深路径（bnd-006 双引擎 255 深/bnd-007 Reader 层） |
| 语料扩展 4 案 | tests/v1/stage1/corpus/ + subset_corpus_tests.rs | 4 | 0 | pos-029 字符串 require + 比较内建三连 + read-line 未调用/pos-030 嵌套 module/neg-048 环/neg-049 缺失——期望探针轮一次实证（72/72 首跑全绿） |
| 审计 S 节 | examples/audit/stage0_gate_audit_r1.rs | 0 | 10 | S01-S10：树锚/七陷阱六案/loader 三面/三层分流三案/篡改双锚（detector-detects 元审计第三实例） |
| **1.6 合计（净 +29）** | | **22** | **21** | **正负比 ≈ 1:0.95（展开层域函数口径申报：验证重心 = 判定分支 × span 位置变体 + 双篡改锚；1:3 红线以全工作树累计口径维持[见回归视图]——分布论证见 expander-parity.md §2-§3 + plan-1.6.md §3** |

- **七类错误矩阵**：**7/7 维持**（expander parity = 既有 kerf-expand 族的 .krf 侧镜像——非新错误类）
- **审计集**：**160 → 170**（S 节 10——detector-detects 元审计第三实例）
- **GATE 6 构成**：根集成 18 = 正 10 ≥1 ✓ / 负 8 ≥3 ✓ / 跨阶段消费 3 ≥1 ✓（语料全扫 + 双面不动点 + 深路径）；每案 = 双引擎 × 双轴四格断言
- 落位：selfhost/v1/expander.krf（自举面第二件）+ crates/kerf-driver/src/expander_parity.rs + 根 tests expander_parity_tests.rs + audit S 节；§18 零新外部依赖零新内部边（可名化补全两例：kerf-compiler re-export CoreExpr/Binding/HandlerClause + kerf-expander re-export CoreError）
- **互递归禁令的工程化解**：单 define 自递归 + 五合成节点模式（mapx/letloop/doloop/clausemap/fnbind）——REC-A 谱系第三实例；扁平前序流（255 深不触 256 帽）
- 实测回填与内循环实录：expander-parity.md §4-§5 + plan-1.6.md §4（实现侧运行语义缺陷 0——连续十一轮；内循环修正全为记录形状/累加器 CT-CL/帧操作/测试期望层——探针战术三轮实录）

### 回归视图（1.6 终态）

- 全量套件于 §3.2 第 6 命令（release 口径）冷跑；1.5 基线 = 1069/1069 → **1.6 终态 = 1098/1098**（净 +29：内联 7 + 根集成 18 + 语料 4——cargo test 函数计数口径；+ §7.3.1 审计集 170 case 独立可重跑——30→…→160→170 单调；**七类 7/7 全点亮维持**；1069 基线零回归；**正负比累计口径 1:3 维持**[展开层域 1:0.95 申报于上表]；B1-B5 性能基线对账——parity 面不在编译热路径[预期零影响]）。

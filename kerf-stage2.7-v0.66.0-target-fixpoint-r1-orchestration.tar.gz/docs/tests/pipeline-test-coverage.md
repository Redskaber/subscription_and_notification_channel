# 编译流水线测试覆盖与完整性审查（pipeline-test-coverage.md）

> 依据：docs/sop.md §14.6.1.1（数据流覆盖分支检测——完整性审查：枚举全覆盖 + 无静默处理 + 错误路径覆盖 + 流水线阶段覆盖）+ §14.6.4 规则 5（性能基线表引用位）
> 产出轮次：Stage 0.11 末轮（2026-09-28）——全流水线首次四维机械审查（数据采集：Task 16-b3-data，全量 rg 扫描 + 逐处人工分类）
> 口径：production = 各文件 `#[cfg(test)]` 边界之上；test = 内联测试模块 + `tests/` 树 + `crates/*/tests/`

## 1. 枚举全覆盖审查（完整性第一轴）

生产代码枚举共 **32 个**（28 pub + 4 私有）。关键错误/管线枚举在主消费点的穷尽性实测：

| 枚举 | 变体数 | 主消费点穷尽性 | catch-all 位 |
|------|-------|--------------|-------------|
| ReadError | 10 | Display + `offset()` 全穷尽 | **0** |
| ExpandError | 9 | Display + `span()` 全穷尽 | 1（`Error::source`——Option 整形，sound） |
| ModuleError | 3 | Display 全穷尽 | 0 |
| CompileError | 13 | Display（13 臂）+ `span()`（13 臂）全穷尽 | **0** |
| RuntimeError | 11 | Display + `span()` 全穷尽 | 1（`got_kind`——Option 整形，sound） |
| SyntaxError / CoreError / SpanError | 2/3/3 | Display 全穷尽 | **0** |
| Severity / DiagnosticCode | 4/5 | `Display`/`tag()` 全穷尽 | **0** |
| StxDatum | 6 | `kind_name`/`Display`/`expand_node` 全穷尽 | 24（全部为形状探测助手或畸形拒绝——非漏配） |
| CoreExpr | 9 | 编译器 `expr` 与求值器 `eval` 双面 9/9 全穷尽 | 1（eval.rs:240 非闭包 define 值直通求值——语义面） |
| ModuleItem | 4 | `eval_items` + `compile_program` 双面 4/4 | 3（含 1 处带消息 `unreachable!`——声明映射不变量） |
| LiteralValue | 6 | `kind_name`/`Display`/`from_literal` 全穷尽 | 2（`pair_cells` `_ => 0`——非 Pair 字面量零堆格，类型事实） |
| **Opcode** | 24 | **VM 主循环 dispatch 24/24 全穷尽零 catch-all** | 6（verify 三处跳过臂 + builtin 四处守卫臂） |
| Value | 8 | `kind_name`/`Display`/parity `render` 全穷尽 | 4（Option/布尔整形面） |
| HeapObj | 2 | gc.rs 标记走查显式 None+双 Some 臂 | 4（经 `Option<HeapObj>` 整形） |
| Builtin | 18 | 注册表穷尽 + `None => unreachable!`（表完备不变量） | 4（分派守卫） |

**结论**：核心错误族（ReadError/CompileError/RuntimeError/SyntaxError/CoreError/SpanError/Severity/DiagnosticCode）在全部消费点**编译器验证穷尽或零 catch-all**；VM 操作码 dispatch 为 24/24 全穷尽。全部 catch-all 均为四类合法形态：形状探测（Option/bool 整形）、畸形输入拒绝（返回 Err）、类型事实臂（`_ => 0`）、带消息守卫（unreachable!/panic! 携带不变量说明）。

## 2. 静默处理审查（完整性第二轴）

- **`.unwrap()` 生产面：0 处**（全部 ~100 处均在测试模块内）。
- **`.expect()` 生产面：33 处，100% 携带内联理由消息**：VM 13（verify 前置不变量 + 入口帧不变量 + debug_info 平行保证）、runtime 2（零 span 构造恒成立 + 闭包注册配对）、registry 1（Vec push-then-last）、compiler 2（冷启动锚 span + 闭包配对）、driver 1（line_of 耦合）、expander 6（匹配臂守卫 + 生成长度恒真）、reader 3（单调 span 构造）、cache 3（**panic-by-design 合同 kit**——函数文档明示「首违例即 panic」）。
- **`panic!()` 生产面：1 处**（vm.rs:530 堆格闭包不变量——分配点类型化论证）。
- **`unreachable!()` 生产面：11 处**，其中 7 处携带消息；**4 处裸 `unreachable!()`**（builtin.rs:132/143/174/182——算术/比较分派 Int/Float 路径，臂前守卫已限定种类；唯一无消息生产 panic 面，登记为 Stage 1 诊断议程顺带项，非 Stage 0 债——见 hidden-problems-assessment.md）。
- **`.ok()` 生产面：1 处**（diagnostic.rs:98——空 span 构造结构恒真，不可吞真错误）。
- **`let _ =` 丢弃：21 处**，全部为 CLI 外壳输出 best-effort 写（broken-pipe 不 panic——shell 惯例）+ stdin 空带容错，均有注释。

## 3. 错误路径覆盖审查（完整性第三轴）

- 七类错误负向 7/7 维持（matrix.md 累计视图 + audit 110/110 门审级双门槛）。
- 错误枚举变体级负向覆盖：ReadError 10/10、ExpandError 9/9、ModuleError 3/3、CompileError 13/13、RuntimeError 11 变体（含 BudgetExceeded/GcStall/Halt 非源可达族经注入面测试）。
- 管线入口（pipeline.rs / cli.rs / session.rs）：零 unwrap/expect/ok 丢弃，全部 `Result` 经 `map_err(|err| vec![Diagnostic::…])`/`?` 传播——**错误即数据（§12.2）实测成立**。

## 4. 流水线阶段覆盖审查（完整性第四轴）

| 阶段 | crate | 内联测试 | crate API | 根集成（seed） | 合计 |
|------|-------|---------|-----------|--------------|------|
| L0 Span | kerf-span | 32 | 8 | 8（span_seed） | 48 |
| L1 Syntax | kerf-syntax | 32 | 8 | 8 | 48 |
| L2 Reader | kerf-reader | 46 | 8 | 9 | 63 |
| L3 Expander | kerf-expander | 77 | 8 | 8+27（expander+macro） | 120 |
| L4 Core | kerf-core | 90（含 reserved 57） | 20 | 8+17（core+reserved） | 135 |
| L5 Compiler | kerf-compiler | 36 | 8 | 8 | 52 |
| L6 VM | kerf-vm | 48 | 7 | 8 | 63 |
| L7 Runtime | kerf-runtime | 37 | 5 | 20 | 62 |
| L8 Driver | kerf-driver | 91 | 6 | 22 | 119 |
| 跨层快照 | 根 tests | — | — | 57（snapshot_seed） | 57 |
| **合计** | | **489** | **78** | **200** | **767** |

阶段间交接点（§14.7.3 数据流五段）全部有跨层集成锚：read→expand（expander_seed）、expand→compile（compiler_seed fib 全链）、compile→vm（vm_seed 四段一断 + fib(25)=75025）、vm↔eval（runtime_seed 双路径 ≥15 程序 + parity 三面）、全链→driver（driver_seed 22 + snapshot_seed 57）。

## 5. 修复状态

| 发现 | 处置 |
|------|------|
| vm/error.rs:8 类覆盖注记停留 6/7（历史现在时态） | **本轮已修**（补 0.9 第七类点亮句） |
| diagnostic.rs:17 「0.10 拥有该扩展」将来时态 | **本轮已修**（改为 Stage 1+ 登记议程措辞） |
| builtin.rs 四处裸 `unreachable!()` | 无消息但臂前守卫完备——登记 Stage 1 诊断议程顺带项（hidden-problems-assessment.md 行 4），非 Stage 0 阻塞 |

## 6. 性能基线表（§14.6.4 规则 5——引用位）

性能基线单一事实源 = `docs/develop/v0/stage-0/performance-baseline.md`（B1 编译 9.3µs 中位 / B2 VM fib(25) 96.7ms / B3 eval fib(20) 9.4ms / B4 GC 压力 0.36ms + 1 cycle/iter + swept 1023 / B5 端到端 97.6ms；回归口径 = median 恶化 >25%）。本表不重复承载。

## 7. 结论

四轴全过：枚举全覆盖 ✓（错误族零漏配 + Opcode 24/24 dispatch 穷尽）、无静默处理 ✓（unwrap 0 + expect 33 全带理由 + ok 1 结构恒真）、错误路径覆盖 ✓（7/7 类 + 变体级 + 入口零丢弃）、流水线阶段覆盖 ✓（九层各有三层测试 + 交接点全锚定 + 快照层 57 全链冻结）。**§14.6.1.1 通过**。

## 8. Stage 1 增量：HM 接线与后端前置链（1.9 终稿——签收）

> 依据：§14.6.1.1 + stage0.md §9.49.3/§9.50。**1.9 签收态**：本节
> 经 deep-review-round1.9.md D8 复核——HM 双层六行 + 后端前置链
> 正面例证维持，另增九信号锚（audit V 节 + 出阶段测试族
> stage_exit_tests.rs 10 案——测试流/设计流/编译管道流三方印证
> 的常驻 cargo 锚）。

### 8.1 HM 双层接线后的错误路径覆盖（1.8 实测）

| 面 | 覆盖 | 锚 |
|----|------|-----|
| E0009 driver 面阻断 | Error 级经 check()/run() 批次 | U1a + e2e_hm_checker + wiring |
| 双层同批共存（E0003+E0009） | 多错误收集不短路 | U9 + N02 + corpus neg-031/037（指令行 1.8 双层化） |
| HM 放行语义（tag dispatch） | 假阳性修复回归锚 | FP3 硬化 ×3（释放/递归/回滚干净） |
| bool 需求例外 | 传播保持 Error | fp3_call + fp3_bool_demand + U1a |
| E0011 Warning 放行 | 预算披露不阻断 | P 节既有 + corpus bnd 族 |
| 装配源零 Error | 修复语义锚（1.4k 行真实程序） | U1c |

### 8.2 后端前置链正面例证（§9.49.3 ★4——预填）

VM 裸索引族（LoadLocal/StoreLocal/LoadGlobal/StoreGlobal）无内联越界检查——**第二道防线持有边界**（verify 的 LocalSlotOutOfRange/GlobalIndexOutOfRange + span_of 平行性 expect 族），前置不变量链完整非静默：编译期 jump 断言（第一道）→ 加载期 verify（第二道）→ 运行期裸索引（信任链终点）。1.9 复核义务：以本节为架构审查（§14.6.1.2）输入重签。

## 9. Stage 2 增量（2.6 骨架——r90 落位；r91 首刀供给；r92 收口维持；2.8 终稿义务）

> **Status**: 骨架（§14.6.6 七件套之七——Stage 2 口径完整性审查小节；沿 §8 Stage 1 增量同位先例）；**r92 收口行（2.6 关闭）**：四轴全维持复跑——1405:0:0 + audit 274/274 + 语料 C 全量重放 41/41 #[ignore] 复跑 + B9c 复跑带内，评估轮零新测试面；**终稿义务 = 2.8 Stage 2 末轮**。

### 9.1 现状基线（截至 r90）

| 完整性轴 | Stage 2 实态 |
|---|---|
| 枚举全覆盖（第一轴） | 语料 85 全路由钉扎（读层 8 / 展开层 19 / 编译层 58——r86 漂移分类账）；audit **274** case A-Z+**AA** 二十五节（r91 AA10——首个双字母节；发射器 25 操作码全路径钉扎{源面 14 + 手搓补 10}） |
| 静默处理（第二轴） | fixpoint fail-closed 双断言 + B7/B8 轴前置条件钉扎（perf_observability_guard）；rebuild 畸形产品 fail-closed 族（Z19-Z22）；**cc 门控缺席 = 跳过披露不失败**（r91：披露句式钉扎 + 发射器 verify 前置门 + 两转译形态守卫 fail-closed） |
| 错误路径（第三轴） | 七类错误 7/7 维持；E0012 捕获边界三层防御（checker + CompileError + RuntimeError 同族措辞） |
| 流水线阶段（第四轴） | 五件 selfhost 全链 parity（组成链 + fixpoint 常设证据）；junction 逐点篡改探针三臂；**链外 C 通道**（r91：语料 C 全量重放 41/41 + 值显示对账{即时值 9 + 浮点电池 12} + 运行时错误族双非零 + 预算/深度覆写守卫） |

### 9.2 2.8 终稿义务

- [x] C 转译后端四轴增量（发射器枚举面 / cc 门控静默面 / e2e 错误路径 / 流水线新阶段接入）——**2.6 实施轮已供给（r91）**：四轴各就位（枚举 = 25 操作码全路径 + 18 内建名单源映射；静默 = 披露句式钉扎 + fail-closed 守卫族；错误路径 = 运行时错误族 8 例 + arity 族 3；新阶段 = 语料 C 全量重放 41/41 + audit AA10）
- [ ] FFI 边界测试轴（R-F 规则违反面负向覆盖）——2.8 评估窗供给
- [ ] 全轴 Stage 2 口径重签（以本节为 §14.6.1 输入）

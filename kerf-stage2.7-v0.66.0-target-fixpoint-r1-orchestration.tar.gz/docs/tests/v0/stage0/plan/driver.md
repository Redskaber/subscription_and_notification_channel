# Stage 0.8 测试文档——kerf-driver 管线编排 + 诊断渲染收口 + CLI/REPL

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-driver/**（内联 + api_tests）+ tests/v0/stage0/plan/driver_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs I 节（§7.3.1 审计集单调增长 70→80）
> 设计依据：docs/stage0.md §12.1（渲染期派生原则——「行号/列号在渲染诊断时由偏移派生，避免双源存储」= TD-001 清偿锚）+ §12.2（「错误是数据而非异常」——多错误单次运行报告）+ §8.7（Diagnostic 结构 rustc 风格）+ §8.8（最小 I/O 传统全局函数）+ docs/sop.md §7.1/§7.1.1（集成测试全套口径 + 七类负向矩阵）+ stage-0-plan.md §5 行 0.8 + roadmap §6 post-0.7 首议程 + plan-0.7.md §8 消费契约（Evaluator/Vm/parity 面）+ R8（CLI/编码面全英文）

## 1. 目标

验证 Stage 0.8 kerf-driver 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | session.rs 会话/文件 intern | 章程项「会话/文件 interning」：`Session` 将文件名↔`FileId` 顺序分配（u32 递增）；**upsert 语义**（同名再 intern = 同 id + 源替换——REPL 累积源重跑的载体）；name/source 反查（未知 id → `Option` None——fail-closed 静默拒绝）；诊断渲染的源文本唯一供给方（单一可信数据源 §2.3-2） |
| FP2 | line_index.rs 行列派生（TD-001 清偿） | §12.1 渲染期派生原则落位：`LineIndex::new(&str)` 一次构建（换行起点向量）；`line_of(offset)`（0 基行号——二分查找，超界钳制到末行）；`to_line_col(offset)`（**1 基行 + 1 基字符列**——字符列非字节列：CJK 源终端列位正确性；多字节字符中点偏移向下取整到字符边界——确定性钳制不 panic）；`line_bounds(line)`（行起点/换行前终点——摘录渲染 + 跨行 span 行内钳制）；`line_count()`；CRLF 行尾 `\r` 摘录裁剪 |
| FP3 | diagnostic.rs + render.rs 诊断收口 | §8.7 结构 Stage 0 切片：`Severity`（Error/Warning/Note/Help 四变体——§8.7 契约形状；0.8 仅 Error 有生产者，其余 = 结构面预留披露）/`DiagnosticCode`（阶段级：Read/Expand/Compile/Runtime/Driver——变体级 E0xxx = Stage 1+ 议程登记）/`Diagnostic{severity, code, message, file, primary_span: Option<Span>}`（**Option 诚实设计**：ReadError 四变体/CompileError 三变体天然无位置——「缺失即缺陷本体」，伪 span = DUMMY 同罪拒绝）；消息 = 各阶段错误 Display 原文透传（R8 单源字典零漂移）；`render_diagnostics(&Session, &[Diagnostic])` rustc 风格渲染：`error[kerf-read]: msg` + ` --> name:line:col` + 源摘录 + 脱字符（span 长度下划线、空 span 单 `^`、跨行钳制首行、无位置免 `-->` 免摘录）+ 多诊断空行分隔 + N>1 汇总行 `error: aborting due to N previous errors` + 行号槽宽自适应 |
| FP4 | pipeline.rs + repl.rs + cli.rs 编排与入口 | `Engine{Vm, Eval}` 双引擎驱动（§18.5 既有边 L5→L8/L6→L8 + **新边 L7→L8**——eval 路径函数调用面，裁定入档 plan-0.8.md）；`run_source` 五段链（read→expand→compile→Vm::new[verify]→run / read→expand→Evaluator::eval_program）错误全径 `Vec<Diagnostic>`（多错误单次报告 §12.2——跨文件收集点 = Session 多文件逐个处理）；`run_parity`（双引擎同源 + assert_parity + 输出序列一致断言）；`check_source`（compile+verify 免执行）；`Repl` 状态机（**session-replay 语义**——裁定入档：累积源整体重跑 + 单调输入带回放 + 表达式提交源级包装 `(define $repl:N expr)` = r110「top-level expression channel = define calling form」落位 + 错误回滚（失败提交不入累积——后续提交可用性保持）+ 未闭合继续累积 + 增量输出（前缀一致则仅打印新增尾部））；`kerf` CLI（`run <file> [--engine vm\|eval] [--parity]` / `check <file>` / `repl` / `--help`；stdin 管道预载输入带；退出码 0/1/2；R8 全英文） |

## 2. 场景

- **正向**：Session intern 顺序 id + upsert 同 id 源替换 + 反查；LineIndex 空源（line_count=1、offset 0→(1,1)）/ 单行无换行 / 多行基本派生 / CJK 字符列（字节偏移≠显示列）/ 换行边界归属；Diagnostic 字段构造 + Severity/DiagnosticCode Display；render 黄金快照（单诊断含 `-->` + 摘录 + 脱字符 + 槽宽 ≥10 行两位行号）/ 多诊断分隔 + 汇总行 / span 下划线长度 / CJK 摘录；pipeline：fib(10) Vm 路径值 + fib(10) Eval 路径值 + parity 双引擎一致报告 + check 通过（免执行零输出）+ write-line 输出面 + read-line 输入消费面；repl：define 后表达式取值 / 多表单提交 / 计数器递增 / 未闭合继续输入后恢复 / 增量输出前缀裁剪；cli：run/check/repl/help 参数解析
- **负向**：Session 未知 id → None；LineIndex 中点偏移向下取整 / 超末偏移钳制 / 孤立换行 / CRLF / 空 span 列；Diagnostic **四阶段 41 变体穷尽映射**（ReadError 10[6 有位 4 无位] + ExpandError 7[全有位] + CompileError 13[10 有位 3 无位] + RuntimeError 11[全有位]——位置提取 + code 归属逐变体循环断言，编译器穷尽 match 守护）；render 无位置免 `-->` / 空 Vec 空串 / 跨行 span 首行钳制 / 零长 span 单脱字符 / 未知文件防御；pipeline：四阶段错误各径诊断（read/expand/compile/runtime code 断言）/ 运行时错误 span 行列回查 / parity 分歧检测（合成异值经 assert_parity 必报——检测器自检沿 0.7 先例）；repl：错误提交回滚后继续 / read-line 超带 Eof / 空行忽略 / 回滚后输入带复位；cli：未知命令 / 缺参 / 坏引擎名 / 文件不存在（退出码 2/1 断言）
- **跨阶段消费**：**§7.1 E2E 全链全套**（源码字符串 → driver → 值/诊断——六类已点亮错误类全数经 driver E2E 可达（语法/空应用/未绑定/展开深度/参数个数/类型不匹配）；正向 fib 源码→VM 值 + eval 值 + parity 三面）；driver 消费 0.3-0.7 全链公共面（read_program/expand_program/compile_program/Vm/Evaluator/assert_parity——§18.5 边活性实证）；审计集 I 节经 CLI 等价路径（render 黄金串稳定）；REPL 会话 E2E（多提交序列——define→expr→error→expr 存活）

## 3. 实测数（三层 + 审计集——实现后回填，§9.2 双向印证）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（消费面扩展） | reader error.rs（0+3）/ compiler error.rs（0+2）——expander span() 0.4 已预置免扩展 | 0 | 5 |
| 单元 session.rs | 内联 | 4 | 1 |
| 单元 line_index.rs | 内联 | 10 | 3 |
| 单元 diagnostic.rs | 内联 | 5 | 6 |
| 单元 render.rs | 内联 | 9 | 4 |
| 单元 pipeline.rs | 内联 | 7 | 8 |
| 单元 repl.rs | 内联 | 11 | 5 |
| 单元 cli.rs | 内联 | 11 | 7 |
| crate API | crates/kerf-driver/tests/api_tests.rs | 4 | 2 |
| 跨 crate 集成 | tests/v0/stage0/plan/driver_seed_tests.rs（经 runner.rs） | 12 | 10 |
| **测试合计** | | **73** | **51** |

- 正负比 = 73:51 ≈ 1:0.7（**偏差申报**：driver = 编排层，正向组合路径（双引擎驱动/渲染黄金/REPL 会话语义/CLI 命令族）是层的主功能面——每一正向 case 断言一条互异的编排语义；负向域 = 41 变体穷尽映射（压缩为循环断言）+ 防御钳制（钳制/越界/无位）+ 回滚恢复 + CLI 用法错。凑数拆分违反 §12 最优>最小——详见 plan-0.8.md §3 与 calibration-data 0.8 行，沿 plan-0.7.md §3 先例）
- 集成构成（GATE 6 其余项）：driver_seed 22 case 中正向 12 ≥1 / 负向 10 ≥3 / 跨阶段消费（全链消费 + 黄金契约 + CLI 面）≥1 ✅；**五类源可达错误类经 driver E2E 全点亮**（语法/空应用/未绑定/参数个数/类型不匹配——第六类宏展开深度 = 合成树专属（256<512 帽序结构性事实，审计 E 节 expander 层维持）+ 帽序边界正向探针（250 深全链通过）
- 累计口径：108+73=181 : 319+51=370 ≈ 1:2.0（全 workspace 427 → **551**，净 +124）
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：70 → **80 case** 单调增长（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + **I10 driver E2E**：五类源可达错误经 driver 全链渲染 + 多文件多诊断 + REPL 错误回滚恢复 + CJK 字符列 + check 免执行拒绝 + parity 报告与分歧数据化 + 无位置免 `-->`）——七类维持 **6/7**（余 1 类结构性 DEFERRED：模块循环依赖@0.9；门审级 7/7 于 0.11 达成）

## 4. 依赖

- kerf-syntax（**§18.5 新边 L1→L8**——裁定入档 plan-0.8.md：REPL 表单分类直查 StxDatum/SyntaxObject，沿 L1→L3「直接消费者直接依赖」先例；0.0 脚手架 Cargo.toml 既有声明的实义化）
- kerf-reader / kerf-expander / kerf-compiler / kerf-vm（§18.5 既有边 L2/L3/L5/L6→L8：read_program / expand_program / compile_program / Vm 全构造面 + VmIo trait 驱动侧实现）
- kerf-runtime（**§18.5 新边 L7→L8**——裁定入档：双路径驱动 eval 引擎 Evaluator::eval_program/with_io/with_budget + assert_parity/parity_repr 函数调用面；再导出类型沿既有链）
- kerf-span（零直依——Span/FileId/ByteOffset 经 kerf-compiler 再导出消费，沿 0.6 决策 1「零新 DAG 边」先例）
- 消费面扩展 ×3（裁定入档）：`ReadError::offset() -> Option<ByteOffset>` / `ExpandError::span() -> Span` / `CompileError::span() -> Option<Span>`（RuntimeError::span() 0.6 既有）——位置提取知识归错误类型本体（单一可信数据源 §2.3-2），driver 免 41 臂字段匹配
- **零新外部依赖**（crates.io 零增量——CLI 手工解析沿零依赖章程；clap 等 = §18 审查项，不引入）

## 5. 覆盖率

- 构造面全覆盖：Session 全公共 API + LineIndex 全查询面（空源/边界/CJK/CRLF/中点）+ Diagnostic 四阶段 41 变体穷尽 + render 全分支（有位/无位/跨行/零长/多诊断/汇总/槽宽）+ pipeline 四错误径 + 双引擎 + parity + check + repl 全事件族 + cli 全命令族与退出码
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界）：① REPL session-replay 语义（累积重跑 O(n²)——确定性优先；持久会话 = Stage 1+ 议程登记）；② REPL 交互输入带外读（read-line 超带 → Eof——确定性磁带模型，交互式 stdin 消费 = `run` 模式 stdin 管道预载）；③ 表达式提交源级包装 `$repl:N` 保留名（r110 define calling form 通道——名空间侵入披露）；④ DiagnosticCode 阶段级（变体级 E0xxx = Stage 1+ §8.7 完整框架议程）；⑤ Severity 四变体仅 Error 有生产者（结构面 = §8.7 契约形状）；⑥ children/suggestions 字段不入 0.8（无生产者不立空字段——R1 桩判定规避；0.10 接口冻结议程登记）；⑦ CJK 行列夹具 = 登记制白名单（模块 docstring + 本节双登记，沿 0.1-0.3 先例）

# Stage 0.6 测试文档——kerf-vm 迭代主循环虚拟机种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-vm/**（内联 + api_tests）+ tests/v0/stage0/plan/vm_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs G 节（§7.3.1 审计集单调增长 50→60）
> 设计依据：docs/stage0.md §19.5（VM 执行循环——switch-dispatch 骨架/三不变式/三陷阱）+ §8.12（字节码 VM——24 操作码分组/VM 状态六件/帧三扩展槽冻结）+ §19.4（分配配额安全点——0.6 预算 fail-closed，GC 0.7 落位）+ §12.1（消费表 VM 行——runtime 错误经 debug_info_table 回查 Span）+ docs/sop.md §7.1.1（七类错误——本轮点亮「参数个数/类型不匹配」两类 → 6/7）+ plan-0.5.md §4 决策 8/10（Handle 卸载边界可调用性归 0.6 + 全局符号表单源播种）+ plan-0.5.md §5 Q2（0.6 消费契约：Bytecode 五件套 + verify 加载钩子 + span_of）

## 1. 目标

验证 Stage 0.6 kerf-vm 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | RuntimeError 错误面 | 十变体全覆盖：ArityMismatch（七类 #5——闭包 params 对 Call argc + 内建 arity 对 Call argc 双面）/ TypeMismatch（七类 #6——truthy 仅 Bool/算术同种类/car-cdr 操作数/Call 被调者可调用性四语境）/ UnboundGlobal（define 先用后存的动态序——verify 不可静态判定的补面）/ UnhandledEffect（Perform 无匹配 handler）/ DivByZero（整除零除数）/ ArithmeticOverflow（i64 checked 族）/ BudgetExceeded（分配配额——§19.4 安全点 fail-closed）/ Eof（read-line 输入耗尽）/ RetFromEntry（entry proto 尾 Ret——verify 合法但运行期无 caller 帧）/ StackUnderflow（防御纵深——§19.5 陷阱二「peek(n) 校验不可省略」；verify 后结构性不可达，存在性断言面）；R8 消息形态（小写开头/无句尾句号/反引号载荷）；全部携带经 `Bytecode::span_of` 回查的源 Span |
| FP2 | Value/Heap 数据面 | Value 八变体（Int/Float/Bool/Str/Nil/Pair/Closure/Builtin——LiteralValue 五变体运行时对应 + Pair/Closure 堆引用 + Builtin 内建）；Heap 单调分配（Vec 基座位——§19.4 bump 语义的 0.6 形态；配额点 = 0.7 GC 挂接点）；ClosureData{proto, env}（§19.5 `Value::closure(p, capture_env())` 骨架——env 捕获现行 dormant，0.5 编译器自由词法变量回落全局的「基础闭包」P0 口径对偶）；Display 形态（pair 点对 `(1 . 2)`/闭包 `#<closure:fib>`/内建 `#<builtin:+>`）；kind_name 诊断名 |
| FP3 | Vm 装配面 | `Vm::new(bytecode)` 三步：①verify 加载钩子（plan-0.5 裁定四第二道防线——坏产物结构化拒绝）②STAGE0_GLOBALS 18 名播种（Builtin 值——expander STAGE0_GLOBALS 与 VM 注册表跨 crate parity 断言，0.7 runtime 官方断言的前置锚）③非内建全局槽 nil 未初始化态；`with_budget`/`with_io` 配置面；BufferIo 缺省 I/O（确定性测试面——read_line/write_line §8.8 最小表面） |
| FP4 | run 迭代主循环 | switch-dispatch 单循环（24 操作码全执行路径——零原生递归：kerf 级调用 = 堆帧栈 Vec push/pop，TD-023 锚）；帧格式冻结（ext1 continuation/ext2 异常表/ext3 调试帧三槽——§8.12/§19.5 不变式 1，Stage 0 Reserved/实名）；pc 单调性例外（仅 Jump/JumpIfFalse/Call/Ret 改 pc——不变式 2）；求值顺序契约消费（args 左→右 + 被调者栈顶 peek(n)——不变式 3 与 §19.3 对偶）；Call 双面分派（闭包→新帧 / 内建→无帧直执）；Perform = 最近匹配 handler 动态查找 + handler 即函数调用（Perform 值 = handler 返回值——§9.1.1 效应系统接口预留层的 Stage 0 最小执行语义，真续延归 ext1 Stage 1+）；Halt 深度 0→Nil / 深度 1→弹值（compile_program/compile 双入口对偶）；I/O 双向（write-line Str 严格型 + read-line 行读）；fib 全链源码→值（`read→expand→compile→verify→run→Int(55)`——0.3/0.4/0.5/0.6 四段一断） |

## 2. 场景

- **正向**：Value Display/相等性族（点对/闭包/内建形态 + eq? 即刻物结构等值/堆对象同一性双语义）；Heap 分配读回 + 配额计数；Vm 装配（verify 通过 + 18 名播种 + parity）；闭包调用全链（Closure 捕获 env 快照 + Call 建帧 + Ret 返值）；内建调用（算术/比较/pair/谓词/I/O 十八名正路径）；if 短路双臂；let 渐进绑定 + assign 栈平衡（值 = 被赋值）；do→Let 链执行；效应 perform→handle 最近匹配 + 嵌套 handler 内层优先；Halt 双形态（深度 0→Nil/深度 1→值）；fib(10)=55 全链 + fib(25)=75025（§20.1 Week 3 判据）；I/O 回环（write-line 落缓冲 + read-line 取种子行）
- **负向**：ArityMismatch 闭包面（`(f 1 2)` 对单参 f——源码可达）+ 内建面（`(+ 1 2 3)` 对二元 Add——源码可达，**七类 #5 点亮**）；TypeMismatch 四语境（`(if 1 2 3)` truthy 非 Bool / `(+ 1 true)` 异种类 / `(car 5)` 非 pair / `(define f 5)(f 1)` 非可调用被调者——全部源码可达，**七类 #6 点亮**）；UnboundGlobal（手构造 LoadGlobal 未存槽——动态序面）；UnhandledEffect（`(perform log 1)` 无 handler——源码可达）；DivByZero（`(/ 1 0)`）；ArithmeticOverflow（i64::MAX+1 checked 拒绝）；BudgetExceeded（小配额 + 分配程序）；Eof（read-line 空输入）；RetFromEntry（手构造 entry=[Ret]——verify 合法产物）；R8 消息形态族断言（全变体）
- **跨阶段消费**：fib 源码四段一断（0.3 reader + 0.4 expander + 0.5 compiler + 0.6 VM——源码→值首次全链贯通）；STAGE0_GLOBALS parity（expander 18 名 ↔ VM 注册表逐名双射——0.7 runtime 官方断言前置锚）；`(define r (fib 10))` 全局表观察面（run 返 Nil + global 查询 Int(55)——模块顶层纯声明语义的消费契约）；效应源级全链（handle/perform 展开→编译→执行→值）；手构造字节码经 verify 门后的运行期负路径（UnboundGlobal/RetFromEntry——0.5 公共校验面与 0.6 运行期的职责分界实证）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | value.rs（3+6）/ builtin.rs（1+4）/ error.rs（0+8）/ frame.rs（1+2）/ vm.rs（3+11） | 8 | 31 |
| crate API | crates/kerf-vm/tests/api_tests.rs | 2 | 5 |
| 跨 crate 集成 | tests/v0/stage0/plan/vm_seed_tests.rs（经 runner.rs） | 2 | 6 |
| **测试合计** | | **12** | **42** |

- 正负比 = 12:42 = 1:3.5 ≥ 1:3 ✅（GATE 6）；≥40 门槛超配（54）；集成构成：正向 2 ≥1 / 负向 6 ≥3 / 跨阶段消费 2 ≥1 ✅
- **0.5 缺陷修复回归对（另行记账，不计入上表）**：compile.rs 内联 +2 正向（兄弟闭包 / 嵌套闭包 cur 恢复——0.6 轮发现的 0.5 `end_closure` 递减缺陷，§20.6 同类全量修复）；轮合计 56 = 14P:42N = 1:3 精确；累计 89:267 = 1:3 精确
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：50 → **60 case** 单调增长（A10 + B10 + C5 + D5 + E10 + F10 + **G10 VM 负向**：源码级 arity×2（闭包/内建）+ 源码级 type×4（truthy/算术异种/car/被调者）+ 源码级 unhandled effect + 源码级 div-zero + 手构造 overflow + 手构造 budget）——七类 **6/7 点亮**（语法错误 + 空应用 + 未绑定标识符 + 宏展开深度 + **参数个数 + 类型不匹配**）；余 1 类结构性 DEFERRED（模块循环依赖@0.9——matrix.md 累计视图记账；门审级 7/7 于 0.11 达成——SOP §7.1.1 v12.5 口径注沿袭）

## 4. 依赖

- kerf-compiler（§18.5 既有边 L5→L6：Bytecode/FuncProto/Instr/Opcode/compile/compile_program 公共面 + 本轮**再导出扩展** `pub use kerf_core::{LiteralValue, Span, Symbol}`——0.5 决策 14「消费面完整性传递」先例延展；**零新 DAG 边、零新外部依赖**）+ kerf-span（dev-dependencies——测试夹具 Span 构造，沿 0.4/0.5 形态）
- 集成层经根聚合 crate `kerf::vm`/`kerf::compiler`/`kerf::expander`/`kerf::reader` 再导出路径（§8.4.6）；审计集 G 节经根聚合 crate 消费

## 5. 覆盖率

- 构造面全覆盖：RuntimeError 十变体全负向 + Value 八变体 Display/相等性 + Heap 分配面 + Builtin 十八名注册表 + Vm 装配三步 + 24 操作码全执行路径（正向经 fib/算术/pair/I/O/效应组合覆盖 + 负向经错误变体覆盖）+ 帧三扩展槽存在性
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界）：真续延/效应展开回退语义 = ext1/ext2 槽 Stage 1+（§9.1.1 接口预留层——0.6 为「handler 即动态函数」最小执行语义，决策入档 plan-0.6）；GC = 0.7 runtime（0.6 Heap 单调分配 + 配额 fail-closed——§19.4 安全点即 0.7 gc_cycle 挂接点）；词法闭包捕获 = Stage 1（0.5 编译器自由词法变量回落全局的「基础闭包」P0 口径——VM env 捕获为 dormant 载体，fib 递归经全局名不受影响）；TCO = Stage 1+（尾位 If 留位已由 0.5 编译侧承载——VM 帧栈不回收为 P0 语义，BudgetExceeded 为其 fail-closed 界）；浮点除零 = IEEE inf/nan 值语义（非错误——DivByZero 仅整除面）；`+` 等内建固定元数（变参折叠 = Stage 2 库面——`(+ 1 2 3)` 报 ArityMismatch 为 0.6 语义）

# Stage 0.1 测试文档——kerf-core CoreExpr 种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-core/**（内联 + api_tests）+ tests/v0/stage0/plan/core_seed_tests.rs
> 设计依据：docs/stage0.md §3.2（冻结原语）+ §6.12.6（收敛裁定）+ §7.4（内部语法三原则）+ §8.6（Span 全携带）

## 1. 目标

验证 Stage 0.1 kerf-core 数据层的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | Symbol 校验构造 | 非空 + 无空白 + 无控制字符（保守下限；完整文法随 0.3 Reader） |
| FP2 | CoreExpr 九变体 + LiteralValue 六变体 | 冻结原语集（TD-005 裁定：Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）；构造子全覆盖 + kind_name 诊断名 |
| FP3 | Span 全携带 + 遍历接口 | 每节点携带 Span（TD-004 裁定：加边 kerf-span→kerf-core）；visit_spans 前序遍历 = 0.4 expander 消费契约 |
| FP4 | 语义下限校验构造器 | 名字承载节点的校验构造器（fn_ 重复参数拒绝 / handle 重复效应拒绝 / 全体非法符号拒绝）——0.4 展开器「源文本→已验证节点」契约占位 |

## 2. 场景

- **正向**：合法构造往返（as_str/Display/kind_name）；九变体 span 访问器；嵌套程序前序遍历精确序；模块项嵌套遍历；CJK 标识符接受（§10.5 CJK 被测对象白名单——登记于 symbol.rs 测试注释）
- **负向**：Symbol 拒绝（空/空格/内嵌空白×4/前导/NUL 控制字符）；错误消息 R8 形态（小写开头/无句尾句号/反引号）；fn_ 重复参数（相邻/非相邻）；handle 重复效应子句（相邻/非相邻）；非法符号经全部九个校验构造器路径拒绝；Span 不变量经聚合路径保持（反转/跨文件/跨代次 join）
- **跨阶段消费**：core 节点 span 经 kerf-span join 归约（expander 形状程序折叠 + reader 形状 token→节点模式）——TD-004 边的活性证明

## 3. 预期数（三层）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | symbol.rs / error.rs / expr.rs / module.rs | 8 | 24 |
| crate API | crates/kerf-core/tests/api_tests.rs | 2 | 6 |
| 跨 crate 集成 | tests/v0/stage0/plan/core_seed_tests.rs（经 runner.rs） | 2 | 6 |
| **合计** | | **12** | **36** |

- 正负比 = 1:3 ✅（GATE 6）；单元 ≥30 ✅（32）；集成构成：正向 2 ≥1 / 负向 6 ≥3 / 跨阶段消费 2 ≥1 ✅
- §7.1.1 七类错误矩阵：仍 N/A（无 Reader/Expander/VM——冷启动结构性缺口沿 plan-0.0.md §6 裁定，0.3 起点亮）

## 4. 依赖

- kerf-span（工作区内路径依赖——TD-004 裁定新增 DAG 边 L0→L4）
- 集成层经根聚合 crate `kerf::core` 再导出路径（§8.4.6）

## 5. 覆盖率

- 构造子全覆盖：CoreExpr 九变体 ×（直接构造或校验构造器）+ LiteralValue 六变体 + ModuleItem 三变体 + Binding/HandlerClause
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）

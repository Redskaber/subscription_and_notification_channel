# kerf-span 测试计划与报告（Stage 0.0 种子 MUV）

> 对应代码：crates/kerf-span/src/span.rs（内联单元）、crates/kerf-span/tests/api_tests.rs（crate API）、tests/v0/stage0/plan/span_seed_tests.rs（跨 crate 集成）
> 设计依据锚：stage0.md §8.6（四字段模型）、§12.1（字节偏移制 + 消费表）；SOP §9.4.3（正负比 1:3）、§8.4.6（两级测试语义）

## 1. 测试目标

验证 Span 数据模型的全部不变量与公共 API 契约：构造校验（start ≤ end）、半开区间语义、同文件同代次合并、ROOT 代次语义、错误面渲染惯例（R8）、以及「跨 crate 消费」的 workspace 装配正确性。

## 2. 覆盖场景（功能点 × 等价类/边界值）

| 功能点 | 等价类划分 | 边界值 |
|--------|-----------|--------|
| FP1 构造 | 合法区间 / 空 span / 反转（相邻、远距、MAX 处） | 0..0、MAX..MAX、start=MAX&end=MAX-1 |
| FP2 root 简写 | 与 new 等价 / 校验不被绕过 | ROOT 常量 = 0 |
| FP3 谓词 | 空/单字节/多字节/全幅 | 0..u32::MAX |
| FP4 contains | 内部/起点（含）/终点（排）/前/后/空 span 自身 | start、end、end-1、start-1 |
| FP5 join | 同文件同代（相离/嵌套/空操作数/对称）/ 跨文件 / 跨代 / 双违（文件优先） | 相同区间跨代（轴独立性） |
| FP6 渲染 | 三错误变体消息 / Display 格式 / R8 惯例（小写开头/无句号/ASCII） | — |
| 装配 | 根聚合 re-export 消费 / token 归约模式（跨阶段消费） | 错误经聚合路径传播 |

## 3. 测试统计（实际运行，2026-09-27）

| 层 | 正向 | 负向 | 合计 |
|----|-----|-----|------|
| 单元（span.rs 内联） | 8 | 24 | 32 |
| crate API（api_tests.rs） | 2 | 6 | 8 |
| 跨 crate 集成（span_seed_tests.rs） | 2 | 6 | 8 |
| **合计** | **12** | **36** | **48** |

正负比 = 1:3（§9.4.3 达标）；运行结果 48 passed / 0 failed（release）。

## 4. 依赖

- 无外部测试依赖（零 dev-dependencies——与 crate 零依赖策略一致，§18 审查规避）。
- 集成层依赖根聚合 crate `kerf`（re-export 面）与 tests/common/mod.rs（TokenLike 消费模式替身——0.3 退役）。

## 5. 覆盖率状态

功能点全覆盖（FP1-FP6 + 公共面 + 装配面）；DEFERRED 项无（span 域内）；管线七类错误矩阵见 matrix.md 阶段累计视图（结构性 DEFERRED 至 0.3+）。

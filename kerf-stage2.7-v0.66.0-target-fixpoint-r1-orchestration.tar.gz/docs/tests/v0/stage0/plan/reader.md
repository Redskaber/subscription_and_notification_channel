# Stage 0.3 测试文档——kerf-reader 词法/语法种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-reader/**（内联 + api_tests）+ tests/v0/stage0/plan/reader_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs（§7.3.1 审计集）
> 设计依据：docs/stage0.md §8.1（类型化 Token 流 Reader——tokenize 三保证：无损覆盖/精确 Span/结构化 LexError）+ §278 能力签名（read : string → Result<SyntaxObject, ReadError>）+ Week1 模块处方（token.rs/lexer.rs/parser.rs）+ docs/sop.md §7.1.1（七类错误——本轮点亮「语法错误/空应用」两类）+ §7.3.1（审计集 ≥30 case 全额口径起强）

## 1. 目标

验证 Stage 0.3 kerf-reader 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | StxToken 词法面 | §8.1 类型化 Token 子集（Delimiter/Identifier/IntLiteral/FloatLiteral/BoolLiteral/StringLiteral/Eof——S-expr 皮肤不产 TypeIdentifier/Keyword/Operator/MacroInvocation，现代皮肤 Stage 2 加性引入）；原子分类：标识符（StxSymbol 下限 + CJK 合法）/ 整数（i64）/ 浮点（f64——Rust parse 语义：`.5`/`1.`/`1e5` 合法）/ 布尔（`#t`/`#f`——stage0.md 语料实证）/ 字符串（转义 `\"` `\\` `\n` `\t` `\r`；裸换行合法——Scheme 传统）；`;` 行注释；空白跳过（Unicode 空白 + BOM \u{FEFF} 显式跳过）；原子终止符 = 空白/`(`/`)`/`"`/`;`（标准 Lisp 读者行为）；**数字形原子 fail-closed**（数字形开头但 i64/f64 双解析失败 → MalformedNumber——不做 Racket 式符号回退，§2.3-4 报错>静默）；Eof 空 span 收尾；无损覆盖（相邻 token 间隙仅空白/注释） |
| FP2 | read_program 程序面 | 多顶层形式；嵌套列表（递归下降，模块处方 parser.rs）；span 字节精确（token=精确字节区间；list=open.start..close.end；多字节 UTF-8 偏移正确）；空程序（纯空白/注释 → Ok(vec![])）；相位戳 Phase::Runtime 全树（展开器负责翻转 transformer 相位）；空 ScopeSet 全树（scope coloring 属 0.4 展开器）；Reader 产出经 SyntaxObject 公共构造器（symbol 校验路径） |
| FP3 | ReadError 错误面 | 九变体全覆盖：UnclosedList/UnexpectedClose/UnterminatedString/InvalidEscape/InvalidBool/MalformedNumber/InvalidSymbol（控制字符——渲染与 syntax/core 单源字典逐字节一致）/EmptyApplication/NestingDepthExceeded；R8 消息形态（小写开头/无句尾句号/反引号载荷）；精确字节定位（载荷携带 ByteOffset）；fail-closed 全路径（无静默回退） |
| FP4 | 256 嵌套帽 + 跨阶段消费 | `NESTING_LIMIT = 256` 公开常量；256 深通过 + 257 深拒绝（双向边界）；帽以嵌套深度计（非 token 总量）；跨阶段：read 树 visit_spans 前序精确序 + span join 归约（0.4 展开器契约）；真实 StxToken 经根聚合路径消费（TokenLike 测试替身退役——本子阶段退役义务执行）；错误恢复（调用级隔离：错误源 A 读取失败后，修正源 B 独立读取成功；结构化错误不 panic） |

## 2. 场景

- **正向**：原子往返（symbol/as_str、int/float/bool/string 载荷 + kind_name + Display）；词法序列（`(add 1 2.5 #t "s")` 全类混合 + Eof）；注释与空白跳过 + 无损覆盖断言（间隙切片仅空白/注释）；BOM 跳过；多字节 CJK 程序 span 字节精确；多形式程序 + 嵌套树构造 + visit_spans 前序序；256 深嵌套通过；空程序；CJK 标识符（§10.5 白名单——登记于测试注释）；`+`/`-`/`...`/`nil` 等符号形合法
- **负向**：`(f` 未闭合 / `)` 孤立闭括 / `()` 空应用（**七类第 3 类点亮**）+ `(1 ())` 嵌套空应用 / `"abc` 未终结字符串 / `"a\x"` 非法转义 / `#q`/`#true` 非法布尔 / `1.2.3`/`12abc`/`0x1F` 数字形双解析失败 / `a\u{0}b` 控制字符符号（InvalidSymbol 渲染单源字典断言）/ `((((…257` 嵌套帽越界 / R8 消息形态族断言 / 多形式程序中间形式错误精确定位
- **跨阶段消费**：read 产树 span 归约（join 折叠至覆盖 span——0.4 契约）；真实 StxToken 归约（covering_span 消费真实 token 流——TokenLike 退役迁移）；错误恢复对（源 A 错误 + 源 B 修正后成功——调用隔离）；read → syntax 构造路径活性（L1→L2 边）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | error.rs（0+5）/ lexer.rs（7+14，含原子邻接正例与 BOM/注释/转义族）/ parser.rs（4+13） | 11 | 32 |
| crate API | crates/kerf-reader/tests/api_tests.rs | 2 | 6 |
| 跨 crate 集成 | tests/v0/stage0/plan/reader_seed_tests.rs（经 runner.rs） | 2 | 7 |
| **测试合计** | | **15** | **45** |
| §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑） | examples/audit/stage0_gate_audit_r1.rs | — | **30 case**（10 单语句 + 10 多语句 + 5 复杂 + 5 错误恢复） |

- 正负比 = 15:45 = 1:3 ✅（GATE 6——实施期首轮实配 15:40 未达标，补 5 个负向至精确 1:3：lone hash / escape-at-EOF / 参数位空应用 / 多形式第三形式定位 / 跨 crate 程序中段数字）；≥40 门槛超配（60）；集成构成：正向 2 ≥1 / 负向 7 ≥3 / 跨阶段消费 2 ≥1 ✅
- §7.1.1 七类错误矩阵：**2/7 点亮**（语法错误 ✓ + 空应用 ✓——两类检测层均已存在）；余 5 类结构性 DEFERRED（未绑定/宏深度@0.4、参数个数/类型不匹配@0.6、模块循环@0.9——检测层未建，matrix.md 累计视图记账；门审级 7/7 于 0.11 达成——SOP §7.1.1 v12.5 口径注：子阶段级 ≥6/7 以「已存在检测层的类全点亮」冷启动代偿口径执行，plan-0.0.md §6 裁定沿袭）

## 4. 依赖

- kerf-syntax（工作区内路径依赖——§18.5 既有边 L1→L2：消费 StxSymbol/SyntaxObject/Phase/StxDatum）+ kerf-span（L0：Span/ByteOffset/FileId）
- 集成层经根聚合 crate `kerf::reader`/`kerf::syntax`/`kerf::span` 再导出路径（§8.4.6）；审计集经根聚合 crate 消费（examples/audit/ + [[example]] 声明——§7.3.1 规则 3 落位）

## 5. 覆盖率

- 构造面全覆盖：StxTokenKind 七变体 + ReadError 九变体全负向 + lex/read_program 双入口正负 + Delimiter 二值
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内；panic-mode/sync-set 多错误恢复机制 = §9.36.8 登记态——Stage 2 开窗项，Stage 0 恢复语义 = 结构化错误 + 调用级隔离，plan-0.3.md 设计记录申报）

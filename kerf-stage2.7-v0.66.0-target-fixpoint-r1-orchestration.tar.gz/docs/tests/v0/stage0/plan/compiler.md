# Stage 0.5 测试文档——kerf-compiler 字节码生成种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-compiler/**（内联 + api_tests）+ tests/v0/stage0/plan/compiler_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs F 节（§7.3.1 审计集单调增长 40→50）
> 设计依据：docs/stage0.md §19.3（Compiler 实现框架——跳转回填/常量池/全局符号表/debug_info_table + 三不变式：栈平衡/回填完备/调试信息全覆盖 + 三陷阱：尾位置留位/常量池去重/全局链接时机）+ §8.12（操作码七分组 + 帧三扩展槽——0.6 VM 侧）+ §8.6（Span 全管线传播）+ §12.1（Span 消费表——Compiler 侧行：字节码指令 → debug_info_table）+ §19.5（求值顺序契约——CALL 前参数按序压栈、被调者栈顶 peek(n)）+ docs/sop.md §7.1.1（七类错误——0.5 维持 4/7）+ 0.1-design-adjudications.md（TD-004 Span 必填/TD-005 原语集）+ plan-0.4.md 决策 16（STAGE0_GLOBALS 单源）+ plan-0.5.md §4（裁定四 verify 公共面 + 决策 14 项）

## 1. 目标

验证 Stage 0.5 kerf-compiler 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | CompileError 错误面 | 12 变体全覆盖：`DepthExceeded`（COMPILE_DEPTH_LIMIT=1024 编译递归帽——合成深树 fail-closed 拒绝，非栈溢出）/ `UnpatchedJump`（CodeBuf finish 占位残留——编译期防御，crate 内联触发）/ `StackUnderflow` + `StackImbalance`（verify DAG 深度传播——下溢与多前驱深度不一致）/ `ConstIndexOutOfRange` / `GlobalIndexOutOfRange` / `LocalSlotOutOfRange` / `ProtoIndexOutOfRange` / `JumpTargetOutOfRange` / `DebugInfoMissing` / `MissingTerminator` / `HaltOutsideEntry`（verify 结构校验族——手工坏产物逐变体触发）；R8 消息形态（小写开头/无句尾句号/反引号载荷）；产物侧变体携带 pc + Span、编译侧携带 depth + Span |
| FP2 | compile 表达式面（9 原语直译） | `Literal`→`PushConst`（常量池 intern；`ConstKey` NaN 规范化去重——`(begin 1 1 1)` 同值单槽）/ `Var`→局部槽命中 `LoadLocal`、否则 `LoadGlobal`（intern 同名同槽）/ `Fn`→闭包 proto（params 局部槽 0..n + body 尾位编译 + 显式 `Ret` + `Closure(proto_idx)`）/ `Apply`→args 左→右 + func + `Call(arity)`（求值顺序契约 §19.5）/ `If`→非尾：cond + `JumpIfFalse` + then + `Jump` 汇合 + else；**尾位：无汇合 Jump**（分支直达 Ret——TCO 留位 §19.3 陷阱一）/ `Assign`→value + `Dup` + `StoreLocal/StoreGlobal`（副本留栈净 +1）/ `Let`→let\* 渐进 `StoreLocal` fresh 槽链 + body 尾位透传 / `Perform`→args 左→右 + `Perform(effect_idx, argc)` / `Handle`→clauses 依序 handler 值 + `PushHandler(effect_idx)` + body[非尾] + `PopHandler(n)`（卸载边界截断尾位——决策 8） |
| FP3 | compile_program 程序面 + Bytecode 结构 | `Define`→value + `StoreGlobal`（净 0；函数糖 Define(f, Fn) 整树编译）/ `Require`→零代码登记（链接 VM 加载期——§19.3 陷阱三）/ `Module`→递归扁平编译（0.9 域归属申报）；toplevel proto 末尾 `Halt`（program 形态深度 0 / compile 单表达式形态深度 1）；`FuncProto { name, params, n_locals, code, debug_info }`；`Bytecode { funcs, consts, globals }` 五件套访问器 + `span_of(func, pc)` 查询（§12.1 Compiler/VM 消费行承载） |
| FP4 | verify 公共校验面 + 跨阶段消费 | `Bytecode::verify` 纯函数两道结构：结构校验（debug_info 对齐 code.len / 操作数四类索引界内 / Jump 目标界内 / 末条 ∈ {Ret, Halt} / Halt 仅入口 proto）+ **DAG 基本块栈深度传播**（bb 入口深度多前驱一致性断言——Stage 0 控制流无回边拓扑收敛；每指令 delta 表驱动 + 下溢检查）；compile/compile_program 产出恒过 verify（契约断言）；fib 源码→read→expand→compile→verify 全链（跨阶段消费主锚——0.3+0.4+0.5 三段一断）；do→Let→`StoreLocal` 链指令形态端到端；debug_info 逐指令 Span 全覆盖（无裸指令——§19.3 不变式 3）+ Span 零构造（全复制自 CoreExpr 节点） |

## 2. 场景

- **正向**：九原语变体各自指令序列快照断言（Literal/Var 局部/Var 全局/Fn 闭包 proto/Apply 求值序/If 非尾双跳转/If 尾位无汇合 Jump/Assign Dup-Store/Let StoreLocal 链/Perform argc/Handle Push-Pop 对）；常量池去重（同值 Int 单槽 + NaN 规范化折叠 + Pair 递归键）；全局 intern 同名同槽（两次引用同 idx）；`span_of` 命中/越界双向；compile 单表达式 Halt 深度 1 形态；verify 好产物通过（fib 全链）；toplevel Define 净 0 + Halt 深度 0；空程序（compile_program(&[]) → toplevel 仅 Halt）
- **负向**：`DepthExceeded`（合成 1025 深树拒绝 / 1024 边界通过对——帽双向）；verify 拒绝族 ×10 变体（手工坏 Bytecode 逐变体构造：Jump 目标 = code.len 越界 / Pop 空栈下溢 / JumpIfFalse 两臂深度不一致 StackImbalance / debug_info 短一行 DebugInfoMissing / PushConst a = consts.len() 越界 / 闭包 proto 内 Halt HaltOutsideEntry / 末条 Pop 无终结符 MissingTerminator / Closure a 越界 ProtoIndexOutOfRange / LoadLocal slot = n_locals 越界 / LoadGlobal a 越界）；CompileError 12 变体构造 + Display R8 形态精确串断言；crate 内联 CodeBuf 防御（UnpatchedJump——emit_jump 后不 patch 直接触发 finish）
- **跨阶段消费**：fib 源码 read_program→expand_program→compile_program→verify 全链（0.5 契约主锚——Define+Fn+If/Apply/Var 树形指令化：`Call 2` 递归形态存在 + `JumpIfFalse` 存在 + `LoadGlobal` 命中 `-` 名 + 常量池含 fib 基线 0/1/2）；do 源码→Let 脱糖→`StoreLocal` 链 + body 末位指令形态（0.4→0.5 端到端）；合成深树经 expander 512 帽先拦（跨层帽序——expander 拒绝先于编译帽）+ 512 内 expander 产出编译通过（1024 编译帽裕量实证）；编译产出 debug_info 与 CoreExpr visit_spans 前序的 Span 集合一致性（无裸指令 + 零构造——span 全来源可追）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | opcode.rs（2+0）/ bytecode.rs（2+2）/ compile.rs（4+3）/ verify.rs（0+11）/ error.rs（0+8） | 8 | 24 |
| crate API | crates/kerf-compiler/tests/api_tests.rs | 2 | 6 |
| 跨 crate 集成 | tests/v0/stage0/plan/compiler_seed_tests.rs（经 runner.rs） | 2 | 6 |
| **测试合计** | | **12** | **36** |

- 正负比 = 12:36 = 1:3 ✅（GATE 6）；≥35 门槛超配（48）；集成构成：正向 2 ≥1 / 负向 6 ≥3 / 跨阶段消费 2 ≥1 ✅
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：40 → **50 case** 单调增长（A10 + B10 + C5 + D5 + E10 + **F10 编译器负向**：编译深度帽越界合成树 / verify 拒绝族 ×9 手工坏产物）——七类**维持 4/7**（0.5 直译层无新检测类点亮；参数个数/类型不匹配@0.6、模块循环依赖@0.9 结构性 DEFERRED——matrix.md 累计视图记账；门审级 7/7 于 0.11 达成——SOP §7.1.1 v12.5 口径注沿袭）

## 4. 依赖

- kerf-core（§18.5 既有边 L4→L5：CoreExpr/ModuleItem/LiteralValue/Symbol/Span 再导出）——**零新 DAG 生产边、零新外部依赖**（kerf-span 仅 dev-dependencies 夹具 `Span::root` 构造；生产 Span 消费经 `kerf_core::Span`——core lib.rs 既有契约）
- 集成层经根聚合 crate `kerf::compiler`/`kerf::core`/`kerf::expander`/`kerf::reader`/`kerf::span` 再导出路径（§8.4.6）；审计集 F 节经根聚合 crate 消费

## 5. 覆盖率

- 构造面全覆盖：CompileError 12 变体全负向 + compile/compile_program 双入口正负 + 九原语全产出指令形态 + ModuleItem 三变体（Define 函数/值双形 + Require 零代码 + Module 递归）+ verify 结构校验五族 + DAG 深度传播两族（下溢/失衡）+ Opcode 24 全 Display/delta/terminator 表断言
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界）：VM 执行语义（CALL 帧切换/效应分派/truthy 校验）= 0.6（§19.5 承载——verify 只做静态结构/深度，不做值语义）；全局名播种与 STAGE0_GLOBALS parity = 0.7 runtime（expander lib.rs 既有钩子）；模块域归属/循环依赖检测 = 0.9；尾位穿透 Handle body = Stage 2 EffectElimination 优化窗（§6.12.1 修正五——登记态）；指令序列化（字节级编码）不在 Stage 0 范围（Bytecode 为内存态纯数据）

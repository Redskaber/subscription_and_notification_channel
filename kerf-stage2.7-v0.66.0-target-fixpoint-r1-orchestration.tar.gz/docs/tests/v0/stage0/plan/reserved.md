# Stage 0.10 测试文档——四项接口预留冻结 + r2 能力模型预留泛化（reserved：effects / multistage / capability 空间 / cache）

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-core/src/reserved/**（四模块内联 + capability/ 模块族[family/token/registry/io]）+ crates/kerf-core/tests/api_tests.rs reserved 节 + tests/v0/stage0/plan/reserved_seed_tests.rs（经 runner.rs）+ examples/audit/stage0_gate_audit_r1.rs K/L 节（§7.3.1 审计集单调增长 90→100→110）
> 设计依据：docs/stage0.md §9.1.1（EffectSystem 形状）+ §9.1.2（MultiStage 形状）+ §9.1.3（CapabilityIO + 令牌类型）+ §9.1.4（CompilationCache 三方法）+ §9.4 十四项矩阵（四项既有预留行）+ §9.5.1 P0-P3 优先级 + §22.3 里程碑清单（四接口项——Effect Handlers / 多阶段编程 / 能力模型 I/O / 编译缓存「接口已定义（实现可为空）」）+ docs/sop.md §21.12-8（根空间统一组织——预留接口依赖方向判据）+ §21.12-10①②（六域从属表 + 空间层级从属判据——冷启动注：kerf-space marker 家族为 Stage 1+ 登记项）+ §2.2 原则 12（接口预留优先于实现）/26（三级成熟度匹配）/27（接口稳定性）/32（预留留白）/40（根空间统一组织）+ stage-0-plan.md §5 行 0.10 + roadmap.md §6 post-0.9 首议程四项 + plan-0.9.md §5 边界申报（§19.2 多阶段 quote/splice = Stage 2+ 区分登记）+ tech-debt-register v0.10

## 1. 目标

验证 Stage 0.10 的四大功能点（P3 三件类型形状 + P2 一件 trait 签名 + 行为规格）：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | reserved::effects 效应系统预留形状（P3） | 蓝图 §9.1.1 伪码的可编译转译：`EffectOp`（伴随 trait——`type Result` 承载 `Self::Effect::Result` 语义）+ `EffectSystem`（`type Effect: EffectOp` / `type Handler` / `type Continuation` / `type Value` 四关联类型 + `perform(&self, effect) -> <Effect as EffectOp>::Result` + `handle(&self, handler, computation: impl FnOnce() -> Self::Value) -> Self::Value` 两方法签名冻结）；**零生产实现**（无任何 concrete impl——Stage 2 语言面；Perform/Handle 原语语义已在内核 CoreExpr）；witness 实现者仅存于测试（签名稳定快照） |
| FP2 | reserved::multistage 多阶段编程预留形状（P3） | 蓝图 §9.1.2 伪码转译：`Expr`（quote 输入面 marker trait）+ `CodeCarrier`（`type Inner` / `type Result`——承载 `Self::Code::Inner` 语义）+ `MultiStage`（`type Code: CodeCarrier` + 关联函数 `quote<E: Expr>` / `splice(Code) -> Inner` / `run(Code) -> Result` 三签名冻结）；**零生产实现**（Stage 2 quote/splice/run 实现窗——§19.2 区分登记沿 plan-0.9 §5）；**命名重叠披露**：预留面 `MultiStage::quote` ≠ 0.9 展开器 `quote` 数据字面量形式（前者 = 阶段化代码构造、后者 = Pair 链字面量——§19.2 Stage 2+ 区分） |
| FP3 | reserved::capability_io 能力模型 I/O 预留形状（P3） | 蓝图 §9.1.3 全件：`ReadCapability` / `WriteCapability` 不可伪造令牌（私有字段——模块外不可构造；ZST）+ `IOError`（`IoErrorKind` 闭集 + 消息 + R8 Display）+ `CapabilityIO`（关联函数 `read_line(&mut ReadCapability) -> Result<String, IOError>` + `write_line(&mut WriteCapability, &str) -> Result<(), IOError>` 签名冻结）；**零生产实现**（Stage 1+ 基础能力传递——当前 I/O = 传统面[vm VmIo/BufferIo + driver TapeIo]维持）；fail-closed 令牌纪律（缺省拒绝——能力安全模型 Stage 0 形状位） |
| FP4 | reserved::cache 编译缓存预留（P2——trait 签名 + 行为规格） | 蓝图 §9.1.4 全件 + 行为规格执行化：`CacheKey`（内容寻址摘要 `[u8; 32]`——算法 = Stage 1 实现细节）+ `CachedResult`（不透明载荷 `Vec<u8>`——服务 §9.3.1 已知缺失需求[跨会话持久化/分布式缓存]的可序列化形态）+ `CompilationCache`（`get_cached` / `store` / `invalidate` 三方法签名冻结）+ **`check_compilation_cache_contract<C: CompilationCache>(cache: &mut C)` 行为规格合同测试 kit**（pub——Stage 1 实现的合同测试复用位）：store→get 命中 + 值相等 / 未存 get → None（负向）/ invalidate 后 get → None（负向）/ 未存 invalidate = no-op 不报错（负向）/ 二次 store = 最新胜 / 跨键隔离无泄漏（负向）——**六条行为契约**任何实现必须全过 |
| FP5 | reserved::capability 能力模型空间（0.10-r2 泛化——P3 类型形状 + 可执行注册机制） | 预留本体从 io 点泛化为空间（裁定二十）：`CapabilityModelDescriptor`（身份卡三元组：name / authorities / operation_face 锚——全 'static，Copy）+ `CapabilityModelFamily`（族契约：`type Error` 封闭错误面 + `fn descriptor()`——不携带操作签名[不预测原则]）+ `TokenCalculus`（令牌纪律：`fn authority() -> &'static str`——封印/占有即许可/缺省拒绝纪律文档化，mint/delegate/revoke = Stage 1 线性窗）+ `CapabilityModelRegistry`（**注册拓展机制本体**：`register<F: CapabilityModelFamily>()` fail-closed 三类拒绝[InvalidDescriptor 四变体/DuplicateModel/AuthorityConflict] + 被拒零副作用 + `lookup`/`governing_model`/`governed_authorities`[注册序确定性]）+ `IoModel`（io 首子模型：Error = IOError 逐字钉扎 + 身份卡 name="io"/authorities=["io.read","io.write"]/operation_face="CapabilityIO"] + 令牌 TokenCalculus 实现两件）；**r1 冻结面零破坏**：旧路径 `reserved::capability_io` re-export 存续（TypeId 同一性实证，四消费面零改动） |

**落位与依赖方向（§21.12-10② 冷启动形态）**：四件全落 `crates/kerf-core/src/reserved/`（L4 语义权威 crate——单一冻结锚点 + 全下游 L5-L8 可达）；预留面**零入边**（除 std 外零依赖——关联类型 + 泛型约束全自含，不引用 kerf-vm::Value / kerf-compiler::Bytecode 等具体实现类型——依赖抽象约束非具体实现的最强冷启动形式）；六域从属（§21.12-10①：effects → 效应域 / multistage → 语法域[元编程] / capability_io → 能力域 / cache → 工具链域[编译期服务]）以模块文档声明位承载——kerf-space marker 家族 = Stage 1+ 登记项，届时 re-anchoring 为加法零破坏（路径登记于 plan-0.10.md 决策）。

## 2. 场景

- **正向**：effects witness（EffectOp Result 类型接线 + perform 路由 + handle 组合值路径）；multistage witness（quote 构造 Code + splice 折返 Inner + run 执行至 Result）；capability 令牌 ZST 断言 ×2 + Debug 形态稳定；CapabilityIO witness 读两行 happy path + 写行捕获；CacheKey 摘要往返 + Eq/Hash 一致性（同摘要等值/异摘要不等）；CachedResult 载荷构造/访问/消费三面；cache 合同 kit 全六条正向（命中/最新胜）；api 再导出面可达（kerf_core::reserved 四族路径 + root kerf::core::reserved 跨 crate 消费）；根集成 witness 全家（四族一次命名——编译级类型存在性）+ 下游泛型消费函数（`fn drive<C: CompilationCache>(cache: &mut C)` 于根位置编译执行——L4 面对下游可用性）
- **负向**：cache 合同（未存 get → None / invalidate 后 get → None / 未存 invalidate no-op / 跨键隔离——四条行为负向）；capability IOError 路径（源耗尽 → `IoErrorKind::Eof` Err / 令牌拒绝 → `IoErrorKind::Denied` Err——fail-closed 消极面）；IoErrorKind Display R8 形态（小写开头无句尾句号 ×全变体）；令牌不可伪造（私有字段——模块外构造面结构性不存在，witness 仅经合法路径）；**形状面诚实申报**：P3 三件无运行时负向可测面（类型形状 = 存在性断言本体；编译失败面[错误接线]无法运行时测试——trybuild 类外部依赖 §18 禁用）——负向集中于 P2 行为规格 + P3 令牌纪律 + IOError 面
- **跨阶段消费**：kerf-core（L4）→ 根 tests/（reserved_seed_tests 经 runner.rs——跨 crate 断言只入根 tests/ §8.4.6）+ → examples/audit K 节（L4 → 根 example 位置消费链）；预留面与既有九 crate 零语义耦合（加法零回归——624 基线不动）；Stage 1 消费预告（cache kit = Stage 1 内存内容寻址实现的合同测试复用位——re-export 于 kerf_core::reserved::cache）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | effects.rs（6+0）/ multistage.rs（4+0）/ capability 族（io 9+6 + family 4+0 + token 2+0 + registry 5+11）/ cache.rs（5+5） | 46 | 22 |
| API 面 | crates/kerf-core/tests/api_tests.rs reserved 节（r1 6+0 + r2 5+1） | 11 | 1 |
| 跨 crate 集成 | tests/v0/stage0/plan/reserved_seed_tests.rs（经 runner.rs；r1 7+5 + r2 4+1） | 11 | 6 |
| **测试合计（r1 实测）** | | **32** | **16** |
| **r2 增量（实测）** | 单元 +27[能力域 37 - 旧 capability_io 10] / api +6 / 根 +5 | **25** | **13** |
| **测试合计（r2 终态）** | | **57** | **29** |

- r2 增量正负比 = 25:13 = 1:0.52（反向偏差申报——框架面结构性正向[类型形状 + 注册端到端 + 拓展证明]；负向集中于注册 fail-closed 族 11 件[三类拒绝全路径 + 未知解析 ×2 + R8 形态 + 互异 + 被拒零副作用] + api/根位拒绝各 1；较 r1 的 32:16 改善；凑数违反 §12）
- 累计口径：r1 后 272:400；r2 后 297:413 = 1:1.39（全 workspace 672 → **710:0:0**——r2 净 +38 cargo test 口径 + audit L 节 +10 = 总验收面 48）；r2 集成构成：正向 4 ≥1 / 负向 1 ≥3 口径沿 r1 层满足（api+根合计 6+5 含拒绝负向 2 + 审计位负向 5）；跨阶段消费 ≥1 ✅（拓展证明四位置：crate 内 ProbeModel/ClockModel + api 位 OutsideNet + 根位 RootClockModel + 审计位 AuditClockModel——外部定义模型入同一闭世界零框架变更；register_any_family 下游泛型消费函数——drive_cache 先例同型）（GATE 6 达标）
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：90 → 100（r1）→ **110 case（r2）** 单调增长（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + J10 + K10 预留面合同 + **L10 能力空间**：L01 io 族契约绑定 / L02 注册端到端 / L03 重复名 fail-closed（负向）/ L04 权威冲突 fail-closed（负向）/ L05 空名描述符拒绝（负向）/ L06 自重复权威拒绝（负向）/ L07 未知解析 → None（负向）/ L08 审计位拓展证明[ClockModel 与 io 同闭世界] / L09 RegistryError R8 形态 + kind 逐对互异（负向）/ L10 re-export 冻结连续性[TypeId 同一 + ZST + 权威词表项]）——七类 7/7 维持（L 节 = 能力空间合同族，不新增错误类）

## 4. 依赖

- **零新入边**：预留面零依赖（除 std——`Vec`/`String`/`fmt`/`error::Error`/`hash` 基础面）；不引用 kerf-span（预留面无 span 语义——系统级契约面非 AST 节点）、不引用 kerf-syntax / kerf-vm / kerf-compiler（§21.12-10② 依赖抽象约束非具体实现——关联类型全自含）
- **零新外部依赖**（crates.io 零增量——§18 审查规避裁定沿袭）；**零新 crate**（9/9 维持——reserved = kerf-core 模块族演进，L4 章程内；kerf-space marker 家族 = Stage 1+ 登记项不提前）
- 消费方：根 tests/runner.rs（+reserved_seed_tests 模块挂载）+ examples/audit K 节 + kerf-core tests/api_tests.rs——全为加法；九 crate 既有语义零改动（624 基线零回归承诺）

## 5. 覆盖率

- 构造面全覆盖：四族全公共 API 有正向（EffectOp/EffectSystem/Expr/CodeCarrier/MultiStage/ReadCapability/WriteCapability/IOError/IoErrorKind/CapabilityIO/CacheKey/CachedResult/CompilationCache/check_compilation_cache_contract——15 公共名全触达）；行为规格六条契约全断言（kit 内逐条 + 集成层复跑）；错误面 IOError 两路径 + Display R8 全变体负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）；**桩审查（R1）**：零桩——预留面本体 = 冻结契约非实现缺位（蓝图「实现可为空」= 原语 12 接口预留优先于实现的登记态，非 TD）

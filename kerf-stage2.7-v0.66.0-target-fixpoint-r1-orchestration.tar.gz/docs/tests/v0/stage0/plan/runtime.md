# Stage 0.7 测试文档——kerf-runtime 标记-清除 GC + 元循环求值器种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-runtime/**（内联 + api_tests）+ tests/v0/stage0/plan/runtime_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs H 节（§7.3.1 审计集单调增长 60→70）
> 设计依据：docs/stage0.md §19.4（标记-清除 GC——三阶段骨架/核心不变式三条/实现陷阱三则）+ §8.11（能力模型：bump 分配 + 递归标记 + 堆遍历清除；根集四类）+ §14.2（内存管理策略）+ §5.1（元循环求值器——语言描述自身）+ §19.5（VM 执行循环——eval 互查对偶面）+ docs/sop.md §7.1.1（七类错误——本轮维持 6/7）+ plan-0.6.md §4（裁定五 Call 栈布局/裁定六 Perform 最小执行语义——eval 语义对齐锚）+ kerf-vm/src/error.rs L50-53（"the 0.7 collector turns this point into collect-then-retry"——预算安全点演进预告）+ kerf-vm/src/value.rs 头注（"the 0.7 collector adds mark bits and a free list over this same shape"）+ kerf-vm/src/builtin.rs 头注（"the 0.7 runtime asserts the two tables' parity"）

## 1. 目标

验证 Stage 0.7 kerf-runtime 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | gc.rs 标记-清除收集器 | §19.4 三阶段：mark_all（**显式工作栈**防爆栈——10^7 嵌套列表对策）→ sweep（未标记归还 free list——保守策略：泄漏容忍误回收零容忍）→ clear_marks（全槽位含空槽——复位对称不变式）；根集四类完备（VM 数据栈/调用栈局部/全局环境/外部显式根 `register_foreign_ref`——§15 FFI 预留的 Rust 化）；GcStats 统计（marked/swept/free_before/free_after）；`MarkSweep` 实现 kerf-vm `Collector` trait（依赖注入——L6 挂接点抽象、L7 算法编排，§21.12-10② 依赖抽象约束）；幂等性（连续两轮 collect 第二轮零回收——干净堆稳定）；free-list 槽位复用（sweep 后 alloc 优先取空槽——HeapRef 稳定复用）；循环结构安全（pair 自环——工作栈 test_and_set 去重）；深链安全（10^5 长度链——显式栈零 Rust 递归） |
| FP2 | eval.rs 元循环求值器 | 九语义原语直接解释 CoreExpr（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle + ModuleItem 三声明——Require 零操作对齐 0.5 编译器「Stage 0 单模块」/Module 递归平铺对齐「flat-table 先例」）；**帧槽位环境模型**（作用域内名字→局部槽、否则→全局表——与 0.5 编译器名字解析逐字对齐；shadow = 新槽位；kerf 调用 = charge 1 + 新帧 params 槽位——计量与 VM 合账同模型）；闭包 = `Value::Closure(HeapRef)` 身份句柄 + evaluator 侧登记簿（params/body）+ `ClosureData{proto: EVAL_CLOSURE_PROTO, env}`（dormant 载体——与 0.6「基础闭包：自由词法变量回落全局」P0 口径对偶；词法捕获激活 = Stage 1 两侧同步）；**内置函数单源分派**（18 名 STAGE0_GLOBALS 经 kerf-vm `builtin_ops` 共享函数——arith/compare/car/cdr/not/eq/io 双侧同实现零漂移；跨 crate parity 官方断言——expander 名表 ↔ Builtin::ALL ↔ eval 注册三面）；`EvalDepthExceeded` 深度帽（Rust 栈防爆——元循环固有约束；VM 侧帧在堆上不受影响——已知语义边界登记）；预算 collect-then-retry（eval 内联 MarkSweep：分配点软超限→collect→重试→仍超 BudgetExceeded——§19.4「分配失败时触发回收」伪代码落位） |
| FP3 | parity.rs 双路径互查 | 结构化 parity 表示（Pair 递归点对展开 `(1 . (2 . nil))`/Closure → `#<closure>`/Builtin → `#<builtin:+>`——HeapRef 地址不参与比较，结构同构即相等）；**≥15 程序 eval 结果 == VM 结果**（fib 递归/算术整浮/比较链/if 嵌套/let* 渐进 + shadow/do→Let 脱糖/set! 局部全局/闭包定义调用/cons-car-cdr/quote 字面 pair/谓词组合/perform-handle 最近匹配/嵌套 handler 内层优先/write-line 输出一致/read-line 输入消费一致——观察面 = 程序返回值 + 全局表快照双面）；负向 parity（同一错误源程序 → 两侧同变体：ArityMismatch 闭包/内建 + TypeMismatch truthy/算术异种/car + DivByZero + UnboundGlobal + UnhandledEffect）；分歧检测器自检（人为构造异值 → parity_repr 必不等——检测器有效性断言） |
| FP4 | E2E 源码→值第一版 + VM 注入面 | 五段一断全链（source → reader → expander → **eval** 直接求值 ↔ compiler → VM 执行——双路径同源分叉点 = Vec<ModuleItem>）；`Vm::with_collector`（Box<dyn Collector> 注入——默认 None 保持 0.6 fail-closed 行为，注入后 collect-then-retry 激活）；`Vm::register_foreign_ref`（外部显式根——§19.4 根集第四类，宿主持有值 GC 保护）；`Vm::snapshot_roots`（四类根快照——收集器输入面）；GC 后继续分配（小预算程序丢弃中间结构 → 无 collector 报 BudgetExceeded / 注入 MarkSweep 后跑通——**collect-then-retry 核心实证**）；注入后 fib(25)=75025 结果不变（GC 零语义干扰回归） |

## 2. 场景

- **正向**：三阶段基本回收（roots 持有子集 → 存活恰为可达集）；深链 10^5（显式工作栈——零 Rust 递归爆栈）；pair 自环循环（test_and_set 去重标记终止）；连续两轮 collect 幂等（第二轮零回收）；sweep 后 alloc 复用同槽位（free-list LIFO）；根集四类各自存活（stack/locals/globals/foreign 逐类置根断言）；GcStats 计量（marked = 可达数/swept = 不可达数/free 前后差）；eval 九原语（Literal 五变体含 pair 字面量/Var 局部→全局回退/Fn+Apply 定义调用/If 双臂短路/Let 渐进 + shadow/Assign 局部槽优先 + 全局直写/Perform→Handle 最近匹配/Require 零操作/Module 平铺）；eval 内置十八名（算术整浮/比较五符/pair 族/谓词族/I/O 双向）；eval 预算 collect-then-retry（软预算 + 丢弃中间结构 → 自动回收跑通）；15 parity 程序全一致（双路径同源分叉）；E2E 源码→值；VM 注入 MarkSweep 后小预算程序跑通；注入后 fib(25) 回归；foreign root 保护（宿主持有值跨 collect 存活）
- **负向**：无根全收（空 roots → live 归零）；sweep 后空槽 get → None；双重 collect 无双重计数；eval 深度帽（深递归程序 → EvalDepthExceeded——eval 独有，VM 不受影响——已知语义边界单测）；eval 预算 collect 后仍超 → BudgetExceeded；ArityMismatch 闭包面（参数个数——七类 #5 维持）/内建面（固定元数）；TypeMismatch 四语境（truthy 非 Bool/算术异种/car 非 pair/被调者不可调用——七类 #6 维持）；UnboundGlobal（未绑定名求值）；DivByZero（整除零）；ArithmeticOverflow（i64 checked）；UnhandledEffect（无 handler perform）；Eof（read-line 耗尽）；R8 消息形态族（新变体 EvalDepthExceeded 小写开头/无句尾句号/span 携带）；VM 无 collector 保持 0.6 fail-closed（BudgetExceeded 直报）；注入后回收仍不足 → BudgetExceeded；负向 parity 族（同源程序双路径同变体断言）；parity 分歧检测器（异值必报不等）
- **跨阶段消费**：五段一断 E2E（0.3 reader + 0.4 expander + **0.7 eval 分叉** + 0.5 compiler + 0.6 VM——同一 Vec<ModuleItem> 双路径）；STAGE0_GLOBALS 三面 parity 官方断言（expander 名表 ↔ Builtin::ALL ↔ eval 分派注册——0.6 前置锚转正）；eval 消费 CoreExpr/ModuleItem 全构造面（L4→L7 直消费——§18.5 新增 L7→L4 边活性）；builtin_ops 单源（kerf-vm 与 kerf-runtime 同函数体——零漂移断言即编译期保证）；VM Collector 注入面消费（kerf-runtime 实现 kerf-vm trait——依赖倒置活性）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联，kerf-vm 演进） | value.rs（2+2）/ error.rs（0+1）/ vm.rs（2+2） | 4 | 5 |
| 单元（crate 内联，kerf-runtime） | gc.rs（0+12）/ eval.rs（3+19）/ parity.rs（2+1） | 5 | 32 |
| crate API | crates/kerf-runtime/tests/api_tests.rs | 3 | 2 |
| 跨 crate 集成 | tests/v0/stage0/plan/runtime_seed_tests.rs（经 runner.rs） | 7 | 13 |
| **测试合计** | | **19** | **52** |

- 正负比 = 19:52 ≈ 1:2.7（**偏差申报**——未达 1:3 精确线；GC 防御族 12 case 全数归负向（不误收/不悬垂/不爆栈/不双计），≥15 parity 程序为验收标准本体不可拆负向，错误族已穷尽十一变体；凑数拆分违反 §12 最优>最小——详见 plan-0.7.md §3 与 calibration-data 0.7 行）
- 累计口径：89+19=108 : 267+52=319 ≈ 1:2.95（全 workspace 356 → **427**）；集成构成：正向 7 ≥1 / 负向 13 ≥3 / 跨阶段消费 6 ≥1 ✅（GATE 6 其余项全达标）
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：60 → **70 case** 单调增长（A10 + B10 + C5 + D5 + E10 + F10 + G10 + **H10 runtime 负向**：eval 源码级 unbound/arity×2/type×4/div-zero/unhandled + GC 防误回收（roots 完备存活断言）+ parity 分歧检测器自检）——七类维持 **6/7**（余 1 类结构性 DEFERRED：模块循环依赖@0.9——matrix.md 累计视图记账；门审级 7/7 于 0.11 达成）

## 4. 依赖

- kerf-vm（§18.5 既有边 L6→L7 消费面：Value/Heap/HeapObj/ClosureData/RuntimeError/Builtin/VmIo/BufferIo/Vm + 本轮新增 Collector trait/Roots/Heap 收集器面/test_and_set_mark 等 + builtin_ops 单源分派函数族）
- kerf-core（**§18.5 新增边 L4→L7**：CoreExpr/ModuleItem/LiteralValue——eval 元循环求值 CoreExpr 的章程内含义；L7 依赖低层零环 ✓）
- kerf-compiler（**§18.5 新增边 L5→L7**：Span/Symbol 再导出消费——eval 错误携带 Span 的类型面；沿 0.5 决策 14「消费面完整性传递」先例）
- kerf-span（dev-dependencies——测试夹具，沿先例）；集成层经根聚合 crate 再导出路径（§8.4.6）
- **零新外部依赖**（crates.io 零增量——§18 审查规避裁定沿袭）

## 5. 覆盖率

- 构造面全覆盖：GC 三阶段全路径 + 根集四类逐类 + RuntimeError 十一变体全负向（新增 EvalDepthExceeded）+ CoreExpr 九变体 eval 全解释 + ModuleItem 三变体全处理 + Builtin 十八名全分派 + Collector trait/Roots/Heap 收集面全公共 API
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界）：eval Rust 递归深度帽 EVAL_DEPTH_LIMIT（VM 帧堆不受限——元循环固有约束，双侧不对称已登记）；词法闭包捕获 dormant（0.6 口径对偶——Stage 1 两侧同步激活）；碎片治理（只分配不压缩——sweep 归还 free list，压缩/分代 = Stage 2 §14.2）；GC 触发 = 分配点软超限（eval 内联 + VM 注入面——0.6 默认无 collector 保持 fail-closed 为兼容契约）；变参内建 = Stage 2 库面（固定元数沿 0.6）；parity 比较闭包值 = kind 级（`#<closure>` 形态——闭包身份不参与程序结果语义）

# Stage 0.11 测试文档——快照测试套件（snapshot suite：≥50 快照 + 性能基线收口轮）

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）+ §9.4.3 v15.1（易错分布全覆盖判定 + 分布论证义务）
> 双生文件：tests/v0/stage0/plan/snapshot_seed_tests.rs（经 tests/runner.rs 挂载——57 case）
> 设计依据：docs/stage0.md §13.2（三层测试第一层：快照测试 = 确定性输出——固定输入 → 固定输出）+ §22.3 里程碑 L6「至少 50 个快照测试通过」+ docs/develop/v0/roadmap.md §6 首议程 1（672/710 计数中快照形态盘点 + 补齐）+ docs/develop/v0/stage-0/plan-0.11.md（本轮计划）
> 录制纪律：全部黄金值由 0.10-r3 基线实现（710:0:0 全绿 + audit 110/110）实测录制（temp probe → 逐条目检 → 冻结内嵌）；快照的本体义务 = 冻结当前已验证行为，非重新推导

## 1. 目标

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | Reader 层快照（RS01-RS10） | 源文本 → SyntaxObject 骨架确定性转储（atom 五类 + 嵌套 list + 注释跳过 + 全九原语 fib 源 + quote 点号语法事实）；转储器 = 测试侧确定性 walker（`dump_stx`——span/scopes/phase 不入转储：结构骨架是快照对象，位置信息由 span 测试族专测） |
| FP2 | Expander 层快照（ES01-ES10） | define 包装源 → ModuleItem/CoreExpr 树确定性转储（`dump_item`/`dump_core`——九语义原语逐一直接形态：Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle + do→Let 脱糖 + define 函数糖展开）；`apply` 显式头 + `set!` 保留名——展开器输出形状逐字节冻结 |
| FP3 | Compiler 层快照（CS01-CS10） | CoreExpr → Bytecode 指令清单确定性转储（`dump_bytecode`——`Instr` Display 机器形态 `op a b` 逐指令 + func 头 params/n_locals + 常量池/全局表索引序）；字面量加载/二元应用/if 跳转形状/let store-local 链/闭包 proto/匿名立即调用/cons/car 链/完整 fib 21 指令/入口消费——编译器输出形状逐字节冻结 |
| FP4 | VM 层快照（VS01-VS10 + VE01-VE02） | define 包装源 → run → `globals` 表（名称=值 Display 形态，编译序）+ `outputs` 行 + 值形态；双引擎各一全链（fib VM + car Eval）——运行时终态逐字节冻结；含 `#<pair>`/`#<closure>`/`#<builtin:+>` 不透明形态与 eq? 身份语义（false——两个 pair 不同堆位） |
| FP5 | Driver 层快照（DS01-DS10） | 源 → 渲染诊断黄金字节（六负向路径：未闭合/类型不匹配/参数个数/未绑定/空应用/多诊断——rustc 风格 `error[code]: msg` + `-->` + 摘录 + 脱字符）+ check 面（funcs/instrs/globals 计数）+ parity 三面（values/outputs/globals 全 true）+ WORKSPACE_VERSION 字符串 + 输出行序——驱动层消费工件逐字节冻结 |
| FP6 | REPL 会话快照（TS01-TS04 + VD01） | 提交序列 → 事件转录（值/新输出/错误回滚[负向路径]/未闭合继续跨行续读）；Value Display 八形态单卡（int/float/bool/str/nil/pair/closure/builtin）——会话状态机行为冻结 |

## 2. 实测数（交付后回填——57 case 全绿）

| 分节 | case 数 | 负向路径形态 | 说明 |
|------|--------|-------------|------|
| §A Reader（RS01-RS10） | 10 | 0 | 确定性骨架转储全正向 |
| §B Expander（ES01-ES10） | 10 | 0 | 九原语展开形状全正向 |
| §C Compiler（CS01-CS10） | 10 | 0 | 指令清单全正向 |
| §D VM/Eval（VS01-VS10 + VE01-VE02） | 12 | 0 | 运行终态全正向（VS09 eq?=false 是身份语义正向断言） |
| §E Driver（DS01-DS10） | 10 | 6（DS01/02/03/04/05/10） | 六负向路径渲染黄金字节 + check/parity/version/outputs 四正向 |
| §F REPL（TS01-TS04 + VD01） | 5 | 1（TS02 错误回滚） | 会话转录 + 值形态卡 |
| **合计** | **57** | **7** | **≥50 门槛满足（§22.3 L6）** |

**与既有 710 套件的关系**：快照套件是**增量冻结层**（新增 57），不重复既有断言面；既有套件中快照形态的测试（driver.md 渲染黄金契约 9 case + compiler.md 指令序断言族 + span 序列断言族等）继续在位——本轮矩阵 §0.11 节登记两类计数（专套 57 + 既有形态盘点 ~40+，合计远超 50 门槛；**门槛以专套 57 为规范口径**——单一可重跑入口）。

## 3. 分布论证（§9.4.3 v15.1——全覆盖义务 + 分布论证义务）

- **易错分布依据**：快照层的错误密度集中在**转储器自身**（walker 遍历漏分支 → 输出缺形）与**黄金值录制时点**（基线行为误读）——两类风险的负向检验由「转储器穷尽 match（编译器强制）+ 黄金值逐条目检（录制纪律）」承载；被冻结对象（已验证 710:0:0 的管线行为）的错误面已由既有套件 7 类 7/7 负向覆盖，快照层重复负向 = 凑数（§12 禁止）。
- **负向形态 7 case 的落位依据**：错误路径的**渲染形态**（字节级）此前仅 driver.md 渲染契约 9 case 覆盖渲染器；本轮将「错误作为被冻结工件」补入快照层（6 渲染 + 1 REPL 回滚）——错误路径的**检测**语义不重复测，错误路径的**呈现字节**入冻结。
- **正负比申报**：50:7 = 1:0.14 反向偏差——快照层 = 结构性正向验收面（确定性契约），沿 0.8（编排层）/0.10（预留冻结轮）反向先例申报；凑数违反 §12。
- **全覆盖义务**：FP1-FP6 每功能点正向 ≥1 ✓；负向覆盖全部已点亮错误类 → 非本轮义务（错误类负向覆盖属检测语义，既有套件 7/7 维持——见 matrix.md 0.11 节注记）。

## 4. 落位与依赖方向

`tests/v0/stage0/plan/snapshot_seed_tests.rs`（§8.4.6 根聚合位——跨 crate 消费 L1→L8 全链）；零新依赖（转储器 = 测试侧纯函数 walker；黄金值内嵌字符串字面量——无黄金文件 I/O，Stage 0 无文件系统依赖面）；挂载 = tests/runner.rs `#[path]`（零 `[[test]]` 声明——§8.4.6 v11.2）。

## 5. 边界申报（非 TD——设计边界）

- 转储器不含 span/scopes/phase（快照对象 = 结构骨架；位置确定性由 span/syntax 测试族承载）——设计选择非缺失。
- 黄金值与实现**共变**（行为变更 → 快照更新 + worklog 记录变更理由）——快照测试义务 = 冻结 + 显式变更面，非永固。
- Float 形态依赖 Rust Display（`-3.5`/`2.5`）——平台稳定性由 Rust 标准库契约承载。

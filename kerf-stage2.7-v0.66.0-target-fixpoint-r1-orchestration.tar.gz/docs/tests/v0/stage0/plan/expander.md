# Stage 0.4 测试文档——kerf-expander 展开/脱糖种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-expander/**（内联 + api_tests）+ tests/v0/stage0/plan/expander_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs E 节（§7.3.1 审计集单调增长 30→40）
> 设计依据：docs/stage0.md §19.2（Expander 实现框架——展开循环骨架/核心不变式/实现陷阱）+ §3.3（语法对象四元组）+ §8.9（相位分离——本轮起步：相位封闭 fail-closed）+ §8.10（基础宏系统骨架——卫生机制 0.9 完整化）+ §6.12.6（Begin→Let 链脱糖）+ §3.2 糖示例（letrec→nil 种子 + set!）+ docs/sop.md §7.1.1（七类错误——本轮点亮「未绑定标识符/宏展开深度」两类）+ §21.12-11（r67 原语真值）+ 0.1-design-adjudications.md（do→Let 脱糖裁定）

## 1. 目标

验证 Stage 0.4 kerf-expander 的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | ExpandError 错误面 | 七变体全覆盖：UnboundIdentifier（七类 #2）/ ExpansionDepthExceeded（七类 #7）/ EmptyForm（空应用合成面复检——0.3 读期先拦的纵深防御第二层）/ PhaseViolation（相位封闭 fail-closed——§8.9 规则 1 起步）/ MalformedForm（特殊形式形态族）/ TopLevelExpression（模块顶层声明边界）/ Core（core 校验构造器语义下限再断言传播——DuplicateParam/DuplicateHandler/InvalidSymbol）；R8 消息形态（小写开头/无句尾句号/反引号载荷）；载荷携带精确 Span |
| FP2 | expand 表达式面（9 核心形式） | 原子：Int/Float/Bool/String→Literal + `nil` 保留字面量（LiteralValue::Nil）+ Symbol→作用域集键控解析（Local/Global/Unbound 三态）；`(fn (params) body)`→Fn（参数绑定新域 + 体着色展开 + 重复参数 Core 再断言）；`(if c t e)`→If（严格三操作数）；`(let (x e) b)` 单绑定 / `(let ((a e1) (b e2)) b)` 多绑定 / `(let () b)` 空绑定→Let（let\* 渐进绑定语义——后值可见前名）；`(do e1 … en)`→Let 链脱糖（`_` 弃置绑定——§6.12.6 Begin→Let 链；`(do e)` 恒等）；`(set! name e)`→Assign（目标必须可解析——Scheme 语义）；`(perform E args…)`→Perform；`(handle body (E h)…)`→Handle（子句闭包于当前域 + 重复效应 Core 再断言）；`(f args…)`→Apply（头保留字平面分派——scoped-keyword 机制 0.9 升级路径登记） |
| FP3 | expand_program 模块面 | `(define (f x) body)` 函数定义糖→Define(f, Fn) + `(define name e)` 值定义→Define（顺序绑定 + 自引用 letrec 式顶层语义——fib 递归契约）；`(require "m")`→Require（仅字符串 datum——fail-closed）；`(module m items…)`→Module（递归声明 + 域隔离：外层 define 不渗入）；裸表达式→TopLevelExpression（顶层表达式项通道 = define 调用形通则——r110 语料锚）；STAGE0_GLOBALS 18 名全局函数表（Stage 0 最小运行时表面——0.7 parity 断言钩子） |
| FP4 | 帽/卫生/跨阶段消费 | `EXPANSION_LIMIT = 512` 公开常量（≥2× reader 256 帽裕量——独立界定合成树/宏产树展开工作预算；512 内通过/越界拒绝双向边界）；域着色生产化（fresh_scope + with_scope_added 深翻转——0.2 契约消费；绑定域 ∈ 标识符作用域集的键控解析——0.9 卫生并集的骨架）；相位全 Runtime 检查（每节点）；Span 全节点真实源 span（脱糖合成节点复用源 span——跨代 join 零发生 = TD-002 裁定实证）；visit_spans 前序精确序；fib 源码→CoreExpr 契约（reader→expander 全链） |

## 2. 场景

- **正向**：原子往返五类（int/float/bool/string/nil→LiteralValue 对应变体）；参数引用经着色解析（Local）；STAGE0_GLOBALS 解析（`+`/`car`→Global→Var）；let\* 渐进语义（后值引用前名）；do→Let 脱糖结构（`_` 弃置绑定数 = 步数-1 + body 末位）；fib 形 fn+if+apply 组合；expand_program 完整 fib 定义（Define + Fn + If 树形 + span 前序序）；define 顺序绑定（后定义引用前定义）；module 嵌套递归；域着色幂等（翻转保形）
- **负向**：未绑定标识符（原子位/操作数位/深层嵌套位——**七类 #2 点亮**）；展开深度越界（合成 513 深树——**七类 #7 点亮**；512 边界通过对）；空表合成面（List(vec![]) 直达 expand——EmptyForm）；相位违规（MacroExpansion 相位树——PhaseViolation）；形态族（fn 少体/if 二操作数/let 坏 spec/set! 非符号目标/perform 非符号效应/handle 坏子句/define 坏形/require 非字符串）；重复参数/重复效应（Core 传播）；顶层裸表达式；set! 未绑定目标；R8 消息形态族断言
- **跨阶段消费**：fib 源码 read_program→expand_program→CoreExpr 契约（Expander→Compiler 0.5 契约锚定）；do 源码→Let 脱糖端到端；未绑定/重复参数经 reader 全链；span 归约（visit_spans 前序 + 全节点携带）；合成深度树经 syntax 构造器（0.2 契约消费）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | error.rs（0+5）/ ctx.rs（3+7）/ expand.rs（5+12） | 8 | 24 |
| crate API | crates/kerf-expander/tests/api_tests.rs | 2 | 6 |
| 跨 crate 集成 | tests/v0/stage0/plan/expander_seed_tests.rs（经 runner.rs） | 2 | 6 |
| **测试合计** | | **12** | **36** |

- 正负比 = 12:36 = 1:3 ✅（GATE 6）；≥40 门槛超配（48）；集成构成：正向 2 ≥1 / 负向 6 ≥3 / 跨阶段消费 2 ≥1 ✅
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：30 → **40 case** 单调增长（A10 + B10 + C5 + D5 + **E10 展开器负向**：未绑定×2/深度越界/相位/形态族×3/顶层表达式/空表合成面/重复参数）——七类 **4/7 点亮**（语法错误 + 空应用 + 未绑定标识符 + 宏展开深度）；余 3 类结构性 DEFERRED（参数个数/类型不匹配@0.6、模块循环依赖@0.9——matrix.md 累计视图记账；门审级 7/7 于 0.11 达成——SOP §7.1.1 v12.5 口径注沿袭）

## 4. 依赖

- kerf-syntax（§18.5 既有边：StxDatum/SyntaxObject/Phase/ScopeId/ScopeSet/StxSymbol/Span 再导出）+ kerf-core（§18.5 既有边：CoreExpr/LiteralValue/Binding/HandlerClause/ModuleItem/Symbol/CoreError 校验构造器）——**零新 DAG 边、零新外部依赖**（Span 经 syntax 再导出消费，无 kerf-span 直依需求）
- 集成层经根聚合 crate `kerf::expander`/`kerf::reader`/`kerf::syntax`/`kerf::core` 再导出路径（§8.4.6）；审计集 E 节经根聚合 crate 消费

## 5. 覆盖率

- 构造面全覆盖：ExpandError 七变体全负向 + expand/expand_program 双入口正负 + 九核心形式全产出变体（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）+ ModuleItem 三变体（Define 函数/值双形 + Require + Module 嵌套）
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界）：宏 transformer 执行/卫生并集/展开缓存 = 0.9 宏系统（§8.10 骨架边界——0.4 为核心形式骨架 + 相位封闭起步）；quote 数据面 = Stage 2 datum 机制（LiteralValue::Pair + nil 承载 Stage 0 数据）；`_` 弃置名 = 惯例绑定（可被用户遮蔽——无害）

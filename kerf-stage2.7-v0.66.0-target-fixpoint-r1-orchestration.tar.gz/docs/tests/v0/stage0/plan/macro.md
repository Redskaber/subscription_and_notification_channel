# Stage 0.9 测试文档——CodeValue + 基础卫生宏系统 + 模块加载层

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-expander/**（code/transformer/module/ctx/expand 内联）+ tests/v0/stage0/plan/macro_seed_tests.rs + examples/audit/stage0_gate_audit_r1.rs J 节（§7.3.1 审计集单调增长 80→90）
> 设计依据：docs/stage0.md §8.10（基础宏系统——卫生宏 + SyntaxObject 骨架：宏定义/宏展开/卫生性保证，syntax-parse 复杂组合排除）+ §19.2（Expander 实现框架——展开循环骨架宏调用分支 + 核心不变式三条[终止性/卫生性/相位封闭性] + 实现陷阱三则[Span 悬空/缓存键含作用域集/set!-define 顺序]）+ §9.38(b)（scope coloring + rename-on-capture 算法——def-site ∪ use-site 并集）+ §6.1/§6.3（CodeValue 结构化代码值——substitute/alpha_rename/free_variables/quote 能力模型）+ §8.9（相位分离系统 + 模块生命周期 declare/instantiate/visit）+ docs/sop.md §7.1.1（七类错误——第 7 类模块循环依赖本轮点亮，子阶段级 + 门审级 7/7 双达成）+ plan-0.4.md §4 裁定三（0.9 议程：expansion_id 递增 + span 集合表示 = 宏 transformer 机制）+ plan-0.7.md 决策 13（quote 登记态边界——0.1 LiteralValue::Pair 消费面兑现）+ plan-0.8.md 0.9 消费契约（Session/渲染/CLI = 宏展开 E2E 基础设施）+ kerf-expander/src/lib.rs 头注（"the def-site ∪ use-site union and transformer execution are the 0.9 macro system"——0.4 骨架边界预告）+ kerf-compiler/src/compile.rs L493-499（"proper scope homes arrive with the 0.9 module system"——编译器侧预告）

## 1. 目标

验证 Stage 0.9 的五大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | code.rs CodeValue 结构化代码值 | §6.3.3 设计 API 的 Stage 0 投影：`CodeValue{syntax}`（数据载体 = SyntaxObject——span/scopes/phase 卫生元数据内携）；`from_syntax`/`to_syntax`（quote 构造面/展开输入面）；`substitute(var, replacement)`（模式变量拼接——syntax-rules 变换器底座）；`alpha_rename(from, to)`（rename-on-capture 补救面——§9.38(b) 第二算法公开化）；`symbols()`（符号普查——Stage 0 无类型层无 binder 模型的诚实口径，§6.3.3 free_variables 的 Stage 2+ 演进位登记）；`to_source()`（S 表达式显示——诊断可观察面）；元数据访问器 span/scopes/phase |
| FP2 | transformer.rs syntax-rules 变换器 | `(define-syntax name (syntax-rules (literals...) (pattern template)...))` 面语法（EBNF §9.26 define_syntax 产生式——`(())` 圆括号形态，reader 0.3 无方括号路径）；**模式匹配**（`_` 通配/字面量表匹配[含保留字 `nil`]/模式变量绑定/嵌套列表递归/原子数据结构相等/定长匹配——Stage 0 无省略号 `...`：图案位出现即注册期 fail-closed 拒绝，登记边界）；**模板实例化**（模式变量 → 使用处实参子树**原样**拼接[span/scopes/phase 保持使用处身份]；引入节点 → def-site 上下文作用域 ∪ 新鲜 def_scope 着色[注册期 template 深翻转预着色] + expansion_id = 使用处代次 + 1[dea12b 范式：引入产物 > 0 / 用户 token = 0] + Phase::Runtime[相位封闭不变式 3]）；**注册期校验**（模式变量重复/`...` 出现/syntax-rules 形状错误 → MalformedForm fail-closed） |
| FP3 | ctx.rs 子集解析规则 + 宏登记簿 | **解析规则 0.4 骨架 → 0.9 一般化**：membership（frame.scope ∈ ref.scopes）→ **binder-scopes 子集**（frame.binder_scopes ⊆ ref.scopes——Racket "Binding as Sets of Scopes" 判据；非宏代码 binder_scopes == ref.scopes 逐字等值 → 0.4 全既有测试零回归的结构性兼容）；Frame 增 `macros`（宏名 → 变换器槽位）+ ctx 变换器 slab；`resolve_macro(name, use_scopes)`（同子集判据——§19.2 实现陷阱 2"缓存键必须含作用域集"的解析期兑现：同名宏不同作用域解析到不同登记）；`bind_macro`（帧内登记——模块隔离语义：嵌套 module 内定义的宏出模块即不可见） |
| FP4 | module.rs 模块加载层 | §8.9 模块生命周期 Stage 0 切片：`load_program(items)`——声明收集（嵌套 module 递归收集 + 重名 fail-closed）→ require 边遍历（顶层 require + 模块内 require 递归）→ **DFS 三色循环检测**（GRAY 回边 → `ModuleCycle{path}`——**§7.1.1 第 7 类点亮**：`module_loader: circular dependency`，子阶段级 + 门审级 7/7 双达成）→ 实例化次序（依赖先行的 DFS 后序——LoadPlan）；未声明模块 → `ModuleNotFound`；**边界申报**：require 的可见性合并（名字空间引入）= Stage 1 模块系统面，本轮交付 = 图验证 + 次序（编译器 flat 编译先例对偶——compile.rs L495 注释兑现位） |
| FP5 | expand.rs quote 形式 + 宏调用分派 + E2E | **`(quote datum)`**：字面量数据 → LiteralValue（Int/Float/Bool/String/Nil[保留字]；proper list → 右折 Pair 链终于 Nil——**0.1 LiteralValue::Pair 消费面兑现**[plan-0.7 决策 13 登记态边界]；符号数据 → `QuoteUnsupportedDatum` fail-closed[Stage 0 值模型无 Symbol 变体——诚实边界，报错>静默]；编译器 ConstKey::Pair 0.5 既有支持消费）；**宏调用分派**（expand_list 核心形式后/应用前：头符号经 `resolve_macro` 命中 → 变换器应用 → 产物递归 expand 至不动点[§19.2 展开循环——宏可展开出宏]；未命中 → 应用；预算 EXPANSION_LIMIT 守护自递归宏[类 5 维持]）；**define-syntax 声明**（ModuleItem::DefineSyntax 新变体——kerf-core 声明层忠实记录 + 编译器/求值器零码跳过[Require 先例]；展开期注册变换器——同程序内先定义后使用，REPL 累积源重解析天然跨行）；**E2E**（定义宏→使用→展开→执行四段全链——plan 行 0.9 验收标准本体；driver 双引擎 + parity 三面 + REPL 跨行 + 诊断渲染） |

## 2. 场景

- **正向**：CodeValue 六操作（构造/回转/拼接叶位/拼接深位/重命名/源显示/符号普查）；子集解析（着色标识符解析既存绑定[0.4 语义保持] + 宏登记可见）；模式匹配五形态（通配/变量/嵌套/原子/字面量）；模板实例化三断言（实参原样拼接 + 引入节点 def 着色 + expansion_id 递增）；模块加载（线性链次序/嵌套模块声明收集/空程序空计划）；quote 原子 + 嵌套 list → Pair 链；define-syntax 声明产出 DefineSyntax 项；my-if 宏展开 == 手写 if（CoreExpr 同构）；E2E：my-if 经 VM 执行 + eval 执行 + 双引擎 parity 三面一致；swap 风格宏正确值（卫生保证的可观察正例——tmp 碰撞下结果正确）；`(car (quote (1 2 3)))` → 1；REPL 两行跨行宏使用；含 module + require 的合法程序执行；嵌套 module 内宏定义且模块内使用；宏产物再宏（嵌套展开两代 expansion_id 单调）；check 面宏程序通过
- **负向**：**卫生防御族**（使用处绑定不捕获引入引用——let 绑定 tmp 包裹宏调用而模板引用 tmp → 必须解析 def-site 上下文而非使用处 let[负向断言：不捕获]；引入绑定不捕获使用处引用——模板 `(fn (tmp) ...)` + 实参含 tmp → 实参 tmp 必须解析外层[不遮蔽]；模块隔离——module 内 define-syntax 出模块即 UnboundMacro；异作用域宏不可见——binder_scopes ⊄ 使用处 scopes）；**错误六变体族**（UnboundMacro[未定义/使用先于定义] + MacroPatternMismatch[无规则命中/字面量不匹配/原子不等/长度不等] + QuoteUnsupportedDatum[符号/嵌套含符号] + ModuleCycle[双模块互引/三模块环/自引用] + ModuleNotFound[未声明] + ModuleDuplicate[重名]）；**注册期校验族**（模式变量重复/图案 `...` 出现/syntax-rules 形状错 ×3/define-syntax 形状错 ×2）；**深度防御**（自递归宏 `(loopy)` → `(loopy)` → ExpansionDepthExceeded[类 5 维持] + 互递归宏对）；**形状守卫**（quote 元数 ≠2/模板相位违例[合成树]/宏产物空形式）；E2E 诊断渲染（模块循环 line:col 定位 + kerf-expand 标签 + 环路径显示 a -> b -> a）
- **跨阶段消费**：五段一断 E2E（0.3 reader + **0.9 宏展开** + 0.5 compiler + 0.6 VM / 0.7 eval——同一展开产物双引擎）；expander → kerf-core（ModuleItem::DefineSyntax 新变体——声明层跨 crate 契约扩展[0.1→0.9 第四变体]）；expander → kerf-compiler（DefineSyntax 零码跳过 + Pair 字面量 ConstKey 既有面首次生产性消费[0.5 前置锚转正]）；expander → kerf-driver（load_program 挂接 pipeline::parse——模块错误经 Diagnostic::from_module 渲染；REPL is_declaration 增 define-syntax 头；宏展开 E2E 全链消费 0.8 基础设施[Session/渲染/CLI——plan-0.8 0.9 消费契约兑现]）；kerf-runtime eval 零码跳过对齐（DefineSyntax 求值面 = Require 先例）

## 3. 预期数（三层 + 审计集）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | code.rs（5+0）/ ctx.rs（2+3）/ transformer.rs（8+7）/ module.rs（3+5）/ expand.rs（3+10） | 21 | 25 |
| 跨 crate 集成 | tests/v0/stage0/plan/macro_seed_tests.rs（经 runner.rs） | 10 | 17 |
| **测试合计** | | **31** | **42** |

- 正负比 = 31:42 ≈ 1:1.35（**偏差申报**——未达 §9.4.3 1:3 精确线；宏展开 E2E = plan 行 0.9 验收标准本体「定义宏→使用→展开→执行」四段全正向不可拆负向 + CodeValue 六操作/变换器匹配实例化 = §6.3.3 设计 API 合同面正向本体 + 负向已穷尽[六新错误变体全负向 + 注册校验七 + 卫生防御族四 + 深度二 + 形状守卫三 + 装载校验族]；凑数拆分违反 §12 最优>最小——沿 0.7（1:2.7）/0.8（1:0.7 反向）偏差申报先例，详见 plan-0.9.md §3 与 calibration-data 0.9 行）
- 累计口径：181+31=212 : 370+42=412 ≈ 1:1.94（全 workspace 551 → **624**）；集成构成：正向 10 ≥1 / 负向 17 ≥3 / 跨阶段消费 6 ≥1 ✅（GATE 6 其余项全达标）
- §7.3.1 审计集（非 cargo test 口径——cargo run --example 可重跑）：80 → **90 case** 单调增长（A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + **J10 宏/模块/quote 负向**：宏未定义/无规则命中/卫生捕获双向/自递归深度/quote 符号拒绝/模块环×2/模块未声明/define-syntax 形状/嵌套模块隔离）——七类 **7/7 全点亮**（第 7 类模块循环依赖 J 节点亮——**门审级 7/7 达成**：matrix.md 累计视图记账，七类全覆盖首次达成；子阶段级 7/7 同轮达成）

## 4. 依赖

- kerf-syntax（既有边：SyntaxObject/StxDatum/ScopeSet/ScopeId/Phase/Span——CodeValue 数据载体 + with_scope_added 深翻转[0.2 契约生产性消费] + ScopeSet::union/is_subset_of[0.2 预置 API 首次生产性消费]）
- kerf-core（既有边：CoreExpr/LiteralValue[Pair 消费面兑现]/ModuleItem[+DefineSyntax 第四变体]/Symbol/CoreError；L4→L3 既有消费方向不变）
- kerf-span（既有边：Span/ExpansionId[代次递增——dea12b 范式]/FileId/ByteOffset）
- kerf-driver（消费方：pipeline::parse 挂接 load_program + Diagnostic::from_module + REPL is_declaration——§18.5 既有边 L3→L8 活性扩展；宏展开 E2E 基础设施消费）
- kerf-compiler（消费方：DefineSyntax 零码跳过——L3→L5 既有边活性扩展；ConstKey::Pair 首次生产性消费）
- kerf-runtime（消费方：eval DefineSyntax 零操作——L3→L7 既有边活性扩展，Require 先例对偶）
- **零新外部依赖**（crates.io 零增量——§18 审查规避裁定沿袭）；**零新 crate**（9/9 维持——宏系统 = kerf-expander 演进，Layer 3 章程内）

## 5. 覆盖率

- 构造面全覆盖：CodeValue 全公共 API + SyntaxRules 注册/匹配/实例化全路径 + ExpandError 十变体（新增三：UnboundMacro/MacroPatternMismatch/QuoteUnsupportedDatum）+ ModuleError 三变体全负向 + ModuleItem 四变体全处理（expander 产出/compiler 跳过/eval 跳过/driver 可见）+ Pattern 五形态 + 卫生着色双向 + expansion_id 递增/保持双断言
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内）
- 边界申报（非 TD——设计边界，登记于 plan-0.9.md §4）：syntax-rules 无省略号（`...` 注册期拒绝——Stage 1 库面；§8.10 "不支持复杂的宏组合"）；quote 符号数据不支持（Stage 0 值模型无 Symbol 变体——fail-closed 报错；Stage 1 值模型演进位）；CodeValue.symbols = 语法普查非语义自由变量（无类型层无 binder 模型——§6.3.3 free_variables Stage 2+ 演进位）；require 可见性合并不交付（本轮 = 图验证 + 实例化次序——Stage 1 模块系统面；编译器 flat 编译 + eval 平铺先例对偶）；宏跨程序/跨文件不持久（Stage 0 单文件程序 + REPL 累积源重解析——§8.9 多文件 = Stage 1）；变换器 = syntax-rules 单一形态（proc-macro 风格显式变换器 = Stage 1+ 面）；展开缓存不实现（本轮解析期作用域键即查即用——缓存 = 性能面 Stage 2 优化窗，登记态）

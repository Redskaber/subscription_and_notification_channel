# Stage 0.2 测试文档——kerf-syntax SyntaxObject 种子

> 依据：docs/sop.md §9.2 规则 1（测试文档先行，实现后双向印证）
> 双生文件：crates/kerf-syntax/**（内联 + api_tests）+ tests/v0/stage0/plan/syntax_seed_tests.rs
> 设计依据：docs/stage0.md §3.3（语法对象四元组——expr/span/scopes/phase）+ §7.3.6（「扩展的 S 表达式」——骨架 + 逐节点增强；Racket 工业实证）+ §8.9（相位模型）/ §9.38（scope coloring 草图）/ §19.2 不变量 2（卫生性——逐标识符作用域集）+ docs/sop.md §21.12（Stx 前缀命名 / ID 无前缀 / 显式再导出）

## 1. 目标

验证 Stage 0.2 kerf-syntax 数据层的四大功能点：

| FP | 功能点 | 说明 |
|----|--------|------|
| FP1 | StxSymbol 校验构造 | 非空 + 无空白 + 无控制字符——与 kerf-core::Symbol 同下限（0.4 展开器以 `&str` 经 core 校验构造器跨界，双下限一致保证「reader 接受 ⇒ core 接受」）；CJK 保持合法（登记制白名单，完整文法随 0.3） |
| FP2 | Phase 相位模型 | 二值枚举（Runtime=0 / MacroExpansion=1，stage0.md §3.3 字段 4）；from_u8 校验解码（拒绝越级值——未来多阶段层级走加性扩展，原则 27）；相位封闭性属 0.4 展开器不变量，数据层不交叉校验（诚实边界） |
| FP3 | ScopeSet 作用域集 | 有序去重集合（确定性迭代序——§2.3-3 确定性边界，无 HashMap 随机序）；insert/contains/union（函数式，操作数不可变——原则 23）/is_subset_of（词法解析查询——§9.38 解析草图）；ScopeId 无前缀 ID 型（§21.12-3），分配新鲜性纪律归 0.4 消费者 |
| FP4 | StxDatum 六变体 + SyntaxObject 四元组 | 无 DUMMY span（结构性——非 Option 必填字段，畸形 span 在 kerf-span 构造层先拒）；List 成员 = 完整 SyntaxObject（逐节点包装——Racket 模型，卫生性需要逐标识符作用域集）；kind_name/Display（S 表达式记法）；visit_spans 前序遍历（0.4 消费契约，镜像 CoreExpr::visit_spans）；with_scope_added 深翻转（函数式——原则 23；scope coloring 原语） |

## 2. 场景

- **正向**：合法构造往返（as_str/Display/kind_name 六变体）；CJK 标识符接受（§10.5 CJK 被测对象白名单——登记于 symbol.rs 测试注释 + 本档）；相位 as_u8/from_u8 双向往返 + Display；作用域集构造/包含/有序迭代/并集/子集链；`(add 1 2)` 形 Display 渲染（嵌套/字符串引号/空表 `()`/浮点保形）；visit_spans 前序精确序；with_scope_added 深翻转不可变性（原树不变 + 新树逐节点含新域 + span/相位/datum 形状不变）
- **负向**：StxSymbol 拒绝（空/纯空白/内嵌空格/内嵌制表/前导/尾随/NUL 控制字符/Unicode 空白 NBSP）；SyntaxError 消息 R8 形态（小写开头/无句尾句号/反引号载荷；InvalidSymbol 渲染与 kerf-core 逐字节一致——单源字典）；Phase::from_u8 拒绝（2/255 + 变体载荷）；作用域集假值族（contains 缺失 false/insert 重复 false/非子集 false/异集不等）；symbol 校验构造器经对象路径拒绝（空/内嵌空格/前导/NUL）；畸形 span 在对象构造前被 kerf-span 层拒绝（无 DUMMY 结构性守卫）；双翻转无重复（去重不变量守卫）
- **跨阶段消费**：reader 形状 token→stx 装配（TokenLike 归约 covering span → 逐 token 构造 → 列表装配 + 前序 span 精确序 + Display 往返——0.3 消费契约）；expander 形状 span 归约 + 深翻转 + 卫生并集（definition ∪ use + 子集可见性判定 + join 折叠——0.4 消费契约；TD-002 边界：跨文件/跨代次 join 经 stx 树保持拒绝）

## 3. 预期数（三层）

| 层 | 文件 | 正向 | 负向 |
|----|------|-----|-----|
| 单元（crate 内联） | symbol.rs（2+8）/ error.rs（0+3）/ phase.rs（2+3）/ scope.rs（2+4）/ expr.rs（2+6） | 8 | 24 |
| crate API | crates/kerf-syntax/tests/api_tests.rs | 2 | 6 |
| 跨 crate 集成 | tests/v0/stage0/plan/syntax_seed_tests.rs（经 runner.rs） | 2 | 6 |
| **合计** | | **12** | **36** |

- 正负比 = 1:3 ✅（GATE 6）；单元 ≥30 ✅（32）；集成构成：正向 2 ≥1 / 负向 6 ≥3 / 跨阶段消费 2 ≥1 ✅
- §7.1.1 七类错误矩阵：仍 N/A（无 Reader/Expander/VM——冷启动结构性缺口沿 plan-0.0.md §6 裁定，0.3 起点亮）

## 4. 依赖

- kerf-span（工作区内路径依赖——§18.5 既有边 L0→L1）
- 集成层经根聚合 crate `kerf::syntax` / `kerf::span` 再导出路径（§8.4.6）

## 5. 覆盖率

- 构造子全覆盖：SyntaxObject 六构造器（symbol 校验 + int/float/bool/string/list 直构）+ StxDatum 六变体 + Phase 二变体（+ from_u8 越界拒绝）+ ScopeSet 全操作面（new/insert/contains/len/is_empty/iter/union/is_subset_of）
- 全部公共 API 有正向 + 错误面有负向；0 UNTESTED；0 DEFERRED（本子阶段范围内；虚线对不建模 = 设计边界非缺口——见 plan-0.2.md 设计对齐）

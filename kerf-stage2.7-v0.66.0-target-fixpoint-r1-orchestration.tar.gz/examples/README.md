# examples/ — 跨 crate 演示与审计脚本（SOP §9.6）

- `audit/`：阶段门审计集（§7.3.1——stage0_gate_audit_r<R>.rs 自 0.11 落位，≥30 case 可重跑）

//! Stage 0 performance baseline (SOP §14.6.4) — the re-runnable
//! benchmark entry for the stage-end gate.
//!
//! Measures the two §22.3 baseline axes (compile time + run time)
//! with std-only tooling (zero new dependencies — SOP §18): wall
//! clock via `std::time::Instant`, statistics as mean/median/min/
//! stdev over N iterations (median stays the primary criterion —
//! environment-noise resistant; §9.61 PERF-2).
//!
//! Methodology v2 (§9.61, K88-K91 frontier adjudications):
//! - Optimizer fences: every measured region takes its source input
//!   through `std::hint::black_box` (K90 — best-effort fence, a
//!   discipline rather than a guarantee; the doc comment records the
//!   limitation so nobody mistakes the fence for a hard one).
//! - Warmup: each axis runs `max(3, iters/10)` unrecorded iterations
//!   before the measured loop, so cold caches and first-touch page
//!   faults land outside the sample set (§9.61 PERF-2).
//! - Reporting: mean / median / min / stdev — the stdev and min
//!   expose outlier contamination that mean/median alone would hide.
//! - Sub-axis split: B1 keeps its composite shape (whole-chain
//!   comparability with the recorded baseline) and gains three
//!   sub-axes B1a/B1b/B1c (read / expand / compile+verify) so a
//!   regression can be attributed to a stage — the §9.44.5 trigger
//!   table demands stage-level attribution, which the composite
//!   number alone could never provide (§9.61 PERF-3).
//! - Deterministic counters: B4 keeps the gc-cycles/swept counters —
//!   the deterministic observability face (K91 pattern: values that
//!   change are a semantic change, not a performance change).
//! - Invoke-share axis: B6d (Stage 3.1, the W-3.1 env-copy blade's
//!   measurement face) splits the closure cost story the way B1's
//!   sub-axes split the compile chain — B6a/b/c measure per-CREATION
//!   cost only; B6d holds one created closure and measures per-
//!   INVOCATION cost (arity check + frame install + body + ret),
//!   the share the flat-closure dynamic-cost framework (Accattoli)
//!   names as the per-call installation cost the blade targets.
//!
//! The output lines are the paste source for
//! `docs/develop/v0/stage-0/performance-baseline.md`; re-run after
//! any change and compare against the recorded baseline (regression
//! detection, §14.6.4 rule 3).
//!
//! Run: `cargo run --release --example stage0_baseline`.

use std::cell::Cell;
use std::hint::black_box;
use std::rc::Rc;
use std::time::Instant;

use kerf::compiler::compile_program;
use kerf::driver::composed_target_read_chain_parity;
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, Roots, Vm};

/// The fib decl, target skin (the pipeline FIB attestation's decl
/// half — r150's migrated spelling; the single-skin r151 note: the
/// benchmark's read axis is the target reader by construction).
const FIB: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }";

/// Four-statistic reporting set (§9.61 PERF-2). Sample standard
/// deviation (the `n-1` form) — the outlier-visibility companion to
/// the median-primary judgment.
struct Stats {
    mean: f64,
    median: f64,
    min: f64,
    stdev: f64,
}

fn stats(samples: &[f64]) -> Stats {
    let mut s = samples.to_vec();
    s.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    let n = s.len() as f64;
    let mean = s.iter().sum::<f64>() / n;
    let median = s[s.len() / 2];
    let min = s[0];
    let var = if s.len() > 1 {
        s.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / (n - 1.0)
    } else {
        0.0
    };
    Stats {
        mean,
        median,
        min,
        stdev: var.sqrt(),
    }
}

/// One line of the paste block for microsecond axes (B1 family):
/// mean / median / min / stdev, one decimal, µs unit.
fn line_stats_us(label: &str, iters: usize, st: &Stats) {
    println!(
        "{label}: {iters} iters, mean {:.1}µs, median {:.1}µs, min {:.1}µs, stdev {:.1}µs",
        st.mean, st.median, st.min, st.stdev
    );
}

/// One line of the paste block for millisecond axes (B2-B5):
/// mean / median / min / stdev, three decimals, ms unit.
fn line_stats_ms(label: &str, iters: usize, st: &Stats) {
    println!(
        "{label}: {iters} iters, mean {:.3}ms, median {:.3}ms, min {:.3}ms, stdev {:.3}ms",
        st.mean, st.median, st.min, st.stdev
    );
}

/// Warmup count for an axis: `max(3, iters/10)` (§9.61 PERF-2 —
/// unrecorded iterations land cold caches and first-touch faults
/// outside the sample set).
fn warmup_iters(iters: usize) -> usize {
    (iters / 10).max(3)
}

/// Counting collector: shares sweep counters out through interior
/// mutability so the bench can read them while the VM owns the box.
/// The sweep itself is the production mark-sweep (`kerf-runtime`).
#[derive(Clone, Default)]
struct SharedCounters {
    cycles: Rc<Cell<u32>>,
    swept: Rc<Cell<u32>>,
}

struct CountingCollector {
    shared: SharedCounters,
}

impl Collector for CountingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let gc = production_collect(heap, roots);
        self.shared.cycles.set(self.shared.cycles.get() + 1);
        self.shared.swept.set(self.shared.swept.get() + gc.swept);
        gc.swept
    }
}

fn main() {
    let file = FileId(0);

    println!("kerf stage-0 performance baseline (methodology v2)");
    println!(
        "env: release profile (debug_assertions={}), parallelism {:?}",
        cfg!(debug_assertions),
        std::thread::available_parallelism()
    );

    // B1 compile throughput: source -> read + expand + compile + verify.
    // Composite axis kept for baseline comparability; the three sub-axes
    // B1a/B1b/B1c below attribute a regression to a stage (PERF-3).
    const B1_ITERS: usize = 1_000;
    for _ in 0..warmup_iters(B1_ITERS) {
        let forms = read_target_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
    }
    let mut b1 = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let t = Instant::now();
        let forms = read_target_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
        b1.push(t.elapsed().as_secs_f64() * 1e6);
    }
    line_stats_us(
        "B1 compile-fib (read+expand+compile+verify)",
        B1_ITERS,
        &stats(&b1),
    );

    // B1a read sub-axis.
    let mut b1a = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let t = Instant::now();
        let forms = read_target_program(file, black_box(FIB)).expect("read");
        let n = forms.len();
        b1a.push(t.elapsed().as_secs_f64() * 1e6);
        black_box(n);
    }
    line_stats_us("B1a read-fib", B1_ITERS, &stats(&b1a));

    // B1b expand sub-axis (reads the product of a fenced read).
    let mut b1b = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let forms = read_target_program(file, black_box(FIB)).expect("read");
        let t = Instant::now();
        let items = expand_program(&forms).expect("expand");
        let n = items.len();
        b1b.push(t.elapsed().as_secs_f64() * 1e6);
        black_box(n);
    }
    line_stats_us("B1b expand-fib", B1_ITERS, &stats(&b1b));

    // B1c compile+verify sub-axis (reads the product of a fenced expand).
    let mut b1c = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let forms = read_target_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let t = Instant::now();
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
        b1c.push(t.elapsed().as_secs_f64() * 1e6);
    }
    line_stats_us("B1c compile+verify-fib", B1_ITERS, &stats(&b1c));

    // B2 VM run: fib(25) = 75025 — the 0.6 anchor workload, entry
    // consumes the defined closure (read back from the global).
    const B2_ITERS: usize = 100;
    const B2_SRC: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(25));";
    let bc2 = {
        let forms = read_target_program(file, black_box(B2_SRC)).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    for _ in 0..warmup_iters(B2_ITERS) {
        let mut vm = Vm::new(bc2.clone()).expect("vm");
        vm.run().expect("fib(25)");
    }
    let mut b2 = Vec::with_capacity(B2_ITERS);
    for _ in 0..B2_ITERS {
        let mut vm = Vm::new(bc2.clone()).expect("vm");
        let t = Instant::now();
        vm.run().expect("fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            vm.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b2.push(elapsed);
    }
    line_stats_ms("B2 vm-run-fib25", B2_ITERS, &stats(&b2));

    // B3 eval run: fib(20) = 6765 on the meta-circular evaluator.
    const B3_ITERS: usize = 30;
    const B3_SRC: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(20));";
    for _ in 0..warmup_iters(B3_ITERS) {
        let mut session = kerf::driver::Session::new();
        kerf::driver::run_source(
            &mut session,
            "bench.ktf",
            black_box(B3_SRC),
            kerf::driver::Engine::Eval,
            &[],
        )
        .expect("eval fib(20)");
    }
    let mut b3 = Vec::with_capacity(B3_ITERS);
    for _ in 0..B3_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.ktf",
            black_box(B3_SRC),
            kerf::driver::Engine::Eval,
            &[],
        )
        .expect("eval fib(20)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("6765".to_owned())
        );
        b3.push(elapsed);
    }
    line_stats_ms("B3 eval-run-fib20", B3_ITERS, &stats(&b3));

    // B4 GC pressure: 2000 top-level defines each allocating one
    // pair that is dead right after `car` consumes it — the sweep
    // path is exercised under a tight 1024-cell budget (frames stay
    // flat; only heap garbage accumulates).
    const B4_ITERS: usize = 50;
    const B4_PAIRS: usize = 2_000;
    let mut churn_src = String::with_capacity(B4_PAIRS * 32);
    for i in 0..B4_PAIRS {
        churn_src.push_str(&format!("define(d{i}, first(pair({i}, nil))); "));
    }
    let churn_bc = {
        let forms = read_target_program(file, black_box(&churn_src)).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    let shared = SharedCounters::default();
    for _ in 0..warmup_iters(B4_ITERS) {
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc.clone(), 1024, collector).expect("vm");
        vm.run().expect("churn program halts");
    }
    let cycles_before = shared.cycles.get();
    let swept_before = shared.swept.get();
    let mut b4 = Vec::with_capacity(B4_ITERS);
    for _ in 0..B4_ITERS {
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc.clone(), 1024, collector)
            .expect("tight-budget vm");
        let t = Instant::now();
        vm.run().expect("churn program halts");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        b4.push(elapsed);
    }
    let st = stats(&b4);
    println!(
        "B4 gc-pressure-churn ({} pairs, budget 1024): {} iters, mean {:.3}ms, median {:.3}ms, min {:.3}ms, stdev {:.3}ms, gc-cycles/iter {}, swept/iter {}",
        B4_PAIRS,
        B4_ITERS,
        st.mean,
        st.median,
        st.min,
        st.stdev,
        (shared.cycles.get() - cycles_before) / B4_ITERS as u32,
        (shared.swept.get() - swept_before) / B4_ITERS as u32,
    );

    // B5 driver end-to-end: run_source VM fib(25) — session + pipeline
    // + halt-snapshot included.
    const B5_ITERS: usize = 50;
    const B5_SRC: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(25));";
    for _ in 0..warmup_iters(B5_ITERS) {
        let mut session = kerf::driver::Session::new();
        kerf::driver::run_source(
            &mut session,
            "bench.ktf",
            black_box(B5_SRC),
            kerf::driver::Engine::Vm,
            &[],
        )
        .expect("e2e fib(25)");
    }
    let mut b5 = Vec::with_capacity(B5_ITERS);
    for _ in 0..B5_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.ktf",
            black_box(B5_SRC),
            kerf::driver::Engine::Vm,
            &[],
        )
        .expect("e2e fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b5.push(elapsed);
    }
    line_stats_ms("B5 driver-e2e-fib25 (vm)", B5_ITERS, &stats(&b5));

    // B6 closure creation (the ★1' quantification axis — Stage 2.2,
    // §9.82): the per-creation cost of the `closure` instruction as a
    // function of the capture count (C descriptors) and the defining
    // frame's width (N = n_locals slots), measured on hand-built
    // bytecode so nothing but the creation loop runs. The flat-capture
    // discipline (Stage 2.1) copies exactly C values per creation;
    // the dormant regime it retired cloned the whole N-slot frame.
    // Faces (M creations per run, unrolled `closure; pop` pairs):
    //   B6a: C=1,  N=4    — the narrow reference
    //   B6b: C=1,  N=100  — must track B6a: cost independent of width
    //   B6c: C=25, N=100  — must scale with the capture count
    // Reported as per-creation nanoseconds (median run / M) — the
    // deterministic structural proofs (env size == C, swept == N-1)
    // live in capture_cost_guard_tests.rs; this axis is the wall
    // clock face.
    const B6_ITERS: usize = 200;
    const B6_CREATIONS: usize = 10_000;
    let b6_face = |label: &str, captured: usize, width: u32| {
        let bc = b6_bytecode(captured, width, B6_CREATIONS);
        for _ in 0..warmup_iters(B6_ITERS) {
            let mut vm = Vm::new(bc.clone()).expect("vm");
            vm.run().expect("creation loop halts");
        }
        let mut runs = Vec::with_capacity(B6_ITERS);
        for _ in 0..B6_ITERS {
            let mut vm = Vm::new(bc.clone()).expect("vm");
            let t = Instant::now();
            vm.run().expect("creation loop halts");
            runs.push(t.elapsed().as_secs_f64() * 1e9);
        }
        let st = stats(&runs);
        println!(
            "{label}: {B6_ITERS} runs x {B6_CREATIONS} creations, \
             mean {:.1}ns, median {:.1}ns, min {:.1}ns, stdev {:.1}ns per creation",
            st.mean / B6_CREATIONS as f64,
            st.median / B6_CREATIONS as f64,
            st.min / B6_CREATIONS as f64,
            st.stdev / B6_CREATIONS as f64,
        );
    };
    b6_face("B6a closure-create (captured=1, width=4)", 1, 4);
    b6_face("B6b closure-create (captured=1, width=100)", 1, 100);
    b6_face("B6c closure-create (captured=25, width=100)", 25, 100);

    // B6d closure-invoke (the Stage 3.1 W-3.1 blade's own axis): one
    // closure created up front, then a tight create-nothing loop —
    // LoadLocal + Call + Pop per iteration — so the sample isolates
    // the per-invocation share: arity check, capture-area install,
    // frame push, the minimal body (PushConst+Ret), frame pop. The
    // pre-blade cost here is the O(captured) env copy `invoke` paid
    // per call; the blade replaces it with one refcount bump.
    const B6_INVOCATIONS: usize = 10_000;
    let b6d_face = |label: &str, captured: usize, width: u32| {
        let bc = b6d_bytecode(captured, width, B6_INVOCATIONS);
        for _ in 0..warmup_iters(B6_ITERS) {
            let mut vm = Vm::new(bc.clone()).expect("vm");
            vm.run().expect("invoke loop halts");
        }
        let mut runs = Vec::with_capacity(B6_ITERS);
        for _ in 0..B6_ITERS {
            let mut vm = Vm::new(bc.clone()).expect("vm");
            let t = Instant::now();
            vm.run().expect("invoke loop halts");
            runs.push(t.elapsed().as_secs_f64() * 1e9);
        }
        let st = stats(&runs);
        println!(
            "{label}: {B6_ITERS} runs x {B6_INVOCATIONS} invocations, \
             mean {:.1}ns, median {:.1}ns, min {:.1}ns, stdev {:.1}ns per invocation",
            st.mean / B6_INVOCATIONS as f64,
            st.median / B6_INVOCATIONS as f64,
            st.min / B6_INVOCATIONS as f64,
            st.stdev / B6_INVOCATIONS as f64,
        );
    };
    b6d_face("B6d closure-invoke (captured=25, width=100)", 25, 100);

    // B7 composed-chain cost (the 2.4 closure measurement face,
    // §9.88): the FULL self-hosted pipeline — the seed lexer + reader
    // (junction 1), the seed expander (junction 2), the seed compiler
    // (junction 3), dual engines at every junction — over the same
    // FIB anchor as B1. The B7/B1 median ratio is the self-hosting
    // cost multiplier: the Stage 2a cost story's baseline number
    // (2.5's fixpoint driver and 2.6's build-orchestration
    // evaluation both consume it; the corpus-sweep policy needs the
    // per-file cost). Fail-closed: a benchmark over a drifting
    // chain is meaningless — every run must report `matched` (the
    // parity is the axis's precondition, never its output).
    const B7_ITERS: usize = 9;
    for _ in 0..warmup_iters(B7_ITERS) {
        let report = composed_target_read_chain_parity("bench-fib", black_box(FIB));
        assert!(
            report.matched,
            "B7 warmup: the composed chain drifted: {}",
            report.failure_line()
        );
    }
    let mut b7 = Vec::with_capacity(B7_ITERS);
    for _ in 0..B7_ITERS {
        let t = Instant::now();
        let report = composed_target_read_chain_parity("bench-fib", black_box(FIB));
        let matched = report.matched;
        b7.push(t.elapsed().as_secs_f64() * 1e3);
        black_box(matched);
        assert!(
            matched,
            "B7: the composed chain drifted: {}",
            report.failure_line()
        );
    }
    line_stats_ms(
        "B7 composed-chain-fib (full seed-skin pipeline, dual engines)",
        B7_ITERS,
        &stats(&b7),
    );
    let b1_median_us = stats(&b1).median;
    let b7_median_us = stats(&b7).median * 1e3;
    println!(
        "B7 self-hosting multiplier vs B1 median: {:.0}x",
        b7_median_us / b1_median_us
    );

    // B8 fixpoint-driver cost (the 2.5 closure measurement face,
    // §9.90): the WHOLE fixpoint proof — C(S) (the seed-skin compiler
    // compiling its own structural source, dual engine), C(C(S))
    // (the self-applied assembly, VM-only bracket), and the executed
    // self-compiled compiler reproducing its own compilation — the
    // wall-clock cost of SOP §21.3 (2) itself. The 2.6
    // build-orchestration evaluation consumes this number as its
    // bootstrap-verification budget floor: an orchestrated build
    // re-runs this proof, so its cost bounds the verification face
    // of any seed-skin-side orchestration. Fail-closed: a benchmark over
    // a broken fixpoint is meaningless — every run must come back
    // with `fixpoint_holds` (the equality is the axis's
    // precondition, never its output; the driver's `Err` channel
    // carries the classified drift reason into the panic).
    const B8_ITERS: usize = 7;
    for _ in 0..warmup_iters(B8_ITERS) {
        let report = kerf::driver::fixpoint_selfhost_compiler_target()
            .expect("B8 warmup: the fixpoint driver runs to a verdict");
        assert!(
            report.fixpoint_holds,
            "B8 warmup: the fixpoint drifted: C(C(S)) != C(S)"
        );
    }
    let mut b8 = Vec::with_capacity(B8_ITERS);
    for _ in 0..B8_ITERS {
        let t = Instant::now();
        let report = kerf::driver::fixpoint_selfhost_compiler_target()
            .expect("B8: the fixpoint driver runs to a verdict");
        let holds = report.fixpoint_holds;
        b8.push(t.elapsed().as_secs_f64() * 1e3);
        black_box(holds);
        assert!(holds, "B8: the fixpoint drifted: C(C(S)) != C(S)");
    }
    line_stats_ms(
        "B8 fixpoint-driver (C(S) + C(C(S)) + VM exec)",
        B8_ITERS,
        &stats(&b8),
    );
    let b8_median_ms = stats(&b8).median;
    println!(
        "B8 fixpoint-proof cost vs B7 composed-chain median: {:.0}x",
        b8_median_ms / stats(&b7).median
    );

    // B10 target-skin fixpoint-driver cost (the switch-window step 4
    // closure measurement face, §9.97): the WHOLE target fixpoint
    // proof — C_t(S') through the production bridge (the NEW reader
    // on every read), C_t(C_t(S')) (the target self-applied
    // assembly, VM-only bracket), and the executed target compiler
    // reproducing its own compilation. The <2x question the plan's
    // risk register carries (trap 3: the seed chain stays untouched,
    // so the seed-skin axes B1-B8 must not move — this axis measures
    // the BRIDGE's own cost, the number the step-5 S-expr production
    // face removal evaluation consumes). Fail-closed: every run must
    // come back with `fixpoint_holds` (the equality is the axis's
    // precondition, never its output).
    const B10_ITERS: usize = 5;
    for _ in 0..warmup_iters(B10_ITERS) {
        let report = kerf::driver::fixpoint_selfhost_compiler_target()
            .expect("B10 warmup: the target fixpoint driver runs to a verdict");
        assert!(
            report.fixpoint_holds,
            "B10 warmup: the target fixpoint drifted: C_t(C_t(S')) != C_t(S')"
        );
    }
    let mut b10 = Vec::with_capacity(B10_ITERS);
    for _ in 0..B10_ITERS {
        let t = Instant::now();
        let report = kerf::driver::fixpoint_selfhost_compiler_target()
            .expect("B10: the target fixpoint driver runs to a verdict");
        let holds = report.fixpoint_holds;
        b10.push(t.elapsed().as_secs_f64() * 1e3);
        black_box(holds);
        assert!(
            holds,
            "B10: the target fixpoint drifted: C_t(C_t(S')) != C_t(S')"
        );
    }
    line_stats_ms(
        "B10 target-fixpoint-driver (bridge + C_t(S') + C_t(C_t(S')) + VM exec)",
        B10_ITERS,
        &stats(&b10),
    );
    println!(
        "B10 target-skin cost vs B8 seed-skin median: {:.2}x",
        stats(&b10).median / b8_median_ms
    );
}

/// Hand-built bytecode for the B6 axis: an entry proto of `width`
/// local slots (all nil — the frame width is the cost variable, the
/// slot values are not) runs `creations` unrolled `closure 1; pop`
/// pairs; proto 1 captures `captured` slots (Local(0..C)) and returns
/// a constant. Nothing else executes — the measured loop is the
/// creation instruction alone.
fn b6_bytecode(captured: usize, width: u32, creations: usize) -> kerf::compiler::Bytecode {
    use kerf::compiler::{Bytecode, CaptureSource, FuncProto, Instr, Opcode};
    use kerf::core::LiteralValue;
    use kerf::span::{ByteOffset, ExpansionId, Span};

    let span = Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("bench fixture span");
    let mut entry_code = Vec::with_capacity(creations * 2 + 2);
    for _ in 0..creations {
        entry_code.push(Instr::with_a(Opcode::Closure, 1));
        entry_code.push(Instr::new(Opcode::Pop));
    }
    entry_code.push(Instr::with_a(Opcode::PushConst, 0));
    entry_code.push(Instr::new(Opcode::Halt));
    let mut entry = FuncProto::new(None, 0, width);
    entry.code = entry_code;
    entry.debug_info = vec![span; entry.code.len()];

    let mut callee_code = Vec::new();
    for k in 0..captured as u32 {
        callee_code.push(Instr::with_a(Opcode::LoadCaptured, k));
        callee_code.push(Instr::new(Opcode::Pop));
    }
    callee_code.push(Instr::with_a(Opcode::PushConst, 0));
    callee_code.push(Instr::new(Opcode::Ret));
    let mut callee = FuncProto::new(None, 0, 0);
    callee.captures = (0..captured as u32).map(CaptureSource::Local).collect();
    callee.code = callee_code;
    callee.debug_info = vec![span; callee.code.len()];

    let mut bc = Bytecode::default();
    bc.consts.push(LiteralValue::Int(0));
    bc.funcs.push(entry);
    bc.funcs.push(callee);
    bc.verify().expect("bench bytecode verifies");
    bc
}

/// Bytecode for the B6d invoke-share face: ONE closure created up
/// front (proto 1, capturing `captured` slots from the entry frame)
/// and stashed in local 0; then `invocations` unrolled
/// `load-local 0; call 0; pop` triples. Proto 1's body is the
/// minimal `push-const 0; ret` — the sample isolates the per-call
/// share (arity check, capture-area install, frame push/pop), not
/// body work. The entry proto's width covers the descriptor table
/// (`Local(0..captured)` indexes the entry frame, so `width` must
/// exceed the capture count — the same discipline as `b6_bytecode`).
fn b6d_bytecode(captured: usize, width: u32, invocations: usize) -> kerf::compiler::Bytecode {
    use kerf::compiler::{Bytecode, CaptureSource, FuncProto, Instr, Opcode};
    use kerf::core::LiteralValue;
    use kerf::span::{ByteOffset, ExpansionId, Span};

    let span = Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("bench fixture span");
    let mut entry_code = Vec::with_capacity(invocations * 3 + 4);
    entry_code.push(Instr::with_a(Opcode::Closure, 1));
    entry_code.push(Instr::with_a(Opcode::StoreLocal, 0));
    for _ in 0..invocations {
        entry_code.push(Instr::with_a(Opcode::LoadLocal, 0));
        entry_code.push(Instr::with_a(Opcode::Call, 0));
        entry_code.push(Instr::new(Opcode::Pop));
    }
    entry_code.push(Instr::with_a(Opcode::PushConst, 0));
    entry_code.push(Instr::new(Opcode::Halt));
    let mut entry = FuncProto::new(None, 0, width);
    entry.code = entry_code;
    entry.debug_info = vec![span; entry.code.len()];

    let mut callee = FuncProto::new(None, 0, 0);
    callee.captures = (0..captured as u32).map(CaptureSource::Local).collect();
    callee.code = vec![Instr::with_a(Opcode::PushConst, 0), Instr::new(Opcode::Ret)];
    callee.debug_info = vec![span; callee.code.len()];

    let mut bc = Bytecode::default();
    bc.consts.push(LiteralValue::Int(0));
    bc.funcs.push(entry);
    bc.funcs.push(callee);
    bc.verify().expect("bench bytecode verifies");
    bc
}

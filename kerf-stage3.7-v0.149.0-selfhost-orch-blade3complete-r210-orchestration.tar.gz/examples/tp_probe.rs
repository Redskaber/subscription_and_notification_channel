//! Target-parser twin probe (W-TGT-READ-TWIN r138 debug face —
//! temporary diagnostic, never part of the parity comparison).
use kerf_driver::{
    target_parser_assembly_probe, target_parser_oracle_dump, target_parser_parity,
    target_parser_twin_dump,
};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("usage: tp_probe <case-name> | --raw <source>");
        return;
    }
    if args[0] == "--raw" && args.len() > 1 {
        run("raw", &args[1]);
        return;
    }
    let name = &args[0];
    let case = kerf_driver::TARGET_PARSER_TWIN_CASES
        .iter()
        .find(|(n, _)| n == name)
        .unwrap_or_else(|| panic!("unknown case {name}"));
    run(name, case.1);
}

fn run(name: &str, source: &str) {
    println!("=== case [{name}] source: {source:?}");
    match target_parser_oracle_dump(source) {
        Ok(dump) => println!("--- oracle    : {dump}"),
        Err(err) => println!("--- oracle ERR: {}", kerf_driver::error_parity_key(&err)),
    }
    match target_parser_twin_dump(source) {
        Ok(vm) => {
            println!("--- vm  axis: {vm}");
        }
        Err(err) => {
            println!("--- twin dump ERR: {err}");
            localize(&err, source);
        }
    }
    match target_parser_parity(name, source) {
        Ok(()) => println!("--- parity: OK"),
        Err(err) => println!("--- parity: {err}"),
    }
}

/// Render the crash site's assembly line when the failure message
/// carries a byte span (file#0:START..END against the assembled
/// twin text).
fn localize(err: &str, source: &str) {
    let Some(at) = err.find(" at file#") else {
        return;
    };
    let rest = &err[at + " at file#".len()..];
    let Some(colon) = rest.find(':') else { return };
    let rest = &rest[colon + 1..];
    let Some(dotdot) = rest.find("..") else {
        return;
    };
    let Ok(start) = rest[..dotdot].parse::<usize>() else {
        return;
    };
    let asm = target_parser_assembly_probe(source);
    let line = asm[..start.min(asm.len())].matches('\n').count() + 1;
    let text = asm.lines().nth(line - 1).unwrap_or("<oob>");
    println!("    crash site: assembly line {line}: {text}");
}

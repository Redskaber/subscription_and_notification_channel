# scripts/ — 环境/构建/部署脚本（SOP §3.4）

按 `<domain>/` 子目录组织；自定义安装/配置脚本归档于此并同步 docs/scripts/。

## testing/

- `replay-poisoned-ambient.sh` — v0.73.0 工具链配对事件重放（r110）：在被污染 ambient 环境变量下运行 c_backend e2e 套件，断言双边界 scrub 防护在位（18:0:2 全绿为通过口径）。文档：`docs/scripts/replay-poisoned-ambient.md`。

- `testing/blade5_modern2_expander_transform.py` — the r201 blade-5 surgery
  script (W-SELFHOST-MODERN-2): the expander/macro shadow-pair co-modernization
  onto the Error vocabulary. Three modes (`--survey` / `--apply` / `--verify`),
  full anchor assertions (any mismatch aborts before writing), two-pass apply
  (call sites first, then the iterative leaf-first guard dissolve — the nested
  ex_expand entry guard spans ~1,950 lines with 27 inner guards), and the
  built-in width/non-ASCII/paren/brace guards. The double-fork daemon pattern
  for the K159-class single-family runs rode /tmp/daemon_t2.py (the r200 escape
  form's first reprise — /tmp/daemon_t2.log carries the run).

- `testing/blade6_modern2_parser_transform.py` — the r203 blade-6
  surgery script (W-SELFHOST-MODERN-2): the parser twin's
  parse-rejection family onto the Error vocabulary plus the give
  protocol's dead "done"-head retirement. Three modes (`--survey` /
  `--apply` / `--verify`), full anchor assertions (any mismatch
  aborts before writing), text-span raise conversion (the
  assignment prefix swaps, the statement's `;` becomes the raise's
  closing paren — single-line, multi-line, and match-arm forms in
  one pass), the iterative leaf-first guard dissolve for the 100
  post-error guards, the done-head retire (21 constructions, the
  inline and multi-line forms), the frozen width/non-ASCII/paren
  guards, and the comment-aware terminal invariants (zero tp_err
  code references, zero done-tag constructions, the byte-frozen
  result tail).

- `testing/daemon_regen.py` — the r203 general daemon form (the
  r200/r201 double-fork escape, productized): run any long cargo
  test as a fully-detached daemon child that survives the sandbox's
  descendant reaping; the parent prints and exits, the caller polls
  the log. Usage: `daemon_regen.py <log-path> [test-filter]`.

#!/usr/bin/env python3
# Blade-4 surgical transformer: cp_ewalk two-level if-chain -> match.
# Mechanical indent-preserving rewrite (M34/M35 of the window doc §12):
#   outer: 7 synthetic-mode arms + `_` real-tree arm
#   inner: 17 real-tree tag arms + `_` bad-node arm
# Bodies keep their expressions verbatim; only arm headers and
# indentation change (outer bodies +4, inner bodies +8).

import re
import sys

PATH = 'selfhost/v1/compiler.ktf'

with open(PATH) as f:
    all_lines = f.readlines()

start = None
for i, l in enumerate(all_lines):
    if l.rstrip('\n') == 'fn cp_ewalk(t, tail) {':
        start = i
        break
if start is None:
    sys.exit('signature line not found')

end = None
for j in range(start + 1, len(all_lines)):
    if all_lines[j] == '}\n':
        end = j
        break
if end is None:
    sys.exit('function close not found')

fn_lines = all_lines[start:end + 1]
out = ['fn cp_ewalk(t, tail: bool) {\n']

i = 1
n = len(fn_lines)
mode = 'pre'

outer_else_if = re.compile(r'^        \} else if eq\(tag, "([a-z]+)"\) \{$')
inner_else_if = re.compile(r'^                \} else if eq\(tag, "([a-z]+)"\) \{$')
inner_let_v = re.compile(r'^                let v = if eq\(tag, "([a-z]+)"\) \{$')

while i < n:
    line = fn_lines[i]
    raw = line.rstrip('\n')
    stripped = raw.strip()
    indent = len(raw) - len(raw.lstrip())

    if mode == 'pre':
        if raw == '        if eq(tag, "awalk") {':
            out.append('        match tag {\n')
            out.append('            "awalk" => {\n')
            mode = 'outer_body'
        else:
            out.append(line)
    elif mode == 'outer_body':
        m = outer_else_if.match(raw)
        if m:
            out.append('            },\n')
            out.append('            "%s" => {\n' % m.group(1))
        elif raw == '        } else {':
            out.append('            },\n')
            out.append('            _ => {\n')
            mode = 'real'
        else:
            out.append('    ' + line if stripped else line)
    elif mode == 'real':
        m = inner_let_v.match(raw)
        if m:
            out.append('                    let v = match tag {\n')
            out.append('                        "%s" => {\n' % m.group(1))
            mode = 'inner_body'
        else:
            out.append('    ' + line if stripped else line)
    elif mode == 'inner_body':
        m = inner_else_if.match(raw)
        if m:
            out.append('                        },\n')
            out.append('                        "%s" => {\n' % m.group(1))
        elif raw == '                } else {':
            out.append('                        },\n')
            out.append('                        _ => {\n')
        elif raw == '                };':
            out.append('                        },\n')
            out.append('                    };\n')
            mode = 'epilogue'
        else:
            out.append('        ' + line if stripped else line)
    elif mode == 'epilogue':
        if stripped == '}' and indent == 12:
            out.append('                }\n')
        elif stripped == '}' and indent == 8:
            out.append('            },\n')
            out.append('        }\n')
        elif indent == 16:
            out.append('    ' + line)
        else:
            out.append(line)
    i += 1

all_lines[start:end + 1] = out
with open(PATH, 'w') as f:
    f.writelines(all_lines)
print('transformed: %d source lines -> %d lines' % (len(fn_lines), len(out)))

#!/usr/bin/env python3
# Blade-5 fidelity check: expander.ktf old vs new, three functions
# (ex_expand M41/M42, ex_decl M43). Body runs (lines between
# structural markers) must be char-identical after whitespace
# stripping; structural markers must pair per the if-chain ->
# match conversion rules. Width reflows only add whitespace, so
# runs may differ in line count but not in content.
#
# Both classifiers are region-state machines: structural lines are
# only recognized at the exact indent the current region expects,
# so same-indent lines inside deeper bodies stay BODY.

import re
import sys

OLD = '/tmp/expander.ktf.pre-blade5'
NEW = 'selfhost/v1/expander.ktf'

with open(OLD) as f:
    old_all = f.readlines()
with open(NEW) as f:
    new_all = f.readlines()


def extract(all_lines, sig_prefix):
    start = next(i for i, l in enumerate(all_lines)
                 if l.rstrip('\n').startswith(sig_prefix))
    end = next(j for j in range(start + 1, len(all_lines))
               if all_lines[j] == '}\n')
    return [l.rstrip('\n') for l in all_lines[start:end + 1]]


i_first = re.compile(r'^ {24}if eq\(h, "quote"\) \{$')
i_arm24 = re.compile(r'^ {24}\} else if eq\(h, "([a-z!-]+)"\) \{$')
i_else24 = '                        } else {'
i_close24 = '                        }'


def classify_old_ex_expand(lines):
    out = []
    region = 'OUTER'
    for l in lines:
        ind = len(l) - len(l.lstrip())
        s = l.strip()
        if l == 'fn ex_expand(t) {':
            out.append(('SIG', None))
        elif region == 'OUTER':
            if l == '        if eq(first(t), "mapx") {':
                out.append(('OPEN', 'mapx'))
            elif re.match(r'^        \} else if eq\(first\(t\), "([a-z]+)"\) \{$', l):
                out.append(('ARM', re.match(r'^        \} else if eq\(first\(t\), "([a-z]+)"\) \{$', l).group(1)))
            elif l == '        } else if ex_depth >= ex_limit {':
                out.append(('GUARD', None))
            elif l == '        } else {':
                out.append(('ELSE', None))
                region = 'REAL'
            elif l == '    } else {':
                out.append(('ERR', None))
            elif s == '}' and ind == 8:
                out.append(('CLOSE', None))
            else:
                out.append(('BODY', s))
        elif region == 'REAL':
            if i_first.match(l):
                out.append(('IOPEN', 'quote'))
                region = 'INNER'
            elif l == '    } else {':
                out.append(('ERR', None))
            elif s == '}' and ind == 8:
                out.append(('CLOSE', None))
            else:
                out.append(('BODY', s))
        elif region == 'INNER':
            if i_arm24.match(l):
                out.append(('IARM', i_arm24.match(l).group(1)))
            elif l == i_else24:
                out.append(('IELSE', None))
            elif l == i_close24:
                out.append(('ICLOSE', None))
                region = 'REAL2'
            else:
                out.append(('BODY', s))
        else:  # REAL2
            if l == '    } else {':
                out.append(('ERR', None))
            elif s == '}' and ind == 8:
                out.append(('CLOSE', None))
            else:
                out.append(('BODY', s))
    return out


def classify_new_ex_expand(lines):
    out = []
    region = 'PRE'
    ichain = None  # indent of the inner match when found
    for l in lines:
        s = l.strip()
        ind = len(l) - len(l.lstrip())
        if l == 'fn ex_expand(t) {':
            out.append(('SIG', None))
        elif region == 'PRE':
            if l == '        let tag = first(t);':
                out.append(('LET', None))
            elif l == '        match tag {':
                out.append(('MATCH', None))
                region = 'ARMS'
            else:
                out.append(('BODY', s))
        elif region == 'ARMS':
            if ind == 12 and re.match(r'^"([a-z]+)" => \{$', s):
                out.append(('ARM', re.match(r'^"([a-z]+)" => \{$', s).group(1)))
            elif ind == 12 and s == '},':
                out.append(('ARMC', None))
            elif ind == 12 and s == '_ => {':
                out.append(('WILD', None))
                region = 'WILD'
            else:
                out.append(('BODY', s))
        elif region == 'WILD':
            if ind == 16 and s == 'if ex_depth >= ex_limit {':
                out.append(('GUARD', None))
            elif ind == 16 and s == '} else {':
                out.append(('ELSE', None))
                region = 'REAL'
            elif ind == 16 and s == '}':
                out.append(('GCLOSE', None))
                region = 'WILDCLOSE'
            else:
                out.append(('BODY', s))
        elif region == 'WILDCLOSE':
            if ind == 12 and s == '},':
                out.append(('ARMC', None))
                region = 'MCLOSEWAIT'
            else:
                out.append(('BODY', s))
        elif region == 'MCLOSEWAIT':
            if ind == 8 and s == '}':
                out.append(('MCLOSE', None))
                region = 'POST'
            else:
                out.append(('BODY', s))
        elif region == 'REAL':
            if re.match(r'^ *match h \{$', l):
                ichain = ind
                out.append(('IMATCH', None))
                region = 'IARMS'
            elif l == '    } else {':
                out.append(('ERR', None))
            elif ind == 16 and s == '}':
                # guard-else close inside the wild arm, after the
                # inner chain completed (REAL2 content folded here)
                out.append(('GCLOSE', None))
                region = 'WILDCLOSE'
            else:
                out.append(('BODY', s))
        elif region == 'IARMS':
            if ind == ichain + 4 and re.match(r'^"([a-z!-]+)" => \{$', s):
                out.append(('IARM', re.match(r'^"([a-z!-]+)" => \{$', s).group(1)))
            elif ind == ichain + 4 and s == '},':
                out.append(('IARMC', None))
            elif ind == ichain + 4 and s == '_ => {':
                out.append(('IWILD', None))
            elif ind == ichain and s == '}':
                out.append(('IMCLOSE', None))
                region = 'REAL'
            else:
                out.append(('BODY', s))
        else:  # POST
            if l == '    } else {':
                out.append(('ERR', None))
            else:
                out.append(('BODY', s))
    return out


d_first = re.compile(r'^ {24}if eq\(h, "define"\) \{$')
d_arm = re.compile(r'^ {24}\} else if eq\(h, "([a-z-]+)"\) \{$')


def classify_old_ex_decl(lines):
    out = []
    region = 'PRE'
    for l in lines:
        s = l.strip()
        if l == 'fn ex_decl(x) {':
            out.append(('SIG', None))
        elif region == 'PRE':
            if d_first.match(l):
                out.append(('IOPEN', 'define'))
                region = 'CHAIN'
            else:
                out.append(('BODY', s))
        elif region == 'CHAIN':
            if d_arm.match(l):
                out.append(('IARM', d_arm.match(l).group(1)))
            elif l == i_else24:
                out.append(('IELSE', None))
            elif l == i_close24:
                out.append(('ICLOSE', None))
                region = 'POST'
            else:
                out.append(('BODY', s))
        else:
            out.append(('BODY', s))
    return out


def classify_new_ex_decl(lines):
    out = []
    region = 'PRE'
    for l in lines:
        s = l.strip()
        ind = len(l) - len(l.lstrip())
        if l == 'fn ex_decl(x) {':
            out.append(('SIG', None))
        elif region == 'PRE':
            if ind == 24 and s == 'match h {':
                out.append(('IMATCH', None))
                region = 'IARMS'
            else:
                out.append(('BODY', s))
        elif region == 'IARMS':
            if ind == 28 and re.match(r'^"([a-z-]+)" => \{$', s):
                out.append(('IARM', re.match(r'^"([a-z-]+)" => \{$', s).group(1)))
            elif ind == 28 and s == '},':
                out.append(('IARMC', None))
            elif ind == 28 and s == '_ => {':
                out.append(('IWILD', None))
            elif ind == 24 and s == '}':
                out.append(('IMCLOSE', None))
                region = 'POST'
            else:
                out.append(('BODY', s))
        else:
            out.append(('BODY', s))
    return out


def toks(items):
    joined = ' '.join(it[1] for it in items if it[1])
    return re.sub(r'\s+', '', joined)


def compare(name, oc, nc):
    oi, ni = 0, 0
    while oi < len(oc) or ni < len(nc):
        o_next = oi
        while o_next < len(oc) and oc[o_next][0] == 'BODY':
            o_next += 1
        n_next = ni
        while n_next < len(nc) and nc[n_next][0] == 'BODY':
            n_next += 1
        a = toks(oc[oi:o_next])
        b = toks(nc[ni:n_next])
        if a != b:
            k = 0
            while k < min(len(a), len(b)) and a[k] == b[k]:
                k += 1
            print('%s BODY-DIFF old@%d new@%d at char %d (%d vs %d)' % (
                name, oi, ni, k, len(a), len(b)))
            return False
        if o_next >= len(oc) and n_next >= len(nc):
            break
        ok = oc[o_next] if o_next < len(oc) else ('END', None)
        nk = nc[n_next] if n_next < len(nc) else ('END', None)
        paired = False
        if ok[0] in ('OPEN', 'IOPEN'):
            want = {'OPEN': ('LET', 'MATCH', 'ARM'), 'IOPEN': ('IMATCH', 'IARM')}[ok[0]]
            got = tuple(nc[n_next + k][0] for k in range(len(want)))
            if got == want and nc[n_next + len(want) - 1][1] == ok[1]:
                o_next += 1
                n_next += len(want)
                paired = True
        elif ok[0] in ('ARM', 'IARM'):
            if nk[0] in ('ARMC', 'IARMC') and n_next + 1 < len(nc) and \
                    nc[n_next + 1] == (ok[0], ok[1]):
                o_next += 1
                n_next += 2
                paired = True
        elif ok[0] == 'GUARD':
            if nk[0] == 'ARMC' and n_next + 2 < len(nc) and \
                    nc[n_next + 1][0] == 'WILD' and nc[n_next + 2][0] == 'GUARD':
                o_next += 1
                n_next += 3
                paired = True
        elif ok[0] == 'ELSE':
            if nk[0] == 'ELSE':
                o_next += 1
                n_next += 1
                paired = True
        elif ok[0] == 'CLOSE':
            if nk[0] == 'GCLOSE' and n_next + 2 < len(nc) and \
                    nc[n_next + 1][0] == 'ARMC' and nc[n_next + 2][0] == 'MCLOSE':
                o_next += 1
                n_next += 3
                paired = True
        elif ok[0] == 'IELSE':
            if nk[0] == 'IARMC' and n_next + 1 < len(nc) and \
                    nc[n_next + 1][0] == 'IWILD':
                o_next += 1
                n_next += 2
                paired = True
        elif ok[0] == 'ICLOSE':
            if nk[0] == 'IARMC' and n_next + 1 < len(nc) and \
                    nc[n_next + 1][0] == 'IMCLOSE':
                o_next += 1
                n_next += 2
                paired = True
        elif ok[0] == nk[0] and ok[1] == nk[1]:
            o_next += 1
            n_next += 1
            paired = True
        if not paired:
            print('%s STRUCT-MISMATCH old@%d %s new@%d %s' % (name, o_next, ok, n_next, nk))
            return False
        oi, ni = o_next, n_next
    return True


ok1 = compare('ex_expand', classify_old_ex_expand(extract(old_all, 'fn ex_expand(')),
              classify_new_ex_expand(extract(new_all, 'fn ex_expand(')))
ok2 = compare('ex_decl', classify_old_ex_decl(extract(old_all, 'fn ex_decl(')),
              classify_new_ex_decl(extract(new_all, 'fn ex_decl(')))

if ok1 and ok2:
    print('FIDELITY OK (token-run level): every body run char-identical,')
    print('every structural pair aligned (ex_expand M41/M42 + ex_decl M43)')
    sys.exit(0)
sys.exit(1)

#!/usr/bin/env python3
"""blade6_transform.py — the blade 6 mechanical if-chain -> match rewriter.

Region-aware, single-scrutinee chains only (window file section 14,
M49-M65). Mixed-guard chains are reported as residuals for hand
surgery (the r178/r179 double-script lineage: a transformer plus a
fidelity verifier, both archived under scripts/testing/ per R4).

Usage:
    python3 scripts/testing/blade6_transform.py --file selfhost/v1/infer.ktf
    python3 scripts/testing/blade6_transform.py --file selfhost/v1/target-parser.ktf [--dry]

Transformation laws (section 14.1 / the blade 1-5 precedents):
  1. A convertible chain compares THE SAME scrutinee (a variable, a
     first(var) accessor, or an int var in the tp_bin_ops form)
     against literals on every branch. One-literal chains convert
     only when the scrutinee is the registered mode/phase parameter
     of a MODE_MACHINES function.
  2. If the scrutinee variable was introduced by `let V = acc;`
     immediately above the chain and V is not referenced inside any
     arm body, the let line is removed and the match scrutinee
     becomes the accessor (single-eval pure accessor, M21).
  3. Arm bodies re-indent +4 (pure whitespace). Single-expression
     bodies emit as one-line arms (`"items" => { tp_step_items(f) },`);
     multi-statement bodies emit as blocks with the trailing comma
     (r175 finding 1 + the r177 arm-body-block law).
  4. The final else becomes the `_` arm verbatim (receiving domain
     unchanged, first-match isomorphic). A chain with a mixed arm is
     skipped wholesale and reported as a residual for hand surgery.
"""

from __future__ import annotations

import argparse
import json
import re
import sys

# {fn: mode/phase var} — one-literal + else chains convert only on
# this parameter (the walk/mode machine family, M51/M60).
MODE_MACHINES = {
    "ti_resolve_walk": "mode", "ti_occurs_walk": "mode",
    "ti_ann_walk": "mode", "ti_collect_walk": "mode",
    "ti_var_walk": "mode", "ti_varocc_walk": "mode",
    "ti_subst_walk": "mode", "ti_type_eq": "mode",
    "ti_tarjan_step": "mode", "ti_resolve_spec": "mode",
    "tp_step_fn_decl": "phase", "tp_give_fn_decl": "phase",
    "tp_give_let_stmt": "phase",
    "tp_give_handle_arms": "phase", "tp_give_type_drop": "phase",
    "tp_ha": "phase", "tp_ma": "phase",
    "tp_step_let_stmt": "phase", "tp_step_type_drop": "phase",
    "tp_step_params": "phase",
    "tp_step_extern_item": "phase", "tp_give_extern_decl": "phase",
}

# Hand-surgery only (mixed-guard cores, M50/M55/M61).
MANUAL_SITES = {
    "ti_unify_step",       # the W-machine core, M50
    "ti_is_numeric",       # mixed t domain, M55
    "tp_step_datum",       # mixed kind predicates, M61
}

# Int-literal chains (M27 int-arm form).
INT_CHAINS = {"tp_bin_ops": "level"}

LIT = r'[\w!+/*<>=.?%-]+'
RE_EQ = re.compile(r'^(\s*)if eq\((\w+), "(' + LIT + r')"\) \{$')
RE_ELSE_EQ = re.compile(r'^\s*\} else if eq\((\w+), "(' + LIT + r')"\) \{$')
RE_EQ_FIRST = re.compile(r'^(\s*)if eq\((first\(\w+\)), "(' + LIT + r')"\) \{$')
RE_ELSE_EQ_FIRST = re.compile(
    r'^\s*\} else if eq\((first\(\w+\)), "(' + LIT + r')"\) \{$')
RE_EQ_SL = re.compile(r'^(\s*)if eq\((\w+), "(' + LIT + r')"\) \{ (.+) \}$')
RE_ELSEIF_SL = re.compile(r'^\s*else if eq\((\w+), "(' + LIT + r')"\) \{ (.+) \}$')
RE_ELSE = re.compile(r'^\s*\} else \{$')
RE_ELSE_SL = re.compile(r'^\s*else \{ (.+) \}$')
RE_IF_ANY = re.compile(r'^(\s*)if [^e].*\{$')
RE_IF_EQLIKE = re.compile(r'^(\s*)if (eq\(|[\w.]+\()')
RE_INT = re.compile(r'^(\s*)if (\w+) == (\d+) \{$')
RE_ELSE_INT = re.compile(r'^\s*\} else if (\w+) == (\d+) \{$')
RE_LET = re.compile(r'^(\s*)let (\w+) = ([^;]+);$')
RE_FN = re.compile(r'^fn (\w+)\(([^)]*)\) \{$')
RE_FN_RET = re.compile(r'^fn (\w+)\(([^)]*)\) -> (\w+) \{$')


def find_fn_bounds(lines):
    """Yield (name, header_idx, body_start, body_end) per top-level fn;
    body_end is the index of the fn's closing brace line."""
    out = []
    i = 0
    n = len(lines)
    while i < n:
        m = RE_FN.match(lines[i]) or RE_FN_RET.match(lines[i])
        if m:
            name = m.group(1)
            j = i + 1
            while j < n and lines[j] != "}":
                j += 1
            out.append((name, i, i + 1, j))
            i = j + 1
        else:
            i += 1
    return out


def parse_chain(lines, start, int_var=None):
    """Parse an if-chain starting at lines[start]. Returns None when
    the chain is not convertible, else a dict with arms/else/end."""
    line = lines[start]
    m_int = RE_INT.match(line) if int_var else None
    m_first = RE_EQ_FIRST.match(line)
    m_sl = RE_EQ_SL.match(line)
    is_int = False
    sl = False
    if m_int:
        scrut = m_int.group(2)
        first_lit = m_int.group(3)
        is_int = True
        arm_re = RE_ELSE_INT
    elif m_first:
        scrut = m_first.group(2)
        first_lit = m_first.group(3)
        arm_re = RE_ELSE_EQ_FIRST
    elif m_sl:
        scrut = m_sl.group(2)
        first_lit = m_sl.group(3)
        arm_re = RE_ELSEIF_SL
        sl = True
    else:
        m = RE_EQ.match(line)
        if not m:
            return None
        scrut = m.group(2)
        first_lit = m.group(3)
        arm_re = RE_ELSE_EQ
    n = len(lines)

    if sl:
        # single-line arms, bare `else if` junctions (name tables)
        arms = [(first_lit, [m_sl.group(4)])]
        idx = start + 1
        while idx < n:
            l2 = lines[idx]
            m2 = RE_ELSEIF_SL.match(l2)
            if m2 and m2.group(1) == scrut:
                arms.append((m2.group(2), [m2.group(3)]))
                idx += 1
                continue
            m3 = RE_ELSE_SL.match(l2)
            if m3:
                return {
                    "scrut": scrut, "arms": arms,
                    "else_body": [m3.group(1)], "end": idx,
                    "is_int": False,
                }
            if RE_ELSE.match(l2):
                idx += 1
                body_start = idx
                d = 1
                idx2 = idx
                while idx2 < n:
                    l3 = lines[idx2]
                    d += net_braces(l3)
                    if d == 0:
                        break
                    idx2 += 1
                return {
                    "scrut": scrut, "arms": arms,
                    "else_body": lines[body_start:idx2], "end": idx2,
                    "is_int": False,
                }
            return None
        return None

    if int_var and not m_int:
        return None

    # multi-line arm bodies, `} else if` junctions
    arms = []
    idx = start + 1
    depth = 1
    body_start = idx
    cur_lit = first_lit
    while idx < n:
        line2 = lines[idx]
        if depth == 1 and arm_re.match(line2):
            m2 = arm_re.match(line2)
            if m2.group(1) != scrut:
                return None
            arms.append((cur_lit, lines[body_start:idx]))
            cur_lit = m2.group(2)
            idx += 1
            body_start = idx
            continue
        if depth == 1 and RE_ELSE.match(line2):
            arms.append((cur_lit, lines[body_start:idx]))
            idx += 1
            body_start = idx
            d = 1
            idx2 = idx
            while idx2 < n:
                l3 = lines[idx2]
                d += net_braces(l3)
                if d == 0:
                    break
                idx2 += 1
            return {
                "scrut": scrut, "arms": arms,
                "else_body": lines[body_start:idx2], "end": idx2,
                "is_int": is_int,
            }
        depth += net_braces(line2)
        if depth <= 0:
            arms.append((cur_lit, lines[body_start:idx]))
            return {
                "scrut": scrut, "arms": arms,
                "else_body": None, "end": idx, "is_int": is_int,
            }
        idx += 1
    return None


def references(body_lines, var):
    pat = re.compile(r'\b' + re.escape(var) + r'\b')
    return any(pat.search(l) for l in body_lines)


def reindent(body_lines, delta):
    out = []
    for l in body_lines:
        if not l.strip():
            out.append(l)
            continue
        cur = len(l) - len(l.lstrip())
        out.append(" " * (cur + delta) + l.lstrip())
    return out


def emit_match(scrut_expr, arms, else_body, indent, is_int, shift=4):
    out = [f"{indent}match {scrut_expr} {{"]
    arm_indent = indent + "    "
    for lit, body in arms:
        lit_s = lit if is_int else '"%s"' % lit
        if len(body) == 1:
            out.append(f"{arm_indent}{lit_s} => {{ {body[0].strip()} }},")
        else:
            out.append(f"{arm_indent}{lit_s} => {{")
            out.extend(reindent(body, shift))
            out.append(f"{arm_indent}}},")
    if else_body is not None:
        if len(else_body) == 1:
            out.append(f"{arm_indent}_ => {{ {else_body[0].strip()} }},")
        else:
            out.append(f"{arm_indent}_ => {{")
            out.extend(reindent(else_body, shift))
            out.append(f"{arm_indent}}},")
    out.append(f"{indent}}}")
    return out



def code_part(line):
    """The line minus its comment suffix, with string bodies removed.
    Brace/paren counting must never see comment or string content
    (the r180 lesson: a comment carrying an escaped `}` flipped the
    walk depth)."""
    out = []
    in_str = False
    i = 0
    n = len(line)
    while i < n:
        ch = line[i]
        if in_str:
            if ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':
            in_str = True
            i += 1
            continue
        if ch == "/" and i + 1 < n and line[i + 1] == "/":
            break
        out.append(ch)
        i += 1
    return "".join(out)


def net_braces(line):
    c = code_part(line)
    return c.count("{") - c.count("}")


def net_parens(line):
    c = code_part(line)
    return c.count("(") - c.count(")")


def close_idx_of(core, open_pos):
    """Index of the close paren matching core[open_pos]."""
    depth = 0
    for i in range(open_pos, len(core)):
        if core[i] == "(":
            depth += 1
        elif core[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return None


def find_guard_start(lines, junction_idx, body_start):
    """Find the `if <pred> {` line whose body the junction's `}`
    closes, by forward-verifying each candidate: the region
    [c, junction-1] must open exactly one brace at c, stay >= 1
    throughout, and end at exactly 1 (the junction's `}` then
    closes it)."""
    def net(l):
        return net_braces(l)

    c = junction_idx - 1
    while c >= body_start:
        l = lines[c]
        if (l.lstrip().startswith("if") and " else " not in l
                and l.endswith("{")):
            depth = 0
            ok = True
            for k in range(c, junction_idx):
                depth += net(lines[k])
                if depth < 1:
                    ok = False
                    break
            if ok and depth == 1:
                return c
        c -= 1
    return None


def process_function(name, body_start, body_end, lines, report):
    """Rewrite every convertible chain inside one function body."""
    if name in MANUAL_SITES:
        return lines, False
    int_var = INT_CHAINS.get(name)
    mode_var = MODE_MACHINES.get(name)
    inserts = []
    i = body_start
    while i < body_end:
        line = lines[i]
        m_start = (RE_EQ.match(line) or RE_EQ_FIRST.match(line)
                   or RE_EQ_SL.match(line)
                   or (RE_INT.match(line) if int_var else None))
        if m_start:
            chain_indent = m_start.group(1)
            parsed = parse_chain(lines, i, int_var)
            if parsed is None:
                report.setdefault("residual", []).append(
                    {"fn": name, "line": i + 1, "why": "mixed-guard"})
            else:
                n_arms = len(parsed["arms"])
                mode_ok = mode_var is not None and parsed["scrut"] == mode_var
                if n_arms >= 2 or (mode_ok and n_arms >= 1):
                    scrut = parsed["scrut"]
                    scrut_expr = scrut
                    drop_from = i
                    if not (scrut.startswith("first(") or scrut.startswith("tk_")):
                        let_idx = i - 1
                        if let_idx >= body_start:
                            let_m = RE_LET.match(lines[let_idx])
                            if let_m and let_m.group(2) == scrut:
                                acc = let_m.group(3).strip()
                                if acc.startswith("first(") or acc.startswith("tk_"):
                                    bodies = [b for _, b in parsed["arms"]]
                                    if parsed["else_body"] is not None:
                                        bodies.append(parsed["else_body"])
                                    if not any(
                                            references(bs, scrut)
                                            for bs in bodies):
                                        scrut_expr = acc
                                        drop_from = let_idx
                    new_lines = emit_match(
                        scrut_expr, parsed["arms"], parsed["else_body"],
                        chain_indent, parsed["is_int"])
                    inserts.append((drop_from, parsed["end"] + 1, new_lines))
                    report.setdefault("converted", []).append({
                        "fn": name, "line": i + 1, "scrut": scrut_expr,
                        "arms": n_arms,
                        "else": parsed["else_body"] is not None,
                        "dropped_let": drop_from != i,
                    })
                    i = parsed["end"] + 1
                    continue
                else:
                    report.setdefault("residual", []).append(
                        {"fn": name, "line": i + 1, "why": "below-threshold"})
        i += 1
    if not inserts:
        return lines, False
    out = []
    prev = 0
    for frm, to, nl in inserts:
        out.extend(lines[prev:frm])
        out.extend(nl)
        prev = to
    out.extend(lines[prev:])
    return out, True


def process_guarded(name, body_start, body_end, lines, report):
    """Second pass: guarded phase machines — an `if <pred> {` guard
    whose else-branch is an eq-chain on one scrutinee (the
    is_nil(phase) fresh-state family, M60). The guard stays; the
    eq-region becomes a match inside the else."""
    if name in MANUAL_SITES:
        return lines, False
    inserts = []
    i = body_start
    while i < body_end:
        line = lines[i]
        m_j = RE_ELSE_EQ.match(line) or RE_ELSE_EQ_FIRST.match(line)
        if m_j:
            scrut = m_j.group(1)
            if scrut.startswith("first("):
                arm_re = RE_ELSE_EQ_FIRST
            else:
                arm_re = RE_ELSE_EQ
            # forward-parse the eq-chain from this junction
            idx = i
            arms = []
            cur_lit = None
            body_start_a = None
            depth = 0
            else_body = None
            chain_end = None
            # the first arm body starts after this junction line
            idx = i + 1
            body_start_a = idx
            depth = 1
            cur_lit = m_j.group(2)
            n = len(lines)
            ok = True
            while idx < n:
                l2 = lines[idx]
                if depth == 1 and arm_re.match(l2):
                    m2 = arm_re.match(l2)
                    if m2.group(1) != scrut:
                        ok = False
                        break
                    arms.append((cur_lit, lines[body_start_a:idx]))
                    cur_lit = m2.group(2)
                    idx += 1
                    body_start_a = idx
                    continue
                if depth == 1 and RE_ELSE.match(l2):
                    arms.append((cur_lit, lines[body_start_a:idx]))
                    idx += 1
                    body_start_a = idx
                    d = 1
                    idx2 = idx
                    while idx2 < n:
                        l3 = lines[idx2]
                        d += net_braces(l3)
                        if d == 0:
                            break
                        idx2 += 1
                    else_body = lines[body_start_a:idx2]
                    chain_end = idx2
                    break
                depth += net_braces(l2)
                if depth <= 0:
                    arms.append((cur_lit, lines[body_start_a:idx]))
                    chain_end = idx
                    break
                idx += 1
            if ok and arms and chain_end is not None and chain_end <= body_end:
                g = find_guard_start(lines, i, body_start)
                if g is not None and g >= body_start:
                    guard_indent = re.match(r'^(\s*)', lines[g]).group(1)
                    # the guard body occupies [g+1, i-1]
                    new_lines = list(lines[g:i])
                    new_lines.append(f"{guard_indent}}} else {{")
                    new_lines.extend(emit_match(
                        scrut, arms, else_body, guard_indent + "    ", False,
                        shift=8))
                    # close the guard if
                    new_lines.append(f"{guard_indent}}}")
                    # validate: brace/paren balance of the replacement
                    seg_ok = all(
                        net_braces(l) == 0 or True for l in new_lines)
                    seg_b = sum(net_braces(l) for l in new_lines)
                    seg_p = sum(net_parens(l) for l in new_lines)
                    if seg_b != 0 or seg_p != 0:
                        report.setdefault("rejected", []).append(
                            {"fn": name, "line": i + 1,
                             "why": "balance"})
                        i += 1
                        continue
                    inserts.append((g, chain_end + 1, new_lines))
                    report.setdefault("converted", []).append({
                        "fn": name, "line": i + 1, "scrut": scrut,
                        "arms": len(arms), "guarded": True,
                        "else": else_body is not None,
                    })
                    # single insert per call: the main loop re-invokes
                    # us on the rewritten text (no overlap risk)
                    out = []
                    prev = 0
                    for frm, to, nl in inserts:
                        out.extend(lines[prev:frm])
                        out.extend(nl)
                        prev = to
                    out.extend(lines[prev:])
                    return out, True
        i += 1
    if not inserts:
        return lines, False
    out = []
    prev = 0
    for frm, to, nl in inserts:
        out.extend(lines[prev:frm])
        out.extend(nl)
        prev = to
    out.extend(lines[prev:])
    return out, True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--dry", action="store_true")
    args = ap.parse_args()

    path = args.file
    lines = open(path).read().splitlines()
    report = {}
    passes = 0
    while True:
        passes += 1
        did = False
        for name, _hi, bs, be in find_fn_bounds(lines):
            for proc in (process_function, process_guarded):
                new_lines, changed = proc(name, bs, be, lines, report)
                if changed:
                    lines = new_lines
                    did = True
                    break
            if did:
                break
        if not did or passes > 800:
            break

    for key in ("converted", "residual"):
        if key in report:
            report[key] = sorted(
                {json.dumps(x, sort_keys=True) for x in report[key]})
            report[key] = [json.loads(x) for x in report[key]]

    report["width_violations"] = [
        i + 1 for i, l in enumerate(lines) if len(l) > 100]
    report["passes"] = passes
    print(json.dumps(report, indent=1, ensure_ascii=False))
    if not args.dry:
        open(path, "w").write("\n".join(lines) + "\n")
        print(f"wrote {path}: {len(lines)} lines", file=sys.stderr)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# Blade-6 (W-SELFHOST-MODERN-2) surgical transformer: target-parser.ktf's
# parse-rejection family onto the Error vocabulary + the give protocol's
# dead "done" head retirement (window doc §9.10, M77-M78):
#   M77a the three tp_err_* helper bodies -> perform raise(payload)
#        (the payload = the ("err" ...) contract record, verbatim)
#   M77b the tp_enter depth-guard inline site -> perform raise (the
#        trailing unreachable `false` drops with it)
#   M77c the two multi-line inline `tp_err = pair(...)` sites and the
#        three stray-closer match arms -> perform raise
#   M77d define(tp_err, nil) retires (the error cell is gone)
#   M77e the 100 post-error guard arms dissolve (iterative leaf-first;
#        the kept THEN work dedents one level, the unreachable ELSE
#        arms drop) — tp_run's head guard dissolves the same way
#   M77f the entry: tp_run_result rides unwrap(attempt(thunk), identity)
#        and tp_verdict aliases it (`define(result, tp_verdict);` is
#        byte-frozen — the decode contract)
#   M78  the give protocol's "done" head retires (21 construction
#        sites -> the single-slot pair(R', nil); tp_finish's done arm
#        reads first(r) — the dead discriminant never had a by-name
#        dispatch, the else arm carried the case)
#
# Modes: --survey (classify + report, zero writes) / --apply (the
# anchored surgery, calls-then-guards) / --verify (post-checks only).
# Every anchor asserts; any mismatch aborts with zero writes.
# Built-in guards: width <= 100, the non-ASCII set may not grow,
# paren balance outside comments/strings, byte-frozen tail anchor.

import re
import sys

PATH = 'selfhost/v1/target-parser.ktf'

# The frozen anchors (byte-exact, asserted on survey and apply):
FROZEN_TAIL = 'define(result, tp_verdict);'

ENTRY_OLD = (
    'define(tp_run_result, tp_run());\n'
    'define(tp_verdict, if is_nil(tp_err) { tp_done } else { tp_err });\n'
    'define(result, tp_verdict);'
)
ENTRY_NEW = (
    'define(tp_run_result, unwrap(attempt(|| { tp_run(); tp_done }), ||(e) { e }));\n'
    'define(tp_verdict, tp_run_result);\n'
    'define(result, tp_verdict);'
)

TP_ENTER_OLD = (
    'fn tp_enter() -> bool {\n'
    '    tp_depth = tp_depth + 1;\n'
    '    if tp_depth > tp_limit {\n'
    '        tp_err = pair("err", pair("nesting", pair(tp_depth, pair(tp_limit, nil))));\n'
    '        false\n'
    '    } else {\n'
    '        true\n'
    '    }\n'
    '}'
)
TP_ENTER_NEW = (
    'fn tp_enter() -> bool {\n'
    '    tp_depth = tp_depth + 1;\n'
    '    if tp_depth > tp_limit {\n'
    '        perform raise(pair("err", pair("nesting", pair(tp_depth, pair(tp_limit, nil)))))\n'
    '    } else {\n'
    '        true\n'
    '    }\n'
    '}'
)

# The unsupported helper's raise form would exceed the 100-col guard on
# one line, so its body takes the wrapped shape directly (the anchor is
# the pre-conversion assignment form).
TP_UNSUPPORTED_OLD = (
    '    tp_err = pair("err", pair("unsupported", pair(form_bytes, pair(tk_s(t), pair(tk_e(t), nil)))));'
)
TP_UNSUPPORTED_NEW = (
    '    perform raise(pair(\n'
    '        "err",\n'
    '        pair("unsupported", pair(form_bytes, pair(tk_s(t), pair(tk_e(t), nil))))\n'
    '    ))'
)

# The three stray-closer arms (the same width story — the wrapped arm
# form keeps the 100-col guard).
TP_STRAY_OLD = (
    '        "close-brace" => { tp_err = pair("err", pair("stray", pair(125, pair(tk_s(t), nil)))); },\n'
    '        "close-paren" => { tp_err = pair("err", pair("stray", pair(41, pair(tk_s(t), nil)))); },\n'
    '        "close-bracket" => { tp_err = pair("err", pair("stray", pair(93, pair(tk_s(t), nil)))); },'
)
TP_STRAY_NEW = (
    '        "close-brace" => {\n'
    '            perform raise(pair("err", pair("stray", pair(125, pair(tk_s(t), nil)))))\n'
    '        },\n'
    '        "close-paren" => {\n'
    '            perform raise(pair("err", pair("stray", pair(41, pair(tk_s(t), nil)))))\n'
    '        },\n'
    '        "close-bracket" => {\n'
    '            perform raise(pair("err", pair("stray", pair(93, pair(tk_s(t), nil)))))\n'
    '        },'
)

STATE_DEFINE_OLD = 'define(tp_err, nil);         // ("err" kind payload ...) | nil'

DELIVERY_COMMENT_OLD = (
    '// Delivery protocol: tp_give(parent, R) returns ("frame" parent\')\n'
    '// when the parent consumed the value, or ("done" R\') when the\n'
    '// parent completed too (tp_finish cascades, running the guard\n'
    '// leave through tp_leave_g on every completed frame). tp_give'
)
DELIVERY_COMMENT_NEW = (
    '// Delivery protocol: tp_give(parent, R) returns ("frame" parent\')\n'
    '// when the parent consumed the value, or (R\') when the\n'
    '// parent completed too (the blade-6 "done"-head retirement: the\n'
    '// head never had a by-name dispatch — tp_finish\'s else arm\n'
    '// carries the case, so the product rides the single slot;\n'
    '// tp_finish cascades, running the guard\n'
    '// leave through tp_leave_g on every completed frame). tp_give'
)

PROPAGATION_LINE_OLD = (
    '//     Rust ? propagation -> the global tp_err (tp_run halts)'
)
PROPAGATION_LINE_NEW = (
    '//     Rust ? propagation -> the one-shot raise (the entry\'s\n'
    '//                        attempt boundary unwinds the machine)'
)

OUTPUT_GLOBALS_OLD = (
    '//   tp_done — ("ok" item-record ...) | nil while running\n'
    '//   tp_err  — ("err" kind payload ...) | nil\n'
    '//   result  — tp_done when it holds, the error otherwise'
)
OUTPUT_GLOBALS_NEW = (
    '//   tp_done — ("ok" item-record ...) | nil while running\n'
    '//   result  — tp_done when it holds, the raise payload otherwise'
)

HEADER_NOTE_NEW = (
    '//\n'
    '// MODERN2 blade 6 (r203): the parse-rejection family rides\n'
    '// `perform raise` through the tp_err_* helpers (the payloads\n'
    '// stay verbatim — the ("err" ...) contract records; the 50\n'
    '// call sites unchanged), the 100 post-error guard arms\n'
    '// dissolve (the one-shot unwinding replaces the first-error\n'
    '// cell), tp_run rides unwrap(attempt(thunk), identity) — the\n'
    '// result define byte-frozen — and the give protocol\'s "done"\n'
    '// head retires (a dead discriminant: the else-arm dispatch\n'
    '// never read it; the products ride the single slot and\n'
    '// tp_finish reads first). The Rust-reader boundary M49 holds\n'
    '// (this twin parses through the frozen reader, so no row\n'
    '// vocabulary); the tp_N positional accessors keep their\n'
    '// navigation — every frame tag is a live dispatch face and\n'
    '// the internal forms are already bare pairs (the done head\n'
    '// was the one C1 surface).\n'
)

TP_FINISH_COMMENT_OLD = (
    '            // r = ("done" R\') — the product rides the WRAPPED slot\n'
    '            // (every done arm constructs pair("done", pair(R\', nil))),\n'
    '            // so the product is the second ELEMENT, not the cdr.'
)
TP_FINISH_COMMENT_NEW = (
    '            // r = (R\') — the done product rides the single\n'
    '            // slot (every done arm constructs pair(R\', nil) —\n'
    '            // the blade-6 head retirement), so the product is\n'
    '            // the FIRST element.'
)
TP_FINISH_UNWRAP_OLD = '            tp_finish(tp_2(r))'
TP_FINISH_UNWRAP_NEW = '            tp_finish(first(r))'

EXPECTED_RAISE_SITES = 9        # 3 helper bodies + tp_enter + 2 multi-line + 3 stray
EXPECTED_GUARDS = 100           # block guards (tp_run's head included; the verdict define is pass-1)
EXPECTED_DONE_SITES = 21        # construction sites (L1185's match-arm form + 14 multi-line + 6 inline; the tp_finish comment is not one)


def die(msg):
    sys.exit('blade6 parser transform: %s' % msg)


def read_source():
    with open(PATH, 'r', encoding='utf-8') as f:
        return f.read()


def write_source(text):
    with open(PATH, 'w', encoding='utf-8') as f:
        f.write(text)


def paren_delta(line):
    """The paren delta of one line outside comments and strings."""
    depth = 0
    in_str = False
    in_comment = False
    i = 0
    while i < len(line):
        c = line[i]
        if in_comment:
            i += 1
            continue
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '/' and i + 1 < len(line) and line[i + 1] == '/':
            break
        if c == '"':
            in_str = True
            i += 1
            continue
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
        i += 1
    return depth


def find_statement_end(lines, start_ln):
    """From the `tp_err = pair(` opener line (1-based), find the line
    whose cumulative paren delta returns to zero and ends with `;`."""
    depth = 0
    for j in range(start_ln - 1, len(lines)):
        depth += paren_delta(lines[j])
        if depth == 0:
            if not lines[j].rstrip().endswith(';'):
                die('M77: the tp_err statement @%d does not end with `;`: %r'
                    % (j + 1, lines[j]))
            return j + 1
    die('M77: the tp_err statement @%d never closes' % start_ln)


def find_rhs_span(text, assign_start):
    """From the offset of `tp_err = `, find the balanced RHS pair(...)
    span: returns (rhs_start, rhs_end) with rhs_end exclusive."""
    rhs_start = text.index('pair(', assign_start)
    depth = 0
    i = rhs_start
    while i < len(text):
        c = text[i]
        if c == '"':
            i += 1
            while i < len(text) and text[i] != '"':
                if text[i] == '\\':
                    i += 1
                i += 1
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                return rhs_start, i + 1
        i += 1
    die('M77: the RHS pair never closes from offset %d' % assign_start)


def convert_raise_sites(text):
    """Pass 1a: the tp_enter anchor first (the whole fn form — the
    assignment converts AND the unreachable `false` drops in one
    replacement), then every remaining `tp_err = pair(...)` statement
    becomes `perform raise(pair(...))` — the assignment prefix swaps
    for the raise, the statement's `;` becomes the raise's closing
    paren; anything after the `;` on the same line (a match arm's
    ` },`) stays untouched."""
    if text.count(TP_ENTER_OLD) != 1:
        die('M77: the tp_enter anchor not found uniquely')
    text = text.replace(TP_ENTER_OLD, TP_ENTER_NEW, 1)
    if text.count(TP_UNSUPPORTED_OLD) != 1:
        die('M77: the tp_err_unsupported body anchor not found uniquely')
    text = text.replace(TP_UNSUPPORTED_OLD, TP_UNSUPPORTED_NEW, 1)
    if text.count(TP_STRAY_OLD) != 1:
        die('M77: the stray-closer arms anchor not found uniquely')
    text = text.replace(TP_STRAY_OLD, TP_STRAY_NEW, 1)
    count = 5
    while True:
        m = re.search(r'tp_err = pair\(', text)
        if m is None:
            break
        start = m.start()
        rhs_start, rhs_end = find_rhs_span(text, start)
        # the suffix: the `;` immediately after the RHS (same line)
        after = text[rhs_end:]
        m2 = re.match(r';', after)
        if not m2:
            line_no = text.count('\n', 0, rhs_end) + 1
            die('M77: no `;` right after the RHS @line %d: %r'
                % (line_no, after[:40]))
        semi_end = rhs_end + 1
        rhs = text[rhs_start:rhs_end]
        replacement = 'perform raise(' + rhs + ')'
        text = text[:start] + replacement + text[semi_end:]
        count += 1
    if count != EXPECTED_RAISE_SITES:
        die('M77: expected %d tp_err assignment sites, converted %d'
            % (EXPECTED_RAISE_SITES, count))
    return text


def retire_error_cell(text):
    """Pass 1b: the define line + the entry defines."""
    if text.count(STATE_DEFINE_OLD) != 1:
        die('M77d: the tp_err define anchor not found uniquely')
    text = text.replace(STATE_DEFINE_OLD + '\n', '', 1)
    if text.count(ENTRY_OLD) != 1:
        die('M77f: the entry anchor not found uniquely')
    text = text.replace(ENTRY_OLD, ENTRY_NEW, 1)
    return text


def brace_delta(line):
    """The brace delta of one line outside comments and strings
    (the comments carry quoted braces — e.g. L97's `spell "{"` note —
    so a raw char walk would corrupt the tracking)."""
    depth = 0
    in_str = False
    i = 0
    while i < len(line):
        c = line[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '/' and i + 1 < len(line) and line[i + 1] == '/':
            break
        if c == '"':
            in_str = True
            i += 1
            continue
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
        i += 1
    return depth


def guard_close(lines, start_ln):
    """The line index (1-based) closing the brace block that opens on
    start_ln (the line must end with `{`) — comment/string aware."""
    depth = 0
    started = False
    for j in range(start_ln - 1, len(lines)):
        depth += brace_delta(lines[j])
        if depth != 0:
            started = True
        if started and depth == 0:
            return j + 1
    return None


def dedent_block(block):
    out = []
    for l in block:
        if l.startswith('    '):
            out.append(l[4:])
        elif l.strip() == '':
            out.append('')
        else:
            die('M77e: cannot dedent a guard work line: %r' % l)
    return out


def dissolve_guards(text):
    """Pass 2, iterative leaf-first: each round dissolves only the leaf
    guards (no other guard strictly inside), re-derives, and repeats
    until zero remain. All block guards here carry an ELSE arm — the
    then-work keeps (dedented), the head and the unreachable else arm
    drop."""
    for round_no in range(1, 80):
        lines = text.split('\n')
        glist = [i + 1 for i, l in enumerate(lines)
                 if re.search(r'if is_nil\(tp_err\)', l)]
        if not glist:
            return text
        regions = []
        for g in glist:
            head = lines[g - 1]
            if not re.fullmatch(r'\s*if is_nil\(tp_err\) \{', head):
                die('M77e: guard head anomaly @%d: %r' % (g, head))
            end = guard_close(lines, g)
            if end is None:
                die('M77e: guard unclosed @%d' % g)
            regions.append((g, end))
        leaves = [r for r in regions
                  if not any(o[0] < r[0] and r[1] < o[1] for o in regions if o is not r)]
        if not leaves:
            die('pass2 round %d: no leaves but %d regions remain'
                % (round_no, len(regions)))
        edits = []
        for first, last in leaves:
            head = lines[first - 1]
            indent = re.match(r'(\s*)', head).group(1)
            # the else separator at the guard's own indent
            else_ln = None
            for j in range(first + 1, last):
                if re.fullmatch(re.escape(indent) + r'\} else \{', lines[j - 1]):
                    else_ln = j
                    break
                if re.fullmatch(re.escape(indent) + r'\} else if .+', lines[j - 1]):
                    die('M77e: unexpected else-if chain inside guard @%d' % first)
            if else_ln is None:
                die('M77e: guard without else arm @%d (all 100 carry one)' % first)
            then_work = lines[first:else_ln - 1]      # 1-based first+1 .. else_ln-1
            edits.append((first, last, dedent_block(then_work)))
        text = apply_edits(text, edits)
    die('pass2: exceeded 80 rounds — non-terminating dissolve')


def retire_done_head(text):
    """Pass 3 (M78): the 21 `pair("done", pair(R', nil))` constructions
    become `pair(R', nil)` — the inline form and the multi-line form
    (the `pair(` opener line + the `"done",` line + the closer lose
    one wrap level)."""
    lines = text.split('\n')
    edits = []
    count = 0
    i = 0
    while i < len(lines):
        l = lines[i]
        # inline form: pair("done", pair(R, nil)) — inside an arm
        # (optionally closed by ` }` and/or trailed by `,`)
        m = re.search(r'pair\("done", (pair\(.*\))\)(\s*\})?(\s*,)?$', l.rstrip())
        if m and '//' not in l:
            new_line = (l.rstrip()[:m.start()] + m.group(1)
                        + (m.group(2) or '') + (m.group(3) or ''))
            edits.append((i + 1, i + 1, [new_line]))
            count += 1
            i += 1
            continue
        # multi-line form: an opener `pair(` (alone) followed by `"done",`
        if l.rstrip().endswith('pair(') and i + 1 < len(lines) \
                and re.fullmatch(r'\s*"done",', lines[i + 1]):
            # find the close of the OUTER pair: track paren depth from i
            depth = 0
            close = None
            for j in range(i, len(lines)):
                depth += paren_delta(lines[j])
                if depth == 0:
                    close = j
                    break
            if close is None:
                die('M78: the done construction @%d never closes' % (i + 1))
            # the inner work = lines i+2 .. close-1, dedented one level;
            # the close line loses one `)` level if it is a bare `)` line
            inner = lines[i + 2:close]
            close_line = lines[close]
            if re.fullmatch(r'\s*\)(,?)\s*', close_line):
                # the closer is a lone paren (possibly with a comma) —
                # drop it entirely: the inner work IS the construction
                new_block = dedent_block(inner)
                if close_line.rstrip().endswith(','):
                    new_block[-1] = new_block[-1].rstrip() + ','
                edits.append((i + 1, close + 1, new_block))
            else:
                # the closer carries more than the paren (e.g. `) )`) —
                # strip one paren level from it
                stripped = close_line.rstrip()
                if not stripped.endswith(')'):
                    die('M78: close line shape @%d: %r' % (close + 1, close_line))
                new_close = stripped[:-1]
                new_block = dedent_block(inner) + [new_close]
                edits.append((i + 1, close + 1, new_block))
            count += 1
            i = close + 1
            continue
        i += 1
    if count != EXPECTED_DONE_SITES:
        die('M78: expected %d done construction sites, found %d'
            % (EXPECTED_DONE_SITES, count))
    text = apply_edits(text, edits)
    # the tp_finish consumption + its comment
    if text.count(TP_FINISH_UNWRAP_OLD) != 1:
        die('M78: the tp_finish unwrap anchor not found uniquely')
    text = text.replace(TP_FINISH_UNWRAP_OLD, TP_FINISH_UNWRAP_NEW, 1)
    if text.count(TP_FINISH_COMMENT_OLD) != 1:
        die('M78: the tp_finish comment anchor not found uniquely')
    text = text.replace(TP_FINISH_COMMENT_OLD, TP_FINISH_COMMENT_NEW, 1)
    return text


def covary_comments(text):
    """Pass 4: the header protocol/propagation/globals notes + the
    blade-6 header note."""
    pairs = [
        (DELIVERY_COMMENT_OLD, DELIVERY_COMMENT_NEW),
        (PROPAGATION_LINE_OLD, PROPAGATION_LINE_NEW),
        (OUTPUT_GLOBALS_OLD, OUTPUT_GLOBALS_NEW),
    ]
    for old, new in pairs:
        if text.count(old) != 1:
            die('pass4: comment anchor not found uniquely: %r' % old[:60])
        text = text.replace(old, new, 1)
    # the blade-6 note lands after the header's first paragraph block
    anchor = ('// Spans ride as plain ints (the parser computes with them). Floats\n'
              '// ride as Debug-text strings (inf/NaN have no literal shape); the\n'
              "// value face stays host-side. tp_forms carries the oracle's own\n"
              '// UnsupportedTargetForm message texts as byte lists keyed by short\n'
              '// tags (the single source \u2014 a twin-side copy drifting is\n'
              '// structurally impossible).')
    if text.count(anchor) != 1:
        die('pass4: the header note anchor not found uniquely')
    text = text.replace(anchor, anchor + '\n' + HEADER_NOTE_NEW, 1)
    return text


def apply_edits(text, edits):
    """Apply (first, last, new_lines) 1-based line edits bottom-up."""
    lines = text.split('\n')
    for first, last, new_lines in sorted(edits, key=lambda e: -e[0]):
        lines[first - 1:last] = new_lines
    return '\n'.join(lines)


def structural_guards(text, label):
    lines = text.split('\n')
    for i, l in enumerate(lines, 1):
        if len(l) > 100:
            die('%s: width guard failed @%d (%d cols): %r' % (label, i, len(l), l))
    # paren balance, whole file, line-cumulative outside comments/strings
    depth = 0
    in_block_comment = False
    for i, l in enumerate(lines, 1):
        if in_block_comment:
            if '*/' in l:
                in_block_comment = False
            continue
        if l.lstrip().startswith('//'):
            continue
        depth += paren_delta(l)
        if depth < 0:
            die('%s: paren balance went negative @%d' % (label, i))
    if depth != 0:
        die('%s: paren balance ends at %d' % (label, depth))
    # the frozen tail
    if not text.rstrip().endswith(FROZEN_TAIL):
        die('%s: the byte-frozen tail anchor drifted' % label)


def non_ascii(text):
    return sorted(set(c for c in text if ord(c) > 127))


def survey():
    text = read_source()
    structural_guards(text, 'survey')
    lines = text.split('\n')
    assigns = [i + 1 for i, l in enumerate(lines)
               if re.search(r'tp_err = pair\(', code_part(l))]
    guards = [i + 1 for i, l in enumerate(lines) if re.search(r'if is_nil\(tp_err\)', l)]
    done_inline = [i + 1 for i, l in enumerate(lines) if re.search(r'pair\("done",', l)]
    print('tp_err assignments: %d (expect %d)' % (len(assigns), EXPECTED_RAISE_SITES))
    print('is_nil(tp_err) mentions: %d (expect %d block guards + 1 entry define)'
          % (len(guards), EXPECTED_GUARDS))
    print('done inline mentions: %d lines (21 constructions + 1 tp_finish comment)'
          % len(done_inline))
    print('entry anchor present: %s' % (ENTRY_OLD in text))
    print('tp_enter anchor present: %s' % (TP_ENTER_OLD in text))
    print('state define anchor present: %s' % (STATE_DEFINE_OLD in text))
    print('non-ASCII set size: %d' % len(non_ascii(text)))


def code_part(line):
    """The line with its trailing comment stripped (string-aware: a
    `//` inside a string does not start a comment)."""
    in_str = False
    i = 0
    while i < len(line):
        c = line[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '/' and i + 1 < len(line) and line[i + 1] == '/':
            return line[:i]
        i += 1
    return line


def terminal_invariants(text):
    """The terminal surgery invariants, comment-aware: zero tp_err
    code references, zero is_nil(tp_err), zero done-tag construction
    forms, the new entry in place."""
    for i, l in enumerate(text.split('\n'), 1):
        code = code_part(l)
        if re.search(r'tp_err(?!_)', code):
            die('terminal: tp_err code reference remains @%d: %r' % (i, l))
        if re.search(r'pair\("done"', code) or re.fullmatch(r'\s*"done",', l):
            die('terminal: a done-tag construction remains @%d: %r' % (i, l))
    if 'is_nil(tp_err)' in text:
        die('terminal: is_nil(tp_err) remains')
    if ENTRY_NEW not in text:
        die('terminal: the new entry form missing')


def apply():
    text = read_source()
    structural_guards(text, 'apply-pre')
    ascii_before = non_ascii(text)
    text = convert_raise_sites(text)
    text = retire_error_cell(text)
    text = dissolve_guards(text)
    text = retire_done_head(text)
    text = covary_comments(text)
    structural_guards(text, 'apply-post')
    ascii_after = non_ascii(text)
    if set(ascii_after) - set(ascii_before):
        die('apply: the non-ASCII set grew: %r'
            % (set(ascii_after) - set(ascii_before)))
    terminal_invariants(text)
    write_source(text)
    lines = text.split('\n')
    print('applied: the surgery is complete — %d lines' % len(lines))


def verify():
    text = read_source()
    structural_guards(text, 'verify')
    terminal_invariants(text)
    if 'perform raise' not in text:
        die('verify: no perform raise sites')
    code_text = '\n'.join(code_part(l) for l in text.split('\n'))
    n_raise = len(re.findall(r'perform raise\(', code_text))
    n_attempt = len(re.findall(r'unwrap\(attempt\(', code_text))
    if n_raise != EXPECTED_RAISE_SITES:
        die('verify: %d perform raise sites (expect %d)'
            % (n_raise, EXPECTED_RAISE_SITES))
    if n_attempt != 1:
        die('verify: %d unwrap(attempt( sites (expect 1)' % n_attempt)
    if not text.rstrip().endswith(FROZEN_TAIL):
        die('verify: the frozen tail drifted')
    print('verify: all post-checks pass (%d raise sites, 1 attempt boundary, '
          'zero tp_err/done code references, frozen tail intact)' % n_raise)


if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] not in ('--survey', '--apply', '--verify'):
        die('usage: blade6_modern2_parser_transform.py --survey|--apply|--verify')
    if sys.argv[1] == '--survey':
        survey()
    elif sys.argv[1] == '--apply':
        apply()
    else:
        verify()

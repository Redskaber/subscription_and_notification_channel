#!/usr/bin/env python3
"""The r200/r201 double-fork daemon form (the sandbox harvest escape):
run the regen (or any long cargo test) as a fully-detached daemon
child that survives the tool-shell's death; poll the log from the
parent. Usage: daemon_regen.py <log-path> [test-filter]"""
import os
import sys
import subprocess

LOG = sys.argv[1] if len(sys.argv) > 1 else '/tmp/regen.log'
FILTER = sys.argv[2] if len(sys.argv) > 2 else 'regen_td032 -- --ignored --nocapture'


def daemon():
    # second fork: the child re-parents to init, fully detached
    if os.fork() > 0:
        os._exit(0)
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    # redirect stdio to the log, drop the terminal
    fd = os.open(LOG, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    os.close(fd)
    os.close(0)
    env = dict(os.environ)
    env['PATH'] = os.path.expanduser('~/.cargo/bin') + ':' + env.get('PATH', '')
    subprocess.run(
        ['cargo', 'test', '--test', 'runner'] + FILTER.split(),
        cwd='/home/z/kerf',
        env=env,
    )
    with open(LOG, 'a') as f:
        f.write('DAEMON-EXIT=0\n')


if os.fork() > 0:
    # parent (the tool shell's child): print and exit fast
    print('daemon launched, log: %s' % LOG)
else:
    daemon()

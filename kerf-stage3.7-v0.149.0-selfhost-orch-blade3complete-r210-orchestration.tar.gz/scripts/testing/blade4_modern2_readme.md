# blade4_modern2_compiler_transform.py — the r200 surgery script (archived)

The W-SELFHOST-MODERN-2 blade-4 source surgery on selfhost/v1/compiler.ktf,
as executed at r200 (the r199 re-delivery): line-range anchored with full
assertions — any anchor mismatch aborts before writing. Carries the M50-M55
source-side edits (8 raise sites, 7 guard dissolutions, the cp_err retirement,
the estate/proto head drops with the ~85 proto read-site shift, the cp_run
unwrap(attempt(...)) contract face) plus the built-in width/non-ASCII/bracket
guards. The macro.ktf header note landed via a separate inline pass.

The daemon launcher for the K159-class single-case runs (a double-fork
daemon that survives the sandbox's descendant reaping — the r200 discovery,
registered at tech-debt r200's TD-029 observation) rode /tmp/daemon_k159.py;
the pattern is reproducible from the worklog record (double-fork + setsid +
stdio redirect + spawnvpe).

#!/usr/bin/env python3
# Blade-5 (W-SELFHOST-MODERN-2) surgical transformer: expander.ktf's
# expansion-rejection family onto the Error vocabulary + macro.ktf's
# shadow-pair co-modernization (window doc §9.8, M59-M71):
#   M59  the ex_fail body -> perform raise(pair("err", tail))
#        (both files, identical bodies — the shadow-pair discipline)
#   M60  the `ex_fail(...); nil` dead-nil arms dissolve (44 expander
#        + 1 macro): the trailing `;` drops, the nil line goes
#   M61  the final-expression call sites stay verbatim (68 expander
#        + 13 macro — asserted unchanged)
#   M62  the ex_declare mod-dup continuation (one site): the dead
#        `ex_declare(...)` tail after ex_fail drops
#   M63  the post-error walk guards dissolve (39 expander + 1 macro,
#        three shapes: with-else-nil / no-else / one-liner), the
#        enclosed WORK keeps its text and dedents one level
#   M64  the six between-helper guards (`if not(is_nil(ex_err)) {
#        nil } else if COND`): the guard arm drops, `} else if`
#        rewrites to `if`
#   M65  ex_run's triple check -> unwrap(attempt(thunk), identity)
#        (the M55 contract-face form; seeds stay outside the thunk —
#        pure, zero raise paths, machine-checked)
#   M66  the ex_err cell retires (define line, both files)
#   M67/M71 the state-cell comment + header notes (both files)
#
# Modes: --survey (classify + report, zero writes) / --apply (the
# anchored surgery, bottom-up) / --verify (post-checks only).
# Every anchor asserts; any mismatch aborts with zero writes.
# Built-in guards: width <= 100, the non-ASCII set may not grow,
# paren balance outside comments/strings, byte-frozen tail anchors.

import re
import sys

PATHS = {
    'expander': 'selfhost/v1/expander.ktf',
    'macro': 'selfhost/v1/macro.ktf',
}

# The frozen anchors (byte-exact, asserted on both survey and apply):
FROZEN_TAIL = 'define(result, ex_run(forms));'
EX_FAIL_BODY_OLD = (
    'fn ex_fail(tail) {\n'
    '    if is_nil(ex_err) { set(ex_err, pair("err", tail)) } else { nil }\n'
    '}'
)
EX_FAIL_BODY_NEW = (
    'fn ex_fail(tail) {\n'
    '    perform raise(pair("err", tail))\n'
    '}'
)
STATE_COMMENT_OLD = (
    '// ---- the expansion state (single run per program; the error cell\n'
    '// records the FIRST rejection and everything after unwinds into\n'
    '// discarded values — first-error-wins mirrors Rust\'s early-return)'
)
STATE_COMMENT_NEW = (
    '// ---- the expansion state (single run per program; the one-shot\n'
    '// raise carries the FIRST rejection straight to the top-level\n'
    '// attempt — first-raise-wins mirrors Rust\'s early-return; the\n'
    '// blade-5 Error-vocabulary consumption retired the error cell)'
)
HEADER_NOTE_EXPANDER = (
    '//\n'
    '// MODERN2 blade 5 (r201): the expansion-rejection family rides\n'
    '// `perform raise` through the ex_fail helper (the payload records\n'
    '// stay verbatim, the call sites unchanged), the post-error guard\n'
    '// arms dissolve (the one-shot unwinding replaces the first-error\n'
    '// cell), and ex_run rides unwrap(attempt(thunk), identity) — the\n'
    '// ok/err records byte-frozen. The Rust-reader boundary M49 holds\n'
    '// (this twin parses through the frozen reader, so no row\n'
    '// vocabulary); the ex_N positional accessors keep their\n'
    '// navigation — every tag here is a live dispatch face and the\n'
    '// internal forms are already bare pairs (zero C1 surface).\n'
)
HEADER_NOTE_MACRO = (
    '// W-SELFHOST-MODERN-2 blade 5 (r201, the shadow-pair\n'
    '// co-modernization): both copies of the pair take the Error\n'
    '// vocabulary in one surgery — ex_fail\'s body rides perform\n'
    '// raise (identical bodies, the MX-2 assembly order stays\n'
    '// order-insensitive), the dead-nil arms dissolve, the one\n'
    '// guard (the defsyn publish) dissolves, and the ex_err cell\n'
    '// retires in both files.\n'
    '//\n'
)


ONE_LINER = r'if is_nil\(ex_err\) \{ (.*) \} else \{ nil \}$'


def read(path):
    with open(path) as f:
        return f.read().split('\n')


def write(path, lines):
    with open(path, 'w') as f:
        f.write('\n'.join(lines))


def find_ex_fail_calls(text):
    """Every ex_fail( call site: (start_line, close_line) 1-based,
    excluding the fn definition line."""
    sites = []
    lines = text.split('\n')
    for m in re.finditer(r'ex_fail\(', text):
        ln = text[:m.start()].count('\n') + 1
        if re.match(r'\s*fn ex_fail\(', lines[ln - 1]):
            continue
        depth = 0
        i = m.end() - 1
        while i < len(text):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        close_ln = text[:i].count('\n') + 1
        sites.append((ln, close_ln))
    return sites


def classify_call(text, site):
    """Classify one ex_fail call site by what follows the closing
    paren: 'dead-nil' | 'final-expr' | 'continuation' | anomaly."""
    lines = text.split('\n')
    start, close = site
    close_text = lines[close - 1]
    after = text.split('\n', close - 1)[close - 1] if False else None
    # What immediately follows the closing paren?
    # Reconstruct: position after the final ')' of the call.
    pos = 0
    for _ in range(close - 1):
        pos = text.index('\n', pos) + 1
    # the close line's trailing content after the LAST ')' that
    # closes the call: find the call's end offset precisely.
    m = None
    for m2 in re.finditer(r'ex_fail\(', text):
        l = text[:m2.start()].count('\n') + 1
        if l == start and not re.match(r'\s*fn ex_fail\(', lines[start - 1]):
            m = m2
            break
    depth = 0
    i = m.end() - 1
    while i < len(text):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                break
        i += 1
    rest = text[i + 1:]
    wsm = re.match(r'[ \t]*', rest)
    after = rest[len(wsm.group(0)):]
    if after.startswith(';'):
        rest2 = text[i + 1 + len(wsm.group(0)) + 1:]
        m2 = re.match(r'\s*nil\b', rest2)
        if m2:
            nil_line = close + 1 + text[i + 2:i + 2 + len(wsm.group(0)) + 1].count('\n') if False else None
            # the nil is on its own line right after (possibly the
            # same line); require it on the next line, alone.
            nxt = lines[close] if close < len(lines) else ''
            if re.fullmatch(r'\s*nil', nxt):
                return 'dead-nil'
        # semicolon followed by a non-nil expression = continuation
        return 'continuation'
    if after.startswith(')') or after.startswith(',') or after.startswith('\n'):
        # final expression of a block/argument position
        return 'final-expr'
    return 'anomaly:%s' % after[:16]


def guard_end(lines, g):
    """The line index (1-based) of the guard's closing `}` at the
    SAME indentation as the if-line — brace-depth tracked outside
    comments/strings. Returns (end_line, indent)."""
    head = lines[g - 1]
    indent = re.match(r'(\s*)', head).group(1)
    depth = 0
    for j in range(g, len(lines) + 1):
        l = lines[j - 1]
        i = 0
        in_str = False
        while i < len(l):
            c = l[i]
            if in_str:
                if c == '\\':
                    i += 2
                    continue
                if c == '"':
                    in_str = False
            else:
                if c == '"':
                    in_str = True
                elif c == '/' and i + 1 < len(l) and l[i + 1] == '/':
                    break
                elif c == '{':
                    depth += 1
                elif c == '}':
                    depth -= 1
            i += 1
        if depth == 0:
            return j, indent
    return None, indent


def guard_shapes(text, guard_lines):
    """Classify each `if is_nil(ex_err)` guard line (excluding the
    ex_fail body and the ex_run triple check, which the caller has
    already separated)."""
    lines = text.split('\n')
    out = []
    for g in guard_lines:
        head = lines[g - 1]
        if re.search(ONE_LINER, head):
            out.append((g, 'one-liner'))
            continue
        if not re.fullmatch(r'\s*if is_nil\(ex_err\) \{', head):
            out.append((g, 'ANOMALY-head'))
            continue
        end, indent = guard_end(lines, g)
        if end is None:
            out.append((g, 'ANOMALY-unclosed'))
            continue
        # with-else: the last three lines are `I} else {` / `I nil` /
        # `I}`; no-else: the last line is `I}` alone
        has_else = re.fullmatch(r'\s*\} else \{', lines[end - 3]) if end >= 3 else None
        if has_else:
            out.append((g, 'with-else'))
        elif re.fullmatch(r'\s*\}', lines[end - 1]):
            out.append((g, 'no-else'))
        else:
            out.append((g, 'ANOMALY-tail@%d' % end))
    return out


def between_guard_lines(text):
    lines = text.split('\n')
    return [i + 1 for i, l in enumerate(lines)
            if re.search(r'if not\(is_nil\(ex_err\)\) \{', l)]


def ex_run_region(text):
    """The triple-check region inside ex_run: returns
    (first_line, last_line) 1-based inclusive of the lines
    `    let items = ex_decl(...)` through the final `    }` before
    the fn close — asserted by exact text below."""
    lines = text.split('\n')
    anchor = None
    for i, l in enumerate(lines):
        if l == '    let items = ex_decl(pair("decls", pair(trees, pair(nil, nil))));':
            anchor = i + 1
            break
    if anchor is None:
        return None, None
    # the region runs to the line before the fn close `}` at col 0
    j = anchor
    while j <= len(lines):
        if lines[j - 1] == '}':
            return anchor, j - 1
        j += 1
    return anchor, None


EX_RUN_OLD = '''    let items = ex_decl(pair("decls", pair(trees, pair(nil, nil))));
    if is_nil(ex_err) {
        // The W-3.2 cross-item collision pass (defines / Stage 0
        // globals), then the loader.
        ex_extern_collide(items);
        if is_nil(ex_err) {
            ex_load(items);
            if is_nil(ex_err) { pair("ok", items) } else { ex_err }
        } else {
            ex_err
        }
    } else {
        ex_err
    }'''
EX_RUN_NEW = '''    unwrap(attempt(|| {
        let items = ex_decl(pair("decls", pair(trees, pair(nil, nil))));
        // The W-3.2 cross-item collision pass (defines / Stage 0
        // globals), then the loader.
        ex_extern_collide(items);
        ex_load(items);
        pair("ok", items)
    }), ||(e) { e })'''


def paren_balance(lines):
    """Count parens outside // comments and "..." strings."""
    bal = 0
    for l in lines:
        i = 0
        in_str = False
        while i < len(l):
            c = l[i]
            if in_str:
                if c == '\\':
                    i += 2
                    continue
                if c == '"':
                    in_str = False
            else:
                if c == '"':
                    in_str = True
                elif c == '/' and i + 1 < len(l) and l[i + 1] == '/':
                    break
                elif c == '(':
                    bal += 1
                elif c == ')':
                    bal -= 1
            i += 1
    return bal


def non_ascii_set(text):
    return set(ch for ch in text if ord(ch) > 127)


SURVEY_EXPECT = {
    'expander': dict(calls=113, dead_nil=44, final_expr=68, continuation=1,
                     guards=39, between=6),
    'macro': dict(calls=14, dead_nil=1, final_expr=13, continuation=0,
                  guards=1, between=0),
}


def survey():
    ok = True
    for key, path in PATHS.items():
        text = open(path).read()
        lines = text.split('\n')
        calls = find_ex_fail_calls(text)
        classes = [classify_call(text, s) for s in calls]
        from collections import Counter
        cnt = Counter(classes)
        # guards: all is_nil(ex_err) lines minus the ex_fail body line
        # minus the ex_run triple (detected by ex_run_region)
        all_iso = [i + 1 for i, l in enumerate(lines)
                   if re.search(r'if is_nil\(ex_err\)', l)]
        body_line = None
        for i, l in enumerate(lines):
            if re.match(r'\s*fn ex_fail\(', l):
                body_line = i + 2  # the body is the next line
                break
        a, b = ex_run_region(text)
        ex_run_lines = set(range(a, b + 1)) if a else set()
        guard_list = [g for g in all_iso
                      if g != body_line and g not in ex_run_lines]
        shapes = guard_shapes(text, guard_list)
        shape_cnt = Counter(s for _, s in shapes)
        between = between_guard_lines(text)
        exp = SURVEY_EXPECT[key]
        print('===== %s (%s) =====' % (key, path))
        print(' ex_fail calls: %d (expect %d) %s' % (
            len(calls), exp['calls'],
            'OK' if len(calls) == exp['calls'] else 'MISMATCH'))
        print('   dead-nil=%d (expect %d) %s' % (
            cnt.get('dead-nil', 0), exp['dead_nil'],
            'OK' if cnt.get('dead-nil', 0) == exp['dead_nil'] else 'MISMATCH'))
        print('   final-expr=%d (expect %d) %s' % (
            cnt.get('final-expr', 0), exp['final_expr'],
            'OK' if cnt.get('final-expr', 0) == exp['final_expr'] else 'MISMATCH'))
        print('   continuation=%d (expect %d) %s' % (
            cnt.get('continuation', 0), exp['continuation'],
            'OK' if cnt.get('continuation', 0) == exp['continuation'] else 'MISMATCH'))
        anomalies = [c for c in classes if c.startswith('anomaly')]
        if anomalies:
            ok = False
            print('   ANOMALIES: %r' % anomalies)
        print(' guards: %d (expect %d) %s; shapes=%s' % (
            len(guard_list), exp['guards'],
            'OK' if len(guard_list) == exp['guards'] else 'MISMATCH',
            dict(shape_cnt)))
        for g, s in shapes:
            if s.startswith('ANOMALY'):
                ok = False
                print('   guard ANOMALY @%d: %s' % (g, s))
        print(' between-helper guards: %d (expect %d) %s' % (
            len(between), exp['between'],
            'OK' if len(between) == exp['between'] else 'MISMATCH'))
        for b_ in between:
            print('   between @%d: %s' % (b_, lines[b_ - 1].strip()))
        # ex_run region assert (expander only — macro has no ex_run)
        a, b = ex_run_region(text)
        if a is None:
            if key == 'expander':
                ok = False
                print(' EX_RUN REGION NOT FOUND')
        else:
            region = '\n'.join(lines[a - 1:b])
            if region != EX_RUN_OLD:
                ok = False
                print(' EX_RUN REGION MISMATCH — anchors differ:')
                import difflib
                for d in difflib.unified_diff(EX_RUN_OLD.split('\n'),
                                              region.split('\n'), lineterm=''):
                    print('   ' + d)
            else:
                print(' ex_run triple-check region: OK (%d-%d)' % (a, b))
        # frozen anchors
        if key == 'expander' and FROZEN_TAIL not in lines:
            ok = False
            print(' FROZEN TAIL MISSING')
        if EX_FAIL_BODY_OLD not in text:
            ok = False
            print(' EX_FAIL BODY ANCHOR MISSING')
        if STATE_COMMENT_OLD not in text and key == 'expander':
            ok = False
            print(' STATE COMMENT ANCHOR MISSING')
        print(' paren balance: %d' % paren_balance(lines))
        wide = [i + 1 for i, l in enumerate(lines) if len(l) > 100]
        if wide:
            ok = False
            print(' WIDTH >100 at %r' % wide[:5])
        print(' non-ASCII set: %r' % sorted(non_ascii_set(text)))
    print('SURVEY: %s' % ('ALL OK' if ok else 'MISMATCHES PRESENT'))
    return 0 if ok else 1


def dedent_block(block_lines):
    out = []
    for l in block_lines:
        if l.startswith('    '):
            out.append(l[4:])
        elif l == '':
            out.append(l)
        else:
            out.append(l)
    return out


def pass1_edits(key, text):
    """Pass 1 (call sites + body + define + ex_run): every edit is
    on distinct lines — the ex_fail close/nil pairs, the bodies, the
    defines, the ex_run region. Guards are NOT touched here (their
    regions contain call sites; the guards dissolve in pass 2 over
    the post-pass-1 text)."""
    lines = text.split('\n')
    edits = []

    # --- M66: the ex_err cell define retires
    for i, l in enumerate(lines):
        if l == 'define(ex_err, nil);':
            edits.append((i + 1, i + 1, []))
            break
    else:
        sys.exit('M66: define(ex_err, nil); not found in %s' % PATHS[key])

    # --- M59: the ex_fail body
    body_idx = None
    for i, l in enumerate(lines):
        if re.match(r'\s*fn ex_fail\(', l):
            body_idx = i
            break
    if body_idx is None:
        sys.exit('M59: fn ex_fail not found in %s' % PATHS[key])
    if lines[body_idx + 1] != '    if is_nil(ex_err) { set(ex_err, pair("err", tail)) } else { nil }':
        sys.exit('M59: ex_fail body anchor mismatch in %s: %r'
                 % (PATHS[key], lines[body_idx + 1]))
    edits.append((body_idx + 2, body_idx + 2,
                  ['    perform raise(pair("err", tail))']))

    # --- M60/M62: the call sites
    calls = find_ex_fail_calls(text)
    for site in calls:
        cls = classify_call(text, site)
        start_ln, close = site
        if cls == 'dead-nil':
            close_text = lines[close - 1]
            m = re.match(r'^(.*?)\)\s*;$', close_text)
            if not m:
                sys.exit('M60: dead-nil close line lacks `;` @%d: %r'
                         % (close, close_text))
            new_close = m.group(1) + ')'
            if not re.fullmatch(r'\s*nil', lines[close]):
                sys.exit('M60: dead-nil nil line missing @%d: %r'
                         % (close + 1, lines[close]))
            edits.append((close, close + 1, [new_close]))
        elif cls == 'continuation':
            close_text = lines[close - 1]
            m = re.match(r'^(.*?)\)\s*;$', close_text)
            if not m:
                sys.exit('M62: cannot strip `;` @%d: %r' % (close, close_text))
            new_close = m.group(1) + ')'
            edits.append((close, close + 1, [new_close]))
        elif cls == 'final-expr':
            pass
        else:
            sys.exit('call-site classification anomaly @%d: %s' % (start_ln, cls))

    # --- M65: the ex_run triple check (expander only)
    if key == 'expander':
        a, b = ex_run_region(text)
        if a is None:
            sys.exit('M65: ex_run region not found')
        region = '\n'.join(lines[a - 1:b])
        if region != EX_RUN_OLD:
            sys.exit('M65: ex_run region anchor mismatch')
        edits.append((a, b, EX_RUN_NEW.split('\n')))

    return edits


def pass2_dissolve(key, text):
    """Pass 2 (guards), iterative leaf-first: wrapper guards (ex_expand's
    entry guard spans ~1,950 lines) contain dozens of inner guards; a
    container's kept WORK must be captured from the CURRENT text, so
    each round dissolves only the leaf guards (no other guard region
    strictly inside), re-derives, and repeats until zero remain."""
    for round_no in range(1, 60):
        lines = text.split('\n')
        glist = [i + 1 for i, l in enumerate(lines)
                 if re.search(r'if is_nil\(ex_err\)', l)]
        blist = between_guard_lines(text)
        if not glist and not blist:
            return text

        # regions: (first, last, kind, payload)
        regions = []
        for g in glist:
            head = lines[g - 1]
            if re.search(ONE_LINER, head):
                regions.append((g, g, 'one-liner', head))
                continue
            if not re.fullmatch(r'\s*if is_nil\(ex_err\) \{', head):
                sys.exit('M63: guard head anomaly @%d: %r' % (g, head))
            end, _ = guard_end(lines, g)
            if end is None:
                sys.exit('M63: guard unclosed @%d' % g)
            regions.append((g, end, 'walk', head))
        for bg in blist:
            head = lines[bg - 1]
            if not re.fullmatch(r'\s*if not\(is_nil\(ex_err\)\) \{', head):
                sys.exit('M64: between guard head mismatch @%d: %r' % (bg, head))
            joiner = lines[bg + 1]
            m = re.match(r'^(\s*)\} else (.*)$', joiner)
            if not m:
                sys.exit('M64: between guard joiner mismatch @%d: %r' % (bg, joiner))
            if m.group(2).startswith('if'):
                regions.append((bg, bg + 2, 'B1', joiner))
            elif m.group(2) == '{':
                end2, _ = guard_end(lines, bg)
                if end2 is None:
                    sys.exit('M64: B2 guard unclosed @%d' % bg)
                regions.append((bg, end2, 'B2', joiner))
            else:
                sys.exit('M64: between guard joiner shape @%d: %r' % (bg, joiner))

        def contains(outer, inner):
            return (outer[0] < inner[0] and inner[1] < outer[1])

        leaves = [r for r in regions
                  if not any(contains(o, r) for o in regions if o is not r)]
        if not leaves:
            sys.exit('pass2 round %d: no leaves but %d regions remain'
                     % (round_no, len(regions)))

        edits = []
        for first, last, kind, head in leaves:
            if kind == 'one-liner':
                m = re.search(ONE_LINER, head)
                indent = re.match(r'(\s*)', head).group(1)
                edits.append((first, first, [indent + m.group(1)]))
                continue
            if kind == 'B1':
                m = re.match(r'^(\s*)\} else (.*)$', head)
                edits.append((first, last, [m.group(1) + m.group(2)]))
                continue
            if kind == 'B2':
                # the kept else-arm WORK: 1-based (first+3)..(last-1)
                # — excludes the joiner line AND the final close
                work = lines[first + 2:last - 1]
                edits.append((first, last, dedent_block(work)))
                continue
            # walk guard: keep the THEN-arm content
            indent = re.match(r'(\s*)', head).group(1)
            else_line = None
            for j in range(first + 1, last):
                if re.fullmatch(re.escape(indent) + r'\} else \{', lines[j - 1]):
                    else_line = j
                    break
            if else_line is not None:
                then_work = lines[first:else_line - 1]
                else_arm = lines[else_line:last]     # 1-based (else_line+1)..last
                # 0-based slice upper `last` = 1-based last — hmm:
                # else content = 1-based (else_line+1)..(last-1)
                if any('ex_fail(' in l for l in else_arm[:-1]):
                    sys.exit('M63: dropped else arm carries ex_fail @%d' % first)
                edits.append((first, last, dedent_block(then_work)))
            else:
                then_work = lines[first:last - 1]
                edits.append((first, last, dedent_block(then_work)))
        text = apply_edits(text, edits)
    sys.exit('pass2: exceeded 60 rounds — non-terminating dissolve')


def apply_edits(text, edits):
    lines = text.split('\n')
    edits.sort(key=lambda e: e[0])
    for first, last, repl in reversed(edits):
        lines[first - 1:last] = repl
    return '\n'.join(lines)


def apply():
    for key, path in PATHS.items():
        text = open(path).read()
        text = apply_edits(text, pass1_edits(key, text))
        text = pass2_dissolve(key, text)

        # --- M67/M71: the comments (text-level replacements)
        if key == 'expander':
            if STATE_COMMENT_OLD not in text:
                sys.exit('M67: state comment anchor missing post-apply')
            text = text.replace(STATE_COMMENT_OLD, STATE_COMMENT_NEW)
            hdr_anchor = '// gray-cycle path slice to the byte.'
            if hdr_anchor not in text:
                sys.exit('M67: header anchor missing')
            text = text.replace(
                hdr_anchor,
                hdr_anchor + '\n' + HEADER_NOTE_EXPANDER.rstrip('\n'), 1)
            sem_old = ('(first error in evaluation order wins — the error cell records\n'
                       '// the first rejection and everything after unwinds into discarded\n'
                       '// values; §9.47.3\'s seven span traps are mirrored one by one):')
            sem_new = ('(first error in evaluation order wins — the one-shot raise\n'
                       '// carries the first rejection straight to the top-level attempt;\n'
                       '// §9.47.3\'s seven span traps are mirrored one by one):')
            if sem_old not in text:
                sys.exit('M67: error-semantics paragraph anchor missing')
            text = text.replace(sem_old, sem_new, 1)
            stale_doc = 'source-first, or nil on rejection (ex_err set).'
            if stale_doc not in text:
                sys.exit('M67: stale rejection doc anchor missing')
            text = text.replace(
                stale_doc,
                'source-first, or raises on rejection (the one-shot\n'
                '// raise rides ex_fail through this twin).', 1)
        else:
            hdr_anchor = "// Zero code changes this blade; the window's \u00a79.6 map carries the\n// two rows (M55'/M56')."
            if hdr_anchor not in text:
                sys.exit('M71: macro header anchor missing')
            text = text.replace(
                hdr_anchor,
                hdr_anchor + '\n' + HEADER_NOTE_MACRO.rstrip('\n'), 1)
        write(path, text.split('\n'))
        print('APPLIED %s' % key)


def verify():
    ok = True
    bodies = {}
    for key, path in PATHS.items():
        text = open(path).read()
        lines = text.split('\n')
        print('===== VERIFY %s =====' % key)
        # zero ex_err references
        refs = [i + 1 for i, l in enumerate(lines)
                if 'ex_err' in l and not l.lstrip().startswith('//')]
        if refs:
            ok = False
            print(' FAIL: ex_err references remain at %r' % refs[:8])
        else:
            print(' OK: zero ex_err references')
        # call counts unchanged
        calls = find_ex_fail_calls(text)
        exp = SURVEY_EXPECT[key]['calls']
        if len(calls) != exp:
            ok = False
            print(' FAIL: ex_fail call count %d != %d' % (len(calls), exp))
        else:
            print(' OK: ex_fail call count %d' % len(calls))
        # zero residual dead-nil / guards / between
        for site in calls:
            cls = classify_call(text, site)
            if cls in ('dead-nil', 'continuation'):
                ok = False
                print(' FAIL: residual %s call @%d' % (cls, site[0]))
        for i, l in enumerate(lines):
            if re.search(r'if is_nil\(ex_err\)', l) or \
               re.search(r'if not\(is_nil\(ex_err\)\)', l):
                ok = False
                print(' FAIL: residual guard @%d: %s' % (i + 1, l.strip()))
        # frozen anchors
        if key == 'expander' and FROZEN_TAIL not in lines:
            ok = False
            print(' FAIL: frozen tail missing')
        else:
            print(' OK: frozen tail present')
        if EX_FAIL_BODY_NEW not in text:
            ok = False
            print(' FAIL: new ex_fail body missing')
        else:
            print(' OK: new ex_fail body present')
            bodies[key] = EX_FAIL_BODY_NEW
        # paren balance
        bal = paren_balance(lines)
        if bal != 0:
            ok = False
            print(' FAIL: paren balance %d' % bal)
        else:
            print(' OK: paren balance 0')
        # width
        wide = [i + 1 for i, l in enumerate(lines) if len(l) > 100]
        if wide:
            ok = False
            print(' FAIL: width>100 at %r' % wide[:6])
        else:
            print(' OK: width <= 100')
    if 'expander' in bodies and 'macro' in bodies:
        if bodies['expander'] != bodies['macro']:
            # shadow-pair discipline: identical bodies (the fn text
            # itself must match across the two files)
            ok = False
            print(' FAIL: shadow-pair bodies differ')
        else:
            print(' OK: shadow-pair bodies identical')
    # the ex_run contract face (expander)
    text = open(PATHS['expander']).read()
    if 'unwrap(attempt(|| {' not in text or "), ||(e) { e })" not in text:
        ok = False
        print(' FAIL: ex_run unwrap(attempt(..)) face missing')
    else:
        print(' OK: ex_run unwrap(attempt(..)) face present')
    print('VERIFY: %s' % ('ALL OK' if ok else 'FAILURES PRESENT'))
    return 0 if ok else 1


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else ''
    if mode == '--survey':
        sys.exit(survey())
    elif mode == '--apply':
        apply()
        sys.exit(verify())
    elif mode == '--verify':
        sys.exit(verify())
    else:
        sys.exit('usage: %s --survey | --apply | --verify' % sys.argv[0])

#!/usr/bin/env python3
# Blade-4 fidelity check: cp_ewalk old vs new. Body runs (lines
# between structural markers) must be char-identical after
# whitespace stripping; structural markers must pair per the
# if-chain -> match conversion rules. Width reflows only add
# whitespace, so runs may differ in line count but not in content.

import re

with open('/tmp/compiler.ktf.pre-blade4') as f:
    old_all = f.readlines()
start = next(i for i, l in enumerate(old_all) if l.rstrip('\n') == 'fn cp_ewalk(t, tail) {')
end = next(j for j in range(start + 1, len(old_all)) if old_all[j] == '}\n')
old = [l.rstrip('\n') for l in old_all[start:end + 1]]

with open('selfhost/v1/compiler.ktf') as f:
    new_all = f.readlines()
start2 = next(i for i, l in enumerate(new_all) if l.rstrip('\n') == 'fn cp_ewalk(t, tail: bool) {')
end2 = next(j for j in range(start2 + 1, len(new_all)) if new_all[j] == '}\n')
new = [l.rstrip('\n') for l in new_all[start2:end2 + 1]]

outer_hdr = re.compile(r'^        \} else if eq\(tag, "([a-z]+)"\) \{$')
inner_hdr = re.compile(r'^                \} else if eq\(tag, "([a-z]+)"\) \{$')
first_arm = re.compile(r'^        if eq\(tag, "awalk"\) \{$')
let_v = re.compile(r'^                let v = if eq\(tag, "var"\) \{$')


def classify_old(lines):
    out = []
    region = 'OUTER'
    for l in lines:
        s = l.strip()
        ind = len(l) - len(l.lstrip())
        if l == 'fn cp_ewalk(t, tail) {':
            out.append(('SIG', None))
        elif region == 'OUTER':
            if first_arm.match(l):
                out.append(('OPEN_OUTER', 'awalk'))
            elif outer_hdr.match(l):
                out.append(('ARM', outer_hdr.match(l).group(1)))
            elif l == '        } else {':
                out.append(('ELSE_OUTER', None))
                region = 'REAL'
            elif s == '}' and ind == 12:
                out.append(('CLOSE12', None))
            elif s == '}' and ind == 8:
                out.append(('CLOSE8', None))
            else:
                out.append(('BODY', s))
        elif region == 'REAL':
            if let_v.match(l):
                out.append(('OPEN_INNER', 'var'))
                region = 'INNER'
            elif s == '}' and ind == 12:
                out.append(('CLOSE12', None))
            else:
                out.append(('BODY', s))
        elif region == 'INNER':
            if inner_hdr.match(l):
                out.append(('ARM', inner_hdr.match(l).group(1)))
            elif l == '                } else {':
                out.append(('ELSE_INNER', None))
            elif l == '                };':
                out.append(('END_INNER', None))
                region = 'EPI'
            else:
                out.append(('BODY', s))
        else:
            if s == '}' and ind == 12:
                out.append(('CLOSE12', None))
            elif s == '}' and ind == 8:
                out.append(('CLOSE8', None))
            else:
                out.append(('BODY', s))
    return out


def classify_new(lines):
    out = []
    for l in lines:
        s = l.strip()
        if l == 'fn cp_ewalk(t, tail: bool) {':
            out.append(('SIG', None))
        elif l == '        match tag {' or l == '                    let v = match tag {':
            out.append(('MATCH', None))
        elif re.match(r'^            "([a-z]+)" => \{$', l):
            out.append(('ARM', re.match(r'^            "([a-z]+)" => \{$', l).group(1)))
        elif re.match(r'^                        "([a-z]+)" => \{$', l):
            out.append(('ARM', re.match(r'^                        "([a-z]+)" => \{$', l).group(1)))
        elif l == '            _ => {':
            out.append(('ELSE_OUTER', None))
        elif l == '                        _ => {':
            out.append(('ELSE_INNER', None))
        elif l == '                        },' or l == '            },':
            out.append(('ARMC', None))
        elif l == '                    };':
            out.append(('END_INNER', None))
        elif l == '                }':
            out.append(('CLOSE12', None))
        elif l == '        }':
            out.append(('CLOSE8', None))
        else:
            out.append(('BODY', s))
    return out


oc = classify_old(old)
nc = classify_new(new)


def toks(items):
    joined = ' '.join(it[1] for it in items if it[1])
    return re.sub(r'\s+', '', joined)


oi, ni = 0, 0
fails = 0
while oi < len(oc) or ni < len(nc):
    o_next = oi
    while o_next < len(oc) and oc[o_next][0] == 'BODY':
        o_next += 1
    n_next = ni
    while n_next < len(nc) and nc[n_next][0] == 'BODY':
        n_next += 1
    a = toks(oc[oi:o_next])
    b = toks(nc[ni:n_next])
    if a != b:
        k = 0
        while k < min(len(a), len(b)) and a[k] == b[k]:
            k += 1
        print('BODY-DIFF old@%d new@%d at char %d (%d vs %d)' % (oi, ni, k, len(a), len(b)))
        fails += 1
        break
    if o_next >= len(oc) and n_next >= len(nc):
        break
    ok = oc[o_next] if o_next < len(oc) else ('END', None)
    nk = nc[n_next] if n_next < len(nc) else ('END', None)
    paired = False
    if ok[0] == 'OPEN_OUTER' and nk[0] == 'MATCH' and n_next + 1 < len(nc) and nc[n_next + 1] == ('ARM', 'awalk'):
        o_next += 1
        n_next += 2
        paired = True
    elif ok[0] == 'OPEN_INNER' and nk[0] == 'MATCH' and n_next + 1 < len(nc) and nc[n_next + 1] == ('ARM', 'var'):
        o_next += 1
        n_next += 2
        paired = True
    elif ok[0] == 'ARM' and nk[0] == 'ARMC' and n_next + 1 < len(nc) and nc[n_next + 1] == ('ARM', ok[1]):
        o_next += 1
        n_next += 2
        paired = True
    elif ok[0] in ('ELSE_OUTER', 'ELSE_INNER', 'END_INNER') and nk[0] == 'ARMC' and n_next + 1 < len(nc) and nc[n_next + 1][0] == ok[0]:
        o_next += 1
        n_next += 2
        paired = True
    elif ok[0] == 'CLOSE8' and nk[0] == 'ARMC' and n_next + 1 < len(nc) and nc[n_next + 1][0] == 'CLOSE8':
        o_next += 1
        n_next += 2
        paired = True
    elif ok[0] == nk[0] and ok[1] == nk[1]:
        o_next += 1
        n_next += 1
        paired = True
    if not paired:
        print('STRUCT-MISMATCH old@%d %s new@%d %s' % (o_next, ok, n_next, nk))
        fails += 1
        break
    oi, ni = o_next, n_next

if fails == 0:
    print('FIDELITY OK (token-run level): every body run char-identical, every structural pair aligned')
    print('old lines: %d, new lines: %d' % (len(oc), len(nc)))
    raise SystemExit(0)
raise SystemExit(1)

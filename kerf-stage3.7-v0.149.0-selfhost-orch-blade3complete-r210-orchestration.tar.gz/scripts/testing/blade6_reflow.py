#!/usr/bin/env python3
"""blade6_reflow.py — pure-whitespace width convergence (<=100 cols).

The blade 6 arm-body indent migration (+4/+8) pushed constructor
calls over the 100-column bound (selfhost_format_guard invariant 1).
This pass splits them at token boundaries only (the r179 38-line
reflow precedent): every transformation here preserves the token
stream verbatim — splits happen at commas, no token is added,
removed, or reordered.

Two shapes are handled:
  1. constructor/statement calls `f(a1, rest...)` — hoist the first
     argument onto its own line, recursively, until every line fits;
  2. one-line match arms `"lit" => { expr },` — expand to block form
     then reflow the expression (the r177 arm-body-block law).
"""

from __future__ import annotations

import argparse
import re
import sys

WIDTH = 100



def code_part(line):
    """Line minus comment suffix, string bodies removed (r180:
    comments carrying braces/parens must never reach the counters)."""
    out = []
    in_str = False
    for i, ch in enumerate(line):
        if in_str:
            if ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            continue
        if ch == "/" and i + 1 < len(line) and line[i + 1] == "/":
            break
        out.append(ch)
    return "".join(out)


def top_level_split(core):
    """Split `fname(arg1, rest...)` at the first depth-1 comma.
    Returns (fname, a1, rest) or None when unsplittable."""
    m = re.match(r'^([\w!?]+)\(', core)
    if not m:
        return None
    fname = m.group(1)
    depth = 0
    first_comma = None
    close_idx = None
    i = m.end() - 1  # position of the opening paren
    start = i + 1
    n = len(core)
    while i < n:
        ch = core[i]
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                close_idx = i
                break
        elif ch == "," and depth == 1 and first_comma is None:
            first_comma = i
        i += 1
    if close_idx is None:
        return None
    if first_comma is None:
        # single argument: descend one level if the argument is a call
        inner = core[start:close_idx].strip()
        sub = top_level_split(inner)
        if sub is None:
            return None
        return ("@" + fname, sub, None)  # marker: hoist inside single arg
    a1 = core[start:first_comma].strip()
    rest = core[first_comma + 1:close_idx].strip()
    return (fname, a1, rest)


def reflow_segment(line):
    """Reflow one line; returns a list of lines, all <=100 when
    possible."""
    if len(line) <= WIDTH:
        return [line]
    indent = re.match(r'^(\s*)', line).group(1)
    core = line.strip()
    tail = ""
    while core and core[-1] in ");,":
        # do not eat the call's own close paren: stop before the
        # last ')' when it closes the outermost call — handled by
        # splitting instead
        break
    # separate a trailing statement tail (semicolon/comma AFTER the
    # final close paren) — find the outermost call via split
    sp = top_level_split(core)
    if sp is None:
        return [line]
    if sp[0].startswith("@"):
        # single-arg call: descend into the argument
        fname = sp[0][1:]
        _sub = sp[1]
        m = re.match(r'^([\w!?]+)\(', core)
        open_paren = m.end() - 1
        close_idx = None
        depth = 0
        for i in range(open_paren, len(core)):
            if core[i] in "([{":
                depth += 1
            elif core[i] in ")]}":
                depth -= 1
                if depth == 0:
                    close_idx = i
                    break
        tail_txt = core[close_idx + 1:]
        inner = core[open_paren + 1:close_idx].strip()
        out = [f"{indent}{fname}("]
        out.extend(reflow_segment(f"{indent}    {inner}"))
        out.append(f"{indent}){tail_txt}")
        return join_and_reflow(out)
    fname, a1, rest = sp
    m = re.match(r'^([\w!?]+)\(', core)
    open_paren = m.end() - 1
    # find the outermost close for the tail
    depth = 0
    close_idx = None
    for i in range(open_paren, len(core)):
        if core[i] in "([{":
            depth += 1
        elif core[i] in ")]}":
            depth -= 1
            if depth == 0:
                close_idx = i
                break
    tail_txt = core[close_idx + 1:]
    out = [f"{indent}{fname}("]
    out.extend(reflow_segment(f"{indent}    {a1},"))
    out.extend(reflow_segment(f"{indent}    {rest}"))
    out.append(f"{indent}){tail_txt}")
    return join_and_reflow(out)


def join_and_reflow(lines):
    """Verify every produced line fits; reflow stragglers."""
    out = []
    for l in lines:
        if len(l) > WIDTH:
            out.extend(reflow_segment(l))
        else:
            out.append(l)
    return out


RE_ONELINE_ARM = re.compile(
    r'^(\s*)("(?:[\w!+/*<>=.?%-]+)"|\d+|_) => \{ (.+) \},$')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--dry", action="store_true")
    args = ap.parse_args()
    path = args.file
    lines = open(path).read().splitlines()
    out = []
    fixed = 0
    for line in lines:
        if len(line) <= WIDTH:
            out.append(line)
            continue
        m = RE_ONELINE_ARM.match(line)
        if m:
            indent, lit, expr = m.groups()
            arm = [f"{indent}{lit} => {{"]
            arm.extend(reflow_segment(f"{indent}    {expr}"))
            arm.append(f"{indent}}},")
            res = join_and_reflow(arm)
            if all(len(x) <= WIDTH for x in res):
                out.extend(res)
                fixed += 1
                continue
        res = reflow_segment(line)
        if all(len(x) <= WIDTH for x in res) and any(
                x.strip() for x in res):
            out.extend(res)
            fixed += 1
        else:
            out.append(line)  # give up on this line (hand reflow)
            print(f"MANUAL REFLOW NEEDED: {line}", file=sys.stderr)
    print(f"reflowed {fixed} lines; "
          f"remaining over-width: {sum(1 for x in out if len(x) > WIDTH)}")
    if not args.dry:
        open(path, "w").write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()

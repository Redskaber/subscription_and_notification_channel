#!/usr/bin/env python3
# Blade-5 surgical transformer: expander.ktf's three monster
# if-chains -> match (window doc §13 M41/M42/M43):
#   M41 outer: ex_expand's 9 synthetic-mode arms + `_` arm carrying
#          the depth guard and the real tree (bodies +4, real tree +8)
#   M42 inner: ex_expand's expression-head chain (10 arms + `_`
#          macro/application fallback, bodies +4 inside the +8 region)
#   M43: ex_decl's declaration-head chain (8 arms + `_` top-fail,
#          bodies +4)
# Bodies keep their expressions verbatim; only arm headers and
# indentation change. Two phases: inner chain first (original
# indents), then the outer chain (which shifts the whole real-tree
# region +8, carrying the already-transformed inner match along).

import re
import sys

PATH = 'selfhost/v1/expander.ktf'

with open(PATH) as f:
    lines = f.readlines()  # 0-based; file line N == lines[N-1]


def find_fn(name):
    for i, l in enumerate(lines):
        if l.rstrip('\n').startswith('fn %s(' % name):
            return i
    sys.exit('fn %s not found' % name)


def fn_end(start):
    for j in range(start + 1, len(lines)):
        if lines[j] == '}\n':
            return j
    sys.exit('fn close not found')


ex_expand_start = find_fn('ex_expand')
ex_expand_end = fn_end(ex_expand_start)          # ~2843 (0-based 2843-1)
ex_decl_start = find_fn('ex_decl')
ex_decl_end = fn_end(ex_decl_start)

# ------------------------------------------------------------------
# Phase 1: inner h-chain of ex_expand (M42), original indents.
#   chain head: `                        if eq(h, "quote") {` (24)
#   arm hdr:    `                        } else if eq(h, "X") {` (24)
#   else:       `                        } else {` (24)
#   close:      `                        }` (24)
# Bodies (indent 28+) shift +4. Everything between chain open and
# close that is not a header IS a body line (including nested
# closing braces at deeper indents).
# ------------------------------------------------------------------
inner_first = re.compile(r'^ {24}if eq\(h, "quote"\) \{$')
inner_arm = re.compile(r'^ {24}\} else if eq\(h, "([a-z!-]+)"\) \{$')
inner_else = '                        } else {'
inner_close = '                        }'

region = lines[ex_expand_start:ex_expand_end + 1]
out = []
i = 0
mode = 'pre'
while i < len(region):
    raw = region[i].rstrip('\n')
    if mode == 'pre':
        if inner_first.match(raw):
            out.append('                        match h {\n')
            out.append('                            "quote" => {\n')
            mode = 'arm'
        else:
            out.append(region[i])
    elif mode == 'arm':
        m = inner_arm.match(raw)
        if m:
            out.append('                            },\n')
            out.append('                            "%s" => {\n' % m.group(1))
        elif raw == inner_else:
            out.append('                            },\n')
            out.append('                            _ => {\n')
            mode = 'else'
        elif raw == inner_close:
            out.append('                            },\n')
            out.append('                        }\n')
            mode = 'post'
        else:
            out.append('    ' + region[i] if raw.strip() else region[i])
    elif mode == 'else':
        if raw == inner_close:
            out.append('                            },\n')
            out.append('                        }\n')
            mode = 'post'
        else:
            out.append('    ' + region[i] if raw.strip() else region[i])
    else:
        out.append(region[i])
    i += 1

lines[ex_expand_start:ex_expand_end + 1] = out

# ------------------------------------------------------------------
# Phase 2: outer chain of ex_expand (M41). Re-locate (phase 1
# changed the line count).
#   chain head: `        if eq(first(t), "mapx") {` (8)
#   arm hdr:    `        } else if eq(first(t), "X") {` (8)
#   guard:      `        } else if ex_depth >= ex_limit {` (8)
#   else:       `        } else {` (8)
#   close:      `        }` (8)
# Insert `let tag = first(t);` before the match. Synthetic arm
# bodies (indent 12) shift +4. The guard's `_` arm wraps the guard
# if/else; the real tree (guard-else body) shifts +8.
# ------------------------------------------------------------------
ex_expand_start = find_fn('ex_expand')
ex_expand_end = fn_end(ex_expand_start)

outer_first = re.compile(r'^        if eq\(first\(t\), "mapx"\) \{$')
outer_arm = re.compile(r'^        \} else if eq\(first\(t\), "([a-z]+)"\) \{$')
outer_guard = '        } else if ex_depth >= ex_limit {'
outer_else = '        } else {'
outer_close = '        }'

region = lines[ex_expand_start:ex_expand_end + 1]
out = []
i = 0
mode = 'pre'
while i < len(region):
    raw = region[i].rstrip('\n')
    if mode == 'pre':
        if outer_first.match(raw):
            out.append('        let tag = first(t);\n')
            out.append('        match tag {\n')
            out.append('            "mapx" => {\n')
            mode = 'arm'
        else:
            out.append(region[i])
    elif mode == 'arm':
        m = outer_arm.match(raw)
        if m:
            out.append('            },\n')
            out.append('            "%s" => {\n' % m.group(1))
        elif raw == outer_guard:
            out.append('            },\n')
            out.append('            _ => {\n')
            out.append('                if ex_depth >= ex_limit {\n')
            mode = 'guard'
        else:
            out.append('    ' + region[i] if raw.strip() else region[i])
    elif mode == 'guard':
        if raw == outer_else:
            out.append('                } else {\n')
            mode = 'real'
        else:
            out.append('        ' + region[i] if raw.strip() else region[i])
    elif mode == 'real':
        if raw == outer_close:
            out.append('                }\n')
            out.append('            },\n')
            out.append('        }\n')
            mode = 'post'
        else:
            out.append('        ' + region[i] if raw.strip() else region[i])
    else:
        out.append(region[i])
    i += 1

lines[ex_expand_start:ex_expand_end + 1] = out

# ------------------------------------------------------------------
# Phase 3: ex_decl h-chain (M43) — same shape as phase 1 but with
# `if eq(h, "define")` as the first arm and the "top" fail else.
# ------------------------------------------------------------------
ex_decl_start = find_fn('ex_decl')
ex_decl_end = fn_end(ex_decl_start)

decl_first = re.compile(r'^ {24}if eq\(h, "define"\) \{$')
decl_arm = re.compile(r'^ {24}\} else if eq\(h, "([a-z-]+)"\) \{$')

region = lines[ex_decl_start:ex_decl_end + 1]
out = []
i = 0
mode = 'pre'
while i < len(region):
    raw = region[i].rstrip('\n')
    if mode == 'pre':
        if decl_first.match(raw):
            out.append('                        match h {\n')
            out.append('                            "define" => {\n')
            mode = 'arm'
        else:
            out.append(region[i])
    elif mode == 'arm':
        m = decl_arm.match(raw)
        if m:
            out.append('                            },\n')
            out.append('                            "%s" => {\n' % m.group(1))
        elif raw == inner_else:
            out.append('                            },\n')
            out.append('                            _ => {\n')
            mode = 'else'
        elif raw == inner_close:
            out.append('                            },\n')
            out.append('                        }\n')
            mode = 'post'
        else:
            out.append('    ' + region[i] if raw.strip() else region[i])
    elif mode == 'else':
        if raw == inner_close:
            out.append('                            },\n')
            out.append('                        }\n')
            mode = 'post'
        else:
            out.append('    ' + region[i] if raw.strip() else region[i])
    else:
        out.append(region[i])
    i += 1

lines[ex_decl_start:ex_decl_end + 1] = out

with open(PATH, 'w') as f:
    f.writelines(lines)

# Width report: any line now exceeding 100 columns.
bad = [(n + 1, len(l.rstrip('\n'))) for n, l in enumerate(lines)
       if len(l.rstrip('\n')) > 100]
print('transform done; over-100 lines: %d' % len(bad))
for n, w in bad[:40]:
    print('  line %d width %d' % (n, w))

#!/usr/bin/env python3
"""The r200 blade-4 surgery on selfhost/v1/compiler.ktf (M50-M55 source side).

Line-range anchored, fully asserted: any anchor mismatch aborts before writing.
Edits apply bottom-up so earlier line numbers stay valid.
"""
import sys

PATH = "/home/z/kerf/selfhost/v1/compiler.ktf"

with open(PATH, "r", encoding="utf-8") as f:
    lines = f.readlines()  # 1-indexed via idx(n) = lines[n-1]

def idx(n):
    return lines[n - 1]

def expect(n, prefix):
    if not idx(n).startswith(prefix):
        print(f"ANCHOR FAIL line {n}: expected prefix {prefix!r}, got {idx(n)!r}")
        sys.exit(1)

TOTAL = len(lines)
assert TOTAL == 1968, f"unexpected line count {TOTAL}"

def replace_range(start, end, new_text):
    """Replace lines[start..end] (1-indexed inclusive) with new_text (a str
    with trailing newline, or '' to delete)."""
    global lines
    new_lines = new_text.splitlines(keepends=True) if new_text else []
    lines[start - 1:end] = new_lines

def dedent_block(start, end, n=4):
    for i in range(start - 1, end):
        if lines[i].startswith(" " * n):
            lines[i] = lines[i][n:]
        elif lines[i].strip() == "":
            pass
        else:
            print(f"DEDENT FAIL line {i+1}: {lines[i]!r}")
            sys.exit(1)

# ============================================================
# E23: cp_run (L1942-1966) — the unwrap(attempt(...)) contract face
# ============================================================
expect(1942, "fn cp_run(stream) {")
expect(1953, "        set(cp_err, nil),")
expect(1959, "        if is_nil(cp_err) {")
new_cp_run = """fn cp_run(stream) {
    unwrap(attempt(|| {
        do(
            set(
                cp_protos,
                pair(
                    cp_proto_make(nil, 0, 0, nil, nil, nil, nil, cp_estate_make(nil, nil, 0, 0)),
                    nil
                )
            ),
            set(cp_cur, 0),
            set(cp_cur_stack, nil),
            set(cp_globals, nil),
            set(cp_consts, nil),
            set(cp_depth, 0),
            set(cp_last_span, pair("0", pair("0", pair(0, nil)))),
            set(cp_externs, nil),
            set(cp_extern_names, nil),
            set(cp_arith_poison, nil),
            cp_ewalk(pair("mwalk", pair(cp_run_take(stream, nil), nil)), false),
            cp_emit("halt", 0, 0, cp_last_span),
            cp_finish()
        )
    }), ||(e) { e })
}
"""
replace_range(1942, 1966, new_cp_run)

# ============================================================
# E22: cp_finish (L1917-1936) — guard dissolves
# ============================================================
expect(1917, "fn cp_finish() {")
expect(1919, "    if is_nil(cp_err) {")
expect(1933, "    } else {")
new_cp_finish = """fn cp_finish() {
    cp_drain(cp_protos);
    pair(
        "ok",
        pair(
            pair("funcs", cp_proto_products(cp_protos)),
            pair(
                pair("globals", cp_rev(cp_globals, nil)),
                pair(
                    pair("consts", cp_rev(cp_consts, nil)),
                    pair(pair("externs", cp_rev(cp_externs, nil)), nil)
                )
            )
        )
    )
}
"""
replace_range(1917, 1936, new_cp_finish)

# ============================================================
# E21: cp_drain (L1900-1915) — raise + cp_9->cp_8
# ============================================================
expect(1900, "fn cp_drain(protos) {")
expect(1904, "        let at = cp_drain_scan(cp_rev(cp_estate_code(cp_9(first(protos))), nil), 0);")
expect(1911, '                pair("err", pair("unpatched-jump", pair(at, pair(cp_2(sp), pair(cp_3(sp), nil)))))')
new_cp_drain = """fn cp_drain(protos) {
    if is_nil(protos) {
        nil
    } else {
        let at = cp_drain_scan(cp_rev(cp_estate_code(cp_8(first(protos))), nil), 0);
        if is_nil(at) {
            cp_drain(rest(protos))
        } else {
            let sp = cp_nth(cp_rev(cp_estate_dbg(cp_8(first(protos))), nil), at);
            perform raise(pair(
                "err",
                pair("unpatched-jump", pair(at, pair(cp_2(sp), pair(cp_3(sp), nil))))
            ))
        }
    }
}
"""
replace_range(1900, 1915, new_cp_drain)

# ============================================================
# E20: cp_proto_products (L1847-1876) — shifts, product head stays
# ============================================================
expect(1847, "fn cp_proto_products(protos) {")
expect(1852, "        let e = cp_9(p);")
expect(1863, '                                pair("caps", cp_cap_srcs(cp_7(p))),')
old_block = "".join(idx(n) for n in range(1851, 1873))
new_block = """        let p = first(protos);
        let e = cp_8(p);
        pair(
            pair(
                "proto",
                pair(
                    first(p),
                    pair(
                        cp_2(p),
                        pair(
                            cp_3(p),
                            pair(
                                pair("caps", cp_cap_srcs(cp_6(p))),
                                pair(
                                    pair("code", cp_rev(cp_estate_code(e), nil)),
                                    pair(pair("dbg", cp_rev(cp_estate_dbg(e), nil)), nil)
                                )
                            )
                        )
                    )
                )
            ),
"""
replace_range(1851, 1872, new_block)

# ============================================================
# E19: cp_ewalk (L1278-1826) — wrapper dissolve + dedent + raises
# ============================================================
expect(1278, "fn cp_ewalk(t, tail: bool) {")
expect(1279, "    if is_nil(cp_err) {")
expect(1280, "        let tag = first(t);")
expect(1281, "        match tag {")
expect(1815, "        }")
expect(1816, "    } else {")
expect(1824, "        false")
expect(1826, "}")

# 19a: the three internal raise replacements on the ORIGINAL text first
body_text = "".join(idx(n) for n in range(1282, 1815))  # arms region L1282-1814

# depth block: the comment (L1527-1534) + do(...) (L1535-1551)
depth_old = "".join(idx(n) for n in range(1527, 1552))
depth_new = """                    perform raise(pair(
                        "err",
                        pair(
                            "depth",
                            pair(co_limit + 1, pair(co_limit, pair(cp_2(t), pair(cp_3(t), nil))))
                        )
                    ))
"""
assert body_text.count(depth_old) == 1, "depth block not unique"
body_text = body_text.replace(depth_old, depth_new)

# assign block: the set(...) (L1662-1674)
assign_old = "".join(idx(n) for n in range(1662, 1675))
assign_new = """                                            perform raise(pair(
                                                "err",
                                                pair(
                                                    "assign-to-captured",
                                                    pair(cp_4(t), pair(cp_2(t), pair(cp_3(t), nil)))
                                                )
                                            ))
"""
assert body_text.count(assign_old) == 1, "assign block not unique"
body_text = body_text.replace(assign_old, assign_new)

# bad-node: single line (L1808)
badnode_old = idx(1808)
badnode_new = "                            perform raise(pair(\"err\", pair(\"bad-node\", pair(tag, nil))))\n"
assert body_text.count(badnode_old) == 1, "bad-node line not unique"
body_text = body_text.replace(badnode_old, badnode_new)

# 19b: the ewalker's proto reads (4 sites): cp_5(cp_cur_proto()) -> cp_4
n_proto = body_text.count("cp_5(cp_cur_proto())")
assert n_proto == 4, f"expected 4 ewalker proto reads, found {n_proto}"
body_text = body_text.replace("cp_5(cp_cur_proto())", "cp_4(cp_cur_proto())")

# 19c: assemble the new fn — body dedented by 4
dedented = []
for ln in body_text.splitlines(keepends=True):
    if ln.startswith("    "):
        dedented.append(ln[4:])
    elif ln.strip() == "":
        dedented.append(ln)
    else:
        print(f"DEDENT FAIL (ewalk arm): {ln!r}")
        sys.exit(1)
new_ewalk = (
    "fn cp_ewalk(t, tail: bool) {\n"
    + "    let tag = first(t);\n"
    + "    match tag {\n"
    + "".join(dedented)
    + "    }\n"
    + "}\n"
)
replace_range(1278, 1826, new_ewalk)

# ============================================================
# E18: cp_set_b (L1199-1219) — wrapper dissolves
# ============================================================
expect(1199, "fn cp_set_b(at, b) {")
expect(1200, "    if is_nil(cp_err) {")
expect(1216, "    } else {")
new_set_b = """fn cp_set_b(at, b) {
    let e = cp_cur_estate();
    let i = (cp_estate_clen(e) - 1) - at;
    let insn = cp_nth(cp_estate_code(e), i);
    cp_set_estate(
        cp_estate_make(
            cp_replace_nth(
                cp_estate_code(e),
                i,
                pair(first(insn), pair(cp_2(insn), pair(b, nil)))
            ),
            cp_estate_dbg(e),
            cp_estate_depth(e),
            cp_estate_clen(e)
        )
    )
}
"""
replace_range(1199, 1219, new_set_b)

# ============================================================
# E17: cp_patch (L1125-1175) — wrapper dissolves + two raises
# ============================================================
expect(1125, "fn cp_patch(at: i64, target: i64) {")
expect(1126, "    if is_nil(cp_err) {")
expect(1172, "    } else {")
new_patch = """fn cp_patch(at: i64, target: i64) {
    let e = cp_cur_estate();
    let i = (cp_estate_clen(e) - 1) - at;
    let insn = cp_nth(cp_estate_code(e), i);
    if eq(cp_2(insn), 4294967295) {
        let expected = cp_3(insn);
        if eq(cp_estate_depth(e), expected) {
            cp_set_estate(
                cp_estate_make(
                    cp_replace_nth(
                        cp_estate_code(e),
                        i,
                        pair(first(insn), pair(target, pair(0, nil)))
                    ),
                    cp_estate_dbg(e),
                    cp_estate_depth(e),
                    cp_estate_clen(e)
                )
            )
        } else {
            perform raise(pair(
                "err",
                pair(
                    "stack-imbalance",
                    pair(
                        at,
                        pair(
                            expected,
                            pair(
                                cp_estate_depth(e),
                                pair(
                                    cp_2(cp_nth(cp_estate_dbg(e), i)),
                                    pair(cp_3(cp_nth(cp_estate_dbg(e), i)), nil)
                                )
                            )
                        )
                    )
                )
            ))
        }
    } else {
        perform raise(pair("err", pair("bad-patch", pair(at, nil))))
    }
}
"""
replace_range(1125, 1175, new_patch)

# ============================================================
# E16: cp_emit_jump (L1099-1116) — wrapper dissolves
# ============================================================
expect(1099, "fn cp_emit_jump(op: str, span) {")
expect(1101, "    if is_nil(cp_err) {")
expect(1112, "    } else {")
new_jump = """fn cp_emit_jump(op: str, span) {
    let pc = cp_emit(op, 4294967295, 0, span);
    let e = cp_cur_estate();
    let code = cp_estate_code(e);
    cp_set_estate(
        cp_estate_make(
            pair(pair(op, pair(4294967295, pair(cp_estate_depth(e), nil))), rest(code)),
            cp_estate_dbg(e),
            cp_estate_depth(e),
            cp_estate_clen(e)
        )
    );
    pc
}
"""
replace_range(1099, 1116, new_jump)

# ============================================================
# E15: cp_emit (L1047-1092) — wrapper dissolves + underflow raise
# ============================================================
expect(1047, "fn cp_emit(op: str, a: i64, b: i64, span) {")
expect(1048, "    if is_nil(cp_err) {")
expect(1089, "    } else {")
new_emit = """fn cp_emit(op: str, a: i64, b: i64, span) {
    let e = cp_cur_estate();
    let pops = cp_op_pops(op, a, b);
    if cp_estate_depth(e) < pops {
        // The span argument is a (start, end, gen) triple
        // (cp_span_of's product); the rejection payload carries
        // the first two — start and end, both offset strings.
        // r135: the first cut destructured positions 2/3 (end,
        // gen) — a latent misalignment exposed by the
        // method-JIT window's stack-effect tamper (the twin's
        // underflow path had never fired on well-formed
        // products); fixed to first/second per the Rust
        // rebuild's make_span contract.
        perform raise(pair(
            "err",
            pair(
                "stack-underflow",
                pair(cp_estate_clen(e), pair(first(span), pair(cp_2(span), nil)))
            )
        ))
    } else {
        let pc = cp_estate_clen(e);
        do(
            cp_set_estate(
                cp_estate_make(
                    pair(pair(op, pair(a, pair(b, nil))), cp_estate_code(e)),
                    pair(span, cp_estate_dbg(e)),
                    (cp_estate_depth(e) + cp_op_pushes(op)) - pops,
                    pc + 1
                )
            ),
            set(cp_last_span, span),
            pc
        )
    }
}
"""
replace_range(1047, 1092, new_emit)

# ============================================================
# E14: cp_resolves_outer (L641-644) — cp_8 -> cp_7
# ============================================================
expect(641, "fn cp_resolves_outer(name: str) -> bool {")
expect(642, "    let parent = cp_8(cp_cur_proto());")
replace_range(641, 644, """fn cp_resolves_outer(name: str) -> bool {
    let parent = cp_7(cp_cur_proto());
    if is_nil(parent) { false } else { cp_chain_holds(parent, name) }
}
""")

# ============================================================
# E13: cp_chain_holds (L628-639)
# ============================================================
expect(628, "fn cp_chain_holds(holder: i64, name: str) -> bool {")
replace_range(628, 639, """fn cp_chain_holds(holder: i64, name: str) -> bool {
    let p = cp_proto_get(holder);
    if cp_has_name(cp_4(p), name) {
        true
    } else if cp_has_name(cp_6(p), name) {
        true
    } else if is_nil(cp_7(p)) {
        false
    } else {
        cp_chain_holds(cp_7(p), name)
    }
}
""")

# ============================================================
# E12: cp_capture_in_cur (L589-623)
# ============================================================
expect(589, "fn cp_capture_in_cur(name: str) {")
replace_range(589, 623, """fn cp_capture_in_cur(name: str) {
    let k = cp_index_of(cp_6(cp_cur_proto()), name, 0);
    if is_nil(k) {
        let parent = cp_7(cp_cur_proto());
        if is_nil(parent) {
            nil
        } else {
            let src = cp_held_by(parent, name);
            if is_nil(src) {
                nil
            } else {
                do(
                    {
                        let c = cp_cur_proto();
                        cp_set_cur(
                            cp_proto_make(
                                first(c),
                                cp_2(c),
                                cp_3(c),
                                cp_4(c),
                                cp_5(c),
                                cp_append(cp_6(c), pair(pair(name, src), nil)),
                                cp_7(c),
                                cp_8(c)
                            )
                        )
                    },
                    cp_index_of(cp_6(cp_cur_proto()), name, 0)
                )
            }
        }
    } else {
        k
    }
}
""")

# ============================================================
# E11: cp_held_by (L544-584)
# ============================================================
expect(544, "fn cp_held_by(holder: i64, name: str) {")
replace_range(544, 584, """fn cp_held_by(holder: i64, name: str) {
    let p = cp_proto_get(holder);
    let slot = cp_assoc_slot(cp_4(p), name);
    if is_nil(slot) {
        let k = cp_index_of(cp_6(p), name, 0);
        if is_nil(k) {
            if is_nil(cp_7(p)) {
                nil
            } else {
                let src = cp_held_by(cp_7(p), name);
                if is_nil(src) {
                    nil
                } else {
                    do(
                        {
                            let h = cp_proto_get(holder);
                            cp_proto_set(
                                holder,
                                cp_proto_make(
                                    first(h),
                                    cp_2(h),
                                    cp_3(h),
                                    cp_4(h),
                                    cp_5(h),
                                    cp_append(cp_6(h), pair(pair(name, src), nil)),
                                    cp_7(h),
                                    cp_8(h)
                                )
                            )
                        },
                        pair("captured", cp_index_of(cp_6(cp_proto_get(holder)), name, 0))
                    )
                }
            }
        } else {
            pair("captured", k)
        }
    } else {
        pair("local", slot)
    }
}
""")

# ============================================================
# E10: cp_alloc_local (L520-535)
# ============================================================
expect(520, "fn cp_alloc_local() -> i64 {")
replace_range(520, 535, """fn cp_alloc_local() -> i64 {
    let p = cp_cur_proto();
    if is_nil(cp_5(p)) {
        cp_set_cur(
            cp_proto_make(first(p), cp_2(p), cp_3(p) + 1, cp_4(p), nil, cp_6(p), cp_7(p), cp_8(p))
        );
        cp_3(p)
    } else {
        cp_set_cur(
            cp_proto_make(
                first(p), cp_2(p), cp_3(p), cp_4(p), rest(cp_5(p)), cp_6(p), cp_7(p), cp_8(p)
            )
        );
        first(cp_5(p))
    }
}
""")

# ============================================================
# E9: cp_truncate (L500-518)
# ============================================================
expect(500, "fn cp_truncate(mark: i64) {")
replace_range(500, 518, """fn cp_truncate(mark: i64) {
    let p = cp_cur_proto(), n = cp_len(cp_4(cp_cur_proto()), 0);
    if n <= mark {
        nil
    } else {
        cp_set_cur(
            cp_proto_make(
                first(p),
                cp_2(p),
                cp_3(p),
                cp_drop(cp_4(p), n - mark),
                cp_append(cp_slots_of(cp_take_n(cp_4(p), n - mark)), cp_5(p)),
                cp_6(p),
                cp_7(p),
                cp_8(p)
            )
        )
    }
}
""")

# ============================================================
# E8: cp_mark (L492)
# ============================================================
expect(492, "fn cp_mark() -> i64 { cp_len(cp_5(cp_cur_proto()), 0) }")
replace_range(492, 492, "fn cp_mark() -> i64 { cp_len(cp_4(cp_cur_proto()), 0) }\n")

# ============================================================
# E7: cp_push_local (L476-490)
# ============================================================
expect(476, "fn cp_push_local(name, slot: i64) {")
replace_range(476, 490, """fn cp_push_local(name, slot: i64) {
    let p = cp_cur_proto();
    cp_set_cur(
        cp_proto_make(
            first(p),
            cp_2(p),
            cp_3(p),
            pair(pair(name, slot), cp_4(p)),
            cp_5(p),
            cp_6(p),
            cp_7(p),
            cp_8(p)
        )
    )
}
""")

# ============================================================
# E6: estate accessors (L450-464)
# ============================================================
expect(450, "fn cp_estate_make(code, dbg, edepth: i64, clen: i64) {")
expect(459, "fn cp_cur_estate() { cp_9(cp_cur_proto()) }")
replace_range(450, 464, """fn cp_estate_make(code, dbg, edepth: i64, clen: i64) {
    pair(code, pair(dbg, pair(edepth, pair(clen, nil))))
}

fn cp_estate_code(e) { first(e) }
fn cp_estate_dbg(e) { cp_2(e) }
fn cp_estate_depth(e) -> i64 { cp_3(e) }
fn cp_estate_clen(e) -> i64 { cp_4(e) }

fn cp_cur_estate() { cp_8(cp_cur_proto()) }

fn cp_set_estate(e) {
    let p = cp_cur_proto();
    cp_set_cur(cp_proto_make(first(p), cp_2(p), cp_3(p), cp_4(p), cp_5(p), cp_6(p), cp_7(p), e))
}
""")

# ============================================================
# E5: proto/estate layout comments + cp_proto_make (L399-430)
# ============================================================
expect(399, "// proto layout: (\"proto\" name params n-locals locals frees caps")
expect(413, "fn cp_proto_make(name, params, nlocals: i64, locals, frees, caps, parent, estate) {")
replace_range(399, 430, """// proto layout: (name params n-locals locals frees caps parent
// estate) — the bare eight-field value chain (the MODERN2 blade-4
// head drop: the "proto" discriminant tag was dead data — no match
// site ever checked it; the product render rebuilds the headed
// record). locals is a newest-first (name . slot) alist (the front
// is the innermost binding, mirroring Rust's rev-find), frees pops
// at the front (the LIFO face), caps is a first-use-order
// (name . src) alist (the product lands in exactly that order), and
// estate is the emission bookkeeping record.
//
// estate layout: (code dbg edepth clen) — the bare four-slot value
// chain (the same head drop — the "estate" tag was dead data).
// code is the newest-first instruction list ((op-name a b) ...),
// dbg the newest-first dense span list ((s e) ...), edepth the
// linear data-stack depth (i32, fail-closed against underflow),
// clen the code length (the pc of the next emit; newest-first
// conses make each emit O(1), the finish reverses once).

fn cp_proto_make(name, params, nlocals: i64, locals, frees, caps, parent, estate) {
    pair(
        name,
        pair(
            params,
            pair(
                nlocals,
                pair(
                    locals,
                    pair(frees, pair(caps, pair(parent, pair(estate, nil))))
                )
            )
        )
    )
}
""")

# ============================================================
# E4: cp_extern_walk duplicate arm (L369-385) — raise
# ============================================================
expect(369, "        if cp_is_member(name, cp_extern_names) {")
expect(375, "            do(")
expect(384, "            )")
new_dup = """        if cp_is_member(name, cp_extern_names) {
            // The r148 parity clearance: the rejection names the
            // GLOBAL table index of the repeating entry (the oracle's
            // own semantics — the cross-block table position), never
            // the within-block walk index (the r148 switch's
            // CLI-parity test caught the divergence).
            perform raise(pair(
                "err",
                pair("extern-name-duplicate", pair(cp_extern_n, pair(name, nil)))
            ))
        } else {
"""
replace_range(369, 385, new_dup)

# ============================================================
# E3: the error-cell block (L263-269) — retirement note
# ============================================================
expect(263, "// ---- the analysis state (single run per program; the error cell")
expect(269, "define(cp_err, nil);")
replace_range(263, 269, """// ---- the analysis state (single run per program; the compile
// rejections ride `perform raise` straight out of the walk — the
// one-shot unwinding to cp_run's attempt boundary replaces the
// first-error cell; post-raise state mutations are unobservable
// because the products render only on a clean run and the driver
// re-initializes everything per run)

define(cp_depth, 0);
""")

# ============================================================
# E2: accessor comment (L162-163)
# ============================================================
expect(162, "// ---- positional field accessors (records share the")
expect(163, "// (tag f2 f3 ...) shape; protos carry nine fields, estates five)")
replace_range(162, 163, """// ---- positional field accessors (records share the
// (tag f2 f3 ...) shape; protos carry eight fields, estates four
// — the MODERN2 blade-4 discriminant-head drop: the "proto" and
// "estate" tags were dead data, no match site ever checked them)
""")

# ============================================================
# E24: the result-define family note (after L101)
# ============================================================
expect(101, "//             break, reported as a harness defect by the host")
insert_at = 102
note24 = """//
// (MODERN2 blade 4: the rejection paths above ride `perform raise`
// with these records verbatim — cp_run's unwrap(attempt(...))
// boundary passes the raise payload through as the err product.)
"""
lines[insert_at:insert_at] = [l + "\n" for l in note24.splitlines()]

# ============================================================
# E1: header blade note (insert after L20)
# ============================================================
expect(19, "// stay honestly bare). The records stay cons-cell trees (the CP-1")
expect(20, "// flat-stream discipline — no struct declarations this blade).")
insert_at = 21
note = """//
// W-SELFHOST-MODERN-2 blade 4 (r200): the twin consumes the
// effect-family chain surface — the compile-rejection family rides
// `perform raise` with the CONTRACT error records verbatim (the
// one-shot unwinding replaces the first-error cell and the seven
// post-error guard arms), the estate/proto discriminant heads drop (the
// dead-tag representation cleanup; the product render rebuilds
// the "proto" head — the Rust-reader boundary M49 keeps the
// consumption in the bare-value-chain + nested-pair form), and
// cp_run rides unwrap(attempt(thunk), identity) — the ok/err
// records byte-frozen (the window's mapping table §9.6 M50-M58).
"""
lines[insert_at:insert_at] = [l + "\n" for l in note.splitlines()]

# ============================================================
# Verification: width, non-ASCII, bracket balance, residual checks
# ============================================================
out = "".join(lines)
probs = []
for i, ln in enumerate(out.splitlines(), 1):
    if len(ln) > 100:
        probs.append(f"WIDTH {i}: {len(ln)} cols: {ln[:60]}...")
for i, ln in enumerate(out.splitlines(), 1):
    for ch in ln:
        if ord(ch) > 127 and ch not in ("—", "§"):
            probs.append(f"NONASCII {i}: {ch!r}")

# bracket balance outside strings/comments (simple state machine)
state = "code"
bal = 0
for ch in out:
    if state == "code":
        if ch == '"':
            state = "str"
        elif ch == "/" :
            state = "maybe_comment"
        elif ch in "([{":
            bal += 1
        elif ch in ")]}":
            bal -= 1
    elif state == "maybe_comment":
        if ch == "/":
            state = "comment"
        else:
            state = "code"
            if ch in "([{":
                bal += 1
            elif ch in ")]}":
                bal -= 1
    elif state == "comment":
        if ch == "\n":
            state = "code"
    elif state == "str":
        if ch == '"':
            state = "code"
if bal != 0:
    probs.append(f"BRACKET BALANCE {bal}")

# residual checks
for i, ln in enumerate(out.splitlines(), 1):
    if "cp_err" in ln:
        probs.append(f"RESIDUAL cp_err line {i}: {ln.strip()[:80]}")
if "is_nil(cp_err)" in out:
    probs.append("RESIDUAL is_nil(cp_err)")
if 'pair(\n        "proto"' in out.replace("    ", "    "):
    pass  # product render keeps its head — checked below
if out.count('pair("caps"') != 1:
    # one in cp_proto_products
    probs.append("caps site count drift")

new_count = len(out.splitlines())
print(f"new line count: {new_count}")
if probs:
    print("PROBLEMS:")
    for p in probs:
        print(" -", p)
    sys.exit(1)

with open(PATH, "w", encoding="utf-8") as f:
    f.write(out)
print("SURGERY OK — all anchors matched, all checks green")

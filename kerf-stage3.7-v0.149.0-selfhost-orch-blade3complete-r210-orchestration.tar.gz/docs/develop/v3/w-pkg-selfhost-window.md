# W-PKG-SELFHOST 包管理器自举窗——判据实证 + 承载裁定 + 刀序（w-pkg-selfhost-window.md）

> **Status**: **CLOSED @ r160（v2.0——刀 4 交付 + 出口条件四条全 ✓ + G5 闭合入账）**：①kerf-pkg 逻辑面五模块 .ktf 孪生全承载（刀 1 micro-toml r156 + 刀 2 semver/manifest r157 + 刀 3a lockfile r158 + 刀 3b resolve+kp 接线 r159）+ kp 生产位 = 孪生臂（r159 三态带 unset 默认）②Rust 逻辑臂退役为构建引导回退带（r160——kerf-pkg lib.rs 退役声明落档：Rust 五模块 = KERF_PKG_SELFHOST=rust 回退位 + parity oracle；IO 壳与深度护栏 = 宿主服务面宪制位）+ 三态回退带红绿验证在档（r159 前置 + r160 语料面维持）③**全语料回归（r160 补全）**：kp_corpus_tests 7 测试（pkg_window 命名语料的缺位五族 + 三环/冲突菱形两变体面——双臂 stdout/stderr/exit 逐位）+ pkg_window 8/8 + parity 31 驱动（新增 conflict-mid-list 边界钉）+ audit AI 10 案维持 ④G5 闭合入账（bootstrap-completion-plan v1.22 §2 G5 行终态 + §3 序 5 出口行 + tech-debt PKG-2 终账）+ 自举矩阵刷新（余 G6——W-EVAL-RETIRE 行权 = 下一窗，T-a 触发器 r149 已达成）。**r160 当轮清偿（语料回归的价值兑现）**：孪生 conflict 面中位违例缺陷——`rs_check_imposed` 递归携带 `rest(imposed)` 致违例在表中位时 `rs_err_conflict` 只收到尾段（oracle 语义 = 整表抛出 PKG-3「every constraint listed」）；r159 parity 案例巧合全绿（conflict-diamond 夹具违例恰在首位）；修复 = 全表透传参 `all` + parity 补钉 conflict-mid-list 案例钉死边界（§20.3 同类路径全量：.ktf 族「递归走表抛错丢前缀」形态唯一——cycle 栈位语义正确、余错误携带标量）；台账改账 resolve.ktf 473→478（17,149→17,154）+ 金链 v0.118.0。历史：v1.4（r159 刀 3 后半）→ v1.3（r158 刀 3 前半 + TD-030 误诊改判）→ v1.2（r157 刀 2）→ v1.1（r156 刀 1）→ v1.0（r155 开窗：判据机检三面全绿〔§7 反冻结改写判据超额 N=7≥5〕+ 承载裁定 = 分刀 .ktf 承载〔ARCH-A 六论据〕+ 四刀序落档）
> **流程权威**: docs/sop.md（§21.12-28① 串行自举段序 / §21.12-33 子代理派遣 / §12 最优>最小 / §2.3-4 报错>静默 / §18 零新依赖）
> **依据**: bootstrap-completion-plan.md §3 序 5 + §7 反冻结改写判据单源（r135 裁定）/ w3.10-package-window.md（PKG-1..3 设计单源 + §5 触发器登记位）/ stage0.md §9.73（EVL-1 BuiltinHost 单源）/ K161（opam 语言无关解耦先例）/ K162（深度护栏 kp 双生面）/ K15（差分 oracle 理论）/ R5（脚手架完整生命周期纪律）

## 1. 开窗判据机检（§7 反冻结改写判据——三面实证，r155）

r115 PKG-2 原双前置 =「融合刀交付（✓ r134）」+「功能冻结」；r135 ARCH-A 反冻结重审将前置二改写为「**manifest 子集实证稳定**」（判据 = kerf.toml/kerf.lock 文法与 semver 边界最近 N≥5 轮零变更 + pkg 语料回归全绿——可机检锚，非政策性冻结）。r155 机检实况：

| 判据面 | 机检方法 | 实证结果 |
|---|---|---|
| ① 文法与边界零变更 | `git diff 2097c93..HEAD -- crates/kerf-pkg/`（r147 闭合态 v0.108.0 → r154 v0.113.0 全历史直接对照——两次灾备重奠基压缩历史的诚实替代法） | **零输出** = 内容级零变更；跨度 = r148/r149/r150/r151/r152/r153/r154 **七轮**（六次版本发布）——N=7 ≥ 5 超额满足 |
| ② pkg 语料回归 | `cargo test --test runner -- pkg_window`（W-3.10 集成族） | **8/8 全绿**（0.00s——两包 e2e / 传递链 / 环检测 / 菱形冲突 / lockfile 往返 + 负向三族） |
| ③ 单元与审计面 | `cargo test -p kerf-pkg` + audit AI 节 | **41/41 全绿**（micro_toml 正负 / semver caret 边界 / manifest 必填 / lockfile 幂等）+ audit AI 10 案（460/460 实跑内含——r154 记录在档） |

**判据结论**：开窗条件满足——§7 重审设计意图（防自举一个文法仍在变动的包管理器 = 防返工面）已消散：文法面七轮冻结于稳定态，回归全绿，返工风险不在。

## 2. 消费面勘定（承载裁定的证据基座）

### 2.1 kerf-pkg 现态（七模块 1,963 行——lib 六模块 1,860 + kp 壳 103）

| 模块 | 行数 | 职责（w3.10 §3 设计单源投影） |
|---|---|---|
| `micro_toml.rs` | 468 | TOML-micro 严格子集：注释/空行/`key = "str"`/`key = int`/`[section]`/`[[array]]` 六接受形 + 全域 fail-closed 拒绝（行:列 span；错误族：unclosed quote / unknown form / duplicate key / trailing garbage） |
| `manifest.rs` | 267 | kerf.toml 投影：`Manifest{package, version, depends}`；必填校验 + 未知键/节 fail-closed + kebab-case 包名 |
| `semver.rs` | 219 | `Version{major,minor,patch}` X.Y.Z 全形解析 + caret 边界（major≥1 比主版本 / major=0 比 minor——Cargo 惯例） |
| `lockfile.rs` | 324 | kerf.lock 模型 + 确定性序列化（BTreeMap 名序 + 固定键序 + LF 尾换行；`serialize(parse(serialize(x))) == serialize(x)` 幂等断言） |
| `resolve.rs` | 291 | 依赖图解析：根 manifest → 递归 libs/<name> → 三色 DFS 环检测（Gray 栈回溯成环路径）→ 后序拓扑（依赖先于依赖者）+ 菱形全约束汇总 |
| `error.rs` | 145 | PkgError 独立错误族（工具链域隔离 §11——不入编译器 E0xxx 注册表） |
| `main.rs`（kp bin） | 103 | `kp resolve <dir>` 单命令 + `KERF_PKG_RESOLVE_DEPTH_LIMIT` 深度护栏（K162——compiler CLI `DepthLimits::from_env` 的 kp 双生：fail-closed 非法值即拒） |

### 2.2 外部消费位（退役面勘定——刀 4 红线基线）

- **唯一 crate 外消费位** = 根 `src/lib.rs` 泛化 re-export（`pub use kerf_pkg as pkg`）——crate 级聚合非 pkg 特有（w3.6 档传递性分账同款形态）；
- `tests/v1/stage1/plan/pkg_window_tests.rs`（集成 8）+ `crates/kerf-pkg/src` 内嵌单元 41 + `examples/audit` AI 节 10 = 测试面全量；
- **driver 消费接线未发生**（w3.10 §5 登记位：多包编译接入触发器 = 模块系统多包需求——未点火）——承载迁移的接口爆炸面**当前为零**（窗口时机最优：消费者只有测试与 kp 壳）。

### 2.3 表达力先例（承载可行性——零新内建路径）

**target-lexer.ktf L14 入口形制**：`define(source_bytes, quote((104, 101, 108, 108, 111, ...)))` ——源文本以**字节整数表**进入 .ktf 程序，逐字节扫描（car/cdr/cons + 算术 + compare）全在冻结子集内；关键字匹配 = 字节表常量对照（`tl_w_fn = quote((102, 110))` 先例）。推论：

1. micro-TOML 文法复杂度 << kerf 语言文法（六接受形 vs 完整语言）——target-lexer 3,000+ 行字节机已证明更难的事；
2. 纯逻辑面（semver 三元组比较 / 三色 DFS / 拓扑排序 / 确定性序列化）= 整数与表运算，子集完全覆盖；
3. 文件 IO = kp Rust 壳承担（读盘→字节表进 / 结构→渲染写盘出——K20 桥形态先例）；
4. **零新内建、零新原语**（8 原语不变性维持；BuiltinHost 18 臂 registry 零扩展；§18 零新依赖）。

## 3. 承载裁定（出口二选一——ARCH-A @ r155）

**裁定 = 分刀 .ktf 承载（选项 A 形态，四刀序，每刀 parity 安全网）**；否决「维持构建引导层宪制位（选项 B）」。论据：

1. **用户指令⑩完成标准精神**：「自举阶段应该充分完成各个阶段的自举（完成标准：完全脱离宿主语言，通过自身语言来进行自举后所有阶段的设计和开发）」——包管理器是 kerf 程序生态的组成阶段，维持 Rust = 该阶段永久宿主依赖（与 VM 永久 Rust 基座不同：VM 是宪制排除项〔R5 明文〕，kerf-pkg 无宪制排除地位——它是 W-3.10 交付的工具层，非语言基座）；
2. **判据已超额满足**（§1——七轮零变更）：K161（opam 语言无关）先例被超越性满足——opam 是「可以不自举」的许可，不是「必须不自举」的禁令；返工风险消散后，自举优于维持（§12 最优>最小）；
3. **C1-C4 ✓ + G7 ✓**（自举链四段生产位就位 + S-expr 四层全拆）：.ktf 承载的 kerf-pkg 可被自举链自身编译验证——「自己用自己语言推进自己」闭环的包管理器环节；
4. **表达力零缺口**（§2.3——字节表先例 + 纯逻辑子集覆盖 + 零新内建）；
5. **接口爆炸面为零的时机窗口**（§2.2——driver 未接线）：迁移成本 = 历史最低点；晚于 driver 接线后迁移 = 消费面扩张后成本单调上升；
6. **G5 真闭合优于裁定闭合**：自举矩阵完成标准（§1 C1-C4 + G5/G6 清账）中 G5 以「.ktf 承载」闭合 = 判据可机检的终态（vs「裁定维持」= 政策性豁免——§7 反冻结同款逻辑：可机检锚优于政策性口号）。

**分刀安全网**（W-SEXP-RETIRE 序 4 技术理由同款：大迁移需要双臂 parity 安全网在场）：每刀交付 .ktf 孪生 + Rust 臂在位 + K15 差分 oracle 全绿——迁移验证成本结构性受控；Rust 逻辑臂退役（刀 4）时 kp 壳与深度护栏保留（K162 面 = 壳层职责非逻辑层职责）。

## 4. 四刀序（fine MUV——每刀全链交付 + GATE 1 六命令 + audit 实跑）

| 刀 | MUV | 内容 | 集成验证 | 排期 |
|---|---|---|---|---|
| 1 | 155+1（r156）✅ 交付 | **micro-toml.ktf 孪生**：字节表输入 → Document pair 结构（globals/entries/items 六形全族）+ span（行:列整数对）+ 错误族**实交 16 枚 kind 全镜像**（oracle micro_toml.rs 全部 format! 模板逐位复刻——超出原列四枚的规划粒度，oracle 实面为准 §8.4.5）+ **parity 驱动**（Rust `micro_toml::parse` vs .ktf 孪生差分对——三方〔oracle == twin-vm == twin-eval〕48 案例〔12 正 + 36 负 = 1:3〕全绿） | parity 全绿 ✓（48/48）+ 孪生行数台账入账（s-expr-conversion-record §3 r156 行——八件 15,219）+ GATE 6 正负比 ✓（1:3） | r156 ✅ |
| 2 | 155+2 ✅ 交付 | **semver.ktf + manifest.ktf 孪生**：双信道 RS-1（con_bytes/ver_bytes）+ u64::from_str 逐位镜像 + i64 正域边界披露；组合程序（micro-toml+semver+manifest 三件拼接，define 顺序重绑定）；oracle 五步投影序 + BTreeMap 名序（插入排序）+ span 偏移回移 + 语法透传（render_mt_error 单源复用）+ 三负向族 15 负 + 嵌套 semver 错误族 | parity 全绿 ✓（semver 36〔12 正 + 24 负〕+ manifest 19〔4 正 + 15 负〕= 55 案）+ pkg_window 8/8 维持 + 孪生族 12/12 + 守卫 8→10 + TD-030 登记（内联 cons 坍缩——let 中转绕道） | r157 ✅ |
| 3a | 155+3（r158）✅ 前半交付 | **lockfile.ktf 孪生**：kerf.lock 模型 + 确定性序列化——parse 往返面（`parse→to_text` 逐位）+ render 归一面（`new→to_text` 逐位：BTreeMap 名序 + 非规范版本重渲染 + 头部 em-dash 字节表 + 数字→十进制构造）；组合装配 mt+semver+lockfile 三件（BR-26 形制跨三件延伸）；同轮 TD-030 误诊改判关闭（W-CONS-COLLAPSE 解散） | parity 双面全绿 ✓（parse 4 正 + 17 负 + render 6 案 = 27 案；三方 oracle == twin-vm == twin-eval 逐位）+ 守卫 10→11 + 台账 16,676 | r158 ✅ |
| 3b | 155+4 ✅ 交付 | **resolve.ktf 孪生 + kp 壳接线**：三色 DFS（Gray 栈环路径）+ 后序拓扑 + 菱形约束汇总 + `KERF_PKG_SELFHOST` 三态回退带（先例 r145-r148 读链切换形态：unset=孪生生产位 / set=vm/rust 臂选择 / 非法值 fail-closed 拒启动）；kp 壳桥 = 读盘→包表字节表进 / 结构→渲染写盘出（K20 形制）；单自递归 phase 判别驱动（oracle 单 visit 同构——互递归在顺序绑定子集内非法） | kp resolve e2e 双臂（孪生位 vs Rust 位同 fixture 同输出逐位）✓ + 回退带三态测试族 ✓ + 红绿回退（孪生位坏→回退带接管→恢复）✓ | r159 ✅ |
| 4 | 155+5 ✅ 交付（r160） | **Rust 逻辑臂退役为构建引导回退带 + 窗口 CLOSED**：Rust 逻辑（micro_toml/manifest/semver/lockfile/resolve 五模块）退役保留于回退带（kp 壳 + 深度护栏 + 文件 IO 壳职责维持 Rust——宪制位声明：IO 壳与护栏 = 宿主服务面非语言逻辑面；lib.rs 退役声明落档）+ **全语料回归补全**（kp_corpus_tests 7 测试：pkg_window 命名语料缺位五族〔传递链/锁文件往返/缺根清单/缺依赖目录/名不匹配〕+ 三环/冲突菱形两变体面——双臂逐位）+ **中位违例缺陷当轮清偿**（rs_check_imposed 全表透传 + conflict-mid-list parity 钉）+ G5 闭合 + 自举矩阵刷新 | 全语料回归 ✓（7/7 双臂逐位）+ audit 460/460 维持 + 回退带红绿验证（r159 前置在档 + r160 语料面维持）✓ | r160 ✅ |

**刀间纪律**：每刀 = 完整内循环（§5.3 八项）+ GATE 1 + commit + §19 双包 + web 同步（用户常设指令⑮⑯）；刀间失败不阻断回退（parity 红刀 = Rust 臂生产位维持，孪生修复后再切——零生产风险形态）。

## 5. 出口条件（窗口 CLOSED 判据——r160 终验全 ✓）

1. ✓ kerf-pkg 逻辑面五模块 .ktf 孪生全承载（刀 1-3 交付）+ kp 生产位 = 孪生臂（刀 3 接线）；
2. ✓ Rust 逻辑臂退役为构建引导回退带（刀 4——lib.rs 退役声明落档）+ 三态回退带红绿验证在档（r159 前置 + r160 语料面维持）；
3. ✓ parity oracle 全绿（31 驱动——含 r160 conflict-mid-list 边界钉）+ pkg_window 8/8 + kp 语料面 7/7（双臂逐位）+ 孪生族 16/16 + audit AI 10 案维持（460/460 live）；
4. ✓ G5 闭合入账（bootstrap-completion-plan v1.22 §2 G5 行终态 + §3 序 5 出口行 + tech-debt PKG-2 终账）+ 自举矩阵刷新（余 G6——W-EVAL-RETIRE 紧随行权：T-a 触发器已达成 r149，重开评估 = G5 闭合后首议程）。

## 6. 登记与披露

- **窗口登记**：bootstrap-completion-plan §3 序 5 行刷新（开窗实况）+ tech-debt-register r155 检视节（PKG-2 触发器行兑现为窗口开启）；
- **W-EVAL-RETIRE 排期确认**：T-a ✓（r149）+ T-b 已消费（r121）——w3.6 v1.0 触发器重定义后的重开条件已满足，排期 = W-PKG-SELFHOST 闭合后（序 6——completion-plan §3 单源）；
- **非目标声明**（登记态零实施义务）：W-PKG-MULTISRC（多源 MVS——w3.10 §5 登记位维持）与 driver 多包接线（触发器未点火）不在本窗范围；
- **零冻结声明**：本窗四刀序 = 排期锚非冻结面（用户常设指令③——一切为最终结果让路；刀序调整须过 §3.3 演进提案 + worklog 记录理由）。
- **r156 镜像边界披露**（刀 1 实施勘定，孪生源头部注释同源）：①trim 域 = ASCII 六字节（9/10/11/12/13/32）vs oracle 的 Rust Unicode 空白类——非 ASCII 空白打头的行在两臂间漂移，parity 语料排除此面（生态 kerf.toml/kerf.lock 从未携带）；②输入包络 = 源字节数正比的 O(N) 自递归帧 + mt_at 的 O(N²) 偏移查找——语料限 ~1KB/案（真实 kerf.toml ~200B），超限由 harness budget 面分类为诚实输入包络（K165）非语义漂移；③i64 累加走**负域**（i64::MIN 幅值无正域对应——target-lexer 先例）；④kerf-pkg 消费面 +1：kerf-driver parity harness 直接消费生产 parser 作 oracle（kerf-reader/lex_target 先例；§18.5 no-forwarding 守恒——harness 只调用不转发），kerf-pkg lib 选择性导出扩一行（Document/Item/MicroTomlError/Value/parse）。
- **r157 镜像边界披露**（刀 2 实施勘定，孪生源头部注释同源）：①semver 组件域 = i64 正域 [0, i64::MAX]（VM 整数 i64 vs oracle 组件 u64——组件 ∈ (i64::MAX, u64::MAX] oracle 接受 / 孪生 fail-closed 拒；K165 诚实输入包络披露，parity 语料排除该带，真实生态 semver 组件为个位数）；②双信道字节表的**单字节形态** = `quote((d,))` 尾逗号（target 皮肤 `(d)` 是分组直通——裸 datum、`(d,)` 才是单元素表；`emit_target_datum` 单元素臂先例；semver 的 byte_table_define 家族化辅助实现同一约定）；③组合程序的 define 重绑定 = 顺序后写覆盖（CLI 双引擎端到端实证在档——`result` 全局经 micro-toml → semver → manifest 三次重绑定，最终取 manifest verdict）；④~~TD-030 生产缺陷披露：内联嵌套 cons（`cons(A, cons(B, nil))`，B 为 pair 构造）在非尾位参数位求值时内层坍缩为 B（`(A B)` → `(A . B)` 点对），let 中转构造同构树正确——8 行最小复现在 tech-debt-register TD-030；manifest.ktf 全部以 let 中转形态构造（规避缺陷形态），缺陷本体修复排期刀 3 前置评估~~ **r158-a 改判：误诊——`cons(A, X)` 尾拼接正确语义被误读（期望 2 表的复现件缺一层包裹）；TD-030 关闭，let 中转纪律解除，刀 3/4 孪生自然构造合法（证据单源 tool-results/r158/td030-assessment.md）**。
- **r159 镜像边界披露**（刀 3 后半实施勘定，孪生源头部注释同源）：①`mt_append(lst, item)` = **尾追加裸元素**惯例（micro-toml 自用法先例〔`mt_append(doc, rec)` 裸传〕）——resolve.ktf 四处初写误传 `pair(X, nil)` 1-list 包裹（edges/cycle 路径/gray 栈/后序 order），追加了 1-list 本身而非其元素，当轮全数清偿改裸传；②`dep-dir-not-found` 记录携带**父目录**，宿主 decode 自拼 `parent/libs/<name>`（oracle `Path::join` 序）——初写误传已拼接 dep_dir 致路径翻倍，当轮清偿；③互递归 = 顺序绑定子集内**非法形态**（跨函数前向引用 = expand 期 unbound identifier——偏移 90410 实证）：oracle 单 `visit` 的 deps 内联扫描投影为孪生时须并入单自递归 phase 判别函数，不得拆双函数互调；④manifest 错误渲染参数化文件位（render_mf_error 四参——依赖清单错误按其自身路径渲染，消息形状不变）；⑤探针插桩（zz_probe 测试 + resolve_parity_at span 窗口打印）当轮加当轮撤，零残留（r157/r158 探针 offset 定位先例延续）。
- **r158 镜像边界披露**（刀 3 前半实施勘定，孪生源头部注释同源）：①render 面版本字节 = 构造面输入——oracle 无法从坏版本构造 LockEntry（测试助手 unwrap），孪生 `render-bad-version` 守卫 fail-closed、语料永不携带；②负数 `version` 整数经 oracle `as u64` 包裹为巨数而孪生 i64 不可名——两臂同判 newer-format 拒绝（fail-closed 行为等价）但消息数字操作数不同，语料排除该带（K165 诚实输入包络；真实锁文件不携带）；③r158-a 同轮 TD-030 误诊改判（见 §6 r157 披露改判注）——let 中转纪律解除，后续孪生自然构造合法。
- **r160 镜像边界披露**（刀 4 实施勘定，孪生源注释同源）：①**conflict 中位违例缺陷（当轮清偿——语料回归面的直接产出）**：`rs_check_imposed(dep, ver, imposed)` 递归携带 `rest(imposed)`，违例发生在表中位时 `rs_err_conflict` 只收到**尾段**（丢满足前缀）——oracle 语义 = 整表抛出（PKG-3「every imposed constraint listed」）；r159 parity 案例巧合全绿的根因 = conflict-diamond 夹具违例恰在首位（tail == whole）；修复 = 全表透传参 `all`（rs_verify 调用点 imposed 双传）+ parity 补钉 conflict-mid-list 案例（e2e kp_corpus conflict_diamond + parity 钉双面）；②§20.3 同类路径全量：.ktf 族「递归走表抛错丢前缀」形态**唯一**（cycle = 栈位切片语义正确〔环路径从首现位起〕；dep-dir/not-found 族携带标量；mt/sv/mf/lk 四孪生错误携带记录位非累积表）；③语料分布方法论沉淀：parity 案例的违例位须覆盖**首位与中位**两形（同族 BR-33「探针期望值先过数学」——分布论证义务 §9.4.3）；④台账改账 resolve.ktf 473→478（+5——修复注释与透传参；总 17,149→17,154，审计口径 wc -l 逐位吻合）。
- **r156 环境受阻披露**（TD-029 容器降级类，基线 stash 复证在档）：GATE 1 分区 697/718 面实测全绿 + 21 面容器受限（abc_pipeline 6 / target_lexer_twin 7 / target_parser_twin 6 / steady_route 1 / stack_flat 1——r155 干净树同款超时，check segment 423s 与 r154 基线 424.82s 持平佐证部分面未降级、selfhost 双盘 parity 族显著降级）。

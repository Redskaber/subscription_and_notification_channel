# W-TEST-FLOW 测试流程优化窗——交付轮：分层执行 + 分块前台 + 断点续跑引擎（w-test-flow-window.md）

> **Status**: DELIVERED & CLOSED（r167 单轮交付——引擎落地 + T2 全量门两轮全绿〔首证轮 + v0.123.0 打包前新鲜轮〕；T0 烟测 29 族 ~42s；零会话中断；九引擎缺陷当轮清偿；fixpoint 567s 历史错配勘正）
> **流程权威**: docs/sop.md（§3.2 交付前验收 / §5.3 八项 / §9 测试标准 / §19.3 打包前测试先行 / §18 零新依赖 / §20.3 同类全量）
> **依据**: 用户 r167 显式指令「当前在推进任务和规划最耗时的是不是测试阶段……至少占 80% 的时间，请先对自举阶段的测试流程进行优化，不清晰或缺失知识的先通过知识搜索」+ 尾指令「测试校验耗时较长并多次意外中断会话，请审查并优化」；知识搜索件 = 167-b-research（GHC validate 分层 / GCC make check / Go 测试缓存与 -short / rustc CI tier 与 --keep-stage / LLVM lit 智能排序+超时+分片 / cargo-nextest build-once+慢测超时+分区——六项目对照报告 + 适用性表 + 排除项清单）；既有锚 = TD-029（容器降级类观测）/ testing-guide v0.122.0 口径 / test_infra_guard_tests §9.57 先例族
> **队列位置**: 用户指令重排序——本窗插队于 W-LANG-FOUNDATION 刀 3（enum）之前；刀 3 顺延为下一入口（completion-plan v1.28 §4.5 单源不变，本窗为横切基建窗非语言面窗）

## 1. 开窗记账（触发链）

| 链 | 事件 | 簿记位 |
|---|---|---|
| 用户指令 | r167 尾指令：测试阶段占 ~80% 时间 + 多次中断会话 → 先优化测试流程（知识搜索先行） | 本档 + worklog r167 |
| 知识搜索 | 167-b-research sub agent（research-only）：六项目测试框架实践对照 | my-project/worklog.md 5592-5605 + 本档 §3 锚表 |
| 环境实证 | nohup/setsid 后台进程在工具调用返回后被收割（cgroup 级）——「意外中断」根因锁定 | 本档 §3.4 |
| 基线实测 | 引擎自身即测量仪：60 族 + 3 虚拟行逐项耗时入台账 | 本档 §2 + target/test-ledger/durations.tsv |

## 2. 基线解剖（167-a——引擎实测，2026-10-12 本轮）

**耗时 Top 10（真实罪魁——数据推翻直觉）**：

| 排名 | 面 | 实测 | 案数 | 备注 |
|---|---|---|---|---|
| 1 | abc_pipeline_tests | **471s** | 6 | e2e 管线最重族 |
| 2 | target_parser_twin_tests | **389s** | 6 | 孪生自应用（与 r166 实测 386.18s 一致——环境未降级佐证） |
| 3 | audit 虚拟行 | **379s** | 460 live + 124 retired | 门审计例程真实全程（r166「14.16s」为分片面） |
| 4 | steady_target_reader_tests | **379s** | 7 | steady 链自应用 |
| 5 | target_lexer_twin_tests | 164s | 7 | 词法孪生 |
| 6 | check_segment_switch_tests | 90s | 10 | check 段自host parity |
| 7 | hm_twin_chain_tests | 47s | 6 | |
| 8 | target_fixpoint_tests | 46s | 8 | |
| 9 | expand_segment_switch_tests | 44s | 9 | 分片续跑实测（6/9 → 9/9） |
| 10 | resolve_twin_tests | 43s | 6 | |

**总账**：全 60 族 + 3 虚拟行串行总和 ≈ **2,180s（~36 min）**；T0 烟测层（29 族）实测 **~42s**；T2 全量门 = 五块 × ~8 min 分块前台完成。

**勘正两项（历史错配——引擎逐族归因的即时收益）**：
- **fixpoint 567.67s 错配**：r166-b3 worklog「fixpoint 20/20（567.67s release）」——该族恒为 **9 案 ~5s**（r164 恢复提交以来零变更，本轮 --list 与单案实测双重证实）；「20/20 @ 567.67s」实为**多族合并切片的总时长错配到族名**（fixpoint 9 + target_fixpoint 8 + …=20 案批）。TD-029 第十一次观测的「结构性增长」归因对象应为切片总时长而非 fixpoint 族——tech-debt r167 检视行勘正注记。
- **audit 14.16s 错配**：r166「124 retired 实跑 exit 0（release 14.16s）」为 retired 分面；全例程（460 live + 124 retired）真实 **379s**。

**覆盖缺口发现**：`cargo test --lib/--doc`（无 --workspace）只选根包——libs 虚拟行初版只覆盖 58/823 案、doc 0 案；修复后 libs = **823 passed / 0 failed / 13 binaries**（与 r166 GATE「lib 823:0」逐位一致）✓。

**对账恒等式**：runner 60 族 passed 总和 **766** + ignored **2** = `--list` 全量 **768** ✓（台账 ↔ 列表双向可审计）。

## 3. 设计（167-b——知识锚 → kerf 形制映射）

### 3.1 分层模型（GHC validate / Go -short / rustc --pass 先例）

| 层 | 语义 | 构成（tiers.tsv 单源） | 预算 | 时机 |
|----|------|------|------|------|
| **T0 smoke** | 恒绿不变量快反馈 | 守卫族 + 种子族 + 语料隔离表（29 族） | 实测 ~42s | §5 内循环每 MUV |
| **T1 round** | 轮内门 | T0 + 标准集成面 + pkg 孪生五件 + `libs` 虚拟行（52 项） | 分钟级 | 常规轮 commit 前 |
| **T2 full** | 全量门（= §3.2 测试面） | 全部 + `doc` + `audit`（63 项） | ~36 min 分块 | 末轮 / §19 打包前恒新鲜 |

**GATE 完整性不变量（宪法级）**：分层只改「何时/如何跑」，永不改「必须过什么」。T2 = `cargo test --release --workspace`（lib+integration+doc）+ 审计例程的逐位等价；打包前恒 `--force` 新鲜全量。

### 3.2 批次引擎机制（scripts/testing/test-tiers.sh，~570 行）

| 机制 | 知识锚 | kerf 形制 |
|---|---|---|
| build-once-run-many | nextest 两阶段 | 批次先 `cargo test --release --no-run --all-targets`；逐族复用缓存二进制 |
| 智能排序 | lit `--order=smart` | red/timeout/running/pending 先行 → 其余按已知耗时降序（durations.tsv = `.lit_test_times.txt` 类比，跨指纹存活） |
| 逐族超时 | nextest slow-timeout | tiers.tsv 第三列；超时记 `timeout` 态继续批次 |
| 全局预算 | lit `--max-time` | `--max-time S`；适配感知装箱（est > 剩余 → 不启动） |
| **族内分片** | lit sharding | est > min(剩余, 300s) → `--list` 枚举 + `--exact` 切片 + 进度文件（`progress/<family>.txt`）——**超窗族（abc 471s > 600s 工具窗）唯一可完成路径** |
| 保守指纹 | Go 缓存的保守子集 | runner 二进制 sha16 + git HEAD + RUST_MIN_STACK + tiers.tsv sha16；指纹变 → 台账自动归档重开；**无跨轮结果缓存**（防假命中） |
| 断点续跑 | lit `--filter-failed` 精神 | `--resume` 跳过同指纹绿族；块间进度由 ledger.tsv 承载 |
| 碰撞盾 | — | libtest 子串过滤（fixpoint_tests ⊂ target_fixpoint_tests、jit_window_tests ⊂ method_jit_window_tests）自动 `--skip` |
| 台账工件 | GCC .sum / lit xunit | ledger.tsv（族/态/秒/计数/时戳）+ state + durations.tsv + batch.log |

### 3.3 守卫三案（tests/v1/stage1/plan/test_tier_guard_tests.rs——test_infra_guard §9.57 同族）

FP1 表↔挂载双向零漂移（孤儿/幻影/重复全防）；FP2 字段健全 + **九慢族 T2 钉扎**（GATE 完整性——移层即红）+ T0 非空下限；FP3 引擎 `bash -n` + 表面标记契约。双生文档 docs/tests/v1/stage1/test-tiers.md（分布论证：库存漂移/静默降级/引擎漂移三类错误面）。

### 3.4 环境强制裁定：「意外中断」根因实证（本轮最重要的经验知识）

**本沙箱在工具调用返回后收割全部子进程**——`nohup bash -c '...' &`（PID 21826，20:10 启动，log 冻结于 "Compiling kerf"）与 `setsid`（脱离会话组亦死）双实验证伪一切后台模式。历史上「测试校验多次意外中断会话」的机制本体 = **长前台命令撞工具超时顶（600s 硬顶）+ 后台不可存活**。

**唯一合法长套件模式 = 分块前台**：`run --resume --max-time <预算>` 重复调用，每块落在单工具窗内，进度由台账承载。配套：构建独立成块（`--build-only`）或逐 crate 预热（cargo 按 crate 缓存）；慢族单块仅推进 1-2 族为正常预期。

## 4. 引擎缺陷清偿史（§20.3 同类全量——当轮九修 + 守卫立捕一例）

| # | 缺陷 | 机制 | 清偿 |
|---|---|---|---|
| 1 | **tier 变量踩碎** | bash 动态作用域：`families_at_or_below` 的 `read -r fam tier _t` 在 EOF 空读时置空变量，踩碎 cmd_run 局部 `tier` → 虚拟行三件全漏选 | 读循环变量 row_ 前缀化（三函数） |
| 2 | **碰撞盾参数吞噬** | collision_skips 输出 `--skip xxx::` 整行（含空格）→ mapfile 单元素 → cargo 收含空格单参数 → libtest 视为未知选项即刻退出（恰好只 fixpoint/jit 两族有碰撞——红行完全吻合） | 输出协议改族名 + build_skip_args 两段拼参 |
| 3 | **local 算术展开序** | `local total=X done_n=$((total-Y))` 的展开先于赋值 → set -u「total: unbound」崩溃 | 拆行 + 注释落档 |
| 4 | **首行摘要** | `awk 'seen[$1]++==0'` 取追加式台账的**最老行**——早已解决的 red 被报为当前态 | 尾行语义（last[] 数组） |
| 5 | **虚拟行覆盖洞** | `cargo test --lib/--doc` 无 `--workspace` 只选根包（58/823） | --workspace + 作废重跑 + 全量核验 823/0/13 ✓ |
| 6 | **整跑死循环险** | est 乐观（180 默认）+ 工具窗硬顶 → 480-560s 灰区族无台账死亡 → 无限整跑重试 | 整跑上限 300s——超限恒走分片（分片恒有进度） |
| 7 | **TSV 制表符吞噬**（守卫立捕） | 编辑轮将全文件 TAB 转空格——严格 TSV 解析立捕（FP1/FP2 双红） | sed 正则重建 + 守卫按设计工作（严格格式承重实证） |
| 8 | **切片超时误判红** | per-case 估值 = 族均值，用例分布不均（selfhost 固定点单案 60s+ 混于 2s 守卫案）——`remaining+30` 头位不足 → check_segment 第 9-10 案切片超时被记 red（整跑 90s 复审真绿——超时 ≠ 失败裁决） | 头位 +90 + ec=124 转 pending（进度保留续跑点） |
| 9 | **虚拟行死锁** | 整跑 300s 帽应用于虚拟行——audit est 379s 永记 pending（虚拟行无分片路径） | 路由重构：虚拟行按剩余预算判定整跑；帽 + 分片仅施于实族 |

## 5. 分层指派表（数据驱动终态——tiers.tsv 单源）

- **T0 ×29**：11 种子族 + 14 守卫/表族（test_infra/perf/limits/message/selfhost_format/lexical/capture/eval/determinism/symbol/parity/pkg_window/workflow/extern）+ typecheck_wiring + target_reader_seed + subset_corpus + test_tier_guard。
- **T1 ×22**：typecheck/hm_inference/pbt/stage_exit 种子 + 双 sweep + hm 双面 + target_corpus_sweep + target_lexer_twin(164s) + c_backend_e2e + steady_expander_chain(11s) + gc/jit/superinstr/method_jit/rec_depth 窗 + **pkg 孪生五件**（micro_toml/semver/manifest/lockfile/resolve——T0 纯化时移入）。
- **T2 ×9（钉扎）**：fixpoint(5s)/target_fixpoint(46s)/target_parser_twin(389s)/abc_pipeline(471s)/steady_target_reader(379s)/四 segment switch(12-90s)——历史耗时与实测双口径入账。
- **虚拟 ×3**：libs(T1)/doc(T2)/audit(T2)。

## 6. 验证面（交付口径）

- **T2 全量门两轮全绿**：首证轮 63/63（五块 20:42-21:28）+ **打包前新鲜全量轮 63/63 @ v0.123.0 指纹**（六块 21:34-22:16——缺陷 #8/#9 修复于其间实证）；对账恒等式 766+2=768 ✓；libs 823/0/13 ✓；audit exit 0（460 live + 124 retired，392s）✓。
- **T0 烟测 29 族 ~42s**（预算 ≤120s 达标）；分片机制实证：fixpoint 9/9 切片、expand 6/9 → 续块 9/9、abc 整窗单族完成。
- **守卫 3/3 绿**；runner 挂载 61 mod（含 common）；六命令面见 close 轮 GATE 1 全量。
- 引擎自身即本轮交付物的验证载体（优化自证——全量门由被优化的流程本身跑绿）。

## 7. 登记项（零信号不开窗——原则 38/44-58）

| 项 | 内容 | 触发器 |
|---|---|---|
| 跨轮结果缓存 | 逐族依赖图输入清单（Go 式假命中风险——保守指纹 v1 弃用） | 任意窗口出现「重复全量跑绿族」的显著浪费投诉 |
| 族级并行 | KERF_TEST_JOBS>1（TD-029 内存余量纪律 v1 串行） | TD-029 闭账或容器内存余量实测充裕 |
| runner.rs 单体拆分 | 60 mod 单 crate 编译 ~10 min（rustc tidy 分文件先例——测试编辑不重编 crate 面） | 任意轮构建块超单工具窗 |
| counts 行多二进制限制 | libs 虚拟行 counts 只记末 crate 摘要（823 全量核验为本轮人工补） | 引擎 v2 |

## 8. 出口条件（窗口闭合清单）

- [x] 引擎 + 分层表 + 守卫 + 双生文档 + testing-guide 扩展（过时基线清偿——差异 C 面）
- [x] T2 全量门分块模式首次全绿 + 对账恒等式
- [x] 环境根因实证（§3.4）+ 六缺陷清偿史（§4）
- [x] 历史错配勘正（fixpoint 567s / audit 14s）
- [x] close 轮：金链 v0.123.0（Cargo.toml 1 + lock 13 + ds08 + 注释链）+ GATE 1 全量（fmt 零 diff / check 0e0w / clippy -D 零 / build ✓ / doc ✓ / 新鲜 T2 63/63 六块）+ §19 双包 + web 数据面 + worklog 三落

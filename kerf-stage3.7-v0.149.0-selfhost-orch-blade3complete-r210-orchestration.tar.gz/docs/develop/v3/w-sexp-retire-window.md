# W-SEXP-RETIRE S-expr 脚手架拆除窗——单皮肤终态三刀（w-sexp-retire-window.md）

> **Status**: **CLOSED**（v1.3——r154 刀 3 **完整交付 + 窗口关闭**：**词面层 + 台账层收口 ✓**〔全树词面清零 ~292 处/37 文件——audit 110 + snapshot_seed 40 + cli 22 + render 13 + macro_seed 11 + 其余散布；四子代理 154-a/b/c1/c2 并行机械清零〔SOP v15.4 §21.12-33 首次全流程适用：工作量预估裁切 + 简报自包含 + 主代理亲执语义位〕+ 主代理守卫文件/selfhost 位；TEST-5 零扫描守卫化〔.krf / skin_transcoder / StxToken / sexp_corpus_migration / ReaderFace::Sexp 五禁令 + 守卫自文件唯一白名单——任何 S-expr 表面复活即红〕；**TD-028 关闭**〔TWIN-HYG-1——expander.ktf (name, generation) 帧表示迁移 2,230→2,349：六推送位〔letloop cons 技巧/doloop "_"/fnbind 参数表/match 臂 ex_binds_frame/define-fn-sugar/define-var〕统一 (name, gen) 正规两元条目 + 代纪律解析链〔源引用 gen=0 全帧 = 基线同深路径；引入引用 gen>0 仅解析引入绑定器 + 全局——ex_frame_has 成员检查 + ex_frame_gens 二趟〕+ ex_externs 全局表〔oracle 种子纪律镜像——extern 名对两类引用恒可解析〕；audit J03 + macro_seed J03 等价案孪生臂回迁生产臂；两手术缺陷当轮清偿〔非正规对 ex_2 崩溃 + ex_is_name_member 不可透视条目〕〕；subset-spec 状态行终态注记；台账升格「转化终态 + 拆除完成」七件 14,616 行；v0.113.0 金链锁步 + GATE 1〕；**出口条件四条全 ✓ 关窗**：①词法语法语义全目标语言单皮肤（S-expr 表面四层全拆）②R5 双臂复证落档 ③六命令全绿 + audit 460/460 + 台账三处单源一致 ④每刀过测试。环境披露：容器重建后 bnd-006 255 深嵌套经孪生展开段需 >2MB 线程栈（r153 容器内刚好够）——GATE 分区 RUST_MIN_STACK=8MB 环境适应措施 + TD-029 登记结构性余量）(v1.2——r151 刀 2 **完整交付**〔三续传会话接力：151-a 裁定层 + 151-b 拆除主体（中断会话落树）+ 151-c 消费面（恢复会话收尾）〕：**S-expr 读链退役 ✓**〔拆除 ~4,700 行：kerf-reader 本体三件 + lexer/reader.ktf 两孪生 812 行〔selfhost 九件→七件〕+ bootstrap 四件〔bootstrap_chain/composed_target_chain/lexer_parity/skin_transcoder〕+ reader_parity→vm_harness 改名；收口五面 pipeline/diagnostic/cli/repl/read_segment + common StxToken 退役 + 转码器退役 + RS-1 内嵌 PrefixDatum 微解析器；消费面 141 错误位点 ~46 文件〔tests 树 40 + audit 59 + bench 三件 + in-crate 45〕；生产缺陷三件当轮清偿〔transcode 命名守卫显示面比较 + REPL callee 恢复 + audit 仲裁四案〕；**TD-028 登记**〔TWIN-HYG-1 孪生展开器 plain-ident 代纪律缺口——audit J03 钉 oracle 臂承载〕；audit 减法共变 480→460 live + 124 retired〔AF 族 + 空应用四元组 + AH9 + AJ07-AJ10 + AL03/AL08 + AY09〕+ 守卫 TEST-3/3b 共变；v0.112.0 金链锁步 + audit 460/460 实跑 exit 0；台账改账九件 14,932→七件 14,497 行——词面清理项移交刀 3：.krf 词面残余扫描 + 台账层收口〕；v1.1——r150 刀 1 **完整交付**〔中断轮续完〕：**语料单皮肤迁移 ✓**〔bootstrap-completion-plan §4.4 刀 1——全语料 .krf→.ktf 落盘 109 案 + 三案退役〔neg-021 单元分歧 / pos-031 关键字词汇分歧 / neg-036 形状分歧——目标皮肤面无主语案，分歧钉扎转入 sweep 专项测试〕+ 逐案双皮肤等价预检〔值/输出/拒绝三面 + 值族三闸〔α-等价 + 单一语义字节码 + 单一值面〕迁移期一次性证明落档 tool-results/r150-migration-report.txt〕+ 消费面切换 **14 测试文件 + 3 子代理 + 漏网 2 件**〔subset_corpus / target_corpus_sweep / hm_twin_face / determinism_guard / test_infra_guard TEST-2 / infer_twin_sweep + typecheck_twin_sweep〔裸机裁定 75/16/18〕/ steady_expander / lexical_capture / c_backend_e2e〔C 回放 52/52〕/ stage_exit / composed_target_chain + bootstrap_chain〔账目 16/23/11/57/2 = 109〕/ superinstr_window〕+ parse_directive 双注释前缀扩展〔`;; expect:` / `// expect:` 同语义单源〕+ 迁移机械臂 examples/retire/sexp_corpus_migration.rs〔R4 归档〕+ **audit 面共变**〔BF 族 10 案 470→480 · 56→57 节 + V03 全语料 sweep 目标面化〔地板 79→109〕+ AF/AK/AL 九案种子源内联化〔SR-2 内联纪律——.krf 原件离树，案前提 = 源文本非文件本体；整族刀 2 随读链退役收编〕〕+ 守卫 TEST-3 四处共变〔480/480 + 584 总账〕+ v0.111.0 金链锁步 + GATE 1 六命令 1693:0:4 + audit 480/480 实跑——诚实披露：neg-057 J2 错误臂渲染形缺口〔刀 2 清理项〕+ neg-062 extern 双胎缺口维持〔r123 两法官契约〕〕）
> **流程权威**: docs/sop.md v15.3 · **规划权威**: bootstrap-completion-plan.md §4.4（G7 · R5 生命周期拆除位）· **台账**: s-expr-conversion-record.md
> **技术锚**: SOP §2.2 原则 41/53（脚手架生命周期 + VM 基座宪制排除）+ R5 拆除判据 + r114 TD-007 转码器机械臂先例 + E5 批次 3 一次性移除先例（r104——替代链完整证明先于拆除纪律）

## 1. 开窗时点实态与入口对账（r149 闭合态）

| 前置 | 判据 | 实态 |
|---|---|---|
| read 段生产位（拆除权发生位） | 孪生目标读链为生产读路径 | ✓ r145（SteadyTargetReaderChain VM 臂默认 + Rust 目标读器退役 oracle + 回退带 `KERF_READ_SEGMENT`） |
| TD-027（展开孪生 match 臂） | expander.ktf 与 oracle expand_match 逐决策镜像 | ✓ r143 清偿关闭（语料族 21 案） |
| R5 拆除判据双臂 | 自建替代 ≥ 被替换物 × 98% **或** 额外能力 > 0 | ✓ 双臂满足：target 读链 G1 全语料覆盖（r139 稳态链全源 sweep）+ 额外能力 > 0（类型注解语法 / 胖关键字） |
| C4 工作流宣告（生产消费证明） | .ktf 语料经生产位编译执行 | ✓ r149（workflow 实录——T-a CLOSED 交棒） |

**S-expr 表面四层清单（本窗拆除对象——逐刀退役）**：

1. **语料层**：`tests/v1/stage1/corpus/*.krf`（112 案——刀 1 迁移 109 + 退役 3）
2. **读链层** ✓ 已拆 @ r151：Rust S-expr lexer/parser（`crates/kerf-reader/src/{lexer,parser}.rs`——本体三件 + token.rs）+ 孪生 `selfhost/v1/{lexer,reader}.ktf`（812 行）+ parity harness（lexer_parity.rs 951 + reader_parity.rs 422→vm_harness）+ 转码器 skin_transcoder.rs + 迁移机械臂——全数离树
3. **词面层** ✓ 已清零 @ r154：全树 `.krf` 伪文件名/双皮肤分支/转码器（`skin_transcoder.rs`）+ subset-spec 状态行（TEST-5 零扫描守卫化——任何 S-expr 表面复活即红）
4. **台账层** ✓ 已收口 @ r154：s-expr-conversion-record 升格「转化终态 + 拆除完成」（七件 14,497→14,616 行〔expander.ktf TD-028 +119〕+ §4 拆除账清零 + r151 先行改账〔九件 14,932→七件 14,497〕）

## 2. 窗内裁定 SR-1..SR-5（ARCH-A）

- **SR-1（迁移语义）**：刀 1 迁移 = .ktf 语料文件落盘 + 期望契约不变（指令行 `// expect:` 前缀等义 `;; expect:`）。机械族经转码器、手作孪生族（parse-error 6 + 负字面量 2 + ruling-D 2 + bnd-007 生成 1）经既有孪生表物化、阶段分歧族（9 案）期望改钉目标面拒绝类（parse-error——读段拒绝即目标面拒绝类）。
- **SR-2（退役三案）**：neg-021（`()` 空应用——ruling C12 目标面读作 nil，拒绝无目标主语）/ pos-031（`else` 字面量使用形——关键字经济保留字，使用形无目标拼写）/ neg-036（裸表达式 handler 臂——目标臂语法恒 fn 包裹，E0007 不可达）：三案**目标皮肤面无主语**，从验收语料退役（≠ 删除语义——分歧钉扎由 sweep 专项测试承载〔C12 nil 行为 / else 保留拒绝 / 臂 fn 包裹良构〕，S-expr 侧断言经内联源维持至刀 2）。语料分布地板维持（pos 45 / neg 54 / bnd 10 = 109 ≥ 地板 20/20/10/50）。
- **SR-3（跨皮肤三闸的迁移期一次性）**：α-等价 + 单一语义字节码 + 单一值面三闸 = **迁移预检义务**（.krf 仍在树时逐案证明，落档迁移报告）；迁移完成后语料单皮肤验证 = validate_target 期望契约（双引擎 parity 内在）+ 双跑确定性。跨皮肤闸不随语料存续（其比较对象之一已退役）——闸的语义由 fixpoint（自源读链）与组成链差分（J0-J2 五联）承载。
- **SR-4（机械臂归档）**：`examples/retire/sexp_corpus_migration.rs`（[[example]] `sexp_corpus_migration`）= 一次性迁移驱动器（R4 归档——窗口工件记录在案；孪生表迁移期单源 = 机械臂，迁移后单源 = .ktf 语料文件本体）。
- **SR-5（不可降级纪律）**：每刀完整交付后方可进下一刀（用户指令——不完整自举留隐患）；刀 1 出口 = 全语料单皮肤 sweep 三面等价 + 双引擎 parity + 双跑确定性 + 六命令全绿；刀 2 出口 = S-expr 读链全树退役后全测试树绿 + fixpoint 经目标读链维持；刀 3 出口 = 词面清零扫描守卫化（任何 S-expr 表面复活即红）。

## 3. 切刀排期（MUV 边界——禁止降级交付）

| 刀 | 内容 | 集成验证 | 状态 |
|---|---|---|---|
| 刀 1（语料单皮肤迁移——r150） | 112 案 .krf→.ktf 落盘（109 迁移 + 3 退役）+ 逐案双皮肤等价预检 + 消费面五件切换 + parse_directive 扩展 + 机械臂归档 | 迁移后全语料 .ktf 单皮肤 sweep 等价（值/输出/拒绝三面）+ 双引擎 parity 维持 + 双跑确定性 + 分布地板 | ✓ r150 |
| 刀 2（S-expr 读链退役）✓ r151 | Rust S-expr lexer/parser 退役 oracle→移除 + lexer/reader.ktf 孪生退役 + parity harness 收编 + driver 双皮肤分支收口 + 转码器退役 | 全测试树绿 ✓（tests 71→0 + in-crate 172/172）+ audit 族减法共变 ✓（460/460 实跑）+ fixpoint 维持 ✓（目标读链 r139 起即生产位——读段零切换） | **已交付**（刀 1 移交清理项处置：J2 渲染形〔消费面随 151-c 全量转面消解〕+ AF/AK/AL 内联种子源〔整族随刀 2 退役/收编〕+ i64::MIN 内联常量〔算术合成孪生 0−9223372036854775807−1 全树清零〕；新增移交刀 3：TD-028 孪生臂回迁 + .krf 词面扫描守卫） |
| 刀 3（S-expr 面清零）✓ r154 | 全树词面清零扫描守卫化（~292 处/37 文件 + TEST-5 五禁令守卫）+ subset-spec 状态行终态注记 + 台账改账升格 + 文档族对账三处单源 + TD-028 孪生臂回迁（随刀项） | 清零扫描守卫化 ✓（TEST-5）+ §8.5 文档检查单全过 + R8 编码面清零 ✓ + audit 460/460 实跑 | **已交付**（窗口 CLOSED） |

## 4. 出口条件（窗口关闭判据）

1. 词法语法语义全目标语言单皮肤（用户指令⑥终态——S-expr 表面四层全拆）
2. R5 拆除判据核验双臂落档（替代覆盖 + 额外能力——§1 对账行的拆除期复证）
3. 六命令全绿 + audit 族共变 + 台账三处单源一致（台账 + completion-plan 窗口行 + stage0 §9.12X）
4. 全程每刀过测试（打包前义务——§19.3 打包前置）

## 5. 守卫义务（每刀）

- 语料分布地板（pos ≥ 20 / neg ≥ 20 / bnd ≥ 10 / 总 ≥ 50）+ 案名前缀唯一
- `corpus_case_table_matches_directory_exactly`（表 ↔ 目录逐位）
- audit 组成守卫 TEST-3 共变（新族入账）
- R8 编码面清零扫描（新写入代码全英文）
- 每刀 GATE 1 六命令全绿先于 commit/打包

## 6. 知识锚（沿袭 + 本窗新增）

- 沿袭：K20 永久宿主层桥（ident 皮肤映射/float Debug/str 转义——目标读链生产位组件，不随 S-expr 退役）/ E5 皮肤映射（stage0 §9.46——目标皮肤拼写契约，刀 3 后成为唯一皮肤契约）/ r104 E5 批次 3（.krf 编译原件一次性移除先例——其时守卫退场模式 = 本窗刀 2 模板）
- 本窗新增：K164 = 语料单皮肤迁移纪律（等价预检先行 + 退役案分歧钉扎转移 + 机械臂归档三件套）

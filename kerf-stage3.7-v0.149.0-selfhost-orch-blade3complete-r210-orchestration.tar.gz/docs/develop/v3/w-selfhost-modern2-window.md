# W-SELFHOST-MODERN-2 自举源现代化二窗——12 件 .ktf 孪生消费效应族链表面（行词汇 + 效应词汇包）

> **Status**: **OPEN——刀 1 DELIVERED @ r196 + 刀 2 DELIVERED @ r197 + 刀 3 DELIVERED @ r198 + 刀 4 DELIVERED @ r200 + 刀 5 DELIVERED @ r201**（刀 4 = r199 手术随收割丢失后 GitHub LFS 锚恢复 + 全量重执行——compiler.ktf 1,968→1,917〔C2 八 raise 位 + 守卫溶解 + 判别头清理 + cp_run 契约面〕+ macro.ktf 733→751〔勘定零代码〕+ M58 harness 共变；余刀：5 expander → 6 infer/target-parser 收官 + close）（刀 1 试点：semver.ktf + micro-toml.ktf〔§9.1〕；刀 2 组合程序族三件：manifest.ktf 525→545 + lockfile.ktf 675→703 + resolve.ktf 517→544〔§9.2/§9.3〕；刀 3 判定/词法面双件：target-lexer.ktf 1,069→1,128 + typecheck.ktf 1,264→1,304 + **连锁修复 compiler.ktf 1,958→1,968（M47——handle 发射位真缺陷当轮清偿）**——C2 词法拒绝族 M35-M38〔29 错误构造位全量 perform raise 短路 + 契约面 unwrap(attempt(thunk), identity) 包装冻结〕+ C1 表示清理 M39-M45〔判别头死数据丢弃 + 嵌套 pair 模式化——**Rust reader 边界修正裁定 M49**：链内嵌件经冻结 Rust reader 构造，行词汇不可表达，裸值链承载〕+ 边界②勘定 M42〔typecheck 零 C2——ruling 21 累积架构〕+ harness 共变 M46〔STD_ERROR 前缀装配四处 + twin_dump/parity 双轴→单轴 + steady 读链 lexer 层 eval 轴退役〕+ **infer 差分 × r188 pin 碰撞 M48（TD-032 结构锚豁免——刀 6 收口）** + 零新探针〔P1-P13 事实集全覆盖〕+ parity 全绿〔lexer 7/7 + parser 6/6 + hm 双族 12 + typecheck 37 + steady 7 + composed 7 + determinism 10 + extern 5〕+ T0 29/29 + T1 59/59 + T2 fresh 70/70 EXIT 0 + 金链 bump v0.141.0→v0.142.0 + 性能 §9.5 八族方差带内零回退；余刀：4 compiler/macro → 5 expander → 6 infer/target-parser 收官 + close）；开窗轮 r195 记录：四触发器全达成〔§4〕+ 前置门四件全过〔§5〕+ 零新桥〔§3.5〕
> **流程权威**: docs/sop.md v15.6（§21.12-28 自举完备优先——自举段最高排期优先级 / §21.12-33 孪生手术亲执 / §3.2.1 长套件纪律 / §19.3 打包前测试）
> **依据**: 用户常设指令③（「每当确认完善 kerf 端自己特性和能力时〔需要从基础核心的能力和特性完善后再延伸〕，知识搜索和项目状态如果时机合适则使用 kerf 当前最新词法语法语义完整重构 kerf 自举 kerf 端的全流程，替换原始编码〔本质优化表示和内容与架构〕」）+ 指令「放行继续推进和演进」+ 指令⑪ 同族（「自己用自己语言推进自己」源码面兑现——modern-1 的直接续作）；知识检索件 = tool-results/r195-search/（六检索 48 命中——rustc 自源采纳 / GHC 扩展分阶 / OCaml 编译器内部 / record 模式 vs 访问器〔JEP 440 证据〕/ OCaml 5 效应错误处理 / bootstrap 重写循环）；先例窗 = w-selfhost-modern-window.md（CLOSED @ r180——G8 表面消费终态；本窗 = 其后置能力面的续作窗）
> **职责边界**: 本档承载 W-SELFHOST-MODERN-2 的裁定、消费分类学、刀级 MUV 排期与诚实边界；语言表面规范单源 = subset-spec（行词汇三机 + handle/perform 冻结面——r184/r187/r188 交付物）；效应实例词汇单源 = selfhost/std/ 六件（r192-r194）+ w-effect-instances-window.md §9；转化台账 = docs/develop/v3/s-expr-conversion-record.md（每刀入账义务——§5 登记义务语义/语言面变更均入账）

## 1. 一行定位

效应族三段链（r181-r194：行类型 → 效应机制 → 六实例词汇包）把**行词汇**（`[l: v; tail]` 行字面量 / `[l: p; tail]` 行模式 / `[l: T; tail]` 行注解 + 箭头携行）与**效应词汇**（handle/perform one-shot 语义 + `std/` 六件：`attempt`/`unwrap`、`with_log`、`state_run`/`state_thread`、`with_read`/`with_write`、`with_async`）交付进生产链后，selfhost/v1 的 12 件孪生仍以 **modern-1 时点（G8 表面）的编码惯用形**书写——标签键内部数据经 `first`/`rest` 位置导航（实测 12 件合计 ~900 `first(` + ~810 `rest(` 位点）、短路错误路径经 `("err" …)` 元组手工穿线（~107 位点）、行字面量消费为零——本窗把这些源**用效应族链表面完整重构**（标签键导航 → 行模式解构、短路错误穿线 → `attempt`/`raise`/`unwrap`、诊断踪迹 → `with_log`、raise 面 API → 效应行注解），使「自举语言用自己语言推进自己」在**效应族链后的源码面**二次兑现（rustc 逐版自源采纳 / JEP 440 record 模式替代访问器链 / OCaml 5 效应错误处理同型——§2 前沿对照）。

## 2. 成熟度口径（现状 + 前沿对照）

| 面 | kerf 现状（@ r195 实测勘定） | 优秀语言参照 |
|---|---|---|
| 编译器自源采纳效应族链表面 | 12 件零行字面量消费（rowlit=0 全件）；标签键内部数据位置导航 ~900 first + ~810 rest 位点（expander 259/220 + infer 233/203 + compiler 81/84 + target-lexer 70/104 + typecheck 60/69 + macro 58/60 + target-parser 54/72 + resolve 36/37 + lockfile 34/38 + manifest 16/23 + micro-toml 15/20 + semver 1/4）；expander 保留 ex_2..ex_7 位置访问器族（`first(rest(rest(…)))` 深位链——位置元组访问的编码症状）；短路错误穿线 ~107 `"err"` 位点（expander 20 + resolve 16 + compiler 15 + semver 13 + target-parser 11 + manifest 9 + micro-toml 9 + lockfile 8 + target-lexer 4 + macro 2）；std/ 六件零编译段消费（消费面 = 语料/harness 专属） | rustc 逐版采纳自身稳定特性（MSRV-of-itself——K-r174-5）；**JEP 440 record patterns**：record 模式解构「不经访问器调用读出数据」——位置访问器链 → 模式解构的官方同型证据；**OCaml 5 effect handlers**：模块化用户定义效应（错误处理 = 效应的标准应用面）；GHC 扩展分阶采纳（boot libraries 演进） |
| 重构安全网 | parity sweep 族 + fixpoint 三阶段 B≡C 位级 + audit 512 live EXIT 0（r194 基线全绿） | rustc UI 金档 + crater；Go 可复现三轮自检（K-r174-2） |
| 行为不变判定 | 双口径既有：字节级（同语法 fixpoint 链）+ CoreExpr 全等（跨语法）——BS-C 分层判据（modern-1 全程实证） | 同 modern-1（Go toolchain2/3 轮缺陷自浮——K-r174-2） |

## 3. 消费分类学裁定（ARCH-A @ r195——五类消费面 + 诚实边界五条）

现代-1 消费的是**派生表面**（struct/enum/match = 数据形与分派形）；本窗消费的是**效应族链表面**（行词汇 + 效应词汇包）。两类表面的表示恒等判据不同，逐类裁定：

| # | 消费类 | 内容 | 表示恒等判据 |
|---|---|---|---|
| C1 | **行字面量/行模式**（标签键内部数据） | 标签键数据构造/解构位（infer 行机器自身的 `("row" ((l T)…) tail)` 字段表、micro-toml/manifest/lockfile 的表键值对表、帧表/环境表等同形位）→ `[l: v; tail]` 构造 + `[l: p; tail]` 解构 | 行字面量脱糖 = cons 链右折叠（RW-13——r184 冻结口径）：**运行时表示逐位同形**，fixpoint B≡C 位级守护 |
| C2 | **Error 效应词汇**（短路错误路径） | `("err" kind payload…)` 手工穿线位（raise 语义 = 深位短路直达顶层）→ `attempt(program)` + raise 载荷 = 原 `("err" …)` 元组 + `unwrap` 便捷组合 | **外部产物形状冻结**（("err" …) 元组 = oracle 契约面——raise 载荷即该元组，不改形状）；控制流表示变化（穿线 → one-shot 短路），成功路径与失败产物位级守护（金档负向族 + parity sweep） |
| C3 | **Log 效应词汇**（诊断踪迹内部面） | 编译段内部诊断/调试踪迹 → `with_log`（退化形恒续 nil——零输出变化）+ `with_log_via` 可注入门面 | 退化形零输出变化（m6 facade 惯例）；踪迹面非产物面（audit 不含踪迹断言） |
| C4 | **效应行注解**（raise 面 API） | 携 raise 的助手函数注解 → 箭头效应行（`(fn (…) R \| (row raise e))`——r188 四元槽注解面） | 注解面 = API face（INST-3 先例——arrow-with-row 无 target-skin 表面位，注解钉金档） |
| C5 | **State 效应词汇**（世代穿线自然位） | 仅当存在**自然世代穿线形**（resolve 三色 DFS 状态携带等）——无自然形则**不开消费**（诚实边界③） | 同 C2（外部产物形状冻结） |

**诚实边界五条**：

1. **外部契约冻结**：12 件孪生的一切**外部可观测产物**（展开结果 `("ok" item…)`/`("err" …)`、推断结果 `("types"…)/("diags"…)`、编译产物 .krf、诊断消息文本）形状逐位冻结——现代化只改**内部惯用形**（导航/穿线/踪迹），不改任何产物面。违反即 NEEDS REVISION。
2. **诊断累积面不开 Error 消费**：typecheck/infer 的 `("diags" …)` 是**累积多诊断**形（非短路）——attempt/raise 只替换**短路单错误**路径（expander 展开拒绝族 / resolve 冲突族 / semver/micro-toml 解析拒绝族）；累积面维持现形（OCaml 5 效应非错误处理唯一形——诚实分工）。
3. **位置元组不强转行**：`("tag" a b c)` 位置元组 = 外部契约面（C1 边界①），**不转标签行**；expander ex_2..ex_7 位置访问器族仅在**内部中间形**可消除位消除（match 嵌套 pair 模式 / 行模式按 C1 判据），外部契约位保留原导航。强转 = 表示变更 = 违反边界①。
4. **性能面诚实账**：效应运行时（perform/handle 通道）对短路路径有真实开销——每刀记录关联族时长对照（T1 直跑 + T2 长族），超窗位（tier 表 timeout_s 天花板 = 基线 ×2.5）即回退该位消费（K129 纪律：不投机微调，实测裁决）。
5. **std/ 装配面 = 既有前缀注入族**：消费 std/error.ktf、std/log.ktf 的孪生件经**前缀装配**（`assembled_*_target_source` 前缀拼接——r121 INJ 族 + r146/r148 段装配 + r192 INST-1(a) 同形制先行）；装配函数在 harness 面（crates/kerf-driver bootstrap 装配族——**验证基建面非 oracle 面**，r174 裁定第 5 条 GHC 教训：验证驱动器保持宿主侧）。

**§3.5 零新桥承继**：r174 桥模式终局裁定直接承继——oracle 冻结于 v0.125.0 语言面（r182-r194 五次行使先例），本窗**零 oracle 共同实现义务**、零新 Rust 桥；验证 = 金档期望 + fixpoint 三阶段 B≡C + audit live 三面（用户桥指令「可审查去除不必要的」——本窗审计结论 = 无新桥，承继裁定即结论）。

## 4. 时机触发器（四件——全达成 @ r195）

| # | 触发器 | 状态 |
|---|---|---|
| ① | 效应族能力里程碑确认完善（三段链 CLOSED @ r194：行类型 r182-r185 + 效应机制 r187-r189 + 六实例 r192-r194——r180 后全部新表面能力）= 用户指令③「每当确认完善 kerf 端自己特性和能力时〔基础核心先行后延伸〕」的触发条件 | **✓ 达成 @ r194** |
| ② | 自由排期区无更高优先自举段（§21.12-28——G1-G8 全 ✓ 终态 + 效应族链闭合；11 候选窗触发器逐一核对零信号〔§17.2 扫描裁定——tech-debt r195 检视〕；自举链消费自身最新能力 = 自举段最高优先活动） | ✓ 达成 @ r195 扫描 |
| ③ | 验证安全网在位（T2 全量 fresh 全绿基线 @ r194 + fixpoint B≡C 位级 + audit 512 live EXIT 0） | ✓ 达成 |
| ④ | 用户显式排期（本轮常设指令③原文 + 「放行继续推进和演进」——与 r174 开 modern-1 同一指令族） | ✓ 达成 @ r195 |

## 5. 开窗前置门（四件）

1. §13.1 设计对齐：本档 §1-§3 即对齐产物（表面规范锚 subset-spec 行词汇三机 + handle/perform 冻结面；消费映射表 = 每刀 a-MUV 义务——modern-1 §9-§14 同形制）。
2. §21.12-28 合规：自举段（编译管道自举面的源码现代化续作）= 最高排期优先级 ✓；排期非自举段裁决理由在案（11 候选窗零信号——扫描裁定）。
3. 8 原语不变性核对（第 152 轮——设计面）：行词汇 = r184 交付的既有皮肤（`;` 尾分隔裁定——零语法增改）；handle/perform = r187 交付的既有冻结面；std/ = r192-r194 交付的库词汇（.ktf 语言内组合非原语）；本窗 = **表面与词汇消费**，核心产消经脱糖抵达同一 CoreExpr——零新原语·零通道·零 VM·零语法变更 ✓。
4. 孪生可表达性：效应族链表面已全量入生产链（target-parser 行三机 r184 + expander 合成模式 r184 + infer 行/效应推断 r182/r188 + compiler handle 域烘焙 r187）——孪生源自身消费这些表面 = 生产链已可处理 ✓（meta-circular：行机器消费行词汇、效应推断面携带效应行注解）。

## 6. 刀级 MUV 排期（最小先行 + 逐刀 parity/fixpoint 门——modern-1 刀序同构）

| 刀 | 对象（行数 @ r194） | 内容 | 验收门 |
|---|---|---|---|
| 刀 1 | semver.ktf（337→340）+ micro-toml.ktf（662→680） | 试点刀：解析拒绝族 → attempt/raise（C2——M1-M12）；开帧 → 行字面量/行模式（C1——M13/M14）；消费映射表 §9 落档 + 探针法证 P1-P10 + std/ 前缀装配 M15 + drive_vm_only 五族切换 M16（eval 轴退役——K15 诚实账 + TD-031 登记） | ✅ DELIVERED @ r196（parity 六族绿 8+14+8 + kp 6/7 双绿 + fixpoint 位级 + T2 fresh 70/70 EXIT 0 + 性能 §9.1 五族 ±2% 零回退 + 金链 v0.140.0） |
| 刀 2 | manifest.ktf（525→545）+ lockfile.ktf（675→703）+ resolve.ktf（517→544） | 组合程序族三件（manifest 9 + lockfile 8 + resolve 16 err 位点 + 36/34/38 first 位）；resolve 世代穿线评估（C5——自然形则消费，无则边界③关） | ✅ DELIVERED @ r197（parity 六族绿 + kp 三态带回退 + fixpoint 位级 + T2 fresh 70/70 EXIT 0 + T1 时长 §9.3 五族 ±2% 零回退 + 金链 v0.141.0；C5 关闭——无自然形裁定 §9.2） |
| 刀 3 | typecheck.ktf（1,264→1,304）+ target-lexer.ktf（1,069→1,128）+ **连锁 compiler.ktf（1,958→1,968）** | 判定面/词法面（60/69 + 70/104 first 位；target-lexer 4 err 位——词法拒绝族 C2 评估）；**诊断累积面不开 Error 消费**（边界②——typecheck diags 维持现形勘定入表） | ✅ DELIVERED @ r198（M35-M49 §9.4：lexer C2 29 位 raise 化 + 双件 C1 pair 模式化〔Rust reader 边界 M49〕+ 边界②勘定 + M46 harness 六件共变 + M47 compiler handle 发射修复 + M48 TD-032 结构锚豁免 + parity 关联族全绿 + T2 fresh 70/70 EXIT 0 + 性能 §9.5 八族带内 + 金链 v0.142.0） |
| 刀 4 | compiler.ktf（1,968→1,917）+ macro.ktf（733→751） | ✅ DELIVERED @ r200（M50-M58 §9.6：compiler C2 八 raise 位 + 七守卫溶解 + cp_err 退役 + estate/proto 判别头丢弃〔~85 读位移位；产物面重建头〕+ cp_run attempt 契约面〔result define 逐字节冻结〕+ M57 handle 域勘定 + macro 零消费双裁定 + M58 harness 共变〔STD_ERROR 七装配位 + eval 轴退役 + 台账六退役 39→33 + 锚 40→36 + TD-032 扩展〕；段开关 39/39 + fixpoint B≡C 位级 + T0 29/29 + T1 59/59 + T2 fresh 70/70 + 金链 v0.143.0；r199 手术随收割丢失 → r200 锚恢复后全量重执行） | 刀 5 领地注记：macro 遮蔽族两份共变 + expander 20 err 位 |
| 刀 5 | expander.ktf（5,286→5,085）+ macro.ktf（751→753） | ✓ DELIVERED @ r201（M59-M73 §9.8）——C2 展开拒绝族：M59 ex_fail 体 perform raise（双件同体——遮蔽族纪律）+ M60 44 dead-nil 位 + M62 1 续行位（ex_declare mod-dup 臂）+ 68 final-expr 位零改动+ M63/M64 守卫溶解（39 walk 守卫含 3 单行形 + 6 between-helper 双形）+ M65 ex_run 契约面（unwrap(attempt(thunk), ||(e){e})——种子八项 thunk 外纯函数实证；result define 逐字节冻结）+ M66 ex_err 单元退役双件+ C1 评估关闭 M72（零消费三论据：M49 行词汇不可表达+ 活 tag 普查全分派零死头 + 内部形已裸 pair）+ macro 遮蔽族两份共变 M68-M71（同体手术 + 1 dead-nil @735 + 1 守卫 @367）+ M73 harness 共变（STD_ERROR 前缀 target_corpus 单点 + abc ccf_expander+ TD-032 豁免集扩展 ccf-expander + 稳链 eval 轴退役 expand_dual/per_source_route 单轴化+ composed 双位 + eval_inventory C9→8）；段开关 39/39（expand 9/9 79s）+ fixpoint B≡C 位级 + T0 29/29 + T1 59/59+ T2 fresh 70/70（abc 625s 双 fork 守护进程承重 + audit 451s live EXIT 0）+ 金链 v0.144.0；性能 §9.9 段开关四族带内 + abc +11% 真实载荷增量披露 | 刀 6 领地注记：infer 行机器消费行词汇 + target-parser 收官 |
| 刀 6 | infer.ktf（5,532）+ target-parser.ktf（5,122） | 收官双件：**行机器消费行词汇**（meta-circular 亮点——infer 11 处 `pair("row"…)` 构造位 + 行字段表导航 → C1）；233/203 first 位；效应行注解 API 面（C4——raise 助手注解钉金档） | 全 parity sweep + fixpoint B≡C + T2 全量（§19.3）+ 出口六条核对 |
| close | 窗口收口 | 出口核对 + 文档共变（台账逐件改账 + selfhost/README 消费注记 + 矩阵 §7 行注记 + roadmap/completion-plan）+ §19 双包 | 出口六条逐条 ✓ → CLOSED |

**每刀义务**（孪生手术纪律 §21.12-33③——亲执）：a 裁定（消费映射表 + 边界勘定 + 不消费位理由）→ b 重构 + parity 族绿 + T1 时长对照 → c 台账/RELEASE_NOTES 共变 + 金链 bump（v0.140.0 起逐刀）→ T2 门（末刀/close）。**回退预案**：每刀独立可回退（git 刀前锚）；效应消费位超窗（边界④）→ 该位回退导航形，其余位维持。

## 7. 出口判据（窗口 CLOSED 六条）

1. **12/12 件消费落位**：每件消费映射表落档（消费位/不消费位及理由逐位可审计）；标签键导航位（C1 判据内）与短路错误穿线位（C2 判据内）全量转化或勘定理由在案。
2. **表示恒等**：全 parity sweep 族绿 + fixpoint 三阶段 B≡C 位级 + audit live EXIT 0（零 oracle 文件机检——r174 冻结裁定第六次行使）。
3. **std/ 装配面**：前缀装配首例落位 + 决定性守卫共变 + 装配面零 oracle 依赖机检。
4. **性能诚实账**：每刀 T1 时长对照 + T2 长族全绿（超窗位回退记录在案——边界④执行凭证）。
5. **效应行注解 API 面**：raise 助手注解金档钉死（C4——ann_pin 形制）。
6. **治理收口**：台账逐件改账 + selfhost/README 消费注记 + 矩阵 v1.2x §7 行注记 + roadmap/completion-plan 共变 + RELEASE_NOTES + worklog 双档 + §19 双包。

## 8. 零载荷边界

开窗轮（r195）= 纯治理面（本档 + 共变链 + 检索存档）——零生产代码、零 crates/ 变更（机检）；刀 1 起（r196+）每刀独立行权、独立验收、独立可回退；本窗零新原语·零通道·零 VM 面·零语法增改·零新桥（§3.5）——一切消费经既有冻结表面与既有库词汇（原则 1/38/41/53 同族纪律）。

## 9. 刀 1 消费映射表（a-MUV 裁定 @ r196——semver.ktf + micro-toml.ktf 试点）

**探针法证基础**（r196 临时探针 10 项，跑后删——r192/r193/r194 先例形制；结果落本表）：

| # | 形制 | 孪生链（读/展/查/编） | Rust 检查器（drive_dual_engines 钉面） | VM | eval |
|---|---|---|---|---|---|
| P1 | k 形式 raise（error.ktf 原生 attempt + halt 子句） | ✓ | ✓（R5 仅顶层立即 perform——fn 体内 raise 零静态检查） | ✓ 99 | ✗ arity（eval handler 入口只传 perform 参数——k 参无传递） |
| P2 | k 形式 ok 路径（handler 不触发） | ✓ | ✓ | ✓ 42 | ✓ 42（handler 从未入调） |
| P3 | 退化形（params==args，pos-021 族） | ✓ | ✓ | ✓ 3 | ✓ 3 |
| P4 | 退化形续体行为 | ✓ | — | ✓ 30（(1+2)*10——perform 位点值替换·body 继续） | ✓ 30（同）——**退化形不能承载短路语义，k 形式为 Error 实例必需** |
| P7 | 行模式同名绑定（[x: x]） | ✓ | — | ✓ 12 | ✓ 12 |
| P8 | 行帧函数内解构（mt_flush 形制） | ✓ | — | ✓ 12 | ✓ 12 |
| P9 | 契约面 wrapper（unwrap(attempt(thunk), identity)）ok/raise | ✓ | ✓ | ✓ 双路 | ok ✓ / raise ✗（同 P1） |
| P10 | 多帧深位 raise 回卷（mt_loop 递归形制） | ✓ | — | ✓ "deep" | ✗（同 P1） |

**验证面裁定（VM-only 政策——探针驱动）**：五个 pkg parity 族（semver/micro-toml/manifest/lockfile/resolve）从 drive_dual_engines 切换 drive_vm_only——**eval 轴对效应消费孪生退役**。依据三重：(i) r187 交付本身将 k 形式 one-shot 语义限定 VM 面（r188 双引擎 lane 豁免 handle-rows 探针——既定先例线）；(ii) r192-r194 实例语料自首日起 VM-only 驱动——pkg 族加入效应消费类 = 政策自然延伸；(iii) eval 引擎 k 形式 halt 子集扩展 = 在验证引擎内二次实现 halt 语义 = **新桥**（r174 终局裁定 + 用户桥指令禁止）。**K15 诚实账**：五族 eval 轴退役（~141 案的引擎一致性检查面），oracle 对照轴（第三轴）全量承载——twin-vm == oracle 逐案维持；登记 TD-031（P2——eval 引擎 k 形式缺口；触发器 = 未来任何对效应消费孪生的 eval 轴需求 → eval k 形式 halt 子集窗评估，零信号不开）。

**C2 消费映射——semver.ktf（13 个 err 穿线位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M1 | sv_num_accum 溢出臂 | `perform raise(原 ("err" "not-a-number" s e) 记录)`；成功返回裸 acc | 载荷 = 原错误记录逐位 |
| M2 | sv_num_component 四失败臂 | 同上 perform raise；成功返回裸 i64 | 错误操作数 = 组件自身文本（符号含） |
| M3 | sv_version_rest / sv_constraint_three | 溶解入 sv_version_io / sv_constraint_io（三组件直接 let，match 级联全拆） | 首失败左→右序保持（求值顺序 = 绑定顺序） |
| M4 | sv_parse_version / sv_parse_constraint 的点数形错 | perform raise(原 version-form / constraint-form 记录) | (0 0) span 形保持 |
| M5 | sv_parse_version / sv_parse_constraint 函数面 | **契约面冻结**：`unwrap(attempt(|| { pair("ok", pair(io(bytes), nil)) }), ||(e) { e })`——("ok"/"err") 记录位级不变 | 下游 manifest/lockfile/resolve 消费面零扰动（它们 match 这些记录） |
| — | sv_caret_satisfies / 三个入口 define | 不消费（纯函数无 err 路径 / 消费契约记录） | — |

**C2 消费映射——micro-toml.ktf（9 个 err 穿线位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M6 | mt_err / mt_err_f | 保持纯构造器；每个失败位 = `perform raise(mt_err(...))` | 记录形状 ("err" kind line col fs fe) 逐位 |
| M7 | mt_validate_header | raise / 裸 nil（ok 记录退役） | 错误序保持（尾部检查先于名校验——oracle 自身序） |
| M8 | mt_section_header / mt_array_header | 返回开帧（raise on 失败）；match v 级联拆 | 帧值 = 4 槽 cons 链逐位 |
| M9 | mt_string_value / mt_int_value / mt_int_accum / mt_value | 返回载荷 pair(val, rest_off)（raise on 失败） | escape/越界/非裸键错误逐位 |
| M10 | mt_entry | 返回条目记录（raise on 失败）；值载荷经 match pair 模式解构 | 条目记录 = 外部契约（见 M14 不消费位） |
| M11 | mt_loop | 返回裸 doc；h/e 的 ("err",_) match 臂全拆（raise 回卷递归——P10 实证）；dup-key 两位 raise | 文件序 doc 构建 / 全局-表内双 seen 轨道保持 |
| M12 | mt_run 函数面 | **契约面冻结**：unwrap(attempt(thunk), identity)——("ok" doc)/("err" …) 位级不变 | mt_verdict/mt_failed/mt_doc/mt_error 入口 define 零改动（harness + manifest 消费面） |

**C1 消费映射——micro-toml.ktf（开帧四处）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M13 | 开帧构造三位（mt_section_header / mt_array_header / mt_loop open2 重建） | 行字面量 `[is_array: .., name: .., entries: .., seen: ..]` | 运行时值 = 同一 4 槽 cons 链（行字面量脱糖 = 值右折——RW-13；P8 实证引擎中立） |
| M14 | 开帧导航两位（mt_flush / mt_loop 表内分支） | 封闭行模式 `[is_array: a, name: n, entries: e, seen: s] => { .. }` + `_` 诚实不可达臂 | 列槽表（list 值槽）= 行优于 struct 的位点（struct 字段标量限定——modern-1 M4 勘定；行字面量无需注解） |
| — | **不消费位（边界③）**：doc 记录（"g"/"e"/"t"/"a"）+ 条目记录 = 外部契约面（harness + manifest 解码——cons 形冻结）；值载荷 (val, rest_off) = 位置 2 槽中间形（单点消费直读）；**semver = 零 C1 位**（全标量/struct——诚实披露） | — | — |

**装配面映射（harness 面——边界⑤）**：

| # | 位点 | 消费形 |
|---|---|---|
| M15 | vm_harness.rs 新增 `STD_ERROR_TARGET_SOURCE`（唯一嵌入）+ 五 pkg parity 装配 + pkg_selfhost 五件装配前缀 error.ktf | r192 INST-1(a) 前缀注入同形制；harness 面 = 验证基建（r174 裁定第 5 条——非 oracle 面） |
| M16 | vm_harness.rs 新增 `drive_vm_only`；五 pkg twin_dump 切换 | 不消费位：pkg_window（kp CLI e2e——本就单 VM 生产驱动）/ steady 族与 twin sweep 族（pkg 源非其 subject）/ fixpoint 载体（pkg 孪生不在编译器/展开器载体内） |

**性能诚实账（边界④）**：§9.1 落档（r195 双引擎基线 vs r196 VM-only 实测——五族全部噪声内，零超窗位，零回退）。

### 9.1 刀 1 性能实测对照（边界④执行凭证——batch.log 双跑实测）

| 族 | r195 基线（双引擎） | r196（VM-only + 效应消费） | Δ |
|---|---|---|---|
| semver_twin | 4.24s | 4.22s | −0.5% |
| micro_toml_twin | 14.04s | 14.18s | +1.0% |
| manifest_twin | 14.22s | 13.96s | −1.8% |
| lockfile_twin | 17.27s | 17.61s | +2.0% |
| resolve_twin | 33.52s | 33.53s | ±0.0% |

**裁定**：五族全部噪声内（±2%）——VM-only 切换减半引擎功（eval 轴退役）与 attempt/handler 安装成本相抵；零族贴 tier 天花板（600s 族级窗），零回退位。行数共变：semver.ktf 337→340（+3——契约面包装两处 + 头注）+ micro-toml.ktf 662→680（+18——行帧模式 + 头注 + 契约面）；台账 18 件 23,994→24,015。

### 9.2 刀 2 消费映射表（a-MUV 裁定 @ r197——manifest.ktf + lockfile.ktf + resolve.ktf 三件套）

**前置确认**：harness 面**零改动**——r196 的 M15/M16 已全覆盖五 pkg 族（`STD_ERROR_TARGET_SOURCE` 前缀在 manifest/lockfile/semver/micro-toml parity + pkg_selfhost 五件组合 L184 装配位；`drive_vm_only` 在五族驱动位；resolve_parity 经 pkg_selfhost 组合装配继承）——刀 2 = 纯三件 .ktf 源面手术。三件今日 rowlit=0（实测）。

**探针法证基础**（r197 临时探针 3 项，跑后删——P1-P10 r196 基础上的增量；结果实测 @ VM）：

| # | 形制 | VM | 判定依据 |
|---|---|---|---|
| P11 | 相位判别自递归（rs_visit phase1/2 形制）+ 6 层交替递归后深位 raise → attempt 捕获原载荷（累加器 33 = 3×1+3×10 完整回卷） | ✓ 33 | k-形式语义与调用深度/相位交替无关（P10 单函数自递归的深一层验证） |
| P12 | 行构造-行模式往返恒等（`[name: a, ver: b, src: c]` 构造 → `[name: n, ver: v, src: s]` 解构 → 重组 == 手折 cons 链双恒等——lk_field/lk_items_walk 形制） | ✓ 1 | RW-13 值右折（P7/P8 原理的构造-解构往返钉死） |
| P13 | thunk 内契约面 match + 多 raise 位（mf_project 微缩形：("ok"/err) 输入 match 保留 → ok 臂内 thunk 双 raise 位 + ok 构造 → unwrap 四路断言 1111） | ✓ 1111 | P9 wrapper 双路 + match 嵌套 + thunk 捕获 match 臂绑定的组合钉死 |

**探针过程钉死的四条语言面事实**（手术形制的硬约束——探针首形踩中后逐条实证）：

1. **`==` 数值专用**：Typecheck 拒绝 str 操作数（`expected int or float, found str`）——tag 比较一律走 match 字面量头模式（既有源码的全部分派形制的根因）。
2. **match 臂列表尾逗号必需**：reader 拒绝无尾逗号的尾臂（`unexpected token }`）——手术中新增/改动的每个 match 都带尾逗号。
3. **嵌套位字面量头模式被 Typecheck 拒绝**（E0009 `expected pair, found str`）——嵌套 tag 检查走两步分派（先绑定再字面量头 match——mf_shift_err 惯用形）；顶层头字面量 ✓。
4. **pair 即 cons，载荷 = 平链**：`pair("err", pair(kind, pair(a, b)))` = `("err" kind a b)` **四元素平链**（非嵌套 pair）——semver 记录形 `("err" kind fs fe)` 的构造语义；raise 载荷与检查模式均按平链对齐（探针首形按嵌套预期全错、平链语义下全绿——机制本身零缺陷，纯属形制澄清）。

**C2 消费映射——manifest.ktf（9 个 err 穿线位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M17 | mf_scan_globals 四错误臂（bad-name / package-not-string / version-not-string / unknown-key） | `perform raise(mf_err4(...))` 载荷 = 原记录逐位；nil 臂返回裸 `pair(pkg, pair(ver, nil))`（ok 包装拆） | 首错误文件序返回保持（递归短路序 = raise 回卷序） |
| M18 | mf_version_project bad-version 臂 | raise（mf_err_nested 原记录）；sv_parse_version match **保留**（契约面消费——§9 M5 冻结）；成功返回裸 triple | 嵌套 semver 拒绝 shift 后逐位（mf_shift_err 保留契约面消费） |
| M19 | mf_dep_entry 三错误臂（bad-name / dep-bad-constraint / dep-not-string） | raise（6 槽嵌套记录逐位）；成功返回裸 Dep 记录 | dep-bad-constraint 双 span + shifted inner 载荷逐位 |
| M20 | mf_scan_items 两错误臂（unknown-section / unknown-section-array）+ dep_entry match 溶解 | raise；成功直接 `pair(item, deps)` 续递归；nil 臂返回裸 deps | 表序 deps 收集保持 |
| M21 | mf_project 函数面 | **契约面冻结**：`unwrap(attempt(thunk), identity)` 包装；mt_verdict match 保留（契约面输入）；syntax 直通臂保留（mt 层错误转传非内部穿线）；missing-package/missing-version 位 thunk 内 raise；最终 ("ok" body) 构造不变 | mf_verdict/mf_project 输出位级不变（harness + resolve 消费面零扰动） |
| — | 不消费位：mf_err4/mf_err_nested 纯构造器（M6 先例）/ mf_shift_err（契约面消费）/ 标量函数群（kebab/键匹配/slice/sort）无 err 路径 | — | — |

**C2 消费映射——lockfile.ktf（8 个 err 穿线位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M22 | lk_raw_walk render-bad-version 臂 | raise（fail-closed 守卫——构造面非语料面）；sv_parse_version match 保留（契约面消费）；nil 臂返回裸 acc | ("ok" 1 out) 契约形状 |
| M23 | lk_render_face 函数面 | `unwrap(attempt(thunk), identity)`；match r 溶解 | lk_render_out define = harness 解码面，位级不变 |
| M24 | lk_scan_globals 两错误臂（version-not-int / unknown-key） | raise；返回裸 fmt | fmt nil 哨兵穿线保持 |
| M25 | lk_close_or_pass 三错误臂（missing-name / missing-entry-version / missing-source） | raise；ok 包装拆（返回裸 acc 或 (rec . acc)） | 关闭序 = 字段序（name→ver→src） |
| M26 | lk_field 五错误臂（name/source/version-not-string / unknown-package-key / bad-entry-version 嵌套） | raise；sv_parse_version match 保留（契约面）；成功返回裸 3 槽（配 M33 行字面量） | 嵌套 shift 后逐位 |
| M27 | lk_items_walk 三错误臂（entry-outside-section / unknown-section-array / unknown-section）+ field/close match 全溶解 | raise；nil 臂返回裸 acc | 头先关闭后分派的 oracle 步序保持 |
| M28 | lk_project 函数面 | `unwrap(attempt(thunk), identity)`；fmt 三检查位（missing-version / newer-format ×2）thunk 内 raise；syntax 直通臂保留 | ("ok" fmt out) 契约形状；lk_parse_out define 位级不变 |
| — | 不消费位：lk_err5/lk_err_nested/lk_shift_err 构造器与契约面消费 / 渲染管线（lk_render_lock 族）纯函数零 err 路径 | — | — |

**C2 消费映射——resolve.ktf（16 个 err 穿线位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M29 | rs_visit phase1（depth 位 + gray-cycle 位）+ ("ok" ctx) 穿线全拆 | raise（rs_err_depth / rs_err_cycle 原记录）；返回裸 ctx；phase1→phase2 调用点 match 溶解直接 let | 三色 DFS 步序（深度帽先于色查 / 灰栈环路径）逐位 |
| M30 | rs_visit phase2 五错误位（dep-dir-not-found / manifest-not-found / io / name-mismatch / cycle） | raise；**mf_project 契约面 match 保留**（("ok") 臂 + `_` 臂 raise rs_err_mf——mf_project 输出 = 跨件契约面）；phase2→phase1 调用点 match 溶解 | 边记录先于色查的 oracle 序逐位；rs_err_mf 载荷 = raw mf 记录逐位 |
| M31 | rs_check_imposed version-conflict 位 + rs_verify match 溶解 | raise（rs_err_conflict 原记录）；返回裸 nil；verify 直接递归 | 全 imposed 列表一次报告（r160 语料面——mid-list 违约仍报全列） |
| M32 | rs_run root 三位（not-found ×2 / io）+ w/v match 溶解 | raise；**mf_verdict 契约面 match 保留**（`_` 臂 raise rs_err_mf）；最终 ("ok" order lock) 构造 + `unwrap(attempt(thunk), identity)` 包装 | result define = harness 解码面（pair("rs", ...) 外壳 + ("ok" order lock) 内形）位级不变 |
| — | 不消费位：rs_err_* 八构造器（M6 先例）/ rs_lock 纯函数 / 目录表与 assoc 通用结构（见 C1 裁定） | — | — |

**C1 消费映射——lockfile.ktf（lk_field 3 槽 slots，自然位）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M33 | lk_field 三成功臂的 ("ok" (name ver src)) 包装 | 裸行字面量 `[name: ..., ver: ..., src: ...]`（M13 形制——脱糖 = 值右折，运行时值 = 同一 3 槽 cons 链） | 字段序 name→ver→src（P12 往返恒等钉死） |
| M34 | lk_items_walk 解构位（三 first/rest 链 L570-572） | 封闭行模式 `[name: n2, ver: v2, src: s2] => { .. }` + `_` 诚实不可达臂（M14 形制） | P12 探针先行 |
| — | **manifest 零 C1 位（诚实披露）**：Slot/Dep 已 struct（modern-1 消费）；mf_split_globals 2 槽 + mf_scan_globals 返回 2 槽 = 位置中间形单点直读（§9 M14 不消费位先例） | — | — |
| — | **resolve 零 C1 位（裁定）**：① rs_ctx 5 槽的读取-修改-重建往返形制（5 读位 + 4 重建位，assoc_set 逐槽更新）与行模式一次性解构形不匹配——访问器函数 = 诚实面先例（§10.3-3）；② rs_entry 3 槽 = harness 注入面（rs_table define 由 harness 构造）= 合同面冻结；③ order/edge/assoc 记录 = 跨件合同面（resolve→lockfile lk_entry_into 消费 + harness 解码）= 边界①保守冻结 | — | — |

**C5 评估裁定——resolve 世代穿线：关闭（无自然形，边界③）**。三条论据：① State 世代链形制 = driver 侧世代递归（get 读当前世代 / put 开新世代 + halt 截断——INST-6 + r192 探针 A 的 capture-frozen 读），resolve 的 ctx 穿线 = 数据递归 DFS（父传子初始 ctx、子传回更新 ctx、递归返回后父继续用子结果）——双向穿线在 State 词汇无自然表达（state_thread 是 driver 驱动 body 重入，非被调函数传回值）；② put 的 halt 截断语义（put 之后同世代代码不跑）与 DFS 的"递归返回后继续 rest(deps)"直接冲突；③ 显式参数穿线本身就是函数式状态传递的自然形——State 强加 = 过度特化（违反通解原则，§1.2 用户指令「禁止过度特化」）。**登记**：C5 于刀 2 关闭，后续刀不再评估（除非 resolve 语义变更）。

**性能诚实账（边界④）**：§9.3 落档（r196 基线 manifest 13.96s / lockfile 17.61s / resolve 33.53s vs r197 实测）。

### 9.3 刀 2 性能实测对照（边界④执行凭证——T2 fresh batch.log 双跑实测）

| 族 | r196 基线（VM-only） | r197（VM-only + 刀 2 效应消费） | Δ |
|---|---|---|---|
| manifest_twin | 13.96s | 14.18s | +1.6% |
| lockfile_twin | 17.61s | 17.60s | −0.1% |
| resolve_twin | 33.53s | 33.61s | +0.2% |
| semver_twin（对照） | 4.22s | 4.19s | −0.7% |
| micro_toml_twin（对照） | 14.18s | 14.14s | −0.3% |

**裁定**：五族全部噪声内（±2%）——三件消费（raise 短路替代 match 穿线）与 attempt/handler 安装成本相抵；零族贴 tier 天花板（600s 族级窗），零回退位。行数共变：manifest.ktf 525→545（+20——头注 + 契约面包装 + 溶解净减穿线）+ lockfile.ktf 675→703（+28——含 M33/M34 行词汇两处）+ resolve.ktf 517→544（+27——含头注 + 宽度守卫折行两处）；台账 18 件 24,015→24,090（+75 wc 实测）。

### 9.4 刀 3 消费映射表（a-MUV 裁定 @ r198——typecheck.ktf + target-lexer.ktf 判定面/词法面对）

**勘定基础**：双件三源深读（typecheck 1,264 / target-lexer 1,069）+ 错误位 grep 实证（typecheck 0 个 `"err"` 位 / target-lexer 内部 `"e"` 形 4 构造位 + 28 调用位 + 2 检查位）+ r196 P1-P10 / r197 P11-P13 探针事实集复用（**零新探针裁定**：刀 3 全部形制落在已钉死的语言面事实内——k 形式 raise 四面行为〔P1〕、契约面 wrapper 双路〔P9〕、多帧深位回卷〔P10——tl_string_body 8 层递归同形〕、行模式解构〔P7/P8/P12〕、行字面量值链同形〔P12/M13〕；无新语言面事实 → 无新探针义务）。

**target-lexer.ktf（1,069——主手术件：C2 词法拒绝族 + C1 成功形中间帧行化）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M35 | tl_err_one/tl_err_at/tl_err_span 三构造器 | 构造器体内直接 `perform raise(pair("err", …))`——载荷 = **契约面 err 记录**逐位（"e"→"err" 头升级：原内部形仅 tl_start 边界转 ("err" …)，现构造即终形）；**28 个调用位零改动**（调用形保持 `tl_err_span("malformed-number", start, end)`——构造即短路） | 载荷 = ("err" kind payload…) 契约面形逐位；kind/payload 六族（unexpected-char/unterminated-string/invalid-escape/malformed-number/int-out-of-range/unclosed-delim）原样 |
| M36 | tl_scan mode-2 unclosed-delim 内联位（1 位） | `perform raise(pair("err", pair("unclosed-delim", pair(cstart, nil))))` | cstart = 最外层开锚（oracle 报告锚）保持 |
| M37 | tl_start 两 `"e"` 检查位 | 溶解——sc/t 恒成功形（错误已在深层构造位短路回卷）；主循环递归位直绑 | 每 token 一帧 + 瞬态帧深纪律（帧形头注）保持 |
| M38 | 顶层 `define(tl_verdict, …)` | `unwrap(attempt(|| { tl_start(source_bytes, 0, nil) }), \|(e) { e })`——成功路 ("ok" tokens) 裸返回，raise 路 unwrap identity 透传 | tl_verdict/tl_tokens/tl_error/tl_failed 四 define 形状逐位冻结（decode 契约面）；result 别名保持 |
| M39 | tl_ok ("t" record remaining pos) 4 槽 × 19 构造位 | **裸 3 槽值链** `pair(record, pair(remaining, pair(pos, nil)))`（"t" 判别头经 M35 短路化后 = 死数据，丢头）——**修正裁定（Rust reader 边界）**：本孪生是读链自举内嵌件，链自身构造经冻结 Rust reader（v0.125.0 语言面——r184 行词汇之前的面），**行字面量形不可用**，嵌套 pair 构造（modern-1 G8 皮肤）承载同等表示清理 | record 槽 = token 记录原形（产物面）逐位——("kw-fn" s e) 等位置元组不转行（边界③） |
| M40 | tl_start 消费位（first(rest(t)) 三层导航） | `match t { (tok, (rem2, (p2, nil))) => { … }, _ => { … } }`（嵌套 pair 模式——同上修正裁定；`_` 诚实不可达臂先例形制） | eof token 构造（(len) 载荷）与 acc 前累积序保持 |
| M41 | tl_scan ("s" remaining pos) × 5 构造位 | **裸 2 槽值链** `pair(remaining, pair(pos, nil))`（同上；mode 递归透传位 12 处零改动——尾位直传） | trivia 三 mode 语义 + cstart 锚保持 |

**不消费位勘定（target-lexer）**：token records 位置元组族 = 产物面冻结（边界①）；byte 表导航（first(remaining)/tl_drop 族）= RS-1 通道契约位；tl_word_tag 关键字表/tl_op 算子表分派 = modern-1 G8 match 皮肤既有位（r177 形制——刀 3 不重复消费）；tl_char_code/tl_bytes_eq/tl_rev 纯函数 = 无标签键数据。

**typecheck.ktf（1,264——勘定件 + C1 小手术：边界②实义 + 2 位族行化）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M42 | **边界②勘定（零 C2 消费）**：全文 0 个 `"err"` 位——tc_walk = ruling 21 多错误收集架构（tc_report 进 tc_diags 流继续走，永不短路）；attempt/raise 只替换**短路单错误**路径（§3 边界②原文）——累积面维持现形 | 不消费（勘定入表） | ("diags" …) 产物面 + 报告序保持 |
| M43 | tc_ext_table entry ("e" name arity) 3 槽 × 1 构造位（tc_ext_insert） | **裸 2 槽值链** `pair(name, pair(arity, nil))`（"e" 判别头 = 死数据——匹配位从未检查头）——**修正裁定（Rust reader 边界）**：本孪生是检查链自举内嵌件（steady check / abc 链），构造经冻结 Rust reader，行字面量形不可用，pair 形承载（表条目 = name→arity 映射的 C1 环境表语义保留） | last-binding-wins（remove-then-append）序 + 18-builtin 覆盖语义保持 |
| M44 | ext 表导航位 × 4（tc_ext_remove 匹配 / tc_ext_find_last 匹配 / tc_extern_lookup 取 arity） | 嵌套 pair 模式解构 `(n2, (a2, nil))`（同上修正裁定） | 两值归约（arity-or-nil）面保持 |
| M45 | tc_let_stack entry (body mark) 2 槽 × 1 构造位（"let" 臂）+ 消费位（letbinds 终止臂 first/tc_2） | **裸值链** `pair(body, pair(mark, nil))` + 嵌套 pair 模式解构（同上） | LIFO 对称性（嵌套 let 值内配对）+ let* 可见性语义保持 |

**不消费位勘定（typecheck）**：tc_2..tc_8 访问器族（~40 位）= CP-1 注入记录流导航（位置平链，compiler/infer 同词汇**跨件契约面**）→ 边界③保留原导航；tc_handlers 栈（clause = 注入流 handler-clause 记录原引用）= 契约位；tc_marks/tc_locals = 纯标量栈/name 链（非标签键数据）；tc_report/tc_defines_face/result 表构造位 = 产物面冻结；R1-R8/LA7 规则分派 = r177 M21-M25 match 皮肤既有位。

**harness 共变（M46——装配 + 驱动切换，M15/M16 先例延伸）**：

| 位点 | 共变 |
|---|---|
| target_lexer_parity.rs twin_dump | 前缀拼 STD_ERROR_TARGET_SOURCE（vm_harness L416 单源）+ drive_dual_engines → **drive_vm_only**（eval 轴退役——TD-031 范围扩展至 target-lexer 族：P1 事实 eval handler 入口 k 参不传）；返回 (vm, eval) → 单轴 |
| target_lexer_parity.rs parity 比较面 | 三路（vm/eval/oracle）→ 两路（twin-vm == oracle——M16 先例） |
| abc_pipeline.rs ccf_lexer_source | extern 声明后拼 STD_ERROR 前缀（链条经 Rust 生产管线编译：reader ✓ 冻结面 / checker ✓ fn 体内 raise 零静态检查〔P1〕/ compiler ✓ handle 域烘焙 r187 / VM ✓ k 形式 one-shot） |
| steady_target_reader_chain.rs new_with_limit | lexer_program 前缀 STD_ERROR（固定程序单源装配） |
| determinism_guard_tests.rs | reader_assembled 前缀 STD_ERROR（双遍历 debug_info 比对面） |
| twin_dump 5 消费位（target_lexer_twin_tests ×3 / steady_target_reader_tests ×1 / parity 内部 ×1） | (vm, eval) 二元解构 → 单轴 |
| abc_pipeline_tests 裸源断言 | contains("unbound") 语义保持——裸源缺 STD_ERROR → attempt/unwrap unbound 同键同层（expansion 层）——跑门验证 |
| target_parser_twin 链 | **零共变**（parser parity 的 token 流走 oracle lexer〔tp_token_prefix〕——lexer twin 不进 parser 链，勘定排除） |

**12 件自应用闭环**：target_lexer_twin_tests 的 selfhost_sources/disk 双测试对六链件（macro/expander/compiler/infer/**typecheck/target-lexer**）三路 parity→刀 3 后两件新源直接入闭环；hm_twin_face 族（W-HM-TWIN §4 双判定面）+ typecheck_parity 族 = typecheck 手术验证面；abc_pipeline/steady 链/determinism 守卫 = 组合链回归面。

**刀 3 执行期三项连锁发现（当轮清偿/登记——链源首次携带效应族词汇的历史性首次行使）**：

| # | 发现 | 处置 |
|---|---|---|
| M47 | **compiler twin 的 handle 发射位真缺陷**：cp_return_effect 在 cwalk 前**预 intern** "return" 子句效应名 → 全部 clause 效应的 global 槽错位（PushHandler a 槽 + PopHandler b 槽 vs oracle 逐位差）——r187 交付的编译对象面从未被链自编译行使过（链源全部 pre-r187 拼法），刀 3 的 ccf-lexer 首次携带 handle 即暴露（B ≢ C 与 A ≢ B 双红） | **当轮修复**（§20.3 同类路径 + 完整自举优先）：删除预 intern，return effect 改在 cwalk 子句循环内与 push-handler 同点计算（oracle compile.rs 的 in-loop 形制逐位对齐）；the_b_artifact parity row 修复后全绿 = 修复实证 |
| M48 | **infer 差分门 × r188 typed-perform pin 的设计性碰撞**：infer twin 的效应面 live 推断（typed-perform + 行注解——r188 设计交付，hm_twin_face 的 handle-rows pin 先例）与 oracle 冻结 dyn 推断结构性分歧；ccf-lexer 首次携带效应面源 → 分歧 + 全局类型变量计数器偏移 + 下游具体化传导（全 dump 差） | **结构锚豁免登记（TD-032）**：ccf-lexer 的 infer 差分改结构锚形制（tdef 记录数 + 函数名序 + 诊断尾部字节级三锚——结构漂移仍 FAIL；typing 行 = 登记豁免域）；check 差分 + tree identity + compile artifact + B≡C 门四门全保留承载防漂移；刀 6 效应面对齐时收口（豁免撤销 + 差分恢复全严格） |
| M49 | **Rust reader 边界（C1 行词汇的消费面前提）**：读链/检查链自举内嵌件（target-lexer/typecheck）的构造经冻结 Rust reader（v0.125.0 面——行词汇 r184 之前）→ 行字面量/行模式语法在这两件**不可表达** | **修正裁定**：两件 C1 全部回退裸值链 + 嵌套 pair 模式（modern-1 G8 皮肤——判别头照丢、表示清理保持；探针实证 Rust reader 对 r197 lockfile 行字面量同样拒绝——pkg 五件因不经 Rust reader 构造而不受此界）；**行词汇的消费面前提 = 非生产链内嵌件**（刀 4/5 对象 compiler/macro/expander 同受此界——勘定入表防重蹈） |

### 9.5 刀 3 性能实测对照（边界④执行凭证——T1/T2 fresh batch.log + 单跑实测）

| 族 | 基线（r197 时点多轮稳定值） | r198（刀 3 后） | Δ |
|---|---|---|---|
| target_lexer_twin（VM-only） | ~258s（历史带 246-277） | 252.21s / 254.26s（双轮） | 带内（−2% 档，变快方向） |
| abc_pipeline（K159 主 case） | ~562s | <645s（sharded 块内完成，555s 预算 + 90 余量窗） | 带内 |
| steady_target_reader | ~400s（历史带 361-413） | 381.37s（单跑）/ 388s（sharded） | 带内（−3% 档） |
| hm_twin_face | ~5s | 4.68-4.85s | 带内 |
| hm_twin_chain | ~52s | 49.26-50.28s | 带内 |
| typecheck_twin_sweep | ~0-1s | 0.11-0.12s | 带内 |
| determinism_guard | ~25.4s | 25.50-26.29s | 带内 |
| target_parser_twin | ~415s（单跑） | 415.31s（单跑实测）+ sharded 完成态 | 0% |

**裁定**：全部关联族在历史方差带内——raise 消费（构造器内短路替代 "e" 形穿线）与 attempt/handler 安装成本相抵；零族贴 tier 天花板（abc K159 < 645s vs 1800s 族窗），零回退位。行数共变：target-lexer.ktf 1,069→1,128（+59——头注 modern-2 段 + 构造器 raise 化 + tl_start 模式化 + 顶层 attempt 包装）+ typecheck.ktf 1,264→1,304（+40——头注边界②勘定段 + ext/let 表 pair 模式化）+ compiler.ktf 1,958→1,968（+10——M47 修复注释 + cwalk 循环内计算）；台账 18 件 24,090→24,199（+109 wc 实测）。

### 9.6 刀 4 消费映射表（a-MUV 裁定 @ r200——compiler.ktf + macro.ktf 编译面/宏面对；r199 原裁定随收割丢失，本表 = 按 r199-harvest 记录 + 双件全量深读的忠实重建，逐位再验证）

**勘定基础**：双件全量深读（compiler 1,968 / macro 733）+ 错误位 grep 实证（compiler 15 个 `"err"` 文中 8 代码位 + 7 头注档位；macro 2 位 = ex_fail 影子对）+ 行词汇双件零出现机检（M49 边界——两件均链内嵌件，经冻结 Rust reader 构造，行字面量不可表达，C1 消费全部回退裸值链 + 嵌套 pair 模式形）+ r196-r198 探针事实集复用（**零新探针裁定**：刀 4 全部形制落在 P1-P13 事实内——k 形式 raise 四面行为〔P1〕、契约面 wrapper 双路〔P9〕、构造器内短路〔M35 先例——构造即终形〕、thunk 捕获 match 臂绑定〔P13〕；无新语言面事实 → 无新探针义务）。

**compiler.ktf（1,968——主手术件：C2 编译拒绝族 + C1 表示清理 + 契约面包装）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M50 | 八个错误构造位（cp_extern_walk 重复名 / cp_emit stack-underflow / cp_patch stack-imbalance + bad-patch / cp_ewalk depth + assign-to-captured + bad-node / cp_drain unpatched-jump） | `perform raise(原 ("err" kind payload…) 记录逐位)`——构造即短路，深位回卷至顶层 attempt；depth 位的前置 cp_depth 递减 set 与 `false` 返回值一并退役（raise 后状态不可观测——cp_run 全量再初始化） | 载荷 = 七族契约错误记录逐位（extern-name-duplicate / stack-underflow / stack-imbalance / bad-patch / depth / assign-to-captured / bad-node / unpatched-jump）；首错即回卷序 = raise 回卷序 |
| M51 | 七处守卫溶解（cp_emit / cp_emit_jump / cp_patch / cp_set_b 的 `is_nil(cp_err)` 包装臂 / cp_ewalk 全体包装〔含 post-error 短路臂〕/ cp_finish 错误检查 / cp_run 嵌套双检查） | 全拆——raise 短路使守卫成死代码；cp_ewalk 体整体降一层缩进（4 空格——superinstr 篡改锚列位共变 40→36 的根因） | walker BOOL 契约注释族随守卫退役（post-error false 返回位不再存在）；成功路径逐位保持 |
| M52 | cp_err 单元（define + 全部 set 位 + 头注块） | 退役——错误状态经效应通道直达，单元死数据 | cp_run 初始化表的 `set(cp_err, nil)` 同退役；其余十项初始化 set 逐位保持 |
| M53 | estate 判别头（"estate" tag） | 5→4 槽：`(code dbg edepth clen)` 裸值链；四访问器移位（code=first / dbg=cp_2 / edepth=cp_3 / clen=cp_4） | 运行时值 = 同一 4 槽 cons 链（头丢弃 = 表示清理，M49 修正裁定形制——pair 载载） |
| M54 | proto 判别头（"proto" tag） | 9→8 槽：`(name params n-locals locals frees caps parent estate)` 裸值链；**全部 proto 读位整体移位**（cp_2→first / cp_3→cp_2 / … / cp_9→cp_8——85 读位实测；cp_cur_estate cp_9→cp_8〔r199 当轮捕获的双移位坑：cp_7 为误，cp_8 为正〕）；产物面 render **重建** "proto" 头（cp_proto_products 的产物记录形逐位冻结） | 内部表示清理（判别头 = 死数据——匹配位从未检查头）；产物面 ("proto" name params n-locals ("caps" …) ("code" …) ("dbg" …)) 逐位冻结（边界①） |
| M55 | cp_run 函数面 | **契约面冻结**：`unwrap(attempt(|| { do(…初始化…, cp_ewalk(…), cp_emit("halt",…), cp_finish()) }), \|(e) { e })`——成功路 ("ok" …) 裸返回，raise 路 identity 透传 | `define(result, cp_run(items));` 逐字节冻结（fixpoint 结构靶串存活——structural_target_source 的 replace 锚依赖）；四 define 面（result）位级不变 |
| M56 | **M57 勘定（handle 域烘焙内部形 = 编译对象面非自用面）**：cwalk/peff 合成模式编译 handle/perform **表达式**（push-handler/pop-handler/perform 操作码发射）——编译对象词汇面；刀 4 自用的 perform raise / attempt / unwrap 是**效应词汇消费面**——两域并存零混淆，勘定入表防误读（§6 刀 4 行原文） | 不消费（勘定入表） | handle 编译位逐位保持（M47 修复后的 in-loop 形制——r198 交付物） |
| — | 不消费位勘定：cp_2..cp_9 访问器族在**非 proto 记录**上的读位（walker 项 t / 平面流记录 rec / kids / insn / span——CP-1 位置平链契约面）→ 边界③保留；操作码表（cp_op_pops/pushes）= 纯分派表零标签键数据；cp_lit_convert / cp_same_const / interning 族 = 纯函数无 err 路径；extern 消费位（cp_extern_walk 的表收集）= 契约面 | — | — |

**macro.ktf（733——勘定件：零消费双裁定 + 头注档）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M55' | C2 零消费裁定：全文 2 个 `"err"` 位 = ex_fail 影子对（harness 解码契约面——MX-2 宏库对展开失败的记录形），非内部穿线位；展开拒绝族的真正载体 = expander.ktf（20 err 位）→ **刀 5 领地**（遮蔽纪律：本件不越刀消费） | 不消费（勘定入表） | 影子对契约面冻结 |
| M56' | C1 零消费裁定：活 tag 普查——全文 tag 键均为 match 字面量头分派位（syntax-rules 模式匹配词汇），零 first/rest 标签键内部数据导航位 | 不消费（勘定入表） | — |
| — | 头注勘定段（+13 行）：刀 4 双裁定 + 刀 5 领地注记 + 行词汇零出现机检记录；**零代码变更** | — | — |

**harness 共变（M58——装配 + 驱动切换 + 台账，M15/M16/M46 先例延伸）**：

| 位点 | 共变 |
|---|---|
| STD_ERROR 前缀七装配位 | target_corpus 双位（assembled_compiler_target_source_with_limit——steady 生产链装配 + ktf_compile_rich 自装配）+ fixpoint 三位（structural_target_source + 两处 Phase-2 assembled）+ abc_pipeline 一位（ccf_compiler_source——ccf-lexer r198 形制）+ target_fixpoint_tests 一位（测试内联 structural）——孪生自由名（attempt/unwrap/raise）经前缀提供活定义（展开层 unbound 拒绝的解除面；r199 当轮捕获：fixpoint 四位初术遗漏经门审红回补） |
| ktf_compile_rich eval 轴退役 | drive_dual_engines → drive_vm_only（TD-031 政策延伸——孪生携效应词汇即 VM-only）；RichCompileRun.eval_text 字段退役（compiler_parity.rs）；vm/eval 比较位全量溶解（fixpoint ×3 + gate_b + composed_target_read_chain ×2 + target_fixpoint_tests ×3 + extern_consumption ×1 + audit AM03） |
| eval_inventory 台账共变 | 六文件退役（C 桶：fixpoint / target_corpus / compiler_parity / composed_target_read_chain；E 桶：target_fixpoint_tests / extern_consumption_tests）——A3/B1/C13/D3/E17/F1/G1=39 → **A3/B1/C9/D3/E15/F1/G1=33** |
| superinstr 篡改锚列位共变 | `wsi_twin_fusion_arm_tamper` 针串内嵌 40 空格 → 36（cp_ewalk 守卫溶解整体降一层缩进）；F1 直臂针串（无内嵌空白）与 method_jit 双针串零共变（位无关子串） |
| TD-032 matches! 集合扩展 | abc_pipeline L442 `name == "ccf-lexer"` → `matches!(name, "ccf-lexer" \| "ccf-compiler")`——ccf-compiler 携 perform 后 infer 差分入登记豁免域（结构锚三件套守护；刀 6 效应面对齐收口） |
| steady_compiler_chain 头注共变 | L31 「both engines, verdict texts compared」→ 单轴 VM-only 表述（rich 驱动面共变） |

**性能诚实账（边界④）**：§9.7 落档（门审 fresh batch.log 对照 r198 基线——compile_segment_switch release 串行 + K159 + 稳定链族）。

### 9.7 刀 4 性能实测对照（边界④执行凭证——T2 fresh 引擎 ledger + 单跑实测）

| 族 | 基线（r198 时点） | r200（刀 4 后） | Δ |
|---|---|---|---|
| abc_pipeline（K159 主 case） | 557.61s（r198 实测） | 610.32s（双 fork 守护进程直跑实测） | **+9.5%**——结构性增长（ccf-compiler 载 STD_ERROR 前缀后每次 A/B/C 链式编译多编 std/error.ktf 源；族窗 1800s 余量 3×，零回退位） |
| audit（512 live 虚拟面） | ~459s | 467s | +1.7% 带内 |
| steady_target_reader（全族） | 381-388s | ~381s（sharded） | 带内 |
| 段开关四族（release 串行合计） | 224.56s（r199 记录口径） | 227.80s（compile 19.26 + expand 77.97 + check 117.18 + read 13.39） | +1.4% 带内 |
| target_fixpoint（全族 8 案） | ~147s（debug 单跑） | 51.44s（release 引擎整族） | 带内（release 口径） |
| target_parser_twin（6 案 sharded） | ~415s（r198 单跑口径） | 94s（sharded 暖树口径） | 口径不同（r198 = 冷单跑含编译；sharded = 预构建二进制）——非回退，机检绿 |

**裁定**：关联族全部在方差带内或口径换算带内——raise 消费（八构造位短路替代 err 穿线 + 守卫全拆）与 attempt/handler 安装成本相抵；K159 +9.5% = 前缀装配的真实编译增量（诚实披露：每次链式编译多编 ~60 行 std/error.ktf，非噪声），族窗余量 3×；零族贴 tier 天花板，零回退位。行数共变：compiler.ktf 1,968→1,917（−51——头注 +16 / 守卫与包装净减 −67）+ macro.ktf 733→751（+18——头注勘定段，零代码变更）；台账 18 件 24,199→24,166（wc 实测）。

### 9.8 刀 5 消费映射表（a-MUV 裁定 @ r201——expander.ktf + macro.ktf 展开面/宏遮蔽面对；12 件中最大件 + 遮蔽族两份共变）

**勘定基础**：双件全量深读 + 机检勘定（blade5_modern2_expander_transform.py --survey——113 ex_fail 调用位分类〔44 dead-nil / 68 final-expr / 1 continuation〕+ 43 if-is_nil 守卫位拆解〔1 体位 + 39 walk 守卫 + 3 ex_run 三重〕+ 6 not-is_nil between-helper 双形〔4 B1 `} else if` + 2 B2 `} else {`〕）+ 活 tag 普查（pair("tag" 全构造 vs eq/match 分派对照——mapx/pc/row-ext/decls/done/edge/svfold/dfold 全活分派位；car/cdr/cons/p = 产物 var 记录名槽载荷非 tag 头；零死判别头）+ M49 边界预裁定承继（expander/macro = 链内嵌件经冻结 Rust reader v0.125.0——行词汇不可表达——r198 勘定入表防重蹈的直接适用）+ 零新探针裁定（P1-P13 事实集全覆盖：k 形式 raise / 契约面 wrapper / 构造器内短路；let-in-thunk = fn 体语句语法既有事实——零新语言面）。

**expander.ktf（5,286→5,085——主手术件：C2 展开拒绝族 + ex_run 契约面）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M59 | ex_fail 体（@1,032——单一构造位） | `perform raise(pair("err", tail))`——构造即短路；体内 is_nil 首错优先检查溶解（raise 一次性 ≡ 首错优先）；**113 调用位零文本改动**（helper 间接层——M35 先例的逆形：刀 3 改 28 调用位零体，本刀改体零调用位） | 载荷 = ("err" tail) 记录逐位；raise 回卷序 ≡ set 序 |
| M60 | 44 dead-nil 位（`ex_fail(...); nil` 形） | 尾 nil 死码移除 + 尾分号降格（raise 不返回——nil 不可达） | 调用文本逐位（载荷冻结） |
| M61 | 68 final-expr 位 | 零改动（ex_fail 为分支末表达式——raise 使分支不完成，形不变） | — |
| M62 | 1 continuation 位（@5,091 ex_declare mod-dup 臂） | 死续行移除（现形 = 记错后继续走、后续守卫全短路——产物面恒等） | 产物 = ("err" "mod-dup" ...) 逐位 |
| M63 | 39 walk 守卫（36 with-else 含 1 非 nil else 臂 @4,617 + 3 one-liner） | 守卫溶解 + WORK 保位 dedent 4（if/else 行移除、WORK 行逐位；**嵌套守卫迭代叶先溶解**——ex_expand 入口守卫跨 ~1,950 行含 27 内层守卫） | WORK 逐位；非 nil else 臂（ex_rev @4,617）作死臂弃置（其值从未被观测） |
| M64 | 6 between-helper 守卫（B1 ×4 + B2 ×2） | B1：`I if not(...) { / I nil / I } else if COND` → `I if COND`（三行并一行）；B2：`if not(...) { nil } else { WORK }` → WORK dedent（保活 else 臂） | B2 的 WORK 含 ex_fail 位（@4,397 enum-ctor 族）随两遍手术先行清净——4,408 ex_enum_ctor_row 段 |
| M65 | ex_run 三重检查（@5,261/5,265/5,267） | **契约面重设计（M55 形制）**：`unwrap(attempt(|| { let items = ex_decl(...); ex_extern_collide(items); ex_load(items); pair("ok", items) }), \|(e) { e })`——种子八项（ex_extern_seed / ex_struct_seed / ex_struct_field_seed / ex_enum_seed / ex_variant_seed / ex_enum_rows / ex_take / ex_count）thunk 外**纯函数零 raise 位机检实证** | `define(result, ex_run(forms));` 逐字节冻结；("ok" items) / ("err" ...) 产物面位级；种子序逐位 |
| M66 | ex_err 单元（define + 头注两行 + 状态档注释） | 退役（M52 形制）——ex_fail 体位随 M59；**双件同步**（遮蔽族） | 其余九项状态 define 逐位保持 |
| M67 | 头注档（错误词汇表 @72-103 + Error semantics 段 + 过时 doc @3,670） | 勘定更新（raise 语义描述 + MODERN2 blade 5 注记段——R8 英文） | 错误种类表冻结（档位语义） |

**macro.ktf（751→753——遮蔽族共变件）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M68 | ex_fail 体（@97——遮蔽对） | 与 expander 同一手术逐位（identical bodies 纪律——MX-2 装配序取后定义恒等，两份任取其一行为同） | 两份体逐位一致（机检断言） |
| M69 | 14 调用位（1 dead-nil @735 + 13 final-expr） | @735 dead-nil 移除；13 位零改动 | 载荷冻结（含 "macro-mismatch" 档位——MX-2 解码契约面） |
| M70 | 1 守卫（@367 defsyn 发布守卫，no-else 形） | 守卫溶解（M63 no-else 形制——WORK dedent 保位） | WORK 逐位 |
| M71 | ex_err 单元（@95）+ 头注档（blade-4 勘定注记） | 退役 + 遮蔽族共变注记段（blade-4 头注的 delivered 形延伸） | 其余 define 逐位（ex_globals 等） |

**C1 评估关闭（ex_2..ex_7 家族 + 标签键位——边界③ + M49 双重裁定）**：

| # | 位点 | 裁定 | 论据 |
|---|---|---|---|
| M72 | ex_2..ex_7 位置访问器族（250 first/172 rest 位）+ 标签键位（~107 位中 expander 份额） | **零消费关闭**（blade-2 C5 同形——登记后续刀不再评估） | 三论据：(a) M49 预裁定——expander/macro = 链内嵌件经冻结 Rust reader（v0.125.0 pre-r184），行词汇不可表达（r198 探针实证 lockfile 行字面量同拒）；(b) 活 tag 普查——全部 tag 头均为活分派位（eq(first(...)) / match 字面头 / one-liner 守卫头）或产物 var 记录名槽载荷（car/cdr/cons/p = 合成名槽非 tag 头）；零死判别头 = 零表示清理可消位；(c) 内部中间形（binds (name . pgen) alist / cov (enum . hits) / frames / enum chains）已是裸 pair——零 tag 头可弃 |

**harness 共变（M73——装配 + 驱动切换 + 台账，M15/M16/M46/M58 先例延伸）**：

| 位点 | 共变 |
|---|---|
| STD_ERROR 前缀装配位 | target_corpus `assembled_expander_target_source_with_limit` **单点**（`{STD_ERROR}\ndefine(ex_limit, ...);{MACRO}{EXPANDER}`——稳链 new_with_limit / per_source_route 文本路由 / expander_parity 组装位三继承）+ abc_pipeline `ccf_expander_source`（extern 槽声明后 STD_ERROR 前缀——ccf-lexer r198 / ccf-compiler r200 形制，第三 handle 携带链源） |
| 稳链 eval 轴退役 | `expand_dual`（Evaluator 轴整函数退役 + `use kerf_runtime::Evaluator` 导入溶解 + `items` 字段随退役）+ `per_source_route` drive_dual_engines → drive_vm_only（返回单值）——**M16/M46/M58 政策线第四次观测**（TD-031） |
| composed_target_read_chain 双位 | sweep 位（expand_dual 对解构 + J1 引擎不一致行删除）+ twin_front_end_read 位（单轴化；读链 parser 层引擎一致性保留——r198 M46 裁定） |
| 测试面共变 | steady_expander_chain_tests 双测改造（vm-only + oracle 两路形）+ composed J1 行删除 + audit AK06 位（示例双轴位单轴化） |
| TD-032 豁免集扩展 | `matches!(name, "ccf-lexer" \| "ccf-compiler" \| "ccf-expander")`——ccf-expander 首次携 handle（链自编译 infer 差分——r188 pin 结构锚形制第三扩展；刀 6 收口维持） |
| eval_inventory 台账 | steady_expander_chain C 桶退役（C9→8 / pin 33→32——phantom 检查当轮捕获形制） |

**性能诚实账（边界④）**：§9.9 落档——段开关四族 + abc + audit 对照（零回退判据 + abc 真实载荷增量披露）。

### 9.9 刀 5 性能实测对照（边界④执行凭证——T2 fresh 引擎 ledger）

| 族 | r200 基线（§9.7） | r201 实测 | Δ | 裁定 |
|---|---|---|---|---|
| compile_segment（11/11） | 19.26s | 19.54s | +1.5% | 带内 |
| expand_segment（9/9） | 77.97s | 79.43s | +1.9% | 带内 |
| check_segment（10/10） | 117.18s | 119.02s | +1.6% | 带内 |
| read_segment（9/9） | 13.39s | 14.12s | +5.5% | 带内（14s 量级——单 case 噪声主导） |
| abc_pipeline（6/6） | 562s | 624.70s | +11.2% | **真实载荷增量披露**：ccf-expander 源现携 STD_ERROR 前缀（+~140 行/装配位）× A/B/C 三腿自编译——源体积驱动的编译时长增量，非算法回退；远低于 1,800s tier 天花板（35%） |
| audit（512 live） | 467s | 451s | −3.4% | 带内 |
| steady_target_reader（7/7） | —（r198 基线 401s） | 388.22s | −3.2% | 带内 |
| fixpoint_tests + target_fixpoint | 8/8 + 9/9 | 8/8（43s）+ 9/9（1s） | — | 位级 B≡C 恒等维持 |

**回退判定**：零族超 tier 天花板；零回退位；abc +11.2% 为源体积增量（前缀装配的必然载荷——K129 纪律：不投机微调，实测裁决 + 披露）。

### 9.10 刀 6 消费映射表（a-MUV 裁定 @ r203——infer.ktf + target-parser.ktf 收官对 + TD-032 收口；机检勘定 = 双件全量深读 + 标签/守卫/构造三普查 + TD-032 分歧实测探针〔/tmp 双侧 dump 91 tdef 逐位分类〕）

**勘定基础**：双件全量深读（infer 5,532 / target-parser 5,122）+ 机检三普查（infer：233 first/203 rest 位 + ti_2..ti_9 访问器 500 调用位 + pair("tag") 构造 40 标签普查 + 活 tag 分派全查；target-parser：tp_err 全 170 位分类〔9 赋值 + 101 守卫 + 3 助手体 + 50 助手调用 + 1 define〕+ 帧标签普查 + "done" 头消费链）+ TD-032 分歧形态实测（ccf-lexer 双侧 dump：91/91 tdef 同名同序 + 30 件分歧逐位分类 = 行面增量〔raise 逃逸箭头 `(fn (P) tN | (row raise tN))` vs oracle `dyn`〕+ 变量计数偏移〔逐 fn 累积 +1→+33 非均匀〕+ halt/body 合一具体化〔attempt 的 `(fn () t5)` vs `(fn () (pair str t2))`——形状级分歧非纯重编号〕）；r196-r201 P1-P13 事实集复用（**零新探针裁定**：刀 6 全部形制落在已钉死事实内——k 形式 raise〔P1〕、契约面 wrapper〔P9〕、多帧深位回卷〔P10——tp_run 递归 + tp_finish 级联同形〕、G8 嵌套 pair 皮肤〔M39 先例〕、r188 注解 API 面〔ann_pin 先例〕；无新语言面事实 → 无新探针义务）。

**infer.ktf（5,532——勘定件：三面关闭全裁定，零代码变更）**：

| # | 位点 | 裁定 | 不变量 |
|---|---|---|---|
| M74 | **边界②勘定（零 C2 消费——M42 同形）**：全文 0 个 `"err"` 位——ti_report 进 ti_diags 流的累积多诊断架构（ruling 21 同形）；attempt/raise 只替换短路单错误路径（§3 边界②）——累积面维持现形 | 不消费（勘定入表） | ("diags" …) 产物面 + 报告序 + E0009/E0010/E0013 诊断族保持 |
| M75 | **C1 关闭（M72 同形三论据——233/203 导航位 + 11 构造位全量关闭）**：(i) **M49 行词汇不可表达**——本孪生经 ccf-infer 骑冻结 Rust reader（v0.125.0 面，行词汇 r184 之前），行字面量/行模式语法在源内不可表达（刀 3 探针实证同界；r201 预裁定兑现）；(ii) **活 tag 普查零死头**——unify-err（L2483 eq 分派）/mis（L3384/L3410/L3713）/rec/enter（L4955 任务环 match）/budget（L5290）全活分派；tdiag/t1..t9/schema/types/diags = Rust 解码器契约面（infer_parity twin_tdef/twin_schema/twin_tdiag + oracle 模板渲染）；11 处 pair("row"…) 构造 = 行类型表示（产物面——("types"…) 内嵌 + oracle parity 契约，"row" 头 17 处活分派）→ 零 M39/M43 形死头可丢；(iii) **内部形已裸 pair + 访问器族 = 跨件契约词汇**——ti_2..ti_9（500 调用位）双职（items 流导航〔CP-1——typecheck M-勘定先例明文「compiler/infer 同词汇跨件契约面」〕+ 内部记录位槽导航）；统一器工作对/任务栈条目/结果记录 = 裸 cons 链既有形（G8 皮肤内）；行字段表导航（ti_row_typed_has/lookup/drop 的 first(first(fields)) 族）= (label opT) 裸对链机内形 | 不消费（三论据关闭——meta-circular 消费落位更正：行机器的行词汇消费面 = 语料〔corpus-row/ 骑孪生链〕+ C4 注解钉金档〔M76/M81〕+ target-parser 行三机生产位〔r184 既有〕；孪生源自身受 M49 边界——开窗时点的「meta-circular 亮点」预期经 r198 M49 发现后按边界如实更正） | 8 原语不变性（第 158 轮——设计面）+ ("types"/("diags") 产物面 + oracle parity 位级 + 全部导航形冻结 |
| M76 | **C4 勘定（infer 侧零源面）**：效应行注解 = API face（arrow-with-row 无 target-skin 表面位——r188 交付面 + INST-3 先例）——孪生源不可承载注解语法；raise 助手注解钉 = 金档测试面交付（M81）；infer 孪生自身 = 行机器（其行词汇生产位 = target-parser 行三机 r184 + infer 行推断 r182/r188 既有生产链） | 勘定入表（消费落位更正：C4 面在金档不在源） | r188 四元槽 + res 第五槽行轨 + hm_twin_face pin 族冻结 |

**target-parser.ktf（5,122——主手术件：C2 收官手术 + C1 死头单点）**：

| # | 位点 | 消费形 | 不变量 |
|---|---|---|---|
| M77 | **C2 解析拒绝族主手术（M35/M59 同形）**：3 助手体（tp_err_unexpected/tp_err_unsupported/tp_err_unclosed——体内直接 `perform raise(pair("err", …))`，载荷 = 契约面 err 记录逐位）+ tp_enter 深度守卫内联位 + 2 多行 unsupported 位（L2977/L3746）+ 3 stray 内联位（L3557-3559）= **9 构造位全量 raise 化**；**50 个助手调用位零改动**（调用形保持——构造即短路）；`define(tp_err, nil)` 单元退役（M66 同形）；**101 守卫全量溶解**（is_nil(tp_err) 位——迭代叶先两遍制〔r201 三坑教训内置〕；else 臂拆除〔raise 已在错误位短路回卷，守卫恒真〕）；入口形：`define(tp_run_result, unwrap(attempt(|| { tp_run(); tp_done }), \|(e) { e }))` + tp_verdict = tp_run_result（M55/M65 同形——**`define(result, tp_verdict);` 逐字节冻结**）；tp_run 头守卫溶解（栈空检查保持） | 载荷 = ("err" kind payload…) 契约面形逐位（unexpected-token/unsupported/unclosed/nesting/stray 五族 kind + payload 槽序原样）；tp_verdict/result 双 define 形状冻结（decode_tp_verdict 契约面）；tp_done ("ok" items) 产物面 |
| M78 | **C1 "done" 死头丢弃（M39 同形——唯一死头）**：tp_give 协议 done 臂 7 构造位 `pair("done", pair(R', nil))` → **裸单槽值链** `pair(R', nil)`（"done" 判别头经查从未按名分派——tp_finish 以 else 臂承接 done 案〔L2030 eq(first(r),"frame") 分派 + else〕= 死数据）；tp_finish done 臂解包 `tp_2(r)` → `first(r)` 共变；**分派不变量注记**：R' 恒为带 tag 对（item/expr 记录族——全产物面形），永不等于裸串 "frame"（形状分派全称性——头注钉死） | tp_give 协议 ("frame" g')/"done" 双形语义 + tp_finish 级联序 + tp_leave_g(mode) 弹帧序保持 |
| — | **不消费位勘定（target-parser）**：tp_2..tp_9 访问器族 = 帧内位槽导航 + tp_token_prefix 记录流导航（跨件契约词汇——边界③）；帧标签族（type-drop 31/frame 26/fresh 20/expr 17/…）全活分派（tp_step 任务环 match + tp_give_* phase match——零死头〔"done" 外〕）；("err" …) 载荷 = 契约面；行三机函数族（tp_give_row_spec/lit/pat + tp_step_row_*）= 生产位（r184 既有——本窗零变更）；token 记录族 = 产物面（边界①） | — | — |

**harness 共变（M79——装配 + 驱动切换 + 差分升级，M46/M58/M73 同形延伸）**：

| 位点 | 共变 |
|---|---|
| abc_pipeline.rs ccf_parser_source | extern 声明后拼 STD_ERROR 前缀（第四个携 handle 链源——ccf-lexer/compiler/expander 先例） |
| steady_target_reader_chain.rs | parser 装配位（L195 三件套）拼 STD_ERROR 前缀 + **parser 层 eval 轴退役**（L479-500 eval 臂拆除——"vm" 单轴；M73 单轴化同形） |
| target_parser_parity.rs twin_dump | 装配位（L521-531）拼 STD_ERROR 前缀 + drive_dual_engines → **drive_vm_only**（双轴 → 单轴；M46 同形）+ 比较面三路 → 两路 |
| eval_inventory_guard_tests.rs | C 桶 steady_target_reader_chain 退役（parser 层 VM-only——Evaluator 引用溶解）C8→C7 + 总 pin 32→31 + 台账注释共变 |
| **TD-032 收口（M80——差分语义升级）** | abc_pipeline 差分门升级：matches! 豁免集（ccf-lexer/ccf-compiler/ccf-expander）**撤销**；携行源期望形 = **金档钉死**（每源 commit 级 fixture 文件——infer 差分 dump 逐字节；再生成 = 蓄意行为〔regen 测试面〕，git diff = 分歧域变更审计面）+ 结构锚保留（tdef 计数/函数名序/诊断尾部 vs oracle——跨实现纪律带）；可比较源（ccf-infer/ccf-check）维持 live oracle 全等（统一期望形语义：expected = 金档 or live oracle）；**裁定依据**：实测分歧含 halt/body 合一具体化（形状级）+ 非均匀计数偏移——同构/重编号/期望计算三路均不可行（需重实现 r188 分配序 = 第三推断实现，脆弱面）；金档钉 = 唯一字节级全严格形；AZ08 审计行共变（同分类器单源化） |
| fixpoint / determinism / composed 面 | ccf_parser_source 前缀经 ccf_sources() 单源流入（fixpoint 六源）；determinism reader_assembled = lexer 面（parser 不在——零共变）；composed J0.5 骑 steady 链（中央装配流入）；target_fixpoint_tests 双子星 parse-only 面（L113——零执行零共变） |
| C4 金档钉（M81） | effect_infer_golden_tests.rs 新增 raise 族两案：(i) **ann_pin carrier for raise**（注解行 (row raise int) 骑箭头四元槽——参数注解 pin 与实参推断行在参数位合一〔read 先例形制〕）；(ii) **escaping raise**（`fn f() { perform raise(...) }` 逃逸行载体——schema 渲染 `(fn () tN \| (row raise tN))`——halt 面 ⊥ 恢复位的逃逸形钉死）；INST-3 刀 1 金档的 raise 补位（§5.3「刀 1 金档须含行类型注解面正例」的 Error 实例收口） |

**12 件自应用闭环**：infer 零变更（hm_twin_face 族 + infer_twin_sweep + typecheck_parity = 既有验证面零共变）；target-parser 新源入 target_parser_twin_tests selfhost/disk 双测试对 + steady_target_reader_tests + abc/steady/determinism 组合链回归面；TD-032 金档 fixture = 新审计工件（crates/kerf-driver/src/bootstrap/fixtures/——四源全 dump）。

**行数预算**：infer 5,532 → 5,532（零变更）；target-parser 5,122 → ~5,050±30（101 守卫溶解净减 + 9 raise 位微增 + done 头 7 位微减 + 入口三行共变）。

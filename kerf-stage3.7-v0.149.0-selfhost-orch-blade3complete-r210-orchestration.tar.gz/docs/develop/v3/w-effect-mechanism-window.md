# W-EFFECT-MECHANISM（效应机制窗——效应族三段链·链中段）

> **Status**: **CLOSED（v1.3——r189 刀 3 DELIVERED + 出口六条全 ✓ @ r189 close）**：刀 3 = 语料/audit/收口面〔corpus-effect/ 28 案〔10 正 + 18 负 = 3 read + 7 type + 8 runtime——四裁决臂 sweep 接线（rw 型形制）+ 着者时三捕获诚实重分类：空子句表合法语法且 check 面读为未覆盖〔E0006〕/子句体操作数面 check 放行 VM 拦截〕+ audit Section BH 10 案〔470→480 live EXIT 0〕+ r185-r188 守卫盲区同路径修复〔BG 组成表行补登〕+ 段 3 前置接口冻结〔§9 六实例消费位形状〕；零生产面文件〕；v1.2——r188 刀 2 DELIVERED**：效应行推断消费全量落地自举生产位〔infer.ktf 4,922→5,532 +610——箭头携行四元表示 `("fn" P R row)` + 覆盖子句 perform 三态定型〔退化形=子句返回类型+参数合一钉位 / k 形式=k 箭头首参续体恢复 / 无覆盖=新鲜续体元变量+行扩展 e:opT（m1 字面改编——op 类型即续体类型，Koka 同调）〕+ handle 覆行〔类型行扣除+处理器行合并〕+ halt/body 返回类型合一〔r187 类型缺口闭合——E0013 面〕+ 泛化行变量入 schema vars + oracle 三件零文件机检（r174 冻结第三刀）+ 金档 25 案 1:3 + 双引擎一致 lane 承载三效应定型语料行 + T2 68/68〕；v1.1——r187 刀 1 DELIVERED**：值层/VM one-shot 语义深化全量落地〔续体值类 2 族 + ext2 OneShotMark + k 形式元数约定 + `return` 子句 pop-handler b 位路由〔+1 哨兵〕+ degenerate 形位级零漂移〕——金档 6:18（T1）+ T0 五案（复用族原生 home——类型层不可表达载运，occurs check 挡值通道 + handle 退化 typing 挡 halt 载运，刀 2 类型面闭合缺口〕+ oracle 三件零文件机检 + fixpoint 位级 + T2 67/67；v1.0——r186 开窗行权轮）**：双前置达成 @ r185（段 1 W-ROW-POLY CLOSED + P2 效应行接口形状冻结——row_effect_shape 6 案）+ r186 开窗行权（触发器链式达成落档 + 前置门四件全过〔§3.3 提案 = 本档本体 / r186-search 六检索五范式家族 / 8 原语不变性第 142 轮设计面 / 孪生可表达性 ✓〕+ 表示与算法裁定落档〔§5〕+ 三刀序〔§6〕+ 出口判据〔§7〕）。同轮完成 r185 P1 披露级递延清偿（T2 长族 fresh 全量 66/66 绿——steady_route 7/7 + fixpoint 17 + abc_pipeline 6/6 + doc + audit 470，§3.2.1 分块纪律 5 chunks）。

## 1. 一行定位

效应机制窗 = 效应族三段链的链中段：把内核已在位的 Perform/Handle 原语从「捕获替换」语义深化为 **one-shot 可恢复处理程序语义**（值层/VM 面），并把 r185 冻结的 P2 效应行形状升级为**推断消费面**（类型层/infer.ktf 孪生生产位）——段 3（六官方效应实例窗）的机制地基。

## 2. 成熟度口径（现状 + 前沿对照）

**现状（@ r186 开窗时点）**：

| 面 | 现状 | 单源 |
|---|---|---|
| 原语层 | Perform/Handle 已属冻结原语集（CoreExpr 九变体 = §6.12.6 语义等价映射的「8 原语」口径——Assign↔Perform(State) 双拼写）；HandlerClause{span, effect, handler} 单臂三槽 | kerf-core expr.rs；stage0 §3.2/§9.15.6⑥ |
| VM 执行面 | PushHandler/PopHandler/Perform 三 opcode + 处理器栈；**语义 = 捕获替换**（perform e(a) ≡ handler_e(a) 动态绑定，处理器返回值即 perform 值，体恒续）——无续体传递/无 halt/无 return 分支 | kerf-vm vm.rs exec_perform |
| 帧格式 | ext2 槽 = Stage 0 预留空槽，语义方向已锚定 = Error 效应 handler 表（Handle continuation 管理载体——非栈展开形态） | stage0 §9.15.7③（04-bytecode-vm §1） |
| 类型层（oracle） | 词法处理器栈走查（R6：顶层未处理 perform = E0006 + HandlerArityMismatch + NonCallableHandler）——**无效应行推断**；r174 冻结后 oracle 停留在 v0.125.0 语言面 | kerf-typecheck check.rs（冻结面） |
| 类型层（孪生） | typecheck.ktf 镜像 R6 词法面；infer.ktf 行代数内核全量在位（行合一五规则 + 四 walk 机族 + 泛化/实例化行变量 @ r182-r185）——**效应行 = 形状冻结零消费**（P2：6 案钉死 `("row" ((eff opT)...) tail)`） | w-row-poly-window §5.4；row_effect_shape_tests |
| 设计源 | 统一而分治模型（return/异常/async/状态/IO/自定义全 = Perform/Handle 参数化，零特殊个体）+ one-shot 纪律 + try/catch = 标准库宏非语言核心 | stage0 §9.15（v7.3 全量吸收） |

**前沿对照（r186-search 六锚——§4 前置门②）**：Koka（行多态效应生产级——效应行合一 = 记录合一的字面改编）/ OCaml 5（one-shot 续体生产级——无类型效应运行时查表对照范式）/ Eff·Effekt（直接风格研究原型）/ Unison（abilities + Request 模式匹配 + pure case）/ Haskell freer 族（翻译式——**否决记录**）/ HM 效应推断（行合一复用 vs Boolean 合一替代——后者否决）。

## 3. 时机触发器（四件——①链式达成 @ r185/r186 行权）

1. **①链式达成 ✓**：completion-plan §3 效应族三段链段 2 开窗前置 = 段 1 W-ROW-POLY CLOSED + P2 效应行接口在位——**双前置达成 @ r185 close**（出口六条全 ✓ + row_effect_shape 形状冻结）；r186 行权开窗（用户常设指令①「完整完全自举优先」效应族链推进的既定下一步——worklog r185 尾行单指「r186 首位 T2 长族补跑 → 效应机制窗开窗」）。
2. **②用户指令⑥链式排期 ✓**：目标语言完整语法语义落地总规划（r181-c）效应族三段链段 2 位（completion-plan §3 单源）。
3. **③矩阵 §11 优先级 ✓**：效应机制窗 = 链中段第 2 位实施窗（矩阵 v1.9 重排后维持；段 1 CLOSED 后链中段升首位待开）。
4. **④§21.12-28 自举段就绪 ✓**：效应机制 = 语言机制面（目标语言语义核心），实施位 = infer.ktf 孪生生产位 + VM Rust 永久基座（宪制排除项——VM 语义深化 = 基座正常工作，非自举面）。

## 4. 开窗前置门（四件——全过 @ r186）

1. **§3.3 演进提案 = 本窗口档本体**（r164/r174/r181 开窗轮同型先例——委员会投票 close 轮）。
2. **知识搜索先行（r186-search 六检索五范式家族——原则 35 判据先于先例，存档 = 本节内嵌 + /tmp 检索工件）**：
   - **m1 Koka 行多态效应**（Leijen 2013/2014《Koka: Programming with Row-polymorphic Effect Types》arXiv:1406.2061 被引 261——「合一算法是 Leijen [14] scoped labels 记录合一的**几乎字面改编**」——效应行推断复用 r182 已落地的行合一五规则机的直接理论依据；duplicate labels 支持多态效应）；
   - **m2 OCaml 5 效应处理器**（ocaml.org 手册 §24 + Sivaramakrishnan《Retrofitting Effect Handlers onto OCaml》+ kcsrk.info「one-shot 续体对几乎所有并发需求充分且远廉于 multi-shot」+ Kiselyov《Eff Directly in OCaml》被引 62——**one-shot 纪律生产级佐证**〔§9.15.6③ E.15 锚一致〕；OCaml 效应无类型推断 = 运行时查表对照范式——kerf 效应行推断为超集路线）；
   - **m3 Eff/Effekt 直接风格**（Dagstuhl《Algebraic Effect Handlers go Mainstream》+ inner-product.com 2024 直接风格解释——handler 保持直接风格易推理 = 内核原生 Perform/Handle 反翻译式佐证）；
   - **m4 Unison abilities**（unison-lang.org 官方「ability 构造子 ↔ handler 模式匹配 + Request 类型 + pure case」——handler = 模式匹配分派的用户面佐证；构造子-操作映射 = HandlerClause 单臂三槽同族）；
   - **m5 Haskell freer 族（**否决记录**）**（polysemy Free-monad 基 = 低效〔discourse.haskell.org 2023〕/ fused-effects 胜 polysemy 但新效应定义成本高 / heftia 2025 higher-order——**翻译式范式整体否决**：值层翻译为 monad 链 vs kerf 内核原生处理器栈 + opcode 直执行；判据 = 侵入面 + 性能双输，与 r174 冻结裁定的「停翻译保内核」精神一致）；
   - **m6 HM 效应推断**（Xie 等《No value restriction is needed for algebraic effects》——call-by-value HM 多态效应安全；Gagallium/INRIA「First try: row polymorphism and the usual unification algorithm」；Madsen 2020 Boolean 合一被引 29——**Boolean 合一替代路线否决**：新机族 vs 行合一复用〔m1 同一判据〕；Reddit Beyond-HM 讨论「records paper 的行多态洞见直接应用于 effect types」）。
3. **8 原语不变性第 142 轮设计面核对 ✓**：Perform/Handle 已在冻结原语集（§3.2——本窗是其**语义侧深化**非新原语）；resume = `Apply(k, [v])`（续体 = 一等可调用值——类 2 值族〔closure/handler 同族〕，零新 AST 节点）；halt = 处理器子句不调 k 直接返回（零新节点——VM 帧栈回卷语义）；return 分支 = 名为 `return` 的效应标签（零新语法——§9.15.2「return 也是流的分支非特殊通道」的语言级落位）；续体管理载体 = ext2 预留槽（§9.15.7③ 物理预留位填充——非新 VM 架构面）；**零新原语·零新通道·零新语法·零 VM 新架构面**四不变性维持。
4. **孪生可表达性评估 ✓**：infer.ktf 行代数机族（ti_unify_row 五规则 + 四 walk 机族 row 臂 + 泛化/实例化行变量 @ r182）= 效应行推断消费的现成地基——m1「字面改编」判据在孪生面同构成立；typecheck.ktf R6 词法走查 = 行消费的词法层先例；18 内建可表达面内（处理器续体传递 = 值级 pair 复合，无新内建需求）。

## 5. 表示与算法裁定（ARCH-A @ r186——判据先于先例）

### 5.1 语义深化裁定（值层/VM 面——刀 1 实施位）

**现行语义（捕获替换）→ 目标语义（one-shot 可恢复）**：

| 面 | 现行 | 目标 | 判据 |
|---|---|---|---|
| 子句调用 | `handler(args)` 返回值即 perform 值 | 子句追加尾参 `k`（one-shot 续体）：`handler(args..., k)` | OCaml 5/Koka/Unison 三范式一致（m2/m4） |
| resume | 不存在 | `k(v)` = Apply 调用 → perform 求值为 v、体续 | m2 one-shot 纪律（§9.15.6③——E.15 锚） |
| halt | 不存在（体恒续） | 子句不调 k 直接返回 r → **handle 表达式**求值为 r（体丢弃） | §9.15.4「栈展开 → Handle 续体管理」替代表 |
| return 分支 | 不存在 | 效应标签 `return`（body 正常完成 = perform return(v) 的处理器分支） | §9.15.2「return 也是流的分支」+ m4 Unison pure case 同构 |
| one-shot 执法 | —— | k 首调消费；二次调用 = 运行时错误（fail-closed） | §9.15.6③（Soundly Handling Linearity / Affect 2025 / Kobayashi 2025） |
| 兼容性 | pos-021 族 | 捕获替换程序 = 「子句恒 resume 等价」的退化形——语义深化保兼容（金档钉死） | §2.3-1 正确>妥协 |

**载体裁定**：续体 = 类 2 值族新成员（一等可调用——closure 同族；`Invoke` 通道复用）；续体帧管理 = **ext2 预留槽填充**（§9.15.7③ 物理预留的语义方向兑现——非新架构面）；处理器栈 PushHandler/PopHandler 形制维持。

### 5.2 效应行推断消费裁定（类型层/infer.ktf 孪生面——刀 2 实施位）

- **函数箭头携行**：箭头类型扩为 `(T -> U | row)` 三元表示（.ktf Type 层 pair 复合——`(arrow T U row)`；效应行 = P2 冻结形状 `("row" ((eff opT)...) tail)` 直接消费）；
- **perform 扩行**：`perform e(args)` 在处理器栈内 → perform 类型 = 子句返回类型（词法面既有）；无处理器 → 当前行扩展 `e:opT`（行合一——m1 字面改编）；
- **handle 覆行**：handle e {...} 从行中移除 e（已覆盖）；return 分支消费 `return` 标签；
- **行逃逸**：顶层未覆盖 = E0006 既有诊断面（词法 R6 与行推断双面一致——刀 2 金档钉死双面一致性）；
- **泛化面**：效应行尾变量入 schema vars（P2 冻结口径——「fresh 行变量入 schema vars〔泛化面效应机制窗扩展〕」兑现）；
- **oracle 冻结维持**（r174 冻结裁定第三刀）：kerf-typecheck/kerf-reader/kerf-expander 零文件机检；验证 = 金档期望 + fixpoint 位级 + audit 三面。

### 5.3 处理程度分级（原则 26——P1/P2/P3）

- **P1（本窗实施面）**：one-shot 可恢复语义（值层/VM 全量）+ 效应行推断消费（箭头携行/扩行/覆行/逃逸/泛化）；
- **P2（接口预留面）**：效应消除优化（Koka 四阶段——§6.12；W-3.x 优化窗消费位）；多射续体（线性/仿射类型保护——§9.15.6③ 登记替代，Stage 2+ 裁定维持）；
- **不做（P3/研究前沿）**：多态效应处理程序（矩阵行 ✓ 设计忽略维持）；效应子类型偏序；Boolean 合一替代路线（m6 否决记录）。

## 6. 刀级 MUV 排期（最小先行 + 逐刀金档/fixpoint 门）

| 刀 | 实施面 | 范围与验收门 | 状态 |
|---|---|---|---|
| 刀 1 | 值层/VM 语义深化 | one-shot 续体值（类 2 族）+ 子句 k 尾参 + resume/halt + return 效应标签 + ext2 槽填充 + 兼容性金档（pos 族零扰动）；验收 = VM 面 T0/T1 全绿 + 捕获替换退化形金档 + one-shot 违例负向 ≥3 | **DELIVERED @ r187**（v0.136.0：续体 = Value::Continuation 堆胞类 2 族 + ext2 OneShotMark + k 形式元数约定〔params==args+1〕+ `return` 子句经 pop-handler b 位〔+1 哨兵防 0 号撞车〕路由；退化形位级零漂移〔金档 6:18 + T0 五案 + T2 67/67〕） |
| 刀 2 | infer.ktf 效应行推断消费 | 箭头携行三元表示 + perform 扩行 + handle 覆行 + 行逃逸 E0006 双面一致 + 泛化行变量；验收 = 金档 ≥24 案 1:3 + oracle 三件零文件机检 + fixpoint 位级 | **DELIVERED @ r188**（v0.137.0：箭头四元槽 + res 记录第五槽行轨 + ti_handlers 上下文栈/hres 任务 + 覆盖子句三态定型〔退化参数合一/k 续体恢复/未处理 Koka 同调扩展〕+ 类型行扣除合并 + halt/body 合一〔E0013 面〕+ schema vars 泛化；金档 25 案 1:3〔effect_infer〕+ oracle 三件零文件 + fixpoint 位级 + T2 68/68；双引擎 lane 承载 pos-021/neg-034/neg-035 + handle-rows 四测试族豁免〔r174 第三刀先例〕） |
| 刀 3 | 语料 + audit + 收口 | corpus-effect/ 语料族 + audit Section BH 扩展（470→N）+ rw 型 sweep 接线 + 段 3 前置接口冻结（六实例消费位形状）；验收 = audit live EXIT 0 + 段 sweep 全绿 | **DELIVERED @ r189**（v0.138.0：corpus-effect 28 案〔10 正 + 18 负 1:3-lean〕+ efx_corpus_sweep 四裁决臂〔value/read-error/type-error/runtime-error——运行时臂 = 效应族独有验证面〕+ audit BH 10 案 480/480 live EXIT 0 + tiers.tsv T1 登记〔人口 57→58〕+ §9 六实例接口冻结；零生产面文件——8 原语第 146 轮构造性维持） |
| close | 出口判据 | §7 六条逐条核对 → 窗口 CLOSED + 段 3（效应族实例窗）开窗前置就绪宣告 | **CLOSED @ r189**（出口六条全 ✓——见 §7 尾注；段 3 前置就绪宣告：机制地基全量在位，六实例 = 冻结机制上的词汇包） |

## 7. 出口判据（窗口 CLOSED 六条）

> **r189 close 逐条核对（全 ✓ → CLOSED）**：①one-shot 可恢复语义内核+VM 全量交付 ✓（刀 1 @ r187——续体值/ext2/k 形式/resume/halt/return + 退化形零漂移金档）；②效应行推断消费 infer.ktf 生产位全量 ✓（刀 2 @ r188——携行/扩行/覆行/逃逸/泛化 + oracle 零文件）；③金档全绿 ✓（刀 1 6:18 + 刀 2 25 案 1:3 + 刀 3 语料族 28 案与四裁决臂 sweep 全绿；7 类错误 ≥6 类负向覆盖维持）；④parity sweep 回归全绿 + fixpoint 位级 + oracle 三件零文件 ✓（刀 3 零生产面变更——构造性维持 + T2 fresh GATE 复证）；⑤8 原语不变性第 146 轮 ✓（刀 3 零生产面文件——零新 AST 节点/零新语法/零新通道/零 VM 新架构面构造性成立）；⑥文档共变链全量 ✓（矩阵 v1.16 + completion-plan v1.47 段 2 CLOSED + tech-debt r189 + 台账 + RELEASE_NOTES v0.138.0 + 金链）。

1. one-shot 可恢复语义在内核+VM 全量交付（resume/halt/return 分支/ext2 载体——捕获替换退化形兼容金档钉死）；
2. 效应行推断消费在 infer.ktf 孪生生产位全量交付（箭头携行/扩行/覆行/逃逸/泛化——P2 形状→消费面闭环）；
3. 金档全绿（刀 1 兼容金档 + 刀 2 金档 ≥24 案 1:3 + 刀 3 语料族与 sweep）——7 类错误 ≥6 类负向覆盖维持；
4. 既有 parity sweep 回归全绿 + fixpoint 位级一致 + oracle 三件零文件机检（r174 冻结第三刀）；
5. 8 原语不变性维持机检（零新 AST 节点/零新语法/ext2 预留位填充——第 143 轮起逐刀核对）；
6. 文档共变链全量（矩阵 §5 行翻 ✓ + completion-plan 段 2 CLOSED + tech-debt + 台账 + 转化记录 + RELEASE_NOTES + 金链）。

## 8. 零载荷边界与效应族链定位

- **效应消除优化**（Koka 四阶段）：登记（§5.3 P2）——W-3.x 优化窗消费位，本窗零实现（原则 38 登记态纪律：零信号不开窗）。
- **多射续体**：登记替代（线性/仿射类型保护前提——Stage 2+ 裁定维持）。
- **六官方效应实例**（Read/Write/State/Async/Error/Log——stage0 §9.14.2）：**段 3（效应族实例窗）实施面**——开窗前置 = 本窗 CLOSED；本窗只交付机制地基，零实例实现。
- **try/catch/`?` 语法糖**：标准库宏面（§9.15.3——依赖表面语法切换窗 #15 后置；本窗零语法糖）。
- **效应族链三段定位**（completion-plan §3 单源）：段 1 W-ROW-POLY ✓CLOSED @ r185（行类型基础）→ **段 2 本窗（机制：语义深化 + 行推断消费）** → 段 3 效应族实例窗（六实例——本窗 CLOSED 即前置就绪）。

## 9. 段 3 前置接口冻结（六实例消费位形状——刀 3 交付 @ r189）

> **性质**：接口形状冻结（判据先于先例——原则 35）。本节只冻结六实例在刀 1/刀 2 机制上的**消费位形状**（perform 词汇 / 子句形 / 行类型 / 机制消费位）；零实例实现（段 3 实施面）。段 3 开窗时若需偏离本冻结，须按 §3.3 演进提案记录理由。

### 9.1 六实例消费位形状表

| 实例 | perform 词汇（消费位） | 子句形 | 行类型（op → resume 型——Koka 同调：op 类型即续体类型） | 机制消费位（刀 1 面） |
|---|---|---|---|---|
| **Read** | `perform read(src)` | k 形（k 恢复携读取载荷） | `(read (fn (src) str))` | resume 单射 |
| **Write** | `perform write(dst, payload)` | k 形（k 恢复携完成确认） | `(write (fn (dst str) nil))` | resume + 副作用驻处理器体 |
| **State\<T\>** | `perform get()` / `perform put(v)` | k 形（处理器持状态胞） | `(get (fn () T))` + `(put (fn (T) nil))` | resume = 状态线程（one-shot k 捕获存储点——恢复即回写，OCaml 5 one-shot 效率先例 m2） |
| **Async** | `perform await(task)` | k 形（k 恢复携完成值） | `(await (fn (task) V))` | resume 单射 + 调度策略驻处理器 |
| **Error\<E\>** | `perform raise(e)` | **halt 形**（子句不调 k 直接返回回退值——续体丢弃） | `(raise (fn (E) ⊥))`（恢复面为空——halt 消费位） | halt + `return` 子句 = 成功路径分支 |
| **Log** | `perform log(msg)` | **退化形天然**（处理器返回 nil 体恒续——pos-021 兼容形即日志语义） | `(log (fn (str) nil))` | degenerate 兼容形 |

### 9.2 冻结裁定五条

1. **零新原语维持**（8 原语不变性第 146 轮预期）：六实例 = 冻结机制之上的词汇包（处理器 + perform 组合），全部落在 Perform/Handle 冻结原语集内——段 3 零机制变更义务。
2. **三种子句形全覆盖消费**：resume（Read/Write/State/Async）+ halt（Error）+ degenerate（Log）——六实例集体消费刀 1 全部语义面（one-shot 可恢复语义的实例级验收即段 3 出口判据之一）。
3. **效应行类型消费刀 2 箭头携行**：每实例 op 类型 = `(fn (args) resumeT)` 形状直接骑 `(arrow P R row)` 四元槽；Error 的 raise 恢复面为空是唯一异形（halt 消费位——行类型回复面 ⊥）。
4. **载体分层**：State/Error/Log 纯语言内可表达（零宿主依赖——段 3 实施序建议先行）；Read/Write 处理器桥宿主 IO（BufferIo 通道族——实施序次之）；Async 调度器 = 策略面（实施序最后，可先交同步直通退化形）。
5. **语法糖后置维持**：try/catch/`?` = 标准库宏面（§9.15.3），依赖表面语法切换窗 #15——段 3 零语法糖义务（Error 实例的表面糖不随实例进入）。

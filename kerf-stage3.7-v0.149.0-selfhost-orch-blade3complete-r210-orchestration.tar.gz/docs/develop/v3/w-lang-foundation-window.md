# W-LANG-FOUNDATION 语言基础完备实施窗——开窗行权轮：设计对齐 + TD-026 重审 + 消费面重勘 + 刀序落档（w-lang-foundation-window.md）

> **Status**: **CLOSED（v1.4——r170 刀 4 交付 + 窗口出口五条全 ✓：四刀全交付〔刀 1 注解 @ r165 / 刀 2 struct @ r166 / 刀 3 enum @ r168 / 刀 4 模式族收口 + GZ-5 评估档案 @ r170〕——G8 语言基础完备闭合入账**。r170 刀 4 交付：裁定落档〔a——窗口档 §11：struct 模式三面裁定（双查表消歧 enum→struct→六模式族 + 零位移字段公式 + 零字段 nil? 面 + GZ-4 计数域零变更 + 穷尽性三判式）+ GZ-5 行多态评估窗档案（§11.2——四触发器 + 四前置门 + W-ROW-POLY 登记名，评估非实施）〕+ 展开器双臂〔b @ f13af2d——oracle compile_pattern 三分区 struct 臂 + struct_arm + struct_face 探针 + 预扫描字段表 + 读链 3+ 元组放行迁移（裁定修正披露——neg-065/066/071/072 期望共变 parse-error → expand-error + audit AC5/AY03/AY10 三腿 + parity 表）+ expander.ktf 孪生全套（ex_struct_field_find/seed + ex_struct_face + ex_ps_assemble + pcvar shift 参数化 + pc 三分区 + 穷尽性三判 + ex_8 访问器）〕+ 语料族 16 案〔c——正 4 负 12 = 1:3 + 人口钉扎十一位共变 154→170（读层 20→17 / 展开层 29→33 / hm 四向量 + clean 81/98 + fed 109 / audit BF01/BF04/V3 / tiers 157→173）〕+ close〔金链 v0.125.0 + T0 29 + T1 52 + T2 63/63 八窗零中断 + 文档五件 + §19 双包 + web〕；前版 v1.3——r168 刀 3 交付：读链双臂〔b1 @ abf88a2——parse_enum_decl oracle + tp 镜像机族 + ModuleItem::Enum 零码臂十一处〕+ 展开器双臂〔b2 @ 7ef4e32——expand_enum 脱糖〔ctor defines E-Variant 复合名 + a0..aN 注入表 param + cons(tag,右折) 体〕+ 警察七族 + 注入通道第三例 ex-enum-ctors + expander.ktf 864 行镜像〕+ 推断层双臂 + GZ-4 穷尽性〔b3 @ c0c35ea——Type::Enum(Symbol) 名义封闭 + EnumTable + expand_match enum 感知〔variant_face 查表 + enum_exhaustive 覆盖集 + variant_arm 编译〕+ compile_pattern variant 模式位 + DEFAULT_BUDGET 8→16MiB K159〕+ 语料族 16 案〔b4 @ 2c614c0——正 4 负 12 = 1:3 + 人口钉扎十位共变 138→154〕+ §10 裁定落档〔GZ-4 展开期单段执法 + enum 表示 cons(decl_index,payload-chain) + 模式首元素查表消歧 + Type 承载名义封闭 @ r168-a〕——「enum = 派生表面非原语面」兑现：构造 = ctor define 单源、消费 = match variant 模式、类型层 Enum(Symbol) 名义原子；v1.2 r166 刀 2 交付：读链双臂〔b1 @ 740f93b——parse_struct_decl + tp 镜像机族〕+ 展开器双臂〔b2 @ a312970——ModuleItem::Struct 零码 item + expand_struct 警察四族 + 脱糖发射序 pending_items 通道 + 十一消费面零码臂 + expander.ktf 镜像〕+ 推断层双臂〔b3 @ 03bf751——StructTable + Type::Struct 名义承载 + unify 透明展开五臂 + Display 名字单显示 + infer.ktf 孪生镜像 + r127 标量崩溃面同族清偿〕+ 语料族 13 案〔b4 @ f1dfaf4——正 3 负 10 = 1:3.3 + 人口钉扎九位共变 125→138〕+ §9 裁定落档〔GZ-2 pair 链 / GZ-3 透明展开 / TD-026 闭账 @ r166——W-HEAP-EXTERN 登记窗承载〕——「struct = 派生表面非原语面」兑现：构造 = cons 右折链、字段访问 = car/cdr^i、类型层 Struct(Symbol) 名义承载；v1.1 刀 1 交付 @ r165：读链 spec 构造〔b1+b2〕+ 展开器 dann 双臂〔b3〕+ 推断层消费双臂〔b4——E0013/解析表/锚定/第三例外〕+ 语料族 16 案〔b5——正负比 1:3〕——「annotations are surface sugar the HM layer owns」后半句兑现；v1.0 开窗行权轮落档：§13.1 设计对齐 + TD-026 重审 + 注解消费面重勘 + 刀序落档；r163 验收 GO 后首议程——从属位解除 @ r163）
> **流程权威**: docs/sop.md（§13.1 阶段开始设计对齐 / §21.12-28③ 完成标准法定 + ⑤ 自举后语言自我推进 / §21.12-33 子代理派遣 / §12 最优>最小 / §2.2 原则 31 表面-内部语法严格分离 + 原则 38/44-58 登记态纪律 / §18 依赖审查 / §19 打包）
> **依据**: bootstrap-completion-plan v1.25 §4.5（四刀 MUV 单源——本档 §5 只引用不复制）+ §9 时点裁定（enum/struct 时机未到非遗忘——实现窗法定验收后）+ stage0.md §9.14.2（类型系统成员三组——R4 实况对账）/ §7.4（内部语法 ADT——7.4.3 内部 AST 完整定义）/ §6.10（类型维前沿成熟度 ~30%——行多态评估非实施）/ §9.14.5（七决策点——类型系统渐进+行多态 vs 纯静态收敛既有裁定）+ tool-results/r76-search/（HM unify 家族七件：m1-rustc-unify_key.rs / m3-ghc-unify.hs / m4-rustc-relate.rs / m11-ocaml-btype.ml / m12-ocaml-ctype.ml + q4-value-restriction.json / q6-ts-bidi.json）+ K140-K142（自举后语言自我发展先例族：Go 1.5 双链解耦 / rustc 2011 先自举后 1.0 稳定 / bootstrappable builds）+ subset-spec §2.1（语义面扩展经语义同刀 MUV 合法行使先例——Stage 2.1 翻转形制）+ tech-debt r163 检视（TD-026 重审排期 = 本轮）/ r163 §14.8 偏差 B1（类型注解消费面 → 本窗刀 1）
> **刀序单源**: bootstrap-completion-plan.md v1.26 §3 序 8 + §4.5（本档 §5 为引用面——冲突时以 completion-plan 为准）

## 1. 开窗记账（触发链落档——r163 终态 → r164 开窗）

| 链 | 事件 | 簿记位 |
|---|---|---|
| **登记** | r140 规划刷新轮——两新窗入序（W-SEXP-RETIRE 序 4 + W-LANG-FOUNDATION 序 7）：用户指令⑤「将 kerf 语言自身底层和基础内容完成纳入计划」落位 | bootstrap-completion-plan v1.5 §3 序 7 + stage0 §9.126 设计层 |
| **从属位维持** | r140-r162：C1-C4 未验收期间语言基础窗维持从属位（§21.12-28① 豁免声明——非自举段排期须附可审计裁决理由；自举窗就绪即让位） | completion-plan §3「非自举段排期豁免声明」 |
| **验收 GO** | r163 自举完备验收：C1-C4 复核实测全绿 + D1-D8 深审零阻塞 + 投票 5.5/5.5 → **GO——完成标准宣告达成**（完全脱离宿主语言，宪制排除项除外）+ **从属位解除** = 验收后首议程（用户指令⑤⑦——语言自我推进面的首个消费议程） | completion-plan v1.25 Status + roadmap v2.89 §6 + tech-debt r163 检视 + worklog r163 |
| **开窗行权** | r164（本轮）：§13.1 设计对齐 + TD-026 重审 + 消费面重勘 + 窗口档新建 + 刀 1 排期 r165 | 本档 + completion-plan v1.26 §3 序 8 + tech-debt r164 检视 |

**时机裁定继承**（completion-plan §9，r140）：enum/struct 实现窗法定于自举完备验收之后——「时机未到（非遗忘、非能力回避）」的三个条件 @ r164 全部消解：①设计已全量登记（§9.14.2 R4 + 语法桥生产在位）维持；②「串行自举纪律的必然结果」条件已消解（验收 GO @ r163——串行义务完成）；③与 8 原语不变性零冲突维持（struct/enum = 派生表面非原语面）。**结论：开窗时机成熟，零遗留阻断。**

## 2. §13.1 设计对齐（阶段开始设计对齐——五步流程执行）

### 2.1 设计文档锚清单（§13.1.2 要求 2——带定位）

| 锚 | 位置 | 承载内容 |
|---|---|---|
| stage0 §9.14.2 | 「类型系统成员」节（next10 §2.2 吸收） | 成员三组全清单：基础类型（i8-i64/u8-u64/f32-f64/bool/char/str/`()`）+ 复合（struct/enum）+ 泛型 + 行多态 union + 交叉类型 + 行类型 + 效应行 + 线性能力；**R4 实况对账**：生产面 = HM 单态推断，行多态/交叉/开放记录/线性能力 = Stage 2+ 登记态 |
| stage0 §7.4 | 内部语法 ADT 设计 | 7.4.3 内部 AST 完整定义（CoreExpr/ModuleItem 族——刀 1 注解锚的表示层设计输入） |
| stage0 §6.10 | 2026 理论前沿全景 | 类型维前沿成熟度 ~30%（行多态）——**评估非实施**口径（刀 4 依据） |
| stage0 §9.14.5 | 七决策点对照 | 类型系统[渐进+行多态 vs 纯静态——灵活性+安全性]全部收敛于既有裁定 |
| tool-results/r76-search/ | HM unify 家族检索件 | m1 rustc unify_key / m3 GHC unify / m4 rustc relate / m11-m12 OCaml btype+ctype / q4 value restriction / q6 TS 双向检查——刀 1「标注-推断 unify」的直接参考族 |
| K140-K142 | stage0 §9.113 | Go 1.5 双链解耦 / rustc 2011 先自举后 1.0 / bootstrappable builds——自举达成后特性经自托管编译器发展 = 「自己用自己语言推进自己」正型路径 |
| subset-spec §2.1 | develop/v1/stage-1/subset-spec.md | 语义面扩展经语义同刀 MUV 合法行使先例（Stage 2.1 闭包捕获翻转形制——本窗刀族的流程先例） |

**设计意图摘要**（§13.1.2 要求 2）：语言基础面完备是「语言自我推进」之后的第一个发展议程——annotations are surface sugar the HM layer owns（注解 = 表面糖，HM 层拥有其语义：推断 × 注解双向检查）；struct/enum = 派生表面非原语面（宏展开为既有核心形式——原则 31 表面-内部语法严格分离：任何表面关键字的编译产物 = 相同核心形式）；语言新能力的验证经自身语言进行（.ktf 自描述测试语料——工作流声明）。

### 2.2 实况对账（§13.1.2 流程步骤 3——已实现 / 偏差 / 未实现）

**已实现（生产在位）**：
1. HM 单态推断引擎（kerf-typecheck：`Type` = Int/Float/Bool/Str/Nil/Pair/Arrow/Dyn/Var——infer_module 入口 + 多错误收集 r75/r80 基线）+ 双检查链孪生生产位（infer.ktf 3,774 + typecheck.ktf 1,234——r147 check 段切换）；
2. **语法桥**：目标皮肤注解文法全量 parse-and-drop（parse_type_drop 四位点生产在位——路径/括号列表/效应并集 `|`/函数返回 `->`/`impl`·`effect` 前缀/泛型参数拒绝面；「桥就位语义未接」ruling C1 second half：adt_type 为 v9 合法产生式，参数列表骑注解丢弃面）；
3. match 消费面：oracle expand_match 超集 + expander.ktf match 臂全量镜像（TD-027 已清偿 @ r143——mchk/marm 合成节点 + compile_pattern 六模式族）——刀 3 enum 消费的既有底座；
4. 目标读链孪生生产位（target-lexer.ktf + target-parser.ktf 4,723——r145 read 段切换）——刀 1 实施的孪生同步底座。

**偏差（本窗清偿对象）**：
- **B1**（r163 §14.8 偏差清单登记）：类型注解消费面——parse_type_drop「parse-and-drop」= 桥就位语义未接 → **本窗刀 1**（HM 推断 × 注解双向检查：标注-推断 unify，注解锚定收敛 TVar；注解错误族 + 诊断码 + 位置面）。

**未实现（登记态——零信号不开窗）**：
- struct/enum 表面 + 脱糖（→ 刀 2/3）；穷尽性检查（→ 刀 3）；模式族扩展收口（→ 刀 4）；行多态（§6.10 ~30%——刀 4 评估窗非实施）；交叉类型/开放记录/线性能力/效应族六实例（Read/Write/State/Async/Error/Log）/自定义效应语法/能力模型 L3（→ completion-plan §4.5「后续」行——各按独立窗单源排期）。
- **登记态纪律声明**（原则 38/44-58）：上列未实现项 = 零机制变更义务、零新原语、零冻结面触碰；开窗须各过 §3.3 演进提案。

### 2.3 灰区决策表（§13.1.2 要求 3——不可省略；「刀内裁定」的判据前置）

| # | 灰区 | 裁定归属 | 判据（前置约束——刀内裁定不得违反） |
|---|---|---|---|
| GZ-1 | 注解表示层：reader 如何携注解入管道（StxDatum 包装形式 / 展开器传递面 / ModuleItem 扩展位） | 刀 1 内裁定 | §12 最优>最小（通解优先）+ 双引擎 parity 最短路径（Rust 臂 ↔ 孪生臂等价可机检）+ 8 原语零触碰 + 原则 31 表面-内部分离（注解 = 表面糖，产物 = 核心形式不变或检查面扩展） |
| GZ-2 | struct 表示层：pair 链 vs vector（构造子/字段访问的宏展开形态） | 刀 2 内裁定 | 通解优先（§12）+ FFI 面（TD-026/R-F3 门——表示跨 FFI 面）+ HM 扩展面（Type 构造子最小充分）+ 孪生可表达性（18 内建零字符操作约束的既有披露面） |
| GZ-3 | Type 构造子形态：struct/enum 入 HM 的类型表示 | 刀 2/3 内裁定 | §12 最优>最小 + 推断确定性（A6 预算纪律延续）+ 诊断面（code 注册表逆映射先例 r147） |
| GZ-4 | 穷尽性检查面：check 期 vs compile 期（enum match 臂完备性） | 刀 3 内裁定 | 保守纪律（合法程序零诊断——types.rs Dyn 注释口径延续）+ 多错误收集面（r75/r80 基线） |
| GZ-5 | 行多态评估窗判据（成熟度/触发器/门槛） | 刀 4 内裁定 | §6.10 前沿 ~30%——**评估非实施**（产出 = 判据 + 时机触发器登记，非机制变更） |

**上一阶段 §14.8 偏差处理**（§13.1.2 要求 4）：r163 偏差清单 B4（roadmap §2 Stage 2a「S-expr 形态」历史表述）已注记清偿（宪制序裁定——用户指令⑥ > 历史文本）；B1（类型注解消费面）→ 本窗刀 1 排期（本档 §2.2 偏差节 + §5 刀 1）；B2/B3 零。**处理完毕零遗留。**

**自举完备优先核对**（§13.1.2 要求 5——v15.3）：自举矩阵 G1-G7 全 ✓ 终态 + 验收 GO @ r163——本窗 = 验收后首议程（非自举段让位义务已消解，从属位解除落档 §1）；本窗排期零冲突（唯一活跃窗）。

## 3. 注解消费面重勘（刀 1 实施面——位点到点清点）

**Rust 面（kerf-reader/src/target/parser.rs）**——注解文法四消费位点 + 文法函数三件：

| 位点 | 行号 | 语法位 |
|---|---|---|
| `fn` 定义返回注解 | parse_type_drop 调用 @ fn 定义臂（`fn name(params) -> T { body }`） | 返回类型 |
| `fn` 参数注解 | parse_params 内（`name: T`——Colon 后） | 参数类型 |
| `let` 绑定注解 | let 臂（`let name: T = value`） | 绑定类型 |
| `fn` 表达式返回注解 | fn-expr 臂（`fn(params) -> T { body }`——赋值右侧/表达式位） | 返回类型 |

文法函数三件：`parse_type_drop`（主入口——paths/括号列表/`\|` 并集/`->` 返回/`impl`·`effect` 前缀 + 泛型参数拒绝面 ruling C1）+ `parse_type_parens`（括号类型列表）+ `parse_generic_args_drop`（泛型参数丢弃——`Foo<i64>`）。**当前语义**：全部 `Result<(), ReadError>`——注解在 READ 期死亡，展开器/检查器零感知（B1 偏差的机制根源）。

**孪生面（selfhost/v1/target-parser.ktf——生产位）**：`tp_give_type_drop` + `tp_step_type_drop` 双函数镜像 + 两调用位（tp-give 帧/tp-step 帧）——**刀 1 实施时孪生必须同步镜像**（parity 双臂纪律——r145-r149 段切换形制延续；读链生产位 = 孪生臂，Rust 臂 = oracle）。

**typecheck 锚点（kerf-typecheck/src/）**：`types.rs` Type 枚举（Int/Float/Bool/Str/Nil/Pair/Arrow/Dyn/Var——注解可写类型宇宙的 HM 侧对应面；**Dyn 注释「it is *not* a user-writable `any` (there is no type syntax)」= 刀 1 后陈旧——刀 1 实施时必须共变**〔§8.4.5 文档以实况为准〕）+ `infer.rs` infer_module（注解锚定收敛 TVar 的 unify 接入位）+ `check.rs` 双检查链 + `code.rs` 诊断码注册表（注解错误族的新码接入位——逆映射先例 r147）。

**传递消费面**：kerf-core module.rs `ModuleItem`（注解若经展开器传递则此为扩展位——GZ-1 刀内裁定）+ 展开器 item 收集面 + audit 语料族（新节义务——completion-plan §4.5 刀 1 集成验证列）+ snapshot 语料（注解程序入 ds 锚——刀 1 实施时快照族共变）。

**词汇面（目标皮肤 token）**：`impl`/`effect` 前缀关键字 + `|` 并集 + `->` 返回 + `<` 泛型拒绝 + 类型名 ident 路径——既有 token 面零新增（刀 1 零语法增改——8 原语不变性约束下注解文法已在位，刀 1 只接语义）。

## 4. TD-026 重审（开窗轮议程——r163 排期兑现）

**现状**（r112 登记 → riding 维持至 r163）：FFI dangling——标量批下 dangling 结构性不可能（R-F1 标量拷贝——零 kerf 堆引用跨界，C 侧无从持有悬垂指针）；转为**堆类型 extern 扩展面（str/pair/句柄协议）的门条件**——该面开窗时随 R-F3 显式句柄根协议一并重审。不闭账。

**本轮重审裁定（ARCH-A @ r164）**：**riding 维持 + 门条件精化 = 刀 2 开窗时点**：

1. **刀 1（类型注解消费面）零 FFI 触碰**——注解面 = 类型系统面（检查期语义），非 extern 面；注解消费不产生任何新 extern 形态、不触碰 extern_table_floor、零跨 FFI 类型流通 → **不触发门条件**（刀 1 红线维持）；
2. **刀 2（struct 表面 + 脱糖）= 门条件达成时点**——struct 表示层裁定（GZ-2：pair 链 vs vector）直接决定堆类型 extern 表面（struct 跨 FFI 的表示流通）；str/pair extern 扩展面与 struct 表示同属堆类型跨界族 → **刀 2 开窗首议程 = R-F3 显式句柄根协议重审**（tech-debt r163 检视「G8 刀 2 前置」的排期落档）；
3. **刀 3/4 维持零触发**——enum（tagged 构造子 = pair 家族表示）与模式匹配（消费面）随刀 2 裁定继承，无独立 FFI 新面；若刀 2 裁定产生新堆跨界形态则随刀继承重审（窗口内连续性义务）。

**不闭账理由维持**：r112 裁定 + w3.2-ffi-extern-window §1.6 单源——堆类型 extern 扩展面未开窗前，dangling 问题在生产面结构性不可达（维持）；闭账时点 = R-F3 重审完成且堆类型 extern 面定形后。

## 5. 刀序（单刀单轮——r142 小窗先例；四刀单源 = completion-plan v1.26 §4.5，本表为引用面）

| 刀 | 内容（引用 completion-plan §4.5） | 集成验证（引用） | 排期 | 前置 |
|---|---|---|---|---|
| 1 | **类型注解消费面** ✅ **交付 @ r165**（读链 b1+b2 + 展开器双臂 b3 + 推断层双臂 b4 + 语料族 b5——E0013 第 14 位 + 解析表 + param 锚定 E0009 第三例外 + 16 案语料；GZ-1 裁定 §8 全落位） | 注解程序正负语料 ✅（16 案 1:3 + subset 128/128）+ parity ✅（双臂逐字）+ audit ✅（460/460 V3 重放 125 案）+ 双引擎面 ✅ | **r165 完成** | 无 |
| 2 | **struct 表面 + 脱糖** ✅ **交付 @ r166**（读链 b1 + 展开器 b2 + 推断层 b3 + 语料族 b4——GZ-2 裁定 §9.2：pair 链右折零标记 + GZ-3 裁定 §9.3：Type::Struct 名义承载透明展开 + TD-026 闭账 §9.1：W-HEAP-EXTERN 登记窗承载） | struct 程序正负语料 ✅（13 案 1:3.3）+ fixpoint 维持 ✅（b3 实测 20/20 release 567.67s——孪生自应用最深面）+ gate B ✅（语料 sweep 125→138 零漂移）+ audit ✅（460/460 live）| **r166 完成** | TD-026/R-F3 重审 = 刀 2 开窗首议程 ✅（§9.1 闭账裁定） |
| 3 | **enum 表面 + 脱糖** ✅ **交付 @ r168**（裁定 a + 读链 b1 + 展开器 b2 + 推断层+GZ-4 b3 + 语料族 b4——GZ-4 裁定 §10.1：展开期单段执法〔检查期/编译期零新增〕+ §10.2 表示裁定：cons(decl_index, payload-chain) tag = 声明序 Int + §10.3 模式裁定：首元素查表消歧 + §10.4 Type 承载：Enum(Symbol) 名义封闭〔透明展开当且仅当无损——多 variant 展开有损丢 tag〕） | enum 程序正负语料 ✅（16 案 1:3 + subset 157/157）+ 双引擎 sweep ✅（154 案零漂移 + fed 105/reader 20/expansion 29 裸机口径 + hm_face 管线口径 fed 100）+ T0 29 + T1 52 族全绿 ✅ + audit ✅（close 轮） | **r168 完成** | 刀 2 表示裁定 ✅（pair 链 + 类型层 tag 位 = §10.2 承接） |
| 4 | **模式匹配扩展 + 行多态评估** ✅ **交付 @ r170**（裁定 a〔§11 三面裁定 + GZ-5 评估档案 §11.2〕+ 展开器双臂 b〔oracle + 孪生 + 读链迁移〕+ 语料族 c〔16 案 1:3 + 人口 154→170〕+ close〔v0.125.0 金链 + T2 63/63〕——「struct 模式 = 派生表面非原语面」兑现：消歧 = 首元素双查表、字段位 = car(cdr^k) 零位移、零字段 = nil?、穷尽性三判式） | 模式族语料 ✅（16 案 1:3 + subset 173/173）+ 评估窗档案 ✅（§11.2 四触发器 + 四门）+ audit ✅（BF01/BF04/V3 共变） | **r170 完成——窗口 CLOSED** | 刀 2/3 表示裁定 ✅（pair 链零标记——零位移公式承接） |

**工作流声明**（completion-plan §4.5 原文继承）：本窗全部实施经自托管工作流进行（编辑 .ktf → kerf 编译 → 测试/基准经 VM——C4 面的生产消费）；每刀交付物含 **.ktf 自描述测试语料**（语言经自身语言验证自身新能力——「自己用自己语言推进自己」的逐刀实证）。

**红线**（全刀全程）：8 原语不变性（零新原语/零新内建/**零语法增改**〔struct/enum/注解 = 表面糖非原语面——注解文法已在位刀 1 只接语义；struct/enum 关键字 = 宏展开表面〕/零操作码变更）+ VM Rust 基座宪制排除零触碰 + 孪生 parity 双臂纪律（每刀 Rust 臂 ↔ 孪生臂同步交付）+ eval 验证面保留红线延续（w-eval-retire-window v2.0 红线继承）。

## 6. 出口条件（窗口 CLOSED 判据——四刀交付后逐条核对；**r170 逐条核对全 ✓——窗口 CLOSED**）

1. 四刀全交付 ✓（刀 1-4 集成验证全绿——注解/struct/enum/模式族语料 + parity + audit 新节 + gate B + fixpoint 维持）✓ **@ r170（T2 63/63 八窗零中断 + subset 173/173 + audit BF01/BF04/V3 共变在档）**；
2. **注解消费面机检锚** ✓（parse_type_drop 的 parse-and-drop 形态终结——r165 在档——「annotations are surface sugar the HM layer owns」后半句兑现的可机检断言：注解程序正负语料族在档 + 注解-推断分歧错误族实测）；
3. **struct/enum .ktf 自描述语料** ✓（工作流声明兑现——r166/r168/r170 三代在档（pos-203/pos-302/pos-402 自组织行）——语言经自身语言验证自身新能力的逐刀实证在档）；
4. **TD-026 刀 2 重审落档** ✓（R-F3 句柄协议 + 堆类型 extern 面定形——闭账 @ r166 + W-HEAP-EXTERN 登记窗承载）；
5. **G8 闭合入账** ✓ @ r170（自举矩阵刷新：语言基础面完备——struct/enum/注解消费/模式族收口 + 行多态评估窗档案落档〔§11.2 登记态判据 + 触发器 + W-ROW-POLY〕）+ audit 全语料维持（BF01/BF04/V3 共变）+ 版本金链锁步 v0.125.0。**窗口 CLOSED @ r170。**

## 7. 登记与披露

- **窗口登记**：本档新建（r164）+ completion-plan v1.26（§2 G8 行 → 行权中 + §3 序 8 开窗 + §8 r164 复核行）+ tech-debt r164 检视（TD-026 重审落档 + 零新 TD + 8 原语第一百二十二轮验证）+ roadmap v2.90（§6 当前位置行刷新）+ RELEASE_NOTES r164 节。
- **诚实披露**（§8.4.5 + §20.6）：①types.rs `Dyn` 变体注释「there is no type syntax」自刀 1 交付起陈旧——刀 1 实施时必须共变（登记于 §3 typecheck 锚点节 + 刀 1 内容列）；②注解文法中泛型参数拒绝面（ruling C1 second half）在刀 1 域内维持现状（adt_type 为 v9 合法产生式——泛型语义接入 = 后续窗登记态非本窗四刀范围）；③行多态 = 评估非实施（刀 4 产出 = 判据 + 触发器登记——§6.10 ~30% 成熟度口径，零机制变更义务）。
- **非目标声明**：交叉类型/开放记录/线性能力/效应族六实例/自定义效应语法/能力模型 L3（completion-plan §4.5「后续」行——各按独立窗单源排期，零信号不开窗）；C 后端堆类型支持（随 TD-026/R-F3 刀 2 重审裁定）；泛型语义接入（登记态）。
- **零冻结声明**：本窗刀序 = 排期锚非冻结面（用户常设指令③；刀序调整须过 §3.3 演进提案 + worklog 记录理由）。
- **S-expr 完全转化记录义务**：本窗零 S-expr 转化实施（S-expr 已全拆 @ r150-r154——语料/词面/台账/读链四层终结）——统一完全转化记录文件零更新（义务条件不触发）。
- **子代理派遣纪律**（§21.12-33）：本窗刀实施若分派子代理，先预估工作量裁切粒度（刀 1 = reader + typecheck + 孪生 + 语料 + audit 五面——**建议主 Agent 亲执**〔§21.12-33③ 裁定轮与核心机制面亲执先例〕；机械面〔语料批量/文档族〕可分派）。

## 8. GZ-1 裁定落档（刀 1 内裁定——注解表示层；判据 = §12 通解 + parity 最短路径 + 8 原语零触碰 + 原则 31）

**读链层（已交付 @ r165 b1+b2——commit 944569a）**：
- `parse_type_drop` → `parse_type_spec`（oracle）/ tp 五机族重设计（孪生生产臂）——parse-and-drop 终结，spec 构造面：
  - 承载子：`(define-ann (name (p spec)... | p...) ret-or-nil body)` / `(fn-ann (params) ret-or-nil body)`〔头 span = `||` 两字符〕/ `(E (fn-ann (params) nil body))`〔头 span = effect span〕/ `(name spec value)` let 三元
  - spec 代数：路径裸符号 / `(tuple S...)`〔空 = unit 型；头 = open span〕/ `(arrow A B)` 与 `(union A B)` 右结合〔循环递归形制逐字镜像〕/ `(app path (tuple...))`〔头 span = args 开括号〕/ `impl`·`effect` 裸标记符号〔原文法即裸关键字〕
  - 泛型参数 `Foo<T>` 维持唯一丢弃面（ruling C1 second half——泛型语义 = 登记态）；spec 保留裸路径
  - ret 缺席 = `nil` 标记符号 @ params_end 点 span；**判别规则 = 符号 "nil" 且 span.start == span.end**（真实路径 spec 永远 ≥1 字节——点 span 是「缺席」编码，reader nil_form 惯例）
  - 未注解面逐字节不变（66/66 reader units + 回归断言实证）

**展开层（dann 发射——b3 待实施，本节为裁定）**：
- kerf-core 扩展位：`ModuleItem::Annotate { span: 注解位点, anchor: 锚, kind: Param|Ret|Let, index: u32, spec: LiteralValue 树 }`——零码 item（Require/DefineSyntax 先例）；kind 标签 "param"/"ret"/"let"
- 孪生记录形制：`("dann" s e kind anchor_s anchor_e index spec-value-tree)`——anchor 为十进制串（item 惯例）；spec 值树 = 符号→字符串、列表→右折 Pair 链终 Nil（kerf 数据宇宙，零新类型）
- 脱糖逐字节不变：define-ann → (define header body) + dann 族；fn-ann → (fn (params) body) + dann 族；let 三元 → (name value) 二元 + dann
- **锚定键（双臂一致性的根基）**：
  - param/ret 锚 = fn 节点自身 span——define-fn = 名字 span（= CoreExpr::Fn.span 经 expand_fn_binding）/ 闭包 = 整形式 span（= expand_node 的 stx.span）/ 句柄臂 = 臂 fn 形式 span（读链形式 extent，双臂现有 parity 纪律已保证一致）
  - let 锚 = **值节点的 extent**（= oracle Binding.span〔expand_let 用 value_node.span 构造〕= 孪生 binding 记录中 value 记录的 (s e)——双臂天然一致；NOT pair extent）
- 位点收集：展开器 ctx/全局累加器（位点收集）；**排放点 = 模块走查中每个顶层形式之后**（紧邻其后、确定性序；嵌套模块的 dann 归属其自身走查——作用域自然成立）
- spec 值树转换（oracle）：StxDatum 符号→LiteralValue::Str / 列表→右折 Pair 链终 Nil / Int·Float·Bool·String 同形；（孪生）：ident 记录→ex_text 字符串 / list 记录→Pair 链
- 判定面：TOP_LEVEL_DECLARATION_HEADS += "define-ann"；RESERVED_MACRO_NAMES += "define-ann"；表达式 dispatch += "fn-ann"；expand_let 三元识别（pair len 3）
- 零码臂：compiler（compile.rs 两处 match）/ check.rs（两处）/ eval / pipeline / parity / guards / rebuild_item "dann" 臂 + retarget_items 共变 + expander_parity dump 双向 "dann" 臂

**推断层（锚定 + 双向检查——b4 待实施）**：
- 预通道：infer 预走查收集 dann → (anchor.start, anchor.end, kind, index) 键表 → (spec 值树, 注解 span)
- **解析表**（spec → Type，逐位退化 Dyn——不可解析形制永不约束，保守纪律 = 合法程序零诊断）：
  - 路径名：int/i8..i64/u8..u64/isize/usize → Int；float/f32/f64 → Float；bool → Bool；str → Str；nil → Nil；其余未知名 → Dyn
  - `(tuple)` → Nil（unit）；`(tuple S)` → resolve(S)（分组）；`(tuple S...)` → 右折 Pair 链（逐位解析，不可解析位 = Dyn）
  - `(arrow P R)`：P 为 `(tuple S...)` 或 `(app Fn (tuple S...))` → params = S...；否则 params = [P]；→ Arrow{params, ret}（`Fn` = 函数类型构造子名——语料既有拼写）
  - `(app Pair (tuple A B))` → Pair{A, B}（二元严格）；`(app Fn ...)` 裸位 → Dyn；其余 app → Dyn
  - `(union ...)` / `(impl ...)` / `(effect ...)` → Dyn（登记态——零信号不约束）
- 锚定语义：param 位 = 新鲜 TVar 与解析注解 unify（锚定收敛——注解侧 Dyn 则跳过）；分歧在其后使用位点以 E0009 呈现（锚定收敛的必然）；ret 位 = 体内推断完成后 unify(body_ty, ret_ann)；let 位 = 值推断后 unify(value_ty, ann)；ret/let 分歧 → **E0013**
- E0013（AnnotationDivergence，code.rs 注册表第 14 位 + 逆映射）：消息形制 `annotation divergence: expected \`{ann}\`, found \`{ty}\``（期望 = 注解侧，发现 = 推断侧；E0009 惯例同源；t{n} 元变量显示沿用 Display）；位置 = dann 的注解位点 span
- types.rs Dyn 注释共变义务（§3 登记）：「there is no type syntax」自刀 1 交付起改写（注解文法已在位——零新内核原语维持：类型词汇 = 表面糖语义层解析表所有，非 Type 枚举扩展）

## 9. GZ-2/GZ-3 + TD-026/R-F3 刀 2 裁定落档（r166——刀 2 开窗首议程）

### 9.1 TD-026/R-F3 重审（首议程——r164 门条件时点到达）

**重审输入**：GZ-2 表示层裁定（§9.2——struct = pair 链）+ extern 词汇表实况（`int`/`bool`/`float` 标量全集——R-F1 拷贝物化）+ 刀 2 零 FFI 面实证（struct 值 = 既有 KValue pair 族；extern 调用位 struct 值 → 运行期 R-F1 守卫 `k_as_*_arg` 拒绝既有面）。

**R-F3 显式句柄根协议草图**（为堆类型 extern 面定形——开窗前置门）：
1. **句柄根表**：kerf 侧 intern 表（句柄 → 堆对象）；C 侧持句柄不持指针（跨界值 = 句柄整数，非裸引用）；
2. **显式根注册/注销 API**：C 侧获得/释放必须经 API 对（`k_root_acquire`/`k_root_release`）——句柄生命周期 = 悬垂风险的唯一复活位，API 对是其闭合机制；
3. **GC 集成**：根表成员 = GC 根集（kerf 堆回收与 C 持有互斥——释放后句柄失效为确定性错误非悬垂）;
4. **表示层输入**（刀 2 钉扎）：struct = pair 链——跨界表示 = 逐层句柄化或线性化序列（开窗时裁定；str = 既有堆串表示直接句柄化）。

**裁定：TD-026 闭账（清偿关闭 @ r166）**——r164 闭账时点条件兑现：①R-F3 重审完成（本节协议草图）；②堆类型 extern 面定形 = **W-HEAP-EXTERN 登记窗**（w3.2 §5 既有登记位增补：触发器〔前端出现需要跨界堆值的真实用例——零信号不开窗〕+ 前置门〔本节 R-F3 协议设计 = 开窗首议程〕+ 表示层输入〔struct = pair 链钉扎〕三件）。闭账 ≠ 遗忘：悬垂风险唯一复活位 = 该窗开窗时，R-F3 协议设计为其首议程（登记窗承载，非债务承载）。C 后端堆类型支持随闭账转该窗前设计输入（刀 2 零 C 后端改动实证）。

### 9.2 GZ-2 裁定（struct 表示层）：**pair 链（右折、nil 终结、零标记）**

- **构造表示**：`Name(f0..fn)` → `cons(f0, cons(f1, ... nil))`（统一右折——空 struct = nil；单字段不特化为裸值〔通解优先 §12〕）；字段访问 field i = `car(cdr^i(p))`（i 次 cdr 后 car）。
- **依据**：①8 原语不变性**宪制排除** vector（vector 不在 8 原语/18 内建宇宙——引入 = 新原语违宪）；②18 内建 `cons`/`car`/`cdr` 既有 = 孪生可表达性零字符操作约束触碰；③跨 FFI 零流通（extern 词汇表维持标量全集——struct 值跨界 = 运行期 R-F1 守卫既有拒绝面，刀 2 零新 extern 形态）；④标记位留刀 3（enum tagged 构造子 = `cons(tag, payload)`——struct 单构造子零标记，struct 名驻**类型层**非值层）。
- **表面文法（目标皮肤）**：`struct Name { field: Type, ... }`（大括号 + 逗号分隔 + 允许尾逗号 + 无分号——Rust 形制；`KwStruct` 既有 token 零词法新增）；字段 spec 复用刀 1 `parse_type_spec` 全量文法（tuple/arrow/union/app/impl/effect 裸标记）。
- **规范形**：`(struct Name (field0 spec0) (field1 spec1) ...)`——字段承载 `(name spec-datum)` 二元与 define-ann 参数条带同构（spec 子树 = StxDatum，展开器 `spec_value` 转换既有通道）。
- **使用面零新表达式文法**：构造 = 既有调用形 `Name(args)`；字段访问 = 既有调用形 + 既有 ident 词汇 `Name_field(p)`（skin `_`→`-` 映射既有——规范名 `Name-field`）。`.` 后缀位维持 fail-closed 拒绝（「field or method access」既有面不动）。
- **顶层限位**：struct 声明 = 顶层 item 专属（嵌套 module 内 → 展开器拒绝——extern 顶层裁定同型；平展 struct 类型表的名字空间安全前提）。

### 9.3 GZ-3 裁定（Type 构造子形态）：**Type::Struct(Symbol, Vec<Type>) 名义承载 + 透明展开 unify（纯别名语义）+ 名字保留 Display**

- **变体**：`Struct(Symbol, Vec<Type>)`——struct 名（诊断面保留）+ 已解析字段类型列表；孪生表示 `("struct" "Name" (T...))`。
- **解析表扩展**（刀 1 表的单点扩展）：未知路径名 → struct 表查（**环检测**：解析栈含该名 → 此位降级 Dyn〔递归 struct 保守纪律——`struct Node { val: i64, next: Node }` 的 `next` 位 = Dyn，struct 本体名字保留〕）→ `Struct(name, fields.map(resolve))`；查无 → Dyn（刀 1 保守纪律延续）。
- **unify 语义：恒透明展开**——Struct 与任何非同形对端 unify 时展开为 pair 链（右折 Nil 终结）再 unify；**无同名特判**（同形异名互通 = 运行期合法故保守放行；名义身份检查〔Point ≠ Circle 同形亦拒〕= Stage 2+ 类型系统演进登记态——本刀保守纪律否决）。环检测 ⇒ Struct 恒有限树 ⇒ 展开恒终止（A6 预算确定性）；resolve 产物恒 ground（零 TVar）⇒ 零 occurs 面、Struct 永不入链接表。
- **Display**：名字单显示（`Point`）——诊断面最优（「expected `Point`, found `str`」）；E0013/E0009 消息用统一前原值（非展开链）。
- **生成注解（脱糖发射）**：构造子 define 携生成 dann（param i spec = 字段 i 声明 spec；ret spec = struct 名路径）；访问器 define 携生成 dann（param 0 spec = struct 名路径；ret spec = 对应字段声明 spec）——刀 1 param 锚定/E0009 第三例外 + ret unify/E0013 机制全量复用（声明字段类型 = 用户书写注解，锚定即执法非发明诊断）。

### 9.4 实施面设计（四 MUV——b1 读链/b2 展开器/b3 推断层/b4 语料）

- **b1 读链双臂**：`parse_struct_decl`（item 位 KwStruct 拒绝臂 → 解析臂；表达式位拒绝臂维持——struct 非表达式）+ target-parser.ktf 镜像机族；curated 族新增正负案。
- **b2 展开器双臂**：kerf-core `ModuleItem::Struct { span, name, fields: Vec<(Symbol, LiteralValue)> }` 零码 item（Annotate 先例）+ `expand_struct`（警察四族：顶层限位/struct 重声明〔预走查计数序盲——extern 同型〕/名字保留〔define-ann/define 对 struct 名 → 拒绝；STAGE0_GLOBALS/extern 名占用 → 拒绝〕/重复字段名）+ 脱糖发射序（ctor define → ctor danns → acc0 define → acc0 danns → ... → dstruct 记录）经 `pending_items` 通道（annotations 通道同型新增）+ 十一消费面零码臂（compile×2/check×2/infer 收集非跳过/eval/retarget/rebuild/dump 双向/compiler_parity 最小记录/infer_parity 全量记录）+ expander.ktf 镜像（ex_struct 臂 + 合成 define/dann/dstruct 记录 + compiler/typecheck arity 跳过臂）。
- **b3 推断层双臂**：`StructTable`（名字 → (字段 spec 值树, 声明 span)——collect 递归嵌套 module）+ resolve 表单点扩展（环检测栈）+ `Type::Struct` + unify 透明展开臂 + Display 名字单显示 + infer.ktf 镜像（ti_struct_collect + ti_resolve 扩展 + unfold 臂 + 显示模板）+ types.rs 注释共变（Type 宇宙新增 Struct 变体——刀 1 Dyn 注释口径延续）。
- **b4 语料族**：正 ≥3（构造+访问全链值验证 / .ktf 自描述〔struct 语料自身用 struct 组织——工作流声明兑现〕/ 递归 struct 环降级）+ 负 ≥9（1:3——E0009 构造违约族 / E0013 注解分歧族 / 展开器警察四族 / 读链拒绝族）+ 人口钉扎 13 文件共变 + 分类钉扎（infer/check 轴）。
- **红线核对**：零新原语（pair 链 = cons/car/cdr 既有）/ 零新内建 / 零操作码变更（dstruct = 零码 item）/ VM 零改动（struct 值 = 既有 KValue pair 族）/ C 后端零改动 / 孪生 parity 双臂纪律全程。

## 10. GZ-4 + enum 表示/模式/类型承载 刀 3 裁定落档（r168——刀 3 开窗首议程）

### 10.1 GZ-4 裁定（穷尽性检查面）：**展开期单段执法（enum 感知扩展）——检查期/编译期零新增**

- **既有底座**（实况勘定 @ r168-a）：`expand_match` 的 irrefutable 末臂纪律 = 展开期执法已在位（`NonExhaustiveMatch` 错误族既有通道；末臂 test 恒真 vacuously——折叠形制「last arm contributes a plain binding」）。
- **刀 3 扩展**：末臂放行二择一——①irrefutable（既有纪律维持，非 enum 的 match 零触碰）②「scrutinee 域内 enum 已知 + 臂模式覆盖全 variant」（完备性放行——末臂携真实 tag 判别 test，链尾 else = 完备性承诺〔合法程序域内不可达——tag 恒 ∈ 声明序全集，构造子 define 单源〕）。
- **完备性判定域 = 合法程序域**：match 值恒经构造子产生（tag 恒 ∈ 声明序全集 + payload 链长度恒正确）→ 放行承诺在合法程序域内成立；手工 cons 伪值 = 域外（FFI 零流通——R-F1 守卫既有，extern 词汇表标量全集）。
- **裁定依据**：①移到检查期须放宽展开期 irrefutable 纪律 → 双段执法 + 折叠形制分裂（末臂 test 恒真 vs 真实 test 两套逻辑跨层分布）——架构面劣化，否决；②保守纪律自动满足（完备程序零诊断 ✓ / 缺口程序 = 既有 `NonExhaustiveMatch` 错误族诊断 ✓）；③多错误收集面：展开器错误通道既有（match 语法完整性属展开器职责边界——r75/r80 多错误收集基线在 check 层不覆盖 match 语法面）；④孪生可表达性：预走查表 + 计数比较 = `struct_counts` 先例同型（18 内建零字符操作约束零触碰）。

### 10.2 enum 表示裁定（GZ-2 继承——tag 位落地）：**cons(decl_index, payload-chain)——tag = 声明序 0 基 Int**

- **构造表示**：`Variant(a0, a1)` → `cons(i, cons(a0, cons(a1, nil)))`——i = 声明序 0 基 Int；payload chain = struct 表示右折同型（无 payload variant → `cons(i, nil)`——payload 空 = nil，与空 struct 同型）。
- **依据**：Int 字面量 18 内建恒可表达 + 数值比较 `=` 既有（tag 判别 = `(= (car s) i)`——孪生零字符操作约束零触碰）；struct 名驻类型层非值层（§9.2 依据④继承：tag = variant 位，struct 单构造子零标记）。
- **tag 裸面披露**：`car` 可取出 tag Int（表示裸面 = struct 字段裸面同性质——刀 2 已披露形制；类型层 Enum 封闭不展开〔§10.4〕——裸面恒表示层细节，类型层不暴露）。

### 10.3 模式面裁定：**首元素查表消歧（enum 表命中 → variant 模式；未命中 → 既有六模式族零触碰）**

- **歧义面清单**（compile_pattern 既有分区 + 扩展位——实况勘定 @ r168-a）：3+ 元素列表 = registered (not implemented) 拒绝区（variant 模式现成扩展位——首元素命中 → 变体模式，未命中 → 维持拒绝）；2 元素 = pair 形区（首元素命中 → 1 payload 变体模式，未命中 → pair 形维持）；1 元素列表 = 透传区（维持）；裸符号 = 绑定区（零 payload 变体名命中 → tag-only 变体模式，未命中 → 绑定维持）。
- **variant 模式 test 形制**：`(if (pair? s) (if (= (car s) i) <payload 位模式> false) false)`——shape 守卫 + tag 判别 + payload 逐位；payload 位 i = `car(cdr^{i+1}(s))` 递归 compile_pattern（tag 移位 +1——struct 访问公式同族；payload 无额外链长守卫 = 既有 Int 模式 identity 形制同性质〔cross-kind scrutinee = 运行期类型错误，identity 披露〕——合法程序域内链长恒正确〔§10.1 判定域〕）。
- **名字空间纪律**：variant 名优先（查表命中即变体模式——绑定替代 = 换名）；variant 名驻声明域（与 struct 名同型预留警察——define 对 variant 名 → 拒绝）。
- **穷尽性计数**：variant 模式按 variant 名去重计数 vs 全集比较（覆盖全集 = §10.1 ②放行；重复 variant = 警察面或放行——b2 实施时按 §12 通评定）。

### 10.4 Type 承载裁定（GZ-3 继承）：**Type::Enum(Symbol) 名义封闭承载——同名 unify 通过、不透明展开、Display 名字单显示**

- **变体**：`Enum(Symbol)`——enum 名单承载（无字段列表：多 variant payload 形状多态，类型层无单一展开形）；孪生表示 `("enum" "Name")`。
- **不透明展开的数学依据**（与 struct 透明展开的分化——同一原则的正确分化非不一致）：透明展开当且仅当无损——struct 单构造子：值层形状 ↔ 类型层形状一一对应（展开 = 同义反复）；enum 多 variant：值层形状（tag-pair）↔ 类型层身份（名）不一一对应（同 E 多形）——展开有损（丢 tag 区分）→ 封闭承载。
- **unify 语义**：Enum × Enum 同名 → 通过；Enum × Enum 异名 / Enum × 其他具体（含 Struct/Pair）→ 具体 Mismatch（E0013 消息「expected `E`, found ...」名字保留——Display 同型）；Enum × Dyn → Dyn 放行（既有保守）。
- **car/cdr 域检查**：Enum 参数 = **类型层拒绝**（E0019 car 域错误族既有——「car of non-pair」；类型层 Enum = 原子名义类型，值层 cons 链 = 表示细节不暴露〔原则 31 表面-内部分离的精确应用：两层分离〕）；用户消费面 = match 模式（唯一合法消费通道——构造子生产 + match 消费单源闭环）。
- **解析表扩展**（刀 1/2 表单点扩展同型）：未知路径名 → enum 表查（环检测不需要——enum 声明 payload 不自引用类型层身份〔E 递归消费经 Dyn 降级 payload 位——payload spec 解析仍走 struct/enum 表递归，环检测栈沿用 §9.3 形制〕）→ `Enum(name)`；查无 → Dyn（刀 1 保守纪律延续）。

### 10.5 实施面设计（五 MUV——a 裁定/b1 读链/b2 展开器/b3 推断层+b4 穷尽性/b5 语料）

- **b1 读链双臂**：`parse_enum_decl`（item 位 KwEnum 拒绝臂 → 解析臂——token 既有零词法新增；表达式位拒绝维持——enum 非表达式）+ target-parser.ktf 镜像机族；curated 族新增正负案。表面文法 Rust 形制：`enum E { V0, V1(T0, T1), ... }`（大括号 + 逗号 + 尾逗号允许 + 无分号；裸变体 / `Name(specs...)` 二形；spec 复用刀 1 `parse_type_spec` 全量文法）；规范形 `(enum Name (v0) (v1 spec0 spec1) ...)`——变体承载 `(vname)` 或 `(vname spec0 spec1...)`。
- **b2 展开器双臂**：kerf-core `ModuleItem::Enum` 零码 item（r168 中断遗留 27 行收编——Annotate/Struct 先例）+ `expand_enum`（警察族：顶层限位 / enum 重声明〔预走查计数序盲——extern 同型〕/ 名字保留〔define-ann/define 对 enum 名 → 拒绝；STAGE0_GLOBALS/extern 名占用 → 拒绝；variant 名驻声明域——define 对 variant 名 → 拒绝〕/ 重复 variant 名 / 变体载体 malformed）+ 脱糖发射序（每 variant：ctor define〔`E-Variant = fn(a0..an) cons(i, right-fold payload)`——携带生成 dann：param k spec = 声明 payload spec k、ret spec = enum 名〕→ ... → `denum` 记录）经 `pending_items` 通道（struct 通道同型）+ 十一消费面零码臂同型 + expander.ktf 镜像（ex_enum 臂 + ex_enum_counts 预走查〔struct_counts 同型〕+ match 臂 enum 感知扩展〔§10.1/10.3——mchk/marm 既有合成节点消费 tag 判别形〕）。
- **b3 推断层双臂**：`EnumTable`（名字 → 有序 variant 表〔名字, payload spec 值树列表〕——collect 递归嵌套 module 同型）+ resolve 表单点扩展（§10.4）+ `Type::Enum` + unify 名义封闭臂 + Display 名字单显示 + infer.ktf 镜像（ti_enum_collect + ti_resolve 扩展 + unify enum 臂 + 显示模板）+ types.rs 注释共变。
- **b4 语料族**：正 ≥3（构造+match 消费全链值验证 / .ktf 自描述〔enum 语料自身用 enum 组织〕/ 穷尽性完备程序〔合法零诊断实证——GZ-4 §10.1 ② 首证〕）+ 负 ≥9（1:3——E0009 构造违约族〔payload 参数类型错〕/ E0013 注解分歧族〔enum 名 × 具体异形〕/ **穷尽性缺口族**〔NonExhaustiveMatch——缺 variant 且末臂非 irrefutable〕/ 展开器警察族 / 读链拒绝族 / E0019 car 域族〔Enum 参数 car——§10.4〕）+ 人口钉扎共变 + 分类钉扎（infer/check 轴）。
- **红线核对**：零新原语（tag = Int 字面量 + cons/car/cdr 既有）/ 零新内建（tag 判别 = `=` 既有）/ 零操作码变更（denum = 零码 item）/ VM 零改动（enum 值 = 既有 KValue pair 族）/ C 后端零改动（脱糖产物 = 既有核心形式）/ 孪生 parity 双臂纪律全程 / **match 折叠形制变更披露**（末臂 test 恒真 → 二择一〔§10.1〕——非 enum 的 match 零触碰边界实证）。

## 11. 刀 4 裁定落档（r170——模式匹配扩展 struct 模式族收口 + GZ-5 行多态评估窗档案）

### 11.1 struct 模式面裁定：**首元素查表双查消歧（enum 表优先 → struct 表次之 → 未命中既有六模式族零触碰）——§10.3 消歧序的通解扩展**

- **消歧序扩展**（§12 通解——同一分派点双查表）：`(Name, p0..pn)` 首元素查表两步——enum 表命中（variant_row 且 payload 数匹配）→ variant 模式（§10.3 既有）；enum 未命中 → **struct 表命中（字段数 + 1 == 元素数）→ struct 模式（本刀新增）**；两表皆未命中 → 既有六模式族分区零触碰（2 元素 = pair 形维持、3+ 元素 = 拒绝区维持、1 元素 = 透传维持、裸符号 = 绑定区维持）。双表无歧义依据：variant 名与 struct 名分驻两表互斥（展开警察既有——struct 名字保留警察 + enum VariantNameCollision 跨 enum 全局唯一 + variant 名驻声明域警察；两表交集 = 空集由 `struct_row`/`variant_row` 查表序保证）；查表次序 = 防御性确定性（无语义差）。
- **struct 模式 test 形制**：`(if (pair? s) <字段位模式链> false)`——shape 守卫 + 字段逐位；**字段位 i = `car(cdr^i(s))` 零位移**（与 variant payload 移位 +1 对照——struct 无 tag〔GZ-2 单构造子零标记裁定继承〕）；字段位模式递归 compile_pattern（嵌套能力既有通道自然获得——pair/variant/struct/字面量任意嵌套）。**零字段 struct 模式 = `(nil? s)`**（空 struct = nil——GZ-2 空结构同型裁定；`()` 皮肤面 = `(Name)` 单元素列表透传区——裸 `Name` 符号 = 绑定区维持，零字段 struct 模式经 `(Name)` 透传到 Name 裸符号后按绑定/变体二判既有，无新分区）。
- **载荷模式无链长守卫 = 刀 3 payload 同性质裁定**（identity 形制——cross-kind scrutinee = 运行期类型错误；合法程序域内链长恒正确——scrutinee 类型层 Type::Struct 透明展开把关〔GZ-3 既有〕，值层必为对应长链）；shape 守卫 `pair?` 维持（Dyn 域 fall through 下一臂——模式语义）。
- **字段数契约**：payload 数 ≠ 字段数 → **不命中 fall through**（双查表命中判据自带——与 variant_row 载荷数判据同型；非专门错误：未命中 2 元素 = pair 形语义既有、3+ 元素 = UnsupportedPattern 既有）。**无新错误族**。
- **类型层零新增**：Type::Struct 既有（GZ-3）——模式面零类型层变更零推断层变更（scrutinee Struct × 字段访问 car/cdr 域检查透明展开既有——刀 2 生成访问器锚定同性质）。
- **穷尽性联动（GZ-4 计数域零变更裁定）**：enum 覆盖集只数 variant 名（§10.1 既有）；struct 模式臂**不贡献穷尽性**（单构造子 struct 的 shape 守卫 fall through 保守纪律——Dyn 域可 fall through 故不视为穷尽贡献者；末臂二择一判定维持既有）。`last_is_plain_binding` 联动三判式（r170-b 实施勘定：裸符号零字段 struct 名在 `is_irrefutable` 下为真而其编译产物 `nil?` 可失败——**刀 3 二判式不足**）：`is_irrefutable(last) ∧ variant_face(last).is_none() ∧ struct_face(last).is_none()`——`struct_face` 新探针与编译分区共享单一裁定（§10.3 纪律同型）。
- **孪生镜像**：expander.ktf `ex_pattern` 分区 struct 查表扩展（`ex_struct_rows` 既有〔刀 2 struct 表孪生〕——同一命中判据形制镜像）；`variant_face` 探针双查表扩展（struct 表命中 → 同样非 plain binding 裁定共享——探针与编译分区单一裁定纪律 §10.3 既有）。
- **红线核对**：零新原语（car/cdr/pair?/nil? 既有）/ 零新内建（字段访问 = car/cdr 组合既有）/ 零操作码变更 / VM 零改动（struct 值 = 既有 pair 链）/ C 后端零改动 / 读链**一处放宽**（裁定修正 @ r170-b 实施时勘定：3+ 元组模式原读链拒绝〔neg-065/066 parse-error 锚定〕——**放宽为读链放行**，拒绝迁移到展开器首元素名字消歧〔UnsupportedPattern 既有错误族〕；`variant and struct patterns are not implemented` 兜底消息半句移除〔预留位兑现〕；neg-065/066 期望共变 parse-error → expand-error；audit AC5/AY03/AY10 三腿共变〔AY10 错误顺序腿回归展开层——exhaust > unbound-scrutinee > unsupported 序钉扎恢复 r151 前语义〕）/ 推断层零改动（Type::Struct 既有）。

### 11.2 GZ-5 行多态评估窗档案（**评估非实施**——判据 + 时机触发器登记；产出 = 本节，零机制变更义务）

- **成熟度口径**（stage0 §6.10.1 继承）：行多态 ⚠️ 早期实践（用于效应追踪和可扩展记录）；生产证据 = OCaml 5（无效应安全）/ Koka / Unison（有效应安全——均早期非主流规模）；与最小自举单元相关性 = 高（效应系统的类型基础）。整合决策（§6.10.2）：✅ 预留类型系统——行基效应类型是效应安全的基础。
- **时机触发器四件**（任一达成才考虑开窗——零信号不开窗〔原则 38/44-58〕）：
  1. **需求触发器**：效应族六官方实例（Read/Write/State/Async/Error/Log——§9.14.2 效应成员）任一进入实施排期（行基效应追踪为其类型基础——前置依赖关系成立）；
  2. **成熟度触发器**：行多态生产证据升级（≥2 门主流规模语言生产采用行多态记录/效应——参照渐进类型 TS 判据形制：生产就绪判据 = 规模用户 + 十年验证）；
  3. **替代路径触发器**：可扩展记录（开放记录）需求出现在实际语料或用户显式请求中，且 struct 单构造子 + 透明展开（GZ-2/GZ-3 既有承载）不能承载；
  4. **成本触发器**：HM 单态推断 + Dyn 保守纪律的实际诊断面损耗（推断退化 Dyn 频率实测——calibration-data 可测量轴）超过行多态实现成本。
- **开窗前置门四件**（触发器达成后仍须全过）：①§3.3 演进提案过会；②知识搜索先行（r76-search HM unify 家族扩展——row unify 算法族检索：OCaml btype 行合一 / Koka 行效应 / PureScript rows 先例）；③8 原语不变性核对（行类型 = 类型层扩展零值层原语——Type 构造子 + 行合一算法，无新值层原语无新内建）；④孪生可表达性评估（infer.ktf 行合一镜像可行性——算法复杂度 + .ktf 18 内建可表达性）。
- **登记名**：W-ROW-POLY（tech-debt-register 同步登记——后续独立窗单源排期；本窗口 G8 闭合**不含**行多态实施——评估档案落档即刀 4 交付物）。

### 11.3 实施面设计（三 MUV + close——b 展开器双臂 / c 语料族 / close 收口链）

- **b 展开器双臂**：`compile_pattern` struct 臂（双查表消歧 + 零位移字段公式 + shape 守卫 + 递归嵌套）+ `variant_face` 探针双查表扩展 + expander.ktf `ex_pattern` struct 分区镜像 + expander_parity struct 模式臂；零警察新增（struct 表名字空间既有警察把守）。
- **c 语料族**：正 4（struct 模式构造+匹配全链值验证 / .ktf 自描述〔模式语料用 struct 组织自身元数据——工作流声明兑现〕/ 嵌套模式〔struct 内 pair 内字面量——递归实证〕/ struct+enum 混合模式程序〔双查表消歧序实证〕）+ 负 12（1:3——展开器拒绝族：3+ 元素未命中双表 UnsupportedPattern / struct 字段数不匹配 fall through 拒绝 / 读链既有拒绝复验；GZ-4 联动族：enum match 混 struct 模式臂缺 variant 报错维持 / 末臂 struct 模式非 irrefutable 穷尽缺口；类型族：E0013 注解分歧 / E0009 构造违约既有复验；E0019 car 域既有复验——7 类错误 ≥6 类负向覆盖）+ 人口钉扎共变（154→170）+ .ktf 自描述。
- **close 收口链**：窗口档 v1.4（刀 4 行 ✅ + 状态行）+ completion-plan v1.30（G8 闭合入账）+ roadmap v2.95 + RELEASE_NOTES v0.125.0 + tech-debt r170 检视（W-ROW-POLY 登记 + 8 原语第一百二十七轮验证）+ GATE 1 全量（T2 --force 新鲜全跑 + audit 陈旧钉扎当轮清偿）+ 金链 v0.125.0 + §19 双包 + web 数据面 + **窗口出口核对五条**（§6 逐条）→ W-LANG-FOUNDATION CLOSED 宣告。

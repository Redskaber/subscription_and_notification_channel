# W-EFFECT-INSTANCES（效应族实例窗——效应族三段链·链末段）

> **Status**: **CLOSED（v1.3——r194 刀 3 DELIVERED + 窗口 CLOSED：出口判据六条全 ✓ @ r194 close）**：刀 3 = Async 策略面 + 收口〔§5.8 开刀定案〔同步直通形制 + 再入路由实证 + 严格 thunk 面 + k 形探针滑落边界〕+ selfhost/std/async.ktf（with_async 同步直通退化形处理器）+ 语料 ef-async-* 8 案 2:6=1:3 汇总 + efx_instance_sweep 六族化〔六库前缀 + 人口门 32→40 + 臂门 8/3/3/18→10/4/4/22〕+ 机制 sweep 排除滤网 ef-async- 扩展 + audit Section BK 10 案〔502→512 live EXIT 0 + 守卫四处共变〕+ §14.5 深审 + 共变链收口〔矩阵 v1.20 行 83 翻 ✓ 终态 + 计数 ✓60→61/登记13→12 + stage0 §9.14.2 登记态→实施态注记 + completion-plan 段 3 CLOSED + RELEASE_NOTES 金链 bump v0.139.0 + selfhost/README + tiers.tsv + tech-debt r194 检视〕；零生产面文件——crates/ 构造性零改动（r174 冻结维持）；8 原语第 151 轮构造性维持〕。v1.2——r193 刀 2 DELIVERED：§5.7 开刀定案〔IO 桥形制 + thunk 链组合纪律 + io-in/io-out 双向缓冲钉死约定〕 + 双库 selfhost/std/{read,write}.ktf + 语料 8 案 8:24=1:3 汇总 + efx_instance_sweep 四族化〔五库前缀〕 + audit BJ 492→502 + 机制 sweep 排除滤网扩展；刀 3 待做。v1.1——r192 刀 1 DELIVERED：§5.6 开刀定案〔INST-6 状态代形制 + INST-1 注入通道 (a) + Error/Log 零偏离〕+ 三库 selfhost/std/{state,error,log}.ktf + 语料 24 案 6:18=1:3 + efx_instance_sweep + audit BI 480→492 + T2 fresh 70/70。v1.0——r191 开窗行权轮）**：双前置达成 @ r189（段 2 W-EFFECT-MECHANISM CLOSED〔出口六条全 ✓〕+ §9 六实例消费位接口冻结〔w-effect-mechanism-window §9——六实例消费位形状表 + 冻结裁定五条〕）+ r191 行权开窗（触发器链式达成落档 + 前置门四件全过〔§3.3 提案 = 本档本体 / r191-search 六检索五范式家族 + Rust 惯例锚 / 8 原语不变性第 148 轮设计面 / 孪生可表达性 ✓〕+ 表示与实施裁定落档〔§5〕+ 三刀序〔§6——载体分层冻结序：纯语言三件 → IO 桥两件 → Async 策略面〕+ 出口判据〔§7〕）。单源：六实例消费位形状 = w-effect-mechanism-window §9（本档引用不改写——判据先于先例，接口冻结优先）。

## 1. 一行定位

效应族实例窗 = 效应族三段链的链末段：在段 2 全量交付的 one-shot 可恢复处理程序机制（值层/VM 语义深化 + 效应行推断消费）之上，交付 **stage0 §9.14.2 登记的六官方效应实例**（Read/Write/State\<T\>/Async/Error\<E\>/Log）——六实例 = 冻结机制之上的**词汇包**（处理器 + perform 组合），全部落在 Perform/Handle 冻结原语集内，段 3 零机制变更义务。

## 2. 成熟度口径（现状 + 前沿对照）

**现状（@ r191 开窗时点）**：

| 面 | 现状 | 单源 |
|---|---|---|
| 机制层 | W-EFFECT-MECHANISM CLOSED @ r189：刀 1 值层/VM one-shot 语义（续体值 + k 尾参 + resume/halt + `return` 子句 + ext2 OneShotMark）+ 刀 2 效应行推断消费（箭头携行四元 `("fn" P R row)` + 覆子句三态定型 + 覆行扣除合并）+ 刀 3 corpus-effect 28 案 + audit 480/480 | w-effect-mechanism-window v1.3 CLOSED |
| 接口层 | §9 六实例消费位形状冻结（perform 词汇 / 子句形 / 行类型 / 机制消费位四列）+ 冻结裁定五条（零新原语 / 三种子句形全覆盖 / 箭头携行消费 / 载体分层 / 语法糖后置） | w-effect-mechanism-window §9（本窗单一接口源） |
| 实例层 | **零实例**——六实例全部登记态（矩阵 §5 行 83；stage0 §9.14.2「效应域首批官方族实例——登记态」） | 矩阵 v1.16；stage0 §9.14.2 |
| IO 桥面 | BufferIo + VmIo trait 在位（kerf-vm io.rs——宿主 IO 通道族：read/write 双向缓冲，测试 api 面消费）——Read/Write 实例处理器桥的宿主锚 | kerf-vm src/io.rs |
| 表面语法 | `module` 语法在位（循环/缺失/重复负例族 corpus neg-018/019/020/048）；`require` 消费面 = 展开器装载器 ex_edges（r179 M44）——库文件通道的设计输入 | corpus；expander 装载器 |
| 语法糖 | try/catch/`?` = 标准库宏面（§9.15.3）——依赖表面语法切换窗 #15，段 3 零语法糖义务（§9.2 裁定 5 维持） | stage0 §9.15.3 |

**前沿对照（r191-search 六锚——§4 前置门②）**：

| 锚 | 家族 | 实例面先例 | 本窗消费 |
|---|---|---|---|
| m1 Koka | 行多态效应（生产级） | 效应 handler 作为标准库控制抽象：异常/async-await/迭代器/解析器/**ambient state**（st\<h\> 堆态效应标记）；实例 = handler 库非语言核心 | State 实例 = handler 库形制的直接先例；实例不升原语的家族证据 |
| m2 OCaml 5 · Eio | one-shot 效应（生产级） | **effects-based direct-style I/O 栈**（Eio 1.0——读文件/网络/并发全走 effect handler）；one-shot 续体「足以覆盖几乎所有并发需要且实现远廉」 | Read/Write 实例 = direct-style IO 的 handler 化先例；one-shot 纪律的段 3 复证（§9 m2 同源） |
| m3 Unison | abilities（生产级） | Abort/Exception/Throw 错误能力族 + handler 注入行为与状态（pragdave「abilities = 注入行为与状态的新方式」） | Error 实例的 halt 形家族先例；State 的「处理器持状态」先例 |
| m4 Effekt | 词法作用域 handler（研究原型） | 效应声明形如异常定义 + 标准库 file read/write 实例 | 实例词汇表形制（effect 声明面 = stage0 §9.14.2 自定义效应登记位，本窗不启用） |
| m5 Haskell freer/polysemy | freer 单子族（库级） | Reader/Writer/**State**/**Error** 全部为**库内解释器**（polysemy Sem / freer-simple「若干常见单子作为效应实现」） | 六实例 = 词汇包（库面非原语面）的最强家族证据——§9.2 裁定 1 同调 |
| m6 Rust | 表面糖惯例（非效应族——惯例锚） | Result + `?` 传播糖 = 标准库 + 表面语法；kernel 面最佳实践（lwn） | Error 实例表面糖（try/catch/`?`）后置的惯例佐证——§9.2 裁定 5；Log 的门面（facade）惯例 = Log 实例处理器可替换性的设计输入 |

## 3. 时机触发器（四件——①链式达成 @ r189/r191 行权）

1. **①链式达成 ✓**：completion-plan §3 效应族三段链段 3 开窗前置 = 段 2 W-EFFECT-MECHANISM CLOSED + §9 六实例消费位接口冻结——**双前置达成 @ r189 close**（出口六条全 ✓ + §9 落档同轮）；r190 恢复轮收口后 r191 行权开窗（用户常设指令「放行继续推进和演进」+ worklog r189/r190 尾行单指「段 3 效应族实例窗开窗行权 = 下一入口」）。
2. **②用户指令⑥链式排期 ✓**：目标语言完整语法语义落地总规划（r181-c）效应族三段链段 3 位（completion-plan §3 单源——「六实例逐刀交付」既定行）。
3. **③矩阵 §11 优先级 ✓**：效应族实例窗 = 链末段实施窗（矩阵 v1.16 §11 优先级 2 位效应族三段链行——段 2 CLOSED 后段 3 升当前实施位）。
4. **④§21.12-28 自举段就绪 ✓**：六实例 = 目标语言语义核心的官方词汇面（语言能用自己表达错误/状态/日志——自举语言自身编译器后续消费的语义基座：编译器诊断/Error 面、状态管理面、日志面的语言级先例）；实施位 = 词汇包文件 + 语料/audit 验证面（VM = Rust 永久基座宪制排除项维持）。

## 4. 开窗前置门（四件——全过 @ r191）

1. **§3.3 演进提案 ✓**：本档本体 = 提案（三刀序 + 验收门 + 出口判据；§5 裁定记录判据与备选否决）。
2. **知识搜索先行 ✓**：r191-search 六检索五范式家族 + Rust 惯例锚存档 `tool-results/r191-search/`（六 JSON——m1 Koka stdlib / m2 OCaml 5·Eio / m3 Unison abilities / m4 Effekt / m5 Haskell freer / m6 Rust Result·?）；**零否决记录面**（本窗无算法选型——机制已冻结，检索为实例形制与家族证据非选型输入；对照 r186-search 的 m5/m6 双否决面）。
3. **8 原语不变性第 148 轮设计面 ✓**：六实例全部落在 Perform/Handle 冻结原语集内（§9.2 裁定 1——词汇包零机制变更）；本窗任何刀若发现需要新原语/新 opcode/新通道 = 即时停止 + §3.3 演进提案升级（ unconstitutional 路径禁止）。
4. **孪生可表达性 ✓**：六实例 = .ktf 语言内 handler + perform 组合（m5 词汇包形制）——selfhost 孪生链可表达面内（Handle/Perform/续体值/效应行推断全量在位 @ r189）；Read/Write 处理器体的宿主 IO 桥 = BufferIo 通道（Rust 基座面，非语言面——孪生可表达性不受 IO 桥影响：处理器体的桥调用走 effect perform 词汇，桥实现在宿主）。

## 5. 表示与实施裁定（ARCH-A @ r191——判据先于先例）

### 5.1 实例载体裁定（INST-1）：词汇包 = 库位文件 + 语料消费双面

- **裁定**：六实例交付物 = **实例定义文件**（`.ktf`——handler 族 + perform 包装 define，落位 `selfhost/std/` 新建标准库区）+ **语料族**（`tests/v1/stage1/corpus-effect/` 扩展——ef-state-*/ef-error-*/ef-log-*/ef-io-*/ef-async-* 命名族）双面。库位文件 = 实例的规范单源（m1/m5 家族形制——handler 库）；语料族 = 端到端验证面（§9 消费位形状逐实例钉死）。
- **注入通道**（刀 1 设计件，开刀时定案）：语料消费库文件的两候选——(a) 测试 harness 装配前缀注入（tp_limit 预算前缀先例形制——库定义拼接为被测程序前缀）；(b) 语料单文件自包含（库定义内联拷贝 + 库文件 = parity/规范面）。**倾向 (a)**：单源纪律（库文件唯一 + 语料引用非拷贝）；若 harness 装配面成本超阈值则降 (b) 并在刀 1 worklog 记录判据。
- **否决记录**：(c) 实例升语言核心/原语面——违反 §9.2 裁定 1（ unconstitutional）；(d) 仅语料无库文件——违反唯一可信数据源（实例形状元神散落语料）。

### 5.2 子句形消费分工裁定（INST-2）：三形三分族对齐 §9 冻结表

- **resume 形**（Read/Write/State/Async）：k 形处理器——续体恢复携载荷；State 的 k 捕获 = 状态胞存储点（恢复即回写——m2 one-shot 状态线程同调）。
- **halt 形**（Error）：子句不调 k 直接返回回退值——续体丢弃；`return` 子句 = 成功路径分支（§9 冻结表原文）。
- **退化形**（Log）：处理器返回 nil 体恒续（pos-021 兼容形即日志语义——§9 冻结表原文）。
- 六实例集体消费刀 1 全部语义面 = 段 3 出口判据之一（§9.2 裁定 2 的实例级验收）。

### 5.3 行类型消费裁定（INST-3）：op 类型骑箭头四元槽

- 每实例 op 类型 = `(fn (args) resumeT)` 形状直接骑 `(arrow P R row)` 四元槽（§9.2 裁定 3）；Error 的 raise 恢复面 ⊥ = 唯一异形（halt 消费位）。
- 刀 1 金档须含行类型注解面正例（注解效应行 + 推断消费面各 ≥1——r188 推断面的实例级复证）。

### 5.4 载体分层实施序裁定（INST-4）：三刀序按宿主依赖度升序

- **刀 1 纯语言三件**（State/Error/Log——零宿主依赖，§9.2 裁定 4 先行建议）→ **刀 2 IO 桥两件**（Read/Write——处理器桥宿主 BufferIo 通道族）→ **刀 3 Async 策略面**（调度器 = 策略面；可先交**同步直通退化形**——`await(task)` 处理器 = 立即求值 resume，真调度器 = 策略替换位）。
- Async 同步直通形的诚实边界：交付的是「Async 实例的消费位词汇 + 同步策略处理器」；并发调度策略 = 后续窗（并发/通道 = L3 授权域，矩阵 §5 并发行——8 原语冻结零通道不变性维持，真异步调度器不在本窗义务内）。刀 3 出口注记此边界。

### 5.5 audit 与 sweep 裁定（INST-5）：逐刀扩展 + 汇总收口

- 刀 1/刀 2 各扩展 audit Section BI/BJ（六实例逐实例钉死——命名延续 BH 先例）；刀 3 汇总收口（Section BK 或刀 3 内合——刀 3 设计时定案，480→N 逐刀递增 live EXIT 0）。
- sweep 接线：`efx_instance_sweep`（efx_corpus_sweep 同形制——四裁决臂复用 + 实例族扩展）；tiers.tsv T1 登记（人口逐刀递增）。
- 守卫纪律：audit 组成表 + 总计断言 + 头行断言三处共变（r185-r189 BG 盲区教训——新增节必须同步登记组成表）。

### 5.6 刀 1 开刀定案（INST-6 状态代形制 + INST-1 注入通道定案——r192）

- **INST-6 状态代形制裁定（ARCH-A @ r192，判据先于先例）**：§9.1 State 行「处理器持状态胞」的 kerf 实施义 = **状态代链（generation chain）**——非 OCaml/Koka 的原地可变胞。依据三重：(i) **探针三实证**（r192 临时探针，结果落本档 + tool-results/r192-search/）：同 handle 周期内 get 恒读周期初值（flat-capture 闭包冻结——1+100+1=102 非 111）+ resume 前压的 handler 死亡（栈整体替换实证——unhandled rejection）+ 同 handle 多次路由本身健全（两次 get 各 resume）；(ii) **前沿同构**：polysemy Tactics（The Effect-Interpreter Effect）——State/Reader 全部为解释器递归（状态骑解释器递归线非闭包胞；`Local f ma -> runReader (f i) $ distrib …` 每效应解释即递归重启）；(iii) **§9.2 裁定 1 宪制约束**：原地胞需新原语 = unconstitutional 路径禁止。**形制**：`put(v)` 保 k 形子句签名（§9 消费位零偏离）+ **halt 体**（ef-pos-104 先例形）回传 `("put" v)`——代终结；`state_thread(state, program)` 驱动器世代递归（get 读当代值，put 以 v 开新代，program 无 put 正常完成即链终值）。**语义边界诚实注记**：put 之后的同代代码不执行（halt 截断）——语料负例钉死；跨代状态线程化完整可达（迭代式 State = 图灵完备状态编程）。**§3.3 偏离记录一行**：§9.1 State 行「处理器持状态胞」实施义经此裁定为世代递归线（偏离理由 = 冻结语义数学边界 + m5 家族证据），词汇/子句形/行类型三面零偏离。
- **INST-1 注入通道定案 = (a) 前缀注入**：harness 装配（sweep/audit 各一前缀注入函数，按语料族名路由——ef-state-\* → state.ktf / ef-error-\* → error.ktf / ef-log-\* → log.ktf；混合案多前缀拼接）；tp_limit 预算前缀先例形制（`assembled_expander_target_source_with_limit` 同构）；成本实测 ≈30 行 Rust 远低阈值——(b) 自包含否决（单源纪律：库文件唯一 + 语料引用非拷贝）。
- **Error/Log 形制确认（零偏离）**：Error = `attempt(program)`（raise k 形签名 + halt 体〔§9 原文「子句不调 k」〕+ return 子句成功路径〔§9 原文〕，回传 `("ok" r)/("raise" e)` + `unwrap` 便捷组合子）；Log = `with_log(program)` 退化形恒续 nil（§9 原文 + pos-021 兼容形）+ `with_log_via(policy, program)` 可注入门面（m6 Rust log facade 惯例）。
- **行类型注解面（INST-3 刀 1 承载）**：注解效应行正例走 API 面（§5.2 裁定维持——arrow-with-row 无 target-skin 表面，ann_pin_carrier 形制金档案）；推断消费面正例走生产链语料（fn 内 perform 自然推断）。BI 各 ≥1。

### 5.7 刀 2 开刀定案（IO 桥形制 + 组合纪律 + 双向缓冲钉死——r193）

- **IO 桥形制裁定（ARCH-A @ r193，判据先于先例）**：Read/Write 处理器体的桥 = **§8.8 宿主内建调用**（`read_line()` / `write_line(payload)`——Stage 0 globals 表内既有词汇，皮肤映射 read-line→read_line）——桥实现在宿主（kerf-vm io.rs BufferIo，Rust 基座面非语言面），桥调用走可调用词汇（§4 孪生可表达性注记的实测兑现：crates/ 零改动）。依据：(i) §9 冻结表 Read 行「resume 单射」——k(read_line()) 种子行即续体载荷；(ii) Write 行「resume + 副作用驻处理器体」——write_line(payload) 副作用在子句体 + k(nil) 完成确认；(iii) m2 Eio direct-style IO 锚（效应位点平坦，通道归处理器）。
- **src/dst 诚实注记**：缓冲面服务单确定性通道——src/dst 骑词汇寻址位（§9 形状零偏离），桥将任意 src/dst 映射到单一缓冲通道；真实流面的资源寻址 = 策略面后续窗（驱动器 0.8 进程流接线为生产侧先例）。探针实证：src 类型漂移（read(42)）合法——行推断为 src 定 int，缓冲桥不约束（运行时无诚实拒绝面，不作语料负例）。
- **组合纪律裁定（thunk 链）**：with_read/with_write 组合 = **thunk 链** `with_read(|| { with_write(p) })`（内层 handle 压入外层动态范围，双效应路由活）；实参位嵌套 `with_read(with_write(p))` = **应用序求值边界**——实参先求值，p 在仅 write handler 下运行，read 逃逸未处理（探针实证 unhandled effect read）——语料负例 ef-io-neg-344 钉死。
- **fail-closed 双面（§8.8 既有边界的实例级钉死）**：读越种子尾 = 运行时拒绝（`read_line: end of input`）——ef-io-neg-347；write 载荷非字符串 = 运行时拒绝（`write_line operand must be a string`）——ef-io-neg-345（类型面无拒绝：perform 操作数行推断为新鲜元变量，不经行合一约束——诚实注记，注解面〔BJ10〕可钉行形状）。
- **双向缓冲钉死约定（sweep 扩展）**：语料指令 `// io-in: <行>` 逐行种子（前序先出）+ `// io-out: <行>` 逐行钉记录输出（RunOutcome.outputs）——双向验证 = 值钉 + 通道两侧钉。
- **新族共变义务（机制 sweep 排除滤网）**：efx_corpus_sweep（r189 机制语料 sweep）按文件名排除实例族——新族 ef-io-* 首跑被排除滤网捕获（未排除 → 未前缀注入 → unbound with_write 红）后扩展——后续新增实例族（刀 3 ef-async-*）必须同步扩展该滤网。

### 5.8 刀 3 开刀定案（同步直通形制 + 再入路由 + 严格 thunk 面——r194）

- **同步直通形制裁定（ARCH-A @ r194，判据先于先例）**：§9.1 Async 行「resume 单射 + 调度策略驻处理器」的刀 3 实施义 = **同步直通退化形**——task = thunk（零参闭包），处理器体 `k(task())` 内联求值后立即注入续体（§5.4 裁定的最小诚实形：策略槽位交付的是退化策略，真调度器 = 策略替换位——后续窗 L3 授权域，并发/通道 = 8 原语冻结零通道维持，本窗零义务）。依据三重：(i) §9 冻结表原文「k 形（k 恢复携完成值）」——k(task()) 即完成值单射；(ii) m2 Eio direct-style 锚（await 位点平坦——同步策略下 await 位点与求值点重合，平坦性保持）；(iii) 探针 A 实证 42（`perform await(|| { 41 + 1 })` 全链生产位绿）。**词汇/子句形/行类型三面零偏离**（§9 表逐位对齐——k 形子句 + `(await (fn (task) V))` 骑箭头四元槽 + BK10 注解面 pin `(fn () int | (row await int))`）。
- **再入路由裁定（探针 B 实证 + VM 源读）**：子句体执行期间原 handler 存活——exec_perform → oneshot_entry 快照含 handler 栈且不弹（快照入续体，活动栈原样）；故 task 内嵌套 perform await 再路由至同一处理器（探针 B = 42 全绿）。此为 r192 探针 B（子句体内新压 handler 死亡——栈替换）的补全面：新压者死、原存者活。语义后果：同步策略下嵌套 await 递归组合健全（task 内的 await 由同一 with_async 承接——递归展开至内层续体，同代返回链完整）。
- **严格 thunk 面裁定（探针 C 实证）**：await 操作数必须是可调用——非闭包操作数（int）在处理器体内联求值时于 apply 拒绝：`type mismatch: call callee must be a closure or builtin, got `int``。诚实注记：行推断为 task 定新鲜元变量（同 r193 write 严格串面先例）——运行时拒绝面非类型层拒绝面；注解面（BK10）可钉行形状。
- **k 形探针滑落边界（探针 D 实证）**：`perform await(a, b)` 双操作数——探针（子句 params == args + 1）失配〔2 ≠ 2+1〕→ 退化 invoke：k 槽位接收原始操作数 b，内联求值成功后 `b(42)` 于 apply 拒绝（同严格 thunk 面文本）。续体永不形成——perform 元数契约 = 恰一操作数（task）；语料负例 ef-async-neg-358 + audit BK9 钉死。
- **§5.4 诚实边界出口注记（窗口 CLOSED 义务）**：交付物 = 「Async 实例消费位词汇 + 同步策略处理器」；并发调度策略 = 后续窗（L3 授权域——矩阵 §5 并发行，零通道 8 原语冻结维持），真异步调度器不在本窗义务内。本注记随窗口 CLOSED 落档于 §8 后续消费面登记行。

## 6. 刀级 MUV 排期（最小先行 + 逐刀金档/audit 门）

| 刀 | 交付物 | 验收门（量化） |
|---|---|---|
| **刀 1**（纯语言三件） | `selfhost/std/state.ktf` + `error.ktf` + `log.ktf`（handler 族 + perform 包装 + 行类型注解面）+ 语料族 ef-state-*/ef-error-*/ef-log-*（每实例 ≥6 案 = 正 ≥2 + 负 ≥4，三族合计 ≥18 案正负 ≥1:2 汇总 1:3 校验）+ audit Section BI（≥10 案）+ sweep 接线 + tiers.tsv T1 | 语料全绿 + audit 480→≥490 live EXIT 0 + sweep 四臂全绿 + 快面三绿 + oracle 零文件机检（r174 冻结）+ fixpoint 位级 |
| **刀 2**（IO 桥两件）**DELIVERED @ r193** | `selfhost/std/read.ktf` + `write.ktf`（处理器体桥 BufferIo——宿主通道消费位）+ 语料族 ef-io-*（双向缓冲注入/读取钉死 ≥8 案 1:3——实交 8 案：io-in/io-out 双向钉死 + 正交性/应用序边界/严格串面/越界 fail-closed）+ audit Section BJ（10 案〔492→502〕）+ sweep 扩展（四族化 + 五库前缀）+ 机制 sweep 排除滤网 ef-io- 扩展 | 同刀 1 形制 + BufferIo 通道 api 面回归（kerf-vm lib 63/63 零扰动）✓ 全过 |
| **刀 3**（Async 策略面 + 收口）**DELIVERED @ r194 + 窗口 CLOSED** | `selfhost/std/async.ktf`（同步直通退化形处理器——§5.4 诚实边界注记）**DELIVERED** + 语料族 ef-async-*（8 案 2:6=1:3——同步直通 + 嵌套再入路由正例；正交性/严格 thunk/非程序/k 形滑落运行时负 + 顶层 E0006 类型负 + 未闭合串读层负）+ audit Section BK（10 案〔502→512 live EXIT 0〕）+ sweep 六族化（六库前缀 + 人口门 40 + 臂门 10/4/4/22）+ 机制 sweep 排除滤网 ef-async- 扩展 + 收口六件（出口判据逐条 ✓ + 矩阵 §5 行 83 翻 ✓ 终态 + 计数 ✓61/登记12 + stage0 §9.14.2 注记 + completion-plan 段 3 CLOSED + RELEASE_NOTES 金链 bump v0.139.0） | 六实例全绿 + audit 512/512 live EXIT 0 + 出口判据六条全 ✓ → **CLOSED** |

**MUV 边界纪律**：一刀 = 一轮（§4.2）；刀内不可降级交付；跨刀不并轮（r186-r189 三刀三轮先例形制维持）。

## 7. 出口判据（窗口 CLOSED 六条——全 ✓ @ r194 close）

1. ✓ 六实例全量交付（库位六文件 + 语料族全绿——State/Error/Log/Read/Write/Async 逐实例消费位形状与 §9 冻结表逐位对齐；六文件 wc：state 73 + error 52 + log 44 + read 49 + write 55 + async 41 = 314）。
2. ✓ 三种子句形全覆盖实例级验收（resume 4 实例〔Read/Write/State/Async〕+ halt 1 实例〔Error〕+ 退化 1 实例〔Log〕——§5.2 分工表全兑现）。
3. ✓ 行类型消费实例级验收（六实例 op 类型骑箭头四元槽 + Error ⊥ 异形——注解面〔BI11/BJ10/BK10 三例〕+ 推断面金档各 ≥1）。
4. ✓ audit 终态 live EXIT 0（三段汇总 480 + BI 12 + BJ 10 + BK 10 = 512 ≥ 510；守卫四处共变零盲区）+ sweep 四臂全绿（六族 40 案 10:30 = 1:3）。
5. ✓ 零新原语维持（8 原语第 151 轮——本窗全程构造性；oracle 零文件机检逐刀维持）。
6. ✓ 共变链收口（矩阵 §5 行 83 翻 ✓ 终态 + 计数 ✓61/登记12 合计 91 维持〔登记-1 ✓+1——v1.17 头声明口径；窗口档初稿「91→92」为登记/✓平移误记，以矩阵单源为准并在此披露〕 + stage0 §9.14.2 注记 + completion-plan §3 段 3 CLOSED + RELEASE_NOTES 金链 bump + 台账 wc 实测 + tech-debt r194 检视 + web 同步 + §19 双包）。

## 8. 载体分层与效应族链定位

- **效应族三段链全景**：段 1 W-ROW-POLY（行类型类型基础——CLOSED @ r185）→ 段 2 W-EFFECT-MECHANISM（机制地基——CLOSED @ r189）→ **段 3 W-EFFECT-INSTANCES（官方词汇面——CLOSED @ r194，出口判据六条全 ✓）**。段 3 收口 = **效应族链全链闭合 @ r194**（「统一而分治」模型 stage0 §9.15 的实例级终验：六官方实例全部落在冻结原语集内 = 设计自证）。
- **正交登记窗族维持**：W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN 零信号不开窗（矩阵 §11 触发器观测维持——非冻结）；语法糖窗（try/catch/`?` 表面糖——§9.2 裁定 5 + m6 惯例锚）= 段 3 后独立候选，依赖表面语法切换窗 #15。
- **后续消费面**（登记态——本窗不实施）：编译器自身消费 Error/Log 词汇（自举语言编译器诊断面——§21.12-28 自举段深化候选）；并发调度策略窗（Async 真调度器——L3 授权 + 矩阵 §5 并发行；**§5.4 诚实边界出口注记 @ r194 CLOSED**：交付物 = Async 消费位词汇 + 同步策略处理器 with_async〔async.ktf〕，策略替换位开放——真调度器不在本窗义务内，零通道 8 原语冻结维持）。

---

*单源声明：六实例消费位形状 = `w-effect-mechanism-window.md` §9（冻结优先，本档 §5 实施裁定不与之冲突；冲突时 §9 为准 + §3.3 演进提案记录偏离理由）。检索存档：`tool-results/r191-search/`（六件 JSON）。*

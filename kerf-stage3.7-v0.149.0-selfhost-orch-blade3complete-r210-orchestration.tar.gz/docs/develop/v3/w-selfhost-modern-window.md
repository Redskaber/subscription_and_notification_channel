# W-SELFHOST-MODERN 自举源现代化窗——12 件 .ktf 孪生用最新语言表面完整重构 + 桥模式终局裁定

> **Status**: **CLOSED @ r180**（**刀 6 DELIVERED @ r180——infer.ktf 4,471→4,512 + target-parser.ktf 4,402→4,424 收官双件 + §14 映射表 M49-M65〔刀 6 门全 parity sweep + fixpoint 17/17〔B≡C 位级〕+ T2 63/63 含 audit 460/460——oracle 零改动第五次行使；台账 21,382→21,445；金链 v0.131.0；出口六条逐条核对 ✓ → 窗口 CLOSED〕；前序刀 1-5 维持原文）——刀 1 DELIVERED @ r175——semver.ktf + micro-toml.ktf 试点双孪生上 G8 表面，表示恒等 + parity 六族全绿 + §9 脱糖映射表；刀 2 DELIVERED @ r176——manifest/lockfile/resolve 组合程序族三件 + §10 映射表；刀 3 DELIVERED @ r177——typecheck.ktf + target-lexer.ktf 判定面/词法面两件 + §11 映射表 M21-M30〔刀 3 门 hm_twin_face 4/4 + target_lexer_twin 7/7 含自应用闭环；台账 21,272→21,254；金链 v0.128.0〕；**刀 4 DELIVERED @ r178——compiler.ktf + macro.ktf 编译面/宏面两件 + §12 映射表 M31-M40〔刀 4 门 compile_segment_switch 11/11 + fixpoint 三阶段 17/17〔B≡C 位级——fixpoint 载体自应用〕 + expand_segment_switch 9/9 + steady_expander_chain 9/9 + gate-B 5/5；遮蔽族冻结（刀 5 共变）；台账 21,254→21,274；金链 v0.129.0〕；**刀 5 DELIVERED @ r179——expander.ktf 最大件全表面 + 遮蔽族两份共变 + §13 映射表 M41-M48〔刀 5 门全 parity sweep + fixpoint 17/17 + T2 63/63 含 audit 460/460——T2 首跑揭 r178 两 audit 针遗漏〔AO10/AP09〕当轮共变清偿；遮蔽族 22 名恒等体机检〔r178「16」低估勘正〕；台账 21,274→21,382；金链 v0.130.0〕；登记 @ r174——四件形制齐备；触发器①已达成〔G8 闭合 @ r170 = 用户指令④「每当确认完善 kerf 端自己特性和能力时，使用 kerf 当前最新词法语法语义完整重构 kerf 自举 kerf 端的全流程，替换原始编码」的触发条件〕；开窗排期 = 本档 §6 刀序，每刀独立行权；余二刀：5 expander〔含遮蔽族两份共变〕→ 6 infer/target-parser 收官 + close）
> **流程权威**: docs/sop.md v15.6（§21.12-28 自举完备优先——自举段最高排期优先级 / §21.12-33 孪生手术亲执 / §3.2.1 长套件纪律 / §19.3 打包前测试）
> **依据**: 用户指令④（重构替换原始编码）+ 指令⑧（桥模式质疑——知识搜索裁定见 §3）+ 指令⑪（完整完全自举首要——「自举语言能自己用自己语言推进自己」的源码面兑现）；知识检索件 = tool-results/r174-search/（五检索 30 命中）；stage0.md §9.25（BS-A）/ §9.113（K140-K142 自举时序锚——自举后特性经自托管编译器发展 = rustc/Go 同型正路）
> **职责边界**: 本档承载 W-SELFHOST-MODERN 的裁定、刀级 MUV 排期与桥终局裁定；语言表面规范单源 = subset-spec + 02 §8.13（EBNF 定稿位）；转化台账 = docs/develop/v3/s-expr-conversion-record.md（每刀入账义务）

## 1. 一行定位

G8 语言基础四刀（r165-r170）把类型注解、struct、enum、match 模式族交付进生产链后，selfhost/v1 的 12 件孪生仍以**旧最小子集编码**书写（8 原语直接形 + 手工 cons 链 + 嵌套 if 分派）——本窗把这些源**用语言自身的最新表面完整重构**（数据形表 → struct/enum 声明、分派臂 → match 模式、参数契约 → 类型注解），使「自举语言用自己语言推进自己」在编译器自身源码面兑现（rustc 采纳自身新特性 / Go 1.5 后工具链现代化同型——K-r174-5/K140）。

## 2. 成熟度口径（现状 + 前沿对照）

| 面 | kerf 现状 | 优秀语言参照 |
|---|---|---|
| 编译器自源采纳新特性 | 12 件全旧子集编码（21,094 行零 struct/enum/match 消费面——G8 四刀只交付了「语言能表达」未交付「编译器自己用」） | rustc 逐版采纳自身稳定特性（bootstrap 编译器支持后才入源——MSRV-of-itself 政策，K-r174-5）；Go 1.5 后工具链用新版 Go 重写（K140） |
| 重构安全网 | parity sweep 族 + fixpoint 三阶段 + audit 460 live（位级守护在位） | rustc UI 金档 + crater；Go 可复现工具链（K-r174-2） |
| 行为不变判定 | 双口径既有：字节级（同语法 fixpoint 链）+ CoreExpr 全等（跨语法）——BS-C 分层判据 | Go 三轮自检（toolchain2/3 轮缺陷自浮——K-r174-2） |

## 3. 桥模式终局裁定（用户指令⑧——「每新增一个需求就加一座桥」的反模式终结）

**知识锚（r174-search 五检索）**：
- **K-r174-1（rustc）**：UI 测试 = 编译输出对照**钉死的期望文件**（.stdout/.stderr 金档），非对照第二实现（rustc-dev-guide tests/ui.html）。
- **K-r174-2（Go）**：Go 1.21+ 完美可复现工具链——验证 = 可复现重建 + 校验和库；自举自检 = toolchain2/toolchain3 轮（新编译器缺陷在后轮自浮）——go.dev/blog/rebuild + golang.design bootstrap §3.3。
- **K-r174-3（GHC）**：validate 分层测试套由 **Python** 驱动（刻意非自举——验证器避免自依赖）；boot libraries 概念（编译器自依赖库集）。
- **K-r174-4（Inko）**：自举后编译器 = 唯一实现，前版编译器为引导基座，验证 = 自身测试套（yorickpeterse.com 2019）。
- **K-r174-5（rustc 特性面）**：新特性经 stable/beta/nightly 通道渐进；强向后兼容保证（rustc-dev-guide implementing-new-features.html）。

**裁定（ARCH-A @ r174）**：

1. **过渡期双实现已履约完毕**：oracle + 孪生 + parity 的双实现形制 = T-a 切换窗（r145-r149）的**过渡验证工具**——其职责（证明替换链等价）已由 G4 闭合 + r163 GO 完结。过渡工具不升格为永久制度。
2. **成熟自举语言零永久双实现先例**：rustc/Go/GHC/Inko 无一为每个新特性维护第二实现 + 逐特性 parity；验证面 = 金档期望 + 可复现构建/fixpoint + 分层测试套（外部驱动）。
3. **oracle 冻结裁定（即刻生效为判据）**：Rust oracle 四段（read/expand/infer+check/compile）**冻结于 v0.125.0 语言面** = 回归验证基线（既有语料的 parity sweep 维持全绿）；此后新语言表面特性**停止 oracle 共同实现义务**（G8 后首个适用者 = 未来 W-ROW-POLY / 效应族实例等窗）——新特性验证 = ①语料行钉死期望（金档形——rustc UI 同型）②fixpoint 三阶段（自编译自执行自复现——Go 三轮自检同型）③audit 例程。**桥模式终结**：不再有「每需求一座桥」。
4. **本窗自身零新桥**：现代化重构 = 纯源面变换（语义恒等），oracle 零改动，parity sweep 逐位绿 = 重构正确性的定义本身。
5. **GHC 教训吸收**：验证驱动器（分层引擎/守卫）保持宿主侧（bash/Rust test harness），**不追求验证基础设施自举**——验证器自依赖 = GHC 刻意回避的反型。

## 4. 时机触发器（四件——①已达成）

| # | 触发器 | 状态 |
|---|---|---|
| ① | 语言基础面确认完善（G8 四刀 CLOSED）= 用户指令④「每当确认完善 kerf 端自己特性和能力时」 | **✓ 达成 @ r170** |
| ② | 自由排期区无更高优先自举段（§21.12-28——14 登记窗零信号，自举段就绪 = 首要入口） | ✓ 达成 @ r171-r174 扫描 |
| ③ | 验证安全网在位（T2 63 族 + fixpoint + audit 460 live 全绿基线 @ r170） | ✓ 达成 |
| ④ | 用户显式排期（本轮指令④⑪原文） | ✓ 达成 @ r174 |

## 5. 开窗前置门（四件）

1. §13.1 设计对齐：本档 §1-§3 即对齐产物（表面规范锚 subset-spec + 02 §8.13；脱糖映射表 = 每刀 a-MUV 义务）。
2. §21.12-28 合规：自举段（编译管道自举面的源码现代化）= 最高排期优先级 ✓。
3. 8 原语不变性核对：重构为**表面糖消费**（struct/enum/match = 派生表面非原语面——r168/r170 裁定），核心产消经脱糖抵达同一 CoreExpr——零新原语零通道零 VM 零语法变更 ✓。
4. 孪生可表达性：G8 表面已全量入孪生展开器/推断层（ex_cov 家族 + Type::Struct/Enum 名义承载）——孪生源自身消费这些表面 = 生产链已可处理 ✓。

## 6. 刀级 MUV 排期（最小先行 + 逐刀 parity/fixpoint 门）

| 刀 | 对象（行数 @ r170） | 内容 | 验收门 |
|---|---|---|---|
| 刀 1 | semver.ktf（304→337）+ micro-toml.ktf（603→662） | 试点刀：数据形（Version/Constraint 记录形）→ struct 声明；分派 → match；**脱糖映射表落档**（a-MUV = §9 M1-M12） | ✅ DELIVERED @ r175（parity 六族全绿：semver 36 + micro-toml 48 + manifest 19 + lockfile + resolve 30 + pkg_window 8；表示恒等机检；台账 21,094→21,186；金链 v0.126.0） |
| 刀 2 | manifest.ktf（494）+ lockfile.ktf（659）+ resolve.ktf（478） | 组合程序族三件同型重构（刀 1 模式复用） | ✅ DELIVERED @ r176（parity 六族全绿 + kp 三态带回退：semver 36 + micro-toml 48 + manifest 19 + lockfile + resolve 30 + pkg_window 8 + kp_selfhost 6〔含回退带〕+ kp_corpus 7 双臂；映射表扩展 §10 M13-M20——struct 型字段首例消费 + 顶层 nil 模式首例；台账 21,186→21,272；金链 v0.127.0） |
| 刀 3 | typecheck.ktf（1,286→1,264）+ target-lexer.ktf（1,065→1,069） | 判定面 R1-R8 规则走查 → match 臂化；词法分派表 → match | ✅ DELIVERED @ r177（hm_twin_face 4/4 + target_lexer_twin 7/7 全绿——含 12 件 selfhost 固定点自应用闭环；关联族 typecheck 36 + hm_twin_chain 6 + parity_contract 15 + reader_seed 17 + corpus 5 + format_guard 3；映射表 §11 M21-M30 + 边界勘定十一条；oracle 零改动——冻结裁定第三次行使；台账 21,272→21,254；金链 v0.128.0） |
| 刀 4 | compiler.ktf（1,900→1,877）+ macro.ktf（692→735） | CP 两遍分派 → match；宏库保守重构（低风险面） | ✅ DELIVERED @ r178（刀 4 门全绿：compile_segment_switch 11/11 + fixpoint 三阶段 17/17〔B≡C 位级——fixpoint 载体自应用〕 + expand_segment_switch 9/9 + steady_expander_chain 9/9 + gate-B 双口径 5/5 + 关联族〔parity_contract 14 + subset_corpus 173 + pkg_window 8 + typecheck_twin_sweep 6 + hm_twin_face 4 + format_guard 3〕；映射表 §12 M31-M40 + 边界勘定十一条〔**遮蔽族冻结——刀 5 共变**〕；oracle 零改动——冻结裁定第四次行使；台账 21,254→21,274；金链 v0.129.0） |
| 刀 5 | expander.ktf（4,740→4,850） | 最大件：警察族分派 + ex_cov 家族 → struct/enum/match 表面 | ✅ DELIVERED @ r179（全 parity sweep 全绿：subset_corpus 173 + parity_contract 15 + expand/check/read/compile segment switch 9/10/9/11 + steady_expander_chain 9 + steady_target_reader 7 + superinstr 16 + method_jit 21 + pkg_window 8 + format_guard 3；fixpoint 三阶段 17/17〔B≡C 位级〕；**T2 全量 63/63 含 audit 460/460 live——T2 首跑揭 r178 两 audit 针遗漏〔AO10 fusion-arm + AP09 poison-scan——r178 更新 tests/ 树两针漏 audit 本位副本〕当轮共变清偿**；映射表 §13 M41-M48 + 边界勘定十条〔遮蔽族 22 名两份共变——r178「16」低估勘正；注解 ~41 位双形名面诚实裸名〕；oracle 零改动——冻结裁定第五次行使；台账 21,274→21,382；金链 v0.130.0） |
| 刀 6 | infer.ktf（4,471→4,512）+ target-parser.ktf（4,402→4,424） | W 机分派臂 + 帧机状态 → 表面化收官 | ✅ DELIVERED @ r180：全 parity sweep + fixpoint 三阶段 17/17（B≡C）+ T2 63/63（audit 460/460）+ oracle 零改动（git diff crates/ 零文件——第五次行使）+ 出口六条 ✓（§7 逐条核对） |
| close | 窗口收口 | 出口核对 + 文档五件 + §19 双包 | ✅ @ r180：出口六条逐条核对（12/12 重构完毕 + 全 parity 族绿 + fixpoint B≡C + 台账 12 件改账 + T2 新鲜全绿 audit exit 0 + 矩阵 §7 行翻转 ✓ + roadmap/completion-plan 共变） |

**每刀义务**（孪生手术纪律 §21.12-33③——亲执）：a 裁定（脱糖映射表 + 边界勘定）→ b 重构 + parity 族绿 → c 语料/台账/RELEASE_NOTES 共变 + 版本金链 → T2 门（末刀/close）。

## 7. 出口判据（窗口 CLOSED 六条）

1. 12/12 件重构完毕（旧编码消费面清零——rg 守卫可选）；
2. 全 parity sweep 族绿（oracle 冻结基线 vs 重构孪生逐位）；
3. fixpoint 三阶段恒等（B≡C 位级维持）；
4. 台账 12 件行数全量改账 + 转化记录 v1.x 共变；
5. T2 全量新鲜全绿（§19.3）+ audit exit 0；
6. 矩阵 §7 行翻转（自举面 = 现代化源码态）+ roadmap/completion-plan 共变。

## 8. 零载荷边界

本窗零新原语、零通道、零 VM 变更、零语法增改（消费既有 G8 表面）；oracle 冻结裁定为验证策略条款（K-r174-1/2/4 先例族），不改既有 oracle 代码；验证基础设施（分层引擎/守卫）保持宿主侧（K-r174-3 教训）。

## 9. 刀 1 脱糖映射表（a-MUV 裁定 @ r175——semver.ktf + micro-toml.ktf）

> 依据：§3.4（现代化重构 = 纯源面变换，语义恒等，oracle 零改动）+ G8 各刀的 oracle 脱糖面（expand.rs struct_ctor_body/struct_field_body/variant_arm/compile_pattern + infer.rs resolve_spec）单源直读。本表每条 = 表面构造 ↔ oracle 脱糖产物的 **CoreExpr/值恒等条款**，b-MUV 实施位点逐条对账（§9.5）。

### 9.1 表示恒等条款（结构面）

| # | 表面构造（新） | oracle 脱糖产物（expand.rs 锚） | 被替换旧形（孪生内） | 恒等依据 |
|---|---|---|---|---|
| M1 | `struct Version { maj: i64, min: i64, pat: i64 }` + 构造 `Version(a, b, c)` | ctor fn：params=字段名，body = `(cons p0 (cons p1 (cons p2 nil)))` 右折（struct_ctor_body） | `pair(a, pair(b, pair(c, nil)))` | cons 右折逐位恒等（同序同 nil 尾） |
| M2 | 访问器 `Version_min(p)` | 每字段一 define：`fn(p) { car(cdr^k(p)) }`（struct_field_body，k = 字段序） | `first(rest(p))` | car(cdr^k) 同链 |
| M3 | `struct Constraint { maj: i64, min: i64, has: i64, pat: i64 }`（四槽 quad） | 同 M1（4 字段右折） | `pair(maj, pair(min, pair(has, pair(pat, nil))))` | 同 M1 |
| M4 | `struct Span { start: i64, end: i64 }`（micro-toml 全部 `(s e)` 对） | 同 M1（2 字段右折） | `pair(s, pair(e, nil))` | 同 M1 |
| M5 | `struct Pos { line: i64, col: i64 }`（`(line col)` 对） | 同 M1 | `pair(line, pair(col, nil))` | 同 M1 |

### 9.2 表示恒等条款（分派面）

| # | 表面构造 | oracle 脱糖产物（compile_pattern 锚） | 被替换旧形 | 恒等依据 |
|---|---|---|---|---|
| M6 | `match r { ("ok", (v, nil)) => B, _ => A }` | scrutinee 载入 carrier let → `if (pair? r) (if (eq? car(r) "ok") (if (pair? cdr(r)) (if (eq? (car (cdr r)) v-bind-真值…) (nil? (cdr (cdr r))) false) false) false) …`——即 pair? 形状守卫 + eq? 字面测试 + car/cdr 位置绑定 + nil? 尾检查的 if 链 | `if eq(first(r), "ok") { let v = first(rest(r)); B } else { A }`（A/B 含错误回传臂） | 值域恒等：孪生自构 record 恒为合法右折链（构造域全称），两形在构造域上逐值一致；非构造域值不可达（parity 驱动域 = 构造域，§3.4 正确性定义） |
| M7 | `match r { ("err", (k, rest5)) => …, _ => … }`（err 记录 6 链的前两槽解构） | 同 M6（字面 "err" + 余链绑定） | `if eq(first(r), "err") { let k = first(rest(r)); … }` | 同 M6 |
| M8 | `match b { 92 => …, 34 => …, _ => … }`（整数字面臂） | `if (= carrier 92) … else if (= carrier 34) … else …`（Int pattern → `=` 内建） | `if b == 92 { … } else if b == 34 { … } else { … }` | `=` 与 `==` 同内建（int 域封闭）；scrutinee 单评（carrier let）与旧 let 同构 |
| M9 | 嵌套对模式 `(("err"), (k, (fs, (fe, nil))))` 级联 | pair? 守卫级联 + 逐位 car/cdr | `first(rest(rest(r)))` 手链 | car/cdr 同链（M2 家族） |

### 9.3 表示恒等条款（注解面）

| # | 表面构造 | oracle 脱糖/推断锚 | 恒等依据 |
|---|---|---|---|
| M10 | 标量注解 `fn sv_is_digit(b: i64) -> bool` | dann 记录（Param/Ret）→ resolve_spec 标量表（i64→Int, bool→Bool）→ E0013 分歧检查 | 检查期-only（零运行时载荷）；注解与实况一致（值域真契约）故 E0013 恒不触发 |
| M11 | 结构类型注解 `con: Constraint, ver: Version` | resolve_spec 经 struct 表 → Type::Struct；**Struct↔Pair 透明律**（infer r170 裁定：`Type::Struct(_, _)` 与 `Type::Pair(..)` 双向兼容） | 下游 lockfile/resolve 仍以 cons 链构造 quad/triple（刀 2 才重构）——Pair 实参过 Struct 注解位恒兼容；Dyn 实参永不约束 |
| M12 | 列表型参数**不注解**（`bytes` 裸名） | 无 dann 位 → HM 自由 | 列表类型在注解面不可表达（§9.4-③）——裸名 = 诚实降级，非假装 |

### 9.4 边界勘定（裁定——不迁移面及理由）

1. **标签联合记录（字符串头）一律保持 cons**：`("ok" X)` / `("err" kind …)` / ("g"/"e"/"t"/"a") / ("str"/"int") 记录 = 宿主契约 + 下游 first/rest 消费面（harness decode_sv_face/decode_mt_verdict + manifest/lockfile/resolve 解链）。enum 表面会换成**整数 tag 表示**（variant_arm 的 `tag as i64` 判别），破坏 RS-1 宿主契约与下游组合程序——**刀 1-6 全窗禁用 enum 于宿主契约记录**（枚举面仅当某记录的表示本身迁移时评估，须 harness + 下游同刀共变，超出本窗「纯源面变换」边界）。
2. **Open 帧（is_array name entries seen）保持 cons**：entries/seen 为列表值——struct 字段强制携带 spec（parse_struct_decl `name: Type` 文法），列表类型在注解面不可表达 → 无诚实 spec 可写 → 保持 cons（M12 同族诚实降级）。name 槽内部已可经 M4 构造（Span(ns, ne)），帧壳不变。
3. **列表参数不注解**：同上——写 `list` 等伪类型名 = 明知降级的谎言（违反 §2.3-4 诚实纪律），裸参数名 = 正确形态。
4. **mt_lines 的 `(start end)` 行区间**：M4 覆盖（Span）。
5. **导出面冻结清单**（下游消费面 = 不可变契约）：semver = `sv_at / sv_parse_version / sv_parse_constraint / sv_caret_satisfies` 四函数 + `sv_version / sv_constraint / sv_caret / result` 四全局；micro-toml = `mt_at / mt_len / mt_rev / mt_append / mt_run / mt_find_byte …` 全 mt_ 函数族 + `mt_verdict / mt_failed / mt_doc / mt_error / result` 全局。**名字、参数序、返回记录形状逐位不变**（manifest/lockfile/resolve 以 first/rest 解链消费 + harness value_elems 解码——表示恒等使旧解链零改动通过）。
6. **名称冲突扫描（r175 实测）**：`Span/Pos/Version/Constraint` + 全部访问器名在 selfhost/v1/*.ktf 与 kerf-driver 语义面零冲突（命中均为注释或 Rust 侧 kerf_span::Span 异名空间）；struct 名保留位（StructNameReserved）不触发。
7. **组合程序落位**：manifest 组合序 = mt 前缀 + semver + manifest——两件 struct 声明位于组合程序中段顶层（TopLevel 合法位）；顺序绑定纪律（subset-spec §2.2）= 声明先于首用（文件头部落位）。
8. **`_` 兜底臂语义**：匹配「欲取形」，`_` 回传替代臂（M6 的 A 臂）——`_` 捕获 err + 一切非 ok 形，与旧 if/else 的 else 臂在**构造域**上逐值一致（构造域 = 孪生自产值的全体；非构造值不可达）。此为窗口全刀统一惯例（rustc UI 金档同型的「域全称兜底」惯例）。

### 9.5 b-MUV 对账义务

实施位点逐条回填：semver.ktf = M1/M3/M6/M7/M10/M11；micro-toml.ktf = M4/M5/M6/M7/M8/M9/M10；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行（「表示恒等·映射表 §9 M#」注记）。parity 全绿 = 恒等性的机检证明（§3.4：重构正确性的定义本身）。

## 10. 刀 2 映射表扩展（a-MUV 裁定 @ r176——manifest + lockfile + resolve 组合程序族三件）

> 依据：§6 刀 2 行（刀 1 模式复用）+ §3.4（纯源面变换语义恒等）。刀 1 的 M1-M12 单源直读复用；本节登记刀 2 的新增条款（编号接续 M12）。oracle 面锚：expand.rs parse_struct_decl/struct_ctor_body/compile_pattern（1304-1478：nil/`_`/字面臂/双查表）+ infer.rs resolve_spec（519-568：struct 表嵌套解析）+ unify（836-951：Struct↔Pair 透明展开 + 参数注解静默锚定 1321-1347——「fresh var never fails to unify」）。

### 10.1 表示恒等条款（刀 2 新增——结构面）

| # | 表面构造（新） | oracle 脱糖/解析锚 | 被替换旧形 | 恒等依据 |
|---|---|---|---|---|
| M13 | `struct Slot { span: Span, line: i64 }` + `Slot(Span(qs,qe), line)`（manifest 全局槽位 pkg/ver 载体）| struct_ctor_body：ctor = cons 右折；字段 spec `Span` 经 resolve_spec struct 表半面解析为 Type::Struct(Span,[Int,Int])——**首例 struct 型字段消费面**（类型层交付 @ r166 GZ-3，孪生消费首例在本刀）| `pair(pair(qs, pair(qe, nil)), pair(line, nil))` | Slot 载体 = cons(Span 值, cons(line, nil))；Span 值 = cons(qs, cons(qe, nil))——逐位恒等（M1×M4 复合）|
| M14 | `struct Dep { name: Span, con: Constraint }` + `Dep(Span(ks,ke), con)`（manifest 依赖记录）| 同 M13（Constraint 型字段 = resolve_spec 嵌套第二例）| `pair(pair(ks, pair(ke, nil)), pair(con, nil))` | 同 M13（M4×M3 复合；con 载荷本就是 Constraint 构造值——sv_parse_constraint 产物）|
| M15 | 组合程序族跨件复用：manifest/lockfile/resolve 直接消费 Span/Pos/Version/Constraint（mt + semver 声明于组合程序前段——顺序绑定满足）| 组合程序 = 单程序单模块（sequential defines）；struct 表全程序共享（§9.4-7 刀 1 先例——semver 声明位于 manifest 组合中段）| 首次跨件消费（刀 1 仅本件消费）| 表示层零新面——四 struct 的构造/访问器面全部刀 1 已验证 |

### 10.2 表示恒等条款（刀 2 新增——分派面）

| # | 表面构造 | oracle 脱糖锚（compile_pattern） | 被替换旧形 | 恒等依据 |
|---|---|---|---|---|
| M16 | 键匹配器分派表化：`let c = match i { 0 => 112, 1 => 97, ..., _ => 101 };`（七件 mf_is_*/lk_is_* 家族——i 索引常量表）| Int 字面臂 = `(= carrier lit)`（M8 同族）；`_` 兜底 = 末位常量 | `if i == 0 { if mf_at(bytes, s) == w { … } else { false } }` 七臂 if 链 + let 常量绑定 w/x/y/z/g/h | 比较序与递归结构逐位同构（位置 i 比常量 c[i] 后递归 i+1）；i==7 长度检查与越界前置检查保持 if 面（标量判定非分派）|
| M17 | 记录标签分派：`match rec { ("t", (name, nil)) => …, ("a", (name, nil)) => …, _ => { e 记录面 } }`（mf_scan_items）+ `match rec { ("g", _) => …, ("e", _) => …, _ => { 表头面 } }`（lk_items_walk）| 字面头 pair 模式 + `_` 通配尾（M6/M7 同族——mt_loop `("err", _)` 先例）| `if eq(tag, "t") … else if eq(tag, "a") … else { e }` | 构造域四成员（g/e/t/a——mt 层产出全域）；`_` = 域内剩余成员（mt_loop 刀 1 同型——`_` 作域成员非错误兜底）|
| M18 | 语法面直通坍缩：`pair("err", pair("syntax", rest(v)))`（mf_project/lk_project 的 mt 拒绝直通）| 无模式面（纯 cons 重组）——恒等代数：rest(("err" k l c fs fe)) = (k l c fs fe) | 6 级 first/rest 解构 + 7 级重建（`let kind = first(rest(v)); …` 六连）| ("err" "syntax" k l c fs fe) 逐位恒等（tag 后整尾原样转挂）|
| M19 | 三色分派：`match c { nil => {白}, 2 => {黑}, _ => {灰-环} }`（rs_visit 双色检查位）+ 状态分派 `match status { 1 => …, 2 => …, _ => {ok} }`（表项状态 + rs_run 根状态）| **顶层 nil 模式**（compile_pattern Symbol "nil" → nil? 测试——首例顶层 nil 臂消费）+ Int 字面臂（M8）| `if is_nil(c) … else if c == 2 … else {灰}` / `if status == 1 … else if status == 2 …` | 构造域 c ∈ {nil,1,2}（rs_assoc_get 产出）／status ∈ {0,1,2}（表构造面）——`_` = 剩余域成员 |
| M20 | 阶段判别分派：`match phase { 1 => {visit 体}, _ => {scan 体} }`（rs_visit 单函数双相）| Int 字面臂（M8）| `if phase == 1 { … } else { … }` | phase ∈ {1,2}（调用面全称——rs_run/自递归两处）；`_` = 2 = scan 相 |

### 10.3 边界勘定（刀 2——不迁移面及理由）

1. **struct 模式（`Span(s, e)` 臂式解构）不使用**：刀 4 已交付（compile_pattern 双查表 struct_face）但刀 1 惯例 = pair 模式 + 访问器（M6/M2）；本刀复用刀 1 惯例（窗口 §6「刀 1 模式复用」）。struct 模式消费面 = 已登记能力，延后至实际需要臂式解构非标签记录的刀（当前无此形态）。
2. **enum 全窗禁用维持**（§9.4-1）：本刀三件全部标签记录（"ok"/"err"/"g"/"e"/"t"/"a"/"str"/"int" + rs 错误族）保持 cons——harness decode + 下游解链 + RS-1 宿主契约。
3. **列表字段记录保持 cons**（§9.4-2 同族）：lk 条目记录（name-bytes/triple/source-bytes）、rs 目录表项（dir/status/payload）、rs ctx 五槽、rs 边表/ imposition 记录、rs order 记录——列表类型注解面不可表达，无诚实 spec。
4. **nil-union 骑乘参数不注解**（M12 同族）：pkg/ver/cur_name/cur_ver/cur_src/fmt/acc/deps 等初始 nil 后置值参数 = 裸名；Slot_span 等带注解访问器收 Dyn/自由变元参（infer.rs 1321-1347 参数注解静默锚定 + 每调用点新鲜元变元——nil 字面量与 Slot 值在不同元变元上永不相撞；刀 1 sv_caret_satisfies 组合实证先例）。
5. **导出面冻结清单（刀 2）**：manifest = `mf_project / mf_slice / mf_verdict`（resolve 消费面）+ `result`；lockfile = `lk_render_lock / lk_sort_entries / lk_bytes_lt`（resolve 消费面）+ `lk_parse_out / lk_render_out / result`；resolve = `rs_run / result` + `rs_depth / rs_table / rs_dot` 通道全局；内部助手（mf_shift_err/lk_shift_err/rs_err_* 等）签名维持但内部现代化——名字、参数序、返回记录形状逐位不变。
6. **名称冲突扫描（r176 实测）**：`Slot/Dep` + 访问器 `Slot_span/Slot_line/Dep_name/Dep_con` 在 selfhost/v1/*.ktf 与 kerf-driver/kerf-pkg 语义面大小写敏感零命中（小写 `dep`/`slot` 为普通名词参数/注释——大小写敏感符号不同物）；struct 名保留位不触发。
7. **组合程序落位不变**：manifest 组合 = mt + sv + mf；lockfile 组合 = mt + sv + mf + lk；resolve 组合 = mt + sv + mf + lk + rs（assembled_*_target_source 单源）；Slot/Dep 声明位于 manifest.ktf 文件头（组合程序中段顶层合法位，声明先于首用）。
8. **`_` 兜底臂语义（刀 2 域成员惯例扩展）**：M17/M19/M20 的 `_` = 构造域剩余成员（非错误兜底）——与 M6 的错误兜底、mt_loop 刀 1 域成员兜底同族，逐刀按域全称判定（各表「恒等依据」列载明域成员）。
9. **mf_project 参数遮蔽警戒（实勘）**：mf_project(bytes, mt_verdict) 的参数遮蔽同名全局——resolve 组合以 `mf_project(bytes, mt_run(bytes))` 传入依赖清单文本，故直通坍缩（M18）与 ok 解构必须作用域参数而非 mt_doc 全局（mt_doc = 根清单面，依赖面不同源）。lk_project 同理。
10. **回退预案（parity 触发）**：M13/M14 若在 parity 六族暴露机制缺陷（struct 型字段首例消费面），回退 = cons 壳 + Span/Constraint 载荷（刀 1 mt_flush 先例形）——表示恒等不变，仅损失访问器面；回退实施须 worklog 记 TD 并在矩阵登记。

### 10.4 b-MUV 对账义务（刀 2）

实施位点逐条回填：manifest.ktf = M13/M14/M15/M16/M17/M18；lockfile.ktf = M15/M16/M17/M18；resolve.ktf = M15/M18/M19/M20；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行。parity 六族全绿（semver 36 + micro-toml 48 + manifest 19 + lockfile + resolve 30 + pkg_window 8——**kp 三态带回退 e2e**）= 恒等性机检证明（§3.4）。

## 11. 刀 3 映射表（a-MUV 裁定 @ r177——typecheck.ktf 判定面 + target-lexer.ktf 词法面）

### 11.1 表示恒等条款（刀 3 新增——分派面与注解面）

刀 3 对象无固定记录形（CP-1 平面序流异构变长记录 + RS-1 字节表——**零 struct 声明**，§11.2-5），现代化面 = 分派臂化 + 注解族两支：

| # | 迁移面（函数位点） | 模式面（G8 能力——单源 expand.rs compile_pattern） | 旧编码形态 | 恒等依据 |
|---|---|---|---|---|
| M21 | 标量 tag 表 match 化：`match first(rec) { "var" => 0, …, _ => quote(-1) }`（tc_child_count 24 臂）/ `match name { "+" => 2, …, _ => nil }`（tc_builtin_arity 18 臂）/ tc_lit_convert 7 臂 / tc_shape_of 3 臂 | String 字面臂（eq? 全类恒等判定——compile_pattern StxDatum::String）+ `_` 兜底；**标量 tag 表 = 直接 match tag 串**（vs M17 pair 模式——尾不消费时不再解构记录） | `let tag = first(rec); if eq(tag, "var") { 0 } else if …` 24 连 | eq? 链逐臂同序——eq?(tag,"var") ≡ 模式臂 "var"；`_` = else 兜底臂原样（quote(-1)/nil/"other"） |
| M22 | walk 模式分派 match 化：`match mode { "expr" => {…}, "args" => {…}, "clauses" => {…}, _ => {letbinds 体} }`（tc_walk 四态 / tc_collect_walk 四态）+ `match mode { 0 => {…}, 1 => {…}, _ => {2 体} }`（tl_scan 三态） | String 字面臂 + Int 字面臂（M8）+ `_` 收尾 | `if eq(mode, "expr") … else if … else {letbinds}` | 末臂穷尽律（刀 1 勘定②）：字面臂可驳、末臂须 `_`——末态（letbinds/2）体落 `_` 臂，头注记明 |
| M23 | 记录组装/收集分派 match 化：tc_assemble 24 臂（12 直通臂坍缩 `_ => rec` 前各自显式）/ tc_collect 7 臂 / tc_walk_items 3 臂 | String 字面臂 + `_` 兜底（直通/跳过体） | tag eq 链 | 同 M21 恒等；直通臂与 else 同体 |
| M24 | walk 标签分派 match 化：tc_walk "expr" 相 tag 10 臂（var/fn/apply/if/lit/assign/let/perform/handle + `_ => nil`）/ tc_collect_walk "assigns" 相 tag 7 臂 | String 字面臂 + 多行臂体块（**臂体块尾逗号**——刀 1 勘定①惯例预载） | 嵌套 if eq(tag,…) 链 | R1-R8 规则体逐臂原样迁移（do/set 突变序列不变——§11.2-4） |
| M25 | 被调分析结果 match 化：apply R2/R4 消费位 + perform R5/R7 消费位——`match callee { ("arity", _) => {…}, ("noncall", _) => {…}, _ => nil }` | Pair 字面头模式（M6/M7 直用）+ `_`（非 pair 调用面——is_pair 守卫的内化） | `if is_pair(callee) { if eq(first(callee), "arity") … } else { nil }` | pair?("x",…) ∧ eq?(head,"arity") ≡ 模式 ("arity", _)——`_` 臂 = is_pair 假分支 + 未知头 else 分支合并（两分支同体 nil） |
| M26 | 判定面注解族（M10-M12 复用 + 新约束）：标量参数 `: i64`（span/arity/count/gen/len 位）+ `: str`（tag/kind/mode/name——刀 1 micro-toml "kind: str" 首例族化）+ `: bool`（in_fn/谓词返程）；列表参数裸名（M12 诚实降级） | 参数注解（infer.rs 1321-1347 静默锚定——r175 三锚先例） | 无注解裸参 | **单态递归约束（本件头注释单源——新勘定）**：tc_walk/tc_collect_walk 递归族参数槽跨全部内部 apply 统一（pre-var 参数槽 unify——类型变更实参会 occur-check），故递归族注解必须全调用点一致；`mode: str` + `in_fn: bool` + x 裸名 = 全调用点恒形态 |
| M27 | 算符极长匹配表 match 化：`match b { 33 => { match b2 { 61 => two(…), _ => one(…) } }, …, _ => tl_err_at(…) }`（tl_op 25 入 b 臂 + b2/b3 嵌套） | Int 字面臂（M8 顶层分派首例——刀 1/2 嵌套常量表先例升顶层）+ 嵌套 match + `_` | `if b == 33 { if b2 == 61 … } else if b == 37 …` 25 连 | = 比较链逐臂同序（b == 33 ≡ 臂 33）；b2/b3 nil 哨兵预计算维持（§11.2-3）——嵌套臂仅接管字面判别 |
| M28 | 词法字节分类面 match 化：`match b { 32 => true, 9 => true, 10 => true, 13 => true, _ => false }`（tl_is_ws 四态） | Int 字面臂 + `_` | `if b == 32 … else if b == 9 …` | 逐值恒等（v9 ASCII trivia 全集 = 四字节） |
| M29 | 词法标量注解族（M26 同族）：byte/pos/pos-start/radix/mode/depth/cstart/uacc/ucount/uat `: i64`；tl_* 递归族同单态约束 | 同 M26 | 同 M26 | 同 M26；mode/depth 整型域 + pos/offset 偏移域全调用点恒形态 |
| M30 | 词法判定臂化的 scan 内层字面判别：tl_scan mode 相内 `b == 47`/`first(rest(remaining)) == 47`/`== 42` 等纯字面比较臂——维持 if 链（谓词臂混杂）**不入 match**（§11.2-2 边界）——仅 mode 三态分派（M22）臂化 | —— | —— | 谓词守卫不可臂化（compile_pattern 模式面 = 字面量/nil/`_`/pair/绑定五族——无谓词模式）；混杂链臂化反而增嵌套层级 |

### 11.2 边界勘定（刀 3——不迁移面及理由）

1. **tl_word_tag 26 关键字等值链维持**：byte-list 等值比较（tl_bytes_eq）无标量判别键——match 模式面无 byte-list 字面模式（compile_pattern 五族单源直读）；重构需引入标量预分类键（长度+首字节）= 算法变更非纯源面变换，违反 §3.4 表示恒等纪律。tl_bytes_eq/tl_bytes_leq/tl_strip_us/tl_char_code 同族维持。
2. **谓词守卫分派维持**：tl_token 四路（34 字面臂可臂化但 word-start/digit 谓词臂混杂——单臂 match 化反降可读性）/ tl_scan 内层 tl_is_ws 谓词臂 / tc_find_last·tc_ext_find_last·tc_member 的 eq(name,…) 运行时值比较 / tl_radix_valid 等——模式臂仅字面量，谓词与运行时值比较不可臂化（M30 同源）。
3. **b2/b3 nil 哨兵预计算维持**：`let b2 = if is_nil(r1) { 0 } else { first(r1) }` 是列表形状守卫非判别表；哨兵 0 不入 b2 match 域（b2 ∈ {61,38,62,46,58,60,124}——0 落 `_` 兜底臂 = 单字符算符路径，恒等）。
4. **do/set 突变序列不动**：多错误收集架构（ruling 21——R1-R8 全收集）与 letrec/locals/marks/handlers/let_stack 推弹对 = 语义载体；match 臂体仅承载原 if 分支体（do/set 调用链原样入臂）。
5. **tc_2..tc_8 访问器族维持（零 struct 声明）**：typecheck 的记录 = CP-1 平面序流异构变长记录（24 tag × 变长字段——无固定 struct 形状可声明，≠ semver/manifest 固定记录形）；手写 car(cdr^k) 链 = M2 访问器的无声明形态，struct 化 = 表示变更违 §3.4。target-lexer 同理（token/错误记录变长）。
6. **导出面冻结清单（刀 3）**：typecheck = `tc_run` + `result` 别名 + 七全局（tc_defines/tc_assigned/tc_diags/tc_handlers/tc_locals/tc_marks/tc_let_stack）+ tc_ext_table/tc_defined_so_far 通道全局——内部助手（tc_walk/tc_collect/tc_assemble/…）签名维持但内部现代化；target-lexer = `tl_verdict/tl_tokens/tl_error` + `result` 别名 + tl_failed 谓词全局——名字、参数序、返回记录形状逐位不变（harness decode + hm/typecheck twin 链消费面）。
7. **名称冲突扫描（r177 预扫）**：刀 3 零新顶层名引入（纯臂化 + 注解——match/注解不开新名）；tc_*/tl_* 前缀族在 selfhost 12 件 + kerf-driver/kerf-reader/kerf-check 语义面维持既有边界零新增碰撞。
8. **`_` 兜底臂语义（域成员惯例延续）**：M21 tc_child_count 的 `_` = extern 记录（quote(-1) 哨兵——CP 约定）；M22 的 `_` = letbinds/2 末态；M23 的 `_` = 直通/跳过；M24 的 `_` = lit 与未知 tag 的 nil 体——逐臂域全称在各表「恒等依据」列。
9. **自应用闭环（刀 3 专属门）**：target_lexer_twin 的 selfhost 固定点族含 target-lexer.ktf 自身——重构后 twin 必须能 lex 自己的新源（`kw-match` 字头自读）；typecheck.ktf 同为 hm twin 链注入源（TYPECHECK_TARGET_SOURCE 单源）——重构后经 harness 注入双引擎判定，R1-R8 诊断流逐位恒等。
10. **回退预案（parity 触发）**：任一 parity 族红 → 变体隔离法二分定位（刀 1 先例——臂尾逗号/末臂穷尽/臂序三惯例已预载故预期零勘定）；M26/M29 注解面 E0013 红 → 回退该位注解为裸名（r175 M12 先例）；M25 is_pair 守卫内化若暴露 unify 面 → 回退显式 is_pair 前置守卫形。
11. **臂体块强制（r177 实勘——§9.2 勘定① 的前置事实面）**：parse_match_expr 的臂体经 parse_block 解析（单源 parser.rs 1723 行）——`pat => expr` 裸表达式臂**非法**，一律 `pat => { expr }`；r175 勘定①（块后强制尾逗号）即本事实的下游条款。r177 首版手写 60 臂漏包裹经 twin 解析面立捕（"unexpected token" 逐臂报位）→ 机械包裹收敛（单行 39 + 多行 21）——消费面学习成本非语言面缺陷，与 r175 三勘定同族；后续刀族（4/5/6）预载本惯例。

### 11.3 b-MUV 对账义务（刀 3）

实施位点逐条回填：typecheck.ktf = M21（tc_child_count/tc_builtin_arity/tc_lit_convert/tc_shape_of）+ M22（tc_walk/tc_collect_walk mode）+ M23（tc_assemble/tc_collect/tc_walk_items）+ M24（tc_walk/tc_collect_walk tag）+ M25（apply/perform 消费位）+ M26（注解族）；target-lexer.ktf = M22（tl_scan mode）+ M27（tl_op）+ M28（tl_is_ws）+ M29（注解族）+ M30（边界维持声明）；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行。验收门（§6 刀 3 行原文）：**hm_twin_face 4/4 + target_lexer_twin 7/7 全绿**（含 12 件 selfhost 固定点自应用面）+ 关联族（typecheck_twin_sweep 6 + typecheck_wiring_seed 10 + hm_twin_chain 6 + selfhost_format_guard 3 + parity_contract 14）。

## 12. 刀 4 映射表（a-MUV 裁定 @ r178——compiler.ktf CP 两遍分派 + macro.ktf 宏库保守面）

> 依据：§3.4（现代化 = 纯源面变换语义恒等 oracle 零改动）+ §6 刀 4 行（验收门 gate-B 双口径 + fixpoint 三阶段）+ 刀 1-3 映射表先例（§9 M1-M12 / §10 M13-M20 / §11 M21-M30）+ r177 实勘预载（§11.2-11 臂体块强制）。本刀对象 = fixpoint 链 B 段载体（compiler.ktf = 全窗最深自引用件——重构后的编译器编译自身）+ MX-2 装配前置件（macro.ktf 骑乘展开器组合序）。

### 12.1 表示恒等条款（刀 4 新增——分派面与注解面）

| # | 表面构造 | oracle 脱糖产物（compile_pattern/expand 锚） | 被替换旧形（孪生内） | 恒等依据 |
|---|---|---|---|---|
| M31 | 编译面标量 tag 表：cp_child_count 24 臂 `match first(rec) { "var" => { 0 }, …, _ => { quote(-1) } }` + cp_lit_convert 7 臂（含 **"pair" 直通臂——compiler 特有**〔typecheck 版无此臂：cp_take 在 assemble 前已转换嵌套 lpair〕`"pair" => { n }`） | Str pattern → eq? 字面测试链（compile_pattern 单源——M21 同型） | `if eq(tag, "var") { 0 } else if …` 链 | eq 与 match Str 臂同内建；scrutinee 单评（`let tag = first(rec)` 既有 let 同构）；M21 边界惯例——尾不消费不再解构（臂体经 cp_N 访问器读） |
| M32 | Pass 1 记录组装分派：cp_assemble 27 臂 `match first(rec) { … }`——define/assign/extern 三臂携带 `do(set(cp_arith_poison, …), …)` 副作用序列 | 同 M31 + do 序列臂内合法（tc_collect 先例——§11.1 M23 消费面） | else-if 链（含副作用臂） | do/set 原样入臂（M24 惯例）；臂序保持原链序（first-match 语义同构） |
| M33 | opcode 栈效应表：cp_op_pops 20 臂 + cp_op_pushes 18 臂 `match op { "call" => { a + 1 }, …, _ => { 0 } }` | 同 M31（Str 字面臂） | `if eq(op, "call") { a + 1 } else if …` 链 | 同 M31；未知名落 `_` = 0/0 降级语义逐位保持（code-axis parity 捕获面不变） |
| M34 | Pass 2 合成模式机（外层）：cp_ewalk 七合成模式 `match tag { "awalk" => {…}, "bwalk" => {…}, "cwalk" => {…}, "acall" => {…}, "peff" => {…}, "cfwalk" => {…}, "mwalk" => {…}, _ => { <真树臂> } }`——`_` 臂携带深度计数器包裹（`cp_depth = cp_depth + 1; if cp_depth > co_limit {…} else { let v = <内层>; cp_depth = cp_depth - 1; v }`） | 同 M31 | 七合成模式 else-if 链 + 末 else 真树包裹 | 合成模式 tag 与真树 tag 零交叠（词法域分离——awalk 族永不与 var/lit 族同名）→ `_` 臂接收域 = 原末 else 接收域逐位一致；深度计数器进出序原样（合成模式旁路 = 臂外位置原样） |
| M35 | Pass 2 真树分派（内层）：`let v = match tag { "var" => {…}, "lit" => {…}, "if" => {…}, "apply" => {…}, "define" => {…}, "assign" => {…}, "let" => {…}, "fn" => {…}, "perform" => {…}, "handle" => {…}, "require" => { nil }, "defsyn" => { nil }, "dann" => { nil }, "dstruct" => { nil }, "denum" => { nil }, "extern" => { cp_extern_walk(t, cp_4(t), 0) }, "module" => {…}, _ => { set(cp_err, pair("err", pair("bad-node", pair(tag, nil)))) } }; cp_depth = cp_depth - 1; v` | 同 M31 | `let v = if eq(tag, "var") {…} else if … else { set(…) }; cp_depth = cp_depth - 1; v` | 值流恒等：臂值 = v（块值语义同构）；bad-node `_` = 原末 else 域全称；尾终止符 bool 契约面不变（臂体返回值逐位同旧） |
| M36 | 排空扫描分派：cp_drain_scan `match first(insn) { "jump" => { if eq(cp_2(insn), 4294967295) { i } else { … } }, "jump-if-false" => { …同构… }, _ => { cp_drain_scan(rest(code), i + 1) } }` | 同 M31 | jump/jump-if-false 二臂 else-if 链 | 哨兵检查维持 if（单比较非分派表——§12.2-6 同源）；首元素读取次数同构（first(insn) 单评） |
| M37 | 宏库模式机（macro.ktf 保守面）：ex_cpat 外层 `match first(t) { "cpl" => {…}, _ => { <cp 节点走查> } }` + ex_mx 双层（外层 mxzip/`_` + 内层模式族 `match first(p) { "wild" => {…}, "lit" => {…}, "var" => {…}, "atom" => {…}, _ => { <列表回退臂> } }`——`_` = plist 匹配 + 非列表 false 的域全称兜底）+ ex_colls 外层（csl/`_`）+ ex_inst 外层（imap/`_`——`_` 臂携带 ident/list 谓词链原样） | 同 M31/M6 | 模式族与模式 tag 的 else-if 链 | 模式 tag（wild/lit/var/atom）与形 tag（mxzip/mx、cpl/cs、imap）词法域分离；`_` 臂内谓词链原样（M30 谓词守卫不可臂化） |
| M38 | 宏库头名分派：ex_binder_names `match hx { "fn" => {…}, "let" => {…}, _ => { nil } }` | 同 M21（tc_builtin_arity 同型） | `if eq(hx, "fn") {…} else if eq(hx, "let") {…} else { nil }` | hx = let 绑定字符串（单评同构） |
| M39 | 编译面注解族（~35 函数位）：返回注解 `cp_len/cp_here/cp_mark/cp_alloc_local/cp_cur_edepth/cp_intern_global/cp_intern_const/cp_child_count/cp_op_pops/cp_op_pushes -> i64` + `cp_is_member/cp_has_name/cp_chain_holds/cp_resolves_outer/cp_same_const -> bool`；参数注解——索引/计数/槽位/深度域 `n/i/acc/at/target/mark/edepth/clen/slot/nlocals/holder/a/b/d: i64` + 名字/操作码域 `name/op/text: str` + **cp_ewalk `tail: bool`**（全调用点字面量 false/true 或参数透传——单态递归约束满足） | dann 记录 → resolve_spec 标量表（i64→Int, bool→Bool, str→Str——M26 同族） | 裸参数名 | 检查期-only 零运行时载荷（M10）；注解与实况一致（索引/计数域恒 int、名字/操作码域恒 str）；**cp_emit/cp_emit_jump/cp_emit_tail_term/cp_ewalk 返回值混合**（pc 或 nil / 项臂 nil）→ 返回不注解（诚实降级——M12 同族）；cp_begin_closure name 槽混合（string 或 nil）→ 裸名 |
| M40 | 宏库注解族（保守面 ~10 位）：`ex_is_mangled/ex_is_name/ex_is_name_eq/ex_is_name_member -> bool` + `ex_macro_resolve(name: str)` + `ex_ar(text: str, stack)` + `ex_active_rename(text: str)` + `ex_macro_use(rules, name: str, x)` | 同 M39 | 裸参数名 | 同 M39；ex_ar text 域 = ex_text 产物恒 string（eq 比较位单源）；混合返回（list/false/nil——ex_lits_walk/ex_syms2/ex_pairnames/ex_binder_names）→ 不注解 |

### 12.2 边界勘定（刀 4——不迁移面及理由）

1. **遮蔽族冻结（本刀最重要边界）**：macro.ktf 的 16 个自含助手（ex_2..ex_8 / ex_cdr3 / ex_cdr4 / ex_is_list / ex_is_ident / ex_text / ex_s / ex_e / **ex_gen** / ex_children / ex_rev / ex_append / ex_len / ex_nth / ex_is_member / ex_assoc + ex_err define）被 expander.ktf 同名重定义遮蔽（MX-2 装配序「合法遮蔽·恒等体」纪律——macro.ktf 头注单源）——**本刀零触碰**；ex_gen 虽为字面头分派面（list/mangled 双臂）亦冻结（单侧现代化破坏双件恒等体不变量）；刀 5（expander.ktf）两份共变现代化（M15 家族词汇跨件复用先例——pkg 五件 struct 表共享序同型）。
2. **分派表 vs 守卫级联边界**：awalk TJ-1 融合的 `eq(first(head), "var")` / acall 的 `eq(first(cp_2(t)), "var")` = 守卫级联（后续槽位/哨兵/前瞻检查深嵌套）非分派表 → 维持 if（刀 3 同型裁定——tc_walk R1-R8 规则体内 bool 守卫原样）；cp_same_const 的 "pair" 检查同族（递归等值走查内卫）。
3. **do/set 突变序列不动**（M24 惯例延续）：cp_extern_walk / cp_emit / cp_patch / cp_truncate 等的 set 链 = 语义载体，match 臂体仅承载原分支体。
4. **谓词守卫维持**（M30 延续）：is_nil / slot nil / parent nil / poison membership 检查全数原样；ex_cpat/ex_mx/ex_colls/ex_inst 的 `_` 臂内 ident/list 谓词链原样。
5. **cp_2..cp_9 位置访问器维持裸名**：CP-1 平面序流异构变长记录（proto 九槽 / estate 五槽 = 异构槽袋非命名字段数据）——零 struct 声明（§11.2-5 同型裁定：tc_2..tc_8 先例）；proto/estate 记录构造与解构全数原样（cp_proto_make/cp_estate_make 及九处调用位）。
6. **单比较不分派**：cp_emit_tail_term 的 `eq(cp_cur, 0)` / cp_drain_scan 哨兵 `eq(cp_2(insn), 4294967295)` / cp_patch 哨兵检查维持 if（M30 同源——分派表面 = 多臂 tag 表）。
7. **导出面冻结清单（刀 4 位）**：compiler.ktf = `result` 全局 + `items` 自由引用（注入通道契约——steady_compiler_chain 构造期检查）+ `co_limit` 消费（装配前缀 define）——cp_* 全族内部名维持（纯体内变换零改名）；macro.ktf = 注册表面（ex_macro_define / ex_macro_use / ex_fail / ex_err / ex_macros / ex_mfs / ex_mfe / ex_mlits / ex_mren / ex_mcount / ex_mgen / ex_mbind / ex_mtrigger + ex_is_name / ex_name_of / ex_is_name_eq / ex_is_name_member 消费面）+ 全部遮蔽族——名字、参数序、返回记录形状逐位不变（expander.ktf 与 harness 消费面零改动通过）。
8. **零新顶层名**：无 struct/enum 声明（分派 + 注解纯变换）→ 名称冲突扫描平凡通过（cp_*/ex_* 前缀族既有边界维持）。
9. **组合落位不变**：compiler.ktf 独立装配（`define(co_limit, N);` 前缀——assembled_compiler_target_source_with_limit 单源）+ macro.ktf 前置 expander（`define(ex_limit, N);` + macro + expander——assembled_expander_target_source 单源）；装配序零改动（include_str! 编译期拾取新源）。
10. **回退预案（parity 触发）**：cp_ewalk 双层 match 化若现 parity 发散（求值序/值流微妙差异）→ 回退保 cp_ewalk 原始 if 链、仅保表类五件（M31/M32/M33/M36 + M37/M38）——parity 族当轮立捕定位（变体隔离法——刀 1 先例）；M39/M40 注解面 E0013 红 → 回退该位注解为裸名（r175 M12 先例）。
11. **臂体块强制实勘条款预载**（r177 实勘 §11.2-11 全文适用）：每臂体经 parse_block 包裹 `{ }` + 尾逗号；末臂 `_` 收尾（末臂穷尽律——字面臂对不可作末臂）；臂序保持原链序；列宽 < 100（selfhost_format_guard 实测面）。

### 12.3 b-MUV 对账义务（刀 4）

实施位点逐条回填：compiler.ktf = M31（cp_child_count / cp_lit_convert）+ M32（cp_assemble）+ M33（cp_op_pops / cp_op_pushes）+ M34/M35（cp_ewalk 外层/内层）+ M36（cp_drain_scan）+ M39（注解族 ~35 位）；macro.ktf = M37（ex_cpat / ex_mx / ex_colls / ex_inst）+ M38（ex_binder_names）+ M40（注解族 ~10 位）；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行。验收门（§6 刀 4 行原文）：**gate-B 双口径**（gate_b_bytecode 全语料 + 双皮肤 transitivity）**+ fixpoint 三阶段**（fixpoint_tests 9 + target_fixpoint_tests 8——B≡C 位级）+ segment switch 双族（compile_segment_switch 11 + expand_segment_switch 9——两孪生各自的切换面）+ 关联族（target_corpus_sweep T1 + steady_compiler_chain/steady_expander_chain 链面 + selfhost_format_guard 3 + parity_contract + snapshot_seed 版本断言）。

## 13. 刀 5 映射表（a-MUV 裁定 @ r179——expander.ktf 最大件全表面 + 遮蔽族两份共变）

> 依据：§3.4（现代化 = 纯源面变换语义恒等 oracle 零改动）+ §6 刀 5 行（验收门全 parity sweep + fixpoint + T2 全量）+ 刀 1-4 映射表先例（§9 M1-M12 / §10 M13-M20 / §11 M21-M30 / §12 M31-M40）+ r175/r177 勘定族预载（臂尾逗号 / 末臂穷尽律 / 臂序 / 臂体块强制）+ r178 遮蔽族冻结条款（本刀共变对象）。本刀对象 = 全项目最大孪生件（4,740 行——单函数 ex_expand 1,491 行 = 全项目最长递归函数）+ MX-2 遮蔽族共变承载件（macro.ktf 同名恒等体解除冻结）。

### 13.1 表示恒等条款（刀 5 新增——分派面与注解面）

| # | 表面构造 | oracle 脱糖产物（compile_pattern/expand 锚） | 被替换旧形（孪生内） | 恒等依据 |
|---|---|---|---|---|
| M41 | 展开器合成模式机（外层）：ex_expand 九合成模式 `let tag = first(t); match tag { "mapx" => {…}, "letloop" => {…}, "doloop" => {…}, "clausemap" => {…}, "fnbind" => {…}, "mchk" => {…}, "pc" => {…}, "pcvar" => {…}, "marm" => {…}, _ => { <深度守卫 + 真树> } }`——`_` 臂携带深度守卫（`if ex_depth >= ex_limit { ex_fail(…) } else { <真树> }`，原链守卫位次逐位保持——合成模式旁路深度计数器的文档化行为不变） | Str pattern → eq? 字面测试链（compile_pattern 单源——M21/M34 同型） | 九合成模式 `eq(first(t), …)` else-if 链 + 守卫 else-if + 末 else 真树 | 合成模式 tag 与真树 tag 零交叠（词法域分离——mapx 族永不与 ident/list 族同名，M34 同源论证）；scrutinee 单评（first(t) 纯访问器——M21 先例）；守卫在 `_` 臂内 = 原链「九臂后守卫」接收域逐位一致；臂体 +4 缩进迁移、真树 +8（M34 同型——纯空白变更） |
| M42 | 展开器表达式头分派（内层）：`match h { "quote" => {…}, "fn" => {…}, "fn-ann" => {…}, "if" => {…}, "let" => {…}, "do" => {…}, "set!" => {…}, "perform" => {…}, "handle" => {…}, "match" => {…}, _ => { <宏应用 + 应用回退> } }`——h 既有 let 绑定串（ex_text(head) 单源）；`_` = ex_macro_resolve 非空走宏展开 / 空走应用回退（原末 else 域全称） | 同 M41 | `if eq(h, "quote") {…} else if …` 十臂链 | h 已 let 单评；特殊形头与标识符头词法域分离（quote/fn/if… 为关键字形，应用回退 = 非特殊形标识符——原 else 接收域 = `_` 接收域逐位一致）；臂体经 parse_block 包裹 + 尾逗号（r177 实勘预载） |
| M43 | 声明展开头分派：ex_decl `match h { "define" => {…}, "define-ann" => {…}, "require" => {…}, "module" => {…}, "define-syntax" => { ex_macro_define(x) }, "extern" => { ex_extern(x, items) }, "struct" => { ex_struct(x, items) }, "enum" => { ex_enum(x, items) }, _ => { ex_fail(pair("top", …)) } }` | 同 M41 | `if eq(h, "define") {…} else if …` 八臂链 + top 失败 else | 同 M42（h let 单源；声明头与表达式头词法域分离——binder_names 排除声明头）；尾四臂单行调用体原样入臂 |
| M44 | 装载器 tag 分派：ex_edges `match first(it) { "require" => {…}, "module" => {…}, _ => { ex_edges(rest(cur), stack, acc) } }` | 同 M31 | require/module 二臂 else-if 链 | M36 同型（二 tag + 域全称兜底）；嵌套于 is_nil(cur) 走查内——走查外壳原样 |
| M45 | 警察标量表：ex_extern_type_tag `match ex_text(t) { "int" => { "int" }, "bool" => { "bool" }, "float" => { "float" }, _ => { nil } }` + **ex_gen（遮蔽族共变件）** `match first(t) { "list" => { ex_4(t) }, "mangled" => { ex_6(t) }, _ => { ex_5(t) } }` | 同 M31 | ex_extern_type_tag 三臂 eq 链 + ex_gen 双臂 eq 链 | scrutinee 单评（ex_text/ex_4 产物——纯访问器）；ex_gen 双件恒等体共变（macro.ktf + expander.ktf 同形同体——M47 纪律）；nil 降级语义逐位保持（C-ABI 标量批外 → nil 消费面 ex_extern_params fail-closed 不变） |
| M46 | 展开器注解族（~45 函数位）：返回注解 `ex_is_list/ex_is_ident/ex_is_bound/ex_frame_has/ex_is_in_frames/ex_hits_has/ex_chain_all_hit/ex_cov_check/ex_enum_exhaustive/ex_is_name_face 族 -> bool` + `ex_len/ex_count/ex_color_of/ex_struct_count/ex_cdr_pow -> i64`；参数注解——名字/文本/span 域 `name/text/nm/vnm/fname/key: str` + 索引/计数/累积域 `n/i/acc/idx/edepth/clen/arity: i64`（span 十进制串域——M26 tc_report 同族） | dann 记录 → resolve_spec 标量表（i64→Int, bool→Bool, str→Str——M26 同族） | 裸参数名 | 检查期-only 零运行时载荷（M10）；注解与实况一致；**混合返回面诚实不注解**：ex_expand 本体（记录或 nil）/ ex_spec_value / ex_extern_type_tag（str 或 nil）/ ex_fail（nil）/ 记录访问器族 / ex_dup_scan（名或 nil）→ 返回不注解；树/列表参数裸名（M12 诚实降级——伪类型名谎言被否决） |
| M47 | **遮蔽族两份共变（本刀核心纪律）**：macro.ktf 与 expander.ktf 共享同名恒等体全族——**实测交集 22 名**（ex_2..ex_7 / ex_cdr3 / ex_cdr4 / ex_is_list / ex_is_ident / ex_text / ex_s / ex_e / ex_children / ex_rev / ex_append / ex_len / ex_nth / ex_is_member / ex_assoc / ex_gen / ex_fail；r178 记账「16 名」为低估——头块 14 单行 + ex_rev/ex_append 计数遗漏 ex_len/ex_nth/ex_is_member/ex_assoc/ex_gen/ex_fail 六名，本刀勘正）——共变义务：任何一侧的现代化（M45 ex_gen match 化 + M46 注解位）**逐字节同施两件**（恒等体不变量 = MX-2 装配纪律的合法性前提——单侧变更 = 遮蔽非法化 + parity 定义性发散） | 同 M45/M46 | 两件同旧形恒等体 | `diff` 恒等体机检（b-MUV 验收位：22 名函数体逐字符一致）；macro.ktf 头注「blade 5 co-modernizes both copies」条款兑现 |
| M48 | 警察族守卫级联维持声明：ex_variant_face / ex_struct_face 的 is_ident/is_list 嵌套谓词链、ex_extern_walk 的 string/is_list 混合面、ex_cov 家族（ex_cov_replace/add/check/walk、ex_chain_all_hit、ex_hits_has）的 is_nil 走查 + 键查找（eq(first(first(…)))）全数维持 if——谓词与键查找非分派表（M30/§12.2-2/§12.2-6 同源） | N/A（维持面） | 维持 | 分派表面 = 多臂 tag 字面表；谓词级联与键查找的臂化 = 语义重组非恒等变换（越 §3.4 边界） |

### 13.2 边界勘定（刀 5——不迁移面及理由）

1. **遮蔽族两份共变纪律（本刀最重要边界）**：22 共享名（§13.1 M47 实测清单）任何现代化变更必须同施 macro.ktf 与 expander.ktf 两件且逐字节恒等；expander.ktf 独有名（ex_8 等）单件变更合法；macro.ktf 独有名（ex_is_name 族等）刀 4 已现代化——零触碰。共变后 `diff` 恒等体机检 = b-MUV 验收位。
2. **守卫级联维持**（M48 + §12.2-2 同源）：ex_variant_face / ex_struct_face / ex_pv_assemble / ex_ps_assemble 的谓词嵌套链、ex_extern_walk 的 string/is_list 混合面、ex_declare 的 module 单 tag 守卫、ex_visit 的 done 单 tag 守卫维持 if。
3. **单比较不分派**（§12.2-6 同源）：ex_define_collect "define" / ex_extern_collect "extern" / ex_skip "list" / ex_spec_value "svfold" / ex_datum_lit "dfold" / ex_decl 外层 "decls" / ABI "string" 检查（ex_extern 内）+ require 的 mt "string" 检查（ex_decl 内）/ ex_cycle_path 边等值检查 / ex_enum_chains_find·ex_variant_info_find·ex_struct_field_find·ex_struct_acc_name·ex_enum_ctor_row 的键查找全数维持 if。
4. **do/set 突变序列不动**（§12.2-3 同源）：ex_frames 进出栈、ex_err 首错记录、ex_depth 增减、ex_colors/ex_dstack/ex_inmod 的装载器状态更新、ex_pending/ex_danns 累积 = 语义载体，臂体仅承载原分支体。
5. **导出面冻结清单（刀 5 位）**：expander.ktf = `result` 全局 + `items` 自由引用 + `ex_limit` 消费（装配前缀 define——assembled_expander_target_source 单源）+ ex_run 入口——ex_* 全族内部名维持（纯体内变换零改名）；macro.ktf = 刀 4 冻结清单维持 + 遮蔽族 22 名（名字/参数序/恒等体逐位）——两件与 harness 消费面零改动通过。
6. **零新顶层名**：无 struct/enum 声明（展开器全记录面 = 运行时构造的标签联合列表——§9.4-1 标签记录全窗保持 cons 边界；分派 + 注解纯变换）→ 名称冲突扫描平凡通过。
7. **组合落位不变**：装配序 macro.ktf → expander.ktf（MX-2）+ `define(ex_limit, N);` 前缀 + `define(forms, quote((…)))` 注入序零改动（include_str! 编译期拾取新源）。
8. **回退预案（parity 触发）**：三大链（M41/M42/M43）任一现 parity 发散 → 回退该链原始 if 形、保表类件（M44/M45 + M46/M47）——parity 族当轮立捕定位（变体隔离法——刀 1 先例）；注解面 E0013 红 → 回退该位为裸名（r175 M12 先例）；遮蔽族恒等体 diff 红 → 单侧多施/漏施位点当轮对齐。
9. **臂体块强制实勘条款预载**（r177 实勘 §11.2-11 + r175 勘定①②全文适用）：每臂体经 parse_block 包裹 `{ }` + 尾逗号；末臂 `_` 收尾；臂序保持原链序（first-match 同构）；列宽 ≤ 100（selfhost_format_guard 实测面——加宽行纯空白 reflow）。
10. **tamper 针清查条款**：expander.ktf / macro.ktf 源形态钉扎针零命中（侦察 @ r179：源形态断言面 = infer.ktf〔E00/tdef——刀 6 对象〕+ typecheck.ktf + opcode.rs；banned-token 守卫与本刀变换面零交集）——tests/ 树预期零共变；若 parity 族内嵌针失配（r178 wmj/wsi 型）→ 针文本随源形态共变 + worklog 披露。

### 13.3 b-MUV 对账义务（刀 5）

实施位点逐条回填：expander.ktf = M41（ex_expand 外层九合成臂 + 守卫 `_`）+ M42（ex_expand 内层表达式头十臂）+ M43（ex_decl 声明头八臂）+ M44（ex_edges）+ M45（ex_extern_type_tag）+ M46（注解族 ~45 位）；macro.ktf = M47 遮蔽族共变（22 名恒等体 + M45 ex_gen match 化 + M46 注解位同施）；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行。验收门（§6 刀 5 行原文）：**全 parity sweep 族绿**（subset_corpus 173 + parity_contract + twin 族全量 + pkg_window 8）**+ fixpoint 三阶段**（fixpoint_tests 9 + target_fixpoint_tests 8——B≡C 位级）**+ T2 全量新鲜全绿**（§3.2.1 长套件纪律）+ 关联族（expand_segment_switch 9 + steady_expander_chain 9 + steady_target_reader + selfhost_format_guard 3 + 遮蔽族 diff 恒等体机检）+ oracle 零改动（git diff crates/ 零文件）。

## 14. 刀 6 映射表（a-MUV 裁定 @ r180——infer.ktf W 机分派臂 + target-parser.ktf 帧机状态收官件）

> 依据：§3.4（现代化 = 纯源面变换语义恒等 oracle 零改动）+ §6 刀 6 行（W 机分派臂 + 帧机状态 → 表面化收官；同上 + 窗口 CLOSED 判据六条）+ 刀 1-5 映射表先例（§9 M1-M12 / §10 M13-M20 / §11 M21-M30 / §12 M31-M40 / §13 M41-M48）+ r175/r177/r178 勘定族预载（臂尾逗号 / 末臂穷尽律 / 臂序 / 臂体块强制 / tamper 针共变）。本刀对象 = 收官双件（合计 8,873 行）：infer.ktf（4,471——迭代 W 机〔显式任务栈 + 事务性 unify + undo log〕+ 解析/occurs/注解 walk 族 + Tarjan SCC 机）+ target-parser.ktf（4,402——帧栈机〔34 状态 + give 归约 + leave 守卫〕+ 相位机族 + token/datum 表）。

### 14.1 表示恒等条款（刀 6 新增——W 机分派臂 + 帧机状态 + 注解面）

| # | 表面构造 | oracle 脱糖产物（compile_pattern/expand 锚） | 被替换旧形（孪生内） | 恒等依据 |
|---|---|---|---|---|
| M49 | **标量 tag 表（判定面）**：ti_child_count 22 臂 / ti_lit_convert 6 臂（is_nil 前置守卫维持）/ ti_assemble 22 臂（12 直通坍缩 + 10 重组——副作用 do 序列臂内合法〔tc_collect M23 先例〕）/ ti_collect_info 3 臂 / ti_ann_walk tag 层 9 臂（tvar/tlit/tfn/tapply/tif/tassign/tlet/…）/ ti_collect_walk tag 层 7 臂 / ti_var_walk tag 层 8 臂 / ti_lit_walk 5 臂——`match tag { "…" => {…}, …, _ => {…} }`，tag 经 `let tag = first(rec)` 单评 | Str pattern → eq? 字面测试链（compile_pattern 单源——M21 同型） | `let tag = first(…); if eq(tag, …)` else-if 链 | tag 与臂域词法分离（tag 值域 = 记录头串；`_` 接收域 = 原末 else 域全称——首匹配同构）；scrutinee 单评（first 纯访问器——M21 先例）；臂体 +4 缩进迁移（纯空白变更） |
| M50 | **W 机核心双层（本刀最重要表面）**：ti_unify_step——外层 `match a { "dyn" => { rest_work }, "int"/"float"/"bool"/"str" => { ti_unify_ground(…) }, "nil" => { if ti_empty_struct(b) … }, _ => { <记录域> } }`：`_` 臂内 ti_is_var(a)/ti_is_var(b)/eq(b,"dyn") 守卫级联**维持 if 形**（原链序逐位保持——var 域在字面域之前判定，`_` 臂体 = 原链 var 两臂 + 记录 else 域同体合并 M25 型）；内层 `match first(a) { "struct" => {…}, "enum" => {…}, "pair" => {…}, "fn" => {…}, _ => { mis } }`（原 not(is_pair(b)) 守卫臂折入 pair/fn 臂内前置 `if not(is_pair(b))`——接收域逐位一致）；"struct" 臂内 eq(b,"nil") 单比较维持 + is_pair(b) 域内 `match first(b)` 三臂子层（struct/pair/`_` mis——M25 is_pair 守卫内化同型）；ti_unify_ground/bind_var/pair/push_params/arrow 单臂族维持；ti_unify_worklist/ti_unify 入口维持 | 同 M49 | ti_unify_step 双层 45 行 if-eq 链（1760-1894——a 字面域 + var 谓词 + tag 记录域 + btag 子层） | a 的字面域（"dyn"/"int"/"float"/"bool"/"str"/"nil"）与记录域（var/struct/enum/pair/fn——is_var/first 判定）互斥不交叠；`_` 臂携带 var 守卫 = 原链「字面域后 var 域」接收域逐位一致（var 记录永非字面串——域分离 M34 同源论证）；btag 子层在 is_pair(b) 域内 = 非 pair 落 `_` 与原 else 合并 |
| M51 | **walk 模式机**：ti_resolve_walk / ti_occurs_walk（mode "one"/params 二态）/ ti_ann_walk（mode node/nodes/binds/clauses 四态）/ ti_collect_walk / ti_var_walk / ti_varocc_walk / ti_subst_walk——`match mode { "one" => {…}, _ => { <params 域> } }`（末态落 `_` 收尾——M22 四态同型；tag 层另经 M49 化）；ti_lit_walk v/depth 维持 | 同 M22 | `if eq(mode, …)` 二态/四态链 | mode 值域封闭（调用点全字面串——单源直读）；`_` 接收域 = 原末 else 域全称；递归互调（resolve/params 互递归）臂体原样 |
| M52 | **规格解析机**：ti_resolve_spec 8 臂——`match mode { "spec" => {…}, "tuple" => {…}, "arrow" => {…}, "arrow-params" => {…}, "params-map" => {…}, "app" => {…}, "struct-name" => {…}, "struct-body" => {…}, _ => { "dyn" } }`（原末 else = "dyn"——`_` 保形）；内层 first(elems) 三臂 + `_`→"dyn"（spec/arrow-params 两处；"arrow-params" 内 "Fn" 单比较维持）；ti_spec_scalar/ti_spec_elems 维持 | 同 M49 | `if eq(mode, …)` 8 臂链 + first(elems) 三臂子层 | 同 M51；"app" 臂内 first(x)="Pair" 单比较维持（单比较不分派——M65 同源） |
| M53 | **类型等价机**：ti_type_eq mode 二态（"one"/`_` params）+ tag 三臂 `match tag { "var" => { eq(ti_2(a), ti_2(b)) }, "pair" => {…}, "fn" => {…}, _ => { false } }`——is_pair(a)/is_pair(b) 前置守卫**维持 if**（a/b 可为裸串 "dyn"/"int"——M25 混合域同型：非 pair 落 false 与原 else 合并） | 同 M49 | `if eq(mode, …)` + tag 三臂链 | eq(a,b) 快道前置维持；tag 值域 = 记录头；裸串域落 is_pair 守卫 else——接收域逐位一致 |
| M54 | **任务机**：ti_enter 九臂（lit/var/fn/apply/if/let/assign/perform/handle）`match first(node) { …, _ => { nil } }`；ti_dispatch 十臂（enter/ifcond/ifthen/ifelse/apply/fnbody/letstep/assign/perform/handle）`match first(task) { …, _ => { nil } }`；ti_machine_run 循环维持 | 同 M42/M43 头分派 | `let tag = first(node); if eq(tag, …)` 九/十臂链 | 头分派与 M42 同型（node 头词法域封闭——CP-1 平面记录流）；`_` = 原末 else nil 域全称 |
| M55 | **名字表**：ti_is_builtin / ti_is_external——`match name { "+" => { true }, …, _ => { false } }`（单行臂族——串字面臂 M21 同型）；ti_builtin_type 按实测（name 语义群组表——若为群组字面臂则 match 化，混合谓词则维持）；ti_is_numeric 混合守卫维持（t 记录/裸串混合面——is_pair 前置 + 字面子层按实测） | 同 M49 | `if eq(name, "+") { true }` 单行链 | name 值域 = 调用点字面串族（闭集——单源直读）；`_` = 原末 else false |
| M56 | **环机/计数循环维持**：ti_tarjan_step mode 二态（roots/loop——`_` loop 域）字面臂化；ti_min_at/ti_tarjan_emit/ti_tarjan/ti_one_edge_row/ti_edges/ti_tdef_loop/ti_scc_of_loop/ti_scc_loop/ti_knot_loop/ti_members_loop/ti_prebind/ti_run_define/ti_schema_for = i64 计数循环 + is_nil 走查（非 tag 分派）全数维持 if | N/A（维持面） | 维持 | 分派表面 = 多臂 tag 字面表；计数循环与走查的臂化 = 语义重组非恒等变换（§12.2-6 同源） |
| M57 | **infer 注解族（~45 函数位）**：返回注解 ti_is_var/ti_is_builtin/ti_is_external/ti_is_struct/ti_is_enum/ti_empty_struct/ti_occurs_walk/ti_type_eq/ti_is_numeric/… -> bool + ti_len/ti_follow hops/ti_slot/ti_occurs/ti_index_of/ti_take_n/ti_drop/ti_min_at/ti_fresh_list/… -> i64；参数注解——名字域 name: str（ti_member/ti_lookup 族/ti_is_builtin/ti_report code/sev: str）/ 索引·计数·深度域 i/j/n/acc/idx/depth/pos/hops/limit: i64 / span 域 s/e: str（ti_report 同 M26 tc_report 族——十进制串域）；**混合返回诚实不注解**：ti_lookup（类型或 "dyn" 串）/ ti_resolve_spec（记录或串）/ ti_spec_scalar（串或 nil）/ 记录访问器 ti_2..ti_9 / ti_pop_result（记录或 nil）→ 返回不注解；树/列表参数裸名（M12 诚实降级） | dann 记录 → resolve_spec 标量表（i64→Int, bool→Bool, str→Str——M26 同族） | 裸参数名 | 检查期-only 零运行时载荷（M10）；注解与实况一致；span 十进制串域单源（M26 tc_report 头注释同族） |
| M58 | **（infer 边界——见 14.2）** | N/A | N/A | N/A |
| M59 | **帧机主分派（本刀第二大表面）**：tp_step 33 字面臂 + `_ => { tp_step_generic_args(f) }`（原末 else 保形——未知模式同落 generic-args，接收域全称）；tp_give 29 字面臂 + `_ => { <machine-drop 缺陷臂> }`（原 else 保形——pair("done", pair(pair("machine-drop", pair(mode, nil)), nil))；mode 参数仍 let 绑定——臂体引用 mode〔M42 h 同型：let 单评保留〕）；tp_dispatch_item 10 字面臂 + `_ => { tp_push(pair("expr-stmt", pair(nil, nil))) }`（ident 臂内 tp_bytes_eq require 字节串检查维持——r109 F5 拒绝面） | 同 M49 | `let mode/kind = first(f/g/t); if eq(mode/kind, …)` 33/29/10 臂链 | mode/kind 值域 = 帧构造点字面串族（全库单源直读——tp_push/tp_replace 调用点闭集）；`_` 接收域 = 原末 else 域全称；scrutinee let 单评保留（tp_give 臂体引用 mode——缺陷臂载荷） |
| M60 | **相位机族**：tp_step_fn_decl（fresh/params/…）/ tp_step_params / tp_step_extern_decl / tp_step_extern_item / tp_step_let_stmt / tp_step_type_drop（相位层 + kind 层双层）/ tp_step_struct_decl/enum_decl/variant/use_decl/macro_decl/block/… 按实测相位层；tp_give_fn_decl（params/annot + `_` 定义体臂）/ tp_give_let_stmt（annot + `_`）/ tp_give_handle_arms（相位四臂）/ tp_give_type_drop（相位五臂）/ tp_ha/tp_ma（phase 头部）——`match phase { "…" => {…}, _ => { <原 else> } }` | 同 M51 相位同型 | `let phase = tp_2(f/g); if eq(phase, …)` 链 | phase 值域 = tp_replace/tp_push 构造点字面族（闭集）；`_` = 原 else 保形（单相位 else = 定义体/缺陷臂——接收域全称） |
| M61 | **token/datum 表**：tp_step_primary 27 臂 / tp_kind_name 9 臂 / tp_datum_word 23 臂 / tp_is_word 23 臂 / tp_datum_op 12 臂 / tp_is_datum_op 12 臂 / tp_cmp_kind 5 臂 / tp_step_postfix 5 臂 / tp_step_pattern 7 臂 / tp_cmp_reduce 5 臂——`match kind { "…" => {…}, _ => {…} }`；tp_step_datum 混合守卫（kind 谓词链 + 字面臂——按实测：字面子层臂化 + 谓词前置维持）；**tp_bin_ops 层表**：`match level { 0 => {…}, 1 => {…}, 3 => {…}, 4 => {…}, 5 => {…}, 6 => {…}, 7 => {…}, _ => { <level-8 体> } }`（level 整型臂——M27 tl_op 同型；level==8 落 `_` 保形） | 同 M27（整型臂顶层分派首例复用） | `if eq(kind, …)` / `if level == N` 链 | kind 值域 = tk_kind 产生器闭集（tp_lexer 单源）；level 值域 = 调用点字面整数族；`_` 接收域 = 原末 else 域全称（is_word/is_datum_op 谓词对族 = word/op 表同域双件——diff 恒等体机检候选） |
| M62 | **算符归约/绑定守卫维持**：tp_bin_reduce/tp_cmp_reduce/tp_unary_reduce/tp_unary_fold/tp_binding_spec/tp_binding_pairs/tp_last_pair/tp_ha/tp_ma 的谓词与序列走查全数维持 if（单层归约 + 列表走查非分派表——§12.2-6 同源）；tp_bytes_eq/tp_form_go/tp_give_params 等维持 | N/A（维持面） | 维持 | 同 M56 论证 |
| M63 | **离开守卫**：tp_leave_g 16 臂字面化——`match mode { "items" => {…}, …, _ => {…} }`（原 else 保形）；tp_finish/tp_pop_finish/tp_push_guarded/tp_bump/tp_replace/tp_at/tp_expect 维持 | 同 M49 | `if eq(mode, …)` 16 臂链 | mode 值域 = 帧模式闭集（与 M59 同域）；`_` = 原 else 域 |
| M64 | **parser 注解族（~45 函数位）**：参数注解——byte/pos/depth/level/phase 计数域 i64（tp_bytes_eq a: i64 / tp_bin_ops level: i64 / tk_s/tk_e: str）/ kind/mode/phase: str（tp_at kind: str / tp_step f 裸〔记录〕）/ span 域 s/e: str；返回注解——tp_at/tp_at2/tp_is_word/tp_is_datum_op/tp_bytes_eq -> bool + tp_count_len/tp_bin_ops -> bool + tp_kind_name 按实测（str 返回或 nil——混合面诚实不注解）；**混合返回诚实不注解**：tp_peek（token 记录）/ tp_form（表值或 nil）/ tk_kind/tk_s（访问器裸名） | 同 M57 dann 同族 | 裸参数名 | 同 M57 |
| M65 | **（parser 边界——见 14.2）** | N/A | N/A | N/A |

### 14.2 边界勘定（刀 6——不迁移面及理由）

1. **W 机守卫级联维持（M50 核心边界）**：ti_unify_step 的 var 域（ti_is_var(a)/ti_is_var(b)）与 b 侧检查（eq(b,"dyn")）维持 if 形于 `_` 臂内——原链序逐位保持（字面域 → var 域 → 记录域）；btag not(is_pair(b)) 守卫折入 pair/fn 臂内前置（原「enum 后 pair 前」位次语义 = pair/fn 臂体首检查——接收域一致）；ti_unify_ground/bind_var/pair/push_params/arrow 单臂族维持。
2. **ti_2..ti_9 / tp_2..tp_9 裸名维持**（CP-1 平面异构变长记录零 struct 声明——M49-M59 全表不引入记录声明）；**do/set 突变序列不动**（§12.2-3）：ti_rollback/ti_mark/ti_push_result/ti_push_task/ti_env_truncate/undo log 语义载体；tp_bump/tp_replace/tp_push/tp_stack 突变全数维持。
3. **单比较不分派**（§12.2-6）：ti_lookup 族 is_nil 级联 / eq(b,"nil") / "Fn" 检查 / first(x)="Pair" / ti_type_eq 的 eq(a,b) 快道；tp_at("eof") 检查族 / tp_bytes_eq require 检查 / tp_any_list_rec 全数维持 if。
4. **谓词守卫维持**（M30 同源）：ti_is_var/ti_empty_struct/ti_is_struct/ti_is_enum/ti_is_numeric 混合面；tp_is_word/tp_is_datum_op 若实测为谓词对族（word/op 同域）→ 与表件同施双件（M61 候选）。
5. **导出面冻结（刀 6 位）**：infer.ktf = `result` 全局 + `items` 自由引用（INJ-1 通道 define(items, quote(...)) 注入序零改动）+ ti_run 入口——ti_* 全族内部名维持（纯体内变换零改名）；target-parser.ktf = `tp_run_result`/`tp_verdict`/`result` 三 define + `tp_forms`/`tp_done`/`tp_err`/`tp_stack` 全局 + tp_run 入口——tp_* 全族内部名维持；两件与 harness 消费面（include_str! 编译期拾取 + 装配序）零改动通过。
6. **零新顶层名**：无 struct/enum 声明（两件全记录面——运行时构造标签列表保持 cons，§9.4-1）→ 名称冲突扫描平凡通过；零改名（M5 纪律）。
7. **组合落位不变**：装配序 infer.ktf / target-parser.ktf 各自独立段（无 MX-2 型遮蔽——两件零共享名族〔ti_/tp_ 前缀分离〕）；include_str! 拾取新源 = 编译期自动。
8. **回退预案（parity 触发）**：任一链现 parity 发散 → 回退该链原始 if 形、保表类件——parity 族当轮立捕定位（变体隔离法——刀 1 先例）；注解面 E0013 红 → 回退该位裸名（r175 M12 先例）；format 守卫红 → 纯空白 reflow 收敛（r179 38 行同型）。
9. **实勘条款预载**（r175 勘定①② + r177 §11.2-11 + r178/r179 tamper 条款全文适用）：臂体经 parse_block 包裹 + 尾逗号；末臂 `_` 收尾（末臂穷尽律——字面臂对不可收尾）；臂序保持原链序（first-match 同构）；列宽 ≤ 100（selfhost_format_guard 三不变量——em-dash/§ 白名单 + 无 ASCII 括号破折号）。
10. **tamper 针清查条款（r179 侦察兑现）**：infer.ktf〔E00/tdef〕与 target-parser.ktf 源形态钉扎针机检零命中（本轮实测：tests/ + examples/ 全树扫描 twin 源文本零嵌入；E00/tdef 针 = hm_twin_face E00 判定文本面 + stage0_gate_audit AN01 tdef 行文本面——**输出面断言非源形态钉扎**，表示恒等手术下恒绿）；banned-token 守卫（.krf/skin_transcoder/StxToken/sexp_corpus_migration/ReaderFace::Sexp）与变换面零交集机检维持；若 parity/audit 族内嵌针失配（r178 wmj/wsi 型）→ 针文本随源形态共变 + worklog 披露。
11. **遮蔽族 N/A 声明**：本刀无 MX-2 型遮蔽（infer/target-parser 零共享名族）；刀 5 已共变的 macro.ktf/expander.ktf 22 名恒等体**零触碰**（本刀非其载体）。

### 14.3 b-MUV 对账义务（刀 6）

实施位点逐条回填：infer.ktf = M49（tag 表八函数）+ M50（ti_unify_step 双层）+ M51（walk 模式机族）+ M52（ti_resolve_spec 8 臂）+ M53（ti_type_eq）+ M54（ti_enter/ti_dispatch）+ M55（名字表）+ M57（注解族 ~45 位）；target-parser.ktf = M59（tp_step/tp_give/tp_dispatch_item）+ M60（相位机族）+ M61（token/datum 表 + tp_bin_ops 整型臂）+ M63（tp_leave_g）+ M64（注解族 ~45 位）；对账产物 = c-MUV 的 RELEASE_NOTES 条目 + 台账改账行。验收门（§6 刀 6 行原文）：**同上〔全 parity sweep + fixpoint 三阶段〕+ 窗口 CLOSED 判据六条**——全 parity sweep（subset_corpus 173 + parity_contract 15 + segment switch 四族 9/10/9/11 + steady 双链 9+7 + twin 族全量〔hm_twin_face 4 + hm_twin_chain 6 + target_parser_twin + typecheck_twin_sweep 6 + read/check segment + superinstr 16 + method_jit 21 + pkg_window 8 + format_guard 3〕）+ fixpoint_tests 9 + target_fixpoint_tests 8（B≡C 位级）+ oracle 零改动（git diff crates/ 零文件）。


### 14.4 实施位点回填（b-MUV 对账 @ r180——§14.3 义务清偿）

实施位点逐条：infer.ktf = M49（ti_child_count 22 臂 / ti_lit_convert 6 臂〔is_nil 前置守卫维持〕/ ti_assemble 22 臂 / ti_collect_info 3 臂 / ti_ann_walk tag 层 9 臂 / ti_collect_walk tag 层 7 臂 / ti_var_walk tag 层 8 臂 / ti_lit_walk 5 臂）+ M50（ti_unify_step 手术：外层四守卫〔eq(a,"dyn")/eq(b,"dyn")/is_var(a)/is_var(b)〕维持 if——**b=="dyn" 先序语义保形**；字面域 match a 六臂 + `_` 记录域嵌套 match first(a)〔struct/enum/pair/fn/_〕；not(is_pair(b)) 守卫折入 pair/fn 臂首检查〔r127 崩溃面守卫原位〕；btag 子层 match first(b) 三处〔is_pair(b) 前置维持〕；GZ-2/GZ-3/GZ-4 注释逐字原位）+ M51（六 walk 模式机 one/params + 等价性 tag 三臂〔is_pair 守卫维持〕）+ M52（八模表 + spec/arrow-params 两处内层 first(elems) 三臂手手术——is_nil(elems) 守卫维持 + "Fn" 单比较维持 + "Pair" 单比较维持）+ M53（ti_type_eq 模式层 + tag 三臂〔is_pair 守卫维持〕）+ M54（ti_enter 九臂 + ti_dispatch 十臂——let tag 摘除 match first(node/task)）+ M55（ti_is_builtin 18 名表单行臂 + ti_builtin_type 18 臂——**ti_is_numeric 混合面手手术**：is_var 前置 + 字面域 match 三臂 + `_` false〔混合返回 true/false/nil 诚实不注解〕）+ 计划外正当转换四件：ti_struct_collect/ti_enum_collect（2 臂 + else 表）+ ti_ann_collect（define/module/extern 头表）+ ti_r4_owns（2 臂）+ ti_schema_for（fnlit/lit/`_` 表）——generic ≥2 规则捕获；维持面 21 处（键查找/单比较/谓词级联/计数循环——M56/M58 边界）；target-parser.ktf = M59（tp_step 33 臂 + `_`→generic-args 保形 + tp_give 29 臂 + `_`→machine-drop 保形〔mode 参数 let 维持——缺陷臂载荷引用〕+ tp_dispatch_item 10 臂〔ident 臂内 require 字节串检查维持〕）+ M60（守护相位机族 12 件手手术式机械转换——is_nil(phase) 守卫维持 + else 内 match：tp_step_closure〔arrow0/arrow/want-block〕/ tp_step_handle_arms〔open/arms/params?/arrow〕/ tp_step_match_arms〔open/arms/arrow/want-body〕/ tp_step_if_expr〔want-then/wait-else〕/ tp_step_perform〔open/want-arg〕/ tp_step_bin/cmp〔op-check〕/ tp_step_postfix〔loop〕/ tp_give_postfix〔wait-call〕/ tp_step_macro_decl〔body〕/ tp_step_type_parens〔body/elem〕/ tp_step_generic_args〔body/elem〕/ tp_step_items〔braced-ext/braced——ctx 守卫〕）+ M61（tp_step_primary 27 臂 / tp_kind_name 9 / tp_datum_word 23 / tp_is_word 23 / tp_datum_op 12 / tp_is_datum_op 12 / tp_cmp_kind 5 / tp_step_pattern 7 / tp_step_postfix 5 + **tp_step_datum 手手术**：六字面臂 + minus 臂内 match tk_kind(next)〔int/float/`_`〕+ open-paren 臂原位 + `_` 携 is_word/is_datum_op 谓词级联〔语义序保持——谓词域与字面域不相交〕）+ M62（tp_bin_ops level 整型臂 0/1/3/4/5/6/7 + `_`→level-8 体〔臂内 kind 单比较维持〕；tp_bin_reduce/tp_cmp_reduce/tp_unary_reduce/tp_unary_fold/binding 族维持）+ M63（tp_leave_g 16 臂 + `_`）+ 注解族 M57/M64（infer ~76 位 / parser ~29 位——span 域 str〔M26 十进制串域族：记录流 node 的 s/e 字段为 str，checker 全量复核通过〕与局部位置域 i64〔pos/j/idx 等〕分离注解；**诚实裸名勘正清单**：tp_ha/tp_ma 全参数〔nil 占位域〕+ ti_member/ti_row_push name〔名/位混合域〕+ ti_rposition/callee best〔nil-or-i64〕——三组经 checker 立捕后当轮回退）；对账产物 = RELEASE_NOTES v0.131.0 条目 + 台账 v1.8 改账行。
# Stage 1.x — 测试分层守卫文档（test-tiers.md）

> **Status**: Delivered（W-TEST-FLOW r167 落档）
> 依据：docs/sop.md §9.2（测试文档先行）+ §9.4.3 v15.1（易错分布全覆盖 + 分布论证义务）+ §8.4.6 v11.2（runner 单入口挂载）+ 用户 r167 指令（自举阶段测试流程优化先行）+ docs/develop/v3/w-test-flow-window.md §3-§4（设计单源）
> 消费面：tests/v1/stage1/plan/test_tier_guard_tests.rs（经 tests/runner.rs `#[path]` 挂载）+ scripts/testing/tiers.tsv（被守卫对象）+ scripts/testing/test-tiers.sh（被守卫对象）

## 1. 功能点（FP = 守卫案）

| FP | 守卫名 | 不变量类 | 断言形态 |
|----|--------|---------|---------|
| FP1 | `tier_table_matches_runner_mounts_exactly` | 库存双向零漂移（test_infra_guard TEST-1 同族——表格面 ↔ 挂载面） | runner.rs 全部 `mod` 族名（`common` 豁免）与 tiers.tsv 实族行**双向零孤儿零幻影零重复**；虚拟行恰为 {libs, doc, audit} 三件 |
| FP2 | `tier_fields_are_sound_and_slow_families_pinned` | 字段健全 + GATE 完整性（慢族钉扎） | 层级标签 ∈ {T0,T1,T2}；timeout 为正整数；八个已知慢自应用族（fixpoint/target_fixpoint/target_parser_twin/abc_pipeline/四 segment switch）**恒 T2 且 timeout ≥ 300s**；T0 族数 ≥ 5（防烟测层被掏空） |
| FP3 | `tier_engine_script_is_wellformed` | 引擎自检（lit `--no-execute` 类比——验证执行器本身） | `bash -n` 静态解析 exit 0；脚本携带必需表面标记（cmd_run/cmd_list/cmd_status/--resume/--force/--max-time/collision_skips/--skip/RUST_MIN_STACK/ledger.prev.tsv/durations.tsv） |

## 2. 易错分布论证（§9.4.3 v15.1——分布依据申报）

被测面 = **测试调度配置**（tiers.tsv）+ **批次引擎**（test-tiers.sh），非编译器管线。错误密度集中于三类历史高发位：

1. **库存漂移**（新增测试文件忘挂 runner.rs / 表格忘记行——test_infra_guard TEST-1 先例族）：FP1 双向覆盖（表格漏行 = 孤儿；幻影行 = 命名漂移）。
2. **静默降级**（慢族被移入快层 = 烟测层冒充全量门——GATE 完整性违例）：FP2 钉扎面覆盖（八慢族白名单 + T0 非空下限）。
3. **引擎漂移**（脚本重构丢失续跑/碰撞跳过/栈适应等关键面）：FP3 标记面 + 语法面覆盖。

负向覆盖说明：守卫族本身即负向执行面（任一漂移出现即红）——三案各盯一类错误面，构成对配置/引擎面的全覆盖判定；无正向「happy path」案（守卫无此形态——§9.4.3 允许纯负向审计族沿负向主体惯例，0.10 门审先例）。

## 3. 计数与覆盖

- 本族 3 案（全负向守卫面）；经 `cargo test --release --test runner test_tier_guard_tests` 选择性执行。
- 依赖：零新 Cargo 依赖（纯 `std::fs` 读取 + `std::process::Command::new("bash").arg("-n")` 静态解析——bash 为仓库脚本既有环境先验，非管线执行）。
- 与 test_infra_guard_tests 的边界：test_infra 守**测试树**（挂载/语料表/审计库存）；本族守**调度配置与引擎**（分层表/超时/钉扎/脚本健全）。互补零重叠。

## 4. 变更纪律

- tiers.tsv 新增族行 = 同步本档 FP1 语义（双向守卫自动执法，无需改档）；**慢族钉扎白名单**变更（FP2）须附 worklog 理由（裁定级变更）。
- 引擎脚本表面标记变更（FP3）同上——标记清单即脚本公共契约。

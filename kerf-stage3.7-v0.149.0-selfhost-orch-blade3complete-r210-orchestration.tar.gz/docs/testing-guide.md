# 测试指南（testing-guide.md）

> 依据：docs/sop.md §8.4.6（两级测试语义）/ §9.1-§9.5（结构/矩阵/比例）/ §9.7（条例格式）/ §3.2（交付前验收）/ §19.3（打包前测试先行）；分层执行条例 = W-TEST-FLOW r167 落档（用户显式指令「先对自举阶段的测试流程进行优化」驱动；设计单源 docs/develop/v3/w-test-flow-window.md）。

## 三层测试架构（两级语义）

| 层 | 位置 | 验证对象 | 发现入口 |
|----|------|---------|---------|
| 单元 | crate `src/**` 内联 `#[cfg(test)]` | 内部行为 | cargo 自动 |
| crate API | `crates/<name>/tests/*.rs` | 本 crate 公共 API（禁止跨 crate 断言——P1 结构违规） | cargo 自动 |
| 跨 crate 集成 | 根 `tests/v0/stage-N/{plan,gate}/*.rs` | 流水线/集成/阶段门审计 | **仅** `tests/runner.rs` 单入口 `#[path]` 挂载（§8.4.6 v11.2——零 `[[test]]` 声明） |

- 新增集成测试 = runner.rs 加一行 `#[path]` mod + 新建文件 + **tiers.tsv 加一行**（分层表守卫 FP1 双向执法）。
- 共享辅助入 `tests/common/mod.rs`（相对 `#[path]` 挂载，以测试文件自身目录为基准）。
- 每个测试代码文件必须有 docs/tests/ 双生文档（目标/场景/计数/覆盖率——§9.2 规则 2）。

## 硬性纪律

1. **易错分布全覆盖判定**（§9.4.3 v15.1——2026-09-28 重构）：全覆盖义务（每功能点 ≥1 正向 + 负向覆盖全部已点亮错误类）+ 易错分布驱动（用例数量按被测面错误密度分配）+ 分布论证义务（测试计划声明分布依据，无论证 = NEEDS REVISION）；凑数禁止（§12）。历史口径 1:3+（v10.0-v15.0）废止——旧偏差申报实践（0.7/0.8/0.9-0.10）自此制度化为常态分布论证。
2. **七类错误矩阵**（§7.1.1）：随管线子阶段逐类点亮（0.3 语法/空应用 → 0.4 未绑定/宏深度 → 0.6 参数/类型 → 0.9 循环依赖）；0.11 门审 7/7。
3. **测试先文档**（§17 Step 5 + §9.4）：子阶段开工前先写 docs/tests/v0/stage0/plan/<x>.md。
4. **阶段门审计集**（§7.3.1）：≥30 case，构成按被审面分布申报（纯错误审计沿负向主体惯例；合同/witness 审计轮按合同面分布——0.10 K/L 节先例），入 `examples/audit/stage<N>_gate_audit_r<R>.rs`，可重跑、逐轮不减。

## 测试分层执行条例（W-TEST-FLOW r167）

### 分层模型（GHC validate / LLVM lit / Go `-short` 先例族——窗口档 §3）

| 层 | 语义 | 内容 | 预算 | 使用时机 |
|----|------|------|------|---------|
| **T0 smoke** | 快反馈 | 全部守卫族 + 种子族 + 语料隔离表 + pkg 孪生（tiers.tsv `T0` 行） | ≤ 120s | §5 内循环每 MUV 后 |
| **T1 round** | 轮内门 | T0 + 标准集成面（种子/扫描/孪生中速族）+ `libs`（workspace --lib） | 分钟级 | 常规轮 commit 前（§5.3 八项自查配套） |
| **T2 full** | 全量门 | 全部族 + `doc`（doc tests）+ `audit`（门审计例程 460 live + 124 retired） | ~30 min 级 | 大阶段末轮 / §19 打包前（**恒新鲜全量**） |

**GATE 完整性不变量（宪法级）**：分层只改变测试**何时/如何**运行，永不改变**必须通过什么**。T2 = SOP §3.2 `cargo test --release` 测试面 + 审计例程的**逐位等价**；打包前验收（§19.3）恒以 `run --tier T2 --force` 新鲜全量执行——**续跑台账永不替代打包门**。

### 执行入口（scripts/testing/test-tiers.sh）

**执行模式（环境强制裁定——窗口档 §3.4）**：本沙箱在工具调用返回后收割全部子进程（nohup 与 setsid 均不可存活——r167 实测）。因此**后台轮询模式禁止**；唯一合法长套件模式 = **分块前台**：重复 `run --resume --max-time <预算>` 调用，每块落在单次工具调用超时窗（≤10 min）内，进度由台账承载。冷构建超出单窗时逐 crate 预热（`cargo build --release -p <crate>`——cargo 按 crate 缓存）或 `--build-only` 独立成块。

```bash
# 列出某层选族
scripts/testing/test-tiers.sh list --tier T0
# 内循环：烟测层（前台，秒级，单窗内完成）
scripts/testing/test-tiers.sh run --tier T0
# 轮内门：标准层（分块前台——每块 ≤ 9 min，重复至 SUMMARY 全绿）
scripts/testing/test-tiers.sh run --tier T1 --resume --max-time 480
scripts/testing/test-tiers.sh run --tier T1 --resume --max-time 480   # …直至 green=N red=0
# 全量门：打包前新鲜全量（恒 --force；同样分块前台）
scripts/testing/test-tiers.sh run --tier T2 --force --max-time 480
scripts/testing/test-tiers.sh run --tier T2 --resume --max-time 480   # …续块
scripts/testing/test-tiers.sh status   # 台账指纹 + 逐族状态
```

### 批次引擎机制（nextest build-once / lit smart-order 先例族）

- **build-once-run-many**：批次先 `cargo test --release --no-run --all-targets` 一次编译，随后逐族复用缓存二进制（消除逐族重编开销）。
- **指纹失效**（保守缓存——Go 语义的保守子集）：指纹 = runner 二进制 sha16 + git HEAD + RUST_MIN_STACK + tiers.tsv sha16。指纹变化 → 台账自动归档（`ledger.prev.tsv`）重开。**续跑仅在指纹不变时跳过绿族**——无跨轮结果缓存（防假命中）。
- **智能排序**（lit `--order=smart` 类比）：上轮 red/timeout 族先行，其余按已知耗时降序（`durations.tsv`——`.lit_test_times.txt` 类比，跨指纹存活）。
- **逐族超时**（nextest slow-timeout 类比）：tiers.tsv 第三列；超时记 `timeout` 态继续批次（不挂死会话）。
- **全局预算** `--max-time S`：预算耗尽将剩余族记 `pending` 后收尾（分批续跑基础）。
- **串行执行 v1**：TD-029 容器内存余量纪律（release 自应用族并发 = 已知降级面）；`KERF_TEST_JOBS>1` 刻意不生效（窗口档 §7 登记项）。
- **分块前台**：逐族串行 + `--max-time` 全局预算 + 台账断点——块间进度由 `ledger.tsv` 承载（防会话中断的机制本体）；慢族超时上限（tiers.tsv）均 > 单窗（如 fixpoint 1800s > 600s），故 T2 慢族单块内可能仅完成 1-2 族——正常预期，续块承接。
- **碰撞跳过**：libtest 过滤为子串匹配——内嵌名族（`fixpoint_tests` ⊂ `target_fixpoint_tests`、`jit_window_tests` ⊂ `method_jit_window_tests`）自动补 `--skip` 盾。
- **台账工件**（`target/test-ledger/`）：`ledger.tsv`（族/状态/秒数/计数/时间戳——机器可读审计面）+ `state`（指纹）+ `durations.tsv`（耗时缓存）+ `batch.log`。

### 配置单源与守卫

- **tiers.tsv = 分层唯一事实源**（族/层/超时/注记四列）；`test_tier_guard_tests` 三守卫执法：FP1 表↔挂载双向零漂移；FP2 字段健全 + 九慢族 T2 钉扎（GATE 完整性）；FP3 引擎 `bash -n` + 表面标记。
- 新增测试族 = runner.rs 挂载 + tiers.tsv 行 + docs/tests 双生档（三件共变——守卫 FP1 漏一即红）。

## 当前基线（v0.123.0 —— W-TEST-FLOW r167 引擎实测口径）

- **测试面**：workspace `--lib` **823 案 / 13 binaries / 0 failed** ✓；runner 集成 60 族 **766 passed + 2 ignored = 768 listed**（台账↔列表对账恒等式 ✓）；门审计 460 live + 124 retired 实跑 exit 0（**379s** 全程实测）；doc tests 0 案（全库无 doctest——机器真相）。
- **T0 烟测预算**：29 族实测 **~42s**（预算 ≤120s ✓；逐族耗时 = 窗口档 §2 基线表 + target/test-ledger/durations.tsv）。
- **慢族 T2 面实测（r167）**：abc_pipeline 471s / target_parser_twin 389s / audit 379s / steady_target_reader 379s / target_lexer_twin 164s / check_segment 90s——全 63 项串行总和 ~2,180s；**历史勘正**：fixpoint 族实为 9 案 ~5s（r166「567.67s」为多族切片总时长错配——见窗口档 §2）。
- 六命令全绿口径（fmt 零 diff / check 0e0w / clippy -D warnings 零 / build 0e0w / doc 唯一 cargo#6313 惯例噪声）维持 §3.2 定义；构建块（--build-only）实测 67s（温树）。

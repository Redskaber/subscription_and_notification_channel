//! kerf-pkg — the kerf package manager (W-3.10 window).
//!
//! Build-bootstrap layer: manifest/lockfile resolution that runs before
//! any compilation. Zero dependencies (SOP §18/§18.5 — the resolver must
//! not depend on pipeline crates). Three rulings single-sourced in
//! `docs/develop/v3/w3.10-package-window.md`:
//!
//! - **PKG-1** file form: `kerf.toml` (manifest) and `kerf.lock`
//!   (lockfile) in a TOML-micro subset — comments, blank lines,
//!   `key = "string"`, `key = integer`, `[section]`, `[[array-section]]`;
//!   everything else is rejected fail-closed.
//! - **PKG-2** implementation language: the W-PKG-SELFHOST window
//!   CLOSED at r160 — the resolution LOGIC is self-hosted. The
//!   production seat is the five-piece `.ktf` twin composition
//!   (`selfhost/v1/{micro-toml,semver,manifest,lockfile,resolve}.ktf`,
//!   driven by the `kp` shell in kerf-driver); the Rust modules of
//!   this crate are the build-guidance ROLLBACK BAND and the parity
//!   oracle (the `KERF_PKG_SELFHOST=rust` seat), no longer the
//!   production logic. The IO shell and the depth guardrails stay
//!   host-service faces by the window's constitutional ruling (they
//!   are services the twin calls, not language logic).
//! - **PKG-3** registry strategy: local-first — a dependency named
//!   `core-bits` resolves to `<manifest-dir>/libs/core-bits/`; version
//!   constraints use semver caret semantics; diamond conflicts fail with
//!   every constraint listed.
//!
//! Layout convention: `<dir>/kerf.toml` is the package manifest,
//! `<dir>/libs/<name>/` holds each dependency, `<dir>/kerf.lock` is the
//! resolution product written at the root package directory.

mod error;
mod lockfile;
mod manifest;
mod micro_toml;
mod resolve;
mod semver;

pub use error::PkgError;
pub use lockfile::{LockEntry, Lockfile};
pub use manifest::Manifest;
pub use micro_toml::{Document, Item, MicroTomlError, Value, parse};
pub use resolve::{RESOLUTION_DEPTH_LIMIT, Resolution, ResolvedPkg, resolve, resolve_with_limit};
pub use semver::{Constraint, Version};

/// The canonical manifest file name (PKG-1).
pub const MANIFEST_FILE: &str = "kerf.toml";
/// The canonical lockfile file name (PKG-1).
pub const LOCKFILE_FILE: &str = "kerf.lock";
/// The conventional dependency directory under a package directory (PKG-3).
pub const LIBS_DIR: &str = "libs";

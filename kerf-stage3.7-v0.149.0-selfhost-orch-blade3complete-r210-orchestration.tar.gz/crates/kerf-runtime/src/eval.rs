//! The meta-circular evaluator (docs/stage0.md §5.1, §21.8 Phase 1) —
//! Layer 7's direct interpreter over CoreExpr.
//!
//! The evaluator is one half of the dual-execution-path cross-check
//! (stage-0-plan §5 row 0.7): the same expanded program runs through
//! `compile → VM` and through `eval`, and the results must agree —
//! a divergence is a P1 line stop (§21.11 risk 5). Every semantic
//! decision here MIRRORS the compiler/VM pair, never invents:
//!
//! * name resolution — innermost binding wins via a tail-first scan
//!   (`Compiler::lookup_local` verbatim); unbound names fall back to
//!   the global table, reads fail `UnboundGlobal`, writes (assign)
//!   store blind (`StoreGlobal` semantics);
//! * evaluation order — arguments left to right, then the callee
//!   (§19.3 emission order, the 0.5 compiler authoritative);
//! * closures — the "basic closure" P0 scope: free lexical names
//!   compile to globals, so the captured env is a DORMANT value
//!   snapshot (0.6 `ClosureData` duality); lexical capture is a
//!   Stage 1 activation on BOTH engines;
//! * budget — the same frames-plus-live-cells account (`depth` is
//!   the evaluator's frame count); exhaustion runs one collect-
//!   then-retry cycle (§19.4 alloc skeleton) before failing closed;
//! * builtins — the 18 STAGE0_GLOBALS dispatch through the shared
//!   kerf-vm functions (single source, zero drift by construction).
//!
//! # The heap activation stack (W-REC-DEPTH blade 1, r136)
//!
//! The evaluator is an EXPLICIT ACTIVATION STACK machine, not a Rust
//! recursion (the K160 unifying move — the r135 knowledge-layer
//! anchor: trampoline / explicit stack / heap-allocated frames are
//! one mechanism, "move activation records from the host stack to
//! the heap, after which depth is bounded by memory policy, not a
//! fixed integer"). Every continuation — argument walks, branch
//! picks, let bindings, handler installs, and above every closure
//! application — rides the `konts` heap vector, and one driver loop
//! consumes it, so the host stack height is CONSTANT in the kerf
//! call depth. The old `EVAL_DEPTH_LIMIT` (2048) Rust-stack guard
//! retired with the recursion: call depth now charges the same
//! frames-plus-live-cells budget the VM keeps (one `reserve` per
//! closure entry — the `push_frame` duality), so arbitrary
//! recursion depth is memory-governed, exactly like the VM.
//! `RuntimeError::EvalDepthExceeded` stays registered as the
//! historical diagnostic face (rendering pinned by the error-registry
//! tests); no engine path constructs it since this blade.
//!
//! The temp-root discipline is the explicit-stack spelling of the
//! §19.4 "explicit C-stack roots": every in-flight intermediate the
//! old Rust frames held as locals (evaluated argument prefixes, the
//! callee, a callee's saved environment) rides the `temp` root stack
//! through guard/truncate pairs recorded in the continuation frames,
//! so a collect-then-retry cycle inside any reserve still sees every
//! reachable value.
//!
//! # The shared tree (SExpr)
//!
//! Continuation frames must HOLD tree nodes (an argument prefix
//! remembers the remaining arguments; a branch remembers both
//! branches), so every node rides an `Rc` — the `SExpr` mirror of
//! `CoreExpr`. Each closure body converts ONCE at creation (the
//! same O(body) walk the old `Rc::new(body.clone())` deep copy
//! paid), each program/expression entry converts once per run, and
//! every frame thereafter clones node handles — never trees. The
//! conversion is a pure structural mirror: no semantic decision
//! exists in it, and the machine's match arms stay
//! decision-for-decision identical to the compiler/VM pair.

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::{Span, Symbol};
use kerf_vm::{
    Builtin, BuiltinHost, ClosureData, Heap, HeapObj, HeapRef, Roots, RuntimeError, Value, VmIo,
    builtin_symbol, demanded, dispatch_builtin,
};

use crate::gc::{self, GcStats};

/// A well-formed empty span for the entry charge of an empty
/// program (the compiler's `last_span` initialization duality) —
/// delegates to the single-source host-position constructor.
fn zero_span() -> Span {
    Span::host()
}

/// The `proto` field of evaluator-made closures: no bytecode exists
/// on this path, so the sentinel is the registry's type tag. It can
/// never collide with a VM proto index (a func table that large is
/// unreachable under any budget).
pub const EVAL_CLOSURE_PROTO: u32 = u32::MAX;

// ---------------------------------------------------------------------------
// The shared tree — the Rc-per-node mirror of CoreExpr
// ---------------------------------------------------------------------------

/// One binding of the shared-tree `Let` (the `Binding` payload —
/// span rides the `Let` head like the source tree's own head).
struct SBinding {
    name: Symbol,
    value: Rc<SExpr>,
}

/// One handler clause of the shared-tree `Handle`.
struct SClause {
    effect: Symbol,
    handler: Rc<SExpr>,
}

/// The machine's expression tree: `CoreExpr` with every child behind
/// an `Rc`, so continuation frames hold node handles (cheap clones),
/// never deep copies, and no reference crosses a closure entry (the
/// W-REC-DEPTH blade 1 representation ruling — see the module doc).
enum SExpr {
    Literal {
        span: Span,
        value: LiteralValue,
    },
    Var {
        span: Span,
        name: Symbol,
    },
    Fn {
        span: Span,
        params: Rc<[Symbol]>,
        body: Rc<SExpr>,
    },
    Apply {
        span: Span,
        func: Rc<SExpr>,
        args: Rc<[Rc<SExpr>]>,
    },
    If {
        cond: Rc<SExpr>,
        then: Rc<SExpr>,
        alt: Rc<SExpr>,
    },
    Assign {
        span: Span,
        name: Symbol,
        value: Rc<SExpr>,
    },
    Let {
        bindings: Rc<[SBinding]>,
        body: Rc<SExpr>,
    },
    Perform {
        span: Span,
        effect: Symbol,
        args: Rc<[Rc<SExpr>]>,
    },
    Handle {
        body: Rc<SExpr>,
        handlers: Rc<[SClause]>,
    },
}

impl SExpr {
    /// The node's own span (the `CoreExpr::span` duality — the
    /// condition's `If` head keeps the source tree's cond-less head
    /// shape, so `If` carries no span of its own, exactly like the
    /// source tree).
    fn span(&self) -> Span {
        match self {
            SExpr::Literal { span, .. }
            | SExpr::Var { span, .. }
            | SExpr::Fn { span, .. }
            | SExpr::Apply { span, .. }
            | SExpr::Assign { span, .. }
            | SExpr::Perform { span, .. } => *span,
            SExpr::If { cond, .. } => cond.span(),
            SExpr::Let { body, .. } => body.span(),
            SExpr::Handle { body, .. } => body.span(),
        }
    }
}

/// Convert one source tree into the shared tree (a pure structural
/// mirror — spans, names, payloads and arity verbatim; no semantic
/// decision lives here).
fn to_shared(expr: &CoreExpr) -> Rc<SExpr> {
    let node = match expr {
        CoreExpr::Literal { span, value } => SExpr::Literal {
            span: *span,
            value: value.clone(),
        },
        CoreExpr::Var { span, name } => SExpr::Var {
            span: *span,
            name: name.clone(),
        },
        CoreExpr::Fn { span, params, body } => SExpr::Fn {
            span: *span,
            params: params.iter().cloned().collect(),
            body: to_shared(body),
        },
        CoreExpr::Apply { span, func, args } => SExpr::Apply {
            span: *span,
            func: to_shared(func),
            args: args.iter().map(to_shared).collect(),
        },
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => SExpr::If {
            cond: to_shared(cond),
            then: to_shared(then_branch),
            alt: to_shared(else_branch),
        },
        CoreExpr::Assign { span, name, value } => SExpr::Assign {
            span: *span,
            name: name.clone(),
            value: to_shared(value),
        },
        CoreExpr::Let { bindings, body, .. } => SExpr::Let {
            bindings: bindings
                .iter()
                .map(|b| SBinding {
                    name: b.name.clone(),
                    value: to_shared(&b.value),
                })
                .collect(),
            body: to_shared(body),
        },
        CoreExpr::Perform { span, effect, args } => SExpr::Perform {
            span: *span,
            effect: effect.clone(),
            args: args.iter().map(to_shared).collect(),
        },
        CoreExpr::Handle { body, handlers, .. } => SExpr::Handle {
            body: to_shared(body),
            handlers: handlers
                .iter()
                .map(|c| SClause {
                    effect: c.effect.clone(),
                    handler: to_shared(&c.handler),
                })
                .collect(),
        },
    };
    Rc::new(node)
}

/// One evaluator-made closure: params/body live in the Rust-side
/// registry, the heap cell carries identity (and the flat capture
/// area — values in descriptor-like order, LA-5).
#[derive(Clone)]
struct EvalClosure {
    /// The `define` name when the closure came from a named fn (the
    /// ArityMismatch payload face — `Compiler::compile_fn(Some(name))`;
    /// §9.67 NB-4: the identity rides the single pool).
    name: Option<Symbol>,
    params: Rc<[Symbol]>,
    body: Rc<SExpr>,
    /// The captured names, in capture order (the values live in the
    /// heap cell's env — the GC-traced flat-closure carrier; the
    /// registry holds names only, never unrooted values). Rebuilt
    /// into the invoked frame's `Env.captured` by zipping with the
    /// cell's env at entry (LA-5).
    captured_names: Rc<[Symbol]>,
}

/// The frame-slot environment (the compiler's scope model at run
/// time): `names` is every binding site in push order, `locals` the
/// slot values; resolution scans `names` tail-first (innermost
/// binding wins — `Compiler::lookup_local` verbatim). §9.67 NB-2:
/// binding sites carry pool entries — a 4-byte comparison per scan
/// step, zero allocation per binding (params and `let`s clone the
/// `Symbol` they already hold).
///
/// Stage 2.1 LA-5: `captured` is the closure's capture area — the
/// values its body's free names resolved to at creation time (the
/// K45 minimal-capture-set mirror of the compiler's descriptor
/// analysis). Resolution order mirrors the compiler exactly: own
/// bindings first, then the captured region, then globals; assigns
/// stop at the captured region (immutable-capture subset, LA-7).
#[derive(Clone, Default)]
struct Env {
    names: Vec<(Symbol, usize)>,
    locals: Vec<Value>,
    captured: Vec<(Symbol, Value)>,
}

impl Env {
    /// A closure body environment: params occupy slots 0..n.
    fn from_params(params: &[Symbol]) -> Self {
        Env {
            names: params
                .iter()
                .enumerate()
                .map(|(i, p)| (p.clone(), i))
                .collect(),
            locals: Vec::new(),
            captured: Vec::new(),
        }
    }

    /// Resolve a name to its slot (innermost binding wins).
    fn resolve(&self, name: &Symbol) -> Option<usize> {
        self.names
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, s)| *s)
    }

    /// Resolve a name in the captured region (LA-5 — the
    /// `load-captured` mirror).
    fn resolve_captured(&self, name: &Symbol) -> Option<&Value> {
        self.captured
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, v)| v)
    }
}

/// The free-name analysis of one closure body (Stage 2.1 LA-4/LA-5 —
/// the Steensgaard flat-closure walk internalized): every name the
/// body can reference that no binder inside the body (or among the
/// params, pre-seeded into `bound`) captures, in first-encounter
/// order — the deterministic order the captured pairs land in.
/// `Assign` targets count as references: the LA-7 boundary needs the
/// target captured for the store to be rejectable at invoke time
/// (the outer scope is gone by then). Walks the shared tree (the
/// machine's own representation — the W-REC-DEPTH blade 1 form).
fn free_names(expr: &SExpr, bound: &mut Vec<Symbol>, out: &mut Vec<Symbol>) {
    let reference = |name: &Symbol, out: &mut Vec<Symbol>| {
        if !bound.iter().any(|n| n == name) && !out.iter().any(|n| n == name) {
            out.push(name.clone());
        }
    };
    match expr {
        SExpr::Literal { .. } => {}
        SExpr::Var { name, .. } => reference(name, out),
        SExpr::Fn { params, body, .. } => {
            let mark = bound.len();
            bound.extend(params.iter().cloned());
            free_names(body, bound, out);
            bound.truncate(mark);
        }
        SExpr::Apply { func, args, .. } => {
            free_names(func, bound, out);
            for arg in args.iter() {
                free_names(arg, bound, out);
            }
        }
        SExpr::If { cond, then, alt } => {
            free_names(cond, bound, out);
            free_names(then, bound, out);
            free_names(alt, bound, out);
        }
        SExpr::Assign { name, value, .. } => {
            reference(name, out);
            free_names(value, bound, out);
        }
        SExpr::Let { bindings, body } => {
            let mark = bound.len();
            for binding in bindings.iter() {
                free_names(&binding.value, bound, out);
                bound.push(binding.name.clone());
            }
            free_names(body, bound, out);
            bound.truncate(mark);
        }
        SExpr::Perform { args, .. } => {
            for arg in args.iter() {
                free_names(arg, bound, out);
            }
        }
        SExpr::Handle { body, handlers } => {
            free_names(body, bound, out);
            for clause in handlers.iter() {
                free_names(&clause.handler, bound, out);
            }
        }
    }
}

/// One continuation frame of the heap activation stack. Every frame
/// the old Rust recursion held implicitly rides this vector instead —
/// the machine's host stack height stays constant in the kerf call
/// depth (W-REC-DEPTH blade 1).
enum Kont {
    /// An `Apply` between arguments (§19.3 order: args left to
    /// right, then the callee). `done` holds the evaluated prefix;
    /// `guard` protects the prefix (and later the callee) across the
    /// call's reserves.
    Arg {
        func: Rc<SExpr>,
        args: Rc<[Rc<SExpr>]>,
        done: Vec<Value>,
        next: usize,
        span: Span,
        guard: usize,
    },
    /// An `Apply`'s callee leg: the arguments are complete, now the
    /// callee expression evaluates.
    Callee {
        argv: Vec<Value>,
        span: Span,
        guard: usize,
    },
    /// An `If`'s condition: the branches ride the frame; the
    /// condition's own span names the type rejection.
    If {
        cond_span: Span,
        then: Rc<SExpr>,
        alt: Rc<SExpr>,
    },
    /// An `Assign`'s right side: the store target resolves once the
    /// value exists.
    Store { name: Symbol, span: Span },
    /// A `Let`'s binding walk (let* semantics: binding i sees slots
    /// 0..i-1 — `locals_mark`/`locals_truncate` as truncate marks).
    Bind {
        bindings: Rc<[SBinding]>,
        idx: usize,
        mark_names: usize,
        mark_locals: usize,
        body: Rc<SExpr>,
    },
    /// A `Let`'s body: restore the binding marks, deliver the value.
    LetOut {
        mark_names: usize,
        mark_locals: usize,
    },
    /// A `Perform`'s argument walk (the handler search follows the
    /// last argument).
    EffectArg {
        effect: Symbol,
        args: Rc<[Rc<SExpr>]>,
        done: Vec<Value>,
        next: usize,
        span: Span,
        guard: usize,
    },
    /// A `Handle`'s clause walk (handler values evaluate at
    /// installation, innermost last).
    Install {
        clauses: Rc<[SClause]>,
        idx: usize,
        body: Rc<SExpr>,
    },
    /// A `Handle`'s body: pop the installed handlers, deliver.
    Uninstall { installed: usize },
    /// ONE CLOSURE ACTIVATION RECORD (the heap frame — the K160
    /// move): the body produced its value. Restore the caller's
    /// environment and the callee-entry temp guard (`entry_guard`,
    /// the saved env's root protections), then the call site's guard
    /// (`site_guard`, the argument prefix and callee protections) —
    /// the two truncations the Rust unwind performed at the invoke
    /// and apply frames.
    Frame {
        saved: Env,
        entry_guard: usize,
        site_guard: usize,
    },
}

/// The outcome of entering a call: a closure body became the new
/// focus (a `Frame` was pushed), or a builtin finished in place.
enum CallOutcome {
    Entered(Rc<SExpr>),
    Returned(Value),
}

/// The meta-circular evaluator.
pub struct Evaluator {
    heap: Heap,
    /// The global table, keyed by interned identity (§9.67 NB-1:
    /// every Var fallback and every define/assign stores reads the
    /// 4-byte pool entry — a text de-intern used to ride every
    /// binding site and a string hash every global reference).
    globals: HashMap<Symbol, Value>,
    /// The extern contract names seen in the item walk (W-3.2): an
    /// unbound reference to one of these is the extern boundary, not
    /// a typo — the diagnostic names the contract.
    extern_names: std::collections::HashSet<Symbol>,
    /// Evaluator-made closures by heap reference (identity registry;
    /// dead entries drop at each cycle).
    closures: HashMap<HeapRef, EvalClosure>,
    /// Installed handlers, innermost last (`PushHandler`/`PopHandler`
    /// duality; `perform` scans tail-first for the nearest match —
    /// §9.67 NB-3: effect identities are pool entries).
    handlers: Vec<(Symbol, Value)>,
    /// The current lexical environment (swapped at closure entry).
    env: Env,
    /// Root-protected in-flight intermediates (the §19.4 explicit
    /// roots of the activation stack — every guard/truncate pair the
    /// continuation frames record).
    temp: Vec<Value>,
    io: Box<dyn VmIo>,
    budget: u32,
    /// Cumulative allocations (the VM-compatible public face).
    allocs: u32,
    /// The kerf call depth (the frame-count half of live usage —
    /// one per closure activation, the `push_frame` duality).
    depth: u32,
    /// Automatic collect-then-retry cycles run so far.
    cycles: u32,
}

impl Default for Evaluator {
    fn default() -> Self {
        Self::new()
    }
}

impl Evaluator {
    /// A default evaluator: buffered I/O, the default budget, the 18
    /// STAGE0_GLOBALS builtins seeded (the VM's `Vm::build` duality).
    pub fn new() -> Self {
        Evaluator::build(kerf_vm::DEFAULT_BUDGET, Box::new(kerf_vm::BufferIo::new()))
    }

    /// Build with a custom I/O face.
    pub fn with_io(io: Box<dyn VmIo>) -> Self {
        Evaluator::build(kerf_vm::DEFAULT_BUDGET, io)
    }

    /// Build with a custom allocation budget (tests and hosts).
    pub fn with_budget(budget: u32) -> Self {
        Evaluator::build(budget, Box::new(kerf_vm::BufferIo::new()))
    }

    fn build(budget: u32, io: Box<dyn VmIo>) -> Self {
        let mut globals = HashMap::new();
        for (builtin, _, _) in Builtin::ALL {
            globals.insert(builtin_symbol(builtin), Value::Builtin(builtin));
        }
        Evaluator {
            heap: Heap::default(),
            globals,
            extern_names: std::collections::HashSet::new(),
            closures: HashMap::new(),
            handlers: Vec::new(),
            env: Env::default(),
            temp: Vec::new(),
            io,
            budget,
            allocs: 0,
            depth: 0,
            cycles: 0,
        }
    }

    // ---------- observation faces ----------

    /// Look a global up by name (the parity observation face; unbound
    /// names and builtins are both visible here — §9.67 NB-7: the
    /// text face stays a linear scan so a miss query never pollutes
    /// the interning pool).
    pub fn global(&self, name: &str) -> Option<&Value> {
        self.globals
            .iter()
            .find(|(s, _)| s.as_str() == name)
            .map(|(_, v)| v)
    }

    /// Look a global up by its interned identity (§9.67 NB-7 — the
    /// hot face and the driver's snapshot face: `Var` fallback and
    /// `Define` roster reads ride the 4-byte hash).
    pub fn global_sym(&self, name: &Symbol) -> Option<&Value> {
        self.globals.get(name)
    }

    /// Bind one global to a literal value materialized on this
    /// evaluator's heap — the W-3.12 injection channel's evaluator
    /// arm (the dual-engine discipline's second cell; the VM arm is
    /// `Vm::inject_global`).
    ///
    /// Channel contract (the evaluator half):
    /// * the pair cells charge the allocation budget through the
    ///   same `reserve_exact` path the `Literal` eval arm uses (the
    ///   §19.4 discipline — injected data is live heap);
    /// * the referenced-name check is the CALLER's duty here (the
    ///   evaluator has no up-front reference set): the dual harness
    ///   checks the name against the compiled bytecode's global
    ///   table — the single source — before injecting into both
    ///   engines. An invalid name fails closed as
    ///   [`kerf_vm::RuntimeError::InjectGlobalUnknown`]; a valid but
    ///   unreferenced name is a dead entry the caller owns;
    /// * the bound entry is a collector root like any global, and a
    ///   program-side `define` of the same name still overwrites it
    ///   at run time (the steady-state program's no-define
    ///   discipline is owned by the driver face that assembles it).
    pub fn inject_global(&mut self, name: &str, lit: &LiteralValue) -> Result<(), RuntimeError> {
        let symbol = Symbol::new(name).map_err(|_| RuntimeError::InjectGlobalUnknown {
            name: name.to_string(),
            span: Span::host(),
        })?;
        let cells = lit.pair_cells() as u32;
        self.reserve_exact(cells, Span::host())?;
        let value = Value::from_literal(lit, &mut self.heap);
        self.globals.insert(symbol, value);
        Ok(())
    }

    /// The object heap (structure inspection for tests and hosts).
    pub fn heap(&self) -> &Heap {
        &self.heap
    }

    /// Cumulative allocations so far (frames + cells; the VM face).
    pub fn allocations(&self) -> u32 {
        self.allocs
    }

    /// Automatic collect-then-retry cycles run so far.
    pub fn collector_cycles(&self) -> u32 {
        self.cycles
    }

    /// Drain recorded output lines.
    pub fn take_output(&mut self) -> Vec<String> {
        self.io.take_output()
    }

    // ---------- program entry ----------

    /// Evaluate a declaration sequence (the `compile_program`
    /// duality): every define binds a global; the program value is
    /// `nil` (the depth-0 halt of a declaration-only product).
    pub fn eval_program(&mut self, items: &[ModuleItem]) -> Result<Value, RuntimeError> {
        let entry_span = items.first().map(|i| i.span()).unwrap_or_else(zero_span);
        self.env = Env::default(); // program isolation: no lexical residue
        self.reserve(entry_span)?; // the entry frame
        self.depth = 1;
        let result = self.eval_items(items);
        self.depth = 0;
        result?;
        Ok(Value::Nil)
    }

    /// Evaluate one expression at top level (an empty environment —
    /// the `compile(expr)` duality).
    pub fn eval_expr(&mut self, expr: &CoreExpr) -> Result<Value, RuntimeError> {
        self.env = Env::default(); // expression isolation: no lexical residue
        self.reserve(expr.span())?; // the entry frame
        self.depth = 1;
        let result = self.run(to_shared(expr));
        self.depth = 0;
        result
    }

    fn eval_items(&mut self, items: &[ModuleItem]) -> Result<(), RuntimeError> {
        for item in items {
            match item {
                ModuleItem::Define { name, value, .. } => {
                    let v = match value {
                        // A named fn defines its closure's diagnostic
                        // name (compile_fn(Some(name)) duality). The
                        // body's `to_shared` is the ONE O(body) walk
                        // this creation pays — the old representation's
                        // deep copy, aimed at the activation stack's
                        // node handles instead.
                        CoreExpr::Fn { params, body, .. } => {
                            self.make_closure(Some(name), params, to_shared(body), value.span())?
                        }
                        _ => self.run(to_shared(value))?,
                    };
                    self.globals.insert(name.clone(), v);
                }
                ModuleItem::Require { .. } => {
                    // Zero code: linking is deferred to load time
                    // (§19.3 trap 3 — Stage 0 single-module runs).
                }
                ModuleItem::DefineSyntax { .. } => {
                    // Zero code: the transformer lives in the expansion
                    // environment (sub-stage 0.9 — the `Require`
                    // zero-code precedent applied to the macro phase).
                }
                ModuleItem::Module { items, .. } => {
                    // Recursive flat evaluation; proper scope homes
                    // arrive with the 0.9 module system. Source-nested
                    // items are read-bounded (the reader nesting cap),
                    // so this walk stays a plain Rust recursion.
                    self.eval_items(items)?;
                }
                ModuleItem::Extern { items, .. } => {
                    // Zero code (W-3.2): the declaration records the
                    // contract names for the boundary diagnostic.
                    for entry in items {
                        self.extern_names.insert(entry.name.clone());
                    }
                }
                ModuleItem::Annotate { .. } => {
                    // Zero code: the dann site record is the HM
                    // layer's own bookkeeping (blade 1 GZ-1) — the
                    // evaluator never sees annotations (the `Require`
                    // zero-code precedent applied to the checking
                    // phase).
                }
                ModuleItem::Struct { .. } => {
                    // Zero code: the struct declaration's runtime
                    // face is its generated defines (blade 2 GZ-2 —
                    // real items in this same stream, evaluated
                    // normally); this record is the type layer's
                    // own bookkeeping (the `Annotate` precedent).
                }
                ModuleItem::Enum { .. } => {
                    // Zero code: the enum declaration's runtime face
                    // is its generated constructor defines (blade 3
                    // GZ-4 — real items in this same stream,
                    // evaluated normally); this record is the type
                    // layer's own bookkeeping (the `Struct` zero-code
                    // precedent's own).
                }
            }
        }
        Ok(())
    }

    // ---------- the explicit activation stack (W-REC-DEPTH blade 1) ----------

    /// Drive the machine over one focus to a value. The two nested
    /// loops are the whole interpreter: the eval phase turns one
    /// expression head into either a value or a pushed continuation
    /// with a new focus; the deliver phase feeds values to
    /// continuations until one pops without a successor (the
    /// machine's result) or re-focuses (the loop continues). The
    /// host stack height never grows with the kerf call depth.
    fn run(&mut self, entry: Rc<SExpr>) -> Result<Value, RuntimeError> {
        let mut konts: Vec<Kont> = Vec::new();
        let mut focus = entry;
        let walked = self.walk(&mut konts, &mut focus);
        match walked {
            Ok(value) => Ok(value),
            Err(err) => {
                // The Rust-unwind mirror: every cleanup the old
                // recursion performed while the error propagated —
                // frame restores, let truncations, handler pops, and
                // the call-site temp truncations — runs here, in pop
                // order.
                self.unwind(konts);
                Err(err)
            }
        }
    }

    fn walk(
        &mut self,
        konts: &mut Vec<Kont>,
        focus: &mut Rc<SExpr>,
    ) -> Result<Value, RuntimeError> {
        loop {
            // ---- the eval phase: one expression head ----
            let mut value = {
                let expr: &SExpr = focus;
                match expr {
                    SExpr::Literal { span, value } => {
                        // §9.69.3 EXC-1/EXC-2: the cell count is the
                        // single-sourced `LiteralValue::pair_cells`
                        // (kerf-core — the VM's materialize budgets against
                        // the same method), and the charge is one
                        // `reserve_exact` batch instead of a per-cell loop.
                        self.reserve_exact(value.pair_cells() as u32, *span)?;
                        Value::from_literal(value, &mut self.heap)
                    }
                    SExpr::Var { span, name } => {
                        if let Some(slot) = self.env.resolve(name) {
                            self.env.locals[slot].clone()
                        } else if let Some(v) = self.env.resolve_captured(name) {
                            // Stage 2.1 LA-5: the capture-area read (the
                            // `load-captured` mirror — MIRRORS, never
                            // invents).
                            v.clone()
                        } else {
                            match self.globals.get(name) {
                                Some(v) => v.clone(),
                                None if self.extern_names.contains(name) => {
                                    return Err(RuntimeError::ExternCallRequiresBackend {
                                        name: name.clone(),
                                        span: *span,
                                    });
                                }
                                None => {
                                    return Err(RuntimeError::UnboundGlobal {
                                        name: name.clone(),
                                        span: *span,
                                    });
                                }
                            }
                        }
                    }
                    SExpr::Fn { span, params, body } => {
                        self.make_closure(None, params, Rc::clone(body), *span)?
                    }
                    SExpr::Apply { span, func, args } => {
                        // §19.3 order: args left to right, then the
                        // callee. The guard protects the evaluated
                        // prefix and the callee across the call's
                        // reserves (the explicit-roots class).
                        let guard = self.temp.len();
                        if args.is_empty() {
                            konts.push(Kont::Callee {
                                argv: Vec::new(),
                                span: *span,
                                guard,
                            });
                            *focus = Rc::clone(func);
                        } else {
                            konts.push(Kont::Arg {
                                func: Rc::clone(func),
                                args: Rc::clone(args),
                                done: Vec::with_capacity(args.len()),
                                next: 0,
                                span: *span,
                                guard,
                            });
                            *focus = Rc::clone(&args[0]);
                        }
                        continue;
                    }
                    SExpr::If { cond, then, alt } => {
                        konts.push(Kont::If {
                            cond_span: cond.span(),
                            then: Rc::clone(then),
                            alt: Rc::clone(alt),
                        });
                        *focus = Rc::clone(cond);
                        continue;
                    }
                    SExpr::Assign { span, name, value } => {
                        konts.push(Kont::Store {
                            name: name.clone(),
                            span: *span,
                        });
                        *focus = Rc::clone(value);
                        continue;
                    }
                    SExpr::Let { bindings, body } => {
                        // let* semantics: binding i sees slots 0..i-1;
                        // the mark/truncate pair is `locals_mark`/
                        // `locals_truncate`.
                        let mark_names = self.env.names.len();
                        let mark_locals = self.env.locals.len();
                        if bindings.is_empty() {
                            konts.push(Kont::LetOut {
                                mark_names,
                                mark_locals,
                            });
                            *focus = Rc::clone(body);
                        } else {
                            konts.push(Kont::Bind {
                                bindings: Rc::clone(bindings),
                                idx: 0,
                                mark_names,
                                mark_locals,
                                body: Rc::clone(body),
                            });
                            *focus = Rc::clone(&bindings[0].value);
                        }
                        continue;
                    }
                    SExpr::Perform { span, effect, args } => {
                        let guard = self.temp.len();
                        if args.is_empty() {
                            // The handler search runs immediately — the
                            // same arm the last-argument delivery takes.
                            match self.handlers.iter().rposition(|(e, _)| e == effect) {
                                Some(idx) => {
                                    let handler = self.handlers[idx].1.clone();
                                    match self.enter_call(
                                        handler,
                                        Vec::new(),
                                        *span,
                                        guard,
                                        konts,
                                    )? {
                                        CallOutcome::Entered(next) => {
                                            *focus = next;
                                            continue;
                                        }
                                        CallOutcome::Returned(v) => v,
                                    }
                                }
                                None => {
                                    self.temp.truncate(guard);
                                    return Err(RuntimeError::UnhandledEffect {
                                        effect: effect.clone(),
                                        span: *span,
                                    });
                                }
                            }
                        } else {
                            konts.push(Kont::EffectArg {
                                effect: effect.clone(),
                                args: Rc::clone(args),
                                done: Vec::with_capacity(args.len()),
                                next: 0,
                                span: *span,
                                guard,
                            });
                            *focus = Rc::clone(&args[0]);
                            continue;
                        }
                    }
                    SExpr::Handle { body, handlers } => {
                        // Handler values are evaluated at installation,
                        // then the body runs with them installed, then
                        // all pop (PopHandler n duality — plan-0.5
                        // decision 8).
                        if handlers.is_empty() {
                            konts.push(Kont::Uninstall { installed: 0 });
                            *focus = Rc::clone(body);
                        } else {
                            konts.push(Kont::Install {
                                clauses: Rc::clone(handlers),
                                idx: 0,
                                body: Rc::clone(body),
                            });
                            *focus = Rc::clone(&handlers[0].handler);
                        }
                        continue;
                    }
                }
            };

            // ---- the deliver phase: feed values to continuations ----
            loop {
                match konts.pop() {
                    None => return Ok(value),
                    Some(k) => match k {
                        Kont::Arg {
                            func,
                            args,
                            mut done,
                            next,
                            span,
                            guard,
                        } => {
                            self.temp.push(value.clone());
                            done.push(value);
                            if next + 1 < args.len() {
                                let following = Rc::clone(&args[next + 1]);
                                konts.push(Kont::Arg {
                                    func,
                                    args,
                                    done,
                                    next: next + 1,
                                    span,
                                    guard,
                                });
                                *focus = following;
                                break;
                            }
                            konts.push(Kont::Callee {
                                argv: done,
                                span,
                                guard,
                            });
                            *focus = func;
                            break;
                        }
                        Kont::Callee { argv, span, guard } => {
                            // The callee arrived: protect it and enter
                            // the call (the old `invoke` entry).
                            self.temp.push(value.clone());
                            match self.enter_call(value, argv, span, guard, konts)? {
                                CallOutcome::Entered(next) => {
                                    *focus = next;
                                    break;
                                }
                                CallOutcome::Returned(v) => value = v,
                            }
                        }
                        Kont::If {
                            cond_span,
                            then,
                            alt,
                        } => match value {
                            Value::Bool(true) => {
                                *focus = then;
                                break;
                            }
                            Value::Bool(false) => {
                                *focus = alt;
                                break;
                            }
                            other => {
                                return Err(RuntimeError::TypeMismatch {
                                    context: "jump-if-false condition",
                                    demanded: demanded::BOOL,
                                    got: other.kind_name(),
                                    span: cond_span,
                                });
                            }
                        },
                        Kont::Store { name, span } => {
                            if let Some(slot) = self.env.resolve(&name) {
                                self.env.locals[slot] = value.clone();
                            } else if self.env.resolve_captured(&name).is_some() {
                                // Stage 2.1 LA-7: the immutable-capture
                                // subset — the assign-to-captured boundary
                                // mirrors the compiler's rejection exactly
                                // (the free-name analysis captures the
                                // target, so the boundary is decidable
                                // here without the outer scope).
                                return Err(RuntimeError::AssignToCaptured { name, span });
                            } else {
                                self.globals.insert(name, value.clone());
                            }
                            // The store yields the value: deliver onward.
                        }
                        Kont::Bind {
                            bindings,
                            idx,
                            mark_names,
                            mark_locals,
                            body,
                        } => {
                            let slot = self.env.locals.len();
                            self.env.names.push((bindings[idx].name.clone(), slot));
                            self.env.locals.push(value);
                            if idx + 1 < bindings.len() {
                                let following = Rc::clone(&bindings[idx + 1].value);
                                konts.push(Kont::Bind {
                                    bindings,
                                    idx: idx + 1,
                                    mark_names,
                                    mark_locals,
                                    body,
                                });
                                *focus = following;
                            } else {
                                konts.push(Kont::LetOut {
                                    mark_names,
                                    mark_locals,
                                });
                                *focus = body;
                            }
                            break;
                        }
                        Kont::LetOut {
                            mark_names,
                            mark_locals,
                        } => {
                            self.env.names.truncate(mark_names);
                            self.env.locals.truncate(mark_locals);
                        }
                        Kont::EffectArg {
                            effect,
                            args: eff_args,
                            mut done,
                            next,
                            span,
                            guard,
                        } => {
                            self.temp.push(value.clone());
                            done.push(value);
                            if next + 1 < eff_args.len() {
                                let following = Rc::clone(&eff_args[next + 1]);
                                konts.push(Kont::EffectArg {
                                    effect,
                                    args: eff_args,
                                    done,
                                    next: next + 1,
                                    span,
                                    guard,
                                });
                                *focus = following;
                                break;
                            }
                            // Args complete: the nearest handler wins.
                            match self.handlers.iter().rposition(|(e, _)| e == &effect) {
                                Some(idx) => {
                                    let handler = self.handlers[idx].1.clone();
                                    match self.enter_call(handler, done, span, guard, konts)? {
                                        CallOutcome::Entered(next) => {
                                            *focus = next;
                                            break;
                                        }
                                        CallOutcome::Returned(v) => value = v,
                                    }
                                }
                                None => {
                                    self.temp.truncate(guard);
                                    return Err(RuntimeError::UnhandledEffect { effect, span });
                                }
                            }
                        }
                        Kont::Install { clauses, idx, body } => {
                            self.handlers.push((clauses[idx].effect.clone(), value));
                            if idx + 1 < clauses.len() {
                                let following = Rc::clone(&clauses[idx + 1].handler);
                                konts.push(Kont::Install {
                                    clauses,
                                    idx: idx + 1,
                                    body,
                                });
                                *focus = following;
                            } else {
                                konts.push(Kont::Uninstall {
                                    installed: clauses.len(),
                                });
                                *focus = body;
                            }
                            break;
                        }
                        Kont::Uninstall { installed } => {
                            let keep = self.handlers.len() - installed;
                            self.handlers.truncate(keep);
                        }
                        Kont::Frame {
                            saved,
                            entry_guard,
                            site_guard,
                        } => {
                            // The closure body produced its value: the
                            // two truncations the Rust unwind performed
                            // (the invoke frame's saved-env protections,
                            // then the apply frame's argument prefix).
                            self.temp.truncate(entry_guard);
                            self.env = saved;
                            self.depth -= 1;
                            self.temp.truncate(site_guard);
                        }
                    },
                }
            }
        }
    }

    /// The Rust-unwind mirror for the error path: every cleanup the
    /// old recursion performed while an error propagated — in pop
    /// order, so the frames restore exactly as the stack unwound.
    ///
    /// Mirrored leak semantics (never "improved"): the old binding
    /// walk and handler-install walk propagated their errors with
    /// `?` BEFORE their per-iteration bookkeeping, so a failure
    /// mid-walk left the partial bindings/installations in place —
    /// `Bind` and `Install` therefore clean nothing here; the outer
    /// frame restores replace the environment wholesale and the next
    /// run re-isolates it at entry.
    fn unwind(&mut self, konts: Vec<Kont>) {
        for k in konts {
            match k {
                Kont::Frame {
                    saved,
                    entry_guard: _,
                    site_guard,
                } => {
                    self.depth = self.depth.saturating_sub(1);
                    self.env = saved;
                    self.temp.truncate(site_guard);
                }
                Kont::Arg { guard, .. }
                | Kont::Callee { guard, .. }
                | Kont::EffectArg { guard, .. } => {
                    self.temp.truncate(guard);
                }
                Kont::LetOut {
                    mark_names,
                    mark_locals,
                } => {
                    self.env.names.truncate(mark_names);
                    self.env.locals.truncate(mark_locals);
                }
                Kont::Uninstall { installed } => {
                    let keep = self.handlers.len().saturating_sub(installed);
                    self.handlers.truncate(keep);
                }
                // If / Store carry no state to restore; Bind and
                // Install mirror the `?`-walk leaks (see above).
                Kont::If { .. } | Kont::Store { .. } | Kont::Bind { .. } | Kont::Install { .. } => {
                }
            }
        }
    }

    // ---------- closures and calls ----------

    fn make_closure(
        &mut self,
        name: Option<&Symbol>,
        params: &[Symbol],
        body: Rc<SExpr>,
        span: Span,
    ) -> Result<Value, RuntimeError> {
        // Stage 2.1 LA-5: capture exactly the body's free names that
        // resolve in the current environment — the K45 minimal-set
        // mirror of the compiler's descriptor analysis (a name bound
        // neither here nor in the captured region is a global
        // reference and stays uncaptured). Assign targets count as
        // references: the LA-7 boundary needs the name captured to
        // reject the store without the (gone) outer scope.
        let mut free: Vec<Symbol> = Vec::new();
        let mut bound: Vec<Symbol> = params.to_vec();
        free_names(&body, &mut bound, &mut free);
        let mut captured_names: Vec<Symbol> = Vec::new();
        let mut values: Vec<Value> = Vec::new();
        for n in free {
            if let Some(slot) = self.env.resolve(&n) {
                captured_names.push(n);
                values.push(self.env.locals[slot].clone());
            } else if let Some(v) = self.env.resolve_captured(&n) {
                captured_names.push(n);
                values.push(v.clone());
            }
        }
        // Root the in-flight captured values across the reserve (a
        // collect-then-retry cycle must not sweep them before the
        // closure cell exists — the §19.4 explicit-roots class).
        // Stage 3.1 W-3.1 blade: the env rides as a shared-immutable
        // Rc — the SAME representation the VM engine installs by
        // refcount bump (the ClosureData duality keeps one shape).
        let guard = self.temp.len();
        self.temp.extend(values.iter().cloned());
        self.reserve(span)?; // the closure cell (Closure duality)
        let r = self.heap.alloc(HeapObj::Closure(ClosureData {
            proto: EVAL_CLOSURE_PROTO,
            env: Rc::new(values),
        }));
        self.temp.truncate(guard);
        // The body rides as the shared tree's own node handle (the
        // ONE O(body) conversion happened at its `to_shared` entry —
        // per creation this walk only clones the handle).
        self.closures.insert(
            r,
            EvalClosure {
                name: name.cloned(),
                params: params.iter().cloned().collect(),
                body,
                captured_names: captured_names.into(),
            },
        );
        Ok(Value::Closure(r))
    }

    /// Invoke a callable with evaluated args (the `Vm::invoke`
    /// duality shared by `Apply` and `Perform`'s handler call). The
    /// call site's temp guard rides along: every rejection here
    /// truncates it first (the apply frame's unwind), and a closure
    /// entry records it on the `Frame` (the return truncation).
    ///
    /// Callers protect `callee` and `args` on the temp root stack —
    /// this function reserves (frames, `cons`), so the values it
    /// received must be reachable from the roots.
    fn enter_call(
        &mut self,
        callee: Value,
        args: Vec<Value>,
        span: Span,
        site_guard: usize,
        konts: &mut Vec<Kont>,
    ) -> Result<CallOutcome, RuntimeError> {
        match callee {
            Value::Closure(r) => {
                let closure = self
                    .closures
                    .get(&r)
                    .cloned()
                    .expect("evaluator closures are registry-paired with their cells");
                if args.len() != closure.params.len() {
                    self.temp.truncate(site_guard);
                    return Err(RuntimeError::ArityMismatch {
                        func: closure.name.clone(),
                        expected: closure.params.len() as u32,
                        actual: args.len() as u32,
                        span,
                    });
                }
                self.reserve(span).inspect_err(|_| {
                    // The apply frame's unwind truncation on the
                    // reject path (the reserve failed before the
                    // frame charge landed).
                    self.temp.truncate(site_guard);
                })?; // the callee frame (push_frame duality)
                self.depth += 1;
                let saved = std::mem::replace(&mut self.env, Env::from_params(&closure.params));
                // The swapped-out environment's locals AND captured
                // values are root-protected for the whole body (the
                // §19.4 explicit-roots class of an evaluator frame;
                // missing either reclaims in-flight callers' values).
                // The activation record carries the guard pair: the
                // entry guard (these protections) and the call
                // site's guard (the argument prefix and callee).
                let entry_guard = self.temp.len();
                self.temp.extend(saved.locals.iter().cloned());
                self.temp
                    .extend(saved.captured.iter().map(|(_, v)| v.clone()));
                // Stage 2.1 LA-5: install the captured region — the
                // closure cell's env is the capture area (descriptor-
                // like order); zipping it with the registry's names
                // rebuilds the frame environment.
                let cell = self
                    .heap
                    .get(r)
                    .map(|obj| match obj {
                        HeapObj::Closure(d) => Rc::clone(&d.env),
                        _ => Rc::default(),
                    })
                    .unwrap_or_default();
                self.env.captured = closure
                    .captured_names
                    .iter()
                    .cloned()
                    .zip(cell.iter().cloned())
                    .collect();
                self.env.locals = args;
                konts.push(Kont::Frame {
                    saved,
                    entry_guard,
                    site_guard,
                });
                Ok(CallOutcome::Entered(closure.body))
            }
            Value::Builtin(b) => {
                // §9.73 EVL-1/EVL-2: the arity check and the routing
                // live in the single-source `dispatch_builtin` — the
                // SAME function the VM enters (twin dispatch retired).
                let result = dispatch_builtin(self, b, args, span);
                self.temp.truncate(site_guard);
                result.map(CallOutcome::Returned)
            }
            other => {
                self.temp.truncate(site_guard);
                Err(RuntimeError::TypeMismatch {
                    context: "call callee",
                    demanded: demanded::CALLABLE,
                    got: other.kind_name(),
                    span,
                })
            }
        }
    }

    // ---------- the §19.4 safety point ----------

    /// Count one allocation (the `Vm::reserve` duality): the LIVE
    /// footprint (depth + live cells) checks against the budget; on
    /// exhaustion one collect-then-retry cycle runs before the
    /// fail-closed error.
    fn reserve(&mut self, span: Span) -> Result<(), RuntimeError> {
        if self.live_usage() < self.budget {
            self.allocs += 1;
            return Ok(());
        }
        self.collect_now();
        if self.live_usage() < self.budget {
            self.allocs += 1;
            return Ok(());
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    /// Count `n` allocations in one budget check (§9.69.3 EXC-2 —
    /// the VM's `reserve_exact` twin). The per-cell loop this
    /// replaces performed `n` identical checks: live usage only
    /// moves when `heap.alloc` runs in the `from_literal` walk that
    /// follows, so one check under the same condition is
    /// behavior-identical (accept/reject boundary, retry point, and
    /// success-path `allocs` total all match).
    fn reserve_exact(&mut self, n: u32, span: Span) -> Result<(), RuntimeError> {
        if n == 0 {
            return Ok(());
        }
        if self.live_usage() < self.budget {
            self.allocs += n;
            return Ok(());
        }
        self.collect_now();
        if self.live_usage() < self.budget {
            self.allocs += n;
            return Ok(());
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    fn live_usage(&self) -> u32 {
        self.depth + self.heap.live_len() as u32
    }

    /// Run one explicit cycle (roots: the current locals, every
    /// global, every installed handler, every protected temp — the
    /// §19.4 completeness classes of an evaluator state).
    ///
    /// Determinism note (stage0.md §9.55.4): the root list order
    /// (including the HashMap-ordered globals slice) only varies the
    /// mark *visitation sequence*; the marked set is the reachability
    /// fixpoint and sweep rebuilds the free list in slot-index order,
    /// so collection stays run-to-run deterministic.
    pub fn collect_now(&mut self) -> GcStats {
        let roots = Roots {
            stack: Vec::new(),
            // The current env's captured region is frame-adjacent
            // live state (the LA-5 mirror of the VM's frame capture
            // areas joining the roots — §19.4 completeness).
            locals: self
                .env
                .locals
                .iter()
                .chain(self.env.captured.iter().map(|(_, v)| v))
                .cloned()
                .collect(),
            globals: self.globals.values().cloned().collect(),
            foreign: self.temp.clone(),
            handlers: self.handlers.iter().map(|(_, v)| v.clone()).collect(),
        };
        let stats = gc::collect(&mut self.heap, &roots);
        self.cycles += 1;
        // Drop registry entries of swept closure cells (dead identity).
        self.closures.retain(|r, _| self.heap.is_live(*r));
        stats
    }
}

impl BuiltinHost for Evaluator {
    /// The depth + live-cells budget (§19.4 — the evaluator's safety
    /// point semantics stay engine-local).
    fn charge(&mut self, span: Span) -> Result<(), RuntimeError> {
        self.reserve(span)
    }

    fn io_mut(&mut self) -> &mut dyn VmIo {
        self.io.as_mut()
    }

    fn heap_mut(&mut self) -> &mut Heap {
        &mut self.heap
    }

    fn heap(&self) -> &Heap {
        &self.heap
    }
}

#[cfg(test)]
mod tests {
    //! Evaluator tests (FP2): primitive-by-primitive positives and the
    //! error family over hand-built CoreExpr (the kerf-vm api_tests
    //! fixture precedent — source-level pipelines live in the root
    //! integration tree).

    use super::*;
    use kerf_core::{Binding, HandlerClause};

    fn fix_span() -> Span {
        zero_span()
    }

    fn lit(v: LiteralValue) -> CoreExpr {
        CoreExpr::Literal {
            span: fix_span(),
            value: v,
        }
    }

    fn int(n: i64) -> CoreExpr {
        lit(LiteralValue::Int(n))
    }

    fn var(name: &str) -> CoreExpr {
        CoreExpr::var(fix_span(), name).expect("fixture var")
    }

    fn app(func: CoreExpr, args: Vec<CoreExpr>) -> CoreExpr {
        CoreExpr::Apply {
            span: fix_span(),
            func: Box::new(func),
            args,
        }
    }

    fn call(name: &str, args: Vec<CoreExpr>) -> CoreExpr {
        app(var(name), args)
    }

    fn if_(cond: CoreExpr, then: CoreExpr, else_: CoreExpr) -> CoreExpr {
        CoreExpr::If {
            span: fix_span(),
            cond: Box::new(cond),
            then_branch: Box::new(then),
            else_branch: Box::new(else_),
        }
    }

    fn let_(bindings: Vec<(&str, CoreExpr)>, body: CoreExpr) -> CoreExpr {
        CoreExpr::Let {
            span: fix_span(),
            bindings: bindings
                .into_iter()
                .map(|(n, v)| Binding::new(fix_span(), n, v).expect("fixture binding"))
                .collect(),
            body: Box::new(body),
        }
    }

    fn fn_(params: &[&str], body: CoreExpr) -> CoreExpr {
        CoreExpr::fn_(fix_span(), params, body).expect("fixture fn")
    }

    fn define(name: &str, value: CoreExpr) -> ModuleItem {
        ModuleItem::define(fix_span(), name, value).expect("fixture define")
    }

    /// A deep countdown pair for the blade face: `non_tail` wraps
    /// the recursive call in `(+ 1 …)` (every activation stays live
    /// until the base case), the tail-shaped leg returns the call's
    /// value directly (the subset has no tail-call reuse — the same
    /// frame walk in the other source shape).
    fn countdown(non_tail: bool) -> CoreExpr {
        let step = call("countdown", vec![call("-", vec![var("n"), int(1)])]);
        let branch = if non_tail {
            call("+", vec![int(1), step])
        } else {
            step
        };
        fn_(
            &["n"],
            if_(call("=", vec![var("n"), int(0)]), int(0), branch),
        )
    }

    // ---------- positives ----------

    #[test]
    fn seeds_builtins_and_evaluates_primitives() {
        let mut ev = Evaluator::new();
        // All 18 STAGE0_GLOBALS seeded (the Vm::build duality).
        for (_, name, _) in Builtin::ALL {
            assert!(
                matches!(ev.global(name), Some(Value::Builtin(_))),
                "builtin {name} must be seeded"
            );
        }
        // if / let / var / assign over eval_expr.
        let expr = let_(
            vec![("a", int(1)), ("b", int(2))],
            if_(
                call("<", vec![var("a"), var("b")]),
                call("+", vec![var("a"), var("b")]),
                int(0),
            ),
        );
        assert_eq!(ev.eval_expr(&expr).expect("primitives run"), Value::Int(3));
        // Shadowing: the inner binding wins, the outer survives.
        let shadow = let_(vec![("x", int(1))], let_(vec![("x", int(2))], var("x")));
        assert_eq!(ev.eval_expr(&shadow).expect("shadow runs"), Value::Int(2));
    }

    #[test]
    fn closures_apply_and_effects_nearest_match() {
        let mut ev = Evaluator::new();
        // A named closure: define -> call -> recursion (fib 10).
        let fib = fn_(
            &["n"],
            if_(
                call("<", vec![var("n"), int(2)]),
                var("n"),
                call(
                    "+",
                    vec![
                        call("fib", vec![call("-", vec![var("n"), int(1)])]),
                        call("fib", vec![call("-", vec![var("n"), int(2)])]),
                    ],
                ),
            ),
        );
        ev.eval_program(&[define("fib", fib), define("r", call("fib", vec![int(10)]))])
            .expect("fib runs");
        assert_eq!(ev.global("r"), Some(&Value::Int(55)));

        // perform -> nearest handler (rposition duality); require is
        // a no-op and module items flatten.
        let handler = fn_(&["v"], call("*", vec![var("v"), int(10)]));
        // perform with no args through a handle clause.
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "log", vec![int(4)]).expect("fixture perform"),
            vec![HandlerClause::new(fix_span(), "log", handler).expect("fixture clause")],
        )
        .expect("fixture handle");
        let program = vec![
            define("h", handled),
            ModuleItem::require(fix_span(), "other").expect("fixture require"),
            ModuleItem::module(fix_span(), "m", vec![define("r2", var("h"))])
                .expect("fixture module"),
        ];
        ev.eval_program(&program).expect("effects run");
        assert_eq!(ev.global("r2"), Some(&Value::Int(40)));
    }

    #[test]
    fn budget_collect_then_retry_runs_discarding_programs() {
        // A tight budget over a discarding chain: each (car (cons a b))
        // term's pair cell dies the moment `car` pops it, so the live
        // set stays small — but WITHOUT collection the un-reclaimed
        // cells accumulate past the budget (heap live count is
        // monotonic until a cycle runs). The inline collect-then-
        // retry keeps the chain alive.
        let mut ev = Evaluator::with_budget(8);
        let mut terms = Vec::new();
        for i in 0..12 {
            terms.push(call("car", vec![call("cons", vec![int(i), int(0)])]));
        }
        let sum = terms
            .into_iter()
            .reduce(|a, b| call("+", vec![a, b]))
            .expect("chain");
        assert_eq!(
            ev.eval_expr(&sum)
                .expect("collect-then-retry keeps the run alive"),
            Value::Int(66) // 0+1+...+11
        );
        assert!(
            ev.collector_cycles() > 0,
            "at least one automatic cycle ran"
        );

        // Contrast: the same chain under the same budget WITHOUT any
        // way to reclaim fails closed (the heap face is exercised
        // here through a second evaluator with a live-set-retaining
        // program — see the api_tests budget negative).
        let mut strict = Evaluator::with_budget(8);
        let mut keep = Vec::new();
        for i in 0..12 {
            keep.push(call("cons", vec![int(i), int(0)]));
        }
        // A right-nested cons chain keeps every cell live as an arg.
        let chain = keep
            .into_iter()
            .rev()
            .reduce(|acc, cell| call("cons", vec![cell, acc]))
            .expect("chain");
        assert!(matches!(
            strict.eval_expr(&chain),
            Err(RuntimeError::BudgetExceeded { .. })
        ));
    }

    // ---------- the heap activation stack (W-REC-DEPTH blade 1) ----------

    #[test]
    fn deep_non_tail_recursion_rides_the_heap_activation_stack() {
        // 10^5 frames of NON-tail recursion on the DEFAULT test
        // thread stack (8 MiB): every activation rides the konts
        // vector, so the host stack height is constant — the K160
        // move made executable (the old Rust recursion needed a
        // 64 MiB deep-stack thread to reach even 2048; the r74/r83
        // lineage). Depth is memory-governed: 100_000 activations +
        // live cells sit far inside the default budget (8 Mi).
        let mut ev = Evaluator::new();
        ev.eval_program(&[
            define("countdown", countdown(true)),
            define("r", call("countdown", vec![int(100_000)])),
        ])
        .expect("10^5 non-tail frames run on the default stack");
        assert_eq!(ev.global("r"), Some(&Value::Int(100_000)));
    }

    #[test]
    fn deep_tail_shaped_recursion_rides_the_heap_activation_stack() {
        // The tail-shaped leg of the pair: the call is the branch
        // value, but the subset has no tail-call reuse (the VM
        // pushes a frame per call too — the termination ladder), so
        // this is the same heap-frame walk in the other source
        // shape. Both legs prove the plan's acceptance pair: deep
        // recursion of either shape is bounded by the budget, never
        // by the host stack.
        let mut ev = Evaluator::new();
        ev.eval_program(&[
            define("countdown", countdown(false)),
            define("r", call("countdown", vec![int(100_000)])),
        ])
        .expect("10^5 tail-shaped frames run on the default stack");
        assert_eq!(ev.global("r"), Some(&Value::Int(0)));
    }

    #[test]
    fn deep_recursion_fails_closed_at_the_budget() {
        // The fail-closed face: a tight budget turns the unbounded
        // depth into the structured BudgetExceeded rejection (the
        // §19.4 safety point — the same account the VM keeps), with
        // the machine state unwound cleanly (depth back to zero).
        let mut ev = Evaluator::with_budget(64);
        let err = ev
            .eval_program(&[
                define("countdown", countdown(true)),
                define("r", call("countdown", vec![int(10_000)])),
            ])
            .expect_err("the budget is the bound, not the stack");
        assert!(matches!(err, RuntimeError::BudgetExceeded { .. }));
        // The run unwound: a depth inside the same tight budget runs
        // cleanly on a fresh evaluator.
        let mut ev2 = Evaluator::with_budget(64);
        ev2.eval_program(&[
            define("countdown", countdown(true)),
            define("r", call("countdown", vec![int(32)])),
        ])
        .expect("depth inside the budget runs");
        assert_eq!(ev2.global("r"), Some(&Value::Int(32)));
    }

    #[test]
    fn deep_recursion_collects_garbage_frames_on_the_way_up() {
        // Root completeness under depth: a discarding step (each
        // frame's pair cell dies the moment `car` pops it on the
        // unwind) under a budget that only fits the LIVE frames
        // survives because each cycle reclaims the dead cells while
        // every live activation's saved environment stays rooted —
        // the explicit-roots class of the activation stack. The
        // budget arithmetic: the walk's 2_000 activations are live
        // until they return (depth is half of live usage), and the
        // per-frame garbage forces the periodic cycles.
        let mut ev = Evaluator::with_budget(2_100);
        let step = call("countdown", vec![call("-", vec![var("n"), int(1)])]);
        // Two discarding pair cells per frame: with one, the depth
        // decrease and the garbage increase cancel frame-for-frame
        // (live usage stays flat and no cycle ever fires); with two,
        // live usage climbs +1 per unwound frame until the budget
        // forces the collect-then-retry cycle.
        let body = fn_(
            &["n"],
            if_(
                call("=", vec![var("n"), int(0)]),
                int(0),
                call(
                    "car",
                    vec![call(
                        "cons",
                        vec![call("car", vec![call("cons", vec![step, int(0)])]), int(0)],
                    )],
                ),
            ),
        );
        ev.eval_program(&[
            define("countdown", body),
            define("r", call("countdown", vec![int(2_000)])),
        ])
        .expect("the discarding walk survives on collect-then-retry");
        assert_eq!(ev.global("r"), Some(&Value::Int(0)));
        assert!(
            ev.collector_cycles() > 0,
            "the tight budget forced at least one cycle under depth"
        );
    }

    #[test]
    fn errors_from_deep_frames_unwind_the_activation_stack() {
        // An error 10^4 frames deep: the unwind restores every frame
        // (the Rust-unwind mirror) and the span survives to the top —
        // the §12.1 consumption contract at depth.
        let mut ev = Evaluator::new();
        let step = call("countdown", vec![call("-", vec![var("n"), int(1)])]);
        let body = fn_(
            &["n"],
            if_(
                call("=", vec![var("n"), int(0)]),
                call("/", vec![int(1), int(0)]),
                call("+", vec![int(1), step]),
            ),
        );
        let err = ev
            .eval_program(&[
                define("countdown", body),
                define("r", call("countdown", vec![int(10_000)])),
            ])
            .expect_err("div by zero at the base of a deep chain");
        assert!(matches!(err, RuntimeError::DivByZero { .. }));
    }

    // ---------- negatives ----------

    #[test]
    fn arity_mismatch_closure_face() {
        let mut ev = Evaluator::new();
        let f = fn_(&["a"], var("a"));
        let err = ev
            .eval_program(&[define("f", f), define("r", call("f", vec![int(1), int(2)]))])
            .expect_err("two args to a one-param closure");
        match err {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => {
                // §9.67 NB-5: the payload identity is a pool entry.
                assert_eq!(func.as_ref().map(|s| s.as_str()), Some("f"));
                assert_eq!((expected, actual), (1, 2));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn arity_mismatch_builtin_face() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(1), int(2), int(3)]))
            .expect_err("fixed arity two");
        match err {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => {
                assert_eq!(func.as_ref().map(|s| s.as_str()), Some("+"));
                assert_eq!((expected, actual), (2, 3));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_truthy_condition() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&if_(int(1), int(2), int(3)))
            .expect_err("condition must be bool");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "jump-if-false condition");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_arith_mixed_kinds() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(1), lit(LiteralValue::Float(2.5))]))
            .expect_err("mixed kinds rejected");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "add operand");
                assert_eq!(got, "float");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_car_operand() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("car", vec![int(5)]))
            .expect_err("car demands a pair");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "car operand");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_call_callee() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_program(&[define("f", int(5)), define("r", call("f", vec![int(1)]))])
            .expect_err("callee must be callable");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "call callee");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn unbound_global_read_fails() {
        let mut ev = Evaluator::new();
        let err = ev.eval_expr(&var("missing")).expect_err("never defined");
        match err {
            RuntimeError::UnboundGlobal { name, .. } => {
                assert_eq!(name.as_str(), "missing");
            }
            other => panic!("expected unbound global, got {other:?}"),
        }
    }

    #[test]
    fn div_by_zero_fails_closed() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("/", vec![int(6), int(0)]))
            .expect_err("integer zero divisor");
        assert!(matches!(err, RuntimeError::DivByZero { .. }));
    }

    #[test]
    fn arithmetic_overflow_fails_closed() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(i64::MAX), int(1)]))
            .expect_err("checked add");
        assert!(matches!(err, RuntimeError::ArithmeticOverflow { .. }));
    }

    #[test]
    fn unhandled_effect_names_the_effect() {
        let mut ev = Evaluator::new();
        let expr = CoreExpr::perform(fix_span(), "log", vec![int(1)]).expect("fixture");
        let err = ev.eval_expr(&expr).expect_err("no handler installed");
        match err {
            RuntimeError::UnhandledEffect { effect, .. } => {
                assert_eq!(effect.as_str(), "log");
            }
            other => panic!("expected unhandled effect, got {other:?}"),
        }
    }

    #[test]
    fn read_line_eof_fails() {
        let mut ev = Evaluator::new(); // BufferIo with empty input
        let err = ev
            .eval_expr(&call("read-line", vec![]))
            .expect_err("empty input");
        assert!(matches!(err, RuntimeError::Eof { .. }));
    }

    #[test]
    fn perform_handler_arity_mismatch_propagates() {
        // The handler is a function like any callable — performing
        // with the wrong argument count is the closure-face arity
        // error (the VM invoke duality).
        let mut ev = Evaluator::new();
        let handler = fn_(&["a", "b"], var("a"));
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "e", vec![int(1)]).expect("fixture"),
            vec![HandlerClause::new(fix_span(), "e", handler).expect("fixture clause")],
        )
        .expect("fixture handle");
        let err = ev
            .eval_expr(&handled)
            .expect_err("one arg to two-param handler");
        match err {
            RuntimeError::ArityMismatch {
                expected, actual, ..
            } => {
                assert_eq!((expected, actual), (2, 1));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn write_line_rejects_non_string_operands() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("write-line", vec![int(5)]))
            .expect_err("write-line demands a string");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!((context, got), ("write-line operand", "int"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn not_rejects_non_bool_and_cdr_rejects_non_pair() {
        let mut ev = Evaluator::new();
        match ev.eval_expr(&call("not", vec![int(1)])) {
            Err(RuntimeError::TypeMismatch { context, got, .. }) => {
                assert_eq!((context, got), ("not operand", "int"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
        match ev.eval_expr(&call("cdr", vec![lit(LiteralValue::Nil)])) {
            Err(RuntimeError::TypeMismatch { context, got, .. }) => {
                assert_eq!((context, got), ("cdr operand", "nil"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn errors_propagate_from_nested_contexts_with_their_own_spans() {
        // An error raised deep inside a let inside an if inside a
        // closure body: the variant and span survive the unwind (the
        // §12.1 consumption contract on the eval path).
        let mut ev = Evaluator::new();
        let div = call("/", vec![int(1), int(0)]);
        let inner = let_(
            vec![("x", int(1))],
            if_(call("=", vec![var("x"), int(1)]), div, int(0)),
        );
        let outer = fn_(&["n"], inner);
        let err = ev
            .eval_program(&[define("f", outer), define("r", call("f", vec![int(9)]))])
            .expect_err("div by zero two scopes deep");
        match err {
            RuntimeError::DivByZero { span } => {
                // The span is the div form's own (fixture span).
                assert_eq!(span, fix_span());
            }
            other => panic!("expected div by zero, got {other:?}"),
        }
    }

    #[test]
    fn handler_scope_ends_with_the_handle_form() {
        // After the handle form completes, its handlers are gone —
        // a later perform of the same effect is unhandled (the
        // PopHandler n duality).
        let mut ev = Evaluator::new();
        let handler = fn_(&["v"], var("v"));
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "e", vec![int(1)]).expect("fixture"),
            vec![HandlerClause::new(fix_span(), "e", handler).expect("fixture clause")],
        )
        .expect("fixture handle");
        let after = let_(
            vec![("h", handled)],
            CoreExpr::perform(fix_span(), "e", vec![int(2)]).expect("fixture"),
        );
        let err = ev
            .eval_expr(&after)
            .expect_err("handler popped with the form");
        match err {
            RuntimeError::UnhandledEffect { effect, .. } => assert_eq!(effect.as_str(), "e"),
            other => panic!("expected unhandled effect, got {other:?}"),
        }
    }

    #[test]
    fn arity_and_budget_messages_follow_the_r8_family() {
        // §9.56 DIAG-1: messages stand on their own — no span suffix.
        let mut ev = Evaluator::new();
        let msg = ev
            .eval_expr(&call("+", vec![int(1)]))
            .expect_err("arity")
            .to_string();
        assert_eq!(msg, "arity mismatch: `+` expects `2` arguments, got `1`");

        // The depth leg of the old face became the budget leg with
        // the blade: the machine's bound is the allocation budget,
        // and its message carries the number that moved.
        let mut ev2 = Evaluator::with_budget(8);
        let msg2 = ev2
            .eval_program(&[
                define("countdown", countdown(true)),
                define("r", call("countdown", vec![int(10_000)])),
            ])
            .expect_err("budget")
            .to_string();
        assert_eq!(msg2, "allocation budget of `8` exhausted");
    }

    #[test]
    fn closure_captures_the_let_binding_beyond_its_scope() {
        // The Stage 2.1 flipped semantics (the §9.51.2 anchor family
        // inverted, evaluator side): the free name `x` IS captured
        // from the defining let — the closure cell carries the
        // captured value, and the body reads it through the captured
        // region even after the let's scope has exited (the flat
        // closure outlives its defining frame).
        let mut ev = Evaluator::new();
        let closure_in_let = let_(
            vec![("x", int(5))],
            fn_(&["y"], call("+", vec![var("x"), var("y")])),
        );
        // Grab the closure, then call it after the let has exited.
        let program = vec![
            define("f", closure_in_let),
            define("r", call("f", vec![int(1)])),
        ];
        ev.eval_program(&program).expect("the capture resolves");
        assert_eq!(
            ev.global("r").map(|v| v.to_string()),
            Some("6".into()),
            "x stays 5 through the captured region"
        );
    }

    #[test]
    fn name_tables_ride_the_single_pool() {
        // §9.67 NB-1/NB-2/NB-3 guard: the globals table, the binding
        // sites, and the handler stack all key by interned identity —
        // an independently interned Symbol of the same text IS the
        // table entry (the §9.52 single pool invariant), and a miss
        // through the identity face never pollutes the pool.
        let mut ev = Evaluator::new();
        ev.eval_program(&[define("x", int(42)), define("y", int(7))])
            .expect("defines run");
        // Identity face: same text interned independently resolves.
        let x_again = Symbol::new("x").expect("fixture symbol");
        assert_eq!(
            ev.global_sym(&x_again).map(|v| v.to_string()),
            Some("42".into())
        );
        // Text face still agrees (the observation face is a scan).
        assert_eq!(ev.global("x").map(|v| v.to_string()), Some("42".into()));
        // A miss through the identity face resolves None for both
        // faces and leaves the roster untouched (no shadow insert).
        let miss = Symbol::new("never-defined").expect("fixture symbol");
        assert!(ev.global_sym(&miss).is_none());
        assert!(ev.global("never-defined").is_none());
        // Builtin seeding rides the pool too: the seeded identity and
        // an independent intern of "+" are one entry (NB-5 seeding
        // face — the payload reads the pool, never re-interns).
        let plus = Symbol::new("+").expect("fixture symbol");
        assert!(matches!(ev.global_sym(&plus), Some(Value::Builtin(_))));
    }

    #[test]
    fn inject_global_binds_a_value_the_var_fallback_reads() {
        // W-3.12 injection channel, evaluator arm: the host binds
        // `data`, a free Var reference falls through env to the
        // global map and yields the materialized chain (the
        // dual-engine discipline's second cell).
        let mut ev = Evaluator::new();
        let table = LiteralValue::Pair(
            Box::new(LiteralValue::Int(104)),
            Box::new(LiteralValue::Pair(
                Box::new(LiteralValue::Int(105)),
                Box::new(LiteralValue::Nil),
            )),
        );
        ev.inject_global("data", &table).expect("binds");
        let out = ev.eval_expr(&var("data")).expect("the var resolves");
        let (a, b) = out.as_pair(ev.heap()).expect("the outer pair");
        assert_eq!(a, &Value::Int(104));
        let (c, d) = b.as_pair(ev.heap()).expect("the inner pair");
        assert_eq!(c, &Value::Int(105));
        assert_eq!(d, &Value::Nil);
        // The two cells charged through the same reserve path the
        // Literal arm uses (plus the entry charge of the eval walk).
        assert_eq!(ev.allocations(), 3);
    }

    #[test]
    fn inject_global_invalid_name_fails_closed() {
        // An invalid identifier cannot be referenced by any program,
        // so it is the same fail-closed family as the VM's
        // name-not-in-table rejection (the caller's referenced-name
        // check rides the compiled bytecode's global table — the
        // single source — upstream of this face).
        let mut ev = Evaluator::new();
        for bad in ["", "has space", "ctrl\u{7}"] {
            match ev.inject_global(bad, &LiteralValue::Int(1)) {
                Err(RuntimeError::InjectGlobalUnknown { name, .. }) => {
                    assert_eq!(name, bad);
                }
                other => panic!("the invalid name must fail closed, got {other:?}"),
            }
        }
        // Nothing was bound: the roster is untouched.
        assert!(ev.global("has space").is_none());
    }

    #[test]
    fn inject_global_charges_the_budget_and_fails_closed_on_exhaustion() {
        // The §19.4 safety point at the host face: the first bind's
        // cells are live and counted, so a second bind past the
        // budget is the definite rejection.
        let mut ev = Evaluator::with_budget(1);
        let table = LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(LiteralValue::Nil));
        ev.inject_global("data", &table)
            .expect("the first bind charges past-capacity like any single site");
        assert!(matches!(
            ev.inject_global("data", &table),
            Err(RuntimeError::BudgetExceeded { .. })
        ));
    }

    #[test]
    fn inject_global_yields_to_a_program_define() {
        // The documented contract: a program-side define of the same
        // name overwrites the bound entry at run time (the
        // steady-state program's no-define discipline is the
        // assembling driver's duty, asserted by the chain's
        // equivalence tests).
        let mut ev = Evaluator::new();
        ev.inject_global("data", &LiteralValue::Int(7))
            .expect("binds");
        ev.eval_program(&[define("data", int(5)), define("out", var("data"))])
            .expect("defines run");
        assert_eq!(ev.global("out").map(|v| v.to_string()), Some("5".into()));
    }
}

//! The W-PKG-SELFHOST blade 4 corpus regression: the W-3.10 named
//! corpus (`pkg_window_tests`) through the production binary on both
//! seats. The blade 3b family covered the band mechanics (the
//! three-state switch, the dual arms, the red-green band); this file
//! completes the corpus face the window's exit table names — every
//! named case of the integration suite rides the `kp` binary with
//! the twin position (the production seat) and the rust rollback
//! band agreeing byte-for-byte on stdout, stderr, and exit status:
//!
//! * the transitive three-package chain (the deepest-first order),
//! * the three-node cycle and the conflict diamond (the two variant
//!   rejection faces the blade 3b family did not reach),
//! * the lockfile roundtrip (the reproducibility principle, K117 —
//!   the written text is byte-identical across arms and across
//!   re-resolutions),
//! * the three rejection families (missing root manifest, missing
//!   dependency directory, directory/name mismatch).
//!
//! With this file the eight named cases of the window's corpus all
//! hold e2e on the production seat (the two-package positive, the
//! agreeable diamond, and the self-cycle rejection ride the blade 3b
//! family), and the Rust logic arm retires into the build-guidance
//! rollback band with the full corpus as its parity witness.

use std::path::{Path, PathBuf};
use std::process::Command;

/// A unique fixture root per test (cleaned up on exit).
fn fixture(tag: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("kerf-kp-corpus-{}-{tag}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("fixture dir creates");
    dir
}

/// Write a package manifest under `dir` (creating the directory).
fn write_pkg(dir: &Path, manifest: &str) {
    std::fs::create_dir_all(dir).expect("package dir creates");
    std::fs::write(dir.join("kerf.toml"), manifest).expect("manifest writes");
}

/// One `kp resolve <dir>` run with a `KERF_PKG_SELFHOST` value:
/// `(exit-ok, stdout, stderr)`.
fn kp_run(dir: &Path, selfhost: &str) -> (bool, String, String) {
    let out = Command::new(env!("CARGO_BIN_EXE_kp"))
        .arg("resolve")
        .arg(dir)
        .env("KERF_PKG_SELFHOST", selfhost)
        .output()
        .expect("the kp binary runs");
    (
        out.status.success(),
        String::from_utf8_lossy(&out.stdout).to_string(),
        String::from_utf8_lossy(&out.stderr).to_string(),
    )
}

/// Both arms over the same fixture: the twin seat (the production
/// position, explicit) and the rust band. The helper asserts the
/// arms agree on everything — the exit status, stdout, and stderr —
/// and hands the agreed faces back for the caller's shape checks.
fn both_arms(dir: &Path) -> (bool, String, String) {
    let twin = kp_run(dir, "twin");
    let rust = kp_run(dir, "rust");
    assert_eq!(twin.0, rust.0, "the exit status agrees across arms");
    assert_eq!(twin.1, rust.1, "the stdout agrees across arms");
    assert_eq!(twin.2, rust.2, "the stderr agrees across arms");
    twin
}

// ---------- the positive families ----------

/// The transitive three-package chain orders the deepest dependency
/// first at every level, on both arms, with the nested
/// root-relative source in the order line and the lockfile.
#[test]
fn transitive_chain_orders_deepest_first_on_both_arms() {
    let dir = fixture("chain");
    write_pkg(
        &dir,
        "package = \"top\"\nversion = \"1.0.0\"\n\n[depends]\nmid = \"1.1\"\n",
    );
    write_pkg(
        &dir.join("libs/mid"),
        "package = \"mid\"\nversion = \"1.2.0\"\n\n[depends]\nbase = \"1.0\"\n",
    );
    write_pkg(
        &dir.join("libs/mid/libs/base"),
        "package = \"base\"\nversion = \"1.0.7\"\n",
    );

    let (ok, out, err) = both_arms(&dir);
    assert!(ok, "the chain resolves: {err}");
    let base = out
        .find("base 1.0.7 (libs/mid/libs/base)")
        .expect("base line");
    let mid = out.find("mid 1.2.0 (libs/mid)").expect("mid line");
    let top = out.find("top 1.0.0 (.)").expect("top line");
    assert!(
        base < mid && mid < top,
        "deepest first at every level: {out}"
    );
    assert!(out.contains("wrote"), "the write line renders: {out}");

    let lock = std::fs::read_to_string(dir.join("kerf.lock")).expect("the lockfile writes");
    assert!(
        lock.contains("name = \"base\"") && lock.contains("source = \"libs/mid/libs/base\""),
        "the nested source is root-relative in the lockfile: {lock}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// The lockfile roundtrip (the reproducibility principle, K117): the
/// written text is byte-identical across arms and across
/// re-resolutions, and the first-resolution name identity holds (the
/// 0.9.9 twin under `right` is never visited).
#[test]
fn lockfile_roundtrip_is_byte_identical_on_both_arms() {
    let dir = fixture("lock");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.2.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"left\"\nversion = \"0.1.2\"\n",
    );
    write_pkg(
        &dir.join("libs/right"),
        "package = \"right\"\nversion = \"0.1.9\"\n\n[depends]\nleft = \"0.1.2\"\n",
    );
    // `right` reaches `left` through the shared name: the first
    // resolution (the root's libs/left) wins; the 0.9.9 twin is
    // never visited.
    write_pkg(
        &dir.join("libs/right/libs/left"),
        "package = \"left\"\nversion = \"0.9.9\"\n",
    );

    let (ok_twin, _, err_twin) = kp_run(&dir, "twin");
    assert!(ok_twin, "the twin seat resolves: {err_twin}");
    let text_twin = std::fs::read_to_string(dir.join("kerf.lock")).expect("twin lockfile");
    assert!(
        text_twin.contains("name = \"left\"") && text_twin.contains("version = \"0.1.2\""),
        "the first resolution wins: {text_twin}"
    );
    assert!(
        !text_twin.contains("0.9.9"),
        "the never-visited twin stays out of the lockfile: {text_twin}"
    );

    std::fs::remove_file(dir.join("kerf.lock")).expect("the lockfile removes");
    let (ok_rust, _, err_rust) = kp_run(&dir, "rust");
    assert!(ok_rust, "the rust band resolves: {err_rust}");
    let text_rust = std::fs::read_to_string(dir.join("kerf.lock")).expect("rust lockfile");
    assert_eq!(
        text_twin, text_rust,
        "the lockfile text is byte-identical across arms"
    );

    // Re-resolving the unchanged graph reproduces the same text on
    // the production seat.
    let (ok_again, _, err_again) = kp_run(&dir, "twin");
    assert!(ok_again, "the graph re-resolves: {err_again}");
    let text_again = std::fs::read_to_string(dir.join("kerf.lock")).expect("re-run lockfile");
    assert_eq!(
        text_twin, text_again,
        "re-resolution is byte-identical (the reproducibility principle)"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

// ---------- the rejection families ----------

/// The three-node cycle (aaa -> bbb -> ccc -> aaa) renders the same
/// named rejection line on both arms.
#[test]
fn three_node_cycle_renders_identically_on_both_arms() {
    let dir = fixture("three-cycle");
    write_pkg(
        &dir,
        "package = \"aaa\"\nversion = \"0.1.0\"\n\n[depends]\nbbb = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/bbb"),
        "package = \"bbb\"\nversion = \"0.1.0\"\n\n[depends]\nccc = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/bbb/libs/ccc"),
        "package = \"ccc\"\nversion = \"0.1.0\"\n\n[depends]\naaa = \"0.1\"\n",
    );

    let (ok, _, err) = both_arms(&dir);
    assert!(!ok, "the three-node cycle is rejected");
    assert!(
        err.contains("dependency cycle detected: aaa -> bbb -> ccc -> aaa"),
        "the cycle names every member in order: {err}"
    );
    assert!(
        !dir.join("kerf.lock").exists(),
        "a rejected resolution writes no lockfile"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// The conflict diamond (left requires deep 0.1, right requires deep
/// 0.2) reports the resolved version and every imposed constraint,
/// identically on both arms.
#[test]
fn conflict_diamond_renders_identically_on_both_arms() {
    let dir = fixture("conflict");
    write_pkg(
        &dir,
        "package = \"top\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/right"),
        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.2\"\n",
    );
    write_pkg(
        &dir.join("libs/left/libs/deep"),
        "package = \"deep\"\nversion = \"0.1.4\"\n",
    );

    let (ok, _, err) = both_arms(&dir);
    assert!(!ok, "the conflict diamond is rejected");
    assert!(
        err.contains("version conflict for \"deep\": resolved 0.1.4"),
        "the resolved version is reported: {err}"
    );
    assert!(
        err.contains("\"left\" requires 0.1") && err.contains("\"right\" requires 0.2"),
        "every imposed constraint is listed with its dependent: {err}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// A missing root manifest names the expected path on both arms.
#[test]
fn missing_root_manifest_renders_identically_on_both_arms() {
    let dir = fixture("no-root");

    let (ok, _, err) = both_arms(&dir);
    assert!(!ok, "the missing root manifest is rejected");
    assert!(
        err.contains("manifest not found:") && err.ends_with("kerf.toml\n"),
        "the rejection names the manifest path: {err}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// A missing dependency directory names the dependency and the
/// expected location on both arms.
#[test]
fn missing_dependency_directory_renders_identically_on_both_arms() {
    let dir = fixture("no-dep");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nghost = \"0.1\"\n",
    );

    let (ok, _, err) = both_arms(&dir);
    assert!(!ok, "the missing dependency directory is rejected");
    assert!(
        err.contains("dependency directory for \"ghost\" not found:") && err.contains("libs/ghost"),
        "the rejection names the dependency and its expected directory: {err}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// A dependency directory whose manifest declares a different
/// package name is rejected with the identity rule, identically on
/// both arms.
#[test]
fn directory_name_mismatch_renders_identically_on_both_arms() {
    let dir = fixture("mismatch");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"wrong-name\"\nversion = \"0.1.0\"\n",
    );

    let (ok, _, err) = both_arms(&dir);
    assert!(!ok, "the name mismatch is rejected");
    assert!(
        err.contains("directory is named \"left\"")
            && err.contains("declares package \"wrong-name\""),
        "the rejection names the directory and the declared package: {err}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

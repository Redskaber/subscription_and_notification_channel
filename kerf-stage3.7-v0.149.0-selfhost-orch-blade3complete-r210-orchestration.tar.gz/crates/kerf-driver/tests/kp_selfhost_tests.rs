//! The kp shell tests (W-PKG-SELFHOST blade 3b — the host-crate
//! ruling face): the `kp` binary's dual-arm e2e (the twin position
//! and the rust position produce byte-identical stdout and
//! lockfile text on the same fixture), the three-state rollback
//! band (unset = twin default, `twin`, `rust`, illegal values
//! fail closed), and the red-green band verification (a broken
//! twin renders LOUDLY — never a silent fallback — and the rust
//! band completes the same resolution).
//!
//! The binary face owns these tests (SOP §8.4.6: the bin lives in
//! this package, so `CARGO_BIN_EXE_kp` is the spawn face; the
//! cross-crate parity drives mount at the root `tests/runner.rs`
//! as `resolve_twin_tests`).

use std::path::{Path, PathBuf};
use std::process::Command;

use kerf_driver::pkg_selfhost::{
    RESOLVE_TARGET_SOURCE, TwinOutcome, enumerate_table, run_resolve_twin_vm,
};

/// A unique fixture root per test (cleaned up on exit).
fn fixture(tag: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("kerf-kp-e2e-{}-{tag}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("fixture dir creates");
    dir
}

/// Write a package manifest under `dir` (creating the directory).
fn write_pkg(dir: &Path, manifest: &str) {
    std::fs::create_dir_all(dir).expect("package dir creates");
    std::fs::write(dir.join("kerf.toml"), manifest).expect("manifest writes");
}

/// One `kp resolve <dir>` run with an optional `KERF_PKG_SELFHOST`
/// value: `(exit-ok, stdout, stderr)`.
fn kp_run(dir: &Path, selfhost: Option<&str>) -> (bool, String, String) {
    let mut cmd = Command::new(env!("CARGO_BIN_EXE_kp"));
    cmd.arg("resolve").arg(dir);
    if let Some(value) = selfhost {
        cmd.env("KERF_PKG_SELFHOST", value);
    } else {
        cmd.env_remove("KERF_PKG_SELFHOST");
    }
    let out = cmd.output().expect("the kp binary runs");
    (
        out.status.success(),
        String::from_utf8_lossy(&out.stdout).to_string(),
        String::from_utf8_lossy(&out.stderr).to_string(),
    )
}

// ---------- the e2e dual-arm family ----------

/// The two-package fixture resolves identically on the default
/// (twin) position, the explicit twin position, and the rust
/// rollback band — the same stdout, the same lockfile bytes.
#[test]
fn two_package_graph_resolves_identically_on_both_arms() {
    let dir = fixture("two");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore-bits = \"0.2\"\n",
    );
    write_pkg(
        &dir.join("libs/core-bits"),
        "package = \"core-bits\"\nversion = \"0.2.3\"\n",
    );

    let (ok_default, out_default, err_default) = kp_run(&dir, None);
    assert!(ok_default, "the default position resolves: {err_default}");
    let (ok_twin, out_twin, err_twin) = kp_run(&dir, Some("twin"));
    assert!(ok_twin, "the explicit twin position resolves: {err_twin}");
    let (ok_rust, out_rust, err_rust) = kp_run(&dir, Some("rust"));
    assert!(ok_rust, "the rust band resolves: {err_rust}");

    assert_eq!(out_default, out_twin, "unset and explicit twin agree");
    assert_eq!(out_twin, out_rust, "the twin arm and the rust arm agree");
    assert!(
        out_rust.contains("core-bits 0.2.3 (libs/core-bits)")
            && out_rust.contains("app 0.1.0 (.)")
            && out_rust.contains("wrote"),
        "the order lines and the write line are all present: {out_rust}"
    );

    let lock = std::fs::read_to_string(dir.join("kerf.lock")).expect("the lockfile writes");
    assert!(
        lock.contains("name = \"core-bits\"") && lock.contains("name = \"app\""),
        "the lockfile carries both packages: {lock}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// The diamond fixture: the same resolution on both arms (the
/// first-resolution-wins name identity and the constraint
/// verification ride the twin walk).
#[test]
fn diamond_graph_resolves_identically_on_both_arms() {
    let dir = fixture("diamond");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left/libs/shared"),
        "package = \"shared\"\nversion = \"0.1.5\"\n",
    );
    write_pkg(
        &dir.join("libs/right"),
        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/right/libs/shared"),
        "package = \"shared\"\nversion = \"0.1.5\"\n",
    );

    let (ok_twin, out_twin, err_twin) = kp_run(&dir, Some("twin"));
    assert!(ok_twin, "the twin arm resolves the diamond: {err_twin}");
    let (ok_rust, out_rust, err_rust) = kp_run(&dir, Some("rust"));
    assert!(ok_rust, "the rust arm resolves the diamond: {err_rust}");
    assert_eq!(out_twin, out_rust, "the diamond output agrees across arms");
    assert_eq!(
        out_twin.matches("shared 0.1.5").count(),
        1,
        "the shared name resolves once: {out_twin}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

/// The rejection e2e: a cycle fixture renders the same rejection
/// line on both arms (stderr, the PkgError Display face).
#[test]
fn cycle_rejection_renders_identically_on_both_arms() {
    let dir = fixture("cycle");
    write_pkg(
        &dir,
        "package = \"ouro\"\nversion = \"0.1.0\"\n\n[depends]\nouro = \"0.1\"\n",
    );

    let (ok_twin, _, err_twin) = kp_run(&dir, Some("twin"));
    assert!(!ok_twin, "the twin arm rejects the self-cycle");
    let (ok_rust, _, err_rust) = kp_run(&dir, Some("rust"));
    assert!(!ok_rust, "the rust arm rejects the self-cycle");
    assert_eq!(err_twin, err_rust, "the rejection line agrees");
    assert!(
        err_twin.contains("dependency cycle detected: ouro -> ouro"),
        "the cycle names the package twice: {err_twin}"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

// ---------- the three-state rollback band ----------

/// The fail-closed band: an illegal `KERF_PKG_SELFHOST` value
/// aborts the run with the position-parse error — never a silent
/// ignore.
#[test]
fn illegal_selfhost_value_fails_closed() {
    let dir = fixture("band");
    write_pkg(&dir, "package = \"solo\"\nversion = \"0.1.0\"\n");
    for bad in ["bogus", "", " TWIN ", "vm"] {
        let (ok, _, err) = kp_run(&dir, Some(bad));
        assert!(!ok, "the illegal value `{bad}` aborts");
        assert!(
            err.contains("invalid value for KERF_PKG_SELFHOST"),
            "the fail-closed message renders: {err}"
        );
    }
    let _ = std::fs::remove_dir_all(&dir);
}

/// The depth guardrail keeps its fail-closed face on the twin arm
/// (the K162 twin of the compiler CLI's DepthLimits).
#[test]
fn illegal_depth_limit_fails_closed_on_both_arms() {
    let dir = fixture("depth");
    write_pkg(&dir, "package = \"solo\"\nversion = \"0.1.0\"\n");
    for arm in ["twin", "rust"] {
        let out = Command::new(env!("CARGO_BIN_EXE_kp"))
            .arg("resolve")
            .arg(&dir)
            .env("KERF_PKG_SELFHOST", arm)
            .env("KERF_PKG_RESOLVE_DEPTH_LIMIT", "zero")
            .output()
            .expect("the kp binary runs");
        assert!(!out.status.success(), "the {arm} arm rejects the bad limit");
        assert!(
            String::from_utf8_lossy(&out.stderr)
                .contains("invalid value for KERF_PKG_RESOLVE_DEPTH_LIMIT"),
            "the {arm} arm renders the guardrail message"
        );
    }
    let _ = std::fs::remove_dir_all(&dir);
}

// ---------- the red-green band verification ----------

/// The red-green family (the window's exit condition):
///
/// * GREEN — the production twin resolves the fixture;
/// * RED — a CORRUPTED twin (a same-shape source whose resolver
///   always fails) renders its wrong rejection LOUDLY on the twin
///   position — never a silent fallback to the rust arm;
/// * BAND — the rust arm completes the same resolution correctly
///   (the rollback band takes over when explicitly selected);
/// * RESTORE — the real twin source resolves again (the recovery).
#[test]
fn broken_twin_errors_loudly_and_the_band_takes_over() {
    let dir = fixture("redgreen");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/core"),
        "package = \"core\"\nversion = \"0.1.0\"\n",
    );

    // GREEN: the production twin resolves.
    let table = enumerate_table(&dir).expect("the fixture enumerates");
    let green = run_resolve_twin_vm(&dir, &table, 512, RESOLVE_TARGET_SOURCE)
        .expect("the real twin resolves");
    assert!(
        matches!(green, TwinOutcome::Ok { .. }),
        "the green face resolves"
    );

    // RED: the corrupted twin fails loudly on the twin position —
    // the same program shape, the resolver forced to reject.
    let broken = RESOLVE_TARGET_SOURCE.replace(
        "define(result, pair(\"rs\", pair(rs_run(), nil)));",
        "define(result, pair(\"rs\", pair(rs_err_depth(1, quote((114, 101, 100))), nil)));",
    );
    assert_ne!(broken, RESOLVE_TARGET_SOURCE, "the corruption applies");
    let red = run_resolve_twin_vm(&dir, &table, 512, &broken).expect("the broken twin runs");
    assert!(
        matches!(red, TwinOutcome::Err(ref message) if message.contains("depth limit")),
        "the broken twin renders its (wrong) rejection loudly: {red:?}"
    );

    // BAND: the rust arm completes the same resolution.
    let (ok_rust, out_rust, err_rust) = kp_run(&dir, Some("rust"));
    assert!(ok_rust, "the band takes over: {err_rust}");
    assert!(
        out_rust.contains("core 0.1.0"),
        "the band resolves: {out_rust}"
    );

    // RESTORE: the real twin source resolves again.
    let restore = run_resolve_twin_vm(&dir, &table, 512, RESOLVE_TARGET_SOURCE)
        .expect("the restored twin resolves");
    assert!(
        matches!(restore, TwinOutcome::Ok { .. }),
        "the recovery face resolves"
    );
    let _ = std::fs::remove_dir_all(&dir);
}

//! `kp` — the kerf package tool (W-3.10 driver face; hosted in
//! kerf-driver since the W-PKG-SELFHOST blade 3b — the twin arm
//! needs the pipeline face, and the parity-harness edge
//! kerf-driver -> kerf-pkg forbids the reverse, SOP §18.5 DAG).
//!
//! Hand-rolled argument parsing (SOP §18 — no external deps). The
//! one v0 command:
//!
//! ```text
//! kp resolve <dir>    resolve the package graph at <dir>,
//!                     print the topological order, write <dir>/kerf.lock
//! ```
//!
//! The production position (the blade 3b switch, the r145-r148
//! read/expand/check/compile precedent): the resolver logic rides
//! the five-piece `.ktf` twin composition on the VM — the
//! dependency-free Rust resolver stays as the oracle and the
//! rollback band. The `KERF_PKG_SELFHOST` environment variable
//! selects the position for the process entry — `twin` (the
//! default, including unset) or `rust` (the rollback); any other
//! value is a hard error (fail-closed, the `KERF_READ_SEGMENT`
//! precedent: a silently ignored position override would be a
//! lie). A twin-arm failure is rendered LOUDLY — never a silent
//! fallback to the Rust arm (§2.3-4 — errors over silence).

use std::path::Path;
use std::process::ExitCode;

use kerf_driver::pkg_selfhost::{
    RESOLVE_TARGET_SOURCE, TwinOutcome, enumerate_table, run_resolve_twin_vm,
};
use kerf_pkg::{Lockfile, PkgError, RESOLUTION_DEPTH_LIMIT, resolve_with_limit};

/// Which implementation resolves the package graph (the blade 3b
/// production position).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SelfhostPosition {
    /// The five-piece `.ktf` twin composition on the VM — the
    /// switched production default.
    Twin,
    /// The Rust resolver — the rollback band (and the parity
    /// oracle).
    Rust,
}

impl SelfhostPosition {
    /// Parse one `KERF_PKG_SELFHOST` value (the process entry's
    /// fail-closed face): `twin` and `rust` are the only legal
    /// spellings.
    fn parse_value(raw: &str) -> Result<Self, String> {
        match raw.trim() {
            "twin" => Ok(SelfhostPosition::Twin),
            "rust" => Ok(SelfhostPosition::Rust),
            other => Err(format!(
                "invalid value for KERF_PKG_SELFHOST: `{other}` (expected `twin` or `rust`)"
            )),
        }
    }

    /// Read the environment override: unset keeps the switched
    /// default (`Twin`); a set value must parse (the caller reports
    /// and exits — never a silent ignore).
    fn from_env() -> Result<Self, String> {
        match std::env::var("KERF_PKG_SELFHOST") {
            Ok(raw) => Self::parse_value(&raw),
            Err(std::env::VarError::NotPresent) => Ok(SelfhostPosition::Twin),
            Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
                "invalid value for KERF_PKG_SELFHOST: `{}` (expected `twin` or `rust`)",
                raw.to_string_lossy()
            )),
        }
    }
}

/// The depth-guardrail override of the resolver (the K162 face of
/// the W-REC-DEPTH blade 2, the `kp` twin of the compiler CLI's
/// `DepthLimits::from_env`): unset keeps the conservative default;
/// a set value must be a positive integer or the run aborts
/// (fail-closed).
fn resolve_depth_from_env() -> Result<u32, String> {
    match std::env::var("KERF_PKG_RESOLVE_DEPTH_LIMIT") {
        Ok(raw) => match raw.parse::<u32>() {
            Ok(n) if n > 0 => Ok(n),
            _ => Err(format!(
                "invalid value for KERF_PKG_RESOLVE_DEPTH_LIMIT: `{raw}` (expected a positive integer)"
            )),
        },
        Err(std::env::VarError::NotPresent) => Ok(RESOLUTION_DEPTH_LIMIT),
        Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
            "invalid value for KERF_PKG_RESOLVE_DEPTH_LIMIT: `{}` (expected a positive integer)",
            raw.to_string_lossy()
        )),
    }
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.as_slice() {
        [cmd, dir] if cmd == "resolve" => run_resolve(Path::new(dir)),
        [flag] if flag == "--help" || flag == "-h" || flag == "help" => {
            print_usage();
            ExitCode::SUCCESS
        }
        _ => {
            print_usage();
            ExitCode::FAILURE
        }
    }
}

fn run_resolve(dir: &Path) -> ExitCode {
    let depth_limit = match resolve_depth_from_env() {
        Ok(limit) => limit,
        Err(message) => {
            eprintln!("kp: {message}");
            return ExitCode::FAILURE;
        }
    };
    let position = match SelfhostPosition::from_env() {
        Ok(position) => position,
        Err(message) => {
            eprintln!("kp: {message}");
            return ExitCode::FAILURE;
        }
    };
    match position {
        SelfhostPosition::Twin => run_twin_arm(dir, depth_limit),
        SelfhostPosition::Rust => run_rust_arm(dir, depth_limit),
    }
}

/// The twin arm: enumerate the layout, drive the five-piece
/// composition on the VM, print the order, write the lockfile —
/// the same stdout and the same lockfile text the Rust arm
/// produces (the parity harness proves them byte-identical; a
/// twin defect renders loudly, never a silent fallback).
fn run_twin_arm(dir: &Path, depth_limit: u32) -> ExitCode {
    let table = match enumerate_table(dir) {
        Ok(table) => table,
        Err(message) => {
            eprintln!("kp: {message}");
            return ExitCode::FAILURE;
        }
    };
    match run_resolve_twin_vm(dir, &table, depth_limit, RESOLVE_TARGET_SOURCE) {
        Ok(TwinOutcome::Ok { order, lockfile }) => {
            for (name, version, source) in &order {
                println!("{name} {version} ({source})");
            }
            match std::fs::write(dir.join("kerf.lock"), &lockfile) {
                Ok(()) => {
                    println!(
                        "wrote {} ({} package{})",
                        dir.join("kerf.lock").display(),
                        order.len(),
                        if order.len() == 1 { "" } else { "s" }
                    );
                    ExitCode::SUCCESS
                }
                Err(e) => {
                    eprintln!(
                        "kp: {}",
                        PkgError::Io {
                            op: "write lockfile".to_string(),
                            source: e.to_string(),
                        }
                    );
                    ExitCode::FAILURE
                }
            }
        }
        Ok(TwinOutcome::Err(message)) => {
            eprintln!("kp: {message}");
            ExitCode::FAILURE
        }
        Err(defect) => {
            eprintln!("kp: {defect}");
            ExitCode::FAILURE
        }
    }
}

/// The Rust arm — the rollback band (and the parity oracle): the
/// dependency-free resolver of kerf-pkg, verbatim.
fn run_rust_arm(dir: &Path, depth_limit: u32) -> ExitCode {
    match resolve_with_limit(dir, depth_limit) {
        Ok(resolution) => {
            for pkg in &resolution.order {
                println!("{} {} ({})", pkg.name, pkg.version, pkg.source);
            }
            match write_lockfile(dir, &resolution.lockfile) {
                Ok(()) => {
                    println!(
                        "wrote {} ({} package{})",
                        dir.join("kerf.lock").display(),
                        resolution.lockfile.packages.len(),
                        if resolution.lockfile.packages.len() == 1 {
                            ""
                        } else {
                            "s"
                        }
                    );
                    ExitCode::SUCCESS
                }
                Err(err) => {
                    eprintln!("kp: {err}");
                    ExitCode::FAILURE
                }
            }
        }
        Err(err) => {
            eprintln!("kp: {err}");
            ExitCode::FAILURE
        }
    }
}

/// Write the lockfile next to the root manifest (deterministic
/// text).
fn write_lockfile(dir: &Path, lockfile: &Lockfile) -> Result<(), PkgError> {
    let path = dir.join("kerf.lock");
    std::fs::write(&path, lockfile.to_text()).map_err(|e| PkgError::Io {
        op: "write lockfile".to_string(),
        source: e.to_string(),
    })
}

fn print_usage() {
    println!("usage: kp resolve <dir>");
    println!("  resolve the package graph at <dir> and write <dir>/kerf.lock");
    println!();
    println!("environment:");
    println!("  KERF_PKG_SELFHOST=twin|rust   the resolver position (default: twin)");
    println!(
        "  KERF_PKG_RESOLVE_DEPTH_LIMIT=N the depth guardrail (default: {RESOLUTION_DEPTH_LIMIT})"
    );
}

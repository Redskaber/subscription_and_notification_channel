//! The kp shell bridge — the W-PKG-SELFHOST blade 3b host face
//! (w-pkg-selfhost-window.md §4 blade row 3b): the package tool's
//! K20 channel between the filesystem and the five-piece `.ktf`
//! resolver composition.
//!
//! The division of labor (the window's constitutional ruling: the
//! IO shell and the guardrails are HOST-SERVICE faces, the
//! resolution LOGIC is the twin's):
//!
//! * the SHELL enumerates the layout (the root plus every
//!   libs-nested child directory), reads each `kerf.toml`, and
//!   carries the directory table — every manifest's parse happens
//!   inside the twin walk in oracle visit order, so the oracle's
//!   lazy discovery is preserved exactly (an unreadable or broken
//!   manifest only surfaces when the walk reaches its directory);
//! * the TWIN decides everything else — the three-color walk, the
//!   cycle paths, the depth cap, the name checks, the diamond
//!   verification, the topological order, and the lockfile text
//!   through the lockfile twin's own sort + render pipeline;
//! * the SHELL renders the twin's structured records into the
//!   oracle's `PkgError` Display lines (the message shapes live in
//!   ONE place — the Rust error family — and the parity harness
//!   proves the two arms byte-identical).
//!
//! Host-crate ruling (§18.5 DAG): the bridge lives in kerf-driver
//! because the twin arm needs the pipeline face, and the
//! parity-harness edge kerf-driver -> kerf-pkg forbids the reverse
//! edge — the `kp` binary moved here with it (the Rust logic arm
//! stays kerf-pkg's dependency-free lib, the oracle and the
//! rollback band).

use std::path::{Path, PathBuf};

use kerf_vm::{BufferIo, Heap, Value, Vm};

// ORCH blade 1 (O6): the four pkg-logic source embeddings retired
// from this module — the resolve assembly rides the import composer
// and the unit registry (target_corpus::selfhost_unit_source).
use crate::bootstrap::manifest_parity::render_mf_error;
use crate::bootstrap::target_corpus::target_byte_table_prefix;
use crate::bootstrap::vm_harness::{as_i64, as_str, harness_run_failure, need_fields, value_elems};
use crate::check_segment::CheckSegment;
use crate::diagnostic::Severity;
use crate::pipeline;
use crate::session::Session;

/// The W-PKG-SELFHOST blade 3 twin, part two (r159): the
/// dependency-graph resolver in its own target skin.
pub const RESOLVE_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/resolve.ktf");

// ---------------------------------------------------------------------------
// The directory table (the enumeration face)
// ---------------------------------------------------------------------------

/// One directory's manifest read outcome.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ManifestRead {
    /// The manifest read ok (its text — `read_to_string` guarantees
    /// UTF-8; invalid UTF-8 rides the io arm on both sides of the
    /// bridge).
    Ok(String),
    /// `kerf.toml` is absent (the oracle's `ManifestNotFound`).
    NotFound,
    /// The read failed otherwise (the oracle's `Io` — the message is
    /// captured verbatim at the one read site both arms share).
    Io(String),
}

/// One enumerated directory: the root-relative path (the lockfile
/// `source` strings verbatim) and its manifest read outcome.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DirEntry {
    /// The root-relative path — `"."` for the root, `libs/a`,
    /// `libs/a/libs/b` (the same construction rule `rs_dep_dir`
    /// follows inside the twin).
    pub rel: String,
    /// The manifest read outcome.
    pub read: ManifestRead,
}

/// Enumerate the package layout under `root`: the root itself plus
/// every libs-nested child directory (a dependency's directory is
/// always `<parent>/libs/<name>` — directories outside the
/// convention are unreachable by the oracle and never enter the
/// table). Children sort by name for deterministic tables (the
/// twin only ever looks entries up, so the order is a debugging
/// convenience, never a semantic input).
pub fn enumerate_table(root: &Path) -> Result<Vec<DirEntry>, String> {
    let mut out = Vec::new();
    visit_dir(root, ".", &mut out)?;
    Ok(out)
}

fn visit_dir(path: &Path, rel: &str, out: &mut Vec<DirEntry>) -> Result<(), String> {
    let read = match std::fs::read_to_string(path.join("kerf.toml")) {
        Ok(text) => ManifestRead::Ok(text),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => ManifestRead::NotFound,
        Err(e) => ManifestRead::Io(e.to_string()),
    };
    out.push(DirEntry {
        rel: rel.to_string(),
        read,
    });
    let libs = path.join("libs");
    if libs.is_dir() {
        let mut children: Vec<PathBuf> = std::fs::read_dir(&libs)
            .map_err(|e| format!("enumerate {}: {e}", libs.display()))?
            .filter_map(|e| e.ok().map(|e| e.path()))
            .filter(|p| p.is_dir())
            .collect();
        children.sort();
        for child in children {
            let name = child
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .to_string();
            let child_rel = if rel == "." {
                format!("libs/{name}")
            } else {
                format!("{rel}/libs/{name}")
            };
            visit_dir(&child, &child_rel, out)?;
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The program assembly (the first five-piece composition)
// ---------------------------------------------------------------------------

/// One byte table as target-skin quoted text (the BR-25 single-byte
/// trailing-comma rule; the empty table rides `nil` — the datum
/// face of the empty list).
fn quoted_byte_table(bytes: &[u8]) -> String {
    if bytes.is_empty() {
        "nil".to_string()
    } else if bytes.len() == 1 {
        format!("({},)", bytes[0])
    } else {
        let parts: Vec<String> = bytes.iter().map(|b| b.to_string()).collect();
        format!("({},)", parts.join(", "))
    }
}

/// One table entry — `(dir status payload)` — as quoted text.
fn quoted_entry(entry: &DirEntry) -> String {
    let (status, payload) = match &entry.read {
        ManifestRead::Ok(text) => ("0", quoted_byte_table(text.as_bytes())),
        ManifestRead::NotFound => ("1", "nil".to_string()),
        ManifestRead::Io(message) => ("2", quoted_byte_table(message.as_bytes())),
    };
    format!(
        "({}, {}, {})",
        quoted_byte_table(entry.rel.as_bytes()),
        status,
        payload
    )
}

/// The assembled five-piece resolver program (W-SELFHOST-ORCH
/// blade 1, O5/O6): the channels (the root manifest text — `nil`
/// when the root read failed — the depth cap, the directory table,
/// the semver/lockfile channel placeholders) consolidated at the
/// assembly head, then the composed chain — resolve.ktf's own
/// `import` declarations bring the std Error instance and the pkg
/// four in dependency order (micro-toml → semver → manifest →
/// lockfile → resolve), the composer reproducing the retired
/// host-side splice's file chain byte-identically. The manifest
/// twin's top-level `mf_verdict` IS the root projection; the
/// resolver's final `result` define overrides every earlier one
/// (the sequential-store semantics, the manifest assembly
/// precedent). The channel repositioning is disclosed in the
/// window record (O6): the old layout interleaved con/ver between
/// the micro-toml and semver twins and lk_entries_in between the
/// manifest and lockfile twins — pure import splicing cannot
/// interleave; the channels are lazily-read defines (the verdict
/// tail evaluates them at run time), position-inert, and the
/// twin/oracle product faces pin it.
pub fn resolve_twin_program(table: &[DirEntry], depth: u32, resolve_src: &str) -> String {
    let source_prefix = match table.first().map(|e| &e.read) {
        Some(ManifestRead::Ok(text)) => target_byte_table_prefix(text),
        _ => "define(source_bytes, quote(nil));\n".to_string(),
    };
    let entries: Vec<String> = table.iter().map(quoted_entry).collect();
    let table_define = if entries.is_empty() {
        "define(rs_table, quote(nil));\n".to_string()
    } else {
        format!("define(rs_table, quote(({},)));\n", entries.join(", "))
    };
    format!(
        "{source_prefix}define(rs_depth, {depth});\n{table_define}\
         define(con_bytes, quote(nil));\ndefine(ver_bytes, quote(nil));\n\
         define(lk_entries_in, quote(nil));\n{}",
        crate::bootstrap::target_corpus::compose_selfhost(resolve_src)
    )
}

// ---------------------------------------------------------------------------
// The outcome + the record decoding
// ---------------------------------------------------------------------------

/// The twin resolver's decoded outcome: the structured success
/// (the topological order plus the lockfile text) or the rendered
/// rejection (the `PkgError` Display line — the parity harness
/// proves it byte-identical to the oracle's own).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TwinOutcome {
    /// The resolution: `(name, version, source)` per package in
    /// topological order (dependencies first, root last) plus the
    /// deterministic lockfile text.
    Ok {
        /// The resolved order.
        order: Vec<(String, String, String)>,
        /// The lockfile text (the twin's own render).
        lockfile: String,
    },
    /// The rendered rejection (the oracle's `PkgError` Display
    /// text, verbatim).
    Err(String),
}

/// The manifest path of one enumerated directory — the same
/// `Path::join` construction the oracle's `read_manifest` performs
/// (`root/kerf.toml` for the root, `root/<rel>/kerf.toml`
/// otherwise).
fn manifest_path(root: &Path, rel: &str) -> PathBuf {
    if rel == "." {
        root.join("kerf.toml")
    } else {
        root.join(rel).join("kerf.toml")
    }
}

/// The dependency directory path — the oracle's
/// `dir.join("libs").join(name)` construction.
fn dep_dir_path(root: &Path, parent_rel: &str, name: &str) -> PathBuf {
    if parent_rel == "." {
        root.join("libs").join(name)
    } else {
        root.join(parent_rel).join("libs").join(name)
    }
}

/// The manifest text of one enumerated directory (the decode's
/// slicing source — an `mf-err` record's spans point into it).
fn table_text<'a>(table: &'a [DirEntry], rel: &str) -> Result<&'a str, String> {
    table
        .iter()
        .find(|e| e.rel == rel)
        .and_then(|e| match &e.read {
            ManifestRead::Ok(text) => Some(text.as_str()),
            _ => None,
        })
        .ok_or_else(|| format!("harness defect: no manifest text for `{rel}`"))
}

/// Decode one byte-table value into its String.
fn decode_bytes(value: &Value, heap: &Heap, what: &str) -> Result<String, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("{what}: {err}"))?;
    let mut out = Vec::with_capacity(elems.len());
    for e in &elems {
        let b = as_i64(e).map_err(|err| format!("{what} byte: {err}"))?;
        if !(0..=255).contains(&b) {
            return Err(format!("{what}: non-byte value {b}"));
        }
        out.push(b as u8);
    }
    String::from_utf8(out).map_err(|err| format!("{what}: non-utf8 render: {err}"))
}

/// Render one constraint quad — `(maj min has pat)` — into its
/// canonical text (`X.Y.Z` when the patch component rode, `X.Y`
/// otherwise — the parsed-then-Displayed form).
fn con_text(quad: &[&Value]) -> Result<String, String> {
    need_fields(quad, 4, "constraint quad")?;
    let maj = as_i64(quad[0])?;
    let min = as_i64(quad[1])?;
    let has = as_i64(quad[2])?;
    let pat = as_i64(quad[3])?;
    if has == 1 {
        Ok(format!("{maj}.{min}.{pat}"))
    } else {
        Ok(format!("{maj}.{min}"))
    }
}

/// Decode the twin's `result` record — `("rs" verdict)` — into the
/// outcome. The verdict: `("ok" order lock-bytes)` or one of the
/// eight resolve-layer rejections (the rs_err constructors'
/// layouts, mirrored one field at a time). Shared by the parity
/// harness (both engines) and the production drive.
pub(crate) fn decode_rs_verdict(
    value: &Value,
    heap: &Heap,
    table: &[DirEntry],
    root: &Path,
) -> Result<TwinOutcome, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("verdict chain: {err}"))?;
    need_fields(&elems, 2, "resolve verdict")?;
    let head = as_str(elems[0]).map_err(|err| format!("verdict tag: {err}"))?;
    if head != "rs" {
        return Err(format!("harness defect: unknown verdict tag `{head}`"));
    }
    let verdict = value_elems(elems[1], heap).map_err(|err| format!("verdict body: {err}"))?;
    need_fields(&verdict, 2, "resolve record")?;
    let tag = as_str(verdict[0]).map_err(|err| format!("resolve tag: {err}"))?;
    if tag == "ok" {
        // ("ok" order lock-bytes)
        let order_elems = value_elems(verdict[1], heap)?;
        let mut order = Vec::with_capacity(order_elems.len());
        for entry in &order_elems {
            let e = value_elems(entry, heap)?;
            need_fields(&e, 3, "order entry")?;
            let name = decode_bytes(e[0], heap, "order name")?;
            let triple = value_elems(e[1], heap)?;
            need_fields(&triple, 3, "version triple")?;
            let version = format!(
                "{}.{}.{}",
                as_i64(triple[0])?,
                as_i64(triple[1])?,
                as_i64(triple[2])?
            );
            let source = decode_bytes(e[2], heap, "order source")?;
            order.push((name, version, source));
        }
        let lockfile = decode_bytes(verdict[2], heap, "the rendered lockfile")?;
        Ok(TwinOutcome::Ok { order, lockfile })
    } else if tag == "err" {
        let rec = &verdict[1..];
        let kind = as_str(rec[0]).map_err(|err| format!("resolve kind: {err}"))?;
        match kind {
            "manifest-not-found" => {
                need_fields(rec, 2, "manifest-not-found record")?;
                let rel = decode_bytes(rec[1], heap, "manifest dir")?;
                Ok(TwinOutcome::Err(format!(
                    "manifest not found: {}",
                    manifest_path(root, &rel).display()
                )))
            }
            "io" => {
                need_fields(rec, 3, "io record")?;
                let source = decode_bytes(rec[2], heap, "io message")?;
                Ok(TwinOutcome::Err(format!("read manifest: {source}")))
            }
            "mf-err" => {
                // ("err" "mf-err" dir raw-mf-record)
                need_fields(rec, 3, "mf-err record")?;
                let rel = decode_bytes(rec[1], heap, "manifest dir")?;
                let text = table_text(table, &rel)?;
                let file = manifest_path(root, &rel).display().to_string();
                let raw = value_elems(rec[2], heap)?;
                let rendered = render_mf_error(&raw, heap, text, &file)?;
                Ok(TwinOutcome::Err(
                    rendered
                        .trim_end()
                        .strip_prefix("ERR ")
                        .unwrap_or(&rendered)
                        .to_string(),
                ))
            }
            "dep-dir-not-found" => {
                need_fields(rec, 3, "dep-dir-not-found record")?;
                let name = decode_bytes(rec[1], heap, "dependency name")?;
                let parent = decode_bytes(rec[2], heap, "parent dir")?;
                Ok(TwinOutcome::Err(format!(
                    "dependency directory for \"{name}\" not found: {}",
                    dep_dir_path(root, &parent, &name).display()
                )))
            }
            "cycle" => {
                need_fields(rec, 2, "cycle record")?;
                let names = value_elems(rec[1], heap)?;
                let mut parts = Vec::with_capacity(names.len());
                for n in &names {
                    parts.push(decode_bytes(n, heap, "cycle name")?);
                }
                Ok(TwinOutcome::Err(format!(
                    "dependency cycle detected: {}",
                    parts.join(" -> ")
                )))
            }
            "name-mismatch" => {
                need_fields(rec, 4, "name-mismatch record")?;
                let rel = decode_bytes(rec[1], heap, "manifest dir")?;
                let expected = decode_bytes(rec[2], heap, "expected name")?;
                let declared = decode_bytes(rec[3], heap, "declared name")?;
                Ok(TwinOutcome::Err(format!(
                    "{}: directory is named \"{expected}\" but the manifest declares package \"{declared}\"",
                    manifest_path(root, &rel).display()
                )))
            }
            "version-conflict" => {
                // ("err" "version-conflict" name triple imposed)
                need_fields(rec, 4, "version-conflict record")?;
                let name = decode_bytes(rec[1], heap, "conflict name")?;
                let triple = value_elems(rec[2], heap)?;
                need_fields(&triple, 3, "version triple")?;
                let version = format!(
                    "{}.{}.{}",
                    as_i64(triple[0])?,
                    as_i64(triple[1])?,
                    as_i64(triple[2])?
                );
                let imposed = value_elems(rec[3], heap)?;
                let mut parts = Vec::with_capacity(imposed.len());
                for dc in &imposed {
                    let pair = value_elems(dc, heap)?;
                    need_fields(&pair, 2, "imposed pair")?;
                    let dependent = decode_bytes(pair[0], heap, "dependent name")?;
                    let quad = value_elems(pair[1], heap)?;
                    parts.push(format!("\"{dependent}\" requires {}", con_text(&quad)?));
                }
                Ok(TwinOutcome::Err(format!(
                    "version conflict for \"{name}\": resolved {version}, but {}",
                    parts.join(", ")
                )))
            }
            "depth" => {
                need_fields(rec, 3, "depth record")?;
                let limit = as_i64(rec[1])?;
                let name = decode_bytes(rec[2], heap, "depth name")?;
                Ok(TwinOutcome::Err(format!(
                    "dependency chain under \"{name}\" exceeds the depth limit {limit}"
                )))
            }
            other => Err(format!("harness defect: unknown resolve kind `{other}`")),
        }
    } else {
        Err(format!("harness defect: unknown resolve tag `{tag}`"))
    }
}

// ---------------------------------------------------------------------------
// The production drive (the single-VM face — the twin arm's engine)
// ---------------------------------------------------------------------------

/// Drive the assembled resolver program on the VM (the production
/// engine — the same single-engine face the read segment's
/// production position rides; the check segment pins the Rust
/// checkers per the r147 TA-7 form, the assembled program being a
/// chain artifact whose check verdict only feeds the must-be-clean
/// assertion).
pub fn run_resolve_twin_vm(
    root: &Path,
    table: &[DirEntry],
    depth: u32,
    resolve_src: &str,
) -> Result<TwinOutcome, String> {
    let assembled = resolve_twin_program(table, depth, resolve_src);
    let mut session = Session::new();
    session.set_check_segment(CheckSegment::Rust);
    let program =
        pipeline::parse_with(&mut session, "kp-resolve-host", &assembled).map_err(|diags| {
            format!("selfhost defect: the assembled resolver failed to parse: {diags:?}")
        })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "selfhost defect: the assembled resolver failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("selfhost defect: the assembled resolver failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("selfhost defect: the vm rejected the resolver: {err}"))?;
    vm.run()
        .map_err(|err| harness_run_failure("vm", "resolver twin", &err))?;
    let value = vm
        .global("result")
        .ok_or_else(|| "selfhost defect: no `result` global on the vm engine".to_string())?;
    decode_rs_verdict(value, vm.heap(), table, root)
}

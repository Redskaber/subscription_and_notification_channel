//! kerf-driver — the compiler entry point / pipeline orchestration
//! (Layer 8, stage-0-plan row 0.8; TD-003 final resolution step).
//!
//! Charter: read -> expand -> {compile -> VM, eval} pipeline assembly,
//! session/file interning, the diagnostics rendering closure (TD-001
//! payoff — line/column derived at render time), and the CLI/REPL
//! surface. Stages interact through data contracts only (SOP §11);
//! errors are data (§12.2): every stage failure becomes a
//! [`Diagnostic`] and is rendered in one pass.
//!
//! Layout: `session` (file interning), `line_index` (the TD-001
//! byte-offset -> line/column derivation), `diagnostic` (the §8.7
//! structure, Stage 0 slice), `render` (rustc-flavored rendering),
//! `pipeline` (dual-engine orchestration), `target_skin` (the E5
//! skin map's Rust-side spelling contract — the production bridge
//! and the twin corpus share it), `parity` (the Stage 1.4
//! acceptance-corpus contract), `repl` (session-replay state
//! machine), `cli` (the `kerf` binary face), and `bootstrap/` (the
//! r122 unification: the whole selfhost twin surface — twin
//! embeddings, the four parity harnesses, the steady-state
//! injection chains, the composed chains, the fixpoint gates — one
//! directory, separated from this production face). The executable
//! entry is `src/main.rs` (bin name `kerf`).

pub mod bootstrap;
mod check_segment;
mod cli;
mod compile_segment;
mod diagnostic;
mod expand_segment;
mod line_index;
mod parity;
mod pipeline;
pub mod pkg_selfhost;
mod read_segment;
mod render;
mod repl;
mod session;
mod target_skin;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use bootstrap::abc_pipeline::{
    AbcReport, ArtifactRow, CCF_SLOTS, ChainProducts, abc_pipeline, ccf_check_source,
    ccf_compiler_source, ccf_expander_source, ccf_infer_dump, ccf_infer_source, ccf_lexer_source,
    ccf_parser_source, ccf_sources, chain_compile_ccf_via, compile_via, expand_via,
    infer_differential_holds, read_via, registered_infer_golden, rust_compile_ccf,
    steady_compiler_equivalence, structurally_anchored_divergence,
};
pub use bootstrap::compiler_parity::{
    cp_error_key, items_stream_prefix, oracle_analysis_dump, oracle_analysis_dump_typed,
    rebuild_bytecode,
};
pub use bootstrap::composed_full_chain::{ComposedLayer, dump_faithfulness_witness};
pub use bootstrap::composed_target_read_chain::{
    ComposedTargetReadReport, TargetReadLayer, composed_target_read_chain_on,
    composed_target_read_chain_parity, twin_front_end_read,
};
pub use bootstrap::expander_parity::{
    ParityError, error_parity_key as expand_error_parity_key, forms_stream_prefix,
    oracle_dump_items, reconstruct_expand_error,
};
pub use bootstrap::fixpoint::{
    FixpointProducts, FixpointReport, SemanticDigest, SemanticProtoDigest,
    fixpoint_products_target, fixpoint_selfhost_compiler_target, semantic_projection,
};
pub use bootstrap::import_composer::{ComposedProgram, ImportError, compose_imports};
pub use bootstrap::infer_parity::{
    PerSourceInferRun, RebuiltTdef, RebuiltTypedVerdict, infer_twin_per_source_dual,
    infer_twin_per_source_text_dual, items_stream_literal, oracle_infer_outcome,
    oracle_inference_axes, oracle_types_segment, rebuild_typed_verdict,
};
pub use bootstrap::lockfile_parity::{
    LOCKFILE_RENDER_CASES, LOCKFILE_RENDER_MULTI, LOCKFILE_RENDER_NONCANON, LOCKFILE_TARGET_SOURCE,
    LOCKFILE_TWIN_CASES, assembled_lockfile_target_source, lockfile_oracle_parse_dump,
    lockfile_oracle_render_dump, lockfile_parity, lockfile_render_parity, lockfile_twin_dump,
};
pub use bootstrap::manifest_parity::{
    MANIFEST_TARGET_SOURCE, MANIFEST_TWIN_CASES, assembled_manifest_target_source,
    manifest_oracle_dump, manifest_parity, manifest_twin_dump,
};
pub use bootstrap::micro_toml_parity::{
    MICRO_TOML_TARGET_SOURCE, MICRO_TOML_TWIN_CASES, micro_toml_oracle_dump, micro_toml_parity,
    micro_toml_twin_dump,
};
pub use bootstrap::resolve_parity::{
    deep_chain_case, resolve_oracle_dump, resolve_parity, resolve_parity_at, resolve_parity_cases,
    resolve_twin_dump,
};
pub use bootstrap::semver_parity::{
    SEMVER_TARGET_SOURCE, SEMVER_TWIN_CASES, semver_oracle_dump, semver_parity, semver_twin_dump,
};
pub use bootstrap::steady_compiler_chain::SteadyCompilerChain;
pub use bootstrap::steady_expander_chain::{
    STEADY_FORMS_NAME, SteadyExpanderChain, SteadyExpansion, forms_stream_literal,
    oracle_expansion_axes, per_source_route,
};
pub use bootstrap::steady_target_reader_chain::{
    STEADY_TARGET_SOURCE_NAME, STEADY_TP_TOKENS_NAME, SteadyTargetRead, SteadyTargetReaderChain,
};
pub use bootstrap::steady_typecheck_chain::{
    STEADY_ITEMS_NAME, SteadyCheckChain, SteadyTypecheckChain,
};
pub use bootstrap::target_corpus::{
    BUILD_TARGET_SOURCE, COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, INFER_TARGET_SOURCE,
    MACRO_TARGET_SOURCE, TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE,
    TYPECHECK_TARGET_SOURCE, assembled_build_source, assembled_compiler_target_source,
    assembled_expander_target_source, carrier_assembly_prefix, compose_selfhost,
    datum_target_spellable, forms_target_spellable, gate_b_bytecode, ktf_compile_rich,
    read_target_source_for_bootstrap, selfhost_unit_source, target_byte_table_prefix,
    target_forms_stream_prefix, target_items_stream_prefix,
};
pub use bootstrap::target_lexer_parity::{
    TARGET_LEXER_TWIN_CASES, target_lexer_parity, target_lexer_twin_dump, target_oracle_token_dump,
};
pub use bootstrap::target_parser_parity::{
    TARGET_PARSER_TWIN_CASES, target_parser_assembly_probe, target_parser_oracle_dump,
    target_parser_parity, target_parser_twin_dump,
};
pub use bootstrap::typecheck_parity::{
    check_twin_per_source_dual, decode_check_result, oracle_check_axes,
};
pub use bootstrap::vm_harness::{
    STD_ERROR_TARGET_SOURCE, byte_table_literal, byte_table_prefix, error_parity_key, oracle_dump,
};
pub use check_segment::{CheckSegment, production_check};
pub use cli::{Command, parse_args, run_cli, usage, version};
pub use compile_segment::{CompileSegment, ProductionCompileError, production_compile};
pub use diagnostic::{Diagnostic, DiagnosticCode, Severity};
pub use expand_segment::{ExpandSegment, ProductionExpandError, production_expand};
pub use line_index::LineIndex;
pub use parity::{
    AlphaMap, CorpusCase, EquivalenceReport, Expectation, Observed, alpha_item_equal,
    alpha_items_equal, parse_directive, validate, validate_all, validate_target,
};
pub use pipeline::{
    CheckOutcome, DepthLimits, EmitCOutcome, Engine, ParityReport, ParsedProgram, RunOutcome,
    check_source, check_source_with, emit_c_source, emit_c_source_with, parse_target,
    parse_target_with_injected, run_parity_source, run_parity_source_with, run_source,
    run_source_with,
};
pub use read_segment::{ProductionReadError, ReadSegment, production_read};
pub use render::{column_of, render_diagnostics};
pub use repl::{Repl, ReplEvent};
pub use session::Session;

// Since v0.28.0 coordinate types are imported directly from kerf-span
// (the no-forwarding rule, stage0.md §9.59; SOP §18.5 v15.2).

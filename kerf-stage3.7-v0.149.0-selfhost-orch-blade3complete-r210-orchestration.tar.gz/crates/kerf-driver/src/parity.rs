//! Parity contract surface — the Stage 1.4 subset-freeze skeleton
//! (stage-1-plan row 1.4; docs/stage0.md §9.45.6 and §9.25.4 BS-C).
//!
//! Stage 1.4 slice: the *dual-engine* equivalence face. The four
//! existing parity instances (the B3 reader parity, the E5 nine-leg
//! walk, the TD-032 cut points, the 1.3 HM pair) each hand-rolled
//! their comparison; this module is their structured unification —
//! an acceptance corpus of sources with in-file expectations
//! (the GCC torture `dg-*` / rustc ui-test pattern, §9.45.5),
//! validated through the real driver pipeline.
//!
//! Oracle theory (K15, §9.45.2): each case pairs the two engines
//! (the bytecode VM and the meta-circular evaluator) with one
//! expected outcome — the differential pair rules out engine drift,
//! the expectation pins the semantic truth. Bytecode-level equality
//! stays out of scope (the fixpoint window; BS-C layering).
//!
//! Expectation convention (subset-spec.md): the expected value of a
//! halting case is the halt value of its **last top-level define**
//! (define-only modules halt with `nil` as the program value; the
//! last define is the module's observable result — the same channel
//! the REPL reads through its `$repl:N` wrappers).
//!
//! The 1.5 dual-reader window extends the same report shape; no
//! reader abstraction is pre-built here (the §9.45.6 "not doing"
//! list — zero-signal windows stay closed).

use kerf_vm::BufferIo;

use crate::diagnostic::{Diagnostic, DiagnosticCode, Severity};
use crate::pipeline::{self, Engine, ParsedProgram};
use crate::session::Session;

/// What one corpus case expects the pipeline to do with its source.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Expectation {
    /// Both engines halt and the last top-level define holds this
    /// structural repr (the `parity_repr` form: ints in decimal,
    /// floats in `Debug` form, `true`/`false`, `"quoted"` strings,
    /// `nil`, `(a . b)` pairs, `#<closure>`, `#<builtin:name>`).
    Value(String),
    /// The reader rejects the source (a `kerf-read` diagnostic).
    ParseError,
    /// The expander or the module loader rejects the program (a
    /// `kerf-expand` diagnostic — loader failures render under the
    /// expand tag through the Stage 0.9 wiring).
    ExpandError,
    /// The checker passes but the pipeline rejects the program at
    /// compile (a `kerf-compile` diagnostic — the product judge; the
    /// extern C-domain floor rides here since the r123
    /// re-attribution, W-CSYM-EXPR ruling b). Rejection precedes
    /// both engines.
    CompileError,
    /// The conservative checker reports error-level findings with
    /// exactly these E0xxx codes (order-insensitive set equality).
    TypeError(Vec<String>),
    /// The checker passes but both engines reject the program at
    /// runtime (dual-engine error agreement).
    RuntimeError,
    /// The checker reports warning-level findings only (exactly
    /// these codes) and both engines halt; the last top-level
    /// define holds this structural repr.
    Warning { codes: Vec<String>, value: String },
}

impl std::fmt::Display for Expectation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Expectation::Value(repr) => write!(f, "halt with `{repr}`"),
            Expectation::ParseError => f.write_str("read rejection"),
            Expectation::ExpandError => f.write_str("expand rejection"),
            Expectation::CompileError => f.write_str("compile rejection"),
            Expectation::TypeError(codes) => {
                write!(f, "checker rejection {codes:?}")
            }
            Expectation::RuntimeError => f.write_str("runtime rejection on both engines"),
            Expectation::Warning { codes, value } => {
                write!(f, "warnings {codes:?} then halt with `{value}`")
            }
        }
    }
}

/// One acceptance-corpus case: a name, its source text, and the
/// expectation parsed from the source's `;; expect:` directive line.
///
/// The directive grammar (subset-spec.md):
/// - `;; expect: value <repr>`
/// - `;; expect: parse-error`
/// - `;; expect: expand-error`
/// - `;; expect: compile-error`
/// - `;; expect: type-error <code> <code>...`
/// - `;; expect: runtime-error`
/// - `;; expect: warning <code>... value <repr>`
///
/// Two matching conventions (§9.74 PAR-3/PAR-4, made explicit):
/// - **Multiset matching.** The `type-error` and `warning` code
///   lists compare as *multisets* — order-insensitive, duplicates
///   significant. A program the checker reports with the same code
///   twice (two separate `E0009` sites, never short-circuited) needs
///   that code written twice in the directive; a duplicate on one
///   side only is a mismatch. The GCC `dg-error` one-directive-one-
///   message and rustc compiletest's per-expectation `found` slots
///   are the same semantics (K157/K158).
/// - **`value` implies zero warnings.** The `value` form is a dual
///   assertion: the halt repr matches AND the checker produced no
///   warning-level findings. A program that halts correctly while
///   carrying warnings (e.g. a shadowing `E0008`) fails a `value`
///   expectation — the `warning` form is the way to expect such a
///   program.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CorpusCase<'a> {
    /// The case name (diagnostics attribute here; conventionally the
    /// source file stem, e.g. `pos-003-closures`).
    pub name: &'a str,
    /// The full source text, directive line included.
    pub source: &'a str,
    /// The parsed expectation.
    pub expectation: Expectation,
}

impl<'a> CorpusCase<'a> {
    /// Build a case from its name and source, parsing the directive
    /// line (the first line of the source). Errors carry the case
    /// name and the directive problem (report over silence).
    pub fn from_source(name: &'a str, source: &'a str) -> Result<Self, String> {
        let directive_line = source.lines().next().unwrap_or("");
        let expectation = parse_directive(directive_line)
            .map_err(|problem| format!("case `{name}`: {problem}"))?;
        Ok(Self {
            name,
            source,
            expectation,
        })
    }
}

/// What the pipeline actually did with a case's source.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Observed {
    /// Both engines halted and agreed; the last top-level define
    /// held this structural repr.
    Halted { last_repr: String },
    /// The pipeline rejected the source at this stage (the stable
    /// tag of the first diagnostic: `kerf-read`, `kerf-expand`,
    /// `kerf-compile`, `kerf-runtime`, or an E0xxx checker code).
    Rejected { stage: String, codes: Vec<String> },
}

impl std::fmt::Display for Observed {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Observed::Halted { last_repr } => write!(f, "halt with `{last_repr}`"),
            Observed::Rejected { stage, codes } => {
                if codes.is_empty() {
                    write!(f, "rejection at `{stage}`")
                } else {
                    write!(f, "rejection at `{stage}` with {codes:?}")
                }
            }
        }
    }
}

/// The per-case equivalence report — the BS-C `EquivalenceReport`,
/// Stage 1.4 slice (one reader, dual engines).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EquivalenceReport {
    /// The case name (diagnostics attribute here).
    pub case: String,
    /// What the pipeline actually did.
    pub observed: Observed,
    /// Whether `observed` satisfied the case's expectation.
    pub matched: bool,
    /// Human-readable drift note when `matched` is false (the BS-C
    /// `SemanticDrift` slice: description first; span fields arrive
    /// with the 1.5 dual-reader window).
    pub drift: Option<String>,
}

impl EquivalenceReport {
    /// The failure line for batch renderers: `case: expected X, observed Y`.
    pub fn failure_line(&self) -> String {
        format!(
            "case `{}`: expected matched, observed {}",
            self.case, self.observed
        )
    }
}

/// Validate one corpus case through the real pipeline (parse ->
/// checker -> dual engines). Never panics: every divergence is a
/// `matched == false` report with a drift note (errors are data).
/// The r151 single-skin retarget: the entry reads through the target
/// reader (the corpus went single-skin at r150; the retired
/// S-expr `parse` entry left the tree with its reader).
pub fn validate(case: &CorpusCase) -> EquivalenceReport {
    let mut session = Session::new();
    let parsed = pipeline::parse_target(&mut session, "corpus.ktf", case.source);
    validate_parsed(case, parsed)
}

/// The target-skin twin of [`validate`] (switch-window-plan §1
/// step 5 — the corpus closeout rides BOTH skins): the same
/// expectation contract, the same typecheck/halt/runtime machinery,
/// with the front end reading through the NEW reader
/// (`pipeline::parse_target`). A case that passes `validate` and
/// `validate_target` on its source has held its expectation through
/// both entries — the corpus closeout's per-case contract.
pub fn validate_target(case: &CorpusCase) -> EquivalenceReport {
    let mut session = Session::new();
    let parsed = pipeline::parse_target(&mut session, "corpus.ktf", case.source);
    validate_parsed(case, parsed)
}

/// The shared validation body (both reader faces feed the same
/// spine — §9.25.4's single semantics under two skins).
fn validate_parsed(
    case: &CorpusCase,
    parsed: Result<ParsedProgram, Vec<Diagnostic>>,
) -> EquivalenceReport {
    let program = match parsed {
        Ok(program) => program,
        Err(diags) => return rejection_report(case, &diags),
    };
    let findings = program.typecheck();
    let errors = tags_of(&findings, Severity::Error);
    let warnings = tags_of(&findings, Severity::Warning);
    match &case.expectation {
        Expectation::Value(expected) => {
            if !errors.is_empty() {
                return mismatch(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                    format!("expected a halt, but the checker rejected the program: {errors:?}"),
                );
            }
            halt_report(case, &program, expected, &warnings, None)
        }
        Expectation::Warning { codes, value } => {
            if !errors.is_empty() {
                return mismatch(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                    format!("expected warnings, but the checker rejected the program: {errors:?}"),
                );
            }
            halt_report(case, &program, value, &warnings, Some(codes))
        }
        Expectation::TypeError(codes) => {
            if errors.is_empty() {
                return mismatch(
                    case,
                    Observed::Halted {
                        last_repr: String::new(),
                    },
                    format!("expected checker codes {codes:?}, but the checker passed"),
                );
            }
            if same_set(&errors, codes) {
                matched(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                )
            } else {
                mismatch(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                    format!("expected checker codes {codes:?}, observed {errors:?}"),
                )
            }
        }
        Expectation::CompileError => {
            if !errors.is_empty() {
                return mismatch(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                    format!(
                        "expected a compile rejection, but the checker rejected first: {errors:?}"
                    ),
                );
            }
            compile_rejection_report(case, &program)
        }
        Expectation::RuntimeError => {
            if !errors.is_empty() {
                return mismatch(
                    case,
                    Observed::Rejected {
                        stage: errors[0].clone(),
                        codes: errors.clone(),
                    },
                    format!(
                        "expected a runtime rejection, but the checker rejected first: {errors:?}"
                    ),
                );
            }
            runtime_rejection_report(case, &program)
        }
        Expectation::ParseError | Expectation::ExpandError => mismatch(
            case,
            Observed::Halted {
                last_repr: String::new(),
            },
            "expected a read/expand rejection, but the program parsed and expanded".to_owned(),
        ),
    }
}

/// Validate a whole corpus (the batch face — the BS-C
/// `validate_test_suite` shape).
pub fn validate_all<'a, I>(cases: I) -> Vec<EquivalenceReport>
where
    I: IntoIterator<Item = &'a CorpusCase<'a>>,
{
    cases.into_iter().map(validate).collect()
}

// ---------- shared helpers ----------

/// The stable tags of all diagnostics at one severity (in reporting
/// order — `kerf-read`-style stage tags, E0xxx codes for the
/// checker).
fn tags_of(diags: &[Diagnostic], severity: Severity) -> Vec<String> {
    diags
        .iter()
        .filter(|d| d.severity == severity)
        .map(|d| d.code.tag().to_owned())
        .collect()
}

/// Order-insensitive set equality for tag lists.
fn same_set(a: &[String], b: &[String]) -> bool {
    let mut left = a.to_vec();
    let mut right = b.to_vec();
    left.sort();
    right.sort();
    left == right
}

fn matched(case: &CorpusCase, observed: Observed) -> EquivalenceReport {
    EquivalenceReport {
        case: case.name.to_owned(),
        observed,
        matched: true,
        drift: None,
    }
}

fn mismatch(case: &CorpusCase, observed: Observed, drift: String) -> EquivalenceReport {
    EquivalenceReport {
        case: case.name.to_owned(),
        observed,
        matched: false,
        drift: Some(drift),
    }
}

/// Report a parse/expand/loader rejection against the case's
/// expectation (only `ParseError`, `ExpandError` and `CompileError`
/// can match a rejection — every other expectation diverged).
fn rejection_report(case: &CorpusCase, diags: &[Diagnostic]) -> EquivalenceReport {
    let stage = diags
        .first()
        .map(|d| d.code.tag().to_owned())
        .unwrap_or_else(|| "unknown".to_owned());
    let codes = tags_of(diags, Severity::Error);
    let observed = Observed::Rejected { stage, codes };
    let expected_stage = match &case.expectation {
        Expectation::ParseError => Some("kerf-read"),
        Expectation::ExpandError => Some("kerf-expand"),
        Expectation::CompileError => Some("kerf-compile"),
        _ => None,
    };
    match expected_stage {
        Some(want) if want == observed_stage_tag(&observed) => matched(case, observed),
        _ => {
            let drift = format!("expected {}, observed {}", case.expectation, observed);
            mismatch(case, observed, drift)
        }
    }
}

fn observed_stage_tag(observed: &Observed) -> &str {
    match observed {
        Observed::Rejected { stage, .. } => stage,
        Observed::Halted { .. } => "",
    }
}

/// The compile-rejection path (the r123 expectation kind): the
/// checker passed, so drive the full pipeline — the rejection must
/// carry the `kerf-compile` tag (the product judge; the extern
/// C-domain floor's compile face since the re-attribution). A halt
/// or any earlier/later stage is a drift, never a panic.
fn compile_rejection_report(case: &CorpusCase, program: &ParsedProgram) -> EquivalenceReport {
    let diags = match program.run_parity(&[]) {
        Err(diags) => diags,
        Ok(_) => {
            return mismatch(
                case,
                Observed::Halted {
                    last_repr: String::new(),
                },
                "expected a compile rejection, but both engines ran".to_owned(),
            );
        }
    };
    let stage = diags
        .first()
        .map(|d| d.code.tag().to_owned())
        .unwrap_or_else(|| "unknown".to_owned());
    let observed = Observed::Rejected {
        stage: stage.clone(),
        codes: tags_of(&diags, Severity::Error),
    };
    if stage == "kerf-compile" {
        matched(case, observed)
    } else {
        let drift = format!("expected {}, observed {}", case.expectation, observed);
        mismatch(case, observed, drift)
    }
}

/// The halt path: run both engines, assert the full dual-engine
/// contract, compare the last define's repr and the warning codes.
fn halt_report(
    case: &CorpusCase,
    program: &ParsedProgram,
    expected_repr: &str,
    warnings: &[String],
    expected_warnings: Option<&[String]>,
) -> EquivalenceReport {
    let parity = match program.run_parity(&[]) {
        Err(diags) => {
            let stage = diags
                .first()
                .map(|d| d.code.tag().to_owned())
                .unwrap_or_else(|| "unknown".to_owned());
            return mismatch(
                case,
                Observed::Rejected {
                    stage,
                    codes: tags_of(&diags, Severity::Error),
                },
                "expected both engines to halt, but the pipeline rejected the program".to_owned(),
            );
        }
        Ok(report) => report,
    };
    if !parity.agrees() {
        return mismatch(
            case,
            Observed::Halted {
                last_repr: parity.vm_repr.clone(),
            },
            format!(
                "engine drift: vm=`{}` eval=`{}` values_agree={} outputs_agree={} globals_agree={}",
                parity.vm_repr,
                parity.eval_repr,
                parity.values_agree,
                parity.outputs_agree,
                parity.globals_agree
            ),
        );
    }
    let Some((name, repr)) = parity.globals_repr.last() else {
        return mismatch(
            case,
            Observed::Halted {
                last_repr: String::new(),
            },
            "no top-level define to observe (the value convention reads the last define)"
                .to_owned(),
        );
    };
    let value_ok = repr == expected_repr;
    let warnings_ok = match expected_warnings {
        None => warnings.is_empty(),
        Some(codes) => same_set(warnings, codes),
    };
    if value_ok && warnings_ok {
        matched(
            case,
            Observed::Halted {
                last_repr: repr.clone(),
            },
        )
    } else {
        let mut drift = String::new();
        if !value_ok {
            drift.push_str(&format!(
                "last define `{name}` expected `{expected_repr}`, observed `{repr}`"
            ));
        }
        if !warnings_ok {
            if !drift.is_empty() {
                drift.push_str("; ");
            }
            match expected_warnings {
                None => drift.push_str(&format!("expected no warnings, observed {warnings:?}")),
                Some(codes) => drift.push_str(&format!(
                    "expected warning codes {codes:?}, observed {warnings:?}"
                )),
            }
        }
        mismatch(
            case,
            Observed::Halted {
                last_repr: repr.clone(),
            },
            drift,
        )
    }
}

/// The runtime-rejection path: both engines must reject the program
/// with a runtime-stage diagnostic (dual-engine error agreement).
fn runtime_rejection_report(case: &CorpusCase, program: &ParsedProgram) -> EquivalenceReport {
    let vm = program.run(
        Engine::Vm,
        Box::new(BufferIo::with_input(std::iter::empty::<String>())),
    );
    let eval = program.run(
        Engine::Eval,
        Box::new(BufferIo::with_input(std::iter::empty::<String>())),
    );
    let tag_of = |res: &Result<crate::pipeline::RunOutcome, Vec<Diagnostic>>| {
        res.as_ref()
            .err()
            .and_then(|diags| diags.first())
            .map(|d| d.code)
    };
    match (tag_of(&vm), tag_of(&eval)) {
        (Some(DiagnosticCode::Runtime), Some(DiagnosticCode::Runtime)) => matched(
            case,
            Observed::Rejected {
                stage: "kerf-runtime".to_owned(),
                codes: Vec::new(),
            },
        ),
        (Some(code), None) | (None, Some(code)) => mismatch(
            case,
            Observed::Rejected {
                stage: code.tag().to_owned(),
                codes: Vec::new(),
            },
            format!(
                "engine drift: one engine rejected (`{}`), the other halted",
                code.tag()
            ),
        ),
        (Some(a), Some(b)) if a != b => mismatch(
            case,
            Observed::Rejected {
                stage: a.tag().to_owned(),
                codes: Vec::new(),
            },
            format!(
                "engine drift: rejection stages differ (`{}` vs `{}`)",
                a.tag(),
                b.tag()
            ),
        ),
        (Some(code), Some(_)) => mismatch(
            case,
            Observed::Rejected {
                stage: code.tag().to_owned(),
                codes: Vec::new(),
            },
            format!(
                "expected a runtime rejection, rejected at `{}` before execution",
                code.tag()
            ),
        ),
        (None, None) => mismatch(
            case,
            Observed::Halted {
                last_repr: String::new(),
            },
            "expected a runtime rejection, but both engines halted".to_owned(),
        ),
    }
}

// ---------- the directive parser ----------

/// Parse one expectation directive line (`;; expect:` or `// expect:`).
///
/// The line must start with `;; expect:` (seed skin) or `// expect:`
/// (target skin — one expectation semantics, SR-1); the payload
/// grammar is the six-form set documented on [`CorpusCase`].
/// Type-error and warning codes are whitespace-separated E0xxx
/// tokens.
pub fn parse_directive(line: &str) -> Result<Expectation, String> {
    // The directive prefix is skin-neutral (W-SEXP-RETIRE blade 1,
    // w-sexp-retire-window SR-1): the seed skin's `;; expect:` and
    // the target skin's `// expect:` carry ONE expectation
    // semantics — the corpus file's own comment style picks the
    // glyph, never the contract.
    let rest = line
        .strip_prefix(";; expect:")
        .or_else(|| line.strip_prefix("// expect:"))
        .ok_or_else(|| "missing `;; expect:` directive line".to_owned())?;
    let rest = rest.trim();
    if rest.is_empty() {
        return Err("empty expectation directive".to_owned());
    }
    let mut parts = rest.split_whitespace();
    match parts.next() {
        Some("value") => {
            let repr = rest["value".len()..].trim();
            if repr.is_empty() {
                return Err("value expectation needs a repr payload".to_owned());
            }
            Ok(Expectation::Value(repr.to_owned()))
        }
        Some("parse-error") => Ok(Expectation::ParseError),
        Some("expand-error") => Ok(Expectation::ExpandError),
        Some("compile-error") => Ok(Expectation::CompileError),
        Some("runtime-error") => Ok(Expectation::RuntimeError),
        Some("type-error") => {
            let codes: Vec<String> = parts.map(str::to_owned).collect();
            if codes.is_empty() {
                return Err("type-error expectation needs at least one code".to_owned());
            }
            Ok(Expectation::TypeError(codes))
        }
        Some("warning") => {
            let (codes_part, value_part) = match rest.split_once(" value ") {
                Some((head, tail)) => (head, tail.trim()),
                None => return Err("warning expectation needs a `value <repr>` tail".to_owned()),
            };
            let codes: Vec<String> = codes_part["warning".len()..]
                .split_whitespace()
                .map(str::to_owned)
                .collect();
            if codes.is_empty() {
                return Err("warning expectation needs at least one code".to_owned());
            }
            if value_part.is_empty() {
                return Err("warning expectation needs a repr payload".to_owned());
            }
            Ok(Expectation::Warning {
                codes,
                value: value_part.to_owned(),
            })
        }
        other => Err(format!(
            "unknown expectation keyword `{}` (want value/parse-error/expand-error/compile-error/type-error/runtime-error/warning)",
            other.unwrap_or("")
        )),
    }
}

// ---------- the alpha-equivalence machinery (ruling H — the single source) ----------
//
// Relocated from the step-3 test file at step 5: the corpus sweep
// AND the skin transcoder's naming guard need the same face (the
// span-blind equality of expanded item trees, locally-bound names
// modulo a capture-avoiding bijection — the ruling-H skin-collision
// carrier: a twin's `rest` local rides `remaining` because `rest`
// is a skin-reserved builtin spelling, and keeping it would shadow
// the builtin inside the twin, a semantic break).

/// The bijection: locally-bound originals to twin spellings.
pub type AlphaMap = Vec<(kerf_span::Symbol, kerf_span::Symbol)>;

fn alpha_lookup<'a>(env: &'a AlphaMap, a: &kerf_span::Symbol) -> Option<&'a kerf_span::Symbol> {
    env.iter().find(|(x, _)| x == a).map(|(_, y)| y)
}

fn alpha_resolve(env: &AlphaMap, a: &kerf_span::Symbol, b: &kerf_span::Symbol) -> bool {
    match alpha_lookup(env, a) {
        Some(y) => y == b,
        None => a == b,
    }
}

fn alpha_extend(env: &mut AlphaMap, a: &kerf_span::Symbol, b: &kerf_span::Symbol) -> bool {
    if let Some(y) = alpha_lookup(env, a) {
        return y == b;
    }
    if env.iter().any(|(_, y)| y == b) {
        return false;
    }
    env.push((a.clone(), b.clone()));
    true
}

/// Span-blind alpha-equivalence of two expanded item trees.
pub fn alpha_items_equal(a: &[kerf_core::ModuleItem], b: &[kerf_core::ModuleItem]) -> bool {
    a.len() == b.len() && a.iter().zip(b).all(|(x, y)| alpha_item_equal(x, y))
}

/// One item pair (globals stay literal — the bijection is for
/// locally-bound names only).
pub fn alpha_item_equal(a: &kerf_core::ModuleItem, b: &kerf_core::ModuleItem) -> bool {
    use kerf_core::ModuleItem;
    match (a, b) {
        (
            ModuleItem::Define {
                name: n1,
                value: v1,
                ..
            },
            ModuleItem::Define {
                name: n2,
                value: v2,
                ..
            },
        ) => n1 == n2 && alpha_expr_equal(v1, v2, &mut Vec::new()),
        (ModuleItem::Require { module: m1, .. }, ModuleItem::Require { module: m2, .. }) => {
            m1 == m2
        }
        (
            ModuleItem::Module {
                name: n1,
                items: i1,
                ..
            },
            ModuleItem::Module {
                name: n2,
                items: i2,
                ..
            },
        ) => n1 == n2 && alpha_items_equal(i1, i2),
        (ModuleItem::DefineSyntax { name: n1, .. }, ModuleItem::DefineSyntax { name: n2, .. }) => {
            n1 == n2
        }
        // W-3.2: the extern contract — field-wise (the spans differ
        // between skins by construction; the contract fields are the
        // comparison face: ABI, names, signatures).
        (
            ModuleItem::Extern {
                abi: a1, items: i1, ..
            },
            ModuleItem::Extern {
                abi: a2, items: i2, ..
            },
        ) => {
            a1 == a2
                && i1.len() == i2.len()
                && i1
                    .iter()
                    .zip(i2)
                    .all(|(x, y)| x.name == y.name && x.params == y.params && x.ret == y.ret)
        }
        _ => false,
    }
}

fn alpha_expr_equal(a: &kerf_core::CoreExpr, b: &kerf_core::CoreExpr, env: &mut AlphaMap) -> bool {
    use kerf_core::CoreExpr;
    match (a, b) {
        (
            CoreExpr::Fn {
                params: p1,
                body: b1,
                ..
            },
            CoreExpr::Fn {
                params: p2,
                body: b2,
                ..
            },
        ) => {
            if p1.len() != p2.len() {
                return false;
            }
            let mark = env.len();
            let mut ok = true;
            for (x, y) in p1.iter().zip(p2) {
                ok = ok && alpha_extend(env, x, y);
            }
            ok = ok && alpha_expr_equal(b1, b2, env);
            env.truncate(mark);
            ok
        }
        (
            CoreExpr::Apply {
                func: f1, args: a1, ..
            },
            CoreExpr::Apply {
                func: f2, args: a2, ..
            },
        ) => {
            alpha_expr_equal(f1, f2, env)
                && a1.len() == a2.len()
                && a1.iter().zip(a2).all(|(x, y)| alpha_expr_equal(x, y, env))
        }
        (
            CoreExpr::If {
                cond: c1,
                then_branch: t1,
                else_branch: e1,
                ..
            },
            CoreExpr::If {
                cond: c2,
                then_branch: t2,
                else_branch: e2,
                ..
            },
        ) => {
            alpha_expr_equal(c1, c2, env)
                && alpha_expr_equal(t1, t2, env)
                && alpha_expr_equal(e1, e2, env)
        }
        (CoreExpr::Var { name: n1, .. }, CoreExpr::Var { name: n2, .. }) => {
            alpha_resolve(env, n1, n2)
        }
        (CoreExpr::Literal { value: v1, .. }, CoreExpr::Literal { value: v2, .. }) => v1 == v2,
        (
            CoreExpr::Assign {
                name: n1,
                value: v1,
                ..
            },
            CoreExpr::Assign {
                name: n2,
                value: v2,
                ..
            },
        ) => alpha_resolve(env, n1, n2) && alpha_expr_equal(v1, v2, env),
        (
            CoreExpr::Let {
                bindings: b1,
                body: y1,
                ..
            },
            CoreExpr::Let {
                bindings: b2,
                body: y2,
                ..
            },
        ) => {
            if b1.len() != b2.len() {
                return false;
            }
            let mark = env.len();
            let mut ok = true;
            for (x, y) in b1.iter().zip(b2) {
                ok = ok && alpha_expr_equal(&x.value, &y.value, env);
                ok = ok && alpha_extend(env, &x.name, &y.name);
            }
            ok = ok && alpha_expr_equal(y1, y2, env);
            env.truncate(mark);
            ok
        }
        (
            CoreExpr::Perform {
                effect: e1,
                args: a1,
                ..
            },
            CoreExpr::Perform {
                effect: e2,
                args: a2,
                ..
            },
        ) => {
            e1 == e2
                && a1.len() == a2.len()
                && a1.iter().zip(a2).all(|(x, y)| alpha_expr_equal(x, y, env))
        }
        (
            CoreExpr::Handle {
                body: y1,
                handlers: h1,
                ..
            },
            CoreExpr::Handle {
                body: y2,
                handlers: h2,
                ..
            },
        ) => {
            alpha_expr_equal(y1, y2, env)
                && h1.len() == h2.len()
                && h1.iter().zip(h2).all(|(x, y)| {
                    x.effect == y.effect && alpha_expr_equal(&x.handler, &y.handler, env)
                })
        }
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    //! Directive parser unit tests (the harness's own oracle — the
    //! integration faces live in the root tests/ tree).

    use super::*;

    #[test]
    fn directive_value_parses_repr_verbatim() {
        assert_eq!(
            parse_directive(";; expect: value 42"),
            Ok(Expectation::Value("42".to_owned()))
        );
        assert_eq!(
            parse_directive(";; expect: value (1 . (2 . nil))"),
            Ok(Expectation::Value("(1 . (2 . nil))".to_owned()))
        );
    }

    #[test]
    fn directive_bare_keywords() {
        assert_eq!(
            parse_directive(";; expect: parse-error"),
            Ok(Expectation::ParseError)
        );
        assert_eq!(
            parse_directive(";; expect: expand-error"),
            Ok(Expectation::ExpandError)
        );
        assert_eq!(
            parse_directive(";; expect: compile-error"),
            Ok(Expectation::CompileError)
        );
        assert_eq!(
            parse_directive(";; expect: runtime-error"),
            Ok(Expectation::RuntimeError)
        );
        // The r123 kind renders like its siblings (the failure-line
        // vocabulary: lowercase, no position fragments).
        assert_eq!(Expectation::CompileError.to_string(), "compile rejection");
    }

    #[test]
    fn directive_type_error_collects_codes() {
        assert_eq!(
            parse_directive(";; expect: type-error E0002 E0004"),
            Ok(Expectation::TypeError(vec![
                "E0002".to_owned(),
                "E0004".to_owned()
            ]))
        );
    }

    #[test]
    fn directive_warning_takes_codes_and_value() {
        assert_eq!(
            parse_directive(";; expect: warning E0008 value nil"),
            Ok(Expectation::Warning {
                codes: vec!["E0008".to_owned()],
                value: "nil".to_owned()
            })
        );
    }

    #[test]
    fn directive_rejects_missing_prefix() {
        assert!(parse_directive(";; expects: value 1").is_err());
        assert!(parse_directive("(define x 1)").is_err());
    }

    #[test]
    fn directive_rejects_empty_and_unknown() {
        assert!(parse_directive(";; expect:").is_err());
        assert!(parse_directive(";; expect: value").is_err());
        assert!(parse_directive(";; expect: halt-with 42").is_err());
        assert!(parse_directive(";; expect: type-error").is_err());
        assert!(parse_directive(";; expect: warning E0008").is_err());
    }

    #[test]
    fn same_set_is_order_insensitive() {
        let a = vec!["E0002".to_owned(), "E0004".to_owned()];
        let b = vec!["E0004".to_owned(), "E0002".to_owned()];
        assert!(same_set(&a, &b));
        assert!(!same_set(&a, &["E0002".to_owned()]));
    }

    #[test]
    fn same_set_is_multiset_duplicates_significant() {
        // §9.74 PAR-3: code lists compare as multisets — duplicates
        // significant. K157 (GCC `dg-error`, one directive one
        // message) and K158 (rustc compiletest, one `found` slot per
        // expectation) hold the same convention: a program the
        // checker reports with the same code twice needs that code
        // written twice; a duplicate on one side only is a mismatch.
        let dup = vec!["E0009".to_owned(), "E0009".to_owned()];
        let one = vec!["E0009".to_owned()];
        assert!(same_set(&dup, &dup), "equal multisets match");
        assert!(!same_set(&dup, &one), "an extra duplicate must not match");
        assert!(!same_set(&one, &dup), "a missing duplicate must not match");
    }

    #[test]
    fn value_expectation_fails_on_a_warning_program() {
        // §9.74 PAR-4: the `value` form asserts zero warnings too.
        // The source is the pos-028 rebinding program (the r151
        // single-skin retarget: the target-skin spelling — the block
        // sequencer with the expression-position assign) — it halts
        // with `1` while carrying an `E0008` warning; a bare `value`
        // expectation must fail it (fail-closed), and the drift must
        // name the warning divergence (the `warning` form is the way
        // to expect such a program).
        let src = "// expect: value 1\ndefine(result, { set(first, 5); 1 });\n";
        let case = CorpusCase::from_source("value-vs-warning", src).expect("the directive parses");
        let report = validate(&case);
        assert!(
            !report.matched,
            "a warned program must fail a value expectation"
        );
        assert!(
            report
                .drift
                .as_deref()
                .is_some_and(|d| d.contains("expected no warnings")),
            "the drift names the warning divergence: {:?}",
            report.drift
        );
    }

    #[test]
    fn corpus_case_parses_directive_from_source() {
        let src = ";; expect: value 3\n(define x (+ 1 2))\n";
        let case = CorpusCase::from_source("pos-001", src).expect("directive parses");
        assert_eq!(case.expectation, Expectation::Value("3".to_owned()));
        assert_eq!(case.name, "pos-001");
    }
}

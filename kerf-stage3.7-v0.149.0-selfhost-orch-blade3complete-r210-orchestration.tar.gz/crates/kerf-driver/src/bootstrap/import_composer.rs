//! The import composer (W-SELFHOST-ORCH blade 1 — O3): the
//! host-side generic composition mechanism behind the source-level
//! `import` declaration.
//!
//! The composition layer's discipline is the module loader's own
//! (docs/stage0.md §9.64): units enter the composition in
//! **first-seen order** (MOD-2), each unit contributes exactly once
//! (a later import of an already-composed unit contributes nothing
//! — the line vanishes), and the unit graph is walked with an
//! in-progress stack that closes every cycle fail-closed (the
//! three-color DFS's own shape, MOD-8). The composer is the import
//! form's ONLY consumer (O2): the expander, the loader, the
//! ModuleItem grammar, and the CP-1 items channel never see an
//! import form — the composed program is flat, exactly the program
//! the old host-side splicing produced.
//!
//! Byte-exactness (O6): a first-seen site's form span (the keyword
//! through the semicolon — the `use` span convention) is replaced
//! by the composed unit's text VERBATIM; the source's own gap after
//! the form (its newline) is preserved, which reproduces the
//! `format!("{A}\n{B}")` separator byte-for-byte whether or not the
//! unit's text ends in a newline. A seen-skip site's span plus the
//! one immediately following newline is removed (the whole line
//! vanishes). With the carriers' import declarations on consecutive
//! top-of-file lines the composed output is byte-identical to the
//! retired assembly concatenations — the parity goldens pin this.
//!
//! The seed-readability boundary (O3, revised in-round at blade 1:
//! the b-MUV discovery that the row-literal carriers —
//! micro-toml/lockfile, the r184/r196 row skin — sit beyond the
//! frozen Rust reader's grammar BY DESIGN, M49: their parsing is
//! the twin chain's production position): every import-CARRYING
//! source reads through the seed (the carriers' own files); a unit
//! the seed cannot read rides VERBATIM — spliced with no site walk,
//! disclosed in the product's `verbatim` list, and an import line
//! inside such a rider rejects loudly at the downstream expansion
//! face (the composed source's parse/expand owns the rejection) —
//! fail-closed end to end, never a silent skip.
//!
//! Trust boundary: the entry source is untrusted (the reader's own
//! nesting cap governs its read; the form walk is flat); the unit
//! graph is the closed compile-time registry (`include_str!`
//! constants — the recursion is bounded by the registry's size and
//! every cycle closes at the in-progress stack).

use std::collections::HashSet;
use std::fmt;

use kerf_reader::read_target_program;
use kerf_span::{FileId, Span};
use kerf_syntax::{StxDatum, SyntaxObject};

/// A composition failure (the fail-closed family — every shape
/// reports, none silently degrades).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ImportError {
    /// An import chain closed on itself; `path` lists the cycle in
    /// import order (`a -> b -> a`), the loader's own cycle face.
    ImportCycle { path: Vec<String> },
    /// An import naming a unit the registry never declared.
    ImportNotFound { name: String },
}

impl fmt::Display for ImportError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ImportError::ImportCycle { path } => {
                let names: Vec<String> = path.iter().map(|s| format!("`{s}`")).collect();
                write!(f, "import cycle detected: {}", names.join(" -> "))
            }
            ImportError::ImportNotFound { name } => {
                write!(f, "imported unit `{name}` is not registered")
            }
        }
    }
}

/// One composition's product: the composed text, the units that
/// contributed (first-seen order — the audit face the parity goldens
/// and the dedup assertions read), and the verbatim riders (the
/// seed-unreadable units that spliced with no site walk — the M49
/// disclosure: their parsing is the twin chain's production
/// position, and an import line inside one rejects loudly at the
/// downstream expansion face).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ComposedProgram {
    /// The composed source text (every walkable import site
    /// resolved).
    pub text: String,
    /// The contributing units, first-seen order (walked and
    /// verbatim riders alike).
    pub units: Vec<String>,
    /// The seed-unreadable riders, first-seen order (the M49
    /// boundary's audit face).
    pub verbatim: Vec<String>,
}

/// Compose one entry source: resolve every top-level `import`
/// declaration through `resolve` (the unit registry's face) under
/// the loader's first-seen discipline and return the composed
/// program.
pub fn compose_imports(
    entry: &str,
    resolve: &dyn Fn(&str) -> Option<String>,
) -> Result<ComposedProgram, ImportError> {
    let mut composer = Composer {
        resolve,
        seen: HashSet::new(),
        in_progress: Vec::new(),
        units: Vec::new(),
        verbatim: Vec::new(),
    };
    let text = composer.compose_source(entry, "the entry")?;
    Ok(ComposedProgram {
        text,
        units: composer.units,
        verbatim: composer.verbatim,
    })
}

struct Composer<'a> {
    resolve: &'a dyn Fn(&str) -> Option<String>,
    seen: HashSet<String>,
    in_progress: Vec<String>,
    units: Vec<String>,
    verbatim: Vec<String>,
}

impl Composer<'_> {
    /// Compose one source text (the entry or one unit): read it
    /// through the frozen reader; a source that READS walks its
    /// top-level import sites (the form-span splice below), and a
    /// source the seed cannot read rides VERBATIM (the O3-revised
    /// M49 boundary: the row-literal carriers' parsing is the twin
    /// chain's production position — the rider splices with no
    /// walk, its name joins the product's verbatim disclosure, and
    /// an import line inside it rejects loudly at the downstream
    /// expansion face).
    fn compose_source(&mut self, source: &str, name: &str) -> Result<String, ImportError> {
        let Ok(forms) = read_target_program(FileId(0), source) else {
            if name != "the entry" {
                self.verbatim.push(name.to_string());
            }
            return Ok(source.to_string());
        };
        let sites = import_sites(&forms);
        let bytes = source.as_bytes();
        let mut out = String::with_capacity(source.len() + 4096);
        let mut cursor = 0usize;
        for (start, end, unit) in sites {
            let replacement = self.compose_site(&unit)?;
            out.push_str(&source[cursor..start]);
            match replacement {
                Some(text) => {
                    // First-seen: the form's span becomes the unit's
                    // composed text verbatim; the source's own gap
                    // after the form survives as the separator.
                    out.push_str(&text);
                    cursor = end;
                }
                None => {
                    // Seen: the whole line goes — the span plus the
                    // one immediately following newline.
                    let mut skip = end;
                    if bytes.get(skip) == Some(&b'\n') {
                        skip += 1;
                    }
                    cursor = skip;
                }
            }
        }
        out.push_str(&source[cursor..]);
        Ok(out)
    }

    /// One import site's contribution: `None` for an already-seen
    /// unit (the line vanishes), the composed text otherwise.
    fn compose_site(&mut self, name: &str) -> Result<Option<String>, ImportError> {
        if self.seen.contains(name) {
            return Ok(None);
        }
        let text = self.compose_unit(name)?;
        Ok(Some(text))
    }

    /// Compose one unit by registry name: cycle-check against the
    /// in-progress stack, resolve, recurse into the unit's own
    /// imports, and record the first-seen order. The units list
    /// records at ENTRY (the pre-order first-seen discipline,
    /// §9.64 MOD-2 — the order the sites are encountered); the
    /// seen set marks at COMPLETION (a unit still in progress is
    /// not yet seen, so a back-edge reaches the cycle check, never
    /// a silent skip).
    fn compose_unit(&mut self, name: &str) -> Result<String, ImportError> {
        if let Some(start) = self.in_progress.iter().position(|n| n == name) {
            let mut path: Vec<String> = self.in_progress[start..].to_vec();
            path.push(name.to_string());
            return Err(ImportError::ImportCycle { path });
        }
        let source = (self.resolve)(name).ok_or_else(|| ImportError::ImportNotFound {
            name: name.to_string(),
        })?;
        self.units.push(name.to_string());
        self.in_progress.push(name.to_string());
        let composed = self.compose_source(&source, name);
        self.in_progress.pop();
        let composed = composed?;
        self.seen.insert(name.to_string());
        Ok(composed)
    }
}

/// Every top-level import site in a read form list: the
/// `(start, end, unit-name)` triples in source order. The reader
/// grammar maps every top-level `import` keyword form to exactly
/// `[import, string]` (the `use` machine's own guarantee), so a
/// differently-shaped import-headed form cannot occur — the walk
/// still judges the shape and fails loud on a grammar mismatch
/// (never a silent skip).
fn import_sites(forms: &[SyntaxObject]) -> Vec<(usize, usize, String)> {
    let mut sites = Vec::new();
    for form in forms {
        let StxDatum::List(items) = &form.datum else {
            continue;
        };
        let Some(StxDatum::Symbol(head)) = items.first().map(|o| &o.datum) else {
            continue;
        };
        if head.as_str() != "import" {
            continue;
        }
        if items.len() == 2 {
            if let StxDatum::String(name) = &items[1].datum {
                sites.push((span_start(form.span), span_end(form.span), name.to_string()));
                continue;
            }
        }
        panic!(
            "harness defect: the reader grammar maps every top-level \
             `import` form to [import, string] (a {}-item form appeared)",
            items.len()
        );
    }
    sites
}

fn span_start(span: Span) -> usize {
    span.start.0 as usize
}

fn span_end(span: Span) -> usize {
    span.end.0 as usize
}

#[cfg(test)]
mod tests {
    //! Unit tests for the composer's own discipline (the harness
    //! faces live in tests/v1/stage1/plan/import_composer_tests.rs —
    //! the real-unit goldens, the cross-stage consumption, and the
    //! negative family).

    use super::*;

    fn registry<'a>(units: &'a [(&'a str, &'a str)]) -> impl Fn(&str) -> Option<String> + 'a {
        move |name| {
            units
                .iter()
                .find(|(n, _)| *n == name)
                .map(|(_, src)| (*src).to_string())
        }
    }

    #[test]
    fn a_source_without_imports_composes_to_itself() {
        let entry = "define(x, 1);\n";
        let composed = compose_imports(entry, &registry(&[])).expect("a plain source composes");
        assert_eq!(composed.text, entry);
        assert!(composed.units.is_empty());
    }

    #[test]
    fn a_linear_chain_splices_byte_exactly() {
        // a imports b; b imports c — the composed entry reproduces
        // the format!("{C}\n{B}\n{A_REST}") concatenation
        // byte-for-byte (the O6 rule: the unit text verbatim, the
        // source's own gap newline as the separator).
        let unit_c = "define(c, 3);\n";
        let unit_b = "import \"c\";\ndefine(b, 2);\n";
        let entry = "import \"b\";\ndefine(a, 1);\n";
        let composed = compose_imports(entry, &registry(&[("b", unit_b), ("c", unit_c)]))
            .expect("the chain composes");
        // The byte-exact caliber: the composed output equals the
        // retired format! splice verbatim (each unit's own trailing
        // newline plus the gap's newline — the blank-line separation
        // the old concatenations carried).
        assert_eq!(
            composed.text,
            format!("{unit_c}\ndefine(b, 2);\n\ndefine(a, 1);\n")
        );
        assert_eq!(composed.units, vec!["b", "c"]);
    }

    #[test]
    fn a_diamond_dedups_first_seen() {
        // d imports b then c; b and c both import a — a contributes
        // ONCE (at its first-seen site, inside b), and c's own
        // import line of a vanishes entirely.
        let unit_a = "define(a, 1);\n";
        let unit_b = "import \"a\";\ndefine(b, 2);\n";
        let unit_c = "import \"a\";\ndefine(c, 3);\n";
        let entry = "import \"b\";\nimport \"c\";\ndefine(d, 4);\n";
        let composed = compose_imports(
            entry,
            &registry(&[("a", unit_a), ("b", unit_b), ("c", unit_c)]),
        )
        .expect("the diamond composes");
        assert_eq!(
            composed.text,
            format!("{unit_a}\ndefine(b, 2);\n\ndefine(c, 3);\n\ndefine(d, 4);\n")
        );
        assert_eq!(composed.units, vec!["b", "a", "c"]);
    }

    #[test]
    fn an_unknown_unit_rejects_fail_closed() {
        let entry = "import \"ghost\";\n";
        let err = compose_imports(entry, &registry(&[])).expect_err("an unregistered unit rejects");
        assert_eq!(
            err,
            ImportError::ImportNotFound {
                name: "ghost".to_string()
            }
        );
        assert_eq!(err.to_string(), "imported unit `ghost` is not registered");
    }

    #[test]
    fn a_two_unit_cycle_rejects_with_the_path() {
        let unit_a = "import \"b\";\ndefine(a, 1);\n";
        let unit_b = "import \"a\";\ndefine(b, 2);\n";
        let entry = "import \"a\";\n";
        let err = compose_imports(entry, &registry(&[("a", unit_a), ("b", unit_b)]))
            .expect_err("a cycle rejects");
        assert_eq!(
            err,
            ImportError::ImportCycle {
                path: vec!["a".to_string(), "b".to_string(), "a".to_string()]
            }
        );
    }

    #[test]
    fn a_self_import_rejects() {
        let unit_a = "import \"a\";\ndefine(a, 1);\n";
        let entry = "import \"a\";\n";
        let err =
            compose_imports(entry, &registry(&[("a", unit_a)])).expect_err("a self-import rejects");
        assert_eq!(
            err,
            ImportError::ImportCycle {
                path: vec!["a".to_string(), "a".to_string()]
            }
        );
    }

    #[test]
    fn a_repeated_import_of_one_unit_splices_once() {
        // The entry itself imports the same unit twice: the second
        // site's line vanishes (first-seen, the entry's own sites
        // included).
        let unit_a = "define(a, 1);\n";
        let entry = "import \"a\";\nimport \"a\";\ndefine(x, 2);\n";
        let composed =
            compose_imports(entry, &registry(&[("a", unit_a)])).expect("the repeat composes");
        assert_eq!(composed.text, "define(a, 1);\n\ndefine(x, 2);\n");
        assert_eq!(composed.units, vec!["a"]);
    }

    #[test]
    fn a_seed_unreadable_unit_rides_verbatim_with_disclosure() {
        // The O3-revised M49 boundary: a unit whose source sits
        // beyond the frozen reader's grammar (the row-literal
        // carriers' own shape — `[f: v]` rejects at the seed) rides
        // VERBATIM: spliced with no site walk, disclosed in the
        // product's verbatim list. An import line inside such a
        // rider survives into the composed text — the downstream
        // expansion face owns that rejection (fail-closed end to
        // end; the harness family pins the real carriers).
        let row_unit = "define(rec, [f: 1]);\n";
        let entry = "import \"row\";\ndefine(x, 1);\n";
        let composed = compose_imports(entry, &registry(&[("row", row_unit)]))
            .expect("the seed-unreadable unit rides verbatim");
        assert_eq!(composed.text, "define(rec, [f: 1]);\n\ndefine(x, 1);\n");
        assert_eq!(composed.units, vec!["row"]);
        assert_eq!(composed.verbatim, vec!["row"]);
    }

    #[test]
    fn a_readable_unit_walks_and_stays_out_of_the_verbatim_list() {
        let unit_a = "define(a, 1);\n";
        let entry = "import \"a\";\ndefine(x, 2);\n";
        let composed = compose_imports(entry, &registry(&[("a", unit_a)]))
            .expect("the walkable unit composes");
        assert_eq!(composed.text, "define(a, 1);\n\ndefine(x, 2);\n");
        assert_eq!(composed.units, vec!["a"]);
        assert!(composed.verbatim.is_empty());
    }
}

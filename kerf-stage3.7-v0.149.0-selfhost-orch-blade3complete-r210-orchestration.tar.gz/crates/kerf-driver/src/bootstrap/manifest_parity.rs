//! The manifest twin parity harness (W-PKG-SELFHOST blade 2, part
//! two — w-pkg-selfhost-window.md §4 blade row 2): the package
//! manager's kerf.toml projection, the COMPOSED program
//! `micro-toml.ktf + semver.ktf + manifest.ktf`, against the Rust
//! oracle `kerf_pkg::Manifest::parse` through the full `.ktf` chain
//! on BOTH engines — the eleventh selfhost twin, the third of the
//! kerf-pkg self-hosting family (K15: the differential oracle).
//!
//! The composition is the macro+expander assembly precedent carried
//! across three twins: the RS-1 `source_bytes` prefix, the blade 1
//! micro-TOML twin (its `mt_verdict` top-level define runs first),
//! placeholder channels for the semver twin's own top-level parse
//! (empty tables — its FUNCTION family is what this projection
//! calls), the blade 2 semver twin, and the manifest projection —
//! one program, sequential defines, the `result` global re-bound by
//! the last writer (the empirically pinned target-skin semantics).
//!
//! The dump grammar (one line):
//!
//! ```text
//!     (manifest "math-utils" (ver 0.1.0) (deps ("core-bits" (con 0.2)) ("strings" (con 0.1.5))))
//!     (manifest "p" (ver 0.1.0) (deps))
//!     ERR kerf.toml:3:1: "package" must be a string
//!     ERR kerf.toml: missing required key "package"
//! ```
//!
//! The deps render name-sorted (the oracle's BTreeMap iteration
//! order); the error axis renders the oracle's own `PkgError`
//! Display verbatim — `{file}:{line}: {message}` or `{file}:
//! {message}` for the un-anchored rejections — with manifest.rs's
//! format! templates reproduced exactly, including the nested
//! semver rejections (`dependency "a": invalid version "bad":
//! expected the X.Y or X.Y.Z form`) whose component spans this
//! harness slices from the same source on both sides.

use kerf_pkg::Manifest;
use kerf_vm::{Heap, Value};

use crate::bootstrap::micro_toml_parity::{MICRO_TOML_TARGET_SOURCE, render_mt_error, span_text};
use crate::bootstrap::semver_parity::SEMVER_TARGET_SOURCE;
use crate::bootstrap::target_corpus::target_byte_table_prefix;
use crate::bootstrap::vm_harness::{
    STD_ERROR_TARGET_SOURCE, as_i64, as_str, drive_vm_only, first_diff, need_fields, value_elems,
};

// ---------------------------------------------------------------------------
// The twin source embedding
// ---------------------------------------------------------------------------

/// The W-PKG-SELFHOST blade 2 twin, part two (r157): the kerf.toml
/// manifest projection in its own target skin.
pub const MANIFEST_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/manifest.ktf");

/// The composed program: the RS-1 prefix, the micro-TOML twin, the
/// placeholder semver channels (its top-level parse rides the empty
/// tables — form errors, harmless; the projection calls its
/// functions), the semver twin, and the manifest projection. The
/// `result` global ends at the manifest verdict (the last define
/// wins — the sequential-store semantics).
pub fn assembled_manifest_target_source(text: &str) -> String {
    format!(
        "{}\n{}\n{}\ndefine(con_bytes, quote(nil));\ndefine(ver_bytes, quote(nil));\n{}\n{}",
        STD_ERROR_TARGET_SOURCE,
        target_byte_table_prefix(text),
        MICRO_TOML_TARGET_SOURCE,
        SEMVER_TARGET_SOURCE,
        MANIFEST_TARGET_SOURCE
    )
}

// ---------------------------------------------------------------------------
// The oracle axis: the Rust manifest projection's dump
// ---------------------------------------------------------------------------

/// The oracle's normalized dump: the manifest record on success
/// (package name, version triple, the name-sorted dependency pairs)
/// or the `PkgError` Display on rejection.
pub fn manifest_oracle_dump(text: &str) -> String {
    match Manifest::parse("kerf.toml", text) {
        Ok(m) => {
            let deps = m
                .depends
                .iter()
                .map(|(name, c)| format!("(\"{name}\" (con {c}))"))
                .collect::<Vec<_>>()
                .join(" ");
            if deps.is_empty() {
                format!("(manifest \"{}\" (ver {}) (deps))\n", m.package, m.version)
            } else {
                format!(
                    "(manifest \"{}\" (ver {}) (deps {deps}))\n",
                    m.package, m.version
                )
            }
        }
        Err(e) => format!("ERR {e}\n"),
    }
}

// ---------------------------------------------------------------------------
// The .ktf side: decoding the twin's verdict
// ---------------------------------------------------------------------------

/// Render one nested semver rejection — ("err" kind fs fe) with
/// SOURCE offsets — into its message fragment, slicing the
/// component operand from the owning text.
fn render_inner_semver(inner: &[&Value], heap: &Heap, text: &str) -> Result<String, String> {
    need_fields(inner, 4, "nested semver error")?;
    let kind = as_str(inner[1]).map_err(|err| format!("nested kind: {err}"))?;
    let fs = as_i64(inner[2])?;
    let fe = as_i64(inner[3])?;
    let _ = heap;
    match kind {
        "version-form" => Ok("expected the X.Y.Z form".to_string()),
        "constraint-form" => Ok("expected the X.Y or X.Y.Z form".to_string()),
        "not-a-number" => {
            let part = span_text(text, fs, fe, "nested semver component")?;
            Ok(format!("component \"{part}\" is not a number"))
        }
        other => Err(format!("harness defect: unknown nested kind `{other}`")),
    }
}

/// Render the twin's manifest error record into the oracle's own
/// line — the `ERR {file}...` dump form. Field layouts by kind (the
/// twin's constructors):
///
/// * five fields — (kind line fs fe): every plain rejection;
/// * six fields — (kind line tfs tfe inner): bad-version;
/// * seven fields — (kind line nks nke cfs cfe inner):
///   dep-bad-constraint;
/// * seven fields — (kind mt-kind line col fs fe): the syntax
///   pass-through.
///
/// The message line of one manifest error record — the PkgError
/// Display equivalent for the ManifestInvalid/Syntax family,
/// parameterized over the file (the resolve pass-through renders a
/// dependency's manifest against ITS path; the manifest drive
/// itself pins "kerf.toml" — the blade 3b reuse face, the message
/// shapes unchanged).
pub(crate) fn render_mf_error(
    elems: &[&Value],
    heap: &Heap,
    text: &str,
    file: &str,
) -> Result<String, String> {
    let kind = as_str(elems[1]).map_err(|err| format!("manifest kind: {err}"))?;
    let anchored = |line: i64, message: String| {
        if line == 0 {
            format!("{file}: {message}")
        } else {
            format!("{file}:{line}: {message}")
        }
    };
    let operand = |fs: i64, fe: i64, what: &str| span_text(text, fs, fe, what);
    match kind {
        "syntax" => {
            // (kind mt-kind line col fs fe)
            need_fields(elems, 7, "syntax record")?;
            let mt_kind = as_str(elems[2]).map_err(|err| format!("mt kind: {err}"))?;
            let line = as_i64(elems[3])?;
            let col = as_i64(elems[4])?;
            let fs = as_i64(elems[5])?;
            let fe = as_i64(elems[6])?;
            let message = render_mt_error(mt_kind, line, col, fs, fe, text)?;
            // render_mt_error already carries the `line:col: message` form —
            // the file name rides the front, never a doubled position.
            Ok(format!("ERR {file}:{message}\n"))
        }
        "package-not-string" => {
            need_fields(elems, 5, "package-not-string record")?;
            let line = as_i64(elems[2])?;
            Ok(format!(
                "ERR {}\n",
                anchored(line, "\"package\" must be a string".to_string())
            ))
        }
        "version-not-string" => {
            need_fields(elems, 5, "version-not-string record")?;
            let line = as_i64(elems[2])?;
            Ok(format!(
                "ERR {}\n",
                anchored(line, "\"version\" must be a string".to_string())
            ))
        }
        "bad-name" => {
            need_fields(elems, 5, "bad-name record")?;
            let line = as_i64(elems[2])?;
            let name = operand(as_i64(elems[3])?, as_i64(elems[4])?, "package name")?;
            Ok(format!(
                "ERR {}\n",
                anchored(
                    line,
                    format!(
                        "package name \"{name}\" must be kebab-case (lowercase letters, digits, `-`)"
                    )
                )
            ))
        }
        "unknown-key" => {
            need_fields(elems, 5, "unknown-key record")?;
            let line = as_i64(elems[2])?;
            let key = operand(as_i64(elems[3])?, as_i64(elems[4])?, "manifest key")?;
            Ok(format!(
                "ERR {}\n",
                anchored(line, format!("unknown manifest key \"{key}\""))
            ))
        }
        "missing-package" => {
            need_fields(elems, 5, "missing-package record")?;
            Ok(format!("ERR {}: missing required key \"package\"\n", file))
        }
        "missing-version" => {
            need_fields(elems, 5, "missing-version record")?;
            Ok(format!("ERR {}: missing required key \"version\"\n", file))
        }
        "dep-not-string" => {
            need_fields(elems, 5, "dep-not-string record")?;
            let line = as_i64(elems[2])?;
            let name = operand(as_i64(elems[3])?, as_i64(elems[4])?, "dependency name")?;
            Ok(format!(
                "ERR {}\n",
                anchored(
                    line,
                    format!("dependency \"{name}\" must carry a string constraint")
                )
            ))
        }
        "unknown-section" => {
            need_fields(elems, 5, "unknown-section record")?;
            let name = operand(as_i64(elems[3])?, as_i64(elems[4])?, "section name")?;
            Ok(format!("ERR {file}: unknown manifest section \"{name}\"\n"))
        }
        "unknown-section-array" => {
            need_fields(elems, 5, "unknown-section-array record")?;
            let name = operand(as_i64(elems[3])?, as_i64(elems[4])?, "array section name")?;
            Ok(format!(
                "ERR {file}: unknown manifest section \"[[{name}]]\"\n"
            ))
        }
        "bad-version" => {
            // (kind line tfs tfe inner)
            need_fields(elems, 6, "bad-version record")?;
            let line = as_i64(elems[2])?;
            let ver_text = operand(as_i64(elems[3])?, as_i64(elems[4])?, "version text")?;
            let inner = value_elems(elems[5], heap)?;
            let inner_msg = render_inner_semver(&inner, heap, text)?;
            Ok(format!(
                "ERR {}\n",
                anchored(line, format!("invalid version \"{ver_text}\": {inner_msg}"))
            ))
        }
        "dep-bad-constraint" => {
            // ("err" kind line nks nke cfs cfe inner) — eight fields
            need_fields(elems, 8, "dep-bad-constraint record")?;
            let line = as_i64(elems[2])?;
            let name = operand(as_i64(elems[3])?, as_i64(elems[4])?, "dependency name")?;
            let con_text = operand(as_i64(elems[5])?, as_i64(elems[6])?, "constraint text")?;
            let inner = value_elems(elems[7], heap)?;
            let inner_msg = render_inner_semver(&inner, heap, text)?;
            Ok(format!(
                "ERR {}\n",
                anchored(
                    line,
                    format!("dependency \"{name}\": invalid version \"{con_text}\": {inner_msg}")
                )
            ))
        }
        other => Err(format!("harness defect: unknown manifest kind `{other}`")),
    }
}

/// Decode one dependency record — ((ns ne) (cmaj cmin chas cpat))
/// — into its dump fragment `("name" (con X.Y[.Z]))`.
fn decode_mf_dep(dep: &Value, heap: &Heap, text: &str) -> Result<String, String> {
    let outer = value_elems(dep, heap).map_err(|err| format!("dep chain: {err}"))?;
    need_fields(&outer, 2, "dep record")?;
    let name_span = value_elems(outer[0], heap)?;
    need_fields(&name_span, 2, "dep name span")?;
    let name = span_text(
        text,
        as_i64(name_span[0])?,
        as_i64(name_span[1])?,
        "dependency name",
    )?;
    let quad = value_elems(outer[1], heap)?;
    need_fields(&quad, 4, "dep constraint quad")?;
    let maj = as_i64(quad[0])?;
    let min = as_i64(quad[1])?;
    let has = as_i64(quad[2])?;
    let pat = as_i64(quad[3])?;
    let con = if has == 1 {
        format!("{maj}.{min}.{pat}")
    } else {
        format!("{maj}.{min}")
    };
    Ok(format!("(\"{name}\" (con {con}))"))
}

/// Decode the twin's `result` global — the manifest verdict.
fn decode_mf_verdict(value: &Value, heap: &Heap, text: &str) -> Result<String, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("verdict chain: {err}"))?;
    need_fields(&elems, 2, "manifest verdict")?;
    let head = as_str(elems[0]).map_err(|err| format!("verdict tag: {err}"))?;
    if head == "ok" {
        // ("ok" pkg-span triple deps)
        let body = value_elems(elems[1], heap)?;
        need_fields(&body, 3, "manifest record")?;
        let pkg_span = value_elems(body[0], heap)?;
        need_fields(&pkg_span, 2, "package name span")?;
        let name = span_text(
            text,
            as_i64(pkg_span[0])?,
            as_i64(pkg_span[1])?,
            "package name",
        )?;
        let triple = value_elems(body[1], heap)?;
        need_fields(&triple, 3, "version triple")?;
        let ver = format!(
            "{}.{}.{}",
            as_i64(triple[0])?,
            as_i64(triple[1])?,
            as_i64(triple[2])?
        );
        let deps_elems = value_elems(body[2], heap)?;
        if deps_elems.is_empty() {
            Ok(format!("(manifest \"{name}\" (ver {ver}) (deps))\n"))
        } else {
            let mut parts = Vec::with_capacity(deps_elems.len());
            for dep in &deps_elems {
                parts.push(decode_mf_dep(dep, heap, text)?);
            }
            Ok(format!(
                "(manifest \"{name}\" (ver {ver}) (deps {}))\n",
                parts.join(" ")
            ))
        }
    } else if head == "err" {
        Ok(render_mf_error(&elems, heap, text, "kerf.toml")?)
    } else {
        Err(format!("harness defect: unknown manifest tag `{head}`"))
    }
}

// ---------------------------------------------------------------------------
// The drive + comparison entries
// ---------------------------------------------------------------------------

/// The twin's single-axis dump (vm): the composed `.ktf` program
/// runs on the vm engine (the M16 single-engine face — the modern2
/// blade 1: the pkg twins consume the Error vocabulary, the k-form
/// raise paths ride the VM's one-shot semantics, the eval axis
/// retired for the pkg families — the modern2 window §9 ruling).
pub fn manifest_twin_dump(text: &str) -> Result<String, String> {
    let assembled = assembled_manifest_target_source(text);
    let decode = |value: &Value, heap: &Heap| decode_mf_verdict(value, heap, text);
    drive_vm_only("manifest-parity-host", "manifest twin", &assembled, decode)
}

/// The two-way comparison: twin-vm == oracle, on the manifest dump
/// (the projection record or the rendered error line). On mismatch
/// the failure names the case and the first differing line pair.
/// The engine-agreement axis retired at the modern2 blade 1 (the
/// window §9 M16 ruling).
pub fn manifest_parity(case: &str, text: &str) -> Result<(), String> {
    let oracle = manifest_oracle_dump(text);
    let vm_dump = manifest_twin_dump(text)?;
    if let Some((ol, tl)) = first_diff(&oracle, &vm_dump) {
        return Err(format!(
            "manifest parity FAIL [{case}]: oracle `{ol}` vs twin `{tl}`"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case list
// ---------------------------------------------------------------------------

/// The curated twin cases: the positive axis (a minimal manifest,
/// the name-sorted dependency projection, a realistic multi-depend
/// manifest, a version with the full X.Y.Z spelling) and the
/// rejection family — the three negative tribes of the blade row
/// (missing required keys, unknown keys and sections, non-kebab
/// names) plus the nested semver rejections and the micro-toml
/// syntax pass-through.
pub const MANIFEST_TWIN_CASES: &[(&str, &str)] = &[
    // ---- positive ----
    ("minimal", "package = \"p\"\nversion = \"0.1.0\"\n"),
    (
        "deps-sorted",
        "package = \"math-utils\"\nversion = \"1.4.0\"\n\n[depends]\nstrings = \"0.1.5\"\ncore-bits = \"0.2\"\n",
    ),
    (
        "realistic",
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nstrings = \"0.1.5\"\ncore-bits = \"0.2\"\nmath-utils = \"1.4\"\n",
    ),
    (
        "full-triple-version",
        "package = \"p\"\nversion = \"10.20.30\"\n\n[depends]\na = \"1.2.3\"\n",
    ),
    // ---- negative: the missing-required tribe ----
    ("missing-package", "version = \"0.1.0\"\n"),
    ("missing-version", "package = \"p\"\n"),
    ("missing-both", ""),
    // ---- negative: the unknown-key and unknown-section tribe ----
    (
        "unknown-key",
        "package = \"p\"\nversion = \"0.1.0\"\nedition = \"2024\"\n",
    ),
    (
        "unknown-section",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[features]\nx = \"y\"\n",
    ),
    (
        "unknown-array-section",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[[bins]]\nname = \"x\"\n",
    ),
    (
        "depends-as-array-section",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[[depends]]\na = \"0.1\"\n",
    ),
    // ---- negative: the value and name tribe ----
    ("package-not-string", "package = 3\nversion = \"0.1.0\"\n"),
    ("version-not-string", "package = \"p\"\nversion = 1\n"),
    (
        "uppercase-package",
        "package = \"MyPkg\"\nversion = \"0.1.0\"\n",
    ),
    (
        "bad-dep-name",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\nBad = \"0.1\"\n",
    ),
    (
        "dep-not-string",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\na = 2\n",
    ),
    // ---- negative: the nested semver and syntax tribe ----
    ("bad-version-text", "package = \"p\"\nversion = \"1.2\"\n"),
    (
        "bad-dep-constraint",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\na = \"bad\"\n",
    ),
    (
        "bad-dep-constraint-component",
        "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\na = \"1.x\"\n",
    ),
    (
        "syntax-pass-through",
        "package = \"p\nversion = \"0.1.0\"\n",
    ),
];

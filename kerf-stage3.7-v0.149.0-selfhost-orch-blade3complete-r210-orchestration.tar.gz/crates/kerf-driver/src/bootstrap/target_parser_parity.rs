//! Target-parser parity — the W-TGT-READ-TWIN blade 2 harness (gap
//! G1 of bootstrap-completion-plan.md §4.2): the target-skin
//! PARSER layer, written in the frozen kerf subset itself
//! (`selfhost/v1/target-parser.ktf` — the ninth selfhost twin, the
//! second that mirrors the TARGET read chain), checked against the
//! Rust target parser oracle (`kerf_reader::read_target_program`)
//! through the full `.ktf` chain on both engines.
//!
//! Hosting — the TP-1 token-record channel: the host lexes the
//! source with the single-source Rust target lexer (`lex_target` —
//! the skin mapping applied there, K20) and injects the token
//! records, the nesting limit, and the oracle's own
//! UnsupportedTargetForm message texts (the `tp_forms` table — a
//! twin-side copy of a message drifting is structurally
//! impossible; a PARSER-SIDE drift is caught by the three-way
//! comparison itself, which is the drift guard). The twin makes
//! every parse decision — the 14-level precedence cascade, the
//! do/let backwards fold, the quote datum carrier, the pattern
//! family, the type annotation drop, every fail-closed face — and
//! the harness decodes the `tp_verdict` global (aliased `result`)
//! from BOTH engines.
//!
//! One axis, byte-for-byte (the target_lexer_parity lineage):
//!
//! * **Tree axis** — the oracle `read_target_program` tree and the
//!   twin's tree records normalize to the same dump grammar
//!   (`(ident s e name)`, `(int s e v)`, `(float s e v)`,
//!   `(bool s e b)`, `(string s e "text")`, `(list s e child...)`
//!   — the reader_parity `oracle_dump` grammar, the shared dump
//!   single source), so tree drift localizes to the exact record;
//!   on a rejection both sides render through the oracle's own
//!   `ReadError` (rebuilt on the twin side through the SAME error
//!   type — `error_parity_key`), so the kind AND the payload
//!   compare byte-precisely.
//!
//! The permanent host layer (K20, the blade-1 division carried to
//! the parse layer): the **use-form skin mapping** (the twin's
//! use-str record carries the raw module text; the harness maps it
//! through `skin_symbol` — the oracle's own single source — and
//! the mapping failure renders through the same InvalidSymbol
//! key), the **float value face** (the twin's dfloat record
//! carries the positive lexeme's Debug text; the host negates the
//! parsed f64), and the **unexpected-token text** (the twin's
//! record carries the span; the harness slices the source — the
//! eof face renders "end of input" exactly as the oracle's own
//! empty-lexeme arm does). Every other decision is made in
//! `target-parser.ktf`.

use kerf_reader::{ReadError, TgtKind, lex_target, read_target_program, skin_symbol};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};
use kerf_vm::{Heap, Value};
use std::rc::Rc;

use crate::bootstrap::target_corpus::{TARGET_PARSER_TARGET_SOURCE, transcode_quoted_define};
use crate::bootstrap::vm_harness::{
    STD_ERROR_TARGET_SOURCE, as_i64, as_str, drive_vm_only, error_parity_key, need_fields,
    oracle_dump, value_elems,
};

// ---------------------------------------------------------------------------
// The injected form table — the oracle's own message texts (the
// keys are the twin's tp_k_* byte constants; a parser.rs text
// change drifts against this table and FAILS the three-way
// comparison on the very next curated rejection run, so the
// comparison is the drift guard).
// ---------------------------------------------------------------------------

/// (key bytes, the oracle's `form` payload) — one entry per
/// `UnsupportedTargetForm` site in `parser.rs`.
const TP_FORMS: &[(&[u8], &str)] = &[
    (b"type-decls", "type declarations"),
    (
        b"require-call",
        "the `require` call form (the target skin spells it `use \"name\";` or `use path;`)",
    ),
    (b"generic", "generic parameters"),
    (b"use-tree", "use tree or alias forms"),
    (b"use-path", "use path form"),
    // ORCH blade 1 (O1): the composition face's own rejection texts
    // (the oracle's parse_import_decl messages, verbatim).
    (b"import-tree", "import tree or alias forms"),
    (b"import-path", "import path form"),
    (
        b"macro-spec",
        "the macro body carries one spec datum (`syntax-rules ...`)",
    ),
    (b"quote-data", "quote carries data, not expressions"),
    (
        b"empty-list",
        "the empty quoted list (write `nil` \u{2014} the datum face of the empty list)",
    ),
    (b"index", "index expression"),
    (b"field", "field or method access"),
    (b"cast", "cast expression"),
    (b"fn-expr", "fn expression (closures use `||`)"),
    (b"impl", "impl expressions"),
    (b"handler-kw", "handler body keyword outside a handler arm"),
    (b"halt", "halt handler body"),
    (b"pass", "pass handler body"),
    (b"or-pat", "or-patterns"),
    (b"guard", "match arm guards"),
    (
        b"pattern",
        "pattern syntax (paths and `@` bindings are not implemented)",
    ),
    (b"range", "range expression"),
];

// ---------------------------------------------------------------------------
// The injection prefixes (S-expr forms transcoded to the target
// skin — the transcode_quoted_define single source)
// ---------------------------------------------------------------------------

/// `(define tp_tokens (quote (...)))` — the oracle token stream as
/// records: `("kw-fn" s e)` / `("ident" s e (bytes))` (the mapped
/// canonical text) / `("int" s e v)` / `("float" s e "debug")` /
/// `("str" s e "decoded")` / `("bool" s e #t)` / `("eof" e)`.
/// `Err` carries the oracle's own lexer rejection (the harness
/// layer split: lexer-side failures are decided by the single
/// source and the .ktf layer is not run for them).
fn tp_token_prefix(source: &str) -> Result<String, ReadError> {
    let tokens = lex_target(FileId(0), source)?;
    let lit = |s: &str| crate::bootstrap::vm_harness::encode_string_literal(s);
    let mut out = String::from("(define tp-tokens (quote (");
    for (i, tok) in tokens.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        let (s, e) = (tok.span.start.0, tok.span.end.0);
        match &tok.kind {
            TgtKind::Ident(sym) => {
                let bytes: Vec<String> = sym.as_str().bytes().map(|b| b.to_string()).collect();
                out.push_str(&format!("(\"ident\" {s} {e} ({}))", bytes.join(" ")));
            }
            TgtKind::Int(v) => out.push_str(&format!("(\"int\" {s} {e} {v})")),
            TgtKind::Float(v) => {
                out.push_str(&format!("(\"float\" {s} {e} {})", lit(&format!("{v:?}"))))
            }
            TgtKind::Str(value) => {
                out.push_str(&format!("(\"str\" {s} {e} {})", lit(value)));
            }
            TgtKind::Bool(b) => {
                let spelling = if *b { "#t" } else { "#f" };
                out.push_str(&format!("(\"bool\" {s} {e} {spelling})"));
            }
            TgtKind::Eof => out.push_str(&format!("(\"eof\" {e})")),
            other => {
                out.push_str(&format!(
                    "(\"{}\" {s} {e})",
                    crate::bootstrap::target_lexer_parity::kind_tag(other)
                ));
            }
        }
    }
    out.push_str(")))");
    Ok(out)
}

/// `(define tp_forms (quote (...)))` — the form table, one
/// `((key bytes) (form bytes))` pair per entry. `pub(crate)` since
/// blade 3 (the steady chain's fixed program embeds the same table
/// — one spelling, never a re-typed copy that could drift).
pub(crate) fn tp_forms_prefix() -> String {
    let mut out = String::from("(define tp-forms (quote (");
    for (i, (key, form)) in TP_FORMS.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        let kb: Vec<String> = key.iter().map(|b| b.to_string()).collect();
        let fb: Vec<String> = form.bytes().map(|b| b.to_string()).collect();
        out.push_str(&format!("(({}) ({}))", kb.join(" "), fb.join(" ")));
    }
    out.push_str(")))");
    out
}

/// The limit rides as a plain int define on the target skin (a
/// quoted datum would be a list — the twin compares against the
/// int; the constant is injected, never transcoded). `pub(crate)`
/// since blade 3 (the steady chain's fixed program embeds the same
/// constant).
pub(crate) fn tp_limit_prefix(limit: usize) -> String {
    format!("define(tp_limit, {limit});\n")
}

// ---------------------------------------------------------------------------
// The oracle side (the shared dump single source)
// ---------------------------------------------------------------------------

/// The oracle's normalized tree dump — `oracle_dump` over the
/// `read_target_program` forms (the grammar both sides normalize
/// to; `Err` carries the oracle's own rejection, rendered as the
/// parity key by the caller).
pub fn target_parser_oracle_dump(source: &str) -> Result<String, ReadError> {
    let forms = read_target_program(FileId(0), source)?;
    Ok(oracle_dump(&forms))
}

// ---------------------------------------------------------------------------
// The .ktf side — decoding the twin's verdict
// ---------------------------------------------------------------------------

/// Decode a byte-list value into its UTF-8 text (ident texts and
/// form payloads).
fn decode_bytes(v: &Value, heap: &Heap, what: &str) -> Result<String, String> {
    let elems = value_elems(v, heap).map_err(|e| format!("{what}: {e}"))?;
    let mut bytes = Vec::with_capacity(elems.len());
    for e in &elems {
        bytes.push(as_i64(e).map_err(|err| format!("{what} payload: {err}"))? as u8);
    }
    String::from_utf8(bytes)
        .map_err(|_| format!("harness defect: {what} bytes are not valid UTF-8"))
}

/// Rebuild the span (the twin's spans are the oracle's own token
/// extents, so the slice is safe by construction).
fn span_of(s: i64, e: i64) -> Result<Span, String> {
    Span::new(
        FileId(0),
        ByteOffset(s as u32),
        ByteOffset(e as u32),
        ExpansionId::ROOT,
    )
    .map_err(|err| format!("harness defect: rebuilt span rejected: {err}"))
}

/// The static form text for a form-table payload (the reverse
/// lookup BY VALUE — the twin emits the injected form text bytes,
/// and the table's static str for the same text is the oracle's
/// own single source; an unknown text is a harness defect, never
/// a silent mismatch).
fn static_form(bytes: &[u8]) -> Result<&'static str, String> {
    for (_key, form) in TP_FORMS {
        if form.as_bytes() == bytes {
            return Ok(form);
        }
    }
    Err(format!(
        "harness defect: the twin emitted an unknown form payload ({bytes:?})"
    ))
}

/// Decode one tree record into its dump fragment. `Ok(Err(key))`
/// when a K20 host face rejects the case (the use-str skin
/// mapping), `Err` on a harness defect.
fn decode_tp_tree(
    rec: &Value,
    heap: &Heap,
    out: &mut String,
) -> Result<Result<(), String>, String> {
    let elems = value_elems(rec, heap).map_err(|e| format!("tree record: {e}"))?;
    need_fields(&elems, 3, "tree record")?;
    let tag = as_str(elems[0]).map_err(|e| format!("tree tag: {e}"))?;
    let s = as_i64(elems[1]).map_err(|e| format!("tree span start: {e}"))?;
    let e = as_i64(elems[2]).map_err(|e| format!("tree span end: {e}"))?;
    let fragment = match tag {
        "ident" => {
            let text = decode_bytes(elems.get(3).ok_or("ident lacks its text")?, heap, "ident")?;
            format!("(ident {s} {e} {text})")
        }
        "int" => {
            let v = as_i64(elems.get(3).ok_or("int lacks its value")?)
                .map_err(|e| format!("int payload: {e}"))?;
            format!("(int {s} {e} {v})")
        }
        "float" => {
            // The injected Debug text rides through verbatim (the
            // oracle's own {v:?} of the same f64).
            let text = as_str(elems.get(3).ok_or("float lacks its text")?)
                .map_err(|e| format!("float payload: {e}"))?;
            format!("(float {s} {e} {text})")
        }
        "dfloat" => {
            // The K20 value face: the twin carried the positive
            // lexeme's Debug text; the host negates the parsed f64.
            let text = as_str(elems.get(3).ok_or("dfloat lacks its text")?)
                .map_err(|e| format!("dfloat payload: {e}"))?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("harness defect: dfloat text `{text}` does not parse"))?;
            format!("(float {s} {e} {:?})", -v)
        }
        "bool" => match elems.get(3) {
            Some(Value::Bool(b)) => format!("(bool {s} {e} {b})"),
            Some(other) => return Err(format!("harness defect: bool payload is {other:?}")),
            None => return Err("harness defect: bool record lacks its payload".to_string()),
        },
        "string" => {
            let text = as_str(elems.get(3).ok_or("string lacks its text")?)
                .map_err(|e| format!("string payload: {e}"))?;
            format!("(string {s} {e} {text:?})")
        }
        "list" => {
            let mut inner = String::new();
            for child in &elems[3..] {
                match decode_tp_tree(child, heap, &mut inner)? {
                    Ok(()) => inner.push(' '),
                    Err(key) => return Ok(Err(key)),
                }
            }
            let trimmed = inner.trim_end();
            format!(
                "(list {s} {e}{sep}{trimmed})",
                sep = if trimmed.is_empty() { "" } else { " " }
            )
        }
        "use-str" => {
            // The K20 use-form skin mapping: the harness maps the
            // raw module text through skin_symbol — the oracle's
            // own single source (a mapping failure renders through
            // the same InvalidSymbol key).
            need_fields(&elems, 7, "use-str record")?;
            let kw_s = s;
            let kw_e = e;
            let name_s = as_i64(elems[3]).map_err(|e| format!("use-str name span: {e}"))?;
            let name_e = as_i64(elems[4]).map_err(|e| format!("use-str name span: {e}"))?;
            let semi_e = as_i64(elems[5]).map_err(|e| format!("use-str semi span: {e}"))?;
            let raw = as_str(elems.get(6).ok_or("use-str lacks its text")?)
                .map_err(|e| format!("use-str payload: {e}"))?;
            match skin_symbol(raw) {
                Ok(mapped) => format!(
                    "(list {kw_s} {semi_e} (ident {kw_s} {kw_e} require) (string {name_s} {name_e} {:?}))",
                    mapped.as_str()
                ),
                // The mapping failure IS the oracle's own
                // ReadError::InvalidSymbol — render its key directly
                // (the same single source both sides ride).
                Err(err) => return Ok(Err(error_parity_key(&err))),
            }
        }
        "use-path" => {
            need_fields(&elems, 6, "use-path record")?;
            let kw_s = s;
            let kw_e = e;
            let seg_end = as_i64(elems[3]).map_err(|e| format!("use-path segment end: {e}"))?;
            let semi_e = as_i64(elems[4]).map_err(|e| format!("use-path semi span: {e}"))?;
            let text = decode_bytes(
                elems.get(5).ok_or("use-path lacks its text")?,
                heap,
                "use-path",
            )?;
            format!(
                "(list {kw_s} {semi_e} (ident {kw_s} {kw_e} require) (string {kw_s} {seg_end} {text:?}))"
            )
        }
        // ORCH blade 1 (O1): the composition declaration's records —
        // the use arms' mirror with the verbatim-payload divergence
        // (the unit registry keys are the identity; the use-str skin
        // mapping does NOT apply here: units are not value-namespace
        // names, the registry resolves the exact text).
        "import-str" => {
            need_fields(&elems, 7, "import-str record")?;
            let kw_s = s;
            let kw_e = e;
            let name_s = as_i64(elems[3]).map_err(|e| format!("import-str name span: {e}"))?;
            let name_e = as_i64(elems[4]).map_err(|e| format!("import-str name span: {e}"))?;
            let semi_e = as_i64(elems[5]).map_err(|e| format!("import-str semi span: {e}"))?;
            let raw = as_str(elems.get(6).ok_or("import-str lacks its text")?)
                .map_err(|e| format!("import-str payload: {e}"))?;
            format!(
                "(list {kw_s} {semi_e} (ident {kw_s} {kw_e} import) (string {name_s} {name_e} {raw:?}))"
            )
        }
        "import-path" => {
            need_fields(&elems, 6, "import-path record")?;
            let kw_s = s;
            let kw_e = e;
            let seg_end = as_i64(elems[3]).map_err(|e| format!("import-path segment end: {e}"))?;
            let semi_e = as_i64(elems[4]).map_err(|e| format!("import-path semi span: {e}"))?;
            let text = decode_bytes(
                elems.get(5).ok_or("import-path lacks its text")?,
                heap,
                "import-path",
            )?;
            format!(
                "(list {kw_s} {semi_e} (ident {kw_s} {kw_e} import) (string {kw_s} {seg_end} {text:?}))"
            )
        }
        other => return Err(format!("harness defect: unknown tree record tag `{other}`")),
    };
    out.push_str(&fragment);
    Ok(Ok(()))
}

/// Rebuild the oracle `ReadError` from a twin error record's
/// payload (kind first, then the variant's payloads — the header
/// contract of `target-parser.ktf`).
pub(crate) fn rebuild_tp_error(
    kind: &str,
    payload: &[&Value],
    heap: &Heap,
    source: &str,
) -> Result<ReadError, String> {
    let at =
        |i: usize| -> Result<ByteOffset, String> { Ok(ByteOffset(as_i64(payload[i])? as u32)) };
    let span_at = |i: usize, j: usize| -> Result<Span, String> {
        let s = as_i64(payload[i])?;
        let e = as_i64(payload[j])?;
        span_of(s, e)
    };
    match kind {
        "unsupported" => {
            need_fields(payload, 3, "unsupported")?;
            let bytes = decode_bytes(payload[0], heap, "form")?;
            let form = static_form(bytes.as_bytes())?;
            Ok(ReadError::UnsupportedTargetForm {
                form,
                span: span_at(1, 2)?,
            })
        }
        "unexpected-token" => {
            need_fields(payload, 2, "unexpected-token")?;
            let s = as_i64(payload[0])?;
            let e = as_i64(payload[1])?;
            let text = if s == e {
                // The eof token's empty lexeme — the oracle's own
                // "end of input" arm.
                "end of input".to_string()
            } else {
                source
                    .get(s as usize..e as usize)
                    .ok_or_else(|| format!("harness defect: span {s}..{e} is out of bounds"))?
                    .to_string()
            };
            Ok(ReadError::UnexpectedTargetToken {
                text,
                span: span_of(s, e)?,
            })
        }
        "unclosed" => {
            need_fields(payload, 2, "unclosed")?;
            // The parser-site unclosed delimiters: `{` for the block
            // family (module/extern/struct/enum braces, fn bodies,
            // handle/match arm lists — the lexer owns the `/*` face),
            // `(` for the enum payload list (blade 3 — the only
            // parser-site paren unclosed). The opening rides the
            // payload's second field, the stray face's own shape.
            let cp = as_i64(payload[1])? as u32;
            let opening: &'static str = match cp {
                123 => "{",
                40 => "(",
                _ => {
                    return Err(format!(
                        "harness defect: codepoint {cp} is not an unclosed opening"
                    ));
                }
            };
            Ok(ReadError::UnclosedTargetDelim {
                opened_at: at(0)?,
                opening,
            })
        }
        "stray" => {
            need_fields(payload, 2, "stray")?;
            let cp = as_i64(payload[0])? as u32;
            let closing = char::from_u32(cp)
                .ok_or_else(|| format!("harness defect: codepoint {cp} is not a char"))?;
            Ok(ReadError::StrayTargetDelim {
                closing,
                at: at(1)?,
            })
        }
        "nesting" => {
            need_fields(payload, 2, "nesting")?;
            Ok(ReadError::NestingDepthExceeded {
                depth: as_i64(payload[0])? as usize,
                limit: as_i64(payload[1])? as usize,
            })
        }
        other => Err(format!(
            "harness defect: unknown parser error kind `{other}`"
        )),
    }
}

/// Decode the twin's `tp_verdict` (the `result` alias) into the
/// tree-axis outcome: `Ok(Ok(dump))`, `Ok(Err(key))` on the twin's
/// own rejection, `Err` on a harness defect. `pub(crate)` since
/// blade 3 (the steady chain decodes through the same single
/// source — the cross-route equivalence rides it).
pub(crate) fn decode_tp_verdict(
    value: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Result<String, String>, String> {
    let elems = value_elems(value, heap).map_err(|e| format!("verdict chain: {e}"))?;
    // The verdict contract: ("ok" item ...) — zero items on an
    // empty source is a legitimate ("ok") — only the tag is
    // unconditional; the err face carries kind + payload.
    need_fields(&elems, 1, "verdict")?;
    let tag = as_str(elems[0]).map_err(|e| format!("verdict tag: {e}"))?;
    if tag == "ok" {
        let mut out = String::new();
        for (i, rec) in elems[1..].iter().enumerate() {
            if i > 0 {
                out.push(' ');
            }
            match decode_tp_tree(rec, heap, &mut out)? {
                Ok(()) => {}
                Err(key) => return Ok(Err(key)),
            }
        }
        Ok(Ok(out))
    } else if tag == "err" {
        need_fields(&elems, 2, "verdict err")?;
        let kind = as_str(elems[1]).map_err(|e| format!("error kind: {e}"))?;
        let err = rebuild_tp_error(kind, &elems[2..], heap, source)?;
        Ok(Err(error_parity_key(&err)))
    } else {
        Err(format!("harness defect: unknown verdict tag `{tag}`"))
    }
}

/// The parser twin's verdict as the production face needs it: the
/// rebuilt `ReadError` on the twin's own rejection, `None` on the
/// ok verdict (the dump/key rendering stays in the parity faces —
/// this is the step-④ read position's rejection probe).
pub(crate) fn tp_verdict_read_error(
    value: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Option<ReadError>, String> {
    let elems = value_elems(value, heap).map_err(|e| format!("verdict chain: {e}"))?;
    need_fields(&elems, 1, "verdict")?;
    let tag = as_str(elems[0]).map_err(|e| format!("verdict tag: {e}"))?;
    match tag {
        "ok" => Ok(None),
        "err" => {
            need_fields(&elems, 2, "verdict err")?;
            let kind = as_str(elems[1]).map_err(|e| format!("error kind: {e}"))?;
            Ok(Some(rebuild_tp_error(kind, &elems[2..], heap, source)?))
        }
        other => Err(format!("harness defect: unknown verdict tag `{other}`")),
    }
}

/// A debug probe: the assembled prefix (test/diagnostic face — never
/// part of the comparison, just the assembly text).
pub fn target_parser_assembly_probe(source: &str) -> String {
    format!(
        "{}{}{}\n{STD_ERROR_TARGET_SOURCE}\n{}{}",
        transcode_quoted_define(
            &tp_token_prefix(source)
                .unwrap_or_else(|_| "(define tp-tokens (quote nil))".to_string())
        ),
        tp_limit_prefix(256),
        transcode_quoted_define(&tp_forms_prefix()),
        TARGET_PARSER_TARGET_SOURCE,
        crate::bootstrap::target_corpus::PARSER_HOSTING_TAIL
    )
}

/// The twin drive: assemble the token-table, limit, form-table, and
/// std Error-instance prefixes ahead of the twin source, parse
/// through the production bridge (`ReaderFace::Target`), run the VM
/// engine, and decode the verdict into the dump grammar (the error
/// face rendered as `ERR {key}` — the harness contract). MODERN2
/// blade 6 (r203): the parser twin consumes the Error vocabulary
/// (the parse-rejection family rides `perform raise`, the entry
/// rides `unwrap(attempt(...))`), so this drive takes the vm-only
/// form (the M16/M46 policy line — the engine-agreement axis
/// retires for the family, the oracle comparison carries the full
/// load).
pub fn target_parser_twin_dump(source: &str) -> Result<String, String> {
    let assembled = format!(
        "{}{}{}\n{STD_ERROR_TARGET_SOURCE}\n{}{}",
        transcode_quoted_define(&tp_token_prefix(source).map_err(|err| {
            format!(
                "harness layer: the oracle lexer rejected the case: {}",
                error_parity_key(&err)
            )
        })?),
        tp_limit_prefix(256),
        transcode_quoted_define(&tp_forms_prefix()),
        TARGET_PARSER_TARGET_SOURCE,
        crate::bootstrap::target_corpus::PARSER_HOSTING_TAIL
    );
    let decode = |value: &Value, heap: &Heap| decode_tp_verdict(value, heap, source);
    let vm_axis = drive_vm_only(
        "target-parser-parity-host",
        "target parser twin",
        &assembled,
        decode,
    )?;
    let axis_form = |axis: Result<String, String>| match axis {
        Ok(dump) => dump,
        Err(key) => format!("ERR {key}"),
    };
    Ok(axis_form(vm_axis))
}

// ---------------------------------------------------------------------------
// The comparison entry
// ---------------------------------------------------------------------------

/// The first differing fragment of two dumps (the failure-line
/// precedent: the exact record that drifted).
fn first_diff(a: &str, b: &str) -> Option<(String, String)> {
    let la: Vec<&str> = a.split(')').collect();
    let lb: Vec<&str> = b.split(')').collect();
    for (xa, xb) in la.iter().zip(lb.iter()) {
        if xa != xb {
            return Some((xa.to_string(), xb.to_string()));
        }
    }
    if la.len() != lb.len() {
        return Some((
            format!("<{} parts>", la.len()),
            format!("<{} parts>", lb.len()),
        ));
    }
    None
}

/// The two-way comparison: twin-vm == oracle, on the dump grammar
/// (success) or the error key (rejection). MODERN2 blade 6 (r203):
/// the twin drive is vm-only (the parser twin consumes the Error
/// vocabulary — the engine-agreement axis retired; the oracle
/// comparison carries the full load).
pub fn target_parser_parity(case: &str, source: &str) -> Result<(), String> {
    let oracle = match target_parser_oracle_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let vm_dump = match target_parser_twin_dump(source) {
        Ok(dump) => dump,
        Err(err) if err.starts_with("harness layer: the oracle lexer rejected") => {
            // The layer split (K20): the lexer IS the single source
            // shared by the oracle and the twin's injection — a
            // lexer-side rejection is the twin's rejection with the
            // same key by construction; the .ktf layer never runs.
            // Defensive: the oracle must reject too (it rides the
            // same lexer — anything else is a harness defect).
            return match target_parser_oracle_dump(source) {
                Err(_) => Ok(()),
                Ok(_) => Err(format!(
                    "target-parser parity FAIL [{case}]: the oracle lexer rejected \
                     the case but the oracle parser accepted it"
                )),
            };
        }
        Err(err) => return Err(err),
    };
    if let Some((ol, tl)) = first_diff(&oracle, &vm_dump) {
        return Err(format!(
            "target-parser parity FAIL [{case}]: oracle `{ol}` vs twin `{tl}`"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case list (the parity sweep's synthetic face — the
// selfhost sources ride separately through their own embeddings)
// ---------------------------------------------------------------------------

/// The curated twin cases: every frame mode's happy path, every
/// precedence level, the desugar families, the span disciplines,
/// and the rejection family (each negative case's three-way
/// agreement is on the SAME error key — kind and payload).
pub const TARGET_PARSER_TWIN_CASES: &[(&str, &str)] = &[
    // ---- the declaration family ----
    ("fn-empty-params", "fn f() { 1 }\n"),
    (
        "fn-params-annot",
        "fn add(mut a, b: int) -> int { a + b }\n",
    ),
    (
        "fn-generic-annot",
        "fn apply(f) -> impl Fn(int) -> int { f }\n",
    ),
    (
        "module-nested",
        "module outer { fn a() { 1 }\nmodule inner { fn b() { 2 }\n }\n }\n",
    ),
    (
        "extern-abi",
        "extern \"C\" { fn abs(x: int) -> int; fn pow(b: int, e: int) -> int; }\n",
    ),
    ("extern-no-abi", "extern { fn one() -> int; }\n"),
    // ---- the blade 2 struct declaration family ----
    ("struct-basic", "struct P { x: i64, y: i64, }\n"),
    ("struct-unit", "struct Unit { }\n"),
    (
        "struct-spec-algebra",
        "struct R { pt: (i64, str), f: Fn(i64) -> bool, m: impl }\n",
    ),
    ("struct-single-no-comma", "struct W { only: bool }\n"),
    // ---- the blade 3 enum declaration family (GZ-4 — §10.5) ----
    ("enum-basic", "enum E { A, B(i64, str), }\n"),
    ("enum-empty-unit", "enum Never { }\n"),
    ("enum-empty-payload", "enum E { A(), B(i64), }\n"),
    ("enum-single-no-comma", "enum E { A(i64) }\n"),
    (
        "enum-spec-algebra",
        "enum E { A((i64, str)), B(Fn(i64) -> bool), C(impl), }\n",
    ),
    ("use-string", "use \"m_a\";\n"),
    ("use-string-kebab", "use \"m-b\";\n"),
    ("use-path", "use a::b::c;\n"),
    // ORCH blade 1 (O1): the composition declaration's accepting
    // faces — the string form (payload verbatim: no skin mapping)
    // and the path form (the joined `/`-segments over the lexed
    // identity).
    ("import-string", "import \"std/error\";\n"),
    ("import-string-snake", "import \"read_line\";\n"),
    ("import-path", "import std::error;\n"),
    (
        "macro-decl",
        "macro swap { (syntax_rules, (swap_rule, 2)) }\n",
    ),
    // ---- the statement family ----
    ("expr-stmt-call", "define(result, add(1, 2));\n"),
    ("expr-stmt-quote", "quote(x);\n"),
    ("let-multi", "fn f() { let a = 1, b = 2, c = 3; a }\n"),
    ("let-annot", "fn f() { let mut x: int = 5; x }\n"),
    ("assign", "fn f() { let x = 1; x = 2; x }\n"),
    // ---- the block fold ----
    ("block-tail", "fn f() { let a = 1; a + 1 }\n"),
    ("block-no-tail", "fn f() { let a = 1; }\n"),
    ("block-nested", "fn f() { { 1 } { 2 } }\n"),
    // ---- the precedence cascade ----
    ("or-and", "fn f(a, b, c) { a || b && c }\n"),
    (
        "cmp-family",
        "fn f(a, b) { a == b }\nfn g(a, b) { a != b }\nfn h(a, b) { a < b }\nfn i(a, b) { a >= b }\n",
    ),
    ("bit-family", "fn f(a, b) { a | b ^ c & d << 2 >> 1 }\n"),
    ("arith-term", "fn f(a, b) { a + b * 3 - 4 / 2 % 3 }\n"),
    (
        "unary-stack",
        "fn f(a) { --a }\nfn g(a) { !-a }\nfn h(a) { -!a }\n",
    ),
    ("call-chain", "define(r, f(1)(2)(3));\n"),
    ("macro-call", "define(r, swap!(1, 2));\n"),
    // ---- the quote datum carrier ----
    ("quote-list", "quote((1, 2, 3));\n"),
    ("quote-grouping", "quote((1));\n"),
    ("quote-words", "quote((fn, let, if, else));\n"),
    (
        "quote-operators",
        "quote((..., +, *, /, %, <, >, <=, >=, ==, !=, <<, >>));\n",
    ),
    ("quote-negative", "quote((-1, -2.5, -));\n"),
    ("quote-nested", "quote((a, (b, c), d));\n"),
    ("quote-paths", "quote((a::b, c));\n"),
    // ---- paths and closures ----
    ("path-qualified", "define(r, a::b::c(1));\n"),
    ("closure-move", "fn f(x) { move || { x } }\n"),
    ("closure-params", "fn f(x) { |a, b| { a + b + x } }\n"),
    ("closure-annot", "fn f() { || -> int { 1 } }\n"),
    // ---- control flow ----
    ("if-else", "fn f(a) { if a { 1 } else { 2 } }\n"),
    (
        "if-else-if",
        "fn f(a) { if a { 1 } else if a { 2 } else { 3 } }\n",
    ),
    ("if-no-else", "fn f(a) { if a { 1 } }\n"),
    (
        "perform-handle",
        "define(r, handle perform E(1) { E(v) => resume(v + 1) });\n",
    ),
    (
        "handle-block-body",
        "define(r, handle perform E(1) { E(v) => { v } });\n",
    ),
    (
        "match-literals",
        "fn f(x) { match x { 1 => { 10 }, 2 => { 20 }, } }\n",
    ),
    ("match-binding", "fn f(x) { match x { mut y => { y }, } }\n"),
    ("match-pair", "fn f(x) { match x { (a, b) => { a }, } }\n"),
    (
        "match-nil-pattern",
        "fn f(x) { match x { () => { 0 }, 3 => { 3 }, } }\n",
    ),
    (
        "match-str-bool",
        "fn f(x) { match x { \"a\" => { 1 }, true => { 2 }, 1.5 => { 3 }, } }\n",
    ),
    // ---- the type annotation spec algebra (blade 1 — GZ-1: the
    // construction face; parse-and-drop is over) ----
    ("type-drop", "fn f(x: (int, bool) | float -> str) { x }\n"),
    ("type-generic-args", "fn f(x: Return(int, i64)) { x }\n"),
    (
        "type-spec-tuple",
        "fn f(x: (int, bool)) { x }\nfn g() -> () { nil }\n",
    ),
    (
        "type-spec-arrow-chain",
        "fn f(g: int -> bool -> int) { g }\n",
    ),
    ("type-spec-union-chain", "fn f(x: int | bool | str) { x }\n"),
    ("type-spec-fn-app", "fn f(x: Fn(int) -> int) { x }\n"),
    (
        "type-spec-bare-markers",
        "fn f() -> impl { nil }\nfn g() -> effect { nil }\n",
    ),
    (
        // The latent-gap closure: generic args then a paren list —
        // the Rust `if Lt {...} if OpenParen {...}` sequence (the
        // old twin skipped the paren check after generics).
        "type-spec-generic-then-parens",
        "fn f(x: Foo<i64>(int, bool)) { x }\n",
    ),
    ("type-spec-param-only", "fn f(a, b: int) { b }\n"),
    ("let-triple-mixed", "fn f() { let x: int = 5, y = x; y }\n"),
    (
        "closure-fn-ann",
        "define(r, ||(a: int, b: int) -> int { a + b });\ndefine(s, ||(x: bool) { x });\n",
    ),
    (
        "handle-arm-annot",
        "define(r, handle perform E(1) { E(v: int) => resume(v + 1), });\n",
    ),
    // ---- the program face ----
    (
        "program-face",
        "fn add(a, b) { let s = a + b; s }\ndefine(result, add(1, 2));\n",
    ),
    ("empty-source", ""),
    // ---- the rejection family (same error key on all three ways) ----
    ("neg-type-item", "type T = int;\n"),
    ("neg-effect-item", "effect E { }\n"),
    ("neg-capability-item", "capability C { }\n"),
    ("neg-require-call", "require(\"m\");\n"),
    ("neg-fn-generics", "fn f<T>(x) { x }\n"),
    ("neg-struct-missing-colon", "struct S { x i64 }\n"),
    ("neg-struct-bad-spec", "struct S { x: 1 }\n"),
    ("neg-struct-unclosed", "struct S { x: i64,\n"),
    ("neg-enum-unclosed", "enum E { A,\n"),
    ("neg-enum-payload-unclosed", "enum E { A(i64,\n"),
    ("neg-enum-bad-spec", "enum E { A(1), }\n"),
    ("neg-struct-expr-face", "define(r, struct S { });\n"),
    ("neg-enum-expr-face", "define(r, enum E { });\n"),
    (
        "neg-extern-generics",
        "extern \"C\" { fn f<T>(x: int) -> int; }\n",
    ),
    ("neg-use-tree", "use a::{b, c};\n"),
    ("neg-use-as", "use a as b;\n"),
    ("neg-use-bad-form", "use 1;\n"),
    // ORCH blade 1 (O1): the composition face's rejection family
    // (the `use` family's own shapes) plus the keyword reservation
    // (a call form / an fn name reject at the reader).
    ("neg-import-tree", "import a::{b, c};\n"),
    ("neg-import-as", "import a as b;\n"),
    ("neg-import-bad-form", "import 1;\n"),
    ("neg-import-call-form", "import(\"std/error\");\n"),
    ("neg-import-fn-name", "fn import(x) { x }\n"),
    ("neg-macro-empty", "macro m { }\n"),
    ("neg-macro-two", "macro m { (a) (b) }\n"),
    ("neg-index", "fn f(a) { a[0] }\n"),
    ("neg-field", "fn f(a) { a.b }\n"),
    ("neg-cast", "fn f(a) { a as int }\n"),
    ("neg-fn-expr", "define(r, fn(x) { x });\n"),
    ("neg-impl-expr", "define(r, impl { });\n"),
    ("neg-resume-pos", "define(r, resume(1));\n"),
    ("neg-halt-pos", "define(r, halt);\n"),
    ("neg-pass-pos", "define(r, pass);\n"),
    ("neg-cmp-chain", "fn f(a, b, c) { a < b < c }\n"),
    ("neg-range", "fn f(a, b) { a..b }\n"),
    (
        "neg-or-pattern",
        "fn f(x) { match x { 1 | 2 => { 0 }, } }\n",
    ),
    (
        "neg-match-guard",
        "fn f(x) { match x { 1 if true => { 0 }, } }\n",
    ),
    (
        "neg-tuple3",
        "fn f(x) { match x { (a, b, c) => { a }, } }\n",
    ),
    (
        "neg-pattern-path",
        "fn f(x) { match x { a::b => { 0 }, } }\n",
    ),
    (
        "neg-pattern-at",
        "fn f(x) { match x { a @ 1 => { 0 }, } }\n",
    ),
    (
        "neg-pattern-trailing-comma",
        "fn f(x) { match x { (a, ) => { 0 }, } }\n",
    ),
    ("neg-empty-match", "fn f(x) { match x { } }\n"),
    ("neg-stray-brace", "fn f() { 1 } }\n"),
    ("neg-stray-paren", "define(r, 1));\n"),
    ("neg-stray-bracket", "define(r, 1]);\n"),
    ("neg-unclosed-block", "fn f() { 1\n"),
    ("neg-unclosed-module", "module m {\n"),
    ("neg-unclosed-match", "fn f(x) { match x {\n"),
    ("neg-empty-quote-list", "quote(());\n"),
    ("neg-quote-two", "quote((a, b c));\n"),
    ("neg-missing-semi", "define(r, 1)\n"),
    ("neg-bad-token-flow", "fn f() { let = 1; }\n"),
    ("neg-depth-cap", "fn f() { { { { 1 } } } }\n"),
];

// ---------------------------------------------------------------------------
// The tree rebuild — the composition chain's junction feed (blade 3).
// The `rebuild_read_forms` lineage (lexer_parity) carried to the
// TARGET twins: the same record grammar `decode_tp_tree` renders,
// value-shaped — one `SyntaxObject` per record, source spans,
// generation ROOT (the read chain's products are source syntax;
// macro generations begin at the expansion layer, never below it).
// ---------------------------------------------------------------------------

/// The span a record's byte offsets stand for (source spans — the
/// twin's spans are the oracle's own token extents).
fn tp_span_of(s: i64, e: i64) -> Result<Span, String> {
    span_of(s, e)
}

/// One node of the rebuilt forms tree (the `decode_tp_tree` grammar,
/// value-shaped).
fn rebuild_tp_node(value: &Value, heap: &Heap, _source: &str) -> Result<SyntaxObject, String> {
    let elems = value_elems(value, heap).map_err(|e| format!("tree record: {e}"))?;
    need_fields(&elems, 3, "tree record")?;
    let tag = as_str(elems[0]).map_err(|e| format!("tree tag: {e}"))?;
    let s = as_i64(elems[1]).map_err(|e| format!("tree span start: {e}"))?;
    let e = as_i64(elems[2]).map_err(|e| format!("tree span end: {e}"))?;
    let host = |datum, span| SyntaxObject {
        datum,
        span,
        scopes: ScopeSet::new(),
        phase: Phase::Runtime,
    };
    match tag {
        "ident" => {
            let text = decode_bytes(elems.get(3).ok_or("ident lacks its text")?, heap, "ident")?;
            let sym = kerf_span::Symbol::new(&text).map_err(|err| {
                format!("harness defect: the twin emitted an invalid identifier ({err:?})")
            })?;
            Ok(host(StxDatum::Symbol(sym), tp_span_of(s, e)?))
        }
        "int" => {
            let v = as_i64(elems.get(3).ok_or("int lacks its value")?)
                .map_err(|e| format!("int payload: {e}"))?;
            Ok(host(StxDatum::Int(v), tp_span_of(s, e)?))
        }
        "float" => {
            // The injected Debug text rides through verbatim — the
            // oracle's own {v:?} of the same f64; Debug is
            // roundtrip-exact, so the parse restores the value.
            let text = as_str(elems.get(3).ok_or("float lacks its text")?)
                .map_err(|e| format!("float payload: {e}"))?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("harness defect: float text `{text}` does not parse"))?;
            Ok(host(StxDatum::Float(v), tp_span_of(s, e)?))
        }
        "dfloat" => {
            // The K20 value face: the twin carried the positive
            // lexeme's Debug text; the host negates the parsed f64.
            let text = as_str(elems.get(3).ok_or("dfloat lacks its text")?)
                .map_err(|e| format!("dfloat payload: {e}"))?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("harness defect: dfloat text `{text}` does not parse"))?;
            Ok(host(StxDatum::Float(-v), tp_span_of(s, e)?))
        }
        "bool" => match elems.get(3) {
            Some(Value::Bool(b)) => Ok(host(StxDatum::Bool(*b), tp_span_of(s, e)?)),
            Some(other) => Err(format!("harness defect: bool payload is {other:?}")),
            None => Err("harness defect: bool record lacks its payload".to_string()),
        },
        "string" => {
            let text = as_str(elems.get(3).ok_or("string lacks its text")?)
                .map_err(|e| format!("string payload: {e}"))?;
            Ok(host(StxDatum::String(Rc::from(text)), tp_span_of(s, e)?))
        }
        "list" => {
            let mut items = Vec::with_capacity(elems.len() - 3);
            for child in &elems[3..] {
                items.push(rebuild_tp_node(child, heap, _source)?);
            }
            Ok(host(StxDatum::List(items), tp_span_of(s, e)?))
        }
        "use-str" => {
            // The K20 use-form skin mapping: the host maps the raw
            // module text through skin_symbol — the oracle's own
            // single source (a mapping failure is the oracle's own
            // InvalidSymbol; the twin never reaches it — the record
            // decodes as the oracle's tree would have).
            need_fields(&elems, 7, "use-str record")?;
            let kw_s = s;
            let kw_e = e;
            let name_s = as_i64(elems[3]).map_err(|e| format!("use-str name span: {e}"))?;
            let name_e = as_i64(elems[4]).map_err(|e| format!("use-str name span: {e}"))?;
            let semi_e = as_i64(elems[5]).map_err(|e| format!("use-str semi span: {e}"))?;
            let raw = as_str(elems.get(6).ok_or("use-str lacks its text")?)
                .map_err(|e| format!("use-str payload: {e}"))?;
            let mapped = skin_symbol(raw).map_err(|err| {
                format!("harness defect: the twin use-str is unmappable ({err:?})")
            })?;
            let head =
                kerf_span::Symbol::new("require").expect("the require spelling is a valid symbol");
            Ok(host(
                StxDatum::List(vec![
                    SyntaxObject {
                        datum: StxDatum::Symbol(head),
                        span: tp_span_of(kw_s, kw_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                    SyntaxObject {
                        datum: StxDatum::String(Rc::from(mapped.as_str())),
                        span: tp_span_of(name_s, name_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                ]),
                tp_span_of(kw_s, semi_e)?,
            ))
        }
        "use-path" => {
            need_fields(&elems, 6, "use-path record")?;
            let kw_s = s;
            let kw_e = e;
            let seg_end = as_i64(elems[3]).map_err(|e| format!("use-path segment end: {e}"))?;
            let semi_e = as_i64(elems[4]).map_err(|e| format!("use-path semi span: {e}"))?;
            let text = decode_bytes(
                elems.get(5).ok_or("use-path lacks its text")?,
                heap,
                "use-path",
            )?;
            let head =
                kerf_span::Symbol::new("require").expect("the require spelling is a valid symbol");
            Ok(host(
                StxDatum::List(vec![
                    SyntaxObject {
                        datum: StxDatum::Symbol(head),
                        span: tp_span_of(kw_s, kw_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                    SyntaxObject {
                        datum: StxDatum::String(Rc::from(text.as_str())),
                        span: tp_span_of(kw_s, seg_end)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                ]),
                tp_span_of(kw_s, semi_e)?,
            ))
        }
        // ORCH blade 1 (O7): the composition declaration's records —
        // the use arms' mirror with the verbatim-payload divergence
        // (no skin mapping: the unit registry resolves the exact
        // text).
        "import-str" => {
            need_fields(&elems, 7, "import-str record")?;
            let kw_s = s;
            let kw_e = e;
            let name_s = as_i64(elems[3]).map_err(|e| format!("import-str name span: {e}"))?;
            let name_e = as_i64(elems[4]).map_err(|e| format!("import-str name span: {e}"))?;
            let semi_e = as_i64(elems[5]).map_err(|e| format!("import-str semi span: {e}"))?;
            let raw = as_str(elems.get(6).ok_or("import-str lacks its text")?)
                .map_err(|e| format!("import-str payload: {e}"))?;
            let head =
                kerf_span::Symbol::new("import").expect("the import spelling is a valid symbol");
            Ok(host(
                StxDatum::List(vec![
                    SyntaxObject {
                        datum: StxDatum::Symbol(head),
                        span: tp_span_of(kw_s, kw_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                    SyntaxObject {
                        datum: StxDatum::String(Rc::from(raw)),
                        span: tp_span_of(name_s, name_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                ]),
                tp_span_of(kw_s, semi_e)?,
            ))
        }
        "import-path" => {
            need_fields(&elems, 6, "import-path record")?;
            let kw_s = s;
            let kw_e = e;
            let seg_end = as_i64(elems[3]).map_err(|e| format!("import-path segment end: {e}"))?;
            let semi_e = as_i64(elems[4]).map_err(|e| format!("import-path semi span: {e}"))?;
            let text = decode_bytes(
                elems.get(5).ok_or("import-path lacks its text")?,
                heap,
                "import-path",
            )?;
            let head =
                kerf_span::Symbol::new("import").expect("the import spelling is a valid symbol");
            Ok(host(
                StxDatum::List(vec![
                    SyntaxObject {
                        datum: StxDatum::Symbol(head),
                        span: tp_span_of(kw_s, kw_e)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                    SyntaxObject {
                        datum: StxDatum::String(Rc::from(text.as_str())),
                        span: tp_span_of(kw_s, seg_end)?,
                        scopes: ScopeSet::new(),
                        phase: Phase::Runtime,
                    },
                ]),
                tp_span_of(kw_s, semi_e)?,
            ))
        }
        other => Err(format!("harness defect: unknown tree record tag `{other}`")),
    }
}

/// Rebuild the twin's `tp_verdict` tree into `Vec<SyntaxObject>` (the
/// cross-stage feed — the composition chain's junction input and the
/// fixpoint purity leg's read face). `Ok(None)` on the twin's own
/// rejection (a rejection feeds nothing forward); `Err` on a harness
/// defect.
pub fn rebuild_tp_forms(
    value: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Option<Vec<SyntaxObject>>, String> {
    let elems = value_elems(value, heap).map_err(|e| format!("verdict chain: {e}"))?;
    need_fields(&elems, 1, "verdict")?;
    let tag = as_str(elems[0]).map_err(|e| format!("verdict tag: {e}"))?;
    match tag {
        "ok" => {
            let mut forms = Vec::with_capacity(elems.len().saturating_sub(1));
            for form in &elems[1..] {
                forms.push(rebuild_tp_node(form, heap, source)?);
            }
            Ok(Some(forms))
        }
        "err" => Ok(None),
        other => Err(format!("harness defect: unknown verdict tag `{other}`")),
    }
}

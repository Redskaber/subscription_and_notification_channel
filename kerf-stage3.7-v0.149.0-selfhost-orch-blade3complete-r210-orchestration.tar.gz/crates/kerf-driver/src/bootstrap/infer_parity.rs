//! The W-HM-TWIN segment-three parity faces (w-hm-twin-window.md §3,
//! the 127-a MUV): the HM inference twin — `selfhost/v1/infer.ktf`,
//! the full `infer_module` mirror written in the frozen target
//! subset — checked against the Rust inference oracle
//! (`kerf_typecheck::infer_module`) bit-for-bit on the inference
//! axis: the tdef table (flat define order, budget survivors only),
//! the generalized schemas (the quantified var indices included —
//! the engine's metavariable numbering is part of the parity face),
//! the resolved annotation trees, the effect rows and the
//! diagnostics channel (report order, the template payload rendered
//! through the oracle's own format strings — the R8 single-source
//! dictionary).
//!
//! Hosting (TWIN-2, the INJ-1 channel's segment-three payload — the
//! same channel serves segments one/two/three): the host runs the
//! Rust reader and the Rust expander — the single sources of tree
//! truth for their layers — and injects the EXPANDED item tree as a
//! flat pre-order record stream through the channel's value face
//! ([`items_stream_literal`] — the value twin of the text route's
//! `items_stream_prefix`). The same grammar `compiler.ktf` consumes
//! (the CP-1 vocabulary contract): records are proper lists with the
//! trailing generation field, children follow as the next records,
//! variable-arity records carry their count in a field; literal
//! components ride the `lint`/`lfloat`/`lbool`/`lstring`/`lnil`/
//! `lpair` vocabulary, spans as decimal strings, floats as Debug
//! text.
//!
//! Comparison face: both sides render into the same compact verdict
//! text — `(ok (types (tdef ...) ...) (diags (tdiag ...) ...))` —
//! types as the engine's display strings (the twin's algebra and the
//! oracle's `Type` Display produce the same strings by construction:
//! the bare grounds `int`/`float`/`bool`/`str`/`nil`/`dyn`, the
//! metavariables `t{n}`, the structural `(pair A B)` and
//! `(fn (P...) R)`); spans as decimal strings; effect rows as the
//! ordered name list; the diagnostics as the five-field record with
//! the template payload rendered through the oracle's format strings
//! (the twin's payload carries the structured template id plus
//! arguments, never a baked message).

use std::rc::Rc;

use kerf_core::{Binding, CoreExpr, ExternItem, HandlerClause, LiteralValue, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_typecheck::{
    EffectRow, INFERENCE_DEPTH_LIMIT, InferOutcome, Severity, Type, TypeCode, TypeDiagnostic,
    TypeSchema, TypedBinding, TypedDefine, TypedExpr, TypedHandler, infer_module,
};
use kerf_vm::{Heap, Value};

use crate::bootstrap::vm_harness::{as_i64, as_str, need_fields, value_elems};

// ---------- the value-face payload (the CP-1 record stream) ----------

/// The value-face item-record stream — the injection payload for the
/// segment-three twin: one flat pre-order record per item /
/// expression / binding / clause / literal component, the value twin
/// of the text route's `items_stream_prefix` (compiler_parity). The
/// empty stream rides as `nil` (the datum face of the empty list —
/// the forms-stream precedent).
///
/// r144: the trailing generation field rides as an INT — the CP-1
/// text grammar's own form ("the trailing generation int closing
/// every record"), and load-bearing on the compile segment: the
/// compiler twin passes the input generation through to its
/// product's dbg span records verbatim, and the rebuild face
/// (`dump_ktf_span`) rejects a string generation. The previous
/// string spelling rode only through the checker twins (which
/// carry the field opaquely), so the assembled text route — the
/// only compile-segment delivery before the A/B/C pipeline — never
/// exposed the mismatch.
pub fn items_stream_literal(items: &[ModuleItem]) -> LiteralValue {
    if items.is_empty() {
        return LiteralValue::Nil;
    }
    let mut records: Vec<LiteralValue> = Vec::new();
    for item in items {
        emit_item_literal(item, &mut records);
    }
    let mut list = LiteralValue::Nil;
    for record in records.iter().rev() {
        list = LiteralValue::Pair(Box::new(record.clone()), Box::new(list));
    }
    list
}

/// A proper list from a field vector (the trailing nil terminator is
/// part of the grammar — the twin's cdr-walking accessors rely on
/// it).
fn lv_list(fields: Vec<LiteralValue>) -> LiteralValue {
    let mut out = LiteralValue::Nil;
    for f in fields.into_iter().rev() {
        out = LiteralValue::Pair(Box::new(f), Box::new(out));
    }
    out
}

fn lv_str(s: &str) -> LiteralValue {
    LiteralValue::String(Rc::from(s))
}

fn span_pair(span: Span) -> (String, String) {
    (span.start.0.to_string(), span.end.0.to_string())
}

/// One literal value in the stream vocabulary (`lint`/`lfloat`/
/// `lbool`/`lstring`/`lnil` close themselves; `lpair` emits its two
/// components as the next records). The walk is ITERATIVE on
/// purpose: a flat list's right spine is as deep as the list is
/// long, and the stream carries user quote data of arbitrary spine
/// depth — the K163 family's r148 sixth instance (the compile
/// segment's production stream exposed it: the oracle chain walks
/// the same input on the default stack, so the encoder must too —
/// the `pair_cells`/`from_literal`/`rebuild_lit` precedents). The
/// explicit stack preserves the recursive form's visit order
/// exactly: the pair marker, the left subtree, then the right.
fn emit_litval_literal(value: &LiteralValue, out: &mut Vec<LiteralValue>) {
    let mut pending: Vec<&LiteralValue> = vec![value];
    while let Some(current) = pending.pop() {
        match current {
            LiteralValue::Int(v) => out.push(lv_list(vec![lv_str("lint"), LiteralValue::Int(*v)])),
            LiteralValue::Float(v) => {
                out.push(lv_list(vec![lv_str("lfloat"), lv_str(&format!("{v:?}"))]))
            }
            LiteralValue::Bool(v) => {
                out.push(lv_list(vec![lv_str("lbool"), LiteralValue::Bool(*v)]))
            }
            LiteralValue::String(v) => {
                out.push(lv_list(vec![lv_str("lstring"), lv_str(v.as_ref())]))
            }
            LiteralValue::Nil => out.push(lv_list(vec![lv_str("lnil")])),
            LiteralValue::Pair(a, b) => {
                out.push(lv_list(vec![lv_str("lpair")]));
                // Pushed in reverse so the LEFT child pops first —
                // the recursive form's visit order, exactly.
                pending.push(b);
                pending.push(a);
            }
        }
    }
}

/// One binding record: `("bind" s e name g)` with the value as the
/// next record.
fn emit_binding_literal(b: &Binding, out: &mut Vec<LiteralValue>) {
    let (s, e) = span_pair(b.span);
    out.push(lv_list(vec![
        lv_str("bind"),
        lv_str(&s),
        lv_str(&e),
        lv_str(b.name.as_str()),
        LiteralValue::Int(i64::from(b.span.expansion_id.0)),
    ]));
    emit_expr_literal(&b.value, out);
}

/// One handler-clause record: `("clause" s e effect g)` with the
/// handler expression as the next record.
fn emit_clause_literal(h: &HandlerClause, out: &mut Vec<LiteralValue>) {
    let (s, e) = span_pair(h.span);
    out.push(lv_list(vec![
        lv_str("clause"),
        lv_str(&s),
        lv_str(&e),
        lv_str(h.effect.as_str()),
        LiteralValue::Int(i64::from(h.span.expansion_id.0)),
    ]));
    emit_expr_literal(&h.handler, out);
}

/// One expression record into the flat pre-order stream — the value
/// twin of `compiler_parity::emit_expr` (the single-source CP-1
/// vocabulary contract).
fn emit_expr_literal(expr: &CoreExpr, out: &mut Vec<LiteralValue>) {
    let (s, e) = span_pair(expr_span(expr));
    let g = LiteralValue::Int(i64::from(expr_span(expr).expansion_id.0));
    match expr {
        CoreExpr::Fn { params, body, .. } => {
            let params_list = if params.is_empty() {
                LiteralValue::Nil
            } else {
                lv_list(params.iter().map(|p| lv_str(p.as_str())).collect())
            };
            out.push(lv_list(vec![
                lv_str("fn"),
                lv_str(&s),
                lv_str(&e),
                params_list,
                g,
            ]));
            emit_expr_literal(body, out);
        }
        CoreExpr::Apply { func, args, .. } => {
            out.push(lv_list(vec![
                lv_str("apply"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(args.len()).expect("arity fits i64")),
                g,
            ]));
            for a in args {
                emit_expr_literal(a, out);
            }
            emit_expr_literal(func, out);
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            out.push(lv_list(vec![lv_str("if"), lv_str(&s), lv_str(&e), g]));
            emit_expr_literal(cond, out);
            emit_expr_literal(then_branch, out);
            emit_expr_literal(else_branch, out);
        }
        CoreExpr::Var { name, .. } => {
            out.push(lv_list(vec![
                lv_str("var"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                g,
            ]));
        }
        CoreExpr::Literal { value, .. } => {
            out.push(lv_list(vec![lv_str("lit"), lv_str(&s), lv_str(&e), g]));
            emit_litval_literal(value, out);
        }
        CoreExpr::Assign { name, value, .. } => {
            out.push(lv_list(vec![
                lv_str("assign"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                g,
            ]));
            emit_expr_literal(value, out);
        }
        CoreExpr::Let { bindings, body, .. } => {
            out.push(lv_list(vec![
                lv_str("let"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(bindings.len()).expect("arity fits i64")),
                g,
            ]));
            for b in bindings {
                emit_binding_literal(b, out);
            }
            emit_expr_literal(body, out);
        }
        CoreExpr::Perform { effect, args, .. } => {
            out.push(lv_list(vec![
                lv_str("perform"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(args.len()).expect("arity fits i64")),
                lv_str(effect.as_str()),
                g,
            ]));
            for a in args {
                emit_expr_literal(a, out);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            out.push(lv_list(vec![
                lv_str("handle"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(handlers.len()).expect("arity fits i64")),
                g,
            ]));
            for h in handlers {
                emit_clause_literal(h, out);
            }
            emit_expr_literal(body, out);
        }
    }
}

/// One item record into the flat pre-order stream — the value twin
/// of `compiler_parity::emit_item`.
fn emit_item_literal(item: &ModuleItem, out: &mut Vec<LiteralValue>) {
    match item {
        ModuleItem::Define { span, name, value } => {
            let (s, e) = span_pair(*span);
            let mut fields = vec![
                lv_str("define"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                LiteralValue::Int(i64::from(span.expansion_id.0)),
            ];
            out.push(lv_list(std::mem::take(&mut fields)));
            emit_expr_literal(value, out);
        }
        ModuleItem::Require { span, module } => {
            let (s, e) = span_pair(*span);
            out.push(lv_list(vec![
                lv_str("require"),
                lv_str(&s),
                lv_str(&e),
                lv_str(module.as_str()),
                LiteralValue::Int(i64::from(span.expansion_id.0)),
            ]));
        }
        ModuleItem::DefineSyntax { span, name } => {
            let (s, e) = span_pair(*span);
            out.push(lv_list(vec![
                lv_str("defsyn"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                LiteralValue::Int(i64::from(span.expansion_id.0)),
            ]));
        }
        // The blade 1 dann site record (GZ-1): the full payload rides
        // the infer twin's input stream — the inference walk collects
        // these into its anchor-keyed table (the spec value tree is
        // already a LiteralValue: it rides as-is, no transcoding).
        ModuleItem::Annotate {
            span,
            anchor,
            kind,
            index,
            spec,
        } => {
            let (s, e) = span_pair(*span);
            let (as_, ae) = span_pair(*anchor);
            out.push(lv_list(vec![
                lv_str("dann"),
                lv_str(&s),
                lv_str(&e),
                lv_str(kind.kind_tag()),
                lv_str(&as_),
                lv_str(&ae),
                LiteralValue::Int(i64::from(*index)),
                spec.clone(),
            ]));
        }
        ModuleItem::Struct { span, name, fields } => {
            // The blade 2 struct record (GZ-2): the full payload
            // rides the infer twin's input stream — the resolve
            // table's struct half collects these (name + each
            // field's spec value tree, already LiteralValues).
            let (s, e) = span_pair(*span);
            let field_list: Vec<LiteralValue> = fields
                .iter()
                .map(|(fname, spec)| lv_list(vec![lv_str(fname.as_str()), spec.clone()]))
                .collect();
            out.push(lv_list(vec![
                lv_str("dstruct"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                lv_list(field_list),
            ]));
        }
        ModuleItem::Enum {
            span,
            name,
            variants,
        } => {
            // The blade 3 enum record (GZ-4): the full payload rides
            // the infer twin's input stream — the resolve table's
            // enum half collects these (name + each variant's spec
            // value trees, already LiteralValues). Each variant is
            // (v) for the payload-less form, (v spec...) for the
            // payload form (the struct field strip's own face).
            let (s, e) = span_pair(*span);
            let variant_list: Vec<LiteralValue> = variants
                .iter()
                .map(|(vname, specs)| {
                    let mut entries = Vec::with_capacity(specs.len() + 1);
                    entries.push(lv_str(vname.as_str()));
                    for spec in specs {
                        entries.push(spec.clone());
                    }
                    lv_list(entries)
                })
                .collect();
            out.push(lv_list(vec![
                lv_str("denum"),
                lv_str(&s),
                lv_str(&e),
                lv_str(name.as_str()),
                lv_list(variant_list),
            ]));
        }
        ModuleItem::Module { span, name, items } => {
            let (s, e) = span_pair(*span);
            out.push(lv_list(vec![
                lv_str("module"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(items.len()).expect("arity fits i64")),
                lv_str(name.as_str()),
                LiteralValue::Int(i64::from(span.expansion_id.0)),
            ]));
            for inner in items {
                emit_item_literal(inner, out);
            }
        }
        ModuleItem::Extern { span, items, .. } => {
            let (s, e) = span_pair(*span);
            let mut fields = vec![
                lv_str("extern"),
                lv_str(&s),
                lv_str(&e),
                LiteralValue::Int(i64::try_from(items.len()).expect("arity fits i64")),
                LiteralValue::Int(i64::from(span.expansion_id.0)),
            ];
            for entry in items {
                fields.push(extern_entry_literal(entry));
            }
            out.push(lv_list(fields));
        }
    }
}

/// One extern entry: `(name ("tag" ...) "ret-tag")` — the r124
/// junction-3 face (the params and ret as quoted tag strings).
fn extern_entry_literal(entry: &ExternItem) -> LiteralValue {
    let params = lv_list(entry.params.iter().map(|t| lv_str(t.kind_tag())).collect());
    lv_list(vec![
        lv_str(entry.name.as_str()),
        params,
        lv_str(entry.ret.kind_tag()),
    ])
}

/// Every CoreExpr variant carries a `span` field (the constructor
/// contract); this reads it without consuming the enum (the
/// compiler_parity precedent, verbatim).
fn expr_span(expr: &CoreExpr) -> Span {
    match expr {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

// ---------- the oracle face (the inference axis) ----------

/// The Rust inference oracle's verdict text on the inference axis:
/// `infer_module` over the production externals (the pipeline
/// composition — `pipeline_externals(items)`, the 18-builtin table
/// plus the program's own extern declarations), rendered into the
/// same compact face the twin's product decodes into.
pub fn oracle_inference_axes(items: &[ModuleItem]) -> String {
    let externals = crate::pipeline::pipeline_externals(items);
    let outcome: InferOutcome = infer_module(items, &externals);
    let mut out = String::from("(ok (types");
    for d in &outcome.typed.defines {
        out.push(' ');
        out.push_str(&oracle_tdef(d));
    }
    out.push_str(") (diags");
    for d in &outcome.diagnostics {
        out.push(' ');
        out.push_str(&oracle_tdiag(d));
    }
    out.push_str("))");
    out
}

/// One tdef record: `(tdef name (schema (vars...) body) (effs ...) tnode)`.
fn oracle_tdef(d: &TypedDefine) -> String {
    format!(
        "(tdef {} {} {} {})",
        d.name.as_str(),
        oracle_schema(&d.schema),
        oracle_row(&d.effects),
        oracle_tnode(&d.body)
    )
}

/// One schema record: `(schema (vars...) body)` — the quantified
/// metavariable indices in deterministic first-seen order (part of
/// the parity face: the twin's numbering must match the engine's).
fn oracle_schema(s: &TypeSchema) -> String {
    let vars = s
        .vars
        .iter()
        .map(|v| v.to_string())
        .collect::<Vec<_>>()
        .join(" ");
    format!("(schema ({vars}) {})", s.body)
}

/// One effect row: `(effs name ...)` — the ordered name list (the
/// row algebra's first-seen order; empty renders as `(effs)`).
fn oracle_row(r: &EffectRow) -> String {
    let mut out = String::from("(effs");
    for e in r.as_slice() {
        out.push(' ');
        out.push_str(e.as_str());
    }
    out.push(')');
    out
}

/// One annotation tree node — the twin's tnode vocabulary rendered
/// from the oracle's `TypedExpr` (same fields, same order).
fn oracle_tnode(node: &TypedExpr) -> String {
    match node {
        TypedExpr::Fn {
            span,
            params,
            body,
            ty,
        } => {
            let ps = params
                .iter()
                .map(|p| p.as_str().to_string())
                .collect::<Vec<_>>();
            format!(
                "(tfn {} {} ({}) {} {})",
                span.start.0,
                span.end.0,
                ps.join(" "),
                oracle_tnode(body),
                ty
            )
        }
        TypedExpr::Apply {
            span,
            func,
            args,
            ty,
            effects,
        } => {
            let args_str = args.iter().map(oracle_tnode).collect::<Vec<_>>().join(" ");
            format!(
                "(tapply {} {} {} ({}) {} {})",
                span.start.0,
                span.end.0,
                oracle_tnode(func),
                args_str,
                ty,
                oracle_row(effects)
            )
        }
        TypedExpr::If {
            span,
            cond,
            then_branch,
            else_branch,
            ty,
            effects,
        } => format!(
            "(tif {} {} {} {} {} {} {})",
            span.start.0,
            span.end.0,
            oracle_tnode(cond),
            oracle_tnode(then_branch),
            oracle_tnode(else_branch),
            ty,
            oracle_row(effects)
        ),
        TypedExpr::Var { span, name, ty } => {
            format!(
                "(tvar {} {} {} {})",
                span.start.0,
                span.end.0,
                name.as_str(),
                ty
            )
        }
        TypedExpr::Literal { span, value, ty } => format!(
            "(tlit {} {} {} {})",
            span.start.0,
            span.end.0,
            oracle_litval(value),
            ty
        ),
        TypedExpr::Assign {
            span,
            name,
            value,
            ty,
            effects,
        } => format!(
            "(tassign {} {} {} {} {} {})",
            span.start.0,
            span.end.0,
            name.as_str(),
            oracle_tnode(value),
            ty,
            oracle_row(effects)
        ),
        TypedExpr::Let {
            span,
            bindings,
            body,
            ty,
            effects,
        } => {
            let bs = bindings
                .iter()
                .map(|b| {
                    format!(
                        "(tbind {} {} {} {} {})",
                        b.span.start.0,
                        b.span.end.0,
                        b.name.as_str(),
                        b.ty,
                        oracle_tnode(&b.value)
                    )
                })
                .collect::<Vec<_>>()
                .join(" ");
            format!(
                "(tlet {} {} ({}) {} {} {})",
                span.start.0,
                span.end.0,
                bs,
                oracle_tnode(body),
                ty,
                oracle_row(effects)
            )
        }
        TypedExpr::Perform {
            span,
            effect,
            args,
            ty,
            effects,
        } => {
            let args_str = args.iter().map(oracle_tnode).collect::<Vec<_>>().join(" ");
            format!(
                "(tperform {} {} {} ({}) {} {})",
                span.start.0,
                span.end.0,
                effect.as_str(),
                args_str,
                ty,
                oracle_row(effects)
            )
        }
        TypedExpr::Handle {
            span,
            body,
            handlers,
            ty,
            effects,
        } => {
            let hs = handlers
                .iter()
                .map(|h| {
                    format!(
                        "(tclause {} {} {} {} {})",
                        h.span.start.0,
                        h.span.end.0,
                        h.effect.as_str(),
                        h.ty,
                        oracle_tnode(&h.handler)
                    )
                })
                .collect::<Vec<_>>()
                .join(" ");
            format!(
                "(thandle {} {} {} ({}) {} {})",
                span.start.0,
                span.end.0,
                oracle_tnode(body),
                hs,
                ty,
                oracle_row(effects)
            )
        }
    }
}

/// One literal value in the twin's converted vocabulary — the
/// `("int" 42)` family the twin's `ti_lit_walk` consumes and the
/// `tlit` node embeds.
fn oracle_litval(v: &LiteralValue) -> String {
    match v {
        LiteralValue::Int(i) => format!("(int {i})"),
        LiteralValue::Float(f) => format!("(float {:?})", f),
        LiteralValue::Bool(b) => format!("(bool {})", if *b { "#t" } else { "#f" }),
        LiteralValue::String(s) => format!("(string \"{s}\")"),
        LiteralValue::Nil => "nil".to_string(),
        LiteralValue::Pair(a, b) => {
            format!("(pair {} {})", oracle_litval(a), oracle_litval(b))
        }
    }
}

/// One tdiag record: `(tdiag code severity s e message)` — the
/// oracle's own rendered message (the twin's payload must produce
/// the same text through the template table).
fn oracle_tdiag(d: &TypeDiagnostic) -> String {
    let sev = match d.severity {
        Severity::Error => "error",
        Severity::Warning => "warning",
    };
    format!(
        "(tdiag {} {} {} {} {})",
        d.code.as_str(),
        sev,
        d.span.start.0,
        d.span.end.0,
        d.message
    )
}

// ---------- the twin product decoder ----------

/// The twin's `result` global decoded into the same compact verdict
/// text the oracle face renders — the comparison point of the sweep.
pub fn decode_infer_result(value: &Value, heap: &Heap) -> Result<String, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "the twin's result record")?;
    if as_str(elems[0])? != "ok" {
        return Err(format!(
            "the twin's verdict tag is `{}` — the module driver must complete",
            as_str(elems[0])?
        ));
    }
    let types_secs = value_elems(elems[1], heap)?;
    if as_str(types_secs[0])? != "types" {
        return Err("the types section tag drifted".to_string());
    }
    let diags_secs = value_elems(elems[2], heap)?;
    if as_str(diags_secs[0])? != "diags" {
        return Err("the diags section tag drifted".to_string());
    }
    // The twin's sections carry the product list as their single
    // second field — ("types" tdef-list) / ("diags" diag-list):
    // decode the field as the list, then the records individually.
    let tdefs = value_elems(types_secs[1], heap)?;
    let tdiags = value_elems(diags_secs[1], heap)?;
    let mut out = String::from("(ok (types");
    for t in &tdefs {
        out.push(' ');
        out.push_str(&twin_tdef(t, heap)?);
    }
    out.push_str(") (diags");
    for d in &tdiags {
        out.push(' ');
        out.push_str(&twin_tdiag(d, heap)?);
    }
    out.push_str("))");
    Ok(out)
}

/// One twin tdef record: the decoded five-field list
/// `("tdef" name schema eff node)`. `pub(crate)` since the shared
/// dump renderer's `types` arm (compiler_parity) renders through
/// this same single-source decoder.
pub(crate) fn twin_tdef(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 5, "tdef record")?;
    if as_str(e[0])? != "tdef" {
        return Err(format!(
            "a non-tdef record in the types section: {}",
            as_str(e[0])?
        ));
    }
    let name = as_str(e[1])?;
    let schema = twin_schema(e[2], heap)?;
    let row = twin_row(e[3], heap)?;
    let node = twin_tnode(e[4], heap)?;
    Ok(format!("(tdef {name} {schema} {row} {node})"))
}

/// One twin schema record: `("schema" (vars...) body)`.
fn twin_schema(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 3, "schema record")?;
    if as_str(e[0])? != "schema" {
        return Err(format!("a non-schema record: {}", as_str(e[0])?));
    }
    let vars = value_elems(e[1], heap)?;
    let vars_str = vars
        .iter()
        .map(|v| as_i64(v).map(|i| i.to_string()))
        .collect::<Result<Vec<_>, _>>()?
        .join(" ");
    let body = twin_type_display(e[2], heap)?;
    Ok(format!("(schema ({vars_str}) {body})"))
}

/// One twin effect row: a proper list of effect-name strings.
fn twin_row(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    let mut out = String::from("(effs");
    for name in e {
        out.push(' ');
        out.push_str(as_str(name)?);
    }
    out.push(')');
    Ok(out)
}

/// One twin annotation tree node — the tnode vocabulary decoded from
/// the product tree (the twin's types are its own algebra values;
/// the display strings match the oracle's `Type` by construction).
fn twin_tnode(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    let tag = as_str(*e.first().ok_or("an empty tnode record")?)?;
    match tag {
        "tfn" => {
            need_fields(&e, 6, "tfn record")?;
            let ps = value_elems(e[3], heap)?;
            let params = ps
                .iter()
                .map(|p| Ok(as_str(p)?.to_string()))
                .collect::<Result<Vec<_>, String>>()?
                .join(" ");
            Ok(format!(
                "(tfn {} {} ({}) {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                params,
                twin_tnode(e[4], heap)?,
                twin_type_display(e[5], heap)?
            ))
        }
        "tapply" => {
            need_fields(&e, 7, "tapply record")?;
            let args = value_elems(e[4], heap)?;
            let args_str = args
                .iter()
                .map(|a| twin_tnode(a, heap))
                .collect::<Result<Vec<_>, _>>()?
                .join(" ");
            Ok(format!(
                "(tapply {} {} {} ({}) {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                twin_tnode(e[3], heap)?,
                args_str,
                twin_type_display(e[5], heap)?,
                twin_row(e[6], heap)?
            ))
        }
        "tif" => {
            need_fields(&e, 8, "tif record")?;
            Ok(format!(
                "(tif {} {} {} {} {} {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                twin_tnode(e[3], heap)?,
                twin_tnode(e[4], heap)?,
                twin_tnode(e[5], heap)?,
                twin_type_display(e[6], heap)?,
                twin_row(e[7], heap)?
            ))
        }
        "tvar" => {
            need_fields(&e, 5, "tvar record")?;
            Ok(format!(
                "(tvar {} {} {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                as_str(e[3])?,
                twin_type_display(e[4], heap)?
            ))
        }
        "tlit" => {
            need_fields(&e, 5, "tlit record")?;
            Ok(format!(
                "(tlit {} {} {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                twin_litval(e[3], heap)?,
                twin_type_display(e[4], heap)?
            ))
        }
        "tassign" => {
            need_fields(&e, 7, "tassign record")?;
            Ok(format!(
                "(tassign {} {} {} {} {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                as_str(e[3])?,
                twin_tnode(e[4], heap)?,
                twin_type_display(e[5], heap)?,
                twin_row(e[6], heap)?
            ))
        }
        "tlet" => {
            need_fields(&e, 7, "tlet record")?;
            let binds = value_elems(e[3], heap)?;
            let bs = binds
                .iter()
                .map(|b| {
                    let be = value_elems(b, heap)?;
                    need_fields(&be, 6, "tbind record")?;
                    if as_str(be[0])? != "tbind" {
                        return Err("a non-tbind record in the tlet list".to_string());
                    }
                    Ok(format!(
                        "(tbind {} {} {} {} {})",
                        as_str(be[1])?,
                        as_str(be[2])?,
                        as_str(be[3])?,
                        twin_type_display(be[4], heap)?,
                        twin_tnode(be[5], heap)?
                    ))
                })
                .collect::<Result<Vec<_>, _>>()?
                .join(" ");
            Ok(format!(
                "(tlet {} {} ({}) {} {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                bs,
                twin_tnode(e[4], heap)?,
                twin_type_display(e[5], heap)?,
                twin_row(e[6], heap)?
            ))
        }
        "tperform" => {
            need_fields(&e, 7, "tperform record")?;
            let args = value_elems(e[4], heap)?;
            let args_str = args
                .iter()
                .map(|a| twin_tnode(a, heap))
                .collect::<Result<Vec<_>, _>>()?
                .join(" ");
            Ok(format!(
                "(tperform {} {} {} ({}) {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                as_str(e[3])?,
                args_str,
                twin_type_display(e[5], heap)?,
                twin_row(e[6], heap)?
            ))
        }
        "thandle" => {
            need_fields(&e, 7, "thandle record")?;
            let clauses = value_elems(e[4], heap)?;
            let hs = clauses
                .iter()
                .map(|c| {
                    let ce = value_elems(c, heap)?;
                    need_fields(&ce, 6, "tclause record")?;
                    if as_str(ce[0])? != "tclause" {
                        return Err("a non-tclause record in the thandle list".to_string());
                    }
                    Ok(format!(
                        "(tclause {} {} {} {} {})",
                        as_str(ce[1])?,
                        as_str(ce[2])?,
                        as_str(ce[3])?,
                        twin_type_display(ce[4], heap)?,
                        twin_tnode(ce[5], heap)?
                    ))
                })
                .collect::<Result<Vec<_>, _>>()?
                .join(" ");
            Ok(format!(
                "(thandle {} {} {} ({}) {} {})",
                as_str(e[1])?,
                as_str(e[2])?,
                twin_tnode(e[3], heap)?,
                hs,
                twin_type_display(e[5], heap)?,
                twin_row(e[6], heap)?
            ))
        }
        other => Err(format!("unknown twin tnode tag `{other}`")),
    }
}

/// One twin type rendered as the engine's display string — the
/// oracle's `Type` Display produces the same text by construction
/// (the bare grounds, `t{n}` metavariables, the structural forms).
fn twin_type_display(v: &Value, heap: &Heap) -> Result<String, String> {
    match v {
        Value::Str(s) => Ok(s.to_string()),
        Value::Nil => Err("a bare nil in a type position".to_string()),
        Value::Pair(_) => {
            let e = value_elems(v, heap)?;
            let tag = as_str(*e.first().ok_or("an empty type record")?)?;
            match tag {
                "var" => {
                    need_fields(&e, 2, "var type")?;
                    Ok(format!("t{}", as_i64(e[1])?))
                }
                "pair" => {
                    need_fields(&e, 3, "pair type")?;
                    Ok(format!(
                        "(pair {} {})",
                        twin_type_display(e[1], heap)?,
                        twin_type_display(e[2], heap)?
                    ))
                }
                "fn" => {
                    need_fields(&e, 3, "fn type")?;
                    let ps = value_elems(e[1], heap)?;
                    let params = ps
                        .iter()
                        .map(|p| twin_type_display(p, heap))
                        .collect::<Result<Vec<_>, _>>()?
                        .join(" ");
                    // The blade 2 arrow-carried row (w-effect-mechanism
                    // §5.2): the four-element form carries the effect
                    // row in the fourth slot — the EMPTY closed row
                    // renders as nothing (the parity face stays
                    // bit-for-bit against the frozen oracle: every
                    // perform-free fn carries exactly it); a carrying
                    // row renders as the " | (row ...)" suffix (the
                    // beyond-oracle lane's own observable).
                    if e.len() >= 4 {
                        let row = twin_type_display(e[3], heap)?;
                        if row == "(row)" {
                            Ok(format!(
                                "(fn ({}) {})",
                                params,
                                twin_type_display(e[2], heap)?
                            ))
                        } else {
                            Ok(format!(
                                "(fn ({}) {} | {})",
                                params,
                                twin_type_display(e[2], heap)?,
                                row
                            ))
                        }
                    } else {
                        Ok(format!(
                            "(fn ({}) {})",
                            params,
                            twin_type_display(e[2], heap)?
                        ))
                    }
                }
                // The blade 2 nominal carrier (GZ-3): the name alone —
                // the same single display the oracle's `Type::Struct`
                // renders (never the unfolded spine).
                "struct" => {
                    need_fields(&e, 3, "struct type")?;
                    Ok(as_str(e[1])?.to_string())
                }
                // The blade 3 closed nominal carrier (GZ-4, §10.4):
                // the name alone — the struct face's own; never
                // unfolded (nothing unfolds).
                "enum" => {
                    need_fields(&e, 2, "enum type")?;
                    Ok(as_str(e[1])?.to_string())
                }
                // The row type (W-ROW-POLY blade 1, RW-7): the fields
                // render in order, the closed tail renders nothing,
                // the open tail renders `| tN` (the var display
                // convention); the empty closed row renders `(row)`.
                "row" => {
                    need_fields(&e, 3, "row type")?;
                    let fields = value_elems(e[1], heap)?;
                    let mut out = String::from("(row");
                    for f in &fields {
                        let fe = value_elems(f, heap)?;
                        need_fields(&fe, 2, "row field")?;
                        out.push(' ');
                        out.push_str(as_str(fe[0])?);
                        out.push(' ');
                        out.push_str(&twin_type_display(fe[1], heap)?);
                    }
                    match &e[2] {
                        Value::Str(s) if s.as_ref() == "nil" => {}
                        tail => {
                            out.push_str(" | ");
                            out.push_str(&twin_type_display(tail, heap)?);
                        }
                    }
                    out.push(')');
                    Ok(out)
                }
                other => Err(format!("unknown twin type tag `{other}`")),
            }
        }
        other => Err(format!("a non-type value in a type position: {other:?}")),
    }
}

/// One twin literal value in the converted vocabulary — the
/// `("int" 42)` family.
fn twin_litval(v: &Value, heap: &Heap) -> Result<String, String> {
    match v {
        Value::Nil => Ok("nil".to_string()),
        Value::Pair(_) => {
            let e = value_elems(v, heap)?;
            let tag = as_str(*e.first().ok_or("an empty litval record")?)?;
            match tag {
                "int" => {
                    need_fields(&e, 2, "int litval")?;
                    Ok(format!("(int {})", as_i64(e[1])?))
                }
                "float" => {
                    need_fields(&e, 2, "float litval")?;
                    Ok(format!("(float {})", as_str(e[1])?))
                }
                "bool" => {
                    need_fields(&e, 2, "bool litval")?;
                    match e[1] {
                        Value::Bool(true) => Ok("(bool #t)".to_string()),
                        Value::Bool(false) => Ok("(bool #f)".to_string()),
                        other => Err(format!("a non-bool payload in a bool litval: {other:?}")),
                    }
                }
                "string" => {
                    need_fields(&e, 2, "string litval")?;
                    Ok(format!("(string \"{}\")", as_str(e[1])?))
                }
                "pair" => {
                    need_fields(&e, 3, "pair litval")?;
                    Ok(format!(
                        "(pair {} {})",
                        twin_litval(e[1], heap)?,
                        twin_litval(e[2], heap)?
                    ))
                }
                other => Err(format!("unknown twin litval tag `{other}`")),
            }
        }
        other => Err(format!(
            "a non-litval value in a litval position: {other:?}"
        )),
    }
}

/// One twin tdiag record: `("tdiag" code sev s e payload)` — the
/// payload is the structured template id plus arguments; the message
/// renders through the oracle's own format strings (the R8
/// single-source dictionary below).
fn twin_tdiag(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 6, "tdiag record")?;
    if as_str(e[0])? != "tdiag" {
        return Err(format!("a non-tdiag record: {}", as_str(e[0])?));
    }
    let code = as_str(e[1])?;
    let sev = as_str(e[2])?;
    let s = as_str(e[3])?;
    let diag_e = as_str(e[4])?;
    let message = render_tdiag_template(e[5], heap)?;
    Ok(format!("(tdiag {code} {sev} {s} {diag_e} {message})"))
}

/// The R8 single-source dictionary — the inference layer's message
/// templates, the oracle's own format strings (the twin's payload
/// carries the template id plus the arguments flat —
/// `("tid" arg1 arg2 ...)`; this table is the only rendering
/// authority on the twin side, so the sweep cross-checks it against
/// the oracle's baked messages on every diagnostic row).
pub(crate) fn render_tdiag_template(payload: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(payload, heap)?;
    need_fields(&e, 2, "template payload")?;
    let id = as_str(e[0])?;
    let args = &e[1..];
    let arg_str = |i: usize| -> Result<String, String> {
        Ok(as_str(*args.get(i).ok_or("the template arity drifted")?)?.to_string())
    };
    let arg_ty = |i: usize| -> Result<String, String> {
        twin_type_display(*args.get(i).ok_or("the template arity drifted")?, heap)
    };
    // The occurs-check's subject is a metavariable index (a bare
    // int) — the engine's `t{var}` display, not a type record.
    let arg_meta = |i: usize| -> Result<String, String> {
        match args.get(i) {
            Some(Value::Int(n)) => Ok(format!("t{n}")),
            other => Err(format!("a non-index metavariable argument: {other:?}")),
        }
    };
    match id {
        // report_unify / the if-condition demand — the general
        // unification failure (`t5` bakes the demanded side as its
        // first argument; same rendered text either way).
        "t1" | "t5" => Ok(format!(
            "type mismatch: expected `{}`, found `{}`",
            arg_ty(0)?,
            arg_ty(1)?
        )),
        // apply_type's concrete branch — the non-callable callee.
        "t2" => Ok(format!(
            "type mismatch: expected a function, found `{}`",
            arg_ty(0)?
        )),
        // the ad-hoc numeric builtins' non-numeric operand.
        "t3" => Ok(format!(
            "type mismatch: expected `int` or `float`, found `{}`",
            arg_ty(0)?
        )),
        // the `car`/`cdr` pair demand — the non-pair operand.
        "t4" => Ok(format!(
            "type mismatch: expected `pair`, found `{}`",
            arg_ty(0)?
        )),
        // the `str` builtin's domain demand (the demanded side rides
        // as the first argument, the `t5` shape).
        "t6" => Ok(format!(
            "type mismatch: expected `{}`, found `{}`",
            arg_ty(0)?,
            arg_ty(1)?
        )),
        // the occurs check — the cyclic type.
        "t7" => Ok(format!(
            "recursive type: `{}` occurs in `{}`",
            arg_meta(0)?,
            arg_ty(1)?
        )),
        // the depth budget (E0011, warning severity; the limit is a
        // checker constant, baked into the template like the
        // oracle's own format string).
        "t8" => Ok(format!(
            "type inference budget of `{INFERENCE_DEPTH_LIMIT}` exceeded in `{}`",
            arg_str(0)?
        )),
        // The blade 1 annotation divergence (GZ-1, E0013): the
        // resolved annotation vs the deep-resolved inferred type —
        // the oracle's own message shape, both sides through the
        // twin type display.
        "t9" => Ok(format!(
            "annotation divergence: expected `{}`, found `{}`",
            arg_ty(0)?,
            arg_ty(1)?
        )),
        other => Err(format!("unknown template id `{other}`")),
    }
}

// ---------- the TWIN-4 parity-machine extension (127-c, face A) ----------

/// The oracle's types segment — `(types (tdef ...) ...)`: the tdef
/// family in the compact grammar, the same records the sweep's
/// verdict text carries, rendered as ONE section that rides the
/// compile product's analysis dump at the tail (w-hm-twin-window §3
/// TWIN-4 face A — the `oracle_analysis_dump` tail segment). The
/// single source is the same renderer pair the full-verdict face
/// uses (the private oracle_tdef) — this function only changes the
/// wrapper.
pub fn oracle_types_segment(items: &[ModuleItem]) -> String {
    let externals = crate::pipeline::pipeline_externals(items);
    let outcome: InferOutcome = infer_module(items, &externals);
    let mut out = String::from("(types");
    for d in &outcome.typed.defines {
        out.push(' ');
        out.push_str(&oracle_tdef(d));
    }
    out.push(')');
    out
}

/// The oracle's structural outcome for the rebuild's field-wise
/// comparison (the gate-B face's oracle side): `infer_module` under
/// the pipeline's own externals — the same single source the text
/// face renders from, exposed structurally for the tests.
pub fn oracle_infer_outcome(items: &[ModuleItem]) -> InferOutcome {
    let externals = crate::pipeline::pipeline_externals(items);
    infer_module(items, &externals)
}

// ---------- the 127-c structural rebuild (face C — the rebuild arm) ----------

/// One rebuilt tdef row: the fields the twin's product grammar
/// carries (name, schema, annotation tree, effect row). The define's
/// own name-span does NOT ride the grammar (the r127 product face —
/// the tree spans ride the tnodes, the define span does not); the
/// comparison against the oracle is field-wise on exactly these
/// fields (the parity family convention: what the grammar carries,
/// the face proves).
#[derive(Debug, Clone, PartialEq)]
pub struct RebuiltTdef {
    pub name: Symbol,
    pub schema: TypeSchema,
    pub body: TypedExpr,
    pub effects: Vec<Symbol>,
}

/// The structural rebuild of the infer twin's `("ok" ("types" ...)
/// ("diags" ...))` product: the tdef rows plus the diagnostics as
/// real [`TypeDiagnostic`] records (the "twin error keys = the Rust
/// TypeDiagnostic keys, bit-for-bit" contract — the rebuild is where
/// the twin's template payloads turn back into the oracle's own
/// record shape through the single-source dictionary). The inference
/// product's diagnostic records carry no subject set (the check
/// product's do); the rebuilt rows carry the empty set — the
/// field-wise comparison covers code/severity/span/message.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct RebuiltTypedVerdict {
    pub defines: Vec<RebuiltTdef>,
    pub diagnostics: Vec<TypeDiagnostic>,
}

/// Rebuild the twin's ok product into the structural records — the
/// segment-three twin of `rebuild_bytecode` (the gate-B face): every
/// section lands field-for-field, every malformed field fails closed
/// with a named error (never a silent drop).
pub fn rebuild_typed_verdict(value: &Value, heap: &Heap) -> Result<RebuiltTypedVerdict, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "the twin's result record")?;
    if as_str(elems[0])? != "ok" {
        return Err(format!(
            "rebuild_typed_verdict needs the ok product, found `{}` (the twin's \
             module driver must complete)",
            as_str(elems[0])?
        ));
    }
    let types_secs = value_elems(elems[1], heap)?;
    if as_str(types_secs.first().ok_or("an empty types section")?)? != "types" {
        return Err("the types section tag drifted".to_string());
    }
    let diags_secs = value_elems(elems[2], heap)?;
    if as_str(diags_secs.first().ok_or("an empty diags section")?)? != "diags" {
        return Err("the diags section tag drifted".to_string());
    }
    let tdefs = value_elems(types_secs[1], heap)?;
    let tdiags = value_elems(diags_secs[1], heap)?;
    let mut out = RebuiltTypedVerdict::default();
    for t in &tdefs {
        out.defines.push(rebuild_tdef(t, heap)?);
    }
    for d in &tdiags {
        out.diagnostics.push(rebuild_tdiag(d, heap)?);
    }
    Ok(out)
}

/// Rebuild one tdef record `("tdef" name schema effs node)`.
fn rebuild_tdef(v: &Value, heap: &Heap) -> Result<RebuiltTdef, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 5, "tdef record")?;
    if as_str(e[0])? != "tdef" {
        return Err(format!(
            "a non-tdef record in the types section: {}",
            as_str(e[0])?
        ));
    }
    let name = Symbol::new(as_str(e[1])?).map_err(|err| format!("tdef name rejected: {err:?}"))?;
    let schema = rebuild_schema(e[2], heap)?;
    let effects = rebuild_row(e[3], heap)?;
    let body = rebuild_tnode(e[4], heap)?;
    Ok(RebuiltTdef {
        name,
        schema,
        body,
        effects,
    })
}

/// Rebuild one schema record `("schema" (vars...) body)` — the
/// quantified indices as `u32` (negative indices fail closed), the
/// body through the type decoder.
fn rebuild_schema(v: &Value, heap: &Heap) -> Result<TypeSchema, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 3, "schema record")?;
    if as_str(e[0])? != "schema" {
        return Err(format!("a non-schema record: {}", as_str(e[0])?));
    }
    let var_elems = value_elems(e[1], heap)?;
    let mut vars = Vec::with_capacity(var_elems.len());
    for v in &var_elems {
        let idx = as_i64(v)?;
        vars.push(u32::try_from(idx).map_err(|_| format!("negative metavariable index `{idx}`"))?);
    }
    Ok(TypeSchema {
        vars,
        body: rebuild_type(e[2], heap)?,
    })
}

/// Rebuild one effect row — the ordered symbol list (the row's own
/// first-seen order is part of the parity face).
fn rebuild_row(v: &Value, heap: &Heap) -> Result<Vec<Symbol>, String> {
    let e = value_elems(v, heap)?;
    let mut out = Vec::with_capacity(e.len());
    for name in &e {
        out.push(
            Symbol::new(as_str(name)?).map_err(|err| format!("effect name rejected: {err:?}"))?,
        );
    }
    Ok(out)
}

/// Rebuild one twin type value into the engine's `Type` — the exact
/// reverse of the twin's own algebra: the ground strings, the
/// `("var" i)` metavariables, the `("pair" A B)` and
/// `("fn" (P...) R)` structural forms. Unknown tags fail closed
/// (a twin bug surfaces here as a named error, never a silent Dyn).
fn rebuild_type(v: &Value, heap: &Heap) -> Result<Type, String> {
    match v {
        Value::Str(s) => match s.as_ref() {
            "int" => Ok(Type::Int),
            "float" => Ok(Type::Float),
            "bool" => Ok(Type::Bool),
            "str" => Ok(Type::Str),
            "nil" => Ok(Type::Nil),
            "dyn" => Ok(Type::Dyn),
            other => Err(format!("unknown ground type `{other}`")),
        },
        Value::Pair(_) => {
            let e = value_elems(v, heap)?;
            let tag = as_str(*e.first().ok_or("an empty type record")?)?;
            match tag {
                "var" => {
                    need_fields(&e, 2, "var type")?;
                    let idx = as_i64(e[1])?;
                    Ok(Type::Var(
                        u32::try_from(idx).map_err(|_| format!("negative var index `{idx}`"))?,
                    ))
                }
                "pair" => {
                    need_fields(&e, 3, "pair type")?;
                    Ok(Type::Pair(
                        Box::new(rebuild_type(e[1], heap)?),
                        Box::new(rebuild_type(e[2], heap)?),
                    ))
                }
                "fn" => {
                    need_fields(&e, 3, "fn type")?;
                    let ps = value_elems(e[1], heap)?;
                    let mut params = Vec::with_capacity(ps.len());
                    for p in &ps {
                        params.push(rebuild_type(p, heap)?);
                    }
                    // The blade 2 fourth slot (w-effect-mechanism §5.2):
                    // the EMPTY closed row strips (the oracle-domain
                    // rebuild stays whole); a carrying row is beyond
                    // the oracle's Type domain by construction (the
                    // r182 beyond-oracle ruling) — the rebuild face
                    // never sees it in its own lane, so the honest
                    // error guards the boundary here.
                    if e.len() >= 4 {
                        let row_elems = value_elems(e[3], heap)?;
                        let empty_closed = row_elems.len() >= 3
                            && matches!(row_elems[1], Value::Nil)
                            && as_str(row_elems[2]) == Ok("nil");
                        if !empty_closed {
                            return Err(
                                "a row-carrying arrow is beyond the oracle Type domain (the beyond-oracle lane owns it)"
                                    .to_string(),
                            );
                        }
                    }
                    Ok(Type::Arrow {
                        params,
                        ret: Box::new(rebuild_type(e[2], heap)?),
                    })
                }
                // The blade 2 nominal carrier (GZ-3): ("struct" name
                // (T...)) — the name plus the rebuilt field types.
                "struct" => {
                    need_fields(&e, 3, "struct type")?;
                    let name = Symbol::new(as_str(e[1])?)
                        .map_err(|err| format!("a struct name rejected: {err:?}"))?;
                    let fs = value_elems(e[2], heap)?;
                    let mut fields = Vec::with_capacity(fs.len());
                    for f in &fs {
                        fields.push(rebuild_type(f, heap)?);
                    }
                    Ok(Type::Struct(name, fields))
                }
                // The blade 3 closed nominal carrier (GZ-4, §10.4):
                // ("enum" name) — the name alone (no field list:
                // a multi-variant value layer has no single
                // type-layer shape).
                "enum" => {
                    need_fields(&e, 2, "enum type")?;
                    let name = Symbol::new(as_str(e[1])?)
                        .map_err(|err| format!("an enum name rejected: {err:?}"))?;
                    Ok(Type::Enum(name))
                }
                other => Err(format!("unknown twin type tag `{other}`")),
            }
        }
        other => Err(format!("a non-type value in a type position: {other:?}")),
    }
}

/// Rebuild one twin literal value — the `("int" 42)` family back
/// into the engine's `LiteralValue` (floats parse from their Debug
/// text — the parity family's float convention).
fn rebuild_litval(v: &Value, heap: &Heap) -> Result<LiteralValue, String> {
    match v {
        Value::Nil => Ok(LiteralValue::Nil),
        Value::Pair(_) => {
            let e = value_elems(v, heap)?;
            let tag = as_str(*e.first().ok_or("an empty litval record")?)?;
            match tag {
                "int" => {
                    need_fields(&e, 2, "int litval")?;
                    Ok(LiteralValue::Int(as_i64(e[1])?))
                }
                "float" => {
                    need_fields(&e, 2, "float litval")?;
                    let text = as_str(e[1])?;
                    text.parse::<f64>()
                        .map(LiteralValue::Float)
                        .map_err(|_| format!("bad float literal `{text}`"))
                }
                "bool" => {
                    need_fields(&e, 2, "bool litval")?;
                    match e[1] {
                        Value::Bool(b) => Ok(LiteralValue::Bool(*b)),
                        other => Err(format!("a non-bool payload in a bool litval: {other:?}")),
                    }
                }
                "string" => {
                    need_fields(&e, 2, "string litval")?;
                    Ok(LiteralValue::String(Rc::from(as_str(e[1])?)))
                }
                "pair" => {
                    need_fields(&e, 3, "pair litval")?;
                    Ok(LiteralValue::Pair(
                        Box::new(rebuild_litval(e[1], heap)?),
                        Box::new(rebuild_litval(e[2], heap)?),
                    ))
                }
                other => Err(format!("unknown twin litval tag `{other}`")),
            }
        }
        other => Err(format!(
            "a non-litval value in a litval position: {other:?}"
        )),
    }
}

/// One span record pair (the decimal-string offsets) rebuilt into a
/// `Span` — FileId(0)/ROOT are the rebuild's fixed frame (the parity
/// family convention: the file and generation identities stay
/// outside the comparison face).
fn rebuild_span(start: &Value, end: &Value) -> Result<Span, String> {
    let s_text = match start {
        Value::Str(s) => s.to_string(),
        other => return Err(format!("a non-string span start: {other:?}")),
    };
    let e_text = match end {
        Value::Str(s) => s.to_string(),
        other => return Err(format!("a non-string span end: {other:?}")),
    };
    let s: u32 = s_text
        .parse()
        .map_err(|_| format!("bad span start `{s_text}`"))?;
    let e: u32 = e_text
        .parse()
        .map_err(|_| format!("bad span end `{e_text}`"))?;
    Span::new(FileId(0), ByteOffset(s), ByteOffset(e), ExpansionId::ROOT)
        .map_err(|err| format!("rebuilt span rejected: {err:?}"))
}

/// Rebuild one annotation tree node — the tnode vocabulary back into
/// the engine's `TypedExpr` (every variant, every field: spans,
/// params, children, types, effect rows).
fn rebuild_tnode(v: &Value, heap: &Heap) -> Result<TypedExpr, String> {
    let e = value_elems(v, heap)?;
    let tag = as_str(*e.first().ok_or("an empty tnode record")?)?;
    match tag {
        "tfn" => {
            need_fields(&e, 6, "tfn record")?;
            let ps = value_elems(e[3], heap)?;
            let mut params = Vec::with_capacity(ps.len());
            for p in &ps {
                params.push(Symbol::new(as_str(p)?).map_err(|err| format!("param: {err:?}"))?);
            }
            Ok(TypedExpr::Fn {
                span: rebuild_span(e[1], e[2])?,
                params,
                body: Box::new(rebuild_tnode(e[4], heap)?),
                ty: rebuild_type(e[5], heap)?,
            })
        }
        "tapply" => {
            need_fields(&e, 7, "tapply record")?;
            let args = value_elems(e[4], heap)?;
            let mut arg_nodes = Vec::with_capacity(args.len());
            for a in &args {
                arg_nodes.push(rebuild_tnode(a, heap)?);
            }
            Ok(TypedExpr::Apply {
                span: rebuild_span(e[1], e[2])?,
                func: Box::new(rebuild_tnode(e[3], heap)?),
                args: arg_nodes,
                ty: rebuild_type(e[5], heap)?,
                effects: rebuild_effect_row(e[6], heap)?,
            })
        }
        "tif" => {
            need_fields(&e, 8, "tif record")?;
            Ok(TypedExpr::If {
                span: rebuild_span(e[1], e[2])?,
                cond: Box::new(rebuild_tnode(e[3], heap)?),
                then_branch: Box::new(rebuild_tnode(e[4], heap)?),
                else_branch: Box::new(rebuild_tnode(e[5], heap)?),
                ty: rebuild_type(e[6], heap)?,
                effects: rebuild_effect_row(e[7], heap)?,
            })
        }
        "tvar" => {
            need_fields(&e, 5, "tvar record")?;
            Ok(TypedExpr::Var {
                span: rebuild_span(e[1], e[2])?,
                name: Symbol::new(as_str(e[3])?).map_err(|err| format!("var name: {err:?}"))?,
                ty: rebuild_type(e[4], heap)?,
            })
        }
        "tlit" => {
            need_fields(&e, 5, "tlit record")?;
            Ok(TypedExpr::Literal {
                span: rebuild_span(e[1], e[2])?,
                value: rebuild_litval(e[3], heap)?,
                ty: rebuild_type(e[4], heap)?,
            })
        }
        "tassign" => {
            need_fields(&e, 7, "tassign record")?;
            Ok(TypedExpr::Assign {
                span: rebuild_span(e[1], e[2])?,
                name: Symbol::new(as_str(e[3])?).map_err(|err| format!("assign name: {err:?}"))?,
                value: Box::new(rebuild_tnode(e[4], heap)?),
                ty: rebuild_type(e[5], heap)?,
                effects: rebuild_effect_row(e[6], heap)?,
            })
        }
        "tlet" => {
            need_fields(&e, 7, "tlet record")?;
            let binds = value_elems(e[3], heap)?;
            let mut bindings = Vec::with_capacity(binds.len());
            for b in &binds {
                let be = value_elems(b, heap)?;
                need_fields(&be, 6, "tbind record")?;
                if as_str(be[0])? != "tbind" {
                    return Err("a non-tbind record in the tlet list".to_string());
                }
                bindings.push(TypedBinding {
                    span: rebuild_span(be[1], be[2])?,
                    name: Symbol::new(as_str(be[3])?)
                        .map_err(|err| format!("bind name: {err:?}"))?,
                    ty: rebuild_type(be[4], heap)?,
                    value: rebuild_tnode(be[5], heap)?,
                });
            }
            Ok(TypedExpr::Let {
                span: rebuild_span(e[1], e[2])?,
                bindings,
                body: Box::new(rebuild_tnode(e[4], heap)?),
                ty: rebuild_type(e[5], heap)?,
                effects: rebuild_effect_row(e[6], heap)?,
            })
        }
        "tperform" => {
            need_fields(&e, 7, "tperform record")?;
            let args = value_elems(e[4], heap)?;
            let mut arg_nodes = Vec::with_capacity(args.len());
            for a in &args {
                arg_nodes.push(rebuild_tnode(a, heap)?);
            }
            Ok(TypedExpr::Perform {
                span: rebuild_span(e[1], e[2])?,
                effect: Symbol::new(as_str(e[3])?)
                    .map_err(|err| format!("effect name: {err:?}"))?,
                args: arg_nodes,
                ty: rebuild_type(e[5], heap)?,
                effects: rebuild_effect_row(e[6], heap)?,
            })
        }
        "thandle" => {
            need_fields(&e, 7, "thandle record")?;
            let clauses = value_elems(e[4], heap)?;
            let mut handler_clauses = Vec::with_capacity(clauses.len());
            for c in &clauses {
                let ce = value_elems(c, heap)?;
                need_fields(&ce, 6, "tclause record")?;
                if as_str(ce[0])? != "tclause" {
                    return Err("a non-tclause record in the thandle list".to_string());
                }
                handler_clauses.push(TypedHandler {
                    span: rebuild_span(ce[1], ce[2])?,
                    effect: Symbol::new(as_str(ce[3])?)
                        .map_err(|err| format!("clause effect: {err:?}"))?,
                    ty: rebuild_type(ce[4], heap)?,
                    handler: rebuild_tnode(ce[5], heap)?,
                });
            }
            Ok(TypedExpr::Handle {
                span: rebuild_span(e[1], e[2])?,
                body: Box::new(rebuild_tnode(e[3], heap)?),
                handlers: handler_clauses,
                ty: rebuild_type(e[5], heap)?,
                effects: rebuild_effect_row(e[6], heap)?,
            })
        }
        other => Err(format!("unknown twin tnode tag `{other}`")),
    }
}

/// Rebuild one effect-row record into the engine's `EffectRow` (the
/// ordered first-seen name list).
fn rebuild_effect_row(v: &Value, heap: &Heap) -> Result<EffectRow, String> {
    let names = rebuild_row(v, heap)?;
    let mut row = EffectRow::empty();
    for name in names {
        row.push(name);
    }
    Ok(row)
}

/// Rebuild one tdiag record `("tdiag" code severity s e payload)`
/// into a real [`TypeDiagnostic`] — the code through the reverse
/// registry (the oracle's own closed set, E0001-E0012), the message
/// through the single-source template dictionary (the same table the
/// sweep's text face renders with), the span in the rebuild's fixed
/// frame. The subject set rides the check product's grammar, not the
/// inference product's — the rebuilt rows carry the empty set.
fn rebuild_tdiag(v: &Value, heap: &Heap) -> Result<TypeDiagnostic, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 6, "tdiag record")?;
    if as_str(e[0])? != "tdiag" {
        return Err(format!("a non-tdiag record: {}", as_str(e[0])?));
    }
    let code = type_code_from_str(as_str(e[1])?)?;
    let severity = match as_str(e[2])? {
        "error" => Severity::Error,
        "warning" => Severity::Warning,
        other => return Err(format!("unknown diagnostic severity `{other}`")),
    };
    let span = rebuild_span(e[3], e[4])?;
    let message = render_tdiag_template(e[5], heap)?;
    Ok(TypeDiagnostic::new(code, severity, span, message))
}

/// The reverse registry — the oracle's own closed code set, reversed
/// through this driver-side table (the twin's payload carries the
/// registry string; the rebuild turns it back into the enum so the
/// comparison is against the real `TypeDiagnostic` records).
fn type_code_from_str(text: &str) -> Result<TypeCode, String> {
    match text {
        "E0001" => Ok(TypeCode::UnboundVariable),
        "E0002" => Ok(TypeCode::ArityMismatch),
        "E0003" => Ok(TypeCode::NonBooleanCondition),
        "E0004" => Ok(TypeCode::NonCallableCallee),
        "E0005" => Ok(TypeCode::HandlerArityMismatch),
        "E0006" => Ok(TypeCode::TopLevelUnhandledPerform),
        "E0007" => Ok(TypeCode::NonCallableHandler),
        "E0008" => Ok(TypeCode::AssignmentTargetSurprise),
        "E0009" => Ok(TypeCode::TypeMismatch),
        "E0010" => Ok(TypeCode::RecursiveType),
        "E0011" => Ok(TypeCode::InferenceBudgetExceeded),
        "E0012" => Ok(TypeCode::AssignToCaptured),
        other => Err(format!("unknown diagnostic code `{other}`")),
    }
}

// ---------- the 127-c per-source text route (the cross-route face) ----------

/// The per-source dual-route run's outcome: both engines' full
/// verdict texts (the RS-4 engine-agreement face), the VM side's
/// types section rendered through the shared dump renderer
/// (`dump_ktf_section`'s `types` arm — the TWIN-4 face B exercised
/// on the REAL twin product), and the VM side's structural rebuild
/// (face C) — the cross-route equivalence's per-source side.
pub struct PerSourceInferRun {
    /// The VM engine's full verdict text.
    pub vm_text: String,
    /// The eval engine's full verdict text.
    pub eval_text: String,
    /// The VM product's types section, rendered through the shared
    /// dump renderer (the section that rides the composed analysis).
    pub vm_types_section: String,
    /// The VM product's structural rebuild.
    pub vm_rebuilt: RebuiltTypedVerdict,
}

/// The per-source text route for the inference twin (the RS-1
/// test-channel form carried to segment three — the expander
/// precedent's `per_source_route` shape): the item stream as the
/// program-text `items` prefix plus the fixed twin text, ONE program
/// parsed through the production bridge, run on BOTH engines. The
/// steady route (compile once + inject per inference) and this route
/// decode through the SAME decoder — the cross-route equivalence
/// asserts the two delivery faces produce the identical verdict.
pub fn infer_twin_per_source_dual(items: &[ModuleItem]) -> Result<PerSourceInferRun, String> {
    let assembled = format!(
        "{}\n{}",
        crate::bootstrap::target_corpus::target_items_stream_prefix(items),
        crate::bootstrap::target_corpus::INFER_TARGET_SOURCE
    );
    let decode_vm = |value: &Value,
                     heap: &Heap|
     -> Result<(String, String, RebuiltTypedVerdict), String> {
        let vm_text = decode_infer_result(value, heap)?;
        let elems = value_elems(value, heap)?;
        need_fields(&elems, 3, "the twin's result record")?;
        let mut types_section = String::new();
        crate::bootstrap::compiler_parity::dump_ktf_section(elems[1], heap, &mut types_section)?;
        let rebuilt = rebuild_typed_verdict(value, heap)?;
        Ok((vm_text, types_section, rebuilt))
    };
    let decode_eval =
        |value: &Value, heap: &Heap| -> Result<String, String> { decode_infer_result(value, heap) };
    let ((vm_text, vm_types_section, vm_rebuilt), eval_text) =
        crate::bootstrap::vm_harness::drive_dual_engines(
            "infer-parity-host.ktf",
            "target infer twin",
            &assembled,
            decode_vm,
            decode_eval,
        )?;
    Ok(PerSourceInferRun {
        vm_text,
        eval_text,
        vm_types_section,
        vm_rebuilt,
    })
}

/// The per-source text route WITHOUT the oracle-domain rebuild face
/// (the r174 frozen-oracle ruling's twin-beyond-oracle lane, the
/// W-ROW-POLY blade-1 consumer): the same assembled source (the
/// item-stream prefix + the fixed twin), both engines, both verdict
/// texts — no `rebuild_typed_verdict` ride, because that face
/// rebuilds into the ORACLE's `Type` domain and a row type is
/// beyond it by construction (the ruling's whole point: the twin
/// implements what the oracle never will). The oracle-domain cases
/// keep `infer_twin_per_source_dual`; the twin-beyond-oracle cases
/// (rows) ride here.
pub fn infer_twin_per_source_text_dual(items: &[ModuleItem]) -> Result<(String, String), String> {
    let assembled = format!(
        "{}\n{}",
        crate::bootstrap::target_corpus::target_items_stream_prefix(items),
        crate::bootstrap::target_corpus::INFER_TARGET_SOURCE
    );
    let decode =
        |value: &Value, heap: &Heap| -> Result<String, String> { decode_infer_result(value, heap) };
    crate::bootstrap::vm_harness::drive_dual_engines(
        "infer-parity-host.ktf",
        "target infer twin",
        &assembled,
        |v, h| decode(v, h),
        |v, h| decode(v, h),
    )
}

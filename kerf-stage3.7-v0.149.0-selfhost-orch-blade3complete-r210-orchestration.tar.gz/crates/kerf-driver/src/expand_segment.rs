//! The T-a switch-window step-④ EXPAND segment production position
//! (w-t-a-switch-window.md §3 r146+ row — the TA-5 form carried to
//! the expansion segment): the `.ktf` production expansion switches
//! from the Rust expander to the steady twin chain (the expander
//! twin compiled once per process — per distinct work budget —
//! running on the VM, the production engine), and the Rust expander
//! retires to the oracle face (the parity harnesses' comparison
//! arm, the seed chain's own expansion, and the rollback band).
//!
//! The dual-chain decoupling (SOP §21.12-28②) instantiated for the
//! expansion segment:
//!
//! * the PRODUCTION face — [`crate::pipeline::parse_with`] on
//!   `ReaderFace::Target` — rides [`ExpandSegment::Twin`] (the
//!   default after the switch);
//! * the SEED/ORACLE faces — the bootstrap bridge
//!   (`read_target_source_for_bootstrap`), the injection-channel
//!   front end (`parse_target_with_injected` — the chain's own
//!   construction entry: the twin chain's own compilation expands
//!   through the Rust expander, a production-position expansion
//!   here would be circular), and the A pass of the A/B/C pipeline
//!   (`rust_compile_ccf`) — PIN the Rust expander explicitly: their
//!   comparisons stay differential (the fixpoint purity leg and the
//!   A ≡ B observation row must never collapse into
//!   self-comparisons).
//!
//! The rollback band (SOP §14.6.4 rule 5 — measurement first): the
//! `KERF_EXPAND_SEGMENT` environment variable selects the position
//! for the CLI process entry — `twin` (the default) or `rust` (the
//! rollback); any other value is a hard error (fail-closed, the
//! `KERF_READ_SEGMENT` precedent: a silently ignored position
//! override would be a lie). The library face stays deterministic —
//! nothing here reads the environment implicitly.
//!
//! Budget mirroring (the `tp_limit` precedent): the twin's work
//! budget rides the assembly prefix (`define(ex_limit, N);`) — the
//! chain must carry the process's effective `KERF_EXPANSION_LIMIT`
//! so an over-budget source rejects with the same key on both
//! positions (the rollback band's parity obligation); each distinct
//! budget gets its own once-compiled chain.

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::ModuleItem;
use kerf_expander::{ExpandError, ModuleError};
use kerf_span::FileId;
use kerf_syntax::SyntaxObject;

use crate::bootstrap::expander_parity::ParityError;
use crate::bootstrap::steady_expander_chain::SteadyExpanderChain;

/// Which implementation expands the read forms in the production
/// pipeline (the step-④ expand segment position).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExpandSegment {
    /// The steady twin chain on the VM (the production engine) —
    /// the switched position: `macro.ktf` + `expander.ktf`, the
    /// twin compiled once per process (per distinct work budget)
    /// through the seed face; the twin's verdict covers the
    /// expansion AND the loader surface (the junction-2
    /// discipline — exactly like the oracle's expand → load
    /// spine).
    Twin,
    /// The Rust expander — the rollback band (and the retired
    /// oracle: the parity harnesses' comparison arm and the seed
    /// chain's own expansion).
    Rust,
}

impl Default for ExpandSegment {
    /// The switched production default (the T-a step-④ ruling:
    /// `Session::new` and every unset position ride the twins).
    fn default() -> Self {
        ExpandSegment::Twin
    }
}

impl ExpandSegment {
    /// Parse one `KERF_EXPAND_SEGMENT` value (the process entry's
    /// fail-closed face): `twin` and `rust` are the only legal
    /// spellings.
    pub fn parse_value(raw: &str) -> Result<Self, String> {
        match raw.trim() {
            "twin" => Ok(ExpandSegment::Twin),
            "rust" => Ok(ExpandSegment::Rust),
            other => Err(format!(
                "invalid value for KERF_EXPAND_SEGMENT: `{other}` (expected `twin` or `rust`)"
            )),
        }
    }

    /// Read the environment override: unset keeps the switched
    /// default (`Twin`); a set value must parse (the caller reports
    /// and exits — never a silent ignore).
    pub fn from_env() -> Result<Self, String> {
        match std::env::var("KERF_EXPAND_SEGMENT") {
            Ok(raw) => Self::parse_value(&raw),
            Err(std::env::VarError::NotPresent) => Ok(ExpandSegment::Twin),
            Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
                "invalid value for KERF_EXPAND_SEGMENT: `{}` (expected `twin` or `rust`)",
                raw.to_string_lossy()
            )),
        }
    }
}

/// The production expansion's failure face — the two families the
/// production position must never confuse (the
/// `ProductionReadError` precedent).
#[derive(Debug)]
pub enum ProductionExpandError {
    /// The program's own rejection (the rebuilt [`ParityError`] —
    /// the expansion or loader error, the same error the oracle
    /// spine produces, so the diagnostics render identically on
    /// both positions).
    Program(ParityError),
    /// A harness defect — the twin chain or a decode broke. A
    /// compiler defect: rendered loudly, never a silent Rust
    /// fallback (SOP §2.3-4 — errors over silence).
    Defect(String),
}

// The per-thread twin-chain cache, keyed by the work budget the
// chain was constructed under: the twin's `ex_limit` global must
// mirror the process's effective `KERF_EXPANSION_LIMIT` (an
// over-budget source rejects with the same key on both positions —
// the rollback band's parity obligation), so each distinct budget
// gets its own once-compiled chain. The default budget covers the
// ordinary corpus; the cache keeps the override honest without
// recompiling per expansion.
//
// Thread-local by necessity (the `ReadSegment` precedent): the
// chain's products carry `Rc` payloads — not `Send`/`Sync`, so a
// global static cannot hold them; the cache value is plain `Rc`
// (never shared across threads). The cost shape is the status
// quo's (every steady-chain test today constructs its own chain;
// the cache only amortizes within one thread — the CLI's single
// main thread constructs exactly once).
thread_local! {
    static PRODUCTION_CHAINS: std::cell::RefCell<HashMap<usize, Rc<SteadyExpanderChain>>> =
        std::cell::RefCell::new(HashMap::new());
}

/// The cached (or first-constructed) production chain for one work
/// budget. Construction failures are NOT cached: a broken chain is
/// a tree defect the test suite would catch — retrying keeps the
/// failure observable per call instead of freezing it (the
/// `production_chain` read precedent).
fn production_chain(budget: usize) -> Result<Rc<SteadyExpanderChain>, String> {
    PRODUCTION_CHAINS.with(|cache| {
        let mut cache = cache.borrow_mut();
        match cache.get(&budget) {
            Some(chain) => Ok(Rc::clone(chain)),
            None => {
                let chain = Rc::new(SteadyExpanderChain::new_with_limit(budget)?);
                cache.insert(budget, Rc::clone(&chain));
                Ok(chain)
            }
        }
    })
}

/// Retarget a rebuilt rejection's spans to the session's file id.
///
/// The twin rebuild faces derive spans with `FileId(0)` (the parity
/// harnesses' convention — every harness interns at zero), but the
/// production position expands forms read from files interned at
/// any id; a span that names the wrong file renders against the
/// wrong source. The walk is exhaustive over every span-carrying
/// variant on purpose: a new variant fails this match at compile
/// time, so the retarget can never silently miss a face (the
/// FIX-16 discipline — the decode table grows with its source).
fn retarget_span(span: &mut kerf_span::Span, file: FileId) {
    span.file_id = file;
}

fn retarget_expand_error(err: ExpandError, file: FileId) -> ExpandError {
    let mut span = err.span();
    retarget_span(&mut span, file);
    err.with_span(span)
}

fn retarget_parity_error(err: ParityError, file: FileId) -> ParityError {
    match err {
        ParityError::Expand(err) => ParityError::Expand(retarget_expand_error(err, file)),
        ParityError::Module(err) => ParityError::Module(retarget_module_error(err, file)),
    }
}

fn retarget_module_error(err: ModuleError, file: FileId) -> ModuleError {
    let mut span = err.span();
    retarget_span(&mut span, file);
    err.with_span(span)
}

/// Retarget the rebuilt ITEM tree's spans to the session's file id
/// (the r147 K163 fourth-instance clearance, the expansion half: the
/// twin's dump-rebuild spans carry `FileId(0)` — the parity
/// harnesses' convention — with the TRUE expansion generations on
/// the tree axis; the r146 switch's sweeps validated in the
/// zero-id domain, so the tree face never retargeted the file. The
/// walk is exhaustive over every span-carrying shape on purpose: a
/// new variant fails this match at compile time (the FIX-16
/// discipline); the generation fields ride untouched — the twin
/// already rebuilds the true generations, only the file identity was
/// the harness convention's).
fn retarget_items(items: &mut [ModuleItem], file: FileId) {
    for item in items.iter_mut() {
        match item {
            ModuleItem::Define { span, value, .. } => {
                span.file_id = file;
                retarget_expr(value, file);
            }
            ModuleItem::Require { span, .. }
            | ModuleItem::DefineSyntax { span, .. }
            | ModuleItem::Extern { span, .. } => {
                span.file_id = file;
            }
            // The dann site record: BOTH spans retarget (the
            // annotation site renders diagnostics; the anchor must
            // keep matching the fn/binding spans the walk compares).
            ModuleItem::Annotate { span, anchor, .. } => {
                span.file_id = file;
                anchor.file_id = file;
            }
            // The struct declaration record: the declaration site
            // retargets (the field spec payload carries no spans).
            ModuleItem::Struct { span, .. } => {
                span.file_id = file;
            }
            // The enum declaration record: the struct record's own
            // face (the variant payload spec trees carry no spans).
            ModuleItem::Enum { span, .. } => {
                span.file_id = file;
            }
            ModuleItem::Module { span, items, .. } => {
                span.file_id = file;
                retarget_items(items, file);
            }
        }
    }
}

/// The expression-level walk (every variant carries a span — TD-004;
/// the sub-shapes ride along: the let bindings, the handler
/// clauses).
fn retarget_expr(expr: &mut kerf_core::CoreExpr, file: FileId) {
    use kerf_core::CoreExpr;
    match expr {
        CoreExpr::Fn { span, body, .. } => {
            span.file_id = file;
            retarget_expr(body, file);
        }
        CoreExpr::Apply { span, func, args } => {
            span.file_id = file;
            retarget_expr(func, file);
            for arg in args.iter_mut() {
                retarget_expr(arg, file);
            }
        }
        CoreExpr::If {
            span,
            cond,
            then_branch,
            else_branch,
        } => {
            span.file_id = file;
            retarget_expr(cond, file);
            retarget_expr(then_branch, file);
            retarget_expr(else_branch, file);
        }
        CoreExpr::Var { span, .. } | CoreExpr::Literal { span, .. } => {
            span.file_id = file;
        }
        CoreExpr::Assign { span, value, .. } => {
            span.file_id = file;
            retarget_expr(value, file);
        }
        CoreExpr::Let {
            span,
            bindings,
            body,
        } => {
            span.file_id = file;
            for binding in bindings.iter_mut() {
                binding.span.file_id = file;
                retarget_expr(&mut binding.value, file);
            }
            retarget_expr(body, file);
        }
        CoreExpr::Perform { span, args, .. } => {
            span.file_id = file;
            for arg in args.iter_mut() {
                retarget_expr(arg, file);
            }
        }
        CoreExpr::Handle {
            span,
            body,
            handlers,
        } => {
            span.file_id = file;
            retarget_expr(body, file);
            for clause in handlers.iter_mut() {
                clause.span.file_id = file;
                retarget_expr(&mut clause.handler, file);
            }
        }
    }
}

/// The production expansion: one read forms stream through the twin
/// chain on the VM (the switched position's single entry — the
/// parse spine's `ReaderFace::Target` arm rides it; the twin's
/// verdict covers the expansion and the loader surface both, the
/// junction-2 discipline).
pub fn production_expand(
    forms: &[SyntaxObject],
    budget: usize,
    file: FileId,
) -> Result<Vec<ModuleItem>, ProductionExpandError> {
    let chain = production_chain(budget).map_err(ProductionExpandError::Defect)?;
    match chain.expand_production(forms) {
        Err(defect) => Err(ProductionExpandError::Defect(defect)),
        Ok(Err(err)) => Err(ProductionExpandError::Program(retarget_parity_error(
            err, file,
        ))),
        Ok(Ok(mut items)) => {
            // The tree face rides the same retarget as the error
            // face (the K163 fourth-instance clearance — see
            // `retarget_items`): every rebuilt span names the
            // session's file, so the checking, the compilation, and
            // every runtime span consumer downstream render against
            // the right source.
            retarget_items(&mut items, file);
            Ok(items)
        }
    }
}

#[cfg(test)]
mod tests {
    //! The expand-segment policy's unit face: env parsing (the
    //! fail-closed three-state) and the span retarget walk over
    //! every span-carrying variant. The pipeline-level integration
    //! faces live in the root test tree
    //! (`expand_segment_switch_tests.rs` — the corpus sweep, the
    //! rollback band, and the cross-stage consumption).

    use super::*;

    #[test]
    fn env_values_parse_fail_closed() {
        assert_eq!(ExpandSegment::parse_value("twin"), Ok(ExpandSegment::Twin));
        assert_eq!(ExpandSegment::parse_value("rust"), Ok(ExpandSegment::Rust));
        // Surrounding whitespace is tolerated (the read-segment
        // precedent: a trailing newline from a shell `FOO=bar\n`
        // export must not become a hard failure).
        assert_eq!(
            ExpandSegment::parse_value(" rust "),
            Ok(ExpandSegment::Rust)
        );
        for bad in ["", "twins", "TWIN", "c", "0", "oracle"] {
            assert!(
                ExpandSegment::parse_value(bad).is_err(),
                "`{bad}` must not parse as an expand segment"
            );
        }
    }

    #[test]
    fn span_retarget_touches_the_expand_error_family() {
        let file = FileId(7);
        let span = || {
            kerf_span::Span::new(
                FileId(0),
                kerf_span::ByteOffset(3),
                kerf_span::ByteOffset(4),
                kerf_span::ExpansionId::ROOT,
            )
            .unwrap()
        };
        let sym = || kerf_span::Symbol::new("x").unwrap();
        let cases: Vec<ExpandError> = vec![
            ExpandError::UnboundIdentifier {
                name: sym(),
                span: span(),
            },
            ExpandError::ExpansionDepthExceeded {
                limit: 512,
                span: span(),
            },
            ExpandError::EmptyForm { span: span() },
            ExpandError::MalformedForm {
                form: "let",
                span: span(),
            },
            ExpandError::TopLevelExpression { span: span() },
            ExpandError::MacroPatternMismatch {
                name: sym(),
                span: span(),
            },
            ExpandError::QuoteUnsupportedDatum { span: span() },
            ExpandError::NonExhaustiveMatch { span: span() },
            ExpandError::UnsupportedPattern { span: span() },
            ExpandError::ExternAbiUnsupported { span: span() },
            ExpandError::ExternTypeUnsupported {
                ty: sym(),
                span: span(),
            },
            ExpandError::ExternNameCollision {
                name: sym(),
                span: span(),
            },
            ExpandError::ExternNotTopLevel { span: span() },
        ];
        for err in cases {
            let retargeted = retarget_expand_error(err, file);
            assert_eq!(
                retargeted.span().file_id,
                file,
                "every rebuilt expansion rejection must name the session's file"
            );
        }
        // The module family rides the same walk.
        let module_cases: Vec<ModuleError> = vec![
            ModuleError::ModuleCycle {
                path: vec![sym()],
                span: span(),
            },
            ModuleError::ModuleNotFound {
                name: sym(),
                span: span(),
            },
            ModuleError::ModuleDuplicate {
                name: sym(),
                span: span(),
            },
        ];
        for err in module_cases {
            let retargeted = retarget_module_error(err, file);
            assert_eq!(retargeted.span().file_id, file);
        }
    }
}

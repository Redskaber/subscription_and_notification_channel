//! Session and file interning (charter item, stage-0-plan row 0.8).
//!
//! The session owns every source text the driver ever touches and the
//! name <-> [`FileId`] mapping. Ids are handed out sequentially from
//! zero (deterministic — SOP §2.3-3); re-interning a known name keeps
//! the id and replaces the source (upsert semantics — the REPL
//! re-reads one growing file per submission, and diagnostics must
//! always render against the *current* text).
//!
//! The session is the single source of truth for diagnostic rendering
//! (SOP §2.3-2): renderers ask the session for file names, source
//! texts, and line indexes, never the callers. Each file's
//! [`LineIndex`] is built once at intern (and rebuilt on REPL upsert)
//! — §9.56 DIAG-4: the rustc source-map shape (line starts cached per
//! file), not a fresh O(source) rebuild per rendered diagnostic.

use kerf_span::{FileId, Span};

use crate::line_index::LineIndex;

/// One interned file: a display name, its current source text, and
/// the render-time line index derived from that text.
#[derive(Debug)]
struct FileEntry {
    name: String,
    source: String,
    index: LineIndex,
}

/// The driver session: file interning plus source storage.
#[derive(Debug, Default)]
pub struct Session {
    entries: Vec<FileEntry>,
    /// The configurable depth guardrails (K162 / W-REC-DEPTH blade
    /// 2): the conservative defaults on [`Session::new`]; the CLI
    /// process entry raises them from the environment through
    /// [`Session::with_limits`] (the single env consumer — the
    /// library face stays deterministic).
    limits: crate::pipeline::DepthLimits,
    /// The step-④ read segment position (the T-a switch window):
    /// `Twin` — the steady twin chain on the VM — is the switched
    /// production default; `Rust` is the rollback band. The CLI
    /// process entry selects it from the environment through
    /// [`Session::with_read_segment`] (the single env consumer —
    /// the same deterministic-library-face discipline as `limits`).
    read_segment: crate::read_segment::ReadSegment,
    /// The step-④ expand segment position (the same T-a window, the
    /// expansion segment's own face): `Twin` — the steady expander
    /// chain on the VM — is the switched production default; `Rust`
    /// is the rollback band and the seed/oracle pin. The CLI
    /// process entry selects it from the environment through
    /// [`Session::set_expand_segment`] (the single env consumer).
    expand_segment: crate::expand_segment::ExpandSegment,
    /// The step-④ check segment position (the same T-a window, the
    /// checking segment's own face): `Twin` — BOTH checker twins
    /// (the conservative checker + the HM inference engine) on the
    /// VM — is the switched production default; `Rust` is the
    /// rollback band and the seed/oracle pin (the twin chains' own
    /// construction entry and the A/B/C A pass MUST pin it: a
    /// twin-position check there would be circular). The CLI
    /// process entry selects it from the environment through
    /// [`Session::set_check_segment`] (the single env consumer).
    check_segment: crate::check_segment::CheckSegment,
    /// The step-④ compile segment position (the same T-a window, the
    /// compile segment's own face): `Twin` — the steady compiler
    /// chain on the VM — is the switched production default; `Rust`
    /// is the rollback band and the seed/oracle pin (the twin
    /// chain's own construction entry and the A/B/C A pass MUST pin
    /// it: a twin-position compile there would be circular). The CLI
    /// process entry selects it from the environment through
    /// [`Session::set_compile_segment`] (the single env consumer).
    compile_segment: crate::compile_segment::CompileSegment,
}

impl Session {
    /// An empty session (no files interned; conservative depth
    /// guardrails).
    pub fn new() -> Self {
        Session {
            entries: Vec::new(),
            limits: crate::pipeline::DepthLimits::default(),
            read_segment: crate::read_segment::ReadSegment::Twin,
            expand_segment: crate::expand_segment::ExpandSegment::Twin,
            check_segment: crate::check_segment::CheckSegment::Twin,
            compile_segment: crate::compile_segment::CompileSegment::Twin,
        }
    }

    /// An empty session with explicit depth guardrails (the CLI's
    /// env-consumption face).
    pub fn with_limits(limits: crate::pipeline::DepthLimits) -> Self {
        Session {
            entries: Vec::new(),
            limits,
            read_segment: crate::read_segment::ReadSegment::Twin,
            expand_segment: crate::expand_segment::ExpandSegment::Twin,
            check_segment: crate::check_segment::CheckSegment::Twin,
            compile_segment: crate::compile_segment::CompileSegment::Twin,
        }
    }

    /// An empty session with an explicit read segment position (the
    /// CLI's env-consumption face — the rollback band selector; also
    /// the seed/oracle faces' pin).
    pub fn with_read_segment(read_segment: crate::read_segment::ReadSegment) -> Self {
        Session {
            entries: Vec::new(),
            limits: crate::pipeline::DepthLimits::default(),
            read_segment,
            expand_segment: crate::expand_segment::ExpandSegment::Twin,
            check_segment: crate::check_segment::CheckSegment::Twin,
            compile_segment: crate::compile_segment::CompileSegment::Twin,
        }
    }

    /// The session's depth guardrails (consumed by the parse spine).
    pub fn limits(&self) -> &crate::pipeline::DepthLimits {
        &self.limits
    }

    /// The session's read segment position (consumed by the parse
    /// spine's `ReaderFace::Target` arm).
    pub fn read_segment(&self) -> crate::read_segment::ReadSegment {
        self.read_segment
    }

    /// Set the read segment position (the CLI process entry's
    /// rollback-band selector — the single mutation face; library
    /// callers construct through [`Session::with_read_segment`]).
    pub fn set_read_segment(&mut self, read_segment: crate::read_segment::ReadSegment) {
        self.read_segment = read_segment;
    }

    /// An empty session with ALL FOUR segment positions pinned
    /// (the seed/oracle faces' constructor — the bootstrap bridge
    /// and the A/B/C A pass: their comparisons stay differential on
    /// every switched segment — read, expand, check, AND compile; a
    /// twin-position segment inside a twin chain's own construction
    /// would be circular).
    pub fn with_segments(
        read_segment: crate::read_segment::ReadSegment,
        expand_segment: crate::expand_segment::ExpandSegment,
        check_segment: crate::check_segment::CheckSegment,
        compile_segment: crate::compile_segment::CompileSegment,
    ) -> Self {
        Session {
            entries: Vec::new(),
            limits: crate::pipeline::DepthLimits::default(),
            read_segment,
            expand_segment,
            check_segment,
            compile_segment,
        }
    }

    /// The session's expand segment position (consumed by the parse
    /// spine's `ReaderFace::Target` arm — the expansion step).
    pub fn expand_segment(&self) -> crate::expand_segment::ExpandSegment {
        self.expand_segment
    }

    /// Set the expand segment position (the CLI process entry's
    /// rollback-band selector — the single mutation face).
    pub fn set_expand_segment(&mut self, expand_segment: crate::expand_segment::ExpandSegment) {
        self.expand_segment = expand_segment;
    }

    /// The session's check segment position (consumed by the parse
    /// spine's checking step — `ParsedProgram::typecheck`).
    pub fn check_segment(&self) -> crate::check_segment::CheckSegment {
        self.check_segment
    }

    /// Set the check segment position (the CLI process entry's
    /// rollback-band selector — the single mutation face).
    pub fn set_check_segment(&mut self, check_segment: crate::check_segment::CheckSegment) {
        self.check_segment = check_segment;
    }

    /// The session's compile segment position (consumed by the
    /// parse spine's compile step — `ParsedProgram::compile_bytecode`).
    pub fn compile_segment(&self) -> crate::compile_segment::CompileSegment {
        self.compile_segment
    }

    /// Set the compile segment position (the CLI process entry's
    /// rollback-band selector — the single mutation face).
    pub fn set_compile_segment(&mut self, compile_segment: crate::compile_segment::CompileSegment) {
        self.compile_segment = compile_segment;
    }

    /// Intern a file: first sight allocates the next sequential
    /// [`FileId`]; a known name keeps its id and has its source
    /// replaced (upsert — REPL re-reads are idempotent).
    pub fn intern(&mut self, name: impl Into<String>, source: impl Into<String>) -> FileId {
        let name = name.into();
        let source = source.into();
        match self.entries.iter().position(|e| e.name == name) {
            Some(idx) => {
                let entry = &mut self.entries[idx];
                entry.index = LineIndex::new(&source);
                entry.source = source;
                FileId(idx as u32)
            }
            None => {
                let index = LineIndex::new(&source);
                self.entries.push(FileEntry {
                    name,
                    source,
                    index,
                });
                FileId((self.entries.len() - 1) as u32)
            }
        }
    }

    /// The display name of an interned file, or `None` for an id this
    /// session never handed out (fail-closed: no silent fallback name).
    pub fn file_name(&self, id: FileId) -> Option<&str> {
        self.entries.get(id.0 as usize).map(|e| e.name.as_str())
    }

    /// The current source text of an interned file, or `None` for an
    /// unknown id.
    pub fn source(&self, id: FileId) -> Option<&str> {
        self.entries.get(id.0 as usize).map(|e| e.source.as_str())
    }

    /// The cached line index of an interned file (built at intern,
    /// rebuilt on upsert), or `None` for an unknown id. §9.56 DIAG-4.
    pub fn line_index(&self, id: FileId) -> Option<&LineIndex> {
        self.entries.get(id.0 as usize).map(|e| &e.index)
    }

    /// The number of interned files (ids `0..len` are all valid).
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether no file has been interned yet.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Whether `span`'s file belongs to this session (used by the
    /// diagnostic constructor to keep the span and the `file` field
    /// from disagreeing).
    pub fn knows(&self, span: &Span) -> bool {
        (span.file_id.0 as usize) < self.entries.len()
    }
}

#[cfg(test)]
mod tests {
    //! Session interning tests (FP1): sequential ids, upsert identity,
    //! lookup round-trips, fail-closed unknown ids.

    use super::*;

    #[test]
    fn first_intern_allocates_sequential_ids() {
        let mut s = Session::new();
        assert!(s.is_empty());
        let a = s.intern("a.ktf", "(define x 1)");
        let b = s.intern("b.ktf", "(define y 2)");
        assert_eq!(a, FileId(0));
        assert_eq!(b, FileId(1));
        assert_eq!(s.len(), 2);
    }

    #[test]
    fn reintern_keeps_id_and_replaces_source() {
        let mut s = Session::new();
        let id = s.intern("repl", "(define x 1)");
        let again = s.intern("repl", "(define x 1)\n(define y 2)");
        assert_eq!(id, again, "upsert must keep the id");
        assert_eq!(s.len(), 1, "upsert must not allocate a new entry");
        assert_eq!(s.source(id), Some("(define x 1)\n(define y 2)"));
    }

    #[test]
    fn name_and_source_round_trip() {
        let mut s = Session::new();
        let id = s.intern("main.ktf", "(+ 1 2)");
        assert_eq!(s.file_name(id), Some("main.ktf"));
        assert_eq!(s.source(id), Some("(+ 1 2)"));
    }

    #[test]
    fn unknown_ids_fail_closed() {
        let s = Session::new();
        assert_eq!(s.file_name(FileId(0)), None);
        assert_eq!(s.source(FileId(0)), None);
        assert_eq!(s.file_name(FileId(999)), None);
    }

    #[test]
    fn reintern_after_growth_still_targets_the_right_entry() {
        let mut s = Session::new();
        let a = s.intern("a.ktf", "1");
        let _b = s.intern("b.ktf", "2");
        let c = s.intern("c.ktf", "3");
        let a2 = s.intern("a.ktf", "one");
        assert_eq!(a, a2);
        assert_eq!(s.source(c), Some("3"));
        assert_eq!(s.source(a2), Some("one"));
        assert_eq!(s.len(), 3);
    }

    #[test]
    fn line_index_cache_matches_fresh_build_and_rebuilds_on_upsert() {
        // §9.56 DIAG-4: the cached index is byte-for-byte the fresh
        // derivation, and a REPL upsert rebuilds it against the new
        // text (stale indexes would mis-render positions).
        let mut s = Session::new();
        let id = s.intern("main.ktf", "(define x 1)\n(+ x 2)");
        let cached = s.line_index(id).expect("index interned");
        let fresh = LineIndex::new("(define x 1)\n(+ x 2)");
        assert_eq!(*cached, fresh);
        assert_eq!(cached.line_count(), 2);

        let _ = s.intern("main.ktf", "one\ntwo\nthree");
        let rebuilt = s.line_index(id).expect("index after upsert");
        assert_eq!(rebuilt.line_count(), 3, "upsert rebuilds the index");
        assert_eq!(rebuilt.line_bounds(2), Some((8, 13)));

        assert_eq!(s.line_index(FileId(9)), None, "unknown ids fail closed");
    }
}

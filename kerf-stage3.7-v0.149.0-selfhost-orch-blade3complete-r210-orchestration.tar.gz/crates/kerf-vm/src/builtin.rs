//! The builtin registry — the VM-side table of the 21 STAGE0_GLOBALS
//! names (docs/stage0.md §8.8 minimal surface; the expander exports the
//! authoritative name list, the 0.7 runtime asserts the two tables'
//! parity — the 0.6 integration tests already pin it cross-crate).
//!
//! Every builtin has a FIXED arity: variadic folds are a Stage 2
//! library concern, so `(+ 1 2 3)` fails with
//! [`crate::RuntimeError::ArityMismatch`] at 0.6 (documented semantics,
//! not an accident).

use std::fmt;
use std::rc::Rc;
use std::sync::OnceLock;

use kerf_compiler::Opcode;
use kerf_span::{Span, Symbol};

use crate::error::{RuntimeError, demanded, type_mismatch};
use crate::io::VmIo;
use crate::value::{Heap, HeapObj, HeapRef, Value};

/// One native function value (a STAGE0_GLOBALS entry).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Builtin {
    // arithmetic and comparison
    Add,
    Sub,
    Mul,
    Div,
    Lt,
    Le,
    Gt,
    Ge,
    NumEq,
    // pair and predicate surface
    Car,
    Cdr,
    Cons,
    IsPair,
    IsNil,
    Eq,
    Not,
    // minimal I/O (§8.8)
    ReadLine,
    WriteLine,
    // the library face (the value display render — W-SELFHOST-ORCH
    // blade 2, the MX-1 retirement: the value→bytes edge rides the
    // §8.8 write channel, the display formatting living host-side)
    RenderLine,
    // the library face (the string→byte-table decode — W-SELFHOST-ORCH
    // blade 3, the read-edge vocabulary: a read line becomes the
    // integer byte chain the lexical twins consume; the string is
    // opaque in-language, so the decode is a library global over the
    // host str, the render-line precedent's read-side sibling)
    StringBytes,
    // the library face (the byte-chain→string encode — the
    // twin-record reflow vocabulary: the parser twin's byte-table
    // payloads re-enter the expander's string-carried record
    // grammar through this edge; the B3 revision's inverse row)
    BytesString,
}

impl Builtin {
    /// The registry: (variant, source name, fixed arity). Names use
    /// the kebab form of the expander's STAGE0_GLOBALS verbatim.
    pub const ALL: [(Builtin, &'static str, u32); 21] = [
        (Builtin::Add, "+", 2),
        (Builtin::Sub, "-", 2),
        (Builtin::Mul, "*", 2),
        (Builtin::Div, "/", 2),
        (Builtin::Lt, "<", 2),
        (Builtin::Le, "<=", 2),
        (Builtin::Gt, ">", 2),
        (Builtin::Ge, ">=", 2),
        (Builtin::NumEq, "=", 2),
        (Builtin::Car, "car", 1),
        (Builtin::Cdr, "cdr", 1),
        (Builtin::Cons, "cons", 2),
        (Builtin::IsPair, "pair?", 1),
        (Builtin::IsNil, "nil?", 1),
        (Builtin::Eq, "eq?", 2),
        (Builtin::Not, "not", 1),
        (Builtin::ReadLine, "read-line", 0),
        (Builtin::WriteLine, "write-line", 1),
        (Builtin::RenderLine, "render-line", 1),
        (Builtin::StringBytes, "string-bytes", 1),
        (Builtin::BytesString, "bytes-string", 1),
    ];

    /// Look a builtin up by its STAGE0_GLOBALS name.
    pub fn from_name(name: &str) -> Option<Builtin> {
        Builtin::ALL
            .iter()
            .find(|(_, n, _)| *n == name)
            .map(|(b, _, _)| *b)
    }

    /// The source name (single source: the registry row).
    pub fn name(&self) -> &'static str {
        match Builtin::ALL.iter().find(|(b, _, _)| b == self) {
            Some((_, n, _)) => n,
            None => unreachable!("every Builtin variant has a registry row"),
        }
    }

    /// The fixed arity.
    pub fn arity(&self) -> u32 {
        match Builtin::ALL.iter().find(|(b, _, _)| b == self) {
            Some((_, _, a)) => *a,
            None => unreachable!("every Builtin variant has a registry row"),
        }
    }
}

/// The interned identity of a builtin's global name (§9.67 NB-5):
/// interned once on first use, then the `ArityMismatch` payload and
/// the evaluator's global seeding read pool entries instead of
/// re-interning text — the `rustc_span::sym` pre-interning discipline
/// (stage0.md §9.66 K113 / §9.67 K116). [`Builtin::ALL`] stays the
/// single text source; this table derives from it, so no name can
/// drift.
pub fn builtin_symbol(b: Builtin) -> Symbol {
    static TABLE: OnceLock<Vec<(Builtin, Symbol)>> = OnceLock::new();
    let table = TABLE.get_or_init(|| {
        Builtin::ALL
            .iter()
            .map(|(b, text, _)| {
                (
                    *b,
                    Symbol::new(text).expect("Builtin::ALL entry must be a valid symbol"),
                )
            })
            .collect()
    });
    table
        .iter()
        .find(|(k, _)| *k == b)
        .map(|(_, s)| s.clone())
        .expect("every Builtin variant has a registry row")
}

impl fmt::Display for Builtin {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "#<builtin:{}>", self.name())
    }
}

// ---------- single-source dispatch (the 0.7 parity floor) ----------
//
// The 18 builtin SEMANTICS live here as free functions so the VM and
// the kerf-runtime meta-circular evaluator share one implementation
// (zero-drift by construction — the parity tests assert the tables,
// the compiler asserts the bodies). Allocation stays with the caller:
// `cons` takes the heap but every budget charge happens at the call
// site, keeping the §19.4 safety point in one place per engine.
//
// §9.73 EVL-1/EVL-2: the ROUTING and the ARITY CHECK are single-sourced
// here too (they used to be written once per engine — a twin dispatch
// over the shared bodies). Every builtin now enters through
// [`dispatch_builtin`] over the [`BuiltinHost`] face, the K150
// host-passing discipline (Lua `precallC`: every C function receives
// `lua_State*` and operates only through it) spelled for two Rust
// engines: static dispatch, two monomorphizations, zero vtable cost.

/// The engine face the shared builtin dispatch needs (the K150/K154
/// host-passing discipline: builtins never touch engine internals —
/// they see exactly this interface). `charge` keeps each engine's
/// §19.4 safety point (the budget semantics stay per-engine); the
/// heap and I/O faces are the same fields both engines already own.
pub trait BuiltinHost {
    /// Charge one allocation against the engine budget (each engine
    /// keeps its own live-usage semantics — the §19.4 safety point).
    fn charge(&mut self, span: Span) -> Result<(), RuntimeError>;
    /// The engine's I/O face (read-line / write-line).
    fn io_mut(&mut self) -> &mut dyn VmIo;
    /// The engine's heap (pair allocation).
    fn heap_mut(&mut self) -> &mut Heap;
    /// The engine's heap, shared (pair reads).
    fn heap(&self) -> &Heap;
}

/// The one builtin entry point for BOTH engines: the fixed-arity
/// check, then the 18-arm routing to the single-source bodies above
/// (the K152 calling-convention lesson: CPython selects the calling
/// adapter ONCE in methodobject.c, never per call site — the twin
/// engines must not re-implement the routing either). A new engine
/// implements [`BuiltinHost`] and gets the full registry behavior
/// from this one function.
pub fn dispatch_builtin<H: BuiltinHost>(
    host: &mut H,
    b: Builtin,
    args: Vec<Value>,
    span: Span,
) -> Result<Value, RuntimeError> {
    if args.len() as u32 != b.arity() {
        return Err(RuntimeError::ArityMismatch {
            // §9.67 NB-5: the payload identity is the pre-interned
            // pool entry — no de-intern/re-intern round trip.
            func: Some(builtin_symbol(b)),
            expected: b.arity(),
            actual: args.len() as u32,
            span,
        });
    }
    match b {
        Builtin::ReadLine => read_line(host.io_mut(), span),
        Builtin::WriteLine => write_line(host.io_mut(), &args[0], span),
        Builtin::RenderLine => render_line(host.io_mut(), &args[0]),
        Builtin::StringBytes => string_bytes(&args[0], host, span),
        Builtin::BytesString => bytes_string(&args[0], host.heap(), span),
        Builtin::Cons => {
            host.charge(span)?;
            let r = cons(args[0].clone(), args[1].clone(), host.heap_mut());
            Ok(Value::Pair(r))
        }
        Builtin::Car => car(&args[0], host.heap(), span),
        Builtin::Cdr => cdr(&args[0], host.heap(), span),
        Builtin::IsPair => Ok(Value::Bool(matches!(args[0], Value::Pair(_)))),
        Builtin::IsNil => Ok(Value::Bool(matches!(args[0], Value::Nil))),
        Builtin::Eq => Ok(Value::Bool(args[0].eq_identity(&args[1]))),
        Builtin::Not => not(&args[0], span),
        Builtin::Add => arith(Opcode::Add, args[0].clone(), args[1].clone(), span),
        Builtin::Sub => arith(Opcode::Sub, args[0].clone(), args[1].clone(), span),
        Builtin::Mul => arith(Opcode::Mul, args[0].clone(), args[1].clone(), span),
        Builtin::Div => arith(Opcode::Div, args[0].clone(), args[1].clone(), span),
        Builtin::Lt | Builtin::Le | Builtin::Gt | Builtin::Ge | Builtin::NumEq => {
            compare(b, &args[0], &args[1], span)
        }
    }
}

/// Same-kind arithmetic: checked i64 ints (fail-closed on overflow
/// and zero division), IEEE floats (inf/nan are values), mixed kinds
/// rejected (§19.5 explicitness).
pub fn arith(op: Opcode, a: Value, b: Value, span: Span) -> Result<Value, RuntimeError> {
    let context: &'static str = match op {
        Opcode::Add => "add operand",
        Opcode::Sub => "sub operand",
        Opcode::Mul => "mul operand",
        Opcode::Div => "div operand",
        _ => unreachable!("arith dispatch covers the four arithmetic ops"),
    };
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => {
            let result = match op {
                Opcode::Add => x.checked_add(y),
                Opcode::Sub => x.checked_sub(y),
                Opcode::Mul => x.checked_mul(y),
                Opcode::Div => {
                    if y == 0 {
                        return Err(RuntimeError::DivByZero { span });
                    }
                    x.checked_div(y)
                }
                _ => unreachable!(),
            };
            result
                .map(Value::Int)
                .ok_or(RuntimeError::ArithmeticOverflow { op, span })
        }
        (Value::Float(x), Value::Float(y)) => Ok(Value::Float(match op {
            Opcode::Add => x + y,
            Opcode::Sub => x - y,
            Opcode::Mul => x * y,
            Opcode::Div => x / y,
            _ => unreachable!(),
        })),
        (a, b) => {
            let got = if !matches!(a, Value::Int(_) | Value::Float(_)) {
                a.kind_name()
            } else {
                b.kind_name()
            };
            Err(RuntimeError::TypeMismatch {
                context,
                demanded: demanded::SAME_KIND_NUMBER,
                got,
                span,
            })
        }
    }
}

/// Same-kind numeric comparison (IEEE semantics for floats: every
/// comparison against NaN is false, including `=`).
pub fn compare(b: Builtin, a: &Value, c: &Value, span: Span) -> Result<Value, RuntimeError> {
    let context: &'static str = match b {
        Builtin::Lt => "`<` operand",
        Builtin::Le => "`<=` operand",
        Builtin::Gt => "`>` operand",
        Builtin::Ge => "`>=` operand",
        Builtin::NumEq => "`=` operand",
        _ => unreachable!("compare dispatch covers the five comparisons"),
    };
    let verdict = match (a, c) {
        (Value::Int(x), Value::Int(y)) => match b {
            Builtin::Lt => x < y,
            Builtin::Le => x <= y,
            Builtin::Gt => x > y,
            Builtin::Ge => x >= y,
            Builtin::NumEq => x == y,
            _ => unreachable!(),
        },
        (Value::Float(x), Value::Float(y)) => match b {
            Builtin::Lt => x < y,
            Builtin::Le => x <= y,
            Builtin::Gt => x > y,
            Builtin::Ge => x >= y,
            Builtin::NumEq => x == y,
            _ => unreachable!(),
        },
        _ => {
            let got = if !matches!(a, Value::Int(_) | Value::Float(_)) {
                a.kind_name()
            } else {
                c.kind_name()
            };
            return Err(RuntimeError::TypeMismatch {
                context,
                demanded: demanded::SAME_KIND_NUMBER,
                got,
                span,
            });
        }
    };
    Ok(Value::Bool(verdict))
}

/// `car` (strict pair operand; shared with the evaluator).
pub fn car(v: &Value, heap: &Heap, span: Span) -> Result<Value, RuntimeError> {
    match v.as_pair(heap) {
        Some((a, _)) => Ok(a.clone()),
        None => Err(type_mismatch("car operand", demanded::PAIR, v, span)),
    }
}

/// `cdr` (strict pair operand; shared with the evaluator).
pub fn cdr(v: &Value, heap: &Heap, span: Span) -> Result<Value, RuntimeError> {
    match v.as_pair(heap) {
        Some((_, d)) => Ok(d.clone()),
        None => Err(type_mismatch("cdr operand", demanded::PAIR, v, span)),
    }
}

/// `cons`: allocate the pair cell (the caller charges the budget
/// first — one safety point per engine).
pub fn cons(a: Value, b: Value, heap: &mut Heap) -> HeapRef {
    heap.alloc(HeapObj::Pair(a, b))
}

/// `not` (strict bool operand).
pub fn not(v: &Value, span: Span) -> Result<Value, RuntimeError> {
    match v {
        Value::Bool(x) => Ok(Value::Bool(!*x)),
        other => Err(type_mismatch("not operand", demanded::BOOL, other, span)),
    }
}

/// `read-line` (end of input fails closed). §9.72 SYN-1: the fresh
/// line becomes the one shared allocation for this runtime string.
pub fn read_line(io: &mut dyn VmIo, span: Span) -> Result<Value, RuntimeError> {
    match io.read_line() {
        Some(line) => Ok(Value::Str(Rc::from(line))),
        None => Err(RuntimeError::Eof { span }),
    }
}

/// `write-line` (strict string operand; nil result).
pub fn write_line(io: &mut dyn VmIo, v: &Value, span: Span) -> Result<Value, RuntimeError> {
    match v {
        Value::Str(s) => {
            io.write_line(s);
            Ok(Value::Nil)
        }
        other => Err(type_mismatch(
            "write-line operand",
            demanded::STRING,
            other,
            span,
        )),
    }
}

/// `render-line` (any value; the host display text emitted as one
/// output line; nil result). The MX-1 retirement (W-SELFHOST-ORCH
/// blade 2): the value→bytes edge rides the §8.8 write channel —
/// the display formatting is the io.rs "later library concern"
/// line arriving as the library face OVER the channel (the
/// string-interning lineage: identity in-language, rendering at
/// the host edge — the read_line precedent's form: the side
/// effect lives in the host, the vocabulary in the language,
/// std/render.ktf). Total over every value kind: the render has
/// no failure face at the value layer (the census golden pins the
/// text digit-by-digit against this same display single source).
pub fn render_line(io: &mut dyn VmIo, v: &Value) -> Result<Value, RuntimeError> {
    io.write_line(&v.to_string());
    Ok(Value::Nil)
}

/// `string-bytes` (the read-edge library face — W-SELFHOST-ORCH
/// blade 3, B3): one string value decoded into the integer byte
/// chain the lexical twins consume (one int per byte, tail-built;
/// the empty string rides as `nil`, the byte-table prefix
/// precedent's empty-source form). Non-string operands fail
/// closed with the strict-string family's type mismatch. One
/// charge per cell — the Cons arm's own budget form (a long line
/// is a real allocation, never a budget-free decode).
pub fn string_bytes<H: BuiltinHost>(
    v: &Value,
    host: &mut H,
    span: Span,
) -> Result<Value, RuntimeError> {
    let s = match v {
        Value::Str(s) => s,
        other => {
            return Err(type_mismatch(
                "string-bytes operand",
                demanded::STRING,
                other,
                span,
            ));
        }
    };
    // Tail-build the chain (the byte_table_literal discipline —
    // reverse iteration, head-cons; iterative dispose, no
    // recursion depth face).
    let mut out = Value::Nil;
    for b in s.as_bytes().iter().rev() {
        host.charge(span)?;
        out = Value::Pair(cons(Value::Int(i64::from(*b)), out, host.heap_mut()));
    }
    Ok(out)
}

/// `bytes-string` (the reflow library face — the B3 revision's
/// inverse row): one integer byte chain re-encoded as a string
/// value (the parser twin's byte-table payloads — identifier texts,
/// decoded string bodies, digitized spans — re-enter the expander's
/// string-carried record grammar through this edge). Non-chain
/// cells and out-of-range bytes fail closed with the strict family's
/// type mismatch (a byte is an int in 0..=255; never a silent
/// truncation), and the chain must decode as utf-8 (the string
/// value's own domain).
pub fn bytes_string(v: &Value, heap: &Heap, span: Span) -> Result<Value, RuntimeError> {
    let mut buf: Vec<u8> = Vec::new();
    let mut cur = v.clone();
    loop {
        match cur.as_pair(heap) {
            Some((head, tail)) => {
                let b = match head {
                    Value::Int(i) if (0..=255).contains(i) => *i as u8,
                    other => {
                        return Err(type_mismatch(
                            "bytes-string byte",
                            "an int in 0..=255",
                            other,
                            span,
                        ));
                    }
                };
                buf.push(b);
                cur = tail.clone();
            }
            None => match cur {
                Value::Nil => break,
                other => {
                    return Err(type_mismatch(
                        "bytes-string chain",
                        "a byte chain",
                        &other,
                        span,
                    ));
                }
            },
        }
    }
    match String::from_utf8(buf) {
        Ok(s) => Ok(Value::Str(Rc::from(s))),
        // The utf-8 rejection is a value-domain failure, not a kind
        // mismatch — the got field carries the honest domain verdict
        // (the fail-closed face stays honest about WHY).
        Err(_) => Err(RuntimeError::TypeMismatch {
            context: "bytes-string payload",
            demanded: "a utf-8 byte chain",
            got: "a non-utf-8 byte chain",
            span,
        }),
    }
}

#[cfg(test)]
mod tests {
    //! Builtin registry tests (FP3 seeding face): round-trips, fixed
    //! arities, and R8 display forms.

    use super::*;

    #[test]
    fn registry_round_trips_all_twenty_one_with_fixed_arities() {
        assert_eq!(Builtin::ALL.len(), 21);
        for (b, name, arity) in Builtin::ALL {
            assert_eq!(Builtin::from_name(name), Some(b));
            assert_eq!(b.name(), name);
            assert_eq!(b.arity(), arity);
        }
        // Arity classes are pinned (fixed, not variadic).
        assert_eq!(Builtin::Add.arity(), 2);
        assert_eq!(Builtin::Cons.arity(), 2);
        assert_eq!(Builtin::Eq.arity(), 2);
        assert_eq!(Builtin::Car.arity(), 1);
        assert_eq!(Builtin::Not.arity(), 1);
        assert_eq!(Builtin::WriteLine.arity(), 1);
        assert_eq!(Builtin::ReadLine.arity(), 0);
        assert_eq!(Builtin::RenderLine.arity(), 1);
        assert_eq!(Builtin::StringBytes.arity(), 1);
        assert_eq!(Builtin::BytesString.arity(), 1);
    }

    #[test]
    fn from_name_rejects_unknown_names() {
        assert!(Builtin::from_name("fib").is_none());
        assert!(Builtin::from_name("cons*").is_none());
        assert!(Builtin::from_name("read").is_none());
        assert!(Builtin::from_name("").is_none());
    }

    #[test]
    fn from_name_is_case_sensitive_and_whitespace_strict() {
        // No case folding, no trimming: the expander interns exact
        // symbol texts, so the VM-side lookup must match exactly.
        assert!(Builtin::from_name("Car").is_none());
        assert!(Builtin::from_name(" car ").is_none());
        assert!(Builtin::from_name("CAR").is_none());
        assert!(Builtin::from_name("pair? ").is_none());
    }

    #[test]
    fn display_forms_follow_r8_family() {
        assert_eq!(Builtin::Add.to_string(), "#<builtin:+>");
        assert_eq!(Builtin::Le.to_string(), "#<builtin:<=>");
        assert_eq!(Builtin::ReadLine.to_string(), "#<builtin:read-line>");
        assert_eq!(Builtin::WriteLine.to_string(), "#<builtin:write-line>");
        assert_eq!(Builtin::RenderLine.to_string(), "#<builtin:render-line>");
        assert_eq!(Builtin::StringBytes.to_string(), "#<builtin:string-bytes>");
        assert_eq!(Builtin::BytesString.to_string(), "#<builtin:bytes-string>");
        assert_eq!(Builtin::IsPair.to_string(), "#<builtin:pair?>");
    }

    #[test]
    fn registry_names_are_pairwise_distinct() {
        let mut names: Vec<&str> = Builtin::ALL.iter().map(|(_, n, _)| *n).collect();
        names.sort_unstable();
        let count = names.len();
        names.dedup();
        assert_eq!(names.len(), count, "registry names must not repeat");
    }

    #[test]
    fn builtin_symbols_match_the_registry_and_pool() {
        // §9.67 NB-5 guard: the derived identity table cannot drift
        // from its single text source (`Builtin::ALL`), and every
        // entry is a live pool member — an independently interned
        // Symbol of the same text resolves equal (the §9.52 single
        // pool invariant, pinned on the seeding face).
        for (b, name, _) in Builtin::ALL {
            let sym = builtin_symbol(b);
            assert_eq!(sym.as_str(), name);
            let independent = Symbol::new(name).expect("registry name must intern");
            assert_eq!(sym, independent);
        }
        // Two reads return the same pool entry (intern-once, not a
        // fresh intern per ArityMismatch payload).
        assert_eq!(builtin_symbol(Builtin::Add), builtin_symbol(Builtin::Add));
    }
}

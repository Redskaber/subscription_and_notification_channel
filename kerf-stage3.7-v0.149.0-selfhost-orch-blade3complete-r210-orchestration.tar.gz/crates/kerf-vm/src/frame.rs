//! Call frames (docs/stage0.md §8.12 / §19.5 invariant 1).
//!
//! The frame FORMAT IS FROZEN: every calling frame carries three
//! extension slots — ext1 continuation, ext2 exception table, ext3
//! debug frame. Stage 0 keeps ext1 as a reserved singleton, fills
//! ext3 with the proto's diagnostic name, and — from the
//! W-EFFECT-MECHANISM blade-1 semantic deepening — fills ext2 under
//! one-shot clause entry (the §9.15.7③ physical reservation's
//! anchored direction: the Handle continuation management carrier,
//! NOT a stack-unwinding form); the slots are part of the §15
//! pre-stage contract, so they exist now and grow later
//! without a layout break.

use std::rc::Rc;

use kerf_span::Symbol;

use crate::value::Value;

/// ext1 — reserved for continuations (Stage 1+ effect resumption).
/// Stage 0 value: locked format, always [`ContinuationSlot::Reserved`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ContinuationSlot {
    Reserved,
}

/// ext2 — the exception-table slot: the Handle continuation
/// management carrier (§9.15.7③). Filled only on a one-shot clause
/// frame (W-EFFECT-MECHANISM §5.1, blade 1): the clause's NORMAL
/// return then means halt — the frame stack unwinds to the
/// installing handle's frame and the clause's return value becomes
/// the handle expression's value. Every other frame keeps the
/// Stage 0 reserved singleton.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ExceptionTableSlot {
    Reserved,
    /// The one-shot clause contract: where a plain clause return
    /// must land (the halt target), and how far the handler stack
    /// unwinds when it does.
    OneShot(OneShotMark),
}

/// The halt contract a one-shot clause frame carries in its ext2
/// slot (W-EFFECT-MECHANISM §5.1, blade 1 — the value-layer/VM
/// semantic deepening; the r186 window's §5.1 ruling table).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OneShotMark {
    /// The index of the frame that ran the installing handle's
    /// push-handler (stable while the handle is live: frames above
    /// it pop before it ever does).
    pub handle_frame: usize,
    /// The pc after that handle's pop-handler — the handle
    /// expression's continuation point (baked into every
    /// push-handler of the handle by the compiler).
    pub resume_pc: u32,
    /// The handler-stack length the halt must restore (the depth
    /// before the installing handle's first clause — the whole
    /// block uninstalls with the handle's completion).
    pub handler_base: usize,
}

/// ext3 — the debug frame. Filled from 0.6 on: the callee proto's
/// diagnostic name (stack-trace rendering is the 0.8 driver's face).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DebugFrameSlot {
    pub func_name: Option<Symbol>,
}

/// The frozen three-slot extension block (§8.12 frame shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FrameExt {
    /// ext1: continuation.
    pub continuation: ContinuationSlot,
    /// ext2: exception table.
    pub exception_table: ExceptionTableSlot,
    /// ext3: debug frame.
    pub debug: DebugFrameSlot,
}

impl FrameExt {
    /// The Stage 0 shape (ext1/ext2 reserved, ext3 named).
    pub fn new(func_name: Option<Symbol>) -> Self {
        FrameExt {
            continuation: ContinuationSlot::Reserved,
            exception_table: ExceptionTableSlot::Reserved,
            debug: DebugFrameSlot { func_name },
        }
    }
}

/// One activation record. Frames live in the VM's frame vector —
/// kerf-level recursion grows that vector, never the Rust stack (the
/// TD-023 anchor: iterative main loop + heap frame stack). Each frame
/// owns its operand stack, locals, and capture area; `pc` is the
/// index into the owning proto's code of the NEXT instruction to
/// fetch.
#[derive(Debug, Clone, PartialEq)]
pub struct Frame {
    /// Proto index into `Bytecode::funcs`.
    pub func: usize,
    /// Next fetch position (§19.5 invariant 2: only jump / call /
    /// ret / error paths move it against the +1 rule).
    pub pc: usize,
    /// Parameter slots first (0..params), then let slots; slots never
    /// stored yet read as `nil` (deterministic baseline — verified
    /// source never reads before its store).
    pub locals: Vec<Value>,
    /// The capture area (Stage 2.1 LA-3): the values this frame's
    /// closure captured, in descriptor order — a shared-immutable
    /// handle into the closure cell's env (Stage 3.1 W-3.1 blade:
    /// `invoke` installs it by refcount bump, not by an O(captured)
    /// copy; the frozen three-slot ext block keeps its layout
    /// (§9.51.2 row 1 ruling)). `load-captured` reads it by index.
    /// The entry proto's area is always empty (top-level free names
    /// are globals).
    pub captured: Rc<Vec<Value>>,
    /// This frame's operand stack.
    pub stack: Vec<Value>,
    /// The frozen extension block.
    pub ext: FrameExt,
}

impl Frame {
    /// Build a frame for `func` whose proto declares `n_locals` slots,
    /// entering with `args` (arity already checked by the caller) and
    /// the captured values of the invoked closure (descriptor order).
    pub fn new(
        func: usize,
        func_name: Option<Symbol>,
        n_locals: u32,
        args: Vec<Value>,
        captured: Rc<Vec<Value>>,
    ) -> Self {
        let mut locals = vec![Value::Nil; n_locals as usize];
        if args.len() > locals.len() {
            // Arity was checked before entry; args beyond n_locals
            // would be a caller-contract violation (params <= n_locals
            // holds for every proto the compiler builds).
            locals.resize(args.len(), Value::Nil);
        }
        for (slot, arg) in locals.iter_mut().zip(args) {
            *slot = arg;
        }
        Frame {
            func,
            pc: 0,
            locals,
            captured,
            stack: Vec::new(),
            ext: FrameExt::new(func_name),
        }
    }
}

#[cfg(test)]
mod tests {
    //! Frame layout tests (FP2/FP4): construction, nil padding, and
    //! the frozen extension-slot shape.

    use super::*;

    fn sym(text: &str) -> Symbol {
        Symbol::new(text).expect("fixture symbol")
    }

    #[test]
    fn frame_binds_args_then_pads_and_locks_ext_slots() {
        let frame = Frame::new(
            1,
            Some(sym("fib")),
            3,
            vec![Value::Int(7)],
            Rc::new(vec![Value::Int(42)]),
        );
        assert_eq!(frame.func, 1);
        assert_eq!(frame.pc, 0);
        // args in param slots, never-stored slots read as nil.
        assert_eq!(frame.locals, vec![Value::Int(7), Value::Nil, Value::Nil]);
        // the capture area rides independently of the locals (the
        // frozen ext block keeps its layout — §9.51.2 row 1).
        assert_eq!(*frame.captured, vec![Value::Int(42)]);
        assert!(frame.stack.is_empty());
        // The three extension slots exist with their Stage 0 values.
        assert_eq!(frame.ext.continuation, ContinuationSlot::Reserved);
        assert_eq!(frame.ext.exception_table, ExceptionTableSlot::Reserved);
        assert_eq!(frame.ext.debug.func_name, Some(sym("fib")));
    }

    #[test]
    fn frame_without_padding_keeps_args_only() {
        // n_locals == arg count: no nil slots at all; an empty capture
        // area is the no-capture shape (a closure proto whose table is
        // empty, or the entry proto).
        let frame = Frame::new(
            0,
            None,
            2,
            vec![Value::Bool(true), Value::Nil],
            Rc::new(Vec::new()),
        );
        assert_eq!(frame.locals, vec![Value::Bool(true), Value::Nil]);
        assert!(frame.captured.is_empty());
    }

    #[test]
    fn anonymous_frame_has_no_debug_name() {
        let frame = Frame::new(0, None, 0, vec![], Rc::new(Vec::new()));
        assert!(frame.locals.is_empty());
        assert!(frame.captured.is_empty());
        assert_eq!(frame.ext.debug.func_name, None);
    }
}

//! kerf-core — the frozen semantic primitive kernel (Layer 4).
//!
//! Single source of truth for the primitive enumeration (docs/sop.md
//! §21.12-11): `CoreExpr` carries the nine semantic primitives `Fn / Apply /
//! If / Var / Literal / Assign / Let / Perform / Handle`; `ModuleItem` is the
//! declaration layer (`Define / Require / Module`); surface `do` sugar
//! desugars into `Let` at expansion time (sub-stage 0.4).
//!
//! The historical frozen set (docs/stage0.md §3.2: Lambda/App/If/VarRef/
//! Literal/SetBang/Define/Begin/Module) maps onto this set via the
//! semantic-equivalence table of §6.12.6 — ratified in
//! docs/develop/v0/stage-0/0.1-design-adjudications.md (TD-005).
//!
//! Design principles (docs/stage0.md §7.4.2): type safety over naming
//! safety (this ADT is compiler-private; `Symbol` hides its payload behind
//! a checked constructor), semantic naming over historical naming, zero
//! redundancy. The ANF/de Bruijn eight-primitive shape (§7.4.3) is a
//! Stage 2 evaluation target and carries no implementation obligation here.
//!
//! Every node carries a real `Span` (never `Option`, never a dummy — TD-004
//! ruling 2; docs/stage0.md §8.6). The expander-side consumption contract
//! (sub-stage 0.4) is pre-anchored by `CoreExpr::visit_spans` and the
//! validated `&str`-based constructors.
//!
//! Sub-stage 0.10 adds the frozen reservation face
//! ([`reserved`]): four contract families (effects / multistage /
//! capability I/O / compilation cache) defined but unimplemented —
//! docs/stage0.md §9.1.1-§9.1.4 + §9.4 matrix, SOP §21.12-10(2).

mod error;
mod expr;
mod module;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub mod reserved;
pub use error::CoreError;
pub use expr::{Binding, CoreExpr, HandlerClause, LiteralValue};
pub use module::{AnnotationKind, ExternAbi, ExternItem, ExternType, ModuleItem};

// Since v0.28.0 this crate re-exports nothing from kerf-span (the
// no-forwarding rule, stage0.md §9.59): the coordinate and identity
// types (`Span`/`FileId`/`ByteOffset`/`ExpansionId`/`Symbol`) still
// appear throughout this crate's public API, but consumers import them
// directly from kerf-span — the rustc_ast precedent: rustc_span is a
// direct dependency of every consumer crate and rustc_ast re-exports
// nothing from it (§9.59 K81; SOP §18.5 v15.2 foundation-direct-edge
// policy).

//! ModuleItem: the declaration layer above CoreExpr (Layer 4).
//!
//! Per the TD-005 adjudication (docs/develop/v0/stage-0/
//! 0.1-design-adjudications.md), the historical §3.2 `Define`/`Module`
//! expression variants migrate to a declaration layer (§7.4.4 migration
//! table: "module moves to the module system layer"), and `Require` joins
//! them as the third declaration variant. A program is a `Vec<ModuleItem>`
//! whose items nest `CoreExpr` payloads. Sub-stage 0.9 adds the fourth
//! variant `DefineSyntax`: the macro declaration is part of the module's
//! declaration record (the single source of truth for what a module
//! declares), while carrying zero runtime code — the transformer itself
//! lives in the expansion environment (kerf-expander, Layer 3).

use std::fmt;

use crate::error::CoreError;
use crate::expr::CoreExpr;
use crate::expr::LiteralValue;
use kerf_span::Span;
use kerf_span::Symbol;

/// One top-level (or nested-module) declaration.
#[derive(Debug, Clone, PartialEq)]
pub enum ModuleItem {
    /// `name` bound to `value` in the module namespace.
    Define {
        span: Span,
        name: Symbol,
        value: CoreExpr,
    },
    /// Dependency declaration on another module.
    Require { span: Span, module: Symbol },
    /// A nested module with its own item list.
    Module {
        span: Span,
        name: Symbol,
        items: Vec<ModuleItem>,
    },
    /// A `define-syntax` macro declaration (sub-stage 0.9). The name is
    /// recorded for diagnostics and module bookkeeping; the transformer
    /// body never reaches code generation or evaluation (the compiler
    /// and the evaluator both skip it — the `Require` zero-code
    /// precedent applied to the macro phase).
    DefineSyntax { span: Span, name: Symbol },
    /// An FFI extern block (Stage 3 W-3.2 — the language-level foreign
    /// contract, the B1 deviation closure). Declares foreign function
    /// signatures; like `Require`/`DefineSyntax` it carries zero
    /// runtime code — the compiler records the contract table in the
    /// bytecode product (`Bytecode::externs`) and the C backend is
    /// the only engine with a foreign call face (the VM/eval engines
    /// fail closed with `ExternCallRequiresBackend`). Top-level only:
    /// the C symbol namespace is flat, so a nested-module extern is
    /// rejected at expansion time.
    Extern {
        span: Span,
        abi: ExternAbi,
        items: Vec<ExternItem>,
    },
    /// A type-annotation site record (W-LANG-FOUNDATION blade 1 —
    /// the GZ-1 representation): the expander's desugaring residue.
    /// Annotations are surface sugar the HM layer owns: the annotated
    /// form desugars to the plain core form byte-for-byte, and each
    /// anchored site emits one zero-code item (the `Require` /
    /// `DefineSyntax` precedent) carrying (a) the ANCHOR the
    /// inference walk can find again — the fn node's own span for
    /// param/ret sites, the binding's value-node extent for let
    /// sites — and (b) the annotation spec as a value tree (symbols
    /// ride as strings, lists ride the pair algebra — the same data
    /// universe the reader's quote face produces; zero new kernel
    /// types). Emitted immediately after the annotated item in the
    /// module's item stream (a deterministic order both arms share).
    Annotate {
        /// The annotation site — the spec's extent (the E0013
        /// diagnostic position).
        span: Span,
        /// The anchor the inference walk matches (see the variant
        /// docs; file-unique by construction — distinct source
        /// positions never share an extent).
        anchor: Span,
        /// Which anchor slot the site points at.
        kind: AnnotationKind,
        /// The param index (Param sites); zero otherwise.
        index: u32,
        /// The spec value tree (the read layer's construction —
        /// see the window file §8 spec algebra).
        spec: LiteralValue,
    },
    /// A struct declaration record (W-LANG-FOUNDATION blade 2 —
    /// the GZ-2/GZ-3 representation): the desugaring's type-layer
    /// residue. A struct is surface sugar the macro layer owns:
    /// the declaration desugars to real `define` items (the
    /// constructor and one accessor per field) plus generated
    /// annotation sites, and this zero-code item carries the
    /// declaration's own face — the name and each field's spec
    /// value tree — so the inference layer's resolve table can map
    /// the name to its field types (the `Require`/`Annotate`
    /// zero-code precedent). Top-level only (the flat type-table
    /// ruling, the extern form's own); the expander police owns
    /// that face.
    Struct {
        /// The declaration site — the struct keyword's extent.
        span: Span,
        /// The declared name (the type-layer identity; reserved
        /// for the module once declared).
        name: Symbol,
        /// The fields in declaration order: (field name, spec
        /// value tree). The spec grammar is the blade 1 algebra
        /// in full (an unresolvable spec degrades to `Dyn`).
        fields: Vec<(Symbol, LiteralValue)>,
    },
    /// An enum declaration record (W-LANG-FOUNDATION blade 3 —
    /// the GZ-4 representation): the desugaring's type-layer
    /// residue, the enum form of the struct record's own. An enum
    /// is surface sugar the macro layer owns: the declaration
    /// desugars to real `define` items (one constructor per
    /// variant, each building `(cons TAG payload-chain)` — the
    /// tag is the variant's declaration-order Int, the payload
    /// chain the struct representation's own right fold) plus
    /// generated annotation sites, and this zero-code item carries
    /// the declaration's own face — the name and each variant's
    /// payload spec value trees — so the inference layer's resolve
    /// table can map the name to `Type::Enum` (the nominal
    /// carrier, the struct record's own discipline). Top-level
    /// only (the flat type-table ruling); the expander police owns
    /// that face.
    Enum {
        /// The declaration site — the enum keyword's extent.
        span: Span,
        /// The declared name (the type-layer identity; reserved
        /// for the module once declared).
        name: Symbol,
        /// The variants in declaration order: (variant name,
        /// payload spec value trees). The spec grammar is the
        /// blade 1 algebra in full (an unresolvable spec degrades
        /// to `Dyn`).
        variants: Vec<(Symbol, Vec<LiteralValue>)>,
    },
}

/// Which anchor slot a dann site points at (blade 1 GZ-1): a fn
/// param position, a fn return slot, or a let binding's value.
/// The twin record grammar spells these `"param"` / `"ret"` /
/// `"let"` ([`AnnotationKind::kind_tag`]).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AnnotationKind {
    /// A fn param slot — `index` selects the param.
    Param,
    /// A fn return slot.
    Ret,
    /// A let binding — the anchor is the binding's value-node
    /// extent (the oracle `Binding::span`, the twin value record).
    Let,
}

impl AnnotationKind {
    /// The stable record tag (the twin item-stream vocabulary —
    /// the `ExternType::kind_tag` precedent).
    pub fn kind_tag(&self) -> &'static str {
        match self {
            AnnotationKind::Param => "param",
            AnnotationKind::Ret => "ret",
            AnnotationKind::Let => "let",
        }
    }

    /// The reverse mapping (the twin rebuild face).
    pub fn from_kind_tag(tag: &str) -> Option<Self> {
        match tag {
            "param" => Some(AnnotationKind::Param),
            "ret" => Some(AnnotationKind::Ret),
            "let" => Some(AnnotationKind::Let),
            _ => None,
        }
    }
}

/// The ABI of an extern block (W-3.2 §1.1). A closed single-variant
/// enum today: only the C ABI is defined (R-F4), and an unknown ABI
/// string is an expander error, never a silent default — a second
/// ABI grows a variant here and nowhere else.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExternAbi {
    C,
}

/// One extern item's type: the C-ABI scalar set (W-3.2 §1.5 R-F1 —
/// the boundary materializes these as plain C values; heap types
/// need the handle protocol, a registered extension face).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExternType {
    Int,
    Bool,
    Float,
}

impl ExternType {
    /// Stable one-word diagnostic/dump tag (the `kind_name`
    /// discipline at the extern type face).
    pub fn kind_tag(&self) -> &'static str {
        match self {
            ExternType::Int => "int",
            ExternType::Bool => "bool",
            ExternType::Float => "float",
        }
    }
}

/// One declared foreign function (W-3.2 §1.2): a name plus a
/// signature. The name is an ordinary canonical identifier (dashes
/// legal); the C symbol is derived (see [`ExternItem::c_symbol`]).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ExternItem {
    pub span: Span,
    pub name: Symbol,
    pub params: Vec<ExternType>,
    pub ret: ExternType,
}

impl ExternItem {
    /// The derived C symbol: the canonical name's target-skin
    /// spelling (interior `-` -> `_` — the skin dictionary's own
    /// direction, W-3.2 §1.3). Deterministic; injectivity within a
    /// program is enforced at the product boundary since the r123
    /// re-attribution (compile/verify via `extern_table_floor`;
    /// zero mangling in the C++ `_ZN...` sense — no type or
    /// signature encoding).
    pub fn c_symbol(&self) -> String {
        self.name.as_str().replace('-', "_")
    }

    /// Whether the derived C symbol is a valid C identifier
    /// (`[A-Za-z_][A-Za-z0-9_]*`) — the boundary floor every
    /// product consumer (compile validation, bytecode `verify`, C
    /// emission) shares through this predicate. Since the r123
    /// re-attribution (W-CSYM-EXPR ruling b) the expander no longer
    /// early-polices this face — the frozen subset cannot express
    /// it, so it is a C-domain product constraint, not source
    /// syntax semantics.
    pub fn c_symbol_is_valid(&self) -> bool {
        let s = self.c_symbol();
        let bytes = s.as_bytes();
        let head_ok = |b: u8| b.is_ascii_alphabetic() || b == b'_';
        let tail_ok = |b: u8| b.is_ascii_alphanumeric() || b == b'_';
        match bytes.first() {
            Some(&b) if head_ok(b) => bytes[1..].iter().all(|&b| tail_ok(b)),
            _ => false,
        }
    }
}

impl ModuleItem {
    /// The span of this declaration (every variant carries one — TD-004).
    pub fn span(&self) -> Span {
        match self {
            ModuleItem::Define { span, .. }
            | ModuleItem::Require { span, .. }
            | ModuleItem::Module { span, .. }
            | ModuleItem::DefineSyntax { span, .. }
            | ModuleItem::Extern { span, .. }
            | ModuleItem::Annotate { span, .. }
            | ModuleItem::Struct { span, .. }
            | ModuleItem::Enum { span, .. } => *span,
        }
    }

    /// Stable diagnostic name (one lowercase word).
    pub fn kind_name(&self) -> &'static str {
        match self {
            ModuleItem::Define { .. } => "define",
            ModuleItem::Require { .. } => "require",
            ModuleItem::Module { .. } => "module",
            ModuleItem::DefineSyntax { .. } => "define-syntax",
            ModuleItem::Extern { .. } => "extern",
            ModuleItem::Annotate { .. } => "dann",
            ModuleItem::Struct { .. } => "dstruct",
            ModuleItem::Enum { .. } => "denum",
        }
    }

    /// Pre-order span traversal: this item's span first, then nested
    /// expression / item spans depth-first (mirrors
    /// [`CoreExpr::visit_spans`] — the same consumption contract at the
    /// declaration layer).
    pub fn visit_spans(&self, f: &mut impl FnMut(Span)) {
        match self {
            ModuleItem::Define { span, value, .. } => {
                f(*span);
                value.visit_spans(f);
            }
            ModuleItem::Require { span, .. } => f(*span),
            ModuleItem::Module { span, items, .. } => {
                f(*span);
                for item in items {
                    item.visit_spans(f);
                }
            }
            ModuleItem::DefineSyntax { span, .. } => f(*span),
            ModuleItem::Extern { span, items, .. } => {
                f(*span);
                for item in items {
                    f(item.span);
                }
            }
            // The dann site record: the annotation site and its
            // anchor are both real source positions (the retarget
            // walk and the diagnostic renderers consume them).
            ModuleItem::Annotate { span, anchor, .. } => {
                f(*span);
                f(*anchor);
            }
            // The struct declaration record: the declaration site
            // is a real source position; the field spec value
            // trees carry no spans of their own (the payload is
            // the type layer's, not the span layer's).
            ModuleItem::Struct { span, .. } => f(*span),
            // The enum declaration record: the struct record's own
            // face — the declaration site is a real source
            // position; the variant payload spec value trees carry
            // no spans of their own (the same layering).
            ModuleItem::Enum { span, .. } => f(*span),
        }
    }

    /// Checked `define` constructor from source-shaped name text.
    pub fn define(span: Span, name: &str, value: CoreExpr) -> Result<Self, CoreError> {
        Ok(ModuleItem::Define {
            span,
            name: Symbol::new(name)?,
            value,
        })
    }

    /// Checked `require` constructor from source-shaped module text.
    pub fn require(span: Span, module: &str) -> Result<Self, CoreError> {
        Ok(ModuleItem::Require {
            span,
            module: Symbol::new(module)?,
        })
    }

    /// Checked `module` constructor from source-shaped name text.
    ///
    /// Member-name uniqueness and cross-module cycles are module-system
    /// semantics owned by plan sub-stage 0.9 (§7.1.1 "module cyclic
    /// dependency" error class); this constructor validates only the
    /// module's own name.
    pub fn module(span: Span, name: &str, items: Vec<ModuleItem>) -> Result<Self, CoreError> {
        Ok(ModuleItem::Module {
            span,
            name: Symbol::new(name)?,
            items,
        })
    }

    /// Checked `define-syntax` constructor from source-shaped name text
    /// (sub-stage 0.9 — the macro declaration record).
    pub fn define_syntax(span: Span, name: &str) -> Result<Self, CoreError> {
        Ok(ModuleItem::DefineSyntax {
            span,
            name: Symbol::new(name)?,
        })
    }

    /// Checked `extern` block constructor (W-3.2). Validates every
    /// item name through the symbol floor and leaves the contract
    /// semantics to the later judges: the language-level faces
    /// (ABI, type vocabulary, canonical collisions) to the
    /// expander, the C-domain faces (derived-symbol legality,
    /// dash/underscore collision) to the product boundary — the
    /// r123 re-attribution (W-CSYM-EXPR ruling b).
    pub fn extern_block(
        span: Span,
        abi: ExternAbi,
        items: Vec<ExternItem>,
    ) -> Result<Self, CoreError> {
        for item in &items {
            Symbol::new(item.name.as_str())?;
        }
        Ok(ModuleItem::Extern { span, abi, items })
    }
}

impl fmt::Display for ModuleItem {
    /// Minimal one-word rendering (stable diagnostic name); canonical
    /// program rendering is deferred with `CoreExpr` (0.8 / 0.11).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.kind_name())
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ModuleItem declaration layer (sub-stage test doc
    //! FP2/FP4; docs/tests/v0/stage0/plan/core.md).

    use super::*;
    use crate::expr::LiteralValue;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn literal(start: u32, end: u32) -> CoreExpr {
        CoreExpr::Literal {
            span: span(start, end),
            value: LiteralValue::Int(1),
        }
    }

    // ---------- positive ----------

    #[test]
    fn moduleitem_kinds_spans_and_nested_visit() {
        let program = vec![
            ModuleItem::require(span(0, 8), "math").unwrap(),
            ModuleItem::module(
                span(10, 60),
                "inner",
                vec![
                    ModuleItem::define(span(20, 40), "one", literal(30, 32)).unwrap(),
                    ModuleItem::define(span(40, 60), "two", literal(50, 52)).unwrap(),
                ],
            )
            .unwrap(),
            ModuleItem::define_syntax(span(70, 90), "my-if").unwrap(),
        ];
        let kinds: Vec<&'static str> = program.iter().map(|i| i.kind_name()).collect();
        assert_eq!(kinds, vec!["require", "module", "define-syntax"]);
        assert_eq!(program[0].span(), span(0, 8));
        assert_eq!(program[0].to_string(), "require");
        assert_eq!(program[2].span(), span(70, 90));
        assert_eq!(program[2].to_string(), "define-syntax");

        let mut collected = Vec::new();
        for item in &program {
            item.visit_spans(&mut |s| collected.push(s.start.0));
        }
        // require; module; inner define1, its literal; inner define2, its
        // literal; define-syntax.
        assert_eq!(collected, vec![0, 10, 20, 30, 40, 50, 70]);
    }

    // ---------- negative ----------

    #[test]
    fn define_constructor_rejects_invalid_name() {
        let err = ModuleItem::define(span(0, 1), "bad name", literal(0, 1))
            .expect_err("invalid define name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    #[test]
    fn require_constructor_rejects_invalid_module_name() {
        let err =
            ModuleItem::require(span(0, 1), "").expect_err("empty module name must be rejected");
        assert_eq!(
            err,
            CoreError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol {
                text: String::new()
            })
        );
    }

    #[test]
    fn define_syntax_constructor_rejects_invalid_name() {
        let err = ModuleItem::define_syntax(span(0, 1), "not a name")
            .expect_err("invalid macro name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    #[test]
    fn module_constructor_rejects_invalid_name() {
        let err = ModuleItem::module(span(0, 1), "a b", vec![])
            .expect_err("invalid module name must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    // ---------- extern (W-3.2) ----------

    fn extern_item(name: &str, params: Vec<ExternType>, ret: ExternType) -> ExternItem {
        ExternItem {
            span: span(10, 20),
            name: Symbol::new(name).expect("fixture name"),
            params,
            ret,
        }
    }

    #[test]
    fn extern_block_constructor_and_face() {
        let block = ModuleItem::extern_block(
            span(0, 30),
            ExternAbi::C,
            vec![
                extern_item(
                    "add",
                    vec![ExternType::Int, ExternType::Int],
                    ExternType::Int,
                ),
                extern_item("truthy", vec![ExternType::Bool], ExternType::Bool),
            ],
        )
        .expect("valid extern block");
        assert_eq!(block.kind_name(), "extern");
        assert_eq!(block.span(), span(0, 30));
        let mut spans = Vec::new();
        block.visit_spans(&mut |s| spans.push(s.start.0));
        // The block span, then each item's span.
        assert_eq!(spans, vec![0, 10, 10]);
    }

    #[test]
    fn extern_c_symbol_derivation_is_the_target_spelling() {
        // W-3.2 §1.3: interior dashes fold to underscores — the skin
        // dictionary's own direction, deterministic and signature-free.
        assert_eq!(
            extern_item("my-add", vec![], ExternType::Int).c_symbol(),
            "my_add"
        );
        assert_eq!(
            extern_item("add", vec![], ExternType::Int).c_symbol(),
            "add"
        );
        assert_eq!(
            extern_item("a-b-c", vec![], ExternType::Int).c_symbol(),
            "a_b_c"
        );
    }

    #[test]
    fn extern_c_symbol_validity_floor() {
        assert!(extern_item("add", vec![], ExternType::Int).c_symbol_is_valid());
        assert!(extern_item("my-add", vec![], ExternType::Int).c_symbol_is_valid());
        assert!(extern_item("_x", vec![], ExternType::Int).c_symbol_is_valid());
        // `set!` derives `set!` — not a C identifier shape.
        assert!(!extern_item("set!", vec![], ExternType::Int).c_symbol_is_valid());
        // A leading digit fails the head rule (the Symbol floor allows
        // digits; the C floor does not).
        assert!(!extern_item("1add", vec![], ExternType::Int).c_symbol_is_valid());
        assert!(!extern_item("9", vec![], ExternType::Int).c_symbol_is_valid());
    }
}

//! ExpandCtx — the expansion environment (scope frames + work budget +
//! the macro registry).
//!
//! The 0.4 hygiene skeleton froze scope-keyed resolution; sub-stage 0.9
//! generalizes the rule to the **binder-scopes subset** judgment
//! (Racket's "Binding as Sets of Scopes"): a frame binds a reference
//! iff the *binding occurrence's* scope set is a subset of the
//! reference's scope set. For non-macro code the two sets coincide
//! (coloring is uniform), so every 0.4 behavior is preserved
//! structurally; for macro-introduced syntax the subset judgment is
//! exactly the hygiene guarantee — an introduced binding carries the
//! def-site scope the spliced arguments lack, and a use-site binding
//! carries its own fresh scope the introduced references lack, so
//! neither can capture the other (docs/stage0.md §19.2 core invariant
//! 2, §9.38(b) scope coloring).
//!
//! The frame also records macro declarations (`define-syntax`): a
//! macro name resolves through the same subset judgment, so macros are
//! lexically scoped like defines (a nested module's macros vanish with
//! its frame — docs/stage0.md §19.2 implementation trap 2: the
//! resolution key includes the scope set).

use std::collections::{HashMap, HashSet};

use kerf_span::Symbol;
use kerf_syntax::{ScopeId, ScopeSet};

use crate::error::ExpandError;
use crate::stage0_global_symbols;
use crate::transformer::SyntaxRules;

/// The expansion work budget: the maximum number of nested `expand`
/// calls on one syntax tree.
///
/// The reader's `NESTING_LIMIT = 256` bounds *source* trees; this cap
/// independently bounds expansion work over any tree, including
/// synthesized trees and macro-produced ones — depth over budget is a
/// structured error, never a stack overflow (docs/stage0.md §19.2
/// core invariant 1). The 2× margin over the reader cap absorbs
/// desugar wrapper levels on maximally nested legal source.
pub const EXPANSION_LIMIT: usize = 512;

/// The outcome of scope-keyed identifier resolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Resolution {
    /// Bound by a lexical frame whose binder scopes are a subset of the
    /// identifier's scope set (parameters, let/do bindings,
    /// module-level defines).
    Local,
    /// Bound by the flat Stage 0 global function table (the minimal
    /// runtime surface — kerf-runtime asserts parity at 0.7).
    Global,
    /// No binding anywhere: the fail-closed error case.
    Unbound,
}

/// One lexical frame: the binding occurrence's scope set, the names
/// bound into it, and the macros declared in it. Opaque outside this
/// module (callers only move `Vec<Frame>` for module isolation
/// save/restore).
///
/// Identity keying (§9.66 TRF-1/TRF-2): both tables key on the
/// interned pool entry, not the text — the callers already hold the
/// `Symbol` from the syntax tree (`StxDatum::Symbol`), so binding
/// stores a 4-byte pool-entry clone (never a text copy) and lookups
/// hash the pool index instead of the bytes (rustc's resolver tables
/// are keyed the same way — stage0.md §9.66 K111/K112).
pub(crate) struct Frame {
    binder_scopes: ScopeSet,
    names: HashSet<Symbol>,
    macros: HashMap<Symbol, usize>,
}

impl Frame {
    fn new(binder_scopes: ScopeSet) -> Self {
        Frame {
            binder_scopes,
            names: HashSet::new(),
            macros: HashMap::new(),
        }
    }
}

/// The expansion environment carried through one `expand_program` or
/// `expand` call tree.
///
/// `Default` = [`ExpandCtx::new`] (the conservative `EXPANSION_LIMIT`
/// budget) — never the all-zero struct (a zero `limit` would reject
/// every `enter`).
pub struct ExpandCtx {
    frames: Vec<Frame>,
    transformers: Vec<SyntaxRules>,
    next_scope: u32,
    depth: usize,
    /// The configured work-budget cap (K162: [`EXPANSION_LIMIT`] on
    /// the default constructor; caller-raised on the `with_limit`
    /// face of the W-REC-DEPTH blade 2).
    limit: usize,
    /// Nested-module depth (W-3.2): 0 at the program top level, +1
    /// per enclosing `module` form. The extern declaration consults
    /// it for the flat-C-namespace ruling (top-level only).
    module_depth: usize,
    /// The program's extern contract names (W-3.2): pre-collected
    /// from the top-level form list before the walk (the letrec
    /// bind-first discipline applied to declarations), and consulted
    /// in the global fallback — an extern name resolves as a global
    /// from any scope, exactly like a Stage 0 global.
    extern_names: HashSet<Symbol>,
    /// The annotation site records collected during the current
    /// top-level form's expansion (W-LANG-FOUNDATION blade 1 — GZ-1:
    /// the "site collection" accumulator). The desugaring arms
    /// (define-ann / fn-ann / let triples) push one zero-code
    /// `ModuleItem::Annotate` per anchored site; the declaration
    /// walk drains the accumulator right after each top-level item
    /// (a deterministic adjacent order the twin mirrors).
    pub(crate) annotations: Vec<kerf_core::ModuleItem>,
    /// The blade 2 struct desugaring's item tail (W-LANG-FOUNDATION
    /// — GZ-2): the constructor's dann sites, every accessor define
    /// with its own dann sites, and the dstruct declaration record.
    /// The struct arm returns the constructor define as its item and
    /// parks the whole tail here; the declaration walk drains it
    /// right after the annotation drain (a deterministic adjacent
    /// order the twin mirrors — the `annotations` discipline's own).
    pub(crate) pending_items: Vec<kerf_core::ModuleItem>,
    /// The struct names declared anywhere in the current module's
    /// top-level form list (blade 2 GZ-2), pre-counted before the
    /// walk: the order-blind reservation table — a define that
    /// rebinds a struct name rejects (`StructNameReserved`), a
    /// second declaration of the same name rejects at both sites
    /// (`StructRedeclared`).
    struct_counts: std::collections::HashMap<Symbol, u32>,
    /// The struct FIELD-COUNT rows (blade 4 §11.1, the pattern
    /// face): name -> declared field count, seeded first-
    /// occurrence wins (the redeclaration police rejects upstream
    /// in `expand_struct` with the full diagnostics; lenient like
    /// the counts — a malformed carrier list still counts its
    /// carriers, and the program dies in `expand_struct` before
    /// any pattern consults the row).
    struct_field_info: std::collections::HashMap<Symbol, u32>,
    /// The enum names declared anywhere in the current module's
    /// top-level form list (blade 3 GZ-4), pre-counted before the
    /// walk (the struct table's own face — `EnumRedeclared` /
    /// `EnumNameReserved`).
    enum_counts: std::collections::HashMap<Symbol, u32>,
    /// The variant names declared anywhere in the current module's
    /// top-level form list (blade 3 GZ-4), pre-counted: the
    /// pattern-face lookup maps one variant name to one enum, so a
    /// second enum's variant of the same name is a cross-enum
    /// collision (`EnumVariantNameCollision`) — the count is over
    /// ALL enums (a count of 2 with distinct parents is the
    /// collision; the per-declaration duplicate is
    /// `EnumDuplicateVariant`, caught in `expand_enum` where the
    /// parent is known).
    variant_counts: std::collections::HashMap<Symbol, u32>,
    /// The enum declaration rows (blade 3 GZ-4, §10.3): the declared
    /// name to its ORDERED variant-name list (declaration order = the
    /// tag numbering's source), pre-scanned before the walk — the
    /// pattern-face lookup and the exhaustiveness count's table.
    /// Only the FIRST declaration of a name rides (the
    /// redeclaration police rejects upstream in `expand_enum`;
    /// lenient here like the counts — malformed enum forms fail in
    /// `expand_enum` with the full police diagnostics).
    enum_variants: std::collections::HashMap<Symbol, Vec<Symbol>>,
    /// The variant lookup rows (blade 3 GZ-4, §10.3): one variant
    /// name to (enum name, tag ordinal, payload count) — the flat
    /// pattern-face lookup maps one variant name to one enum (the
    /// cross-enum collision police rejects upstream in
    /// `expand_enum`), so the rows are collision-free by the time
    /// the pattern face consults them; first occurrence wins in the
    /// lenient pre-scan (same face as `enum_variants`).
    variant_info: std::collections::HashMap<Symbol, (Symbol, u32, usize)>,
    /// The host-injected global names (W-3.12 injection channel):
    /// declared by the HOST that will bind the slots before the run
    /// (the steady-state bootstrap chain's `source_bytes` face),
    /// consulted in the global fallback exactly like extern names.
    /// The expansion-time acceptance is a host declaration, not a
    /// language-surface change: the compiler still emits
    /// load-global, and a host that forgets the bind meets the
    /// run-time `UnboundGlobal` fail-closed face.
    injected_names: HashSet<Symbol>,
}

impl ExpandCtx {
    /// A fresh context: no lexical frames, no registered transformers,
    /// the Stage 0 global table reachable through the flat fallback,
    /// work budget untouched.
    pub fn new() -> Self {
        Self {
            frames: Vec::new(),
            transformers: Vec::new(),
            next_scope: 0,
            depth: 0,
            limit: EXPANSION_LIMIT,
            module_depth: 0,
            extern_names: HashSet::new(),
            injected_names: HashSet::new(),
            annotations: Vec::new(),
            pending_items: Vec::new(),
            struct_counts: std::collections::HashMap::new(),
            struct_field_info: std::collections::HashMap::new(),
            enum_counts: std::collections::HashMap::new(),
            variant_counts: std::collections::HashMap::new(),
            enum_variants: std::collections::HashMap::new(),
            variant_info: std::collections::HashMap::new(),
        }
    }

    /// A fresh context with an explicit work-budget cap (the K162
    /// configurable-guardrail face of the W-REC-DEPTH blade 2: the
    /// default cap stays `512` while deep synthesized trees may ride
    /// a raised limit).
    pub fn with_limit(limit: usize) -> Self {
        Self {
            limit,
            ..Self::new()
        }
    }
}

impl Default for ExpandCtx {
    fn default() -> Self {
        Self::new()
    }
}

impl ExpandCtx {
    /// Drain the collected annotation site records (blade 1 GZ-1):
    /// the declaration walk calls this right after each top-level
    /// item — the dann records ride adjacent to their annotated item
    /// (deterministic order; nested modules drain within their own
    /// walk).
    pub(crate) fn take_annotations(&mut self) -> Vec<kerf_core::ModuleItem> {
        std::mem::take(&mut self.annotations)
    }

    /// Drain the struct desugaring's item tail (blade 2 GZ-2): the
    /// declaration walk calls this right after the annotation drain
    /// — the generated records ride adjacent to their constructor
    /// define (deterministic order; nested modules drain within
    /// their own walk).
    pub(crate) fn take_pending(&mut self) -> Vec<kerf_core::ModuleItem> {
        std::mem::take(&mut self.pending_items)
    }

    /// Seed the struct declaration counts (blade 2 GZ-2): called by
    /// the declaration walk's pre-scan with every `struct` head's
    /// name from the CURRENT module's top-level form list (lenient
    /// by design — malformed struct forms fail in `expand_struct`
    /// with the full police diagnostics).
    pub(crate) fn seed_struct_counts(&mut self, counts: impl IntoIterator<Item = (Symbol, u32)>) {
        self.struct_counts.extend(counts);
    }

    /// How many `struct` declarations in this module carry `name`
    /// (the order-blind redeclaration police's probe — 0 = not a
    /// struct name, 1 = declared once, >1 = redeclared).
    pub(crate) fn struct_name_count(&self, name: &Symbol) -> u32 {
        self.struct_counts.get(name).copied().unwrap_or(0)
    }

    /// Seed the struct field-count rows (blade 4 §11.1): called by
    /// the declaration walk's pre-scan with every `struct` head's
    /// name and carrier count — first occurrence wins per name (the
    /// redeclaration police rejects upstream in `expand_struct`).
    pub(crate) fn seed_struct_rows(&mut self, rows: impl IntoIterator<Item = (Symbol, u32)>) {
        for (name, count) in rows {
            self.struct_field_info.entry(name).or_insert(count);
        }
    }

    /// The pattern-face struct lookup (§11.1): the struct name's
    /// declared field count; None = not a struct name in this
    /// module (the dual-lookup disambiguation's second table —
    /// `variant_row` probes the first).
    pub(crate) fn struct_field_row(&self, name: &Symbol) -> Option<u32> {
        self.struct_field_info.get(name).copied()
    }

    /// Whether `name` is a struct name in this module (the define
    /// arms' reservation probe — blade 2 GZ-2).
    pub(crate) fn is_struct_name(&self, name: &Symbol) -> bool {
        self.struct_counts.contains_key(name)
    }

    /// Seed the enum declaration counts and the variant counts
    /// (blade 3 GZ-4): called by the declaration walk's pre-scan
    /// with every `enum` head's name and every variant name from
    /// the CURRENT module's top-level form list (lenient by design
    /// — malformed enum forms fail in `expand_enum` with the full
    /// police diagnostics; the variant count is over ALL enums,
    /// the cross-enum collision's own probe).
    pub(crate) fn seed_enum_counts(
        &mut self,
        enums: impl IntoIterator<Item = (Symbol, u32)>,
        variants: impl IntoIterator<Item = (Symbol, u32)>,
    ) {
        self.enum_counts.extend(enums);
        self.variant_counts.extend(variants);
    }

    /// How many `enum` declarations in this module carry `name`
    /// (the order-blind redeclaration police's probe — 0 = not an
    /// enum name, 1 = declared once, >1 = redeclared).
    pub(crate) fn enum_name_count(&self, name: &Symbol) -> u32 {
        self.enum_counts.get(name).copied().unwrap_or(0)
    }

    /// Whether `name` is an enum name in this module (the define
    /// arms' reservation probe — blade 3 GZ-4).
    pub(crate) fn is_enum_name(&self, name: &Symbol) -> bool {
        self.enum_counts.contains_key(name)
    }

    /// How many times `name` appears as a variant across all enums
    /// in this module (the cross-enum collision probe — 1 = one
    /// enum owns it, >1 = a collision whichever parents).
    pub(crate) fn variant_name_count(&self, name: &Symbol) -> u32 {
        self.variant_counts.get(name).copied().unwrap_or(0)
    }

    /// Whether `name` is a variant name of any enum in this module
    /// (the define arms' reservation probe — a variant name rides
    /// the declaration namespace, blade 3 GZ-4).
    pub(crate) fn is_variant_name(&self, name: &Symbol) -> bool {
        self.variant_counts.contains_key(name)
    }

    /// Seed the enum declaration rows and the variant lookup rows
    /// (blade 3 GZ-4, §10.3/§10.1②): called by the declaration
    /// walk's pre-scan with every `enum` head's ORDERED variant list
    /// and every variant's (enum, tag ordinal, payload count) row —
    /// first occurrence wins per name (the redeclaration and
    /// cross-enum collision police reject upstream in `expand_enum`
    /// with the full diagnostics; lenient here like the counts).
    pub(crate) fn seed_enum_rows(
        &mut self,
        enum_rows: impl IntoIterator<Item = (Symbol, Vec<Symbol>)>,
        variant_rows: impl IntoIterator<Item = (Symbol, (Symbol, u32, usize))>,
    ) {
        for (name, rows) in enum_rows {
            self.enum_variants.entry(name).or_insert(rows);
        }
        for (variant, row) in variant_rows {
            self.variant_info.entry(variant).or_insert(row);
        }
    }

    /// The pattern-face variant lookup (§10.3): the variant name's
    /// row — (enum name, tag ordinal, payload count); None = not a
    /// variant name in this module (the six-pattern families' own).
    pub(crate) fn variant_row(&self, name: &Symbol) -> Option<(Symbol, u32, usize)> {
        self.variant_info.get(name).cloned()
    }

    /// The exhaustiveness face (§10.1②): the enum's ORDERED
    /// variant-name list in declaration order (the tag numbering's
    /// source — the exhaustiveness count compares the covered set
    /// against it); None = not an enum name in this module.
    pub(crate) fn enum_variant_list(&self, name: &Symbol) -> Option<&[Symbol]> {
        self.enum_variants.get(name).map(|v| v.as_slice())
    }

    /// Enter/leave a nested module body (W-3.2): the extern form's
    /// top-level-only ruling reads this counter.
    pub(crate) fn enter_module(&mut self) {
        self.module_depth += 1;
    }

    pub(crate) fn leave_module(&mut self) {
        self.module_depth -= 1;
    }

    /// Whether the expander is inside a nested module (W-3.2 — the
    /// flat-C-namespace ruling's probe).
    pub(crate) fn in_nested_module(&self) -> bool {
        self.module_depth > 0
    }

    /// Allocate the next fresh scope (monotonic within one context).
    pub(crate) fn fresh_scope(&mut self) -> ScopeId {
        let scope = ScopeId(self.next_scope);
        self.next_scope += 1;
        scope
    }

    /// Push a lexical frame for `scope` entered from the binding
    /// construct whose form carries `base` scopes: the binding
    /// occurrence's scope set is `base ∪ {scope}` — exactly the scopes
    /// a reference *inside* the construct would carry after coloring.
    pub(crate) fn push_frame(&mut self, scope: ScopeId, base: &ScopeSet) {
        let mut binder_scopes = base.clone();
        binder_scopes.insert(scope);
        self.frames.push(Frame::new(binder_scopes));
    }

    /// Pop the innermost lexical frame.
    pub(crate) fn pop_frame(&mut self) {
        self.frames.pop();
    }

    /// Bind `name` in the innermost frame. Names are inserted
    /// progressively (let* order): a value expression expanded before
    /// this call cannot see this binding. The key is the interned pool
    /// entry the caller holds (§9.66 TRF-1: a 4-byte clone, never a
    /// text copy).
    pub(crate) fn bind(&mut self, name: &Symbol) {
        if let Some(frame) = self.frames.last_mut() {
            frame.names.insert(name.clone());
        }
    }

    /// Resolve `name` against `scopes` (the identifier's own scope
    /// set): the innermost frame whose binder scopes are a subset of
    /// `scopes` and that binds `name` wins; the flat global table is
    /// the fallback before the unbound error. Lookup runs on the pool
    /// index (§9.66 TRF-3: the globals fallback is the pre-interned
    /// `stage0_global_symbols()` set, seeded once — K113).
    pub(crate) fn resolve(&self, name: &Symbol, scopes: &ScopeSet) -> Resolution {
        for frame in self.frames.iter().rev() {
            if frame.names.contains(name) && frame.binder_scopes.is_subset_of(scopes) {
                return Resolution::Local;
            }
        }
        if stage0_global_symbols().contains(name)
            || self.extern_names.contains(name)
            || self.injected_names.contains(name)
        {
            return Resolution::Global;
        }
        Resolution::Unbound
    }

    /// Seed the extern contract names (W-3.2): called once from
    /// `expand_declarations`'s top-level entry with the names
    /// pre-collected from the form list (before any item walks, so a
    /// call site may precede its declaration — the bind-first
    /// discipline).
    pub(crate) fn seed_extern_names(&mut self, names: impl IntoIterator<Item = Symbol>) {
        self.extern_names.extend(names);
    }

    /// Whether `name` is a declared extern contract name (blade 2
    /// GZ-2: the struct name-collision police's probe).
    pub(crate) fn is_extern_name(&self, name: &Symbol) -> bool {
        self.extern_names.contains(name)
    }

    /// Seed the host-injected global names (the W-3.12 injection
    /// channel): the host face — called by the
    /// `expand_program_with_injected` entry before the walk, with
    /// the names the host commits to bind into global slots before
    /// the run.
    pub fn seed_injected_names(&mut self, names: impl IntoIterator<Item = Symbol>) {
        self.injected_names.extend(names);
    }

    /// Register a parsed transformer; the returned id is the frame
    /// binding slot used by [`Self::bind_macro`].
    pub(crate) fn register_transformer(&mut self, rules: SyntaxRules) -> usize {
        self.transformers.push(rules);
        self.transformers.len() - 1
    }

    /// The registered transformer for `id`.
    pub(crate) fn transformer(&self, id: usize) -> &SyntaxRules {
        &self.transformers[id]
    }

    /// Declare macro `name` in the innermost frame (the `define-syntax`
    /// binding: lexically scoped like a define). The key is the interned
    /// pool entry (§9.66 TRF-2 — the macro registry is identity-keyed
    /// like rustc's `macro_use_prelude: FxIndexMap<Symbol, _>`, K112).
    pub(crate) fn bind_macro(&mut self, name: &Symbol, id: usize) {
        if let Some(frame) = self.frames.last_mut() {
            frame.macros.insert(name.clone(), id);
        }
    }

    /// Resolve a macro use through the same subset judgment as
    /// [`Self::resolve`]: the innermost frame whose binder scopes are a
    /// subset of the *use-site head's* scopes and that declares `name`
    /// wins (docs/stage0.md §19.2 trap 2 — the scope set is part of
    /// the lookup key, so the same name at different scopes resolves
    /// to different declarations).
    pub(crate) fn resolve_macro(&self, name: &Symbol, use_scopes: &ScopeSet) -> Option<usize> {
        for frame in self.frames.iter().rev() {
            if let Some(id) = frame.macros.get(name) {
                if frame.binder_scopes.is_subset_of(use_scopes) {
                    return Some(*id);
                }
            }
        }
        None
    }

    /// Enter one expansion level: consumes one unit of the work budget
    /// or fails with [`ExpandError::ExpansionDepthExceeded`].
    pub(crate) fn enter(&mut self, span: kerf_span::Span) -> Result<(), ExpandError> {
        if self.depth >= self.limit {
            return Err(ExpandError::ExpansionDepthExceeded {
                limit: self.limit,
                span,
            });
        }
        self.depth += 1;
        Ok(())
    }

    /// Leave one expansion level (paired with [`Self::enter`]).
    pub(crate) fn exit(&mut self) {
        self.depth = self.depth.saturating_sub(1);
    }

    /// Module isolation (docs/stage0.md §8.9 direction): detach all
    /// lexical frames so nested module items cannot see outer defines
    /// or macros; the caller restores them with
    /// [`Self::restore_frames`].
    pub(crate) fn isolate_frames(&mut self) -> Vec<Frame> {
        std::mem::take(&mut self.frames)
    }

    /// Restore frames detached by [`Self::isolate_frames`].
    pub(crate) fn restore_frames(&mut self, saved: Vec<Frame>) {
        self.frames = saved;
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ExpandCtx resolution, macro registry and
    //! budget machinery (sub-stage test doc FP3).

    use super::*;

    /// The interned pool entry for a fixture name (§9.66 TRF-1: the
    /// tables consume the pool entry itself — `Symbol::new` of the
    /// same text always returns the same entry, the single-pool
    /// invariant the identity keying relies on).
    fn s(text: &str) -> Symbol {
        Symbol::new(text).expect("fixture symbol must be valid")
    }

    fn scopes_of(ids: &[u32]) -> ScopeSet {
        let mut set = ScopeSet::new();
        for id in ids {
            set.insert(ScopeId(*id));
        }
        set
    }

    // ---------- positive ----------

    #[test]
    fn fresh_scope_is_monotonic() {
        let mut ctx = ExpandCtx::new();
        let a = ctx.fresh_scope();
        let b = ctx.fresh_scope();
        let c = ctx.fresh_scope();
        assert!(a.0 < b.0 && b.0 < c.0, "scope ids must be monotonic");
    }

    #[test]
    fn subset_rule_resolves_colored_references() {
        // Frame entered from a base context; a reference colored with
        // the same scopes resolves (the 0.4 behavior preserved).
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        let base = scopes_of(&[7]);
        ctx.push_frame(scope, &base);
        ctx.bind(&s("x"));
        let mut ref_scopes = base.clone();
        ref_scopes.insert(scope);
        assert_eq!(ctx.resolve(&s("x"), &ref_scopes), Resolution::Local);
        // Flat global fallback for the Stage 0 surface.
        assert_eq!(ctx.resolve(&s("+"), &scopes_of(&[])), Resolution::Global);
        ctx.pop_frame();
    }

    #[test]
    fn superset_reference_scopes_still_resolve() {
        // A reference under *more* scopes (nested constructs) still
        // resolves against an outer frame: binder ⊆ ref.
        let mut ctx = ExpandCtx::new();
        let outer = ctx.fresh_scope();
        ctx.push_frame(outer, &scopes_of(&[]));
        ctx.bind(&s("x"));
        let inner = ctx.fresh_scope();
        ctx.push_frame(inner, &scopes_of(&[outer.0]));
        ctx.bind(&s("y"));
        let ref_scopes = scopes_of(&[outer.0, inner.0]);
        assert_eq!(ctx.resolve(&s("x"), &ref_scopes), Resolution::Local);
        assert_eq!(ctx.resolve(&s("y"), &ref_scopes), Resolution::Local);
        ctx.pop_frame();
        ctx.pop_frame();
    }

    #[test]
    fn macro_registry_resolves_subset_visible_declarations() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind_macro(&s("m"), 0);
        let mut use_scopes = scopes_of(&[]);
        use_scopes.insert(scope);
        assert_eq!(ctx.resolve_macro(&s("m"), &use_scopes), Some(0));
        ctx.pop_frame();
    }

    #[test]
    fn frame_tables_round_trip_through_the_single_pool() {
        // §9.66 TRF-1/TRF-2/TRF-3 guard: the frame tables key on pool
        // entries, so two independently-interned entries of the same
        // text are the *same* key (the single-pool invariant) — a bind
        // through one entry resolves through the other, and the macros
        // table does the same; the globals fallback answers a pool
        // entry drawn from the pre-interned set.
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        // Two independent interning calls: same text ⇒ same index.
        let binder_entry = s("x");
        let reader_entry = s("x");
        assert_eq!(binder_entry, reader_entry);
        ctx.bind(&binder_entry);
        let mut ref_scopes = scopes_of(&[]);
        ref_scopes.insert(scope);
        assert_eq!(ctx.resolve(&reader_entry, &ref_scopes), Resolution::Local);
        // The macro registry round-trips the same way.
        let macro_binder = s("m");
        let macro_user = s("m");
        ctx.bind_macro(&macro_binder, 7);
        assert_eq!(ctx.resolve_macro(&macro_user, &ref_scopes), Some(7));
        // A different text is a different pool entry — a different key.
        assert_eq!(ctx.resolve(&s("xx"), &ref_scopes), Resolution::Unbound);
        // The globals fallback serves pool entries (the pre-interned
        // set is derived from STAGE0_GLOBALS — same text, same entry).
        assert_eq!(ctx.resolve(&s("car"), &ref_scopes), Resolution::Global);
        ctx.pop_frame();
    }

    // ---------- negative ----------

    #[test]
    fn uncolored_reference_does_not_resolve() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind(&s("x"));
        // Empty scope set (hand-built tree, never colored): the frame
        // scope is not a member, so the binding is invisible — the
        // scope-keyed rule fails closed instead of matching by name.
        assert_eq!(ctx.resolve(&s("x"), &scopes_of(&[])), Resolution::Unbound);
        ctx.pop_frame();
    }

    #[test]
    fn reference_missing_part_of_the_binder_scopes_stays_unbound() {
        // The 0.9 hygiene judgment: a reference that does not carry
        // the *full* binder scope set (e.g. a macro-spliced argument
        // lacking the def-site scope) must not resolve — subset, not
        // membership.
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        let base = scopes_of(&[3]);
        ctx.push_frame(scope, &base);
        ctx.bind(&s("x"));
        // Reference carries the fresh scope but not the base scope.
        assert_eq!(
            ctx.resolve(&s("x"), &scopes_of(&[scope.0])),
            Resolution::Unbound
        );
        ctx.pop_frame();
    }

    #[test]
    fn macro_at_foreign_scope_stays_invisible() {
        let mut ctx = ExpandCtx::new();
        let scope_a = ctx.fresh_scope();
        ctx.push_frame(scope_a, &scopes_of(&[]));
        ctx.bind_macro(&s("m"), 0);
        // The use-site head carries a different scope only: the
        // declaration's binder scopes are not a subset — invisible.
        let scope_b = ctx.fresh_scope();
        assert_eq!(ctx.resolve_macro(&s("m"), &scopes_of(&[scope_b.0])), None);
        ctx.pop_frame();
    }

    #[test]
    fn popped_frame_binding_is_gone() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind(&s("x"));
        ctx.pop_frame();
        assert_eq!(
            ctx.resolve(&s("x"), &scopes_of(&[scope.0])),
            Resolution::Unbound
        );
    }

    #[test]
    fn unknown_name_is_unbound() {
        let ctx = ExpandCtx::new();
        assert_eq!(
            ctx.resolve(&s("nope"), &scopes_of(&[])),
            Resolution::Unbound
        );
    }

    #[test]
    fn stray_exit_does_not_underflow_the_budget() {
        // Saturating discipline: a stray exit below zero must not
        // underflow (and must not silently grant budget).
        let mut ctx = ExpandCtx::new();
        ctx.exit();
        ctx.exit();
        let span = kerf_span::Span::root(
            kerf_span::FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
        )
        .expect("fixture span");
        // Budget accounting stays intact: the full limit is still
        // consumable, and exhaustion still rejects.
        for _ in 0..EXPANSION_LIMIT {
            ctx.enter(span).expect("budget must stay intact");
        }
        assert!(ctx.enter(span).is_err());
    }

    #[test]
    fn isolate_frames_hides_outer_bindings_and_macros() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind(&s("outer"));
        ctx.bind_macro(&s("m"), 0);
        let mut visible = scopes_of(&[]);
        visible.insert(scope);
        let saved = ctx.isolate_frames();
        assert_eq!(ctx.resolve(&s("outer"), &visible), Resolution::Unbound);
        assert_eq!(ctx.resolve_macro(&s("m"), &visible), None);
        ctx.restore_frames(saved);
        assert_eq!(ctx.resolve(&s("outer"), &visible), Resolution::Local);
        assert_eq!(ctx.resolve_macro(&s("m"), &visible), Some(0));
    }

    #[test]
    fn work_budget_rejects_beyond_the_limit() {
        let span = kerf_span::Span::root(
            kerf_span::FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
        )
        .expect("fixture span");
        let mut ctx = ExpandCtx::new();
        for _ in 0..EXPANSION_LIMIT {
            ctx.enter(span).expect("within budget must pass");
        }
        // One more level: beyond the budget — structured rejection.
        let err = ctx.enter(span).expect_err("over budget must fail");
        assert_eq!(
            err,
            ExpandError::ExpansionDepthExceeded {
                limit: EXPANSION_LIMIT,
                span
            }
        );
        // exit restores the budget (paired accounting).
        ctx.exit();
        ctx.enter(span).expect("exit must release one budget unit");
    }
}

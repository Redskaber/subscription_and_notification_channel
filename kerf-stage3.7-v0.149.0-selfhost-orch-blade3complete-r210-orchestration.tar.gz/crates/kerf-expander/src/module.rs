//! The module loading layer (sub-stage 0.9 — docs/stage0.md §8.9
//! module lifecycle, Stage 0 slice).
//!
//! `load_program` validates the declaration graph of one expanded
//! program: it collects the declared (nested) modules, walks every
//! `require` edge (top-level and intra-module, recursively), rejects
//! undeclared modules and duplicate declarations fail-closed, and
//! detects **require cycles** with a three-color DFS — the SOP §7.1.1
//! seventh error class (`module_loader: circular dependency`) lights
//! up here, completing the 7/7 coverage at both the sub-stage and the
//! gate level.
//!
//! Stage 0 boundary (recorded in plan-0.9.md): the deliverable is
//! graph validation plus the dependency-first instantiation order
//! ([`LoadPlan`]); *visibility merging* (requiring a module binds its
//! names into the requiring scope) is the Stage 1 module system — the
//! compiler's flat nested-module compilation and the evaluator's
//! flattening (both established at 0.5/0.7) remain the runtime faces.
//!
//! Identity (§9.64, MOD-1): every module key in this layer — the
//! declaration map, the declaration order, the DFS colors, the cycle
//! path, the error payloads, the load plan — is the interned
//! [`Symbol`] from the single kerf-span pool (§9.52/§9.58). The
//! layer never copies de-interned text: joining the single identity
//! base removed the last text-bridge on the pipeline (each lookup
//! was a `String` allocation per edge per visit).
//!
//! Flat-namespace duplicate semantics (§9.64, MOD-3, recorded): a
//! program is one flat declaration namespace. Duplicate *module*
//! declarations are rejected fail-closed ([`ModuleError::
//! ModuleDuplicate`]); duplicate *define* names are **not** rejected —
//! flat compilation/evaluation stores the last definition into the
//! same global slot (both engines symmetric; the parity globals face
//! observes every define in program order). The module-body
//! duplicate semantics (single-assignment constants — the Racket
//! K104 two-face model) is the Stage 1 module-system window
//! (W-MOD-DUP-DEFINE, §9.64.6).

use std::collections::{HashMap, HashSet};
use std::fmt;

use kerf_core::ModuleItem;
use kerf_span::{Span, Symbol};

/// A module-loading failure (the structured face of the §7.1.1 class
/// 7 family plus the adjacent fail-closed shapes).
#[derive(Debug, Clone, PartialEq)]
pub enum ModuleError {
    /// A require chain closed on itself; `path` lists the cycle in
    /// dependency order (`a -> b -> a`).
    ModuleCycle { path: Vec<Symbol>, span: Span },
    /// A require naming a module the program never declares.
    ModuleNotFound { name: Symbol, span: Span },
    /// Two module declarations share one name.
    ModuleDuplicate { name: Symbol, span: Span },
}

impl fmt::Display for ModuleError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ModuleError::ModuleCycle { path, .. } => {
                // r109 F2: each segment rides backticks like every
                // other identifier payload (R8) — the bare form also
                // made skin-aware re-spelling ambiguous (a bare
                // segment could substring-match unrelated words).
                let names: Vec<String> = path.iter().map(|s| format!("`{}`", s.as_str())).collect();
                write!(f, "module cycle detected: {}", names.join(" -> "))
            }
            ModuleError::ModuleNotFound { name, .. } => {
                write!(f, "required module `{}` is not declared", name.as_str())
            }
            ModuleError::ModuleDuplicate { name, .. } => {
                write!(f, "duplicate module declaration `{}`", name.as_str())
            }
        }
    }
}

impl ModuleError {
    /// The diagnostic span (the `require` / duplicate `module` site).
    pub fn span(&self) -> Span {
        match self {
            ModuleError::ModuleCycle { span, .. }
            | ModuleError::ModuleNotFound { span, .. }
            | ModuleError::ModuleDuplicate { span, .. } => *span,
        }
    }

    /// The same error with its span replaced (the step-④ expand
    /// segment's retarget face — the `ExpandError::with_span`
    /// contract: the twin rebuild's `FileId(0)` spans retarget to
    /// the session's real file id; the match is exhaustive so a new
    /// variant fails here at compile time).
    pub fn with_span(self, span: Span) -> Self {
        match self {
            ModuleError::ModuleCycle { path, .. } => ModuleError::ModuleCycle { path, span },
            ModuleError::ModuleNotFound { name, .. } => ModuleError::ModuleNotFound { name, span },
            ModuleError::ModuleDuplicate { name, .. } => {
                ModuleError::ModuleDuplicate { name, span }
            }
        }
    }

    /// The interned identifiers this error's message names (the
    /// skin-awareness subject set — r109 F2; the cycle names every
    /// segment). See `ExpandError::subject_symbols` for the contract.
    pub fn subject_symbols(&self) -> Vec<&Symbol> {
        match self {
            ModuleError::ModuleCycle { path, .. } => path.iter().collect(),
            ModuleError::ModuleNotFound { name, .. } => vec![name],
            ModuleError::ModuleDuplicate { name, .. } => vec![name],
        }
    }
}

/// The validated instantiation plan: modules in dependency-first order
/// (a DFS post-order over the require graph, deduplicated).
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct LoadPlan {
    order: Vec<Symbol>,
}

impl LoadPlan {
    /// The module instantiation order (dependencies first).
    pub fn order(&self) -> &[Symbol] {
        &self.order
    }
}

/// The DFS node color (three-color cycle detection).
#[derive(Clone, Copy, PartialEq)]
enum Color {
    White,
    Gray,
    Black,
}

/// One declaration graph: every declared module by interned identity,
/// mapped to its declaration item (the require edges live in the
/// item's nested list, walked recursively), plus the first-seen
/// declaration order (pre-order source reading — deterministic).
struct ModuleGraph<'a> {
    declared: HashMap<Symbol, &'a ModuleItem>,
    declaration_order: Vec<Symbol>,
}

impl<'a> ModuleGraph<'a> {
    /// Collect every declared module (nested included) into the flat
    /// namespace; duplicates are rejected fail-closed. The collection
    /// is a true first-seen pre-order walk (§9.64, MOD-2): a module is
    /// recorded the moment it is encountered in source reading order —
    /// its own name first, then its nested declarations depth-first,
    /// then later siblings. The walk is iterative (an iterator stack,
    /// no recursion): hand-built trees can nest arbitrarily deep, and
    /// the loader never recurses on untrusted shapes.
    fn declare(items: &'a [ModuleItem]) -> Result<Self, ModuleError> {
        let mut declared: HashMap<Symbol, &'a ModuleItem> = HashMap::new();
        let mut declaration_order: Vec<Symbol> = Vec::new();
        let mut stack: Vec<std::slice::Iter<'a, ModuleItem>> = vec![items.iter()];
        while let Some(iter) = stack.last_mut() {
            let Some(item) = iter.next() else {
                stack.pop();
                continue;
            };
            if let ModuleItem::Module { span, name, items } = item {
                let key = name.clone();
                if declared.contains_key(&key) {
                    return Err(ModuleError::ModuleDuplicate {
                        name: key,
                        span: *span,
                    });
                }
                declared.insert(key.clone(), item);
                declaration_order.push(key);
                // Descend immediately: pre-order (the nested modules
                // of this declaration are recorded before the next
                // sibling at this level).
                stack.push(items.iter());
            }
        }
        Ok(ModuleGraph {
            declared,
            declaration_order,
        })
    }

    /// Every require edge under one item list (recursive through
    /// nested modules): `(target identity, require span)` pairs.
    /// The walk is an iterative LIFO stack (deterministic; unchanged
    /// since 0.9 — the cycle path and the triggering span it selects
    /// are corpus- and parity-pinned, §9.64.3 MOD-2 scope note).
    fn edges_of(items: &[ModuleItem]) -> Vec<(Symbol, Span)> {
        let mut edges = Vec::new();
        let mut stack: Vec<&[ModuleItem]> = vec![items];
        while let Some(current) = stack.pop() {
            for item in current {
                match item {
                    ModuleItem::Require { span, module } => {
                        edges.push((module.clone(), *span));
                    }
                    ModuleItem::Module { items, .. } => stack.push(items),
                    // Other item kinds contribute no require edges.
                    _ => {}
                }
            }
        }
        edges
    }
}

/// Validate one expanded program's module graph and produce its
/// instantiation plan.
pub fn load_program(items: &[ModuleItem]) -> Result<LoadPlan, ModuleError> {
    let graph = ModuleGraph::declare(items)?;

    let mut colors: HashMap<Symbol, Color> = graph
        .declared
        .keys()
        .map(|name| (name.clone(), Color::White))
        .collect();
    let mut order: Vec<Symbol> = Vec::new();
    let mut in_order: HashSet<Symbol> = HashSet::new();
    let mut stack: Vec<Symbol> = Vec::new();

    // The synthetic root first (top-level requires), then every
    // declared module — unreachable modules are traversed too so every
    // edge is validated.
    for (edge, span) in ModuleGraph::edges_of(items) {
        visit_edge(
            &edge,
            span,
            &graph,
            &mut colors,
            &mut stack,
            &mut order,
            &mut in_order,
        )?;
    }
    // Declaration order (first-seen pre-order) — deterministic
    // traversal.
    for name in &graph.declaration_order {
        if colors.get(name).copied().unwrap_or(Color::White) == Color::White {
            visit_module(
                name,
                &graph,
                &mut colors,
                &mut stack,
                &mut order,
                &mut in_order,
            )?;
        }
    }

    Ok(LoadPlan { order })
}

/// One require edge from a *black or root* context: validate the
/// target exists, then visit it.
fn visit_edge(
    edge: &Symbol,
    span: Span,
    graph: &ModuleGraph,
    colors: &mut HashMap<Symbol, Color>,
    stack: &mut Vec<Symbol>,
    order: &mut Vec<Symbol>,
    in_order: &mut HashSet<Symbol>,
) -> Result<(), ModuleError> {
    if !graph.declared.contains_key(edge) {
        return Err(ModuleError::ModuleNotFound {
            name: edge.clone(),
            span,
        });
    }
    if colors.get(edge).copied().unwrap_or(Color::White) == Color::Gray {
        // The caller is on the current DFS path: a cycle through the
        // synthetic root or an already-gray target.
        let start = stack.iter().position(|n| n == edge).unwrap_or(0);
        let mut path: Vec<Symbol> = stack[start..].to_vec();
        path.push(edge.clone());
        return Err(ModuleError::ModuleCycle { path, span });
    }
    visit_module(edge, graph, colors, stack, order, in_order)
}

/// DFS step for one module: mark gray, walk its edges, mark black,
/// record the post-order position.
fn visit_module(
    name: &Symbol,
    graph: &ModuleGraph,
    colors: &mut HashMap<Symbol, Color>,
    stack: &mut Vec<Symbol>,
    order: &mut Vec<Symbol>,
    in_order: &mut HashSet<Symbol>,
) -> Result<(), ModuleError> {
    match colors.get(name).copied().unwrap_or(Color::White) {
        Color::Black => return Ok(()),
        Color::Gray => {
            // Unreachable through the public entry (the edge loop owns
            // cycle detection and closes gray cycles with the
            // triggering require's span); kept fail-closed for direct
            // reuse, reporting the node's own declaration span.
            let mut path = stack.clone();
            path.push(name.clone());
            let span = graph.declared[name].span();
            return Err(ModuleError::ModuleCycle { path, span });
        }
        Color::White => {}
    }
    colors.insert(name.clone(), Color::Gray);
    stack.push(name.clone());
    // The module's own edges: requires under its declaration
    // (recursive through nested modules).
    let items = match graph.declared[name] {
        ModuleItem::Module { items, .. } => items,
        _ => unreachable!("the declaration map only holds Module items"),
    };
    let edges = ModuleGraph::edges_of(items);
    for (edge, span) in edges {
        visit_edge(&edge, span, graph, colors, stack, order, in_order)?;
    }
    stack.pop();
    colors.insert(name.clone(), Color::Black);
    if in_order.insert(name.clone()) {
        order.push(name.clone());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    //! Unit tests for the module loading layer (sub-stage test doc
    //! FP4; docs/tests/v0/stage0/plan/macro.md).

    use super::*;
    use kerf_core::CoreExpr;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn literal(start: u32, end: u32) -> CoreExpr {
        CoreExpr::Literal {
            span: span(start, end),
            value: kerf_core::LiteralValue::Int(1),
        }
    }

    fn module_item(name: &str, start: u32, end: u32) -> ModuleItem {
        ModuleItem::module(span(start, end), name, vec![]).unwrap()
    }

    fn require_item(name: &str, start: u32, end: u32) -> ModuleItem {
        ModuleItem::require(span(start, end), name).unwrap()
    }

    // ---------- positive ----------

    #[test]
    fn linear_chain_loads_dependencies_first() {
        // (require "b") + module b { (require "c") } + module c {}:
        // order c, b (dependencies first).
        let program = vec![
            require_item("b", 0, 12),
            ModuleItem::module(span(13, 60), "b", vec![require_item("c", 20, 34)]).unwrap(),
            module_item("c", 61, 80),
        ];
        let plan = load_program(&program).expect("a linear chain must load");
        let names: Vec<&str> = plan.order().iter().map(|s| s.as_str()).collect();
        assert_eq!(names, vec!["c", "b"]);
    }

    #[test]
    fn nested_module_declarations_are_collected() {
        // module outer { module inner {} (define one 1) } — both
        // declared, defines ignored by the loader.
        let program = vec![
            ModuleItem::module(
                span(0, 50),
                "outer",
                vec![
                    module_item("inner", 10, 30),
                    ModuleItem::define(span(31, 49), "one", literal(40, 42)).unwrap(),
                ],
            )
            .unwrap(),
        ];
        let plan = load_program(&program).expect("nested declarations must collect");
        // Declaration order: outer first (no edges → post-order), then
        // inner.
        let names: Vec<&str> = plan.order().iter().map(|s| s.as_str()).collect();
        assert_eq!(names, vec!["outer", "inner"]);
    }

    #[test]
    fn empty_program_loads_to_an_empty_plan() {
        let plan = load_program(&[]).expect("an empty program must load");
        assert!(plan.order().is_empty());
    }

    // ---------- negative ----------

    #[test]
    fn two_module_cycle_is_detected_with_the_path() {
        // a requires b; b requires a.
        let program = vec![
            ModuleItem::module(span(0, 50), "a", vec![require_item("b", 10, 24)]).unwrap(),
            ModuleItem::module(span(51, 100), "b", vec![require_item("a", 60, 74)]).unwrap(),
        ];
        let err = load_program(&program).expect_err("a two-module cycle must be rejected");
        match err {
            ModuleError::ModuleCycle { path, .. } => {
                assert_eq!(
                    path,
                    vec![
                        Symbol::new("a").unwrap(),
                        Symbol::new("b").unwrap(),
                        Symbol::new("a").unwrap()
                    ]
                );
            }
            other => panic!("expected ModuleCycle, got {other:?}"),
        }
    }

    #[test]
    fn three_module_cycle_is_detected() {
        // a -> b -> c -> a.
        let program = vec![
            ModuleItem::module(span(0, 40), "a", vec![require_item("b", 10, 24)]).unwrap(),
            ModuleItem::module(span(41, 80), "b", vec![require_item("c", 50, 64)]).unwrap(),
            ModuleItem::module(span(81, 120), "c", vec![require_item("a", 90, 104)]).unwrap(),
        ];
        let err = load_program(&program).expect_err("a three-module cycle must be rejected");
        match err {
            ModuleError::ModuleCycle { path, .. } => {
                assert_eq!(
                    path,
                    vec![
                        Symbol::new("a").unwrap(),
                        Symbol::new("b").unwrap(),
                        Symbol::new("c").unwrap(),
                        Symbol::new("a").unwrap()
                    ]
                );
            }
            other => panic!("expected ModuleCycle, got {other:?}"),
        }
    }

    #[test]
    fn self_require_is_a_cycle() {
        let program =
            vec![ModuleItem::module(span(0, 30), "a", vec![require_item("a", 10, 24)]).unwrap()];
        let err = load_program(&program).expect_err("a self-require must be rejected");
        match err {
            ModuleError::ModuleCycle { path, .. } => {
                assert_eq!(
                    path,
                    vec![Symbol::new("a").unwrap(), Symbol::new("a").unwrap()]
                );
            }
            other => panic!("expected ModuleCycle, got {other:?}"),
        }
    }

    // ---------- MOD-2: the collection order (§9.64) ----------

    #[test]
    fn declaration_order_is_source_reading_order_across_levels() {
        // (module a { (module a1 {}) }) (module b { (module b1 {}) })
        // — a1 is declared before b *and* before b1 in the source.
        // The 0.9-collection LIFO walk recorded b1 before a1
        // (cross-level reversal); the first-seen pre-order walk
        // (§9.64 MOD-2) records source reading order exactly.
        let program = vec![
            ModuleItem::module(span(0, 30), "a", vec![module_item("a1", 10, 20)]).unwrap(),
            ModuleItem::module(span(31, 60), "b", vec![module_item("b1", 41, 51)]).unwrap(),
        ];
        let plan = load_program(&program).expect("unreachable modules must load");
        // No requires: the plan tail is the declaration order itself.
        let names: Vec<&str> = plan.order().iter().map(|s| s.as_str()).collect();
        assert_eq!(names, vec!["a", "a1", "b", "b1"]);
    }

    #[test]
    fn undeclared_module_is_not_found() {
        let program = vec![require_item("ghost", 0, 16)];
        let err = load_program(&program).expect_err("an undeclared require must be rejected");
        // MOD-1 (§9.64): the payload is the interned identity — an
        // independently constructed `Symbol::new("ghost")` equals the
        // loader's key (the layer keys on the single pool, never on
        // de-interned text).
        assert_eq!(
            err,
            ModuleError::ModuleNotFound {
                name: Symbol::new("ghost").unwrap(),
                span: span(0, 16)
            }
        );
    }

    #[test]
    fn duplicate_module_names_are_rejected() {
        let program = vec![module_item("a", 0, 20), module_item("a", 21, 41)];
        let err = load_program(&program).expect_err("duplicate declarations must be rejected");
        assert_eq!(
            err,
            ModuleError::ModuleDuplicate {
                name: Symbol::new("a").unwrap(),
                span: span(21, 41)
            }
        );
    }
}

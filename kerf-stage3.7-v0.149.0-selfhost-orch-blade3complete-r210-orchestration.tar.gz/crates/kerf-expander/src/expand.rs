//! The expansion loop: syntax objects → core expressions
//! (docs/stage0.md §19.2).
//!
//! Two public entries:
//! - [`expand`] — one expression with an explicit environment (the
//!   REPL/driver composition point, plan sub-stage 0.8).
//! - [`expand_program`] — a whole top-level form sequence → module
//!   items (declaration forms only; the top-level expression channel
//!   is the `define` calling form — r110 corpus note).
//!
//! Hygiene skeleton (0.4 slice): every binding construct allocates a
//! fresh scope, colors its subtree on descent (`with_scope_added`),
//! and resolution is scope-set keyed; macro transformers, the
//! def-site ∪ use-site union and the expansion cache are the 0.9 macro
//! system (docs/stage0.md §8.10 skeleton boundary). Span discipline:
//! desugared nodes reuse source spans of the same expansion
//! generation — cross-generation joins never occur here (the TD-002
//! adjudication, plan-0.4.md §4).

use std::collections::HashSet;

use kerf_core::{
    Binding, CoreExpr, ExternAbi, ExternItem, ExternType, HandlerClause, LiteralValue, ModuleItem,
};
use kerf_span::{Span, Symbol};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};

use crate::ctx::{EXPANSION_LIMIT, ExpandCtx, Resolution};
use crate::error::ExpandError;
use crate::stage0_global_symbols;
use crate::transformer::SyntaxRules;

/// Expand one expression with the environment `ctx`.
///
/// Every nested level consumes one unit of the work budget
/// ([`EXPANSION_LIMIT`](crate::EXPANSION_LIMIT)); the phase closure
/// rule (runtime-phase code only — docs/stage0.md §8.9 rule 1) is
/// enforced on every node touched, structural reads included.
pub fn expand(ctx: &mut ExpandCtx, stx: &SyntaxObject) -> Result<CoreExpr, ExpandError> {
    ctx.enter(stx.span)?;
    let result = expand_node(ctx, stx);
    ctx.exit();
    result
}

/// Expand a whole program: top-level forms → module items.
///
/// The module top level accepts declarations only (`define` /
/// `require` / `module`); a bare expression is
/// [`ExpandError::TopLevelExpression`]. Defines bind sequentially and
/// support self-reference (the letrec-shaped top-level rule that
/// makes recursive functions like `fib` expandable); nested modules
/// are scope-isolated from outer defines.
pub fn expand_program(forms: &[SyntaxObject]) -> Result<Vec<ModuleItem>, ExpandError> {
    expand_program_core(forms, &[], EXPANSION_LIMIT)
}

/// The struct accessor name join (blade 2 GZ-2): `Name-field`. The
/// single source for BOTH the desugaring below and the parity
/// harness's injection table — the frozen subset cannot build the
/// string itself (no string-concatenation primitive in the 18), so
/// the harness pre-computes every (struct, field) pair the input
/// declares THROUGH THIS FUNCTION and injects the table ahead of
/// the twin (the TP-1/RS-1 injection-channel lineage; parity itself
/// is the drift guard — the twin emits the table's name, the
/// oracle emits its own, a divergence fails the comparison).
pub fn struct_accessor_name(struct_name: &str, field: &str) -> String {
    format!("{struct_name}-{field}")
}

/// The enum constructor's global name (blade 3 GZ-4): the
/// `Enum-Variant` join, the struct accessor's own face at the
/// constructor layer (the single text source both arms share —
/// the twin consumes the SAME join through the injected table, so
/// the parity drifts into a table-miss fail-closed face, never
/// into a silent divergence).
pub fn enum_ctor_name(enum_name: &str, variant: &str) -> String {
    format!("{enum_name}-{variant}")
}

/// The enum constructor's param names (blade 3 GZ-4): `a0..aN`
/// over the payload positions — generated names the twin consumes
/// through the injected table (the r166-b2 twin expressibility
/// ruling's own face: the frozen subset has no string building, so
/// every synthesized name that is not a source text must ride an
/// injection; the struct's ctor params ARE the field names, the
/// enum's payload specs carry none, so these are the first
/// synthesized params in the tree).
pub fn enum_ctor_param_name(position: usize) -> String {
    format!("a{position}")
}

/// [`expand_program`] with an explicit work-budget cap (the K162
/// configurable-guardrail face of the W-REC-DEPTH blade 2: the
/// default cap stays `512` — [`EXPANSION_LIMIT`] — while deep
/// synthesized trees may ride a raised limit).
pub fn expand_program_with_limit(
    forms: &[SyntaxObject],
    limit: usize,
) -> Result<Vec<ModuleItem>, ExpandError> {
    expand_program_core(forms, &[], limit)
}

/// Expand a whole program with host-injected global names (the
/// W-3.12 injection channel's expansion face): every injected name
/// resolves as a global from any scope — the host commits to
/// binding the slot before the run (the engines' `inject_global`
/// faces, `kerf_vm` and `kerf_runtime`), and a forgotten bind still
/// meets the run-time `UnboundGlobal` fail-closed face. The
/// acceptance set is an API parameter (a host declaration), never a
/// language-surface change: [`expand_program`] is this entry with
/// an empty set.
pub fn expand_program_with_injected(
    forms: &[SyntaxObject],
    injected: &[Symbol],
) -> Result<Vec<ModuleItem>, ExpandError> {
    expand_program_core(forms, injected, EXPANSION_LIMIT)
}

/// [`expand_program_with_injected`] with an explicit work-budget
/// cap (the injected face of the K162 configurable guardrail — the
/// steady-state chains keep the conservative default; deep
/// synthesized sources may ride a raised one).
pub fn expand_program_with_injected_and_limit(
    forms: &[SyntaxObject],
    injected: &[Symbol],
    limit: usize,
) -> Result<Vec<ModuleItem>, ExpandError> {
    expand_program_core(forms, injected, limit)
}

/// The parameterized core every public entry delegates to: one
/// context, optional injected names, an explicit budget.
fn expand_program_core(
    forms: &[SyntaxObject],
    injected: &[Symbol],
    limit: usize,
) -> Result<Vec<ModuleItem>, ExpandError> {
    let mut ctx = ExpandCtx::with_limit(limit);
    if !injected.is_empty() {
        ctx.seed_injected_names(injected.iter().cloned());
    }
    expand_declarations(&mut ctx, forms)
}

// ---------- shared helpers ----------

/// The phase-closure check applied to every structurally consumed
/// node (docs/stage0.md §8.9 rule 1 — the 0.4 slice: runtime
/// expansion accepts runtime-phase syntax only; transformer execution
/// arrives with the 0.9 macro system).
fn require_runtime(stx: &SyntaxObject) -> Result<(), ExpandError> {
    if stx.phase != Phase::Runtime {
        return Err(ExpandError::PhaseViolation {
            phase: stx.phase,
            span: stx.span,
        });
    }
    Ok(())
}

/// The identifier text of a symbol atom (shape check only — callers
/// phase-check the node first).
fn symbol_text(stx: &SyntaxObject) -> Option<&str> {
    match &stx.datum {
        StxDatum::Symbol(sym) => Some(sym.as_str()),
        _ => None,
    }
}

/// The interned identity of a well-formed symbol atom (§9.65 EXP-1:
/// error payloads reference the single-pool entry the syntax tree
/// already carries — never a de-interned text copy).
fn symbol_sym(stx: &SyntaxObject) -> Option<&Symbol> {
    match &stx.datum {
        StxDatum::Symbol(sym) => Some(sym),
        _ => None,
    }
}

/// The interned identities of a well-formed parameter list: a
/// (possibly empty) list of symbol atoms (§9.66 TRF-8: the frame
/// binds the entries the tree carries, never their texts).
fn symbol_syms(node: &SyntaxObject) -> Option<Vec<&Symbol>> {
    node.symbol_syms()
}

fn malformed(form: &'static str, span: Span) -> ExpandError {
    ExpandError::MalformedForm { form, span }
}

fn core_err(source: kerf_core::CoreError, span: Span) -> ExpandError {
    ExpandError::Core { source, span }
}

// ---------- expression expansion ----------

fn expand_node(ctx: &mut ExpandCtx, stx: &SyntaxObject) -> Result<CoreExpr, ExpandError> {
    require_runtime(stx)?;
    match &stx.datum {
        StxDatum::Int(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Int(*v),
        }),
        StxDatum::Float(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Float(*v),
        }),
        StxDatum::Bool(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Bool(*v),
        }),
        StxDatum::String(s) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::String(s.clone()),
        }),
        StxDatum::Symbol(sym) => expand_symbol(ctx, sym, stx),
        StxDatum::List(items) => expand_list(ctx, items, stx.span),
    }
}

fn expand_symbol(
    ctx: &mut ExpandCtx,
    sym: &Symbol,
    stx: &SyntaxObject,
) -> Result<CoreExpr, ExpandError> {
    let text = sym.as_str();
    // `nil` is the reserved literal keyword (the empty-list datum in
    // the core — plan-0.3 decision 3 carries the surface spelling).
    if text == "nil" {
        return Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Nil,
        });
    }
    // §9.66 TRF-8: the pool entry the tree carries goes straight into
    // the frame table (never de-interned for the lookup); the single
    // text crossing left is the core constructor boundary below.
    match ctx.resolve(sym, &stx.scopes) {
        Resolution::Local | Resolution::Global => {
            CoreExpr::var(stx.span, text).map_err(|source| core_err(source, stx.span))
        }
        Resolution::Unbound => Err(ExpandError::UnboundIdentifier {
            name: sym.clone(),
            span: stx.span,
        }),
    }
}

fn expand_list(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // Empty application, synthesized face: the reader rejects `()` in
    // source (plan-0.3 decision 3); this is the second fail-closed
    // layer for hand-built and (at 0.9) macro-produced trees.
    if items.is_empty() {
        return Err(ExpandError::EmptyForm { span });
    }
    require_runtime(&items[0])?;
    if let Some(head) = symbol_sym(&items[0]) {
        // Flat head-keyword dispatch (the 0.4 simplification — the
        // scoped-keyword mechanism is the 0.9 upgrade path). The
        // declaration forms (`define`/`require`/`module`/
        // `define-syntax`) are NOT expression forms: in operand
        // position they expand as applications of unbound identifiers
        // (fail-closed).
        match head.as_str() {
            "fn" => return expand_fn(ctx, items, span),
            // The blade 1 GZ-1 annotated closure: desugar + the dann
            // site records (the plain `fn` product is byte-identical).
            "fn-ann" => return expand_fn_ann(ctx, items, span),
            "if" => return expand_if(ctx, items, span),
            "let" => return expand_let(ctx, items, span),
            "do" => return expand_do(ctx, items, span),
            "set!" => return expand_set(ctx, items, span),
            "perform" => return expand_perform(ctx, items, span),
            "handle" => return expand_handle(ctx, items, span),
            "quote" => return expand_quote(items, span),
            "match" => return expand_match(ctx, items, span),
            // Any other head is not a core form — fall through to the
            // macro dispatch below (macros may shadow plain names).
            _ => {}
        }
        // Macro use (sub-stage 0.9): the head resolves through the
        // same scope-keyed judgment as identifiers — core forms win
        // first (flat dispatch order), macros shadow plain
        // applications (docs/stage0.md §19.2 expansion loop, the
        // macro branch). §9.66 TRF-8: the head's pool entry feeds the
        // macro table directly.
        if let Some(id) = ctx.resolve_macro(head, &items[0].scopes) {
            return expand_macro_use(ctx, id, items);
        }
    }
    expand_application(ctx, items, span)
}

/// One macro use: instantiate the winning clause and re-expand the
/// product to a fixpoint (core forms or further macro uses —
/// docs/stage0.md §19.2: a macro may expand into a macro use, until
/// a core form). Every level consumes expansion work budget, so a
/// self-recursive macro fails with a structured depth error.
fn expand_macro_use(
    ctx: &mut ExpandCtx,
    id: usize,
    items: &[SyntaxObject],
) -> Result<CoreExpr, ExpandError> {
    // The use form's generation: introduced nodes carry generation+1
    // (docs/stage0.md §8.6 / the dea12b tracing contract).
    let use_gen = items[0].span.expansion_id;
    let product = ctx.transformer(id).instantiate(items, use_gen)?;
    expand(ctx, &product)
}

/// `(quote datum)` — the datum as a literal value (sub-stage 0.9; the
/// 0.1 `LiteralValue::Pair` consumption face — plan-0.7 decision 13).
/// Atoms and proper lists fold into the pair chain ending in `Nil`;
/// symbols (and lists containing them) are outside the Stage 0 value
/// model and fail closed.
fn expand_quote(items: &[SyntaxObject], span: Span) -> Result<CoreExpr, ExpandError> {
    // (quote datum) — exactly one datum.
    if items.len() != 2 {
        return Err(malformed("quote", span));
    }
    require_runtime(&items[1])?;
    let value = datum_to_literal(&items[1])?;
    Ok(CoreExpr::Literal { span, value })
}

/// The datum → literal fold: atoms map directly, lists right-fold
/// into `Pair` chains terminated by `Nil` (the proper-list datum
/// shape). Symbol data (except the reserved `nil`) has no Stage 0
/// carrier — the fail-closed boundary.
fn datum_to_literal(node: &SyntaxObject) -> Result<LiteralValue, ExpandError> {
    match &node.datum {
        StxDatum::Int(v) => Ok(LiteralValue::Int(*v)),
        StxDatum::Float(v) => Ok(LiteralValue::Float(*v)),
        StxDatum::Bool(v) => Ok(LiteralValue::Bool(*v)),
        StxDatum::String(v) => Ok(LiteralValue::String(v.clone())),
        StxDatum::Symbol(sym) if sym.as_str() == "nil" => Ok(LiteralValue::Nil),
        StxDatum::Symbol(_) => Err(ExpandError::QuoteUnsupportedDatum { span: node.span }),
        StxDatum::List(list) => {
            let mut acc = LiteralValue::Nil;
            for item in list.iter().rev() {
                acc = LiteralValue::Pair(Box::new(datum_to_literal(item)?), Box::new(acc));
            }
            Ok(acc)
        }
    }
}

fn expand_fn(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (fn (params...) body) — exactly one body form at 0.4
    // (sequencing is the `do` form).
    if items.len() != 3 {
        return Err(malformed("fn", span));
    }
    require_runtime(&items[1])?;
    let params = symbol_syms(&items[1]).ok_or_else(|| malformed("fn", span))?;
    require_runtime(&items[2])?;
    expand_fn_binding(ctx, &params, &items[2], span, &items[0].scopes)
}

/// The shared `Fn` assembly: fresh scope → bind params → color body →
/// expand → validated constructor (duplicate parameters are
/// re-asserted by `CoreExpr::fn_` — the 0.1 constructor contract).
/// `base` is the binding form's own scope set — the frame's binder
/// scopes are `base ∪ {fresh}` (the 0.9 subset-resolution rule).
/// Params are the pool entries the tree carries (§9.66 TRF-8: the
/// frame binds by entry; the core constructor crossing de-interns
/// each entry exactly once — the K110 text boundary).
fn expand_fn_binding(
    ctx: &mut ExpandCtx,
    params: &[&Symbol],
    body_node: &SyntaxObject,
    fn_span: Span,
    base: &ScopeSet,
) -> Result<CoreExpr, ExpandError> {
    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, base);
    let result = (|| {
        for param in params {
            ctx.bind(param);
        }
        let colored_body = body_node.with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        let param_texts: Vec<&str> = params.iter().map(|sym| sym.as_str()).collect();
        CoreExpr::fn_(fn_span, &param_texts, body).map_err(|source| core_err(source, fn_span))
    })();
    ctx.pop_frame();
    result
}

/// The blade 1 GZ-1 spec converter: the read layer's spec tree (a
/// plain `StxDatum` tree — symbols, lists, literals) to the value
/// tree the dann record carries (symbols ride as strings, lists ride
/// the pair algebra — the same data universe the reader's quote face
/// produces; zero new kernel types).
fn spec_value(stx: &SyntaxObject) -> LiteralValue {
    match &stx.datum {
        StxDatum::Symbol(sym) => LiteralValue::String(std::rc::Rc::from(sym.as_str())),
        StxDatum::Int(v) => LiteralValue::Int(*v),
        StxDatum::Float(v) => LiteralValue::Float(*v),
        StxDatum::Bool(v) => LiteralValue::Bool(*v),
        StxDatum::String(v) => LiteralValue::String(std::rc::Rc::clone(v)),
        StxDatum::List(items) => {
            // Right-fold the pair chain over Nil (the proper-list
            // algebra — the record encoders' convention).
            let mut out = LiteralValue::Nil;
            for item in items.iter().rev() {
                out = LiteralValue::Pair(Box::new(spec_value(item)), Box::new(out));
            }
            out
        }
    }
}

/// Whether a ret slot is the reader's ABSENT marker (blade 1 GZ-1):
/// the `nil` symbol at a point span (`start == end`). A real path
/// spec never has an empty extent (a token spans at least one byte),
/// so the point-span nil is unambiguous — the `nil_form` convention
/// ("the span is the construct the unit stands for").
fn is_absent_ret(ret: &SyntaxObject) -> bool {
    ret.span.start == ret.span.end
        && matches!(&ret.datum, StxDatum::Symbol(sym) if sym.as_str() == "nil")
}

/// Push one dann site record (the site collection accumulator — the
/// declaration walk drains it right after the annotated item).
fn push_annotation(
    ctx: &mut ExpandCtx,
    span: Span,
    anchor: Span,
    kind: kerf_core::AnnotationKind,
    index: u32,
    spec: &SyntaxObject,
) {
    ctx.annotations.push(kerf_core::ModuleItem::Annotate {
        span,
        anchor,
        kind,
        index,
        spec: spec_value(spec),
    });
}

/// The annotated param strip: a bare param stays the name symbol; an
/// annotated `(name spec)` pair contributes the name AND one dann
/// site record (anchor = the fn node's own span, index = the param
/// position — `expand_fn_binding` gives the Fn that exact span, so
/// the inference walk finds the site again).
fn annotated_params<'a>(
    ctx: &mut ExpandCtx,
    params: &'a [SyntaxObject],
    anchor: Span,
) -> Result<Vec<&'a Symbol>, ExpandError> {
    let mut out = Vec::with_capacity(params.len());
    for (index, param) in params.iter().enumerate() {
        require_runtime(param)?;
        match &param.datum {
            StxDatum::Symbol(sym) => out.push(sym),
            StxDatum::List(pair) if pair.len() == 2 => {
                require_runtime(&pair[0])?;
                require_runtime(&pair[1])?;
                let name = symbol_sym(&pair[0]).ok_or_else(|| malformed("define-ann", anchor))?;
                push_annotation(
                    ctx,
                    pair[1].span,
                    anchor,
                    kerf_core::AnnotationKind::Param,
                    index as u32,
                    &pair[1],
                );
                out.push(name);
            }
            _ => return Err(malformed("define-ann", anchor)),
        }
    }
    Ok(out)
}

/// `(define-ann (name (p spec)... | p...) ret-or-nil body)` — the
/// blade 1 GZ-1 annotated declaration (the read layer's carrier).
/// Desugars to the plain `define` product BYTE-FOR-BYTE (the param
/// specs strip, the body expands through the shared
/// `expand_fn_binding` with the name's own span — the exact span the
/// unannotated face produces), and each anchored site emits one
/// zero-code dann record: the ret spec (unless the reader's
/// point-span `nil` marker) and every param spec.
fn expand_define_ann(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    // (define-ann header ret body) — exactly four items.
    if items.len() != 4 {
        return Err(malformed("define-ann", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    require_runtime(&items[3])?;
    let header = match &items[1].datum {
        StxDatum::List(header) if !header.is_empty() => header,
        _ => return Err(malformed("define-ann", span)),
    };
    require_runtime(&header[0])?;
    let name = symbol_sym(&header[0]).ok_or_else(|| malformed("define-ann", span))?;
    reject_struct_name(ctx, name, span)?;
    reject_enum_name(ctx, name, span)?;
    // The anchor: the fn node's own span — the define sugar's Fn
    // carries the NAME's span (`expand_fn_binding`), so the dann
    // sites point there.
    let anchor = header[0].span;
    let params = annotated_params(ctx, &header[1..], anchor)?;
    // The ret slot: the spec, or the reader's absent marker (no dann
    // for the marker — an absent annotation never constrains).
    if !is_absent_ret(&items[2]) {
        require_runtime(&items[2])?;
        push_annotation(
            ctx,
            items[2].span,
            anchor,
            kerf_core::AnnotationKind::Ret,
            0,
            &items[2],
        );
    }
    // The plain product: (define (name params...) body) — assembled
    // through the shared binding path so the Fn span, the frames and
    // the coloring are the unannotated face's own.
    ctx.bind(name);
    let value = expand_fn_binding(ctx, &params, &items[3], anchor, &items[0].scopes)?;
    ModuleItem::define(span, name.as_str(), value).map_err(|source| core_err(source, span))
}

/// `(fn-ann (params) ret-or-nil body)` — the blade 1 GZ-1 annotated
/// closure (the expression face). The desugar mirrors
/// `expand_define_ann`: the params strip, the ret spec (unless the
/// point-span marker) and every param spec emit their dann sites
/// (anchor = the WHOLE form's span — exactly what the plain `fn`
/// face gives its Fn node through `expand_node`'s `stx.span`), and
/// the product is the plain `fn` expansion byte-for-byte.
fn expand_fn_ann(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (fn-ann (params) ret body) — exactly four items. The dann
    // emission order is the source order (params first, then the
    // ret slot — the define-ann arm's own order; the twin mirrors
    // both).
    if items.len() != 4 {
        return Err(malformed("fn-ann", span));
    }
    require_runtime(&items[1])?;
    let inner = match &items[1].datum {
        StxDatum::List(inner) => inner,
        _ => return Err(malformed("fn-ann", span)),
    };
    let params = annotated_params(ctx, inner, span)?;
    if !is_absent_ret(&items[2]) {
        require_runtime(&items[2])?;
        push_annotation(
            ctx,
            items[2].span,
            span,
            kerf_core::AnnotationKind::Ret,
            0,
            &items[2],
        );
    }
    require_runtime(&items[3])?;
    expand_fn_binding(ctx, &params, &items[3], span, &items[0].scopes)
}

fn expand_if(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (if cond then else) — both branches mandatory.
    if items.len() != 4 {
        return Err(malformed("if", span));
    }
    for operand in &items[1..] {
        require_runtime(operand)?;
    }
    let cond = expand(ctx, &items[1])?;
    let then_branch = expand(ctx, &items[2])?;
    let else_branch = expand(ctx, &items[3])?;
    Ok(CoreExpr::If {
        span,
        cond: Box::new(cond),
        then_branch: Box::new(then_branch),
        else_branch: Box::new(else_branch),
    })
}

fn expand_let(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (let spec body) with spec = () | (name value) | ((name value)...)
    if items.len() != 3 {
        return Err(malformed("let", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let spec = match &items[1].datum {
        StxDatum::List(spec) => spec,
        _ => return Err(malformed("let", span)),
    };

    // One binding pair: (name atom, value node) with the binding-site
    // span of the name. Pairs carry the name's pool entry (§9.66
    // TRF-8). A blade 1 GZ-1 TRIPLE — (name spec value) — strips to
    // the plain pair and emits one dann site record (the anchor is
    // the VALUE node's extent: exactly `Binding::span` below, so the
    // inference walk finds the site again).
    let mut pairs: Vec<(&Symbol, &SyntaxObject)> = Vec::with_capacity(spec.len());
    if spec.is_empty() {
        // (let () body) — zero bindings.
    } else if matches!(spec[0].datum, StxDatum::List(_)) {
        // Multi-binding spec: every item must be (name value) or the
        // blade 1 triple (name spec value).
        for pair in spec {
            require_runtime(pair)?;
            let pair_items = match &pair.datum {
                StxDatum::List(pair_items) if pair_items.len() == 2 || pair_items.len() == 3 => {
                    pair_items
                }
                _ => return Err(malformed("let", span)),
            };
            require_runtime(&pair_items[0])?;
            let name = symbol_sym(&pair_items[0]).ok_or_else(|| malformed("let", span))?;
            if pair_items.len() == 3 {
                // The annotated binding: the spec site record rides
                // the accumulator (anchored at the value node).
                require_runtime(&pair_items[1])?;
                require_runtime(&pair_items[2])?;
                push_annotation(
                    ctx,
                    pair_items[1].span,
                    pair_items[2].span,
                    kerf_core::AnnotationKind::Let,
                    0,
                    &pair_items[1],
                );
                pairs.push((name, &pair_items[2]));
            } else {
                pairs.push((name, &pair_items[1]));
            }
        }
    } else {
        // Single-binding spec: spec itself is (name value) or the
        // blade 1 triple (name spec value).
        if spec.len() != 2 && spec.len() != 3 {
            return Err(malformed("let", span));
        }
        require_runtime(&spec[0])?;
        let name = symbol_sym(&spec[0]).ok_or_else(|| malformed("let", span))?;
        if spec.len() == 3 {
            require_runtime(&spec[1])?;
            require_runtime(&spec[2])?;
            push_annotation(
                ctx,
                spec[1].span,
                spec[2].span,
                kerf_core::AnnotationKind::Let,
                0,
                &spec[1],
            );
            pairs.push((name, &spec[2]));
        } else {
            pairs.push((name, &spec[1]));
        }
    }

    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, &items[0].scopes);
    let result = (|| {
        // let* order: each value is expanded before its name is bound,
        // so later values see earlier names and never the reverse.
        let mut bindings = Vec::with_capacity(pairs.len());
        for (name, value_node) in pairs {
            require_runtime(value_node)?;
            let colored_value = value_node.with_scope_added(scope);
            let value = expand(ctx, &colored_value)?;
            bindings.push(
                Binding::new(value_node.span, name.as_str(), value)
                    .map_err(|source| core_err(source, value_node.span))?,
            );
            ctx.bind(name);
        }
        let colored_body = items[2].with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        Ok(CoreExpr::Let {
            span,
            bindings,
            body: Box::new(body),
        })
    })();
    ctx.pop_frame();
    result
}

fn expand_do(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (do e1 ... en) — the Begin surface desugaring to a Let chain
    // (docs/stage0.md §6.12.6: Begin -> Let chain). Intermediate values
    // bind to the conventional discard name `_`; the last form is the
    // body. (do e) is the identity (Begin of one expression).
    if items.len() < 2 {
        return Err(malformed("do", span));
    }
    if items.len() == 2 {
        require_runtime(&items[1])?;
        return expand(ctx, &items[1]);
    }
    for node in &items[1..] {
        require_runtime(node)?;
    }
    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, &items[0].scopes);
    let result = (|| {
        // The conventional discard name: interned once here (a pool
        // hit after the first `do` — §9.66 TRF-8), then bound by
        // entry like every other name.
        let discard = Symbol::new("_").expect("the discard name is a valid symbol");
        let mut bindings = Vec::with_capacity(items.len() - 2);
        for step in &items[1..items.len() - 1] {
            let colored_step = step.with_scope_added(scope);
            let value = expand(ctx, &colored_step)?;
            bindings.push(
                Binding::new(step.span, discard.as_str(), value)
                    .map_err(|source| core_err(source, step.span))?,
            );
            ctx.bind(&discard);
        }
        let body_node = items.last().expect("do form has at least 3 items");
        let colored_body = body_node.with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        Ok(CoreExpr::Let {
            span,
            bindings,
            body: Box::new(body),
        })
    })();
    ctx.pop_frame();
    result
}

fn expand_set(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (set! name value) — the historical surface spelling of Assign
    // (docs/stage0.md §6.12.6 mapping). The target must resolve
    // (Scheme semantics: assigning an unbound variable is an error).
    if items.len() != 3 {
        return Err(malformed("set!", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let sym = symbol_sym(&items[1]).ok_or_else(|| malformed("set!", span))?;
    // §9.66 TRF-8: the pool entry feeds the frame table directly.
    match ctx.resolve(sym, &items[1].scopes) {
        Resolution::Local | Resolution::Global => {
            let value = expand(ctx, &items[2])?;
            CoreExpr::assign(span, sym.as_str(), value).map_err(|source| core_err(source, span))
        }
        Resolution::Unbound => Err(ExpandError::UnboundIdentifier {
            name: sym.clone(),
            span: items[1].span,
        }),
    }
}

fn expand_perform(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (perform effect args...) — the effect name is a symbol atom.
    if items.len() < 2 {
        return Err(malformed("perform", span));
    }
    require_runtime(&items[1])?;
    let effect = symbol_text(&items[1]).ok_or_else(|| malformed("perform", span))?;
    let mut args = Vec::with_capacity(items.len() - 2);
    for arg in &items[2..] {
        require_runtime(arg)?;
        args.push(expand(ctx, arg)?);
    }
    CoreExpr::perform(span, effect, args).map_err(|source| core_err(source, span))
}

fn expand_handle(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (handle body (effect handler)...) — handlers are closures over
    // the current scope; duplicate effects are re-asserted by
    // `CoreExpr::handle` (deterministic: left to right).
    if items.len() < 2 {
        return Err(malformed("handle", span));
    }
    require_runtime(&items[1])?;
    let body = expand(ctx, &items[1])?;
    let mut handlers = Vec::with_capacity(items.len() - 2);
    for clause in &items[2..] {
        require_runtime(clause)?;
        let pair = match &clause.datum {
            StxDatum::List(pair) if pair.len() == 2 => pair,
            _ => return Err(malformed("handle", span)),
        };
        require_runtime(&pair[0])?;
        require_runtime(&pair[1])?;
        let effect = symbol_text(&pair[0]).ok_or_else(|| malformed("handle", span))?;
        let handler = expand(ctx, &pair[1])?;
        handlers.push(
            HandlerClause::new(clause.span, effect, handler)
                .map_err(|source| core_err(source, clause.span))?,
        );
    }
    CoreExpr::handle(span, body, handlers).map_err(|source| core_err(source, span))
}

// ---------- match (the classification sugar, switch-window step 2) ----------

/// The scrutinee carrier name. The leading `(` makes it unwritable on
/// both source faces — the S-expr reader terminates an atom run at
/// `(` (the standard Lisp delimiter set) and the target skin's
/// identifier domain is ASCII `[A-Za-z0-9_]` — while `Symbol::new`
/// accepts it (no whitespace, no control characters): the desugared
/// `let` binds a name outside the writable surface, so user code can
/// never capture it (switch-window-plan §5.2 — the identity principle
/// keeps the product equal to a hand-written chain over the same
/// carrier; nested matches stay lexically separated because each
/// carrier's `let` scope starts inside the enclosing arm body).
const MATCH_SCRUTINEE: &str = "match(scrut";

/// One compiled pattern: the test chain (a pure expression over the
/// subject — nested `if`s with `true`/`false` leaves, the `&&`
/// desugaring shape) and the bindings to install when the test
/// passes. The subject expressions are cloned into both faces; every
/// operation involved (`car`, `cdr`, `pair?`, `nil?`, `=`, `eq?`) is
/// pure, so re-evaluation is behavior-identical — and the hand-written
/// equivalent chain makes the same copies, which is what the parity
/// projection compares against (switch-window-plan §5.2).
struct PatternArm {
    test: CoreExpr,
    binds: Vec<(Symbol, CoreExpr, Span)>,
}

/// `(match scrutinee (pattern body)+)` — the classification sugar
/// (docs/stage0.md §9.26.8: match desugars to an If chain; here the
/// "macro layer" is this expander arm, per kernel-mapping ruling).
///
/// Desugaring (switch-window-plan §5.2, the identity principle — the
/// product is the hand-written equivalent):
///
/// ```text
/// (match e (p1 b1) (p2 b2) (x b3))          ; x irrefutable (last)
///   => (let ((match scrut e))
///        (if <t1> (let <binds1> b1')
///        (if <t2> (let <binds2> b2')
///        (let <binds3> b3'))))              ; last arm: no test node
/// ```
///
/// Exhaustiveness (ruling A′): the last arm's pattern must be
/// irrefutable — a bare binding or `_` — so the chain always ends in
/// a value. Refutable tails are rejected ([`ExpandError::
/// NonExhaustiveMatch`]) rather than falling off with no result.
fn expand_match(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (match scrutinee arm...) — at least one arm.
    if items.len() < 3 {
        return Err(malformed("match", span));
    }
    for node in &items[1..] {
        require_runtime(node)?;
    }

    // Each arm: a two-element list `(pattern body)`.
    let mut arms: Vec<(&SyntaxObject, &SyntaxObject)> = Vec::with_capacity(items.len() - 2);
    for arm in &items[2..] {
        let pair = match &arm.datum {
            StxDatum::List(pair) if pair.len() == 2 => pair,
            _ => return Err(malformed("match", span)),
        };
        arms.push((&pair[0], &pair[1]));
    }

    // Exhaustiveness, the ruling A′ + the blade 3 extension (§10.1):
    // the last arm passes under EITHER of two conditions —
    // ① it is irrefutable (a bare binding or `_` — the pre-blade-3
    // discipline, unchanged for every non-enum match), or
    // ② the arms' variant faces cover SOME enum's full variant set
    // (the completeness pass — the last arm then carries a real tag
    // discrimination in its COMPILED test, and the chain's tail
    // ride is the completeness promise: within the legal-program
    // domain every scrutinee value rides a constructor's right-
    // fold, so the tag is always in the declared set — the tail
    // plain-binding fold stays (else-slot placeholder would join
    // to Dyn under `join(a,b)=a==b?a:Dyn`, LOSSY for the match's
    // type — the transparent-unfold's own ruling shape: keep the
    // fold iff it is lossless).
    let last_pattern = arms.last().expect("match has at least one arm").0;
    // The blade 3 boundary precision (the §10.1 two-way, the r168-b4
    // corpus finding): a bare symbol that NAMES a zero-payload
    // variant is a TAG-ONLY variant pattern — its compiled test
    // discriminates the tag, it is NOT an irrefutable binding. The
    // last-arm irrefutable pass must therefore probe the variant
    // face too: irrefutable now means binding-or-wildcard AND
    // not-a-variant AND not-a-struct (a one-element list is the
    // parenthesized pass-through — `variant_face`/`struct_face`
    // thread it, the probes and the compile partition share one
    // ruling, so this walk and the compiled tests can never
    // disagree).
    let last_is_plain_binding = is_irrefutable(last_pattern)
        && variant_face(ctx, last_pattern).is_none()
        && struct_face(ctx, last_pattern).is_none();
    if !last_is_plain_binding && !enum_exhaustive(ctx, &arms) {
        return Err(ExpandError::NonExhaustiveMatch {
            span: last_pattern.span,
        });
    }

    // The scrutinee evaluates exactly once, into a carrier binding.
    let scrutinee = expand(ctx, &items[1])?;
    let scrut_var = CoreExpr::Var {
        span: items[1].span,
        name: Symbol::new(MATCH_SCRUTINEE).expect("the scrutinee carrier is a valid symbol"),
    };

    // Fold the arms right-to-left: the last arm contributes a plain
    // binding (its test is vacuously true), each earlier arm an
    // `if test (let binds body) next`.
    let mut chain: Option<CoreExpr> = None;
    for (pattern, body) in arms.iter().rev() {
        let compiled = compile_pattern(ctx, pattern, &scrut_var)?;
        let body = expand_arm_body(ctx, &compiled.binds, body)?;
        let arm_node = match &compiled.binds[..] {
            [] => body,
            _ => {
                let bindings = compiled
                    .binds
                    .iter()
                    .map(|(name, value, bind_span)| Binding {
                        span: *bind_span,
                        name: name.clone(),
                        value: value.clone(),
                    })
                    .collect();
                CoreExpr::Let {
                    span: body.span(),
                    bindings,
                    body: Box::new(body),
                }
            }
        };
        chain = Some(match chain {
            None => arm_node,
            Some(next) => CoreExpr::If {
                span,
                cond: Box::new(compiled.test),
                then_branch: Box::new(arm_node),
                else_branch: Box::new(next),
            },
        });
    }

    let chain = chain.expect("match has at least one arm");
    let carrier = Binding {
        span: items[1].span,
        name: Symbol::new(MATCH_SCRUTINEE).expect("the scrutinee carrier is a valid symbol"),
        value: scrutinee,
    };
    Ok(CoreExpr::Let {
        span,
        bindings: vec![carrier],
        body: Box::new(chain),
    })
}

/// Expand one arm body with the pattern bindings in scope. The body
/// subtree is colored with the arm's fresh scope (the `expand_do`
/// discipline: bindings install into a fresh frame, the body sees
/// them through the added scope — which also implements the shadowing
/// semantics, a pattern binding legitimately shadows an outer name of
/// the same text).
fn expand_arm_body(
    ctx: &mut ExpandCtx,
    binds: &[(Symbol, CoreExpr, Span)],
    body: &SyntaxObject,
) -> Result<CoreExpr, ExpandError> {
    if binds.is_empty() {
        return expand(ctx, body);
    }
    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, &body.scopes);
    let result = expand_arm_body_bound(ctx, binds, body, scope);
    ctx.pop_frame();
    result
}

/// The arm body under its pattern-binding frame (split from
/// [`expand_arm_body`] so the frame pops on every path without an
/// immediately-invoked closure — the clippy discipline).
fn expand_arm_body_bound(
    ctx: &mut ExpandCtx,
    binds: &[(Symbol, CoreExpr, Span)],
    body: &SyntaxObject,
    scope: kerf_syntax::ScopeId,
) -> Result<CoreExpr, ExpandError> {
    for (name, _, _) in binds {
        ctx.bind(name);
    }
    let colored = body.with_scope_added(scope);
    expand(ctx, &colored)
}

/// A pattern that cannot fail: a bare binding identifier (any symbol
/// other than `nil`, which is the nil-literal pattern) or `_`.
fn is_irrefutable(pattern: &SyntaxObject) -> bool {
    match &pattern.datum {
        StxDatum::Symbol(sym) => sym.as_str() != "nil",
        _ => false,
    }
}

/// The pattern-face variant probe (§10.3): does this pattern compile
/// as a VARIANT pattern, and if so, which variant? None = not a
/// variant face (the six-pattern families' own — the probe and
/// `compile_pattern`'s partition share one ruling, so the
/// exhaustiveness walk and the test compilation can never disagree).
/// The three partitions, exactly `compile_pattern`'s own:
/// - a bare symbol: hit iff it names a ZERO-payload variant (the
///   tag-only face; a payload-carrying variant written bare is a
///   binding, the §10.3 disambiguation);
/// - a list of n >= 2: hit iff the head symbol names an
///   (n-1)-payload variant (the head carries the variant identity,
///   the remaining n-1 elements are the payload positions);
/// - a one-element list: the pass-through (the probe recurses);
/// - anything else (literals, `nil`, `_`, non-symbol heads): None.
fn variant_face(ctx: &ExpandCtx, pattern: &SyntaxObject) -> Option<Symbol> {
    match &pattern.datum {
        StxDatum::Symbol(sym) => match ctx.variant_row(sym) {
            Some((_, _, 0)) => Some(sym.clone()),
            _ => None,
        },
        StxDatum::List(elements) => match elements.len() {
            0 => None,
            1 => variant_face(ctx, &elements[0]),
            n => {
                // The head must be a symbol naming an (n-1)-payload
                // variant; the payload-count match IS the hit
                // condition (a mismatch degrades to the family's
                // own — binding at 2, the registered rejection at 3+,
                // the §10.3 disambiguation).
                let head = match &elements[0].datum {
                    StxDatum::Symbol(head) => head,
                    _ => return None,
                };
                match ctx.variant_row(head) {
                    Some((_, _, payloads)) if payloads + 1 == n => Some(head.clone()),
                    _ => None,
                }
            }
        },
        _ => None,
    }
}

/// Compile one VARIANT pattern arm (§10.3's test shape over §10.2's
/// representation): `(if (pair? s) (if (= (car s) i) PAYLOAD false)
/// false)` — the shape guard, the tag discrimination, then the
/// payload positions one by one; payload position k reads
/// `car(cdr^{k+1} s)` (the tag rides position 0, so every payload
/// shifts by one — the struct access formula's own family). No
/// extra chain-length guard on the payload positions: within the
/// legal-program domain the constructor's right-fold fixes the
/// length (§10.1's domain) — the Int pattern's identity ruling's
/// own.
fn variant_arm(
    ctx: &ExpandCtx,
    variant: &Symbol,
    payload_patterns: &[&SyntaxObject],
    pattern: &SyntaxObject,
    subject: &CoreExpr,
) -> Result<PatternArm, ExpandError> {
    let span = pattern.span;
    // The lookup row cannot miss here — `variant_face` probed the
    // same table under the same head (fail-closed if it ever did).
    let (parent, tag, _) = ctx
        .variant_row(variant)
        .unwrap_or_else(|| panic!("variant row missing for `{variant}`"));
    let _ = parent;
    // The tag discrimination: `(= (car s) i)`.
    let tag_test = builtin2(
        "=",
        &builtin1("car", subject),
        CoreExpr::Literal {
            span,
            value: LiteralValue::Int(tag as i64),
        },
    );
    // The payload positions: position k = car(cdr^{k+1} s).
    let mut binds: Vec<(Symbol, CoreExpr, Span)> = Vec::new();
    let mut tests: Vec<CoreExpr> = Vec::with_capacity(payload_patterns.len());
    for (k, sub) in payload_patterns.iter().enumerate() {
        // cdr^{k+1}: the tag occupies position 0, so position k sits
        // behind k+1 cdrs, then one car.
        let mut cursor = subject.clone();
        for _ in 0..=k {
            cursor = builtin1("cdr", &cursor);
        }
        let position = builtin1("car", &cursor);
        let compiled = compile_pattern(ctx, sub, &position)?;
        tests.push(compiled.test);
        binds.extend(compiled.binds);
    }
    // The payload tests fold right-to-left over a vacuously-true
    // tail (an empty payload face is the tag test alone).
    let mut payload_test = CoreExpr::Literal {
        span,
        value: LiteralValue::Bool(true),
    };
    for t in tests.into_iter().rev() {
        payload_test = and_chain(t, payload_test, span);
    }
    // `(if (= (car s) i) PAYLOAD false)` inside the shape guard.
    let inner = CoreExpr::If {
        span,
        cond: Box::new(tag_test),
        then_branch: Box::new(payload_test),
        else_branch: Box::new(CoreExpr::Literal {
            span,
            value: LiteralValue::Bool(false),
        }),
    };
    let test = CoreExpr::If {
        span,
        cond: Box::new(builtin1("pair?", subject)),
        then_branch: Box::new(inner),
        else_branch: Box::new(CoreExpr::Literal {
            span,
            value: LiteralValue::Bool(false),
        }),
    };
    Ok(PatternArm { test, binds })
}

/// Compile one STRUCT pattern arm (blade 4 §11.1's test shape over
/// GZ-2's representation): a zero-field struct is `(nil? s)` (an
/// empty right-fold IS nil); n >= 1 fields fold into `(if (pair? s)
/// FIELDS false)` — the shape guard, then the field positions one
/// by one with NO tag discrimination and ZERO shift: field position
/// k reads `car(cdr^k s)` (the struct carries no tag — the variant
/// arm's +1 shift's absence IS the struct/enum representation
/// split). No extra chain-length guard on the field positions: the
/// legal-program domain's own (§11.1 — GZ-3's transparent
/// unification fixes the scrutinee's chain length upstream).
fn struct_arm(
    ctx: &ExpandCtx,
    name: &Symbol,
    payload_patterns: &[&SyntaxObject],
    pattern: &SyntaxObject,
    subject: &CoreExpr,
) -> Result<PatternArm, ExpandError> {
    let _ = name;
    let span = pattern.span;
    // The zero-field face: the empty right-fold is nil.
    if payload_patterns.is_empty() {
        return Ok(PatternArm {
            test: builtin1("nil?", subject),
            binds: Vec::new(),
        });
    }
    // The field positions: position k = car(cdr^k s) — zero shift.
    let mut binds: Vec<(Symbol, CoreExpr, Span)> = Vec::new();
    let mut tests: Vec<CoreExpr> = Vec::with_capacity(payload_patterns.len());
    for (k, sub) in payload_patterns.iter().enumerate() {
        let mut cursor = subject.clone();
        for _ in 0..k {
            cursor = builtin1("cdr", &cursor);
        }
        let position = builtin1("car", &cursor);
        let compiled = compile_pattern(ctx, sub, &position)?;
        tests.push(compiled.test);
        binds.extend(compiled.binds);
    }
    // The field tests fold right-to-left over a vacuously-true tail.
    let mut fields_test = CoreExpr::Literal {
        span,
        value: LiteralValue::Bool(true),
    };
    for t in tests.into_iter().rev() {
        fields_test = and_chain(t, fields_test, span);
    }
    // `(if (pair? s) FIELDS false)` — the shape guard.
    let test = CoreExpr::If {
        span,
        cond: Box::new(builtin1("pair?", subject)),
        then_branch: Box::new(fields_test),
        else_branch: Box::new(CoreExpr::Literal {
            span,
            value: LiteralValue::Bool(false),
        }),
    };
    Ok(PatternArm { test, binds })
}

/// The pattern-face struct probe (§11.1): does this pattern compile
/// as a STRUCT pattern, and if so, which struct? The probe exists
/// for the last-arm irrefutable walk (a bare ZERO-field struct name
/// passes `is_irrefutable` as a bare symbol yet compiles a FAILABLE
/// `nil?` test — the walk must see it); it feeds no exhaustiveness
/// count (GZ-4's count domain stays variant-only — §11.1's own).
/// The partitions, exactly `compile_pattern`'s struct half:
/// - a bare symbol: hit iff it names a ZERO-field struct;
/// - a list of n >= 2: hit iff the head symbol names an (n-1)-field
///   struct;
/// - a one-element list: the pass-through (the probe recurses);
/// - anything else: None.
fn struct_face(ctx: &ExpandCtx, pattern: &SyntaxObject) -> Option<Symbol> {
    match &pattern.datum {
        StxDatum::Symbol(sym) => match ctx.struct_field_row(sym) {
            Some(0) => Some(sym.clone()),
            _ => None,
        },
        StxDatum::List(elements) => match elements.len() {
            0 => None,
            1 => struct_face(ctx, &elements[0]),
            n => {
                let head = match &elements[0].datum {
                    StxDatum::Symbol(head) => head,
                    _ => return None,
                };
                match ctx.struct_field_row(head) {
                    Some(fields) if fields as usize + 1 == n => Some(head.clone()),
                    _ => None,
                }
            }
        },
        _ => None,
    }
}

/// The exhaustiveness probe (§10.1②): do the arms' variant faces
/// cover SOME enum's full variant set? Each arm's TOP-LEVEL face
/// rides its variant identity (a nested payload position's variant
/// is a payload consumption, not the arm's identity); the covered
/// set is deduplicated per enum (a repeated variant arm is the
/// first-hit-wins chain's own — redundancy, never a gap), then
/// compared against the enum's ORDERED declaration set (the
/// `variant_face` probe and `compile_pattern` share one ruling, so
/// what counts here is exactly what compiles there).
fn enum_exhaustive(ctx: &ExpandCtx, arms: &[(&SyntaxObject, &SyntaxObject)]) -> bool {
    let mut covered: std::collections::HashMap<Symbol, std::collections::HashSet<Symbol>> =
        std::collections::HashMap::new();
    for (pattern, _) in arms {
        if let Some(variant) = variant_face(ctx, pattern) {
            // The parent cannot miss — `variant_face` probed the same
            // table under the same head.
            if let Some((parent, _, _)) = ctx.variant_row(&variant) {
                covered.entry(parent).or_default().insert(variant);
            }
        }
    }
    covered.retain(|enum_name, hit_set| {
        match ctx.enum_variant_list(enum_name) {
            // Covered iff every declared variant is hit (the hit set
            // is a subset of the declared set by construction, so
            // this is an equality test).
            Some(all) => all.iter().all(|v| hit_set.contains(v)),
            None => false,
        }
    });
    !covered.is_empty()
}

/// Compile one pattern against a subject expression (switch-window-
/// plan §5.2 — the implemented family: numeric literals via `=`,
/// bool/string literals via `eq?`, `nil` via `nil?`, `_`, bare
/// bindings, and two-element tuples via `pair?`+`car`/`cdr` with a
/// one-element tuple as the parenthesized pass-through). Everything
/// else fails closed as [`ExpandError::UnsupportedPattern`].
fn compile_pattern(
    ctx: &ExpandCtx,
    pattern: &SyntaxObject,
    subject: &CoreExpr,
) -> Result<PatternArm, ExpandError> {
    let span = pattern.span;
    match &pattern.datum {
        // Numeric literals: `(= subject lit)` — same-kind value
        // comparison; a cross-kind scrutinee is the same runtime type
        // error the hand-written `(= s 1)` raises (identity).
        StxDatum::Int(value) => Ok(PatternArm {
            test: builtin2(
                "=",
                subject,
                CoreExpr::Literal {
                    span,
                    value: LiteralValue::Int(*value),
                },
            ),
            binds: Vec::new(),
        }),
        StxDatum::Float(value) => Ok(PatternArm {
            test: builtin2(
                "=",
                subject,
                CoreExpr::Literal {
                    span,
                    value: LiteralValue::Float(*value),
                },
            ),
            binds: Vec::new(),
        }),
        // Bool and string literals: `(eq? subject lit)` — the
        // all-kind identity predicate (cross-kind is `false`, so a
        // mismatch falls through to the next arm, the pattern
        // semantics).
        StxDatum::Bool(value) => Ok(PatternArm {
            test: builtin2(
                "eq?",
                subject,
                CoreExpr::Literal {
                    span,
                    value: LiteralValue::Bool(*value),
                },
            ),
            binds: Vec::new(),
        }),
        StxDatum::String(value) => Ok(PatternArm {
            test: builtin2(
                "eq?",
                subject,
                CoreExpr::Literal {
                    span,
                    value: LiteralValue::String(value.clone()),
                },
            ),
            binds: Vec::new(),
        }),
        StxDatum::Symbol(sym) => match sym.as_str() {
            // The nil pattern (unit literal `()` on the target skin,
            // C12): `(nil? subject)`.
            "nil" => Ok(PatternArm {
                test: builtin1("nil?", subject),
                binds: Vec::new(),
            }),
            // The wildcard: always matches, binds nothing.
            "_" => Ok(PatternArm {
                test: CoreExpr::Literal {
                    span,
                    value: LiteralValue::Bool(true),
                },
                binds: Vec::new(),
            }),
            // The blade 3 variant face (§10.3) and the blade 4
            // struct face (§11.1) — the dual-lookup disambiguation:
            // a bare symbol that names a ZERO-payload variant is the
            // tag-only variant pattern; a bare symbol that names a
            // ZERO-field struct is the nil-literal struct pattern
            // (an empty right-fold IS nil — GZ-2's own); any other
            // symbol is the bare binding — the six-family
            // partition's own.
            _ => {
                if let Some(variant) = ctx
                    .variant_row(sym)
                    .and_then(|row| if row.2 == 0 { Some(sym.clone()) } else { None })
                {
                    variant_arm(ctx, &variant, &[], pattern, subject)
                } else if ctx.struct_field_row(sym) == Some(0) {
                    struct_arm(ctx, sym, &[], pattern, subject)
                } else {
                    Ok(PatternArm {
                        test: CoreExpr::Literal {
                            span,
                            value: LiteralValue::Bool(true),
                        },
                        binds: vec![(sym.clone(), subject.clone(), span)],
                    })
                }
            }
        },
        // A list pattern. Two elements = the pair shape (the
        // `Type::Pair` two-ary isomorphism); one element = the
        // parenthesized pass-through (Rust's `(x)` is `x`); three or
        // more = the registered (not implemented) family.
        StxDatum::List(elements) => match elements.len() {
            0 => Err(malformed("match", span)),
            1 => compile_pattern(ctx, &elements[0], subject),
            2 => {
                // The blade 3 variant face (§10.3) and the blade 4
                // struct face (§11.1) — the dual-lookup
                // disambiguation: a two-element list whose head
                // names a ONE-payload variant is the variant pattern;
                // else a head naming a ONE-field struct is the struct
                // pattern; anything else is the pair shape — the
                // two-ary isomorphism's own.
                if let StxDatum::Symbol(head) = &elements[0].datum {
                    if let Some(variant) = ctx
                        .variant_row(head)
                        .and_then(|row| if row.2 == 1 { Some(head.clone()) } else { None })
                    {
                        return variant_arm(ctx, &variant, &[&elements[1]], pattern, subject);
                    }
                    if ctx.struct_field_row(head) == Some(1) {
                        return struct_arm(ctx, head, &[&elements[1]], pattern, subject);
                    }
                }
                let car_subject = builtin1("car", subject);
                let cdr_subject = builtin1("cdr", subject);
                let left = compile_pattern(ctx, &elements[0], &car_subject)?;
                let right = compile_pattern(ctx, &elements[1], &cdr_subject)?;
                // The test chain: (if (pair? s) (if t1 t2 false) false)
                // — the `&&` desugaring shape over the shape test and
                // both subtests.
                let both = and_chain(left.test, right.test, span);
                let test = CoreExpr::If {
                    span,
                    cond: Box::new(builtin1("pair?", subject)),
                    then_branch: Box::new(both),
                    else_branch: Box::new(CoreExpr::Literal {
                        span,
                        value: LiteralValue::Bool(false),
                    }),
                };
                let mut binds = left.binds;
                binds.extend(right.binds);
                Ok(PatternArm { test, binds })
            }
            _ => {
                // The blade 3 variant face (§10.3) and the blade 4
                // struct face (§11.1) — the dual-lookup
                // disambiguation: an n-element list (n >= 3) whose
                // head names an (n-1)-payload variant is the variant
                // pattern; else a head naming an (n-1)-field struct
                // is the struct pattern; anything else stays the
                // registered (not implemented) rejection.
                if let StxDatum::Symbol(head) = &elements[0].datum {
                    if let Some(variant) = ctx.variant_row(head).and_then(|row| {
                        if row.2 + 1 == elements.len() {
                            Some(head.clone())
                        } else {
                            None
                        }
                    }) {
                        let payloads: Vec<&SyntaxObject> = elements[1..].iter().collect();
                        return variant_arm(ctx, &variant, &payloads, pattern, subject);
                    }
                    if ctx.struct_field_row(head) == Some((elements.len() - 1) as u32) {
                        let payloads: Vec<&SyntaxObject> = elements[1..].iter().collect();
                        return struct_arm(ctx, head, &payloads, pattern, subject);
                    }
                }
                Err(ExpandError::UnsupportedPattern { span })
            }
        },
    }
}

/// A global call of arity 2 (the test helpers over builtins — the
/// same nodes a hand-written `(= a b)` expands to).
fn builtin2(name: &str, lhs: &CoreExpr, rhs: CoreExpr) -> CoreExpr {
    CoreExpr::Apply {
        span: lhs.span(),
        func: Box::new(CoreExpr::Var {
            span: lhs.span(),
            name: Symbol::new(name).expect("test builtin name is a valid symbol"),
        }),
        args: vec![lhs.clone(), rhs],
    }
}

/// A global call of arity 1.
fn builtin1(name: &str, arg: &CoreExpr) -> CoreExpr {
    CoreExpr::Apply {
        span: arg.span(),
        func: Box::new(CoreExpr::Var {
            span: arg.span(),
            name: Symbol::new(name).expect("test builtin name is a valid symbol"),
        }),
        args: vec![arg.clone()],
    }
}

/// `(if lhs rhs false)` — one `&&` link (the r98 operator-skin
/// desugaring shape; shared by the tuple pattern's subtest chain).
fn and_chain(lhs: CoreExpr, rhs: CoreExpr, span: Span) -> CoreExpr {
    CoreExpr::If {
        span,
        cond: Box::new(lhs),
        then_branch: Box::new(rhs),
        else_branch: Box::new(CoreExpr::Literal {
            span,
            value: LiteralValue::Bool(false),
        }),
    }
}

fn expand_application(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (func args...) — the func position is an ordinary expression.
    let func = expand(ctx, &items[0])?;
    let mut args = Vec::with_capacity(items.len() - 1);
    for arg in &items[1..] {
        args.push(expand(ctx, arg)?);
    }
    Ok(CoreExpr::Apply {
        span,
        func: Box::new(func),
        args,
    })
}

// ---------- declaration expansion (program face) ----------

fn expand_declarations(
    ctx: &mut ExpandCtx,
    forms: &[SyntaxObject],
) -> Result<Vec<ModuleItem>, ExpandError> {
    // W-3.2: pre-collect the extern contract names before any item
    // walks (the letrec bind-first discipline applied to
    // declarations — a call site may precede its extern block).
    // Lenient by design: malformed extern forms fail in
    // `expand_extern` with the full police diagnostics; this scan
    // only feeds the resolution table symbol heads.
    {
        let mut extern_names = Vec::new();
        for form in forms {
            let items = match &form.datum {
                StxDatum::List(items) if !items.is_empty() => items,
                _ => continue,
            };
            if symbol_text(&items[0]) != Some("extern") {
                continue;
            }
            for stx in &items[1..] {
                match &stx.datum {
                    // The optional ABI string rides before the items.
                    StxDatum::String(_) => {}
                    StxDatum::List(entry) => {
                        if let Some(name) = entry.first().and_then(symbol_sym) {
                            extern_names.push(name.clone());
                        }
                    }
                    // Any other datum shape is not an extern entry
                    // (the reader's extern grammar owns rejection).
                    _ => {}
                }
            }
        }
        ctx.seed_extern_names(extern_names);
    }
    // W-LANG-FOUNDATION blade 2 (GZ-2): pre-count the struct
    // declaration names before any item walks — the order-blind
    // reservation table (a define that rebinds a struct name
    // rejects wherever it sits; a second declaration of the same
    // name rejects at both sites). Lenient by design: malformed
    // struct forms fail in `expand_struct` with the full police
    // diagnostics; this scan only feeds the reservation counts.
    {
        let mut struct_counts: std::collections::HashMap<Symbol, u32> =
            std::collections::HashMap::new();
        let mut struct_rows: std::collections::HashMap<Symbol, u32> =
            std::collections::HashMap::new();
        for form in forms {
            let items = match &form.datum {
                StxDatum::List(items) if !items.is_empty() => items,
                _ => continue,
            };
            if symbol_text(&items[0]) != Some("struct") {
                continue;
            }
            if let Some(name) = items.get(1).and_then(symbol_sym) {
                *struct_counts.entry(name.clone()).or_insert(0) += 1;
                // The blade 4 field-count row (§11.1): first
                // occurrence wins — the redeclaration police rejects
                // upstream in `expand_struct`; lenient like the
                // counts (a malformed carrier still counts — the
                // program dies in `expand_struct` before any pattern
                // consults the row).
                struct_rows
                    .entry(name.clone())
                    .or_insert(items.len().saturating_sub(2) as u32);
            }
        }
        ctx.seed_struct_counts(struct_counts);
        ctx.seed_struct_rows(struct_rows);
    }
    // Blade 3 GZ-4: pre-count the enum names and the variant names
    // before any item walks — the order-blind reservation tables
    // (an enum name rebinds wherever it sits; a cross-enum variant
    // name rejects at BOTH sites — the flat pattern-face lookup's
    // one-name-one-enum precondition). Lenient by design: malformed
    // enum forms fail in `expand_enum` with the full police
    // diagnostics; this scan only feeds the reservation counts.
    // The same scan also builds the ORDERED rows (§10.3): the
    // enum's variant-name list in declaration order (the tag
    // numbering's source — the exhaustiveness count's table) and
    // each variant's (enum, tag ordinal, payload count) row (the
    // pattern-face lookup's table) — first occurrence wins per
    // name, the same lenient face.
    {
        let mut enum_counts: std::collections::HashMap<Symbol, u32> =
            std::collections::HashMap::new();
        let mut variant_counts: std::collections::HashMap<Symbol, u32> =
            std::collections::HashMap::new();
        let mut enum_rows: std::collections::HashMap<Symbol, Vec<Symbol>> =
            std::collections::HashMap::new();
        let mut variant_rows: std::collections::HashMap<Symbol, (Symbol, u32, usize)> =
            std::collections::HashMap::new();
        for form in forms {
            let items = match &form.datum {
                StxDatum::List(items) if !items.is_empty() => items,
                _ => continue,
            };
            if symbol_text(&items[0]) != Some("enum") {
                continue;
            }
            if let Some(name) = items.get(1).and_then(symbol_sym) {
                *enum_counts.entry(name.clone()).or_insert(0) += 1;
                // The ORDERED variant rows ride under the same head:
                // declaration order = the tag numbering's source.
                // First declaration of the name wins (lenient — the
                // redeclaration police rejects in `expand_enum`).
                if let std::collections::hash_map::Entry::Vacant(slot) =
                    enum_rows.entry(name.clone())
                {
                    let mut ordered: Vec<Symbol> = Vec::new();
                    for carrier in items.get(2..).unwrap_or(&[]) {
                        let pair = match &carrier.datum {
                            StxDatum::List(pair) if !pair.is_empty() => pair,
                            _ => continue,
                        };
                        if let Some(vname) = symbol_sym(&pair[0]) {
                            // The row: tag ordinal = the position in
                            // `ordered` (0-based, the §10.2 ruling);
                            // payload count = the carrier's element
                            // count minus the name — `(V p0 p1)` is
                            // two payloads.
                            let tag = ordered.len() as u32;
                            let payloads = pair.len().saturating_sub(1);
                            variant_rows.entry(vname.clone()).or_insert((
                                name.clone(),
                                tag,
                                payloads,
                            ));
                            ordered.push(vname.clone());
                        }
                    }
                    slot.insert(ordered);
                }
            }
            for carrier in items.get(2..).unwrap_or(&[]) {
                let pair = match &carrier.datum {
                    StxDatum::List(pair) if !pair.is_empty() => pair,
                    _ => continue,
                };
                if let Some(vname) = symbol_sym(&pair[0]) {
                    *variant_counts.entry(vname.clone()).or_insert(0) += 1;
                }
            }
        }
        ctx.seed_enum_counts(enum_counts, variant_counts);
        ctx.seed_enum_rows(enum_rows, variant_rows);
    }
    let module_scope = ctx.fresh_scope();
    // The module frame's binder scopes: the *uncolored* forms' base
    // (the outer context) plus the module scope — exactly what a
    // top-level binding occurrence carries after coloring.
    let base = match forms.first() {
        Some(form) => form.scopes.clone(),
        None => ScopeSet::new(),
    };
    ctx.push_frame(module_scope, &base);
    let result = (|| {
        let mut items = Vec::with_capacity(forms.len());
        for form in forms {
            require_runtime(form)?;
            let colored = form.with_scope_added(module_scope);
            items.push(expand_declaration(ctx, &colored)?);
            // The blade 1 dann drain (GZ-1): the annotation site
            // records collected during this form's expansion ride
            // right after their annotated item — a deterministic
            // adjacent order the twin mirrors.
            items.extend(ctx.take_annotations());
            // The blade 2 struct drain (GZ-2): the desugaring's item
            // tail (the constructor's dann sites, the accessor
            // defines with their own dann sites, the dstruct
            // record) rides right after — the same deterministic
            // adjacent order the twin mirrors.
            items.extend(ctx.take_pending());
        }
        reject_extern_collisions(&items)?;
        Ok(items)
    })();
    ctx.pop_frame();
    result
}

/// The declaration heads: a top-level list whose head is one of these
/// strings is a declaration (module item); every other head — the
/// expression special forms included — is a bare top-level expression
/// and is rejected by `expand_declaration`. This constant is the
/// single source for that classification: the driver's REPL wraps
/// expression submissions into `$repl:N` defines and passes
/// declarations through, so it consumes this list instead of keeping
/// a second one (stage0.md §9.62 SURF-2). The gate in
/// `expand_declaration` consults it before the dispatch arms; the
/// `top_level_heads_match_dispatch_table` unit test pins the two
/// together (a const member with no dispatch arm falls to the
/// fail-closed arm and fails the test; an arm without a const member
/// is unreachable dead code).
pub const TOP_LEVEL_DECLARATION_HEADS: &[&str] = &[
    "define",
    "define-ann",
    "require",
    "module",
    "define-syntax",
    "extern",
    "struct",
    "enum",
];

fn expand_declaration(ctx: &mut ExpandCtx, form: &SyntaxObject) -> Result<ModuleItem, ExpandError> {
    let items = match &form.datum {
        StxDatum::List(items) if !items.is_empty() => items,
        // Atoms and `()` at module top level are expressions, not
        // declarations.
        _ => return Err(ExpandError::TopLevelExpression { span: form.span }),
    };
    require_runtime(&items[0])?;
    let head = match symbol_text(&items[0]) {
        // The const is the gate: only declaration heads dispatch.
        Some(head) if TOP_LEVEL_DECLARATION_HEADS.contains(&head) => head,
        // Any other head — including the expression special forms —
        // is a bare top-level expression.
        _ => return Err(ExpandError::TopLevelExpression { span: form.span }),
    };
    match head {
        "define" => expand_define(ctx, items, form.span),
        "define-ann" => expand_define_ann(ctx, items, form.span),
        "require" => expand_require(items, form.span),
        "module" => expand_module(ctx, items, form.span),
        "define-syntax" => expand_define_syntax(ctx, items, form.span),
        "extern" => expand_extern(ctx, items, form.span),
        "struct" => expand_struct(ctx, items, form.span),
        "enum" => expand_enum(ctx, items, form.span),
        // A const member with no dispatch arm above: fail closed —
        // the `top_level_heads_match_dispatch_table` unit test turns
        // this hole into a failure (a const member must never come
        // back out as a top-level-expression rejection).
        _ => Err(ExpandError::TopLevelExpression { span: form.span }),
    }
}

/// The heads a macro name may never take (also the rename-on-capture
/// name faces — transformer.rs): the flat dispatch order resolves core
/// forms before macros, so such a declaration would be silently dead
/// (report over silence — rejected at registration), and an introduced
/// binder named like a core form would be shadowed by the dispatch
/// itself.
pub(crate) const RESERVED_MACRO_NAMES: &[&str] = &[
    "fn",
    "if",
    "let",
    "do",
    "set!",
    "perform",
    "handle",
    "quote",
    "match",
    "define",
    "define-ann",
    "fn-ann",
    "require",
    "module",
    "define-syntax",
    "extern",
    "struct",
    "enum",
    "nil",
    "_",
    "...",
];

/// The interned form of [`RESERVED_MACRO_NAMES`] (§9.66 TRF-6): seeded
/// once on first use, then the macro-instantiation trigger set copies
/// pool entries instead of re-allocating ~15 strings per macro use
/// (the `rustc_span::sym` pre-interning discipline — K113). The
/// `&[&str]` const stays the single text source.
pub(crate) fn reserved_macro_name_symbols() -> &'static std::collections::HashSet<Symbol> {
    static SET: std::sync::OnceLock<std::collections::HashSet<Symbol>> = std::sync::OnceLock::new();
    SET.get_or_init(|| {
        RESERVED_MACRO_NAMES
            .iter()
            .map(|text| Symbol::new(text).expect("reserved name must be a valid symbol"))
            .collect()
    })
}

/// Whether `name` is a reserved macro head (§9.66 TRF-8: judged by the
/// pool entry the caller holds — membership over the pre-interned
/// set, never a text scan).
pub(crate) fn is_reserved_macro_name(name: &Symbol) -> bool {
    reserved_macro_name_symbols().contains(name)
}

/// `(define-syntax name (syntax-rules ...))` — the macro declaration
/// (sub-stage 0.9). Registers the transformer in the current frame
/// (lexically scoped: a nested module's macros vanish with its
/// frame) and emits the zero-code declaration record
/// ([`ModuleItem::DefineSyntax`]).
fn expand_define_syntax(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    // (define-syntax name spec) — exactly three items.
    if items.len() != 3 {
        return Err(malformed("define-syntax", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let sym = symbol_sym(&items[1]).ok_or_else(|| malformed("define-syntax", span))?;
    if is_reserved_macro_name(sym) {
        return Err(malformed("define-syntax", span));
    }
    reject_struct_name(ctx, sym, span)?;
    reject_enum_name(ctx, sym, span)?;
    // Fresh def-site scope, then color the whole spec: every template
    // node carries the definition context plus the def scope (the
    // §9.38(b) coloring — the union the subset judgment consumes).
    let def_scope = ctx.fresh_scope();
    let colored_spec = items[2].with_scope_added(def_scope);
    // §9.65 EXP-3: the declaration identity flows to the transformer
    // as the interned entry itself — the mismatch error later carries
    // this same entry (index equality), never a re-interned copy.
    let rules = SyntaxRules::parse(sym.clone(), &colored_spec, span)?;
    let id = ctx.register_transformer(rules);
    // §9.66 TRF-2: the macro registry binds the pool entry itself.
    ctx.bind_macro(sym, id);
    ModuleItem::define_syntax(span, sym.as_str()).map_err(|source| core_err(source, span))
}

fn expand_define(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    if items.len() != 3 {
        return Err(malformed("define", span));
    }
    require_runtime(&items[1])?;
    match &items[1].datum {
        // Function define sugar: (define (f params...) body) →
        // Define{f, Fn{params, body}} — the near-identity mapping of
        // docs/stage0.md §7.3.5.
        StxDatum::List(name_and_params) if !name_and_params.is_empty() => {
            require_runtime(&name_and_params[0])?;
            let name = symbol_sym(&name_and_params[0]).ok_or_else(|| malformed("define", span))?;
            reject_struct_name(ctx, name, span)?;
            reject_enum_name(ctx, name, span)?;
            let mut params = Vec::with_capacity(name_and_params.len() - 1);
            for param in &name_and_params[1..] {
                require_runtime(param)?;
                params.push(symbol_sym(param).ok_or_else(|| malformed("define", span))?);
            }
            require_runtime(&items[2])?;
            // Pre-bind the name before expanding the body: the
            // letrec-shaped top-level rule (recursive functions
            // resolve their own name).
            ctx.bind(name);
            let value = expand_fn_binding(
                ctx,
                &params,
                &items[2],
                name_and_params[0].span,
                &items[0].scopes,
            )?;
            ModuleItem::define(span, name.as_str(), value).map_err(|source| core_err(source, span))
        }
        // Value define: (define name value).
        StxDatum::Symbol(_) => {
            let name = symbol_sym(&items[1]).expect("datum is a symbol");
            reject_struct_name(ctx, name, span)?;
            reject_enum_name(ctx, name, span)?;
            require_runtime(&items[2])?;
            ctx.bind(name);
            let value = expand(ctx, &items[2])?;
            ModuleItem::define(span, name.as_str(), value).map_err(|source| core_err(source, span))
        }
        _ => Err(malformed("define", span)),
    }
}

fn expand_require(items: &[SyntaxObject], span: Span) -> Result<ModuleItem, ExpandError> {
    // (require "module") — the module name is a string datum
    // (fail-closed: symbols are rejected).
    if items.len() != 2 {
        return Err(malformed("require", span));
    }
    require_runtime(&items[1])?;
    match &items[1].datum {
        StxDatum::String(module) => {
            ModuleItem::require(span, module).map_err(|source| core_err(source, span))
        }
        _ => Err(malformed("require", span)),
    }
}

fn expand_module(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    // (module name items...) — nested declarations, scope-isolated
    // from outer defines (docs/stage0.md §8.9 direction).
    if items.len() < 3 {
        return Err(malformed("module", span));
    }
    require_runtime(&items[1])?;
    let name = symbol_text(&items[1]).ok_or_else(|| malformed("module", span))?;
    let saved = ctx.isolate_frames();
    ctx.enter_module();
    let inner = expand_declarations(ctx, &items[2..]);
    ctx.leave_module();
    ctx.restore_frames(saved);
    ModuleItem::module(span, name, inner?).map_err(|source| core_err(source, span))
}

// ---------- extern declarations (W-3.2 — the FFI contract form) ----------

/// `(extern ["abi"] (name (param-type...) ret-type) ...)` — the FFI
/// declaration. The single form police (W-3.2 §1.7): shape, ABI
/// vocabulary, type vocabulary, C-symbol legality, the
/// top-level-only ruling and the within-block collision family all
/// judge here; the cross-item collision family (extern-vs-extern
/// across blocks, extern-vs-define) runs as the declaration-list
/// post-pass ([`reject_extern_collisions`]). The declaration is
/// macro-inert (the window record's §1.4 ruling: no expansion
/// happens inside the block — `require`'s data-not-code precedent)
/// and carries zero runtime code.
fn expand_extern(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    if ctx.in_nested_module() {
        return Err(ExpandError::ExternNotTopLevel { span });
    }
    // The optional ABI string: absent = C; present must be exactly "C".
    let mut rest = &items[1..];
    let abi = match rest.first().map(|stx| &stx.datum) {
        Some(StxDatum::String(text)) => {
            let stx = &rest[0];
            require_runtime(stx)?;
            if text.as_ref() != "C" {
                return Err(ExpandError::ExternAbiUnsupported { span: stx.span });
            }
            rest = &rest[1..];
            ExternAbi::C
        }
        _ => ExternAbi::C,
    };
    if rest.is_empty() {
        return Err(malformed("extern", span));
    }
    let mut extern_items = Vec::with_capacity(rest.len());
    for stx in rest {
        require_runtime(stx)?;
        extern_items.push(parse_extern_item(stx)?);
    }
    // Within-block collisions: canonical identity and derived C
    // symbol (injectivity — W-3.2 §1.3).
    reject_within_block_collisions(&extern_items)?;
    ModuleItem::extern_block(span, abi, extern_items).map_err(|source| core_err(source, span))
}

/// The struct-name reservation probe (blade 2 GZ-2): every binding
/// arm (define / define-ann / define-syntax) consults this before
/// binding — a struct name is reserved for the whole module (the
/// type table is static; a later define would strand it, the
/// order-blind extern collision discipline).
fn reject_struct_name(ctx: &ExpandCtx, name: &Symbol, span: Span) -> Result<(), ExpandError> {
    if ctx.is_struct_name(name) {
        Err(ExpandError::StructNameReserved {
            name: name.clone(),
            span,
        })
    } else {
        Ok(())
    }
}

/// The enum-name and variant-name reservation probe (blade 3
/// GZ-4): every binding arm (define / define-ann / define-syntax)
/// consults this before binding — an enum name is reserved for the
/// whole module (the struct name's own discipline); a variant name
/// rides the declaration namespace (the pattern-face lookup maps
/// one variant name to one enum, so a define of that name would
/// strand the match disambiguation).
fn reject_enum_name(ctx: &ExpandCtx, name: &Symbol, span: Span) -> Result<(), ExpandError> {
    if ctx.is_enum_name(name) {
        Err(ExpandError::EnumNameReserved {
            name: name.clone(),
            span,
        })
    } else if ctx.is_variant_name(name) {
        Err(ExpandError::EnumVariantNameCollision {
            name: name.clone(),
            span,
        })
    } else {
        Ok(())
    }
}

/// `(struct Name (field spec) ...)` — the blade 2 GZ-2 declaration.
/// Desugars to the constructor define `Name = fn(field0..fieldN)
/// -> cons(field0, cons(field1, ... nil))` (the pair-chain
/// representation, uniform right fold — the empty struct is the nil
/// literal, a single field is not specialized), one accessor define
/// per field `Name-field = fn(p) -> car(cdr^i(p))`, the generated
/// annotation sites for all of them (the blade 1 dann machinery
/// enforces the declared field specs — param i anchors field i's
/// spec, the ret anchors the struct name, each accessor's param
/// anchors the struct name and its ret anchors the field's spec),
/// and the zero-code dstruct record the inference layer's resolve
/// table consumes. The constructor define is THIS arm's item; the
/// whole tail (danns, accessors, dstruct) parks in the pending
/// drain.
///
/// The generated ctor params ARE the field names (the twin's own
/// expressibility ruling: the frozen subset has no string-building
/// primitive, so synthesized names must come from source text —
/// both arms build the identical records); the representation
/// vocabulary police (`cons`/`car`/`cdr` — the GZ-2 names the
/// generated bodies reference) keeps a field from shadowing them.
/// The accessor subject is the constant `p` (a field named `p` is
/// self-consistent — the body references only its own param). The
/// anchors ride real source extents (the name ident for the
/// constructor, the field ident for each accessor — distinct
/// nodes, the anchor-uniqueness discipline).
fn expand_struct(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    if ctx.in_nested_module() {
        return Err(ExpandError::StructNotTopLevel { span });
    }
    // (struct Name (field spec)...) — the name, then one carrier.
    if items.len() < 2 {
        return Err(malformed("struct", span));
    }
    for stx in items {
        require_runtime(stx)?;
    }
    let name = symbol_sym(&items[1])
        .ok_or_else(|| malformed("struct", span))?
        .clone();
    // The order-blind police: the pre-counted declarations, the
    // Stage 0 globals, and the extern contract names (the generated
    // constructor is a define in that same namespace — an extern
    // declared after the struct is caught by the post-walk
    // extern-vs-define police).
    if ctx.struct_name_count(&name) > 1 {
        return Err(ExpandError::StructRedeclared { name, span });
    }
    if crate::stage0_global_symbols().contains(&name)
        || ctx.is_extern_name(&name)
        || ctx.is_enum_name(&name)
    {
        return Err(ExpandError::StructNameCollision { name, span });
    }
    // The fields: (name spec) two-element carriers, duplicate-free.
    let mut fields: Vec<(Symbol, Span, &SyntaxObject)> = Vec::with_capacity(items.len() - 2);
    let mut seen: std::collections::HashSet<Symbol> = std::collections::HashSet::new();
    for carrier in &items[2..] {
        let pair = match &carrier.datum {
            StxDatum::List(pair) if pair.len() == 2 => pair,
            _ => return Err(malformed("struct", span)),
        };
        require_runtime(&pair[0])?;
        require_runtime(&pair[1])?;
        let fname = symbol_sym(&pair[0])
            .ok_or_else(|| malformed("struct", span))?
            .clone();
        if !seen.insert(fname.clone()) {
            return Err(ExpandError::StructDuplicateField {
                name: fname,
                span: carrier.span,
            });
        }
        // The representation vocabulary police: the generated
        // bodies reference `cons`/`car`/`cdr` as globals — a field
        // named after one would shadow it inside its own ctor.
        if matches!(fname.as_str(), "cons" | "car" | "cdr") {
            return Err(ExpandError::StructFieldReserved {
                name: fname,
                span: pair[0].span,
            });
        }
        fields.push((fname, pair[0].span, &pair[1]));
    }
    // The constructor: the Fn carries the NAME ident's own span (the
    // anchor the generated dann sites key on — expand_fn_binding's
    // own discipline for define fns). The params ARE the field
    // names (the twin expressibility ruling — see the arm docs).
    let name_span = items[1].span;
    let params: Vec<Symbol> = fields.iter().map(|(fname, _, _)| fname.clone()).collect();
    let body = struct_ctor_body(&params, name_span);
    let ctor_fn = CoreExpr::Fn {
        span: name_span,
        params: params.clone(),
        body: Box::new(body),
    };
    ctx.bind(&name);
    let ctor = ModuleItem::define(span, name.as_str(), ctor_fn)
        .map_err(|source| core_err(source, span))?;
    // The constructor's dann sites (the define-ann emission order:
    // params first, then the ret slot): param i anchors field i's
    // declared spec; the ret anchors the struct name itself (the
    // resolve table's struct half turns the name into the Struct
    // alias — blade 2 GZ-3).
    for (index, (fname, _, spec)) in fields.iter().enumerate() {
        let _ = fname;
        ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
            span: spec.span,
            anchor: name_span,
            kind: kerf_core::AnnotationKind::Param,
            index: index as u32,
            spec: spec_value(spec),
        });
    }
    ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
        span: name_span,
        anchor: name_span,
        kind: kerf_core::AnnotationKind::Ret,
        index: 0,
        spec: LiteralValue::String(std::rc::Rc::from(name.as_str())),
    });
    // One accessor per field: `Name-field = fn(p) -> car(cdr^i(p))`,
    // anchored at the FIELD ident's own span (a distinct source
    // node per field). The accessor names are ordinary defines —
    // re-bindable like any other (only the struct NAME reserves).
    let subject = Symbol::new("p").expect("the accessor subject is a valid symbol");
    for (index, (fname, field_span, spec)) in fields.iter().enumerate() {
        let acc_text = struct_accessor_name(name.as_str(), fname.as_str());
        let acc_name = Symbol::new(&acc_text).expect("the struct accessor join is a valid symbol");
        let body = struct_field_body(index, subject.clone(), *field_span);
        let acc_fn = CoreExpr::Fn {
            span: *field_span,
            params: vec![subject.clone()],
            body: Box::new(body),
        };
        ctx.bind(&acc_name);
        let acc = ModuleItem::define(*field_span, acc_name.as_str(), acc_fn)
            .map_err(|source| core_err(source, *field_span))?;
        ctx.pending_items.push(acc);
        // The accessor's dann sites: the param anchors the struct
        // name (the alias), the ret anchors the field's own spec.
        ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
            span: name_span,
            anchor: *field_span,
            kind: kerf_core::AnnotationKind::Param,
            index: 0,
            spec: LiteralValue::String(std::rc::Rc::from(name.as_str())),
        });
        ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
            span: spec.span,
            anchor: *field_span,
            kind: kerf_core::AnnotationKind::Ret,
            index: 0,
            spec: spec_value(spec),
        });
    }
    // The dstruct declaration record (the type layer's own input).
    ctx.pending_items.push(kerf_core::ModuleItem::Struct {
        span,
        name: name.clone(),
        fields: fields
            .iter()
            .map(|(fname, _, spec)| (fname.clone(), spec_value(spec)))
            .collect(),
    });
    Ok(ctor)
}

/// The constructor body: `(cons p0 (cons p1 ... nil))` — the
/// uniform right fold over the nil literal (the empty struct is
/// `nil` itself; every node carries the name ident's span — the
/// honest source position for synthesized nodes).
fn struct_ctor_body(params: &[Symbol], span: Span) -> CoreExpr {
    let mut body = CoreExpr::Literal {
        span,
        value: LiteralValue::Nil,
    };
    for p in params.iter().rev() {
        body = CoreExpr::Apply {
            span,
            func: Box::new(CoreExpr::Var {
                span,
                name: Symbol::new("cons").expect("the cons builtin is a valid symbol"),
            }),
            args: vec![
                CoreExpr::Var {
                    span,
                    name: p.clone(),
                },
                body,
            ],
        };
    }
    body
}

/// The field-i accessor body: `(car (cdr^i p))` — i `cdr` hops then
/// `car` (field 0 is the bare `car`).
fn struct_field_body(index: usize, subject: Symbol, span: Span) -> CoreExpr {
    let mut body = CoreExpr::Var {
        span,
        name: subject,
    };
    for _ in 0..index {
        body = CoreExpr::Apply {
            span,
            func: Box::new(CoreExpr::Var {
                span,
                name: Symbol::new("cdr").expect("the cdr builtin is a valid symbol"),
            }),
            args: vec![body],
        };
    }
    CoreExpr::Apply {
        span,
        func: Box::new(CoreExpr::Var {
            span,
            name: Symbol::new("car").expect("the car builtin is a valid symbol"),
        }),
        args: vec![body],
    }
}

/// `(enum Name (v) (v spec ...) ...)` — the blade 3 GZ-4
/// declaration. Desugars to one constructor define per variant
/// `Enum-Variant = fn(a0..aN) -> cons(tag, cons(a0, ... nil))` (the
/// tagged pair-chain representation, §10.2: the tag is the
/// declaration-order 0-based Int literal, the payload chain the
/// struct representation's own right fold — a payload-less variant
/// is `cons(tag, nil)`), the generated annotation sites for each
/// constructor (param k anchors the variant's declared spec k, the
/// ret anchors the enum name — the resolve table's enum half turns
/// the name into the `Enum` nominal carrier), and the zero-code
/// denum record the inference layer's resolve table consumes. The
/// FIRST constructor define is THIS arm's item (the struct
/// ctor's own position); the rest (the remaining constructors,
/// their danns, the denum record) park in the pending drain — the
/// deterministic adjacent order the twin mirrors.
///
/// The generated ctor names (`Enum-Variant`) and param names
/// (`a0..aN`) are synthesized names (the twin expressibility
/// ruling, r166-b2's own face at the enum layer: the frozen subset
/// has no string building — the struct's ctor params ARE the field
/// names, the enum's payload specs carry none, so the constructor
/// join AND the param names both ride the injected
/// `ex-enum-ctors` table; parity itself is the drift guard).
fn expand_enum(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    if ctx.in_nested_module() {
        return Err(ExpandError::EnumNotTopLevel { span });
    }
    // (enum Name (v) (v spec)...) — the name, then one carrier per
    // variant.
    if items.len() < 2 {
        return Err(malformed("enum", span));
    }
    for stx in items {
        require_runtime(stx)?;
    }
    let name = symbol_sym(&items[1])
        .ok_or_else(|| malformed("enum", span))?
        .clone();
    // The order-blind police: the pre-counted declarations, the
    // Stage 0 globals, and the extern contract names (the struct
    // police's own face — the generated constructors are defines in
    // that namespace).
    if ctx.enum_name_count(&name) > 1 {
        return Err(ExpandError::EnumRedeclared { name, span });
    }
    if crate::stage0_global_symbols().contains(&name)
        || ctx.is_extern_name(&name)
        || ctx.is_struct_name(&name)
    {
        return Err(ExpandError::EnumNameCollision { name, span });
    }
    // The variants: (vname) or (vname spec...) carriers.
    let mut variants: Vec<(Symbol, Span, &[SyntaxObject])> = Vec::with_capacity(items.len() - 2);
    let mut seen: std::collections::HashSet<Symbol> = std::collections::HashSet::new();
    for carrier in &items[2..] {
        let pair = match &carrier.datum {
            StxDatum::List(pair) if !pair.is_empty() => pair,
            _ => return Err(malformed("enum", span)),
        };
        require_runtime(&pair[0])?;
        for spec in &pair[1..] {
            require_runtime(spec)?;
        }
        let vname = symbol_sym(&pair[0])
            .ok_or_else(|| malformed("enum", span))?
            .clone();
        if !seen.insert(vname.clone()) {
            return Err(ExpandError::EnumDuplicateVariant {
                name: vname,
                span: carrier.span,
            });
        }
        // The vocabulary police: the pattern-face lookup
        // disambiguates on the variant name, so a variant named after
        // the representation (`cons`/`car`/`cdr`) or the match
        // vocabulary (`nil`/`_`) would hijack the pattern grammar.
        if matches!(vname.as_str(), "cons" | "car" | "cdr" | "nil" | "_") {
            return Err(ExpandError::EnumVariantReserved {
                name: vname,
                span: pair[0].span,
            });
        }
        // The cross-enum collision: this declaration's first
        // occurrence of `vname` meets a count of 2+ — another enum
        // owns a variant of the same name (the flat pattern-face
        // one-name-one-enum precondition, order-blind at BOTH
        // sites).
        if ctx.variant_name_count(&vname) > 1 {
            return Err(ExpandError::EnumVariantNameCollision {
                name: vname,
                span: carrier.span,
            });
        }
        variants.push((vname, pair[0].span, &pair[1..]));
    }
    // One constructor per variant, in declaration order (the tag is
    // the declaration index — §10.2). Each ctor's Fn carries the
    // VARIANT ident's own span (the anchor the generated dann sites
    // key on — the struct ctor's NAME-ident discipline at the
    // variant face).
    let mut first_ctor: Option<ModuleItem> = None;
    for (index, (vname, vname_span, specs)) in variants.iter().enumerate() {
        let ctor_text = enum_ctor_name(name.as_str(), vname.as_str());
        let ctor_name =
            Symbol::new(&ctor_text).expect("the enum constructor join is a valid symbol");
        let params: Vec<Symbol> = (0..specs.len())
            .map(|k| {
                let p = enum_ctor_param_name(k);
                Symbol::new(&p).expect("the enum ctor param join is a valid symbol")
            })
            .collect();
        // The body: cons(tag, right-fold(payload)) — the payload
        // chain is the struct representation's own (a payload-less
        // variant is cons(tag, nil)).
        let mut body = CoreExpr::Literal {
            span: *vname_span,
            value: LiteralValue::Nil,
        };
        for p in params.iter().rev() {
            body = CoreExpr::Apply {
                span: *vname_span,
                func: Box::new(CoreExpr::Var {
                    span: *vname_span,
                    name: Symbol::new("cons").expect("the cons builtin is a valid symbol"),
                }),
                args: vec![
                    CoreExpr::Var {
                        span: *vname_span,
                        name: p.clone(),
                    },
                    body,
                ],
            };
        }
        let body = CoreExpr::Apply {
            span: *vname_span,
            func: Box::new(CoreExpr::Var {
                span: *vname_span,
                name: Symbol::new("cons").expect("the cons builtin is a valid symbol"),
            }),
            args: vec![
                CoreExpr::Literal {
                    span: *vname_span,
                    value: LiteralValue::Int(index as i64),
                },
                body,
            ],
        };
        let ctor_fn = CoreExpr::Fn {
            span: *vname_span,
            params: params.clone(),
            body: Box::new(body),
        };
        ctx.bind(&ctor_name);
        let ctor = ModuleItem::define(*vname_span, ctor_name.as_str(), ctor_fn)
            .map_err(|source| core_err(source, *vname_span))?;
        if first_ctor.is_none() {
            first_ctor = Some(ctor);
        } else {
            ctx.pending_items.push(ctor);
        }
        // The constructor's dann sites (the define-ann emission
        // order): param k anchors the variant's declared spec k; the
        // ret anchors the enum name itself (the resolve table's enum
        // half turns the name into the `Enum` nominal carrier —
        // blade 3 §10.4).
        for (k, spec) in specs.iter().enumerate() {
            ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
                span: spec.span,
                anchor: *vname_span,
                kind: kerf_core::AnnotationKind::Param,
                index: k as u32,
                spec: spec_value(spec),
            });
        }
        ctx.pending_items.push(kerf_core::ModuleItem::Annotate {
            span: *vname_span,
            anchor: *vname_span,
            kind: kerf_core::AnnotationKind::Ret,
            index: 0,
            spec: LiteralValue::String(std::rc::Rc::from(name.as_str())),
        });
    }
    // The denum declaration record (the type layer's own input). An
    // empty enum (zero variants, the Rust `Never` form's own) has no
    // constructor: the denum record is THEN the arm's item itself
    // (a zero-code declaration — the `Annotate`/`dstruct`
    // zero-code precedents' own face).
    let denum = kerf_core::ModuleItem::Enum {
        span,
        name: name.clone(),
        variants: variants
            .iter()
            .map(|(vname, _, specs)| {
                (
                    vname.clone(),
                    specs.iter().map(spec_value).collect::<Vec<_>>(),
                )
            })
            .collect(),
    };
    match first_ctor {
        Some(ctor) => {
            ctx.pending_items.push(denum);
            Ok(ctor)
        }
        None => Ok(denum),
    }
}

/// One `(name (param-type...) ret-type)` payload item.
fn parse_extern_item(stx: &SyntaxObject) -> Result<ExternItem, ExpandError> {
    let items = match &stx.datum {
        StxDatum::List(items) if items.len() == 3 => items,
        _ => return Err(malformed("extern", stx.span)),
    };
    require_runtime(&items[0])?;
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let name = symbol_sym(&items[0])
        .cloned()
        .ok_or_else(|| malformed("extern", stx.span))?;
    let params = match &items[1].datum {
        StxDatum::List(types) => {
            let mut parsed = Vec::with_capacity(types.len());
            for ty in types {
                parsed.push(parse_extern_type(ty)?);
            }
            parsed
        }
        _ => return Err(malformed("extern", stx.span)),
    };
    let ret = parse_extern_type(&items[2])?;
    Ok(ExternItem {
        span: stx.span,
        name,
        params,
        ret,
    })
}

/// One type atom: the scalar vocabulary (anything else fails
/// closed with the batch's boundary named).
fn parse_extern_type(stx: &SyntaxObject) -> Result<ExternType, ExpandError> {
    require_runtime(stx)?;
    let ty = symbol_sym(stx).ok_or_else(|| malformed("extern", stx.span))?;
    match ty.as_str() {
        "int" => Ok(ExternType::Int),
        "bool" => Ok(ExternType::Bool),
        "float" => Ok(ExternType::Float),
        _ => Err(ExpandError::ExternTypeUnsupported {
            ty: ty.clone(),
            span: stx.span,
        }),
    }
}

/// Within one block: duplicate canonical identities reject (the
/// language-level identity check — expressible in the .ktf twin
/// since the r122 refresh). The derived-C-symbol faces (legality,
/// dash/underscore collision) are NOT expander semantics since the
/// r123 re-attribution (W-CSYM-EXPR ruling b): they are C-domain
/// product constraints, judged at `compile`/`verify` through
/// `extern_table_floor` — the twin boundary retired with them.
fn reject_within_block_collisions(items: &[ExternItem]) -> Result<(), ExpandError> {
    let mut canonical: HashSet<&Symbol> = HashSet::new();
    for item in items {
        if !canonical.insert(&item.name) {
            return Err(ExpandError::ExternNameCollision {
                name: item.name.clone(),
                span: item.span,
            });
        }
    }
    Ok(())
}

/// The declaration-list post-pass (W-3.2): extern contracts ride the
/// flat global/C namespace, so a canonical-identity clash with a
/// same-list define, another extern block's item, or a Stage 0
/// global rejects fail-closed (a define would otherwise shadow the
/// contract by store order — silent contract death). Runs on every
/// declaration list; nested lists hold no externs (the
/// top-level-only ruling), so the pass is a no-op there by
/// construction.
fn reject_extern_collisions(items: &[ModuleItem]) -> Result<(), ExpandError> {
    let mut externs: Vec<(&Symbol, Span)> = Vec::new();
    let mut defines: HashSet<&Symbol> = HashSet::new();
    for item in items {
        match item {
            ModuleItem::Define { name, .. } => {
                defines.insert(name);
            }
            ModuleItem::Extern { items, .. } => {
                for entry in items {
                    externs.push((&entry.name, entry.span));
                }
            }
            // Only defines and externs contribute to this collection
            // (nested modules and effect declarations do not).
            _ => {}
        }
    }
    if externs.is_empty() {
        return Ok(());
    }
    for (name, span) in externs {
        if defines.contains(name) || stage0_global_symbols().contains(name) {
            return Err(ExpandError::ExternNameCollision {
                name: name.clone(),
                span,
            });
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    //! Unit tests for the expansion loop (sub-stage test doc FP2-FP4).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};
    use kerf_syntax::ScopeSet;

    fn sp(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sym(start: u32, end: u32, text: &str) -> SyntaxObject {
        SyntaxObject::symbol(sp(start, end), ScopeSet::new(), Phase::Runtime, text)
            .expect("test fixture symbol must be valid")
    }

    fn int(start: u32, end: u32, value: i64) -> SyntaxObject {
        SyntaxObject::int(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
    }

    fn lst(start: u32, end: u32, items: Vec<SyntaxObject>) -> SyntaxObject {
        SyntaxObject::list(sp(start, end), ScopeSet::new(), Phase::Runtime, items)
    }

    // ---------- positive ----------

    #[test]
    fn atoms_expand_to_their_literal_kinds() {
        let mut ctx = ExpandCtx::new();
        let cases = [
            (int(0, 2, 42), "literal"),
            (
                SyntaxObject::float(sp(0, 3), ScopeSet::new(), Phase::Runtime, 2.5),
                "literal",
            ),
            (
                SyntaxObject::bool(sp(0, 2), ScopeSet::new(), Phase::Runtime, true),
                "literal",
            ),
            (
                SyntaxObject::string(sp(0, 3), ScopeSet::new(), Phase::Runtime, "s".to_owned()),
                "literal",
            ),
            // `nil` is the reserved literal keyword.
            (sym(0, 3, "nil"), "literal"),
        ];
        for (stx, kind) in &cases {
            let expr = expand(&mut ctx, stx).expect("atom must expand");
            assert_eq!(expr.kind_name(), *kind);
        }
        let nil_expr = expand(&mut ctx, &sym(0, 3, "nil")).expect("nil expands");
        assert_eq!(
            nil_expr,
            CoreExpr::Literal {
                span: sp(0, 3),
                value: LiteralValue::Nil
            }
        );
    }

    #[test]
    fn param_reference_resolves_through_coloring() {
        let mut ctx = ExpandCtx::new();
        // (fn (x) x)
        let form = lst(
            0,
            9,
            vec![
                sym(0, 2, "fn"),
                lst(4, 7, vec![sym(5, 6, "x")]),
                sym(8, 9, "x"),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("fn form must expand");
        match expr {
            CoreExpr::Fn { params, body, .. } => {
                assert_eq!(params.len(), 1);
                assert_eq!(params[0].as_str(), "x");
                assert_eq!(*body, CoreExpr::var(sp(8, 9), "x").unwrap());
            }
            other => panic!("expected fn, got {other}"),
        }
    }

    #[test]
    fn let_binds_progressively_like_let_star() {
        let mut ctx = ExpandCtx::new();
        // (let ((a 1) (b a)) b) — b's value sees a (let* order).
        let form = lst(
            0,
            22,
            vec![
                sym(0, 3, "let"),
                lst(
                    5,
                    15,
                    vec![
                        lst(6, 10, vec![sym(7, 8, "a"), int(9, 10, 1)]),
                        lst(12, 15, vec![sym(13, 14, "b"), sym(14, 15, "a")]),
                    ],
                ),
                sym(18, 19, "b"),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("let form must expand");
        match expr {
            CoreExpr::Let { bindings, body, .. } => {
                assert_eq!(bindings.len(), 2);
                assert_eq!(bindings[0].name.as_str(), "a");
                assert_eq!(bindings[1].name.as_str(), "b");
                // b's value is a Var reference to a — visible in let* order.
                assert_eq!(bindings[1].value, CoreExpr::var(sp(14, 15), "a").unwrap());
                assert_eq!(*body, CoreExpr::var(sp(18, 19), "b").unwrap());
            }
            other => panic!("expected let, got {other}"),
        }
    }

    #[test]
    fn do_desugars_to_discard_let_chain() {
        let mut ctx = ExpandCtx::new();
        // (do 1 2) → Let{[_ ← 1], 2}
        let form = lst(0, 8, vec![sym(0, 2, "do"), int(3, 4, 1), int(6, 7, 2)]);
        let expr = expand(&mut ctx, &form).expect("do form must expand");
        match expr {
            CoreExpr::Let { bindings, body, .. } => {
                assert_eq!(bindings.len(), 1);
                assert_eq!(bindings[0].name.as_str(), "_");
                assert_eq!(
                    bindings[0].value,
                    CoreExpr::Literal {
                        span: sp(3, 4),
                        value: LiteralValue::Int(1)
                    }
                );
                assert_eq!(
                    *body,
                    CoreExpr::Literal {
                        span: sp(6, 7),
                        value: LiteralValue::Int(2)
                    }
                );
            }
            other => panic!("expected let, got {other}"),
        }
        // (do e) is the identity.
        let single = lst(0, 6, vec![sym(0, 2, "do"), int(3, 4, 9)]);
        let expr = expand(&mut ctx, &single).expect("single-form do expands");
        assert_eq!(
            expr,
            CoreExpr::Literal {
                span: sp(3, 4),
                value: LiteralValue::Int(9)
            }
        );
    }

    #[test]
    fn fn_if_apply_compose_the_fib_shape() {
        let mut ctx = ExpandCtx::new();
        // (fn (n) (if (< n 2) n (+ n 1))) — globals `<` and `+`.
        let form = lst(
            0,
            30,
            vec![
                sym(0, 2, "fn"),
                lst(4, 7, vec![sym(5, 6, "n")]),
                lst(
                    8,
                    29,
                    vec![
                        sym(9, 11, "if"),
                        lst(
                            13,
                            19,
                            vec![sym(14, 15, "<"), sym(16, 17, "n"), int(18, 19, 2)],
                        ),
                        sym(21, 22, "n"),
                        lst(
                            24,
                            29,
                            vec![sym(25, 26, "+"), sym(27, 28, "n"), int(28, 29, 1)],
                        ),
                    ],
                ),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("fib shape must expand");
        match expr {
            CoreExpr::Fn { body, .. } => match *body {
                CoreExpr::If {
                    cond,
                    then_branch,
                    else_branch,
                    ..
                } => {
                    assert!(matches!(*cond, CoreExpr::Apply { .. }));
                    assert_eq!(*then_branch, CoreExpr::var(sp(21, 22), "n").unwrap());
                    assert!(matches!(*else_branch, CoreExpr::Apply { .. }));
                }
                other => panic!("expected if body, got {other}"),
            },
            other => panic!("expected fn, got {other}"),
        }
    }

    // ---------- negative ----------

    #[test]
    fn unbound_symbol_fails_with_name_and_span() {
        let mut ctx = ExpandCtx::new();
        let err = expand(&mut ctx, &sym(7, 10, "fib")).expect_err("fib must be unbound");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("fib").expect("fixture symbol must be valid"),
                span: sp(7, 10)
            }
        );
    }

    #[test]
    fn unbound_in_operand_position_fails() {
        let mut ctx = ExpandCtx::new();
        // (+ 1 undefined-thing)
        let form = lst(
            0,
            21,
            vec![sym(1, 2, "+"), int(4, 5, 1), sym(7, 21, "undefined-thing")],
        );
        let err = expand(&mut ctx, &form).expect_err("operand must be unbound");
        match err {
            ExpandError::UnboundIdentifier { name, span } => {
                assert_eq!(name.as_str(), "undefined-thing");
                assert_eq!(span, sp(7, 21));
            }
            other => panic!("expected unbound identifier, got {other}"),
        }
    }

    #[test]
    fn empty_synthesized_form_is_rejected() {
        let mut ctx = ExpandCtx::new();
        let form = lst(0, 2, vec![]);
        let err = expand(&mut ctx, &form).expect_err("empty form must fail");
        assert_eq!(err, ExpandError::EmptyForm { span: sp(0, 2) });
    }

    #[test]
    fn macro_phase_syntax_is_rejected() {
        let mut ctx = ExpandCtx::new();
        let form = SyntaxObject::symbol(sp(0, 3), ScopeSet::new(), Phase::MacroExpansion, "x")
            .expect("fixture symbol must be valid");
        let err = expand(&mut ctx, &form).expect_err("macro-phase must fail");
        assert_eq!(
            err,
            ExpandError::PhaseViolation {
                phase: Phase::MacroExpansion,
                span: sp(0, 3)
            }
        );
    }

    #[test]
    fn fn_without_body_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (fn (x))
        let form = lst(0, 8, vec![sym(0, 2, "fn"), lst(4, 7, vec![sym(5, 6, "x")])]);
        let err = expand(&mut ctx, &form).expect_err("fn without body must fail");
        assert_eq!(err, malformed("fn", sp(0, 8)));
    }

    #[test]
    fn if_with_two_operands_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (if 1 2)
        let form = lst(0, 8, vec![sym(0, 2, "if"), int(4, 5, 1), int(6, 7, 2)]);
        let err = expand(&mut ctx, &form).expect_err("two-armed if must fail");
        assert_eq!(err, malformed("if", sp(0, 8)));
    }

    #[test]
    fn let_with_short_binding_pair_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (let ((x)) x)
        let form = lst(
            0,
            13,
            vec![
                sym(0, 3, "let"),
                lst(5, 9, vec![lst(6, 9, vec![sym(7, 8, "x")])]),
                sym(11, 12, "x"),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("short pair must fail");
        assert_eq!(err, malformed("let", sp(0, 13)));
    }

    #[test]
    fn duplicate_params_reassert_via_core() {
        let mut ctx = ExpandCtx::new();
        // (fn (x x) x)
        let form = lst(
            0,
            12,
            vec![
                sym(0, 2, "fn"),
                lst(4, 9, vec![sym(5, 6, "x"), sym(7, 8, "x")]),
                sym(11, 12, "x"),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("duplicate params must fail");
        match err {
            ExpandError::Core { source, .. } => {
                assert_eq!(
                    source,
                    kerf_core::CoreError::DuplicateParam {
                        // §9.65 EXP-4: interned identity payload.
                        name: Symbol::new("x").expect("fixture symbol must be valid")
                    }
                );
            }
            other => panic!("expected core error, got {other}"),
        }
    }

    #[test]
    fn duplicate_handlers_reassert_via_core() {
        let mut ctx = ExpandCtx::new();
        // (handle 1 (E 2) (E 3)) — literal handlers keep the
        // duplicate check the first failure.
        let form = lst(
            0,
            20,
            vec![
                sym(0, 6, "handle"),
                int(7, 8, 1),
                lst(9, 14, vec![sym(10, 11, "E"), int(13, 14, 2)]),
                lst(15, 20, vec![sym(16, 17, "E"), int(18, 19, 3)]),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("duplicate handlers must fail");
        match err {
            ExpandError::Core { source, .. } => {
                assert_eq!(
                    source,
                    kerf_core::CoreError::DuplicateHandler {
                        // §9.65 EXP-5: interned identity payload.
                        effect: Symbol::new("E").expect("fixture symbol must be valid")
                    }
                );
            }
            other => panic!("expected core error, got {other}"),
        }
    }

    #[test]
    fn bare_top_level_expression_is_rejected() {
        // (fib 10) at module top level.
        let form = lst(0, 8, vec![sym(1, 4, "fib"), int(5, 7, 10)]);
        let err = expand_program(&[form]).expect_err("bare expression must fail");
        assert_eq!(err, ExpandError::TopLevelExpression { span: sp(0, 8) });
    }

    #[test]
    fn set_to_unbound_target_fails() {
        let mut ctx = ExpandCtx::new();
        // (set! nope 1)
        let form = lst(
            0,
            12,
            vec![sym(0, 4, "set!"), sym(5, 9, "nope"), int(10, 11, 1)],
        );
        let err = expand(&mut ctx, &form).expect_err("unbound set! target must fail");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("nope").expect("fixture symbol must be valid"),
                span: sp(5, 9)
            }
        );
    }

    #[test]
    fn deep_tree_hits_the_expansion_budget_exactly() {
        // A pure-application chain of nesting N recurses N+1 levels
        // deep (the head atom adds one transient level), so nesting
        // EXPANSION_LIMIT - 1 passes and nesting EXPANSION_LIMIT
        // fails — the budget boundary in both directions. The head is
        // a Stage 0 global and the innermost atom a literal so the
        // only possible failure is the budget itself.
        let build = |depth: usize| {
            let mut node = int(0, 1, 42);
            for _ in 0..depth {
                node = lst(0, 2, vec![sym(0, 1, "+"), node]);
            }
            node
        };
        let mut ctx = ExpandCtx::new();
        let within = build(crate::EXPANSION_LIMIT - 1);
        expand(&mut ctx, &within).expect("within-budget tree must expand");
        let beyond = build(crate::EXPANSION_LIMIT);
        let err = expand(&mut ctx, &beyond).expect_err("over-budget tree must fail");
        assert_eq!(
            err,
            ExpandError::ExpansionDepthExceeded {
                limit: crate::EXPANSION_LIMIT,
                span: sp(0, 1)
            }
        );
    }

    // ---------- sub-stage 0.9: quote ----------

    #[test]
    fn quote_atoms_expand_to_their_literal_kinds() {
        let mut ctx = ExpandCtx::new();
        let cases = [
            (int(0, 2, 42), "int"),
            (
                SyntaxObject::float(sp(0, 3), ScopeSet::new(), Phase::Runtime, 2.5),
                "float",
            ),
            (
                SyntaxObject::bool(sp(0, 4), ScopeSet::new(), Phase::Runtime, true),
                "bool",
            ),
            (
                SyntaxObject::string(sp(0, 3), ScopeSet::new(), Phase::Runtime, "s".to_owned()),
                "string",
            ),
            // The reserved literal keyword quotes to Nil.
            (sym(0, 3, "nil"), "nil"),
        ];
        for (stx, kind) in &cases {
            let quoted = lst(0, 10, vec![sym(0, 5, "quote"), stx.clone()]);
            let expr = expand(&mut ctx, &quoted).expect("atom quote must expand");
            let value = match &expr {
                CoreExpr::Literal { value, .. } => value.clone(),
                other => panic!("expected a literal, got {other:?}"),
            };
            assert_eq!(value.kind_name(), *kind);
        }
    }

    #[test]
    fn quote_list_folds_into_a_pair_chain() {
        // (quote (1 2 3)) → Pair(1, Pair(2, Pair(3, Nil))) — the 0.1
        // LiteralValue::Pair consumption face.
        let mut ctx = ExpandCtx::new();
        let datum = lst(7, 14, vec![int(8, 9, 1), int(10, 11, 2), int(12, 13, 3)]);
        let quoted = lst(0, 16, vec![sym(0, 5, "quote"), datum]);
        let expr = expand(&mut ctx, &quoted).expect("list quote must expand");
        match &expr {
            CoreExpr::Literal {
                value: LiteralValue::Pair(a, b),
                ..
            } => {
                assert_eq!(**a, LiteralValue::Int(1));
                match &**b {
                    LiteralValue::Pair(c, d) => {
                        assert_eq!(**c, LiteralValue::Int(2));
                        match &**d {
                            LiteralValue::Pair(e, f) => {
                                assert_eq!(**e, LiteralValue::Int(3));
                                assert_eq!(**f, LiteralValue::Nil);
                            }
                            other => panic!("expected the innermost pair, got {other:?}"),
                        }
                    }
                    other => panic!("expected the middle pair, got {other:?}"),
                }
            }
            other => panic!("expected a pair chain, got {other:?}"),
        }
    }

    #[test]
    fn quote_rejects_symbol_datums() {
        let mut ctx = ExpandCtx::new();
        let quoted = lst(0, 10, vec![sym(0, 5, "quote"), sym(7, 9, "x")]);
        let err = expand(&mut ctx, &quoted).expect_err("a bare symbol quote must fail closed");
        assert_eq!(err, ExpandError::QuoteUnsupportedDatum { span: sp(7, 9) });
    }

    #[test]
    fn quote_rejects_nested_symbol_datums() {
        let mut ctx = ExpandCtx::new();
        // (quote (1 x)) — the nested symbol carries the error span.
        let datum = lst(7, 12, vec![int(8, 9, 1), sym(10, 11, "x")]);
        let quoted = lst(0, 14, vec![sym(0, 5, "quote"), datum]);
        let err = expand(&mut ctx, &quoted).expect_err("a nested symbol quote must fail closed");
        assert_eq!(err, ExpandError::QuoteUnsupportedDatum { span: sp(10, 11) });
    }

    #[test]
    fn quote_rejects_wrong_arity() {
        let mut ctx = ExpandCtx::new();
        // (quote) — zero datums.
        let empty = lst(0, 7, vec![sym(0, 5, "quote")]);
        let err = expand(&mut ctx, &empty).expect_err("zero-datum quote must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "quote"));
        // (quote 1 2) — two datums.
        let extra = lst(0, 12, vec![sym(0, 5, "quote"), int(6, 7, 1), int(8, 9, 2)]);
        let err = expand(&mut ctx, &extra).expect_err("two-datum quote must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "quote"));
    }

    // ---------- sub-stage 0.9: define-syntax + macro use ----------

    /// (define-syntax my-if (syntax-rules () ((_ c t e) (if c t e))))
    fn define_syntax_my_if() -> SyntaxObject {
        let clause = lst(
            40,
            63,
            vec![
                lst(
                    41,
                    50,
                    vec![
                        sym(42, 43, "_"),
                        sym(44, 45, "c"),
                        sym(46, 47, "t"),
                        sym(48, 49, "e"),
                    ],
                ),
                lst(
                    51,
                    62,
                    vec![
                        sym(52, 54, "if"),
                        sym(55, 56, "c"),
                        sym(57, 58, "t"),
                        sym(59, 60, "e"),
                    ],
                ),
            ],
        );
        lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "my-if"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        )
    }

    #[test]
    fn define_syntax_emits_the_declaration_record() {
        let items = expand_program(&[define_syntax_my_if()]).expect("declaration must expand");
        assert_eq!(items.len(), 1);
        assert_eq!(items[0].kind_name(), "define-syntax");
        assert_eq!(items[0].span(), sp(0, 70));
    }

    #[test]
    fn macro_use_expands_to_the_core_form_shape() {
        // (define r (my-if true 1 2)) — the spliced condition keeps
        // its own span; the introduced `if` is generation 1.
        let use_form = lst(
            80,
            100,
            vec![
                sym(81, 86, "my-if"),
                SyntaxObject::bool(sp(87, 91), ScopeSet::new(), Phase::Runtime, true),
                int(92, 93, 1),
                int(94, 95, 2),
            ],
        );
        let program = lst(
            79,
            108,
            vec![sym(80, 86, "define"), sym(87, 88, "r"), use_form],
        );
        let items =
            expand_program(&[define_syntax_my_if(), program]).expect("the macro use must expand");
        let value = match &items[1] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::If { cond, .. } => {
                // The spliced condition kept its use-site span.
                assert_eq!(cond.span(), sp(87, 91));
            }
            other => panic!("expected an if, got {other:?}"),
        }
    }

    #[test]
    fn unbound_head_fails_closed_as_an_identifier() {
        // A head naming nothing is ambiguous between a function call
        // and a macro use: the unified Racket judgment — one
        // UnboundIdentifier error serves both (the dedicated
        // macro-phase family starts at pattern matching).
        let mut ctx = ExpandCtx::new();
        let use_form = lst(0, 6, vec![sym(0, 5, "ghost"), int(0, 1, 1)]);
        let err = expand(&mut ctx, &use_form).expect_err("an unbound head must fail");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("ghost").expect("fixture symbol must be valid"),
                span: sp(0, 5)
            }
        );
    }

    #[test]
    fn use_before_definition_is_unbound() {
        // The use form comes first: the transformer is not yet
        // registered (sequential declaration order) — the head falls
        // through to the unified unbound-identifier judgment.
        let use_form = lst(
            0,
            22,
            vec![
                sym(1, 6, "my-if"),
                sym(7, 11, "true"),
                int(12, 13, 1),
                int(14, 15, 2),
            ],
        );
        let program = lst(
            23,
            50,
            vec![sym(24, 30, "define"), sym(31, 32, "r"), use_form],
        );
        let err = expand_program(&[program, define_syntax_my_if()])
            .expect_err("use before definition must fail");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "my-if")
        );
    }

    #[test]
    fn pattern_mismatch_reports_the_macro_name() {
        // (my-if true 1) — three operands demanded, two supplied.
        let use_form = lst(
            80,
            95,
            vec![sym(81, 86, "my-if"), sym(87, 91, "true"), int(92, 93, 1)],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), use_form],
        );
        let err = expand_program(&[define_syntax_my_if(), program])
            .expect_err("a pattern mismatch must fail closed");
        // The use head's span (the rustc convention: point at the
        // call, not the declaration).
        assert_eq!(
            err,
            ExpandError::MacroPatternMismatch {
                name: Symbol::new("my-if").expect("fixture symbol must be valid"),
                span: sp(81, 86)
            }
        );
    }

    #[test]
    fn self_recursive_macro_hits_the_depth_budget() {
        // (define-syntax loopy (syntax-rules () ((_) (loopy))))
        let clause = lst(
            40,
            56,
            vec![
                lst(41, 45, vec![sym(42, 43, "_")]),
                lst(46, 55, vec![sym(47, 52, "loopy")]),
            ],
        );
        let loopy_def = lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "loopy"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        );
        let use_form = lst(80, 88, vec![sym(81, 86, "loopy")]);
        let program = lst(
            90,
            110,
            vec![sym(91, 97, "define"), sym(98, 99, "r"), use_form],
        );
        let err = expand_program(&[loopy_def, program])
            .expect_err("a self-recursive macro must hit the budget");
        assert!(matches!(err, ExpandError::ExpansionDepthExceeded { .. }));
    }

    #[test]
    fn module_scoped_macros_vanish_outside_their_module() {
        // (module inner (define-syntax ...)) then a top-level use:
        // the inner frame (with the macro) is popped — the head falls
        // through to the unified unbound-identifier judgment
        // (docs/stage0.md §8.9 module isolation).
        let module_form = lst(
            0,
            70,
            vec![
                sym(1, 7, "module"),
                sym(8, 13, "inner"),
                define_syntax_my_if(),
            ],
        );
        let use_form = lst(
            80,
            100,
            vec![
                sym(81, 86, "my-if"),
                sym(87, 91, "true"),
                int(92, 93, 1),
                int(94, 95, 2),
            ],
        );
        let program = lst(
            101,
            125,
            vec![sym(102, 108, "define"), sym(109, 110, "r"), use_form],
        );
        let err = expand_program(&[module_form, program])
            .expect_err("a module-scoped macro must vanish outside");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "my-if")
        );
    }

    #[test]
    fn define_syntax_rejects_malformed_shapes() {
        // Two items only: (define-syntax m).
        let bad = lst(0, 20, vec![sym(1, 14, "define-syntax"), sym(15, 16, "m")]);
        let err = expand_program(&[bad]).expect_err("a two-item define-syntax must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
        // Reserved name: (define-syntax if ...).
        let mut reserved = define_syntax_my_if();
        if let StxDatum::List(items) = &mut reserved.datum {
            items[1] = sym(15, 17, "if");
        }
        let err = expand_program(&[reserved]).expect_err("a reserved macro name must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
        // Non-symbol name: (define-syntax 7 ...).
        let mut numbered = define_syntax_my_if();
        if let StxDatum::List(items) = &mut numbered.datum {
            items[1] = int(15, 16, 7);
        }
        let err = expand_program(&[numbered]).expect_err("a non-symbol macro name must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
    }

    // ---------- sub-stage 0.9: hygiene (defense family) ----------

    /// (define-syntax m (syntax-rules () ((_ e) (fn (tmp) (tmp e)))))
    /// — an introduced binding with an introduced reference around a
    /// spliced use-site expression.
    fn define_syntax_wrap() -> SyntaxObject {
        let clause = lst(
            40,
            70,
            vec![
                lst(41, 45, vec![sym(42, 43, "_"), sym(44, 45, "e")]),
                lst(
                    46,
                    69,
                    vec![
                        sym(47, 49, "fn"),
                        lst(50, 56, vec![sym(51, 54, "tmp")]),
                        lst(57, 68, vec![sym(58, 61, "tmp"), sym(62, 63, "e")]),
                    ],
                ),
            ],
        );
        lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 16, "m"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        )
    }

    #[test]
    fn introduced_binding_renames_away_from_the_use_site_name() {
        // (define f (fn (tmp) (m tmp))) — the use-site `tmp` argument
        // collides with the introduced binder: rename-on-capture makes
        // the introduced binder `tmp__macro_0` so the name-based back
        // half cannot conflate them. The expansion succeeds and the
        // introduced parameter carries the fresh name.
        let use_form = lst(80, 90, vec![sym(81, 82, "m"), sym(83, 86, "tmp")]);
        let inner = lst(
            71,
            92,
            vec![
                sym(72, 74, "fn"),
                lst(75, 80, vec![sym(76, 79, "tmp")]),
                use_form,
            ],
        );
        let program = lst(
            93,
            120,
            vec![sym(94, 100, "define"), sym(101, 102, "f"), inner],
        );
        let items = expand_program(&[define_syntax_wrap(), program])
            .expect("the hygienic wrap must expand");
        // Walk to the inner fn's parameter list and assert the fresh
        // name (the introduced binder was renamed, the use-site param
        // was not).
        let value = match &items[1] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::Fn { params, body, .. } => {
                // The use-site parameter keeps its name.
                let names: Vec<&str> = params.iter().map(|p| p.as_str()).collect();
                assert_eq!(names, vec!["tmp"]);
                // The body is the introduced fn with the renamed
                // parameter.
                match &**body {
                    CoreExpr::Fn {
                        params: inner_params,
                        ..
                    } => {
                        let inner_names: Vec<&str> =
                            inner_params.iter().map(|p| p.as_str()).collect();
                        assert_eq!(inner_names, vec!["tmp__macro_0"]);
                    }
                    other => panic!("expected the introduced fn, got {other:?}"),
                }
            }
            other => panic!("expected the outer fn, got {other:?}"),
        }
    }

    #[test]
    fn use_site_binding_does_not_capture_an_introduced_reference() {
        // (define-syntax m (syntax-rules () ((_) tmp))) — a free
        // introduced reference to `tmp`, unbound at the definition
        // site. Used inside a let that binds tmp: the coloring keeps
        // the introduced reference apart from the use-site binding, so
        // the reference stays unbound — exactly the Racket judgment
        // (no accidental capture), reported fail-closed.
        let clause = lst(
            40,
            50,
            vec![lst(41, 44, vec![sym(42, 43, "_")]), sym(45, 48, "tmp")],
        );
        let def = lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 16, "m"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        );
        // (define r (let ((tmp 1)) (m)))
        let use_form = lst(80, 84, vec![sym(81, 82, "m")]);
        let let_form = lst(
            71,
            95,
            vec![
                sym(72, 75, "let"),
                lst(
                    76,
                    85,
                    vec![lst(77, 84, vec![sym(78, 81, "tmp"), int(82, 83, 1)])],
                ),
                use_form,
            ],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), let_form],
        );
        let err = expand_program(&[def, program])
            .expect_err("the introduced free reference must stay unbound");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "tmp")
        );
    }

    #[test]
    fn error_payloads_round_trip_through_the_single_pool() {
        // §9.65 EXP-1/EXP-2: name payloads are interned identities.
        // The expected values are built through the single pool — the
        // equality holds only because both sides resolve to the same
        // interned entry (index equality), which is exactly the
        // contract the parity decoder depends on when it
        // rebuilds a payload from oracle text. A de-interned String
        // copy would compare by text; a Symbol payload compares by
        // pool entry — this guard pins the stronger contract.
        // (1) unbound identifier from source.
        let mut ctx = ExpandCtx::new();
        let err =
            expand(&mut ctx, &sym(3, 11, "pool-probe")).expect_err("pool-probe must be unbound");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("pool-probe").expect("fixture symbol must be valid"),
                span: sp(3, 11)
            }
        );
        // (2) macro mismatch from a registered transformer: the error
        // carries the declaration-time pool entry, not a fresh copy.
        let clause = lst(
            40,
            56,
            vec![
                lst(41, 50, vec![sym(42, 43, "_"), sym(44, 49, "true")]),
                int(50, 51, 1),
            ],
        );
        let spec = lst(
            21,
            65,
            vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
        );
        let def = lst(
            0,
            70,
            vec![sym(1, 14, "define-syntax"), sym(15, 20, "probe-m"), spec],
        );
        let use_form = lst(
            80,
            95,
            vec![sym(81, 88, "probe-m"), sym(89, 93, "true"), int(93, 94, 2)],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), use_form],
        );
        let err =
            expand_program(&[def, program]).expect_err("arity mismatch must fail every clause");
        assert_eq!(
            err,
            ExpandError::MacroPatternMismatch {
                name: Symbol::new("probe-m").expect("fixture symbol must be valid"),
                span: sp(81, 88)
            }
        );
    }

    #[test]
    fn macro_product_generation_increments_per_hop() {
        // (define-syntax outer (syntax-rules () ((_) (inner))))
        // (define-syntax inner (syntax-rules () ((_) 7)))
        // (define r (outer)) — two macro hops: the final literal is
        // generation 2, the intermediate use form generation 1.
        let inner_clause = lst(
            40,
            52,
            vec![lst(41, 44, vec![sym(42, 43, "_")]), int(45, 46, 7)],
        );
        let inner_def = lst(
            0,
            60,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "inner"),
                lst(
                    21,
                    55,
                    vec![
                        sym(22, 34, "syntax-rules"),
                        sym(35, 38, "nil"),
                        inner_clause,
                    ],
                ),
            ],
        );
        let outer_clause = lst(
            40,
            56,
            vec![
                lst(41, 44, vec![sym(42, 43, "_")]),
                // The template is the *form* (inner), not the bare
                // identifier — macro dispatch happens on list heads
                // only (the Stage 0 boundary).
                lst(45, 52, vec![sym(46, 51, "inner")]),
            ],
        );
        let outer_def = lst(
            0,
            60,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "outer"),
                lst(
                    21,
                    55,
                    vec![
                        sym(22, 34, "syntax-rules"),
                        sym(35, 38, "nil"),
                        outer_clause,
                    ],
                ),
            ],
        );
        let use_form = lst(80, 88, vec![sym(81, 86, "outer")]);
        let program = lst(
            90,
            110,
            vec![sym(91, 97, "define"), sym(98, 99, "r"), use_form],
        );
        let items = expand_program(&[outer_def, inner_def, program]).expect("two hops must expand");
        let value = match &items[2] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::Literal { span, .. } => {
                // The literal came from inner's template: generation 2
                // (outer's product was generation 1, inner's
                // use-generation was 1, its introduced nodes are 2).
                assert_eq!(span.expansion_id, ExpansionId(2));
            }
            other => panic!("expected the final literal, got {other:?}"),
        }
    }

    #[test]
    fn top_level_heads_match_dispatch_table() {
        // §9.62 SURF-2: TOP_LEVEL_DECLARATION_HEADS is the single
        // source the driver's REPL consumes. This test pins the const
        // to the dispatch: every const member must take a declaration
        // arm (never a top-level-expression rejection — that is the
        // fail-closed hole a const member without an arm would fall
        // into), and every non-member head must be rejected as a bare
        // top-level expression.
        for head in TOP_LEVEL_DECLARATION_HEADS {
            let mut ctx = ExpandCtx::new();
            let form = lst(
                0,
                8,
                vec![sym(1, (1 + head.len()) as u32, head), sym(40, 44, "x")],
            );
            // Any non-TopLevelExpression outcome (a successful module
            // item or a declaration-specific error such as
            // MalformedForm or a module-load error) proves the head
            // took its dispatch arm.
            if let Err(ExpandError::TopLevelExpression { .. }) = expand_declaration(&mut ctx, &form)
            {
                panic!("const member `{head}` has no dispatch arm");
            }
        }
        for head in ["if", "+", "frobnicate", "set!"] {
            let mut ctx = ExpandCtx::new();
            let form = lst(
                0,
                8,
                vec![sym(1, (1 + head.len()) as u32, head), sym(40, 44, "x")],
            );
            match expand_declaration(&mut ctx, &form) {
                Err(ExpandError::TopLevelExpression { .. }) => {}
                other => panic!("non-member `{head}` must reject: {other:?}"),
            }
        }
    }

    // ---------- the W-3.2 extern family ----------

    /// `(extern ["abi"] (name (types...) ret) ...)` as a Stx tree.
    fn extern_form(abi: Option<&str>, entries: &[(&str, &[&str], &str)]) -> SyntaxObject {
        let mut items: Vec<SyntaxObject> = vec![sym(0, 6, "extern")];
        if let Some(abi) = abi {
            items.push(SyntaxObject::string(
                sp(7, 10),
                ScopeSet::new(),
                Phase::Runtime,
                std::rc::Rc::from(abi),
            ));
        }
        for (name, params, ret) in entries {
            let param_items: Vec<SyntaxObject> = params
                .iter()
                .enumerate()
                .map(|(i, t)| sym(20 + (i as u32) * 4, 24 + (i as u32) * 4, t))
                .collect();
            items.push(lst(
                20,
                60,
                vec![
                    sym(20, 24, name),
                    lst(25, 40, param_items),
                    sym(45, 49, ret),
                ],
            ));
        }
        lst(0, 70, items)
    }

    fn extern_items(entries: &[(&str, &[&str], &str)]) -> Vec<ModuleItem> {
        expand_program(&[extern_form(Some("C"), entries)]).expect("the extern form expands")
    }

    fn extern_err(form: SyntaxObject) -> ExpandError {
        expand_program(&[form]).expect_err("the rejection must fire")
    }

    #[test]
    fn extern_names_resolve_before_their_declaration() {
        // The bind-first discipline: a call site may precede the
        // extern block (the letrec pre-bind mirror applied to
        // declarations).
        let call = lst(
            0,
            20,
            vec![
                sym(1, 7, "define"),
                sym(8, 14, "result"),
                lst(
                    15,
                    19,
                    vec![sym(15, 18, "add"), int(16, 17, 2), int(18, 19, 40)],
                ),
            ],
        );
        let block = extern_form(Some("C"), &[("add", &["int", "int"], "int")]);
        let items = expand_program(&[call, block]).expect("bind-first holds");
        assert!(matches!(items[0], ModuleItem::Define { .. }));
        assert!(matches!(items[1], ModuleItem::Extern { .. }));
    }

    #[test]
    fn extern_expands_to_the_contract_record() {
        let items = extern_items(&[("add", &["int", "int"], "int"), ("t", &["bool"], "bool")]);
        match &items[0] {
            ModuleItem::Extern { abi, items, .. } => {
                assert_eq!(*abi, ExternAbi::C);
                assert_eq!(items.len(), 2);
                assert_eq!(items[0].name.as_str(), "add");
                assert_eq!(items[0].params, vec![ExternType::Int, ExternType::Int]);
                assert_eq!(items[0].ret, ExternType::Int);
                assert_eq!(items[1].ret, ExternType::Bool);
            }
            other => panic!("an extern record, got `{other}`"),
        }
    }

    #[test]
    fn extern_rejects_nested_module_placement() {
        let inner = extern_form(Some("C"), &[("add", &["int"], "int")]);
        let module = lst(0, 80, vec![sym(0, 6, "module"), sym(7, 8, "m"), inner]);
        let err = expand_program(&[module]).expect_err("the nesting rejects");
        assert!(
            matches!(err, ExpandError::ExternNotTopLevel { .. }),
            "the flat-C-namespace ruling: {err:?}"
        );
    }

    #[test]
    fn extern_rejects_within_block_duplicate_and_bad_symbol() {
        // Duplicate canonical identity in one block — the
        // language-level identity check stays at the expander (the
        // twin expresses it since r122).
        let err = extern_err(extern_form(
            Some("C"),
            &[("add", &["int"], "int"), ("add", &["bool"], "bool")],
        ));
        assert!(matches!(err, ExpandError::ExternNameCollision { .. }));
        // The r123 re-attribution (W-CSYM-EXPR ruling b): the
        // derived-C-symbol faces — dash/underscore collision and C
        // identifier legality — are C-domain product constraints,
        // no longer expander semantics. Both engines ACCEPT at
        // expansion (the twin boundary retired); `compile`/`verify`
        // reject through `extern_table_floor` (the compile-side
        // unit tests pin those verdicts).
        let items = expand_program(std::slice::from_ref(&extern_form(
            Some("C"),
            &[("my-add", &["int"], "int"), ("my_add", &["int"], "int")],
        )))
        .expect("the derived-collision spelling pair now expands");
        assert_eq!(items.len(), 1);
        let items = expand_program(std::slice::from_ref(&extern_form(
            Some("C"),
            &[("set!", &["int"], "int")],
        )))
        .expect("the C-invalid name now expands");
        assert_eq!(items.len(), 1);
    }

    #[test]
    fn extern_rejects_shape_and_carrier_defects() {
        // No items at all.
        let err = extern_err(lst(0, 10, vec![sym(0, 6, "extern"), sym(7, 9, "C")]));
        assert!(matches!(
            err,
            ExpandError::MalformedForm { form: "extern", .. }
        ));
        // A non-list item.
        let err = extern_err(lst(0, 10, vec![sym(0, 6, "extern"), sym(7, 9, "add")]));
        assert!(matches!(
            err,
            ExpandError::MalformedForm { form: "extern", .. }
        ));
        // An unknown ABI string.
        let err = extern_err(extern_form(Some("fastcall"), &[("add", &["int"], "int")]));
        assert!(matches!(err, ExpandError::ExternAbiUnsupported { .. }));
        // An unknown type vocabulary.
        let err = extern_err(extern_form(Some("C"), &[("len-of", &["str"], "int")]));
        assert!(
            matches!(err, ExpandError::ExternTypeUnsupported { ty, .. } if ty.as_str() == "str")
        );
    }

    #[test]
    fn extern_rejects_cross_item_collisions() {
        // extern vs a Stage 0 global (the flat namespace).
        let block = extern_form(Some("C"), &[("car", &["int"], "int")]);
        let err = expand_program(&[block]).expect_err("the builtin clash rejects");
        assert!(
            matches!(&err, ExpandError::ExternNameCollision { name, .. } if name.as_str() == "car"),
            "the builtin clash: {err:?}"
        );
        // extern vs a define (either order).
        let define = lst(
            0,
            20,
            vec![sym(0, 6, "define"), sym(7, 10, "add"), int(11, 12, 3)],
        );
        let block = extern_form(Some("C"), &[("add", &["int"], "int")]);
        let err = expand_program(&[define.clone(), block.clone()])
            .expect_err("define-then-extern rejects");
        assert!(matches!(err, ExpandError::ExternNameCollision { .. }));
        let err = expand_program(&[block, define]).expect_err("extern-then-define rejects");
        assert!(matches!(err, ExpandError::ExternNameCollision { .. }));
    }

    // ---------- the W-3.12 injection channel (injected names) ----------

    fn injected(name: &str) -> Vec<Symbol> {
        vec![Symbol::new(name).expect("fixture symbol passes the floor")]
    }

    #[test]
    fn injected_names_resolve_as_globals_from_any_scope() {
        // The host face: a declared injected name resolves through
        // the flat global fallback — at the top level and from inside
        // a fn body (the extern-names precedent, W-3.12).
        let define = lst(
            0,
            34,
            vec![
                sym(1, 7, "define"),
                sym(8, 14, "result"),
                lst(
                    15,
                    33,
                    vec![
                        sym(15, 17, "fn"),
                        lst(18, 21, vec![sym(19, 20, "x")]),
                        lst(25, 32, vec![sym(25, 37, "source-bytes"), sym(30, 31, "x")]),
                    ],
                ),
            ],
        );
        let items =
            expand_program_with_injected(&[define], &injected("source-bytes")).expect("expands");
        match &items[0] {
            ModuleItem::Define { value, .. } => {
                // The reference rode the fallback (a Var, not a
                // rejection) — the deep shape is the fn's body.
                assert!(matches!(value, CoreExpr::Fn { .. }));
            }
            other => panic!("the define expands, got {other:?}"),
        }
    }

    #[test]
    fn the_empty_set_keeps_the_fail_closed_baseline() {
        // `expand_program` is the injected entry with an empty set:
        // the free reference still fails closed (the unbound
        // identifier rule is the language's own baseline, unchanged
        // by the channel's existence).
        let define = lst(
            0,
            30,
            vec![
                sym(1, 7, "define"),
                sym(8, 14, "result"),
                sym(15, 29, "source-bytes"),
            ],
        );
        let err =
            expand_program(std::slice::from_ref(&define)).expect_err("the free name fails closed");
        assert!(matches!(err, ExpandError::UnboundIdentifier { .. }));
        // And an undeclared name fails even WITH the injected entry
        // active (the acceptance set is exact, never a blanket pass).
        let err =
            expand_program_with_injected(std::slice::from_ref(&define), &injected("other-name"))
                .expect_err("only the declared name is accepted");
        assert!(matches!(err, ExpandError::UnboundIdentifier { .. }));
        // The declared name is the one that passes.
        expand_program_with_injected(&[define], &injected("source-bytes"))
            .expect("the declared name resolves");
    }

    // ---------- the blade 2 struct desugaring (GZ-2) ----------

    /// `struct P { x: i64, y: i64 }` as the canonical carrier form:
    /// `(struct P (x i64) (y i64))`.
    fn struct_form() -> SyntaxObject {
        lst(
            0,
            40,
            vec![
                sym(0, 6, "struct"),
                sym(7, 8, "P"),
                lst(9, 20, vec![sym(10, 11, "x"), sym(12, 15, "i64")]),
                lst(21, 32, vec![sym(22, 23, "y"), sym(24, 27, "i64")]),
            ],
        )
    }

    #[test]
    fn struct_desugars_to_the_define_family_and_records() {
        let items = expand_program(std::slice::from_ref(&struct_form()))
            .expect("the struct declaration desugars");
        // The item family in the pinned emission order: the ctor
        // define, its dann sites (params then ret), one accessor
        // define with its dann sites per field, then the dstruct
        // record.
        let kinds: Vec<&str> = items.iter().map(|i| i.kind_name()).collect();
        assert_eq!(
            kinds,
            vec![
                "define", "dann", "dann", "dann", // the ctor + its sites
                "define", "dann", "dann", // Point-x + its sites
                "define", "dann", "dann", // Point-y + its sites
                "dstruct",
            ]
        );
        // The constructor: the pair-chain body over positional
        // params, anchored at the name ident's span.
        let ModuleItem::Define { name, value, .. } = &items[0] else {
            panic!("the first item is the constructor define");
        };
        assert_eq!(name.as_str(), "P");
        let CoreExpr::Fn { params, body, .. } = value else {
            panic!("the constructor value is a fn");
        };
        assert_eq!(params.len(), 2);
        assert_eq!(params[0].as_str(), "x");
        assert_eq!(params[1].as_str(), "y");
        // The body shape: (cons p0 (cons p1 nil)) — the uniform
        // right fold.
        let CoreExpr::Apply { func, args, .. } = &**body else {
            panic!("the ctor body is a cons application");
        };
        assert!(matches!(&**func, CoreExpr::Var { name, .. } if name.as_str() == "cons"));
        assert_eq!(args.len(), 2);
        let CoreExpr::Apply { args: inner, .. } = &args[1] else {
            panic!("the fold's tail is the nested cons");
        };
        assert!(matches!(
            &inner[1],
            CoreExpr::Literal {
                value: LiteralValue::Nil,
                ..
            }
        ));
        // The accessors: Point-x = car(p), Point-y = car(cdr(p)),
        // each carrying the FIELD ident's span as the Fn span (the
        // dann anchor).
        let ModuleItem::Define { name, value, .. } = &items[4] else {
            panic!("the first accessor");
        };
        assert_eq!(name.as_str(), "P-x");
        let CoreExpr::Fn { span, params, body } = value else {
            panic!("the accessor value is a fn");
        };
        assert_eq!(span.start.0, 10, "the accessor anchors at the field ident");
        assert_eq!(params.len(), 1);
        assert!(matches!(&**body, CoreExpr::Apply { .. }));
        let ModuleItem::Define { name, .. } = &items[7] else {
            panic!("the second accessor");
        };
        assert_eq!(name.as_str(), "P-y");
        // The dstruct record: the name and the field specs in
        // declaration order.
        let ModuleItem::Struct { name, fields, .. } =
            items.last().expect("the dstruct record closes the family")
        else {
            panic!("the last item is the dstruct record");
        };
        assert_eq!(name.as_str(), "P");
        assert_eq!(fields.len(), 2);
        assert_eq!(fields[0].0.as_str(), "x");
        assert_eq!(fields[1].0.as_str(), "y");
    }

    #[test]
    fn struct_unit_desugars_to_the_nil_constructor() {
        let form = lst(0, 16, vec![sym(0, 6, "struct"), sym(7, 11, "Unit")]);
        let items = expand_program(std::slice::from_ref(&form)).expect("the unit struct parses");
        let kinds: Vec<&str> = items.iter().map(|i| i.kind_name()).collect();
        assert_eq!(kinds, vec!["define", "dann", "dstruct"]);
        let ModuleItem::Define { value, .. } = &items[0] else {
            panic!("the ctor define");
        };
        let CoreExpr::Fn { body, .. } = value else {
            panic!("the ctor is a fn");
        };
        assert!(matches!(
            &**body,
            CoreExpr::Literal {
                value: LiteralValue::Nil,
                ..
            }
        ));
    }

    #[test]
    fn struct_police_rejects_the_four_families() {
        // Redeclared: two `struct P` forms — both sites reject.
        let err =
            expand_program(&[struct_form(), struct_form()]).expect_err("the redeclaration rejects");
        assert!(matches!(err, ExpandError::StructRedeclared { name, .. } if name.as_str() == "P"));
        // Reserved: a define that rebinds the struct name.
        let define = lst(
            0,
            20,
            vec![sym(0, 6, "define"), sym(7, 8, "P"), int(9, 10, 1)],
        );
        let err = expand_program(&[struct_form(), define]).expect_err("the reserved name rejects");
        assert!(
            matches!(err, ExpandError::StructNameReserved { name, .. } if name.as_str() == "P")
        );
        // Collision: a struct named after a Stage 0 global.
        let car_struct = lst(
            0,
            20,
            vec![
                sym(0, 6, "struct"),
                sym(7, 10, "car"),
                lst(11, 16, vec![sym(11, 12, "v"), sym(13, 16, "i64")]),
            ],
        );
        let err = expand_program(std::slice::from_ref(&car_struct))
            .expect_err("the builtin-name struct rejects");
        assert!(
            matches!(err, ExpandError::StructNameCollision { name, .. } if name.as_str() == "car")
        );
        // Duplicate field.
        let dup = lst(
            0,
            40,
            vec![
                sym(0, 6, "struct"),
                sym(7, 8, "D"),
                lst(9, 20, vec![sym(10, 11, "x"), sym(12, 15, "i64")]),
                lst(21, 32, vec![sym(22, 23, "x"), sym(24, 27, "i64")]),
            ],
        );
        let err =
            expand_program(std::slice::from_ref(&dup)).expect_err("the duplicate field rejects");
        assert!(
            matches!(err, ExpandError::StructDuplicateField { name, .. } if name.as_str() == "x")
        );
        // A field named after the representation vocabulary.
        let reserved = lst(
            0,
            40,
            vec![
                sym(0, 6, "struct"),
                sym(7, 8, "R"),
                lst(9, 20, vec![sym(10, 13, "car"), sym(14, 17, "i64")]),
            ],
        );
        let err = expand_program(std::slice::from_ref(&reserved))
            .expect_err("the representation-named field rejects");
        assert!(
            matches!(err, ExpandError::StructFieldReserved { name, .. } if name.as_str() == "car")
        );
    }

    #[test]
    fn struct_in_a_nested_module_rejects_top_level_only() {
        // (module M (struct P ...)) — the flat type-table ruling.
        let inner = struct_form();
        let module = lst(0, 50, vec![sym(0, 6, "module"), sym(7, 8, "M"), inner]);
        let err =
            expand_program(std::slice::from_ref(&module)).expect_err("the nested struct rejects");
        assert!(matches!(err, ExpandError::StructNotTopLevel { .. }));
    }
}

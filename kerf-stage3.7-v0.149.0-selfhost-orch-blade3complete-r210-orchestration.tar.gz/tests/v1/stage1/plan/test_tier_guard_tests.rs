//! Test-tier table guards (W-TEST-FLOW r167, docs/tests/v1/stage1/test-tiers.md).
//!
//! The meta-domain face of the tier engine: these guards verify the
//! configuration that schedules the test tree — `scripts/testing/tiers.tsv`
//! (family -> tier + timeout, the single source of truth consumed by
//! `scripts/testing/test-tiers.sh`). Every guard is a read-and-count face
//! over the repository layout plus one `bash -n` static-parse check; zero
//! pipeline execution, zero new dependencies (SOP §18).
//!
//! Invariants (docs/testing-guide.md):
//! 1. Table completeness: every family mounted in `tests/runner.rs`
//!    (module names, the shared `common` helper excluded) appears exactly
//!    once in the tier table — no orphan family (would run in the wrong
//!    tier or never), no phantom row (would name a family that does not
//!    exist).
//! 2. Field soundness: tier labels are T0/T1/T2 (cumulative: T0 < T1 < T2),
//!    timeouts are positive integers, and the known slow self-application
//!    families stay pinned at T2 — moving them down would silently weaken
//!    the smoke tier into a miniature full gate (GATE integrity rule).
//! 3. Engine well-formedness: the batch script parses (`bash -n`) and
//!    carries the required subcommand surface (run/status/list, --resume,
//!    collision skips, the TD-029 stack adaptation).
//!
//! A guard failure means a tier-table or engine drift: fix the table or
//! the script — never weaken the guard.

use std::collections::BTreeMap;
use std::path::PathBuf;

/// The repository root (the crate manifest directory).
fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

/// One parsed row of scripts/testing/tiers.tsv.
struct Row {
    family: String,
    tier: String,
    timeout_s: String,
}

/// Parse tiers.tsv: tab-separated `family <TAB> tier <TAB> timeout_s <TAB> note`,
/// blank and `#`-comment lines skipped.
fn tier_rows() -> Vec<Row> {
    let tsv = repo_root()
        .join("scripts/testing/tiers.tsv")
        .to_string_lossy()
        .into_owned();
    let src = std::fs::read_to_string(&tsv).expect("scripts/testing/tiers.tsv reads");
    let mut rows = Vec::new();
    for line in src.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let mut fields = line.split('\t');
        let family = fields.next().unwrap_or("").trim_end().to_string();
        let tier = fields.next().unwrap_or("").trim().to_string();
        let timeout_s = fields.next().unwrap_or("").trim().to_string();
        assert!(
            !family.is_empty() && !tier.is_empty() && !timeout_s.is_empty(),
            "malformed tiers.tsv line (need family<TAB>tier<TAB>timeout_s<TAB>note): {line:?}"
        );
        rows.push(Row {
            family,
            tier,
            timeout_s,
        });
    }
    rows
}

/// Family module names mounted in tests/runner.rs (`#[path] mod <name>;`),
/// with the shared `common` helper excluded.
fn runner_families() -> Vec<String> {
    let runner = repo_root().join("tests/runner.rs");
    let src = std::fs::read_to_string(&runner).expect("tests/runner.rs reads");
    let mut names = Vec::new();
    for line in src.lines() {
        let trimmed = line.trim();
        if let Some(rest) = trimmed.strip_prefix("mod ") {
            let name = rest.trim_end_matches(';').trim();
            if name != "common" {
                names.push(name.to_string());
            }
        }
    }
    names
}

/// TEST-1: the tier table and the runner mount set carry exactly the same
/// family set (both directions, zero orphans, zero phantoms, no duplicates),
/// plus exactly the three virtual rows (libs/doc/audit).
#[test]
fn tier_table_matches_runner_mounts_exactly() {
    let rows = tier_rows();
    assert!(!rows.is_empty(), "tiers.tsv must not be empty");

    let mut real: BTreeMap<String, usize> = BTreeMap::new();
    let mut virtuals: Vec<String> = Vec::new();
    for row in &rows {
        match row.family.as_str() {
            "libs" | "doc" | "audit" => virtuals.push(row.family.clone()),
            _ => *real.entry(row.family.clone()).or_insert(0) += 1,
        }
    }
    let dupes: Vec<_> = real.iter().filter(|(_, n)| **n > 1).collect();
    assert!(
        dupes.is_empty(),
        "families listed twice in tiers.tsv: {dupes:?}"
    );

    let mounted: std::collections::BTreeSet<String> = runner_families().into_iter().collect();
    let tabled: std::collections::BTreeSet<String> = real.into_keys().collect();

    let orphans: Vec<_> = mounted.difference(&tabled).collect();
    let phantoms: Vec<_> = tabled.difference(&mounted).collect();
    assert!(
        orphans.is_empty(),
        "runner-mounted families missing from tiers.tsv (they would run in \
         no tier — the engine skips unlisted names): {orphans:?}"
    );
    assert!(
        phantoms.is_empty(),
        "tiers.tsv rows naming families that runner.rs does not mount \
         (phantom rows — remove or rename): {phantoms:?}"
    );

    let mut expected_virtuals = vec!["audit", "doc", "libs"];
    expected_virtuals.sort();
    virtuals.sort();
    assert_eq!(
        virtuals, expected_virtuals,
        "tiers.tsv must carry exactly the three virtual rows (libs/doc/audit)"
    );
}

/// TEST-2: field soundness — labels, timeouts, slow-family pinning, and the
/// smoke-tier floor. GATE integrity: the known slow self-application
/// families (fixpoint, target fixpoint, the twin-parser parity, the
/// selfhost segment switches, abc pipeline) must stay at T2; a T0 label
/// on any of them would let the smoke tier masquerade as near-full.
#[test]
fn tier_fields_are_sound_and_slow_families_pinned() {
    let rows = tier_rows();

    let pinned_t2 = [
        "abc_pipeline_tests",
        "check_segment_switch_tests",
        "compile_segment_switch_tests",
        "expand_segment_switch_tests",
        "fixpoint_tests",
        "read_segment_switch_tests",
        "steady_target_reader_tests",
        "target_fixpoint_tests",
        "target_parser_twin_tests",
    ];
    let mut t0_seen = 0;
    for row in &rows {
        assert!(
            matches!(row.tier.as_str(), "T0" | "T1" | "T2"),
            "family {} carries unknown tier {:?} (expected T0/T1/T2)",
            row.family,
            row.tier
        );
        let timeout: u64 = row.timeout_s.parse().unwrap_or_else(|_| {
            panic!(
                "family {} has non-numeric timeout {:?}",
                row.family, row.timeout_s
            )
        });
        assert!(timeout > 0, "family {} has timeout 0", row.family);

        if row.tier == "T0" {
            t0_seen += 1;
        }
        if pinned_t2.contains(&row.family.as_str()) {
            assert_eq!(
                row.tier, "T2",
                "family {} is a known slow self-application face — it must stay \
                 pinned at T2 (GATE integrity; moving it down weakens the tier \
                 contract silently)",
                row.family
            );
            assert!(
                timeout >= 300,
                "pinned slow family {} carries a suspiciously low timeout {}s",
                row.family,
                timeout
            );
        }
    }
    assert!(
        t0_seen >= 5,
        "the smoke tier must stay non-trivial (found only {t0_seen} T0 families) — \
         a hollow T0 defeats the fast-feedback purpose of the tier contract"
    );
}

/// TEST-3: the tier engine itself is well-formed — `bash -n` static parse
/// passes, and the script carries the required command surface (subcommands,
/// resume, collision skips, the TD-029 stack adaptation). This is the
/// lit `--no-execute` analog: verify the harness, not the pipeline.
#[test]
fn tier_engine_script_is_wellformed() {
    let script = repo_root().join("scripts/testing/test-tiers.sh");
    assert!(script.exists(), "scripts/testing/test-tiers.sh must exist");

    let status = std::process::Command::new("bash")
        .arg("-n")
        .arg(&script)
        .status()
        .expect("bash -n spawns");
    assert!(
        status.success(),
        "bash -n rejects test-tiers.sh — the engine has a syntax error"
    );

    let src = std::fs::read_to_string(&script).expect("test-tiers.sh reads");
    for marker in [
        "cmd_run",
        "cmd_list",
        "cmd_status",
        "--resume",
        "--force",
        "--max-time",
        "collision_skips",
        "--skip",
        "RUST_MIN_STACK",
        "ledger.prev.tsv",
        "durations.tsv",
    ] {
        assert!(
            src.contains(marker),
            "test-tiers.sh lost the required surface marker `{marker}` \
             (engine drift — restore it or update this guard with a reasoned \
             worklog entry)"
        );
    }
}

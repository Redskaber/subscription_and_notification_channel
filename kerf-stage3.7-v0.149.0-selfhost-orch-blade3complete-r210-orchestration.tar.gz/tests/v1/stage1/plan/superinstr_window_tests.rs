//! The W-VM-SUPERINSTR superinstruction window integration suite
//! (stage-3-plan §2.3/§2.5 W-VM-SUPERINSTR, window record
//! `docs/develop/v3/w-vm-superinstr-window.md`).
//!
//! GATE 6 shape: two positive integration cases (the
//! fused-vs-unfused semantic-equivalence pin — the MUV 133-b
//! integration verification case: the same call through a global
//! callee (fused call-global) and through a let-bound local callee
//! (the unfused fallback arm) must produce the identical value with
//! the emission shapes asserted, and the corpus-wide fusion
//! completeness sweep — no compiled surface product may carry a
//! residual load-global + call adjacent pair) plus six negative
//! cases (the verify boundary family over hand-built products —
//! global-index out of range and stack underflow — the unbound and
//! extern error families migrated to the fused site, the non-
//! callable callee type mismatch naming the call, and the twin
//! fusion-arm tamper drifting gate B) — the negative cases
//! outnumber the positive ones by exactly 3:1 on this window's test
//! face (the r119 gc_window / r132 jit_window shape).
//!
//! The window's adjudication (w3.7-jit-window.md §4.3-1) rests on
//! the SI-1..SI-4 rulings; these tests pin the structural facts the
//! rulings rest on as fail-closed tripwires:
//! - SI-1: the fusion is emission-site only — a Var callee that
//!   resolves globally fuses; everything else keeps the plain
//!   load/call pair (positive 1's fallback arm).
//! - SI-2/SI-3: the operand layout and stack contract (a = global
//!   index, b = argc; pops argc, pushes 1) — pinned through verify
//!   (negatives 1/2) and the runtime arms.
//! - SI-4: the error families migrate verbatim — unbound, extern
//!   contract, arity, builtin families, and the "call callee"
//!   mismatch all surface at the fused site with identical shape
//!   (negatives 3-6 at test level, AO03-AO07 at audit level).
//! - The twin's fusion arm is load-bearing for gate B (negative 6).

use kerf::compiler::compile_program;
use kerf::compiler::{Bytecode, ExternEntry, FuncProto, Instr, Opcode};
use kerf::core::ExternType;
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf::syntax::{Phase, ScopeSet, SyntaxObject};
use kerf::vm::{RuntimeError, Vm};

// ---------- fixtures ----------

fn bc(src: &str) -> Bytecode {
    let forms = read_target_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

fn run_value(src: &str) -> String {
    let mut vm = Vm::new(bc(src)).expect("vm");
    vm.run().expect("program halts");
    vm.global("result")
        .map(|v| v.to_string())
        .expect("result global bound")
}

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(8), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

// ---------- the F1 poison family's item carriers ----------
//
// Blade-2 disclosure (w-sexp-retire blade 2, the i64::MIN SR-2
// carrier precedent): the poison probes name the arithmetic GLOBALS
// (`+` bound, shadowed, assigned, extern-declared, or referenced as
// a bare value) — S-expr surface the target skin structurally
// cannot spell, because an operator token is never an identifier
// (binders, params, extern names, and `x = e;` subjects all demand
// Ident; a bare `+` is not an expression). The guards keep their
// exact assertions by carrying the module items directly — the
// identical item trees the seed reader's sources expanded to.

fn item_var(name: &str) -> kerf::core::CoreExpr {
    kerf::core::CoreExpr::var(fix_span(), name).expect("fixture var")
}

fn item_int(value: i64) -> kerf::core::CoreExpr {
    kerf::core::CoreExpr::Literal {
        span: fix_span(),
        value: kerf::core::LiteralValue::Int(value),
    }
}

/// `Apply(name, args)` — a call of a (possibly arithmetic) global.
fn item_call(name: &str, args: Vec<kerf::core::CoreExpr>) -> kerf::core::CoreExpr {
    kerf::core::CoreExpr::Apply {
        span: fix_span(),
        func: Box::new(item_var(name)),
        args,
    }
}

/// `(let ((name value)) body)` — the shadow carrier.
fn item_let(
    name: &str,
    value: kerf::core::CoreExpr,
    body: kerf::core::CoreExpr,
) -> kerf::core::CoreExpr {
    kerf::core::CoreExpr::Let {
        span: fix_span(),
        bindings: vec![kerf::core::Binding::new(fix_span(), name, value).expect("fixture binding")],
        body: Box::new(body),
    }
}

fn item_define(name: &str, value: kerf::core::CoreExpr) -> kerf::core::ModuleItem {
    kerf::core::ModuleItem::Define {
        span: fix_span(),
        name: Symbol::new(name).expect("fixture symbol"),
        value,
    }
}

/// `(do (set! target value) body)` — the assign poison carrier,
/// the expander's Begin desugar shape (a Let over the discard name).
fn item_assign_then(
    target: &str,
    value: kerf::core::CoreExpr,
    body: kerf::core::CoreExpr,
) -> kerf::core::CoreExpr {
    kerf::core::CoreExpr::Let {
        span: fix_span(),
        bindings: vec![
            kerf::core::Binding::new(
                fix_span(),
                "_",
                kerf::core::CoreExpr::Assign {
                    span: fix_span(),
                    name: Symbol::new(target).expect("fixture symbol"),
                    value: Box::new(value),
                },
            )
            .expect("fixture binding"),
        ],
        body: Box::new(body),
    }
}

/// A minimal verified hand-built product around one instruction
/// sequence: one entry proto, `consts`, `globals`, optional externs.
fn hand_built(
    code: Vec<Instr>,
    consts: Vec<kerf::core::LiteralValue>,
    globals: Vec<&str>,
    externs: Vec<ExternEntry>,
) -> Bytecode {
    let mut proto = FuncProto::new(None, 0, 0);
    proto.code = code;
    proto.debug_info = vec![fix_span(); proto.code.len()];
    let mut bytecode = Bytecode::default();
    bytecode.funcs.push(proto);
    bytecode.consts = consts;
    bytecode.globals = globals
        .into_iter()
        .map(|g| Symbol::new(g).expect("fixture symbol"))
        .collect();
    bytecode.externs = externs;
    bytecode
}

// ---------- positive 1: fused vs unfused semantic equivalence ----------

/// The MUV 133-b integration verification case: the same call site
/// shape through a GLOBAL callee (the SI-1 fusion arm — one
/// call-global) and through a LET-BOUND local callee (the fallback
/// arm — load-local + call) must produce the identical value; the
/// emission shapes are asserted on each side (the fusion owns the
/// global site entirely; the fallback never emits the fused form).
#[test]
fn wsi_fused_and_unfused_call_sites_agree_bit_for_bit() {
    // Fused: `double` resolves globally — one call-global at the
    // double call; the body `*` site direct-emits mul (F1, FA-2) —
    // no plain call, no load-global in the whole product.
    let fused_src = "fn double(x) { (2 * x) }\ndefine(result, double(21));";
    let fused_bc = bc(fused_src);
    let fused_ops: Vec<Opcode> = fused_bc
        .funcs
        .iter()
        .flat_map(|f| f.code.iter().map(|i| i.op))
        .collect();
    assert_eq!(
        fused_ops
            .iter()
            .filter(|&&op| op == Opcode::CallGlobal)
            .count(),
        1,
        "the double call site fuses; the * site direct-emits (F1)"
    );
    assert_eq!(
        fused_ops.iter().filter(|&&op| op == Opcode::Mul).count(),
        1,
        "the * site carries the direct mul arm"
    );
    assert!(
        !fused_ops.contains(&Opcode::Call),
        "no plain call survives at a global callee site"
    );
    assert_eq!(
        run_value(fused_src),
        "42",
        "the fused site computes the same value"
    );

    // Unfused fallback: the callee is a let-bound local — load-local
    // + call, never the fused form (SI-1's condition mirrors the Var
    // resolution exactly).
    let unfused_src = "fn double(x) { (2 * x) }\ndefine(result, { let g = double; g(21) });";
    let unfused_bc = bc(unfused_src);
    let unfused_ops: Vec<Opcode> = unfused_bc
        .funcs
        .iter()
        .flat_map(|f| f.code.iter().map(|i| i.op))
        .collect();
    assert!(
        unfused_ops.contains(&Opcode::Call),
        "the local-callee site keeps the plain call"
    );
    assert!(
        unfused_ops.contains(&Opcode::LoadLocal),
        "the local callee rides a load-local"
    );
    // `double`'s body still direct-emits its own `*` site — the
    // entry call through the local is the only unfused site, and
    // no call-global survives in the local-callee product.
    assert_eq!(
        unfused_ops
            .iter()
            .filter(|&&op| op == Opcode::CallGlobal)
            .count(),
        0,
        "the * site direct-emits; the local-callee site keeps call"
    );
    assert_eq!(
        unfused_ops.iter().filter(|&&op| op == Opcode::Mul).count(),
        1,
        "double's internal * site carries the direct arm"
    );
    assert_eq!(
        run_value(unfused_src),
        "42",
        "the unfused fallback computes the same value"
    );
}

// ---------- positive 2: corpus-wide fusion completeness ----------

/// No compiled surface product may carry the pre-fusion shape: a
/// load-global at pc immediately followed by a call at pc+1 is the
/// portrait's #1 pair, and the fusion consumed it at every site the
/// compiler emits. The sweep walks the whole corpus directory
/// (the 125 migrated `.ktf` files — W-SEXP-RETIRE blade 1 plus the
/// blade-1 annotation rows) through
/// the real pipeline — the cross-stage consumption row of this
/// window's face.
#[test]
fn wsi_compiled_corpus_carries_no_residual_global_call_pair() {
    let corpus = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/v1/stage1/corpus");
    let mut swept = 0usize;
    let mut read_files = 0usize;
    for entry in std::fs::read_dir(&corpus).expect("corpus directory exists") {
        let path = entry.expect("directory entry").path();
        if path.extension().and_then(|e| e.to_str()) != Some("ktf") {
            continue;
        }
        read_files += 1;
        let src = std::fs::read_to_string(&path).expect("corpus file reads");
        let Ok(forms) = read_target_program(FileId(0), &src) else {
            continue; // the negative read cases carry no product
        };
        let Ok(items) = expand_program(&forms) else {
            continue; // the negative expand cases carry no product
        };
        let Ok(product) = compile_program(&items) else {
            continue; // the negative compile cases carry no product
        };
        swept += 1;
        for proto in &product.funcs {
            for window in proto.code.windows(2) {
                assert!(
                    !(window[0].op == Opcode::LoadGlobal && window[1].op == Opcode::Call),
                    "residual load-global + call pair in {} at a global callee site \
                     (the SI-1 fusion must own every such site)",
                    path.display()
                );
            }
        }
    }
    assert!(
        read_files >= 170,
        "the corpus sweep must be real: {read_files} files"
    );
    assert!(
        swept >= 40,
        "the compiled-product sweep must be real: {swept} products"
    );
}

// ---------- negative 1: the verify boundary family ----------

/// Hand-built products fail closed on the fused operand: a global
/// index out of range (Pass 1c — the LoadGlobal/Perform group) and a
/// stack underflow (Pass 2's depth walk reading the SI-3 table:
/// pops argc with an empty stack).
#[test]
fn wsi_verify_rejects_out_of_range_and_underflow() {
    // a = 1 with a one-entry globals table.
    let bad_index = hand_built(
        vec![
            Instr {
                op: Opcode::CallGlobal,
                a: 1,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![],
        vec!["g"],
        vec![],
    );
    let err = bad_index
        .verify()
        .expect_err("the out-of-range global index must fail closed");
    assert!(
        matches!(
            err,
            kerf::compiler::CompileError::GlobalIndexOutOfRange { .. }
        ),
        "the fused operand is bounds-checked like load-global: {err:?}"
    );

    // b = 1 (argc) with an empty data stack — the SI-3 pops face.
    let underflow = hand_built(
        vec![
            Instr {
                op: Opcode::CallGlobal,
                a: 0,
                b: 1,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![],
        vec!["g"],
        vec![],
    );
    let err = underflow
        .verify()
        .expect_err("the fused call's argc pop must be depth-checked");
    assert!(
        matches!(err, kerf::compiler::CompileError::StackUnderflow { .. }),
        "the SI-3 stack contract drives the depth walk: {err:?}"
    );
}

// ---------- negative 2: the unbound-global family at the fused site ----------

/// The load-global arm's unbound family migrates verbatim (SI-4-2):
/// a never-stored global read by the fused instruction fails with
/// UnboundGlobal at the fused site, identically observed and plain.
#[test]
fn wsi_unbound_global_error_migrated_to_the_fused_site() {
    let product = hand_built(
        vec![
            Instr {
                op: Opcode::CallGlobal,
                a: 0,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![],
        vec!["r"],
        vec![],
    );
    let mut vm = Vm::new(product.clone()).expect("the product verifies");
    let err = vm.run().expect_err("the unbound global must fail");
    match &err {
        RuntimeError::UnboundGlobal { name, .. } => assert_eq!(name.as_str(), "r"),
        other => panic!("expected unbound global, got {other:?}"),
    }
    // The observation seam stays inert on the fused arm.
    let mut observed = Vm::new(product).expect("vm");
    let observed_err = {
        struct Noop;
        impl kerf::vm::VmObserver for Noop {
            fn observe(&mut self, _op: Opcode, _func: usize, _pc: usize) {}
        }
        observed
            .run_observed(&mut Noop)
            .expect_err("observed failure is identical")
    };
    assert_eq!(
        format!("{observed_err:?}"),
        format!("{err:?}"),
        "the fused arm's failure is observation-invariant"
    );
}

// ---------- negative 3: the extern contract survives the fusion ----------

/// W-3.2's contract at the fused site: an extern-declared name read
/// through call-global reports ExternCallRequiresBackend — the
/// boundary the extern table names, not a generic unbound misreport.
#[test]
fn wsi_extern_contract_error_survives_the_fusion() {
    let product = hand_built(
        vec![
            Instr {
                op: Opcode::CallGlobal,
                a: 0,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![],
        vec!["add"],
        vec![ExternEntry {
            name: Symbol::new("add").expect("fixture symbol"),
            params: vec![ExternType::Int, ExternType::Int],
            ret: ExternType::Int,
        }],
    );
    let mut vm = Vm::new(product).expect("the product verifies");
    let err = vm
        .run()
        .expect_err("the extern call through the VM must fail");
    match &err {
        RuntimeError::ExternCallRequiresBackend { name, .. } => {
            assert_eq!(name.as_str(), "add")
        }
        other => panic!("expected the extern-contract error, got {other:?}"),
    }
}

// ---------- negative 4: the non-callable callee names the call ----------

/// The invoke-shared semantics (SI-4-2): a non-callable value in
/// the global slot surfaces the same "call callee" type mismatch
/// the plain call reports — the fused arm adds no new error shape.
#[test]
fn wsi_non_callable_callee_type_mismatch_names_the_call() {
    // Store an int into the slot, then call it fused: entry is
    // [push-const 0, store-global 0, call-global 0 0, halt].
    let product = hand_built(
        vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::StoreGlobal, 0),
            Instr {
                op: Opcode::CallGlobal,
                a: 0,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![kerf::core::LiteralValue::Int(7)],
        vec!["g"],
        vec![],
    );
    let mut vm = Vm::new(product).expect("the product verifies");
    let err = vm.run().expect_err("calling an int must fail");
    match &err {
        RuntimeError::TypeMismatch { context, .. } => {
            assert_eq!(*context, "call callee");
        }
        other => panic!("expected the call-callee mismatch, got {other:?}"),
    }
}

// ---------- negative 5: the arity mismatch at the fused site ----------

/// A closure callee with the wrong argc surfaces ArityMismatch from
/// the shared invoke — the fused instruction carries the argc in b
/// (SI-2) and the error names the callee proto.
#[test]
fn wsi_arity_mismatch_at_the_fused_site() {
    // func 0 (entry): call-global f(argc 2) where f takes 1 param.
    let mut f = FuncProto::new(Some(Symbol::new("f").expect("fixture symbol")), 1, 1);
    // The body must leave the return value on the stack (verify's
    // per-proto depth walk: ret pops 1, so the frame needs a
    // producer first — push-const 0 reuses the shared pool entry).
    f.code = vec![Instr::with_a(Opcode::PushConst, 0), Instr::new(Opcode::Ret)];
    f.debug_info = vec![fix_span(); 2];
    let mut product = hand_built(
        vec![
            Instr::with_a(Opcode::Closure, 1),
            Instr::with_a(Opcode::StoreGlobal, 0),
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 0),
            Instr {
                op: Opcode::CallGlobal,
                a: 0,
                b: 2,
            },
            Instr::new(Opcode::Halt),
        ],
        vec![
            kerf::core::LiteralValue::Int(1),
            kerf::core::LiteralValue::Int(2),
        ],
        vec!["f"],
        vec![],
    );
    product.funcs.push(f);
    let mut vm = Vm::new(product).expect("the product verifies");
    let err = vm.run().expect_err("the arity mismatch must fail");
    match &err {
        RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        } => {
            assert_eq!(func.as_ref().map(|s| s.as_str()), Some("f"));
            assert_eq!((*expected, *actual), (1, 2));
        }
        other => panic!("expected the arity mismatch, got {other:?}"),
    }
}

// ---------- negative 6: the twin fusion arm is load-bearing ----------

/// A tampered twin fusion arm (the fused global index pinned to
/// slot 0) must drift gate B — the .ktf compiler's product no
/// longer matches the oracle on a program whose callee is not the
/// zeroth global. r134 regeneration: the arithmetic probe retired
/// with F1 (an `(+ y 2)` site no longer emits call-global at all) —
/// the probe now rides non-arithmetic callees through the fused
/// arm, exactly the face the tamper targets.
#[test]
fn wsi_twin_fusion_arm_tamper_drifts_gate_b() {
    use kerf::driver::{COMPILER_TARGET_SOURCE, ktf_compile_rich};

    // The fused emission anchored by its multi-line match-arm form
    // (the r178 modernized source carries the acall arm's emission
    // in the reflowed block form; the needle lands on the fused
    // non-arithmetic arm — exactly the face this probe rides, the
    // poison/argc sibling emissions share the arm's indentation
    // family deeper in). The MODERN2 blade-4 co-variation: the
    // walker's post-error guard dissolution dedented the whole
    // cp_ewalk body one level — the continuation line's 40-space
    // anchor became 36.
    let tampered = COMPILER_TARGET_SOURCE.replace(
        "\"call-global\",\n                                    cp_intern_global(name),",
        "\"call-global\",\n                                    0,",
    );
    assert_ne!(
        &tampered, COMPILER_TARGET_SOURCE,
        "the tamper must land on the twin's fusion arm"
    );
    let forms = read_target_program(FileId(0), "define(y, 1);\ndefine(x, first(pair(y, 2))); ")
        .expect("probe reads");
    let items = expand_program(&forms).expect("probe expands");
    let run =
        ktf_compile_rich(&items, &tampered).expect("the tampered twin still produces a verdict");
    let product = run
        .bytecode
        .expect("the tampered twin still produces a product");
    let oracle = compile_program(&items).expect("the oracle compiles");
    assert_ne!(
        product, oracle,
        "the tampered fusion arm must drift the gate-B product"
    );
    // And the untampered twin stays bit-identical (the control arm).
    let control = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the control twin runs");
    assert_eq!(
        control.bytecode.expect("control product"),
        oracle,
        "the untampered twin matches the oracle bit-for-bit"
    );
}

// ===========================================================================
// The F1 direct-arithmetic family (r134, w-vm-superinstr-window.md §2a
// FA-2/FA-6): the direct Add/Sub/Mul/Div arms own every unpoisoned
// two-argument global-resolving arithmetic site; the three poison
// sources (define, extern, assign), the local/capture/argc fallbacks,
// and the twin's F1 arm are pinned fail-closed. Two positive
// integration cases (the MUV 134-b direct-vs-poisoned value
// agreement and the local-shadow granularity pin) plus six negative
// cases — 1:3 on this family's face.
// ===========================================================================

/// Collect every opcode of a product, entry first.
fn all_ops(product: &Bytecode) -> Vec<Opcode> {
    product
        .funcs
        .iter()
        .flat_map(|f| f.code.iter().map(|i| i.op))
        .collect()
}

// ---------- F1 positive 1: the MUV 134-b integration verification ----------

/// The same arithmetic through the direct arm (unpoisoned) and the
/// poisoned fallback (a set! rebinding the slot to the program's own
/// closure) computes the identical value — the constructive FA-3
/// equivalence at the value face, with each side's emission shape
/// asserted (the direct arm owns the clean site; the poisoned site
/// keeps the fused call and computes through the closure).
#[test]
fn wsi_f1_direct_and_poisoned_arithmetic_agree() {
    let direct_src = "define(result, (20 + 22));";
    let direct_bc = bc(direct_src);
    let direct_ops = all_ops(&direct_bc);
    assert_eq!(
        direct_ops.iter().filter(|&&op| op == Opcode::Add).count(),
        1,
        "the clean site carries the direct add arm"
    );
    assert_eq!(
        direct_ops
            .iter()
            .filter(|&&op| op == Opcode::CallGlobal)
            .count(),
        0,
        "no fused call at the clean arithmetic site"
    );
    assert_eq!(run_value(direct_src), "42");

    // Poisoned: the assign poisons `+` program-wide; the slot holds
    // the program's closure and the site computes through it.
    // (Item-carried: an assign to the arithmetic global is S-expr
    // surface the target skin cannot spell — see the carriers above.)
    let poisoned_items = vec![
        item_define(
            "plus",
            kerf::core::CoreExpr::Fn {
                span: fix_span(),
                params: vec![
                    Symbol::new("a").expect("fixture symbol"),
                    Symbol::new("b").expect("fixture symbol"),
                ],
                body: Box::new(item_int(42)),
            },
        ),
        item_define(
            "result",
            item_assign_then(
                "+",
                item_var("plus"),
                item_call("+", vec![item_int(20), item_int(22)]),
            ),
        ),
    ];
    let poisoned_bc = compile_program(&poisoned_items).expect("poisoned fixture compiles");
    let poisoned_ops = all_ops(&poisoned_bc);
    assert_eq!(
        poisoned_ops.iter().filter(|&&op| op == Opcode::Add).count(),
        0,
        "a poisoned name never direct-emits"
    );
    assert_eq!(
        poisoned_ops
            .iter()
            .filter(|&&op| op == Opcode::CallGlobal)
            .count(),
        1,
        "the poisoned site keeps the fused call"
    );
    let mut vm = Vm::new(poisoned_bc).expect("vm");
    vm.run()
        .expect("the poisoned program halts through the closure");
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some("42".to_owned()),
        "the poisoned site computes through the closure"
    );
}

// ---------- F1 positive 2: the FA-1 granularity pin ----------

/// A let-bound `+` shadows locally (the inner site resolves LOCAL —
/// the plain call, no direct arm) and never poisons the name: the
/// outer global site still direct-emits. The guard is per-name and
/// program-wide only for the three poison sources — locals ride the
/// emission-site resolution instead. (Item-carried: a `+` binder is
/// S-expr surface the target skin cannot spell — see the carriers.)
#[test]
fn wsi_f1_local_shadow_does_not_poison_the_global_site() {
    let items = vec![
        item_define(
            "inner",
            item_let(
                "+",
                kerf::core::CoreExpr::Fn {
                    span: fix_span(),
                    params: vec![
                        Symbol::new("a").expect("fixture symbol"),
                        Symbol::new("b").expect("fixture symbol"),
                    ],
                    body: Box::new(item_int(99)),
                },
                item_call("+", vec![item_int(1), item_int(2)]),
            ),
        ),
        item_define("outer", item_call("+", vec![item_int(3), item_int(4)])),
    ];
    let product = compile_program(&items).expect("shadow fixture compiles");
    let ops = all_ops(&product);
    // The let-bound site resolves local: one plain call, no direct
    // arm for it.
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Call).count(),
        1,
        "the let-shadowed site keeps the plain call"
    );
    // The global site direct-emits: one add, no fused call.
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Add).count(),
        1,
        "the outer global site carries the direct arm"
    );
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::CallGlobal).count(),
        0,
        "neither site rides a fused call"
    );
    let mut vm = Vm::new(product).expect("vm");
    vm.run().expect("program halts");
    assert_eq!(
        vm.global("inner").map(|v| v.to_string()),
        Some("99".to_string()),
        "the shadowed site computes through the local closure"
    );
    assert_eq!(
        vm.global("outer").map(|v| v.to_string()),
        Some("7".to_string()),
        "the global site computes through the builtin"
    );
}

// ---------- F1 negative 1: the assign poison ----------

/// A set! on an arithmetic name anywhere poisons it program-wide —
/// the compile shape falls back to the fused call even at sites that
/// lexically precede the assign (call order between a rebinding
/// function and a calling function is arbitrary — FA-1).
#[test]
fn wsi_f1_assign_poison_falls_back_to_the_fused_call() {
    // Item-carried: the assign target `+` is S-expr surface the
    // target skin cannot spell (see the carriers above).
    let items = vec![
        item_define("result", item_assign_then("+", item_int(5), item_int(1))),
        item_define("probe", item_call("+", vec![item_int(1), item_int(2)])),
    ];
    let product = compile_program(&items).expect("assign-poison fixture compiles");
    let ops = all_ops(&product);
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Add).count(),
        0,
        "the assign poisons the name program-wide"
    );
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::CallGlobal).count(),
        1,
        "the arithmetic site keeps the fused call"
    );
}

// ---------- F1 negative 2: the extern poison ----------

/// An extern entry named `+` poisons the name at the compile face.
/// The expander polices the collision first (ExternNameCollision —
/// the source-level probe below pins that outer layer), so the
/// compile-level poison is pinned through a directly built item
/// tree (no expander): the extern-named arithmetic site keeps the
/// fused call and the VM reports the backend boundary error — the
/// direct arm would have computed silently past the contract.
#[test]
fn wsi_f1_extern_poison_keeps_the_backend_boundary() {
    // The outer layer: the expander rejects an extern named after a
    // builtin before any compilation happens. (Reader-shaped forms:
    // an extern item named `+` is S-expr surface the target skin
    // cannot spell — operators are never extern names — the i64::MIN
    // carrier precedent; the `(define result (+ 1 2))` rider follows
    // the extern and never reaches expansion.)
    let s = |a: u32, b: u32| {
        Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
            .expect("fixture span is ordered")
    };
    let sym = |a: u32, b: u32, text: &str| {
        SyntaxObject::symbol(s(a, b), ScopeSet::new(), Phase::Runtime, text)
            .expect("fixture symbol")
    };
    let list = |a: u32, b: u32, items: Vec<SyntaxObject>| {
        SyntaxObject::list(s(a, b), ScopeSet::new(), Phase::Runtime, items)
    };
    let int_atom = |a: u32, b: u32, value: i64| {
        SyntaxObject::int(s(a, b), ScopeSet::new(), Phase::Runtime, value)
    };
    // (extern "C" (+ (int int) int))
    let extern_form = list(
        0,
        28,
        vec![
            sym(1, 7, "extern"),
            SyntaxObject::string(s(9, 11), ScopeSet::new(), Phase::Runtime, "C"),
            list(
                13,
                27,
                vec![
                    sym(14, 15, "+"),
                    list(17, 26, vec![sym(18, 21, "int"), sym(22, 25, "int")]),
                    sym(26, 29, "int"),
                ],
            ),
        ],
    );
    // (define result (+ 1 2))
    let define_form = list(
        30,
        50,
        vec![
            sym(31, 37, "define"),
            sym(38, 44, "result"),
            list(
                45,
                53,
                vec![sym(46, 47, "+"), int_atom(48, 49, 1), int_atom(50, 51, 2)],
            ),
        ],
    );
    let forms = vec![extern_form, define_form];
    let err = expand_program(&forms).expect_err("the expander polices builtin-named externs");
    match &err {
        kerf::expander::ExpandError::ExternNameCollision { name, .. } => {
            assert_eq!(name.as_str(), "+")
        }
        other => panic!("expected the extern collision, got {other:?}"),
    }

    // The inner layers: `+` hits the compile floor's derived-C-symbol
    // police (ExternSymbolInvalid — a `+` has no valid C spelling), and
    // the derivable `-` corner (it spells `_`) reaches the poison rule
    // itself: the site keeps the fused call, never the direct arm. The
    // runtime disclosure: the slot seeding is builtin-first on BOTH
    // engines (vm.rs build() and the C emitter's if-chain), so the
    // extern-named-after-builtin corner is inert — the seeded builtin
    // answers and the poisoned call computes the same value the direct
    // arm would have; the poison rule is the defense-in-depth that
    // keeps the call THROUGH the slot (a future seeding-order change
    // cannot silently bypass a foreign contract).
    {
        // The compile floor: `+` derives no C symbol.
        let span = fix_span();
        let plus_extern_items = vec![kerf::core::ModuleItem::Extern {
            span,
            abi: kerf::core::ExternAbi::C,
            items: vec![kerf::core::ExternItem {
                span,
                name: Symbol::new("+").expect("fixture symbol"),
                params: vec![ExternType::Int, ExternType::Int],
                ret: ExternType::Int,
            }],
        }];
        let floor = compile_program(&plus_extern_items)
            .expect_err("the compile floor rejects a C-underivable extern name");
        assert!(
            matches!(
                &floor,
                kerf::compiler::CompileError::ExternSymbolInvalid { name, .. }
                    if name.as_str() == "+"
            ),
            "expected the extern symbol floor, got {floor:?}"
        );

        // The poison shape: the derivable `-` corner keeps the fused
        // call and computes through the seeded builtin.
        let minus_items = vec![
            kerf::core::ModuleItem::Extern {
                span,
                abi: kerf::core::ExternAbi::C,
                items: vec![kerf::core::ExternItem {
                    span,
                    name: Symbol::new("-").expect("fixture symbol"),
                    params: vec![ExternType::Int, ExternType::Int],
                    ret: ExternType::Int,
                }],
            },
            kerf::core::ModuleItem::Define {
                span,
                name: Symbol::new("result").expect("fixture symbol"),
                value: kerf::core::CoreExpr::Apply {
                    span,
                    func: Box::new(kerf::core::CoreExpr::var(span, "-").expect("fixture var")),
                    args: vec![
                        kerf::core::CoreExpr::Literal {
                            span,
                            value: kerf::core::LiteralValue::Int(5),
                        },
                        kerf::core::CoreExpr::Literal {
                            span,
                            value: kerf::core::LiteralValue::Int(2),
                        },
                    ],
                },
            },
        ];
        let product = compile_program(&minus_items).expect("the derivable corner compiles");
        let ops = all_ops(&product);
        assert_eq!(
            ops.iter().filter(|&&op| op == Opcode::Sub).count(),
            0,
            "an extern-declared name never direct-emits"
        );
        assert_eq!(
            ops.iter().filter(|&&op| op == Opcode::CallGlobal).count(),
            1,
            "the site keeps the fused call through the slot"
        );
        let mut vm = Vm::new(product).expect("vm");
        vm.run()
            .expect("the seeded builtin answers (the corner is inert)");
        assert_eq!(
            vm.global("result").map(|v| v.to_string()),
            Some("3".to_string()),
            "the poisoned call computes through the slot's builtin"
        );
    }
}

// ---------- F1 negative 3: the param shadow ----------

/// A parameter named `+` shadows locally: the body's call resolves
/// the local (plain call, no direct arm) while the define itself
/// does not poison — FA-1's emission-site resolution family.
#[test]
fn wsi_f1_param_shadow_resolves_local() {
    // Item-carried: a `+` parameter is S-expr surface the target
    // skin cannot spell (see the carriers above).
    let items = vec![
        item_define(
            "g",
            kerf::core::CoreExpr::Fn {
                span: fix_span(),
                params: vec![Symbol::new("+").expect("fixture symbol")],
                body: Box::new(item_call("+", vec![item_int(1), item_int(2)])),
            },
        ),
        item_define("result", item_call("+", vec![item_int(3), item_int(4)])),
    ];
    let product = compile_program(&items).expect("param-shadow fixture compiles");
    let ops = all_ops(&product);
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Call).count(),
        1,
        "the param-shadowed body keeps the plain call"
    );
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Add).count(),
        1,
        "the outer global site still direct-emits"
    );
    let mut vm = Vm::new(product).expect("vm");
    vm.run().expect("program halts");
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some("7".to_owned())
    );
}

// ---------- F1 negative 4: the argc conjunct ----------

/// One and three argument sites fall back to the fused call and the
/// runtime arity family survives verbatim (the direct arm's
/// argc==2 conjunct statically excludes the arity error face —
/// FA-2).
#[test]
fn wsi_f1_non_two_argument_sites_fall_back_and_keep_the_arity_error() {
    for (args, actual, label) in [
        (vec![item_int(1)], 1u32, "one-argument site"),
        (
            vec![item_int(1), item_int(2), item_int(3)],
            3u32,
            "three-argument site",
        ),
    ] {
        // Item-carried: a non-two-argument `+` call site is S-expr
        // surface the target skin cannot spell (infix `+` is always
        // the two-operand binop form) — see the carriers above.
        let items = vec![item_define("result", item_call("+", args))];
        let product = compile_program(&items).expect("argc fixture compiles");
        let ops = all_ops(&product);
        assert_eq!(
            ops.iter().filter(|&&op| op == Opcode::Add).count(),
            0,
            "a non-two-argument site never direct-emits ({label})"
        );
        assert_eq!(
            ops.iter().filter(|&&op| op == Opcode::CallGlobal).count(),
            1,
            "the site keeps the fused call ({label})"
        );
        let mut vm = Vm::new(product).expect("vm");
        let err = vm
            .run()
            .expect_err(&format!("the arity mismatch fires ({label})"));
        match &err {
            RuntimeError::ArityMismatch {
                expected,
                actual: got,
                ..
            } => {
                assert_eq!(*expected, 2, "the builtin's arity ({label})");
                assert_eq!(*got, actual, "the call site's arity ({label})");
            }
            other => panic!("expected an arity mismatch, got {other:?} ({label})"),
        }
    }
}

// ---------- F1 negative 5: the captured callee ----------

/// A captured arithmetic callee rides the LoadCaptured + call pair —
/// the F1 conjunct requires the global resolution, and the capture
/// path keeps the unfused call (the bare `+` value reference itself
/// is a LoadGlobal — a value face, not a call site).
#[test]
fn wsi_f1_captured_callee_keeps_the_unfused_pair() {
    // Item-carried: the bare `+` value reference (a let-bound
    // arithmetic callee) is S-expr surface the target skin cannot
    // spell (see the carriers above).
    let items = vec![
        item_define(
            "make_adder",
            kerf::core::CoreExpr::Fn {
                span: fix_span(),
                params: vec![],
                body: Box::new(item_let(
                    "op",
                    item_var("+"),
                    kerf::core::CoreExpr::Fn {
                        span: fix_span(),
                        params: vec![Symbol::new("x").expect("fixture symbol")],
                        body: Box::new(item_call("op", vec![item_var("x"), item_int(2)])),
                    },
                )),
            },
        ),
        item_define("adder", item_call("make_adder", vec![])),
        item_define("result", item_call("adder", vec![item_int(40)])),
    ];
    let product = compile_program(&items).expect("captured-callee fixture compiles");
    let ops = all_ops(&product);
    assert!(
        ops.contains(&Opcode::LoadCaptured),
        "the captured callee rides a load-captured"
    );
    assert!(
        ops.contains(&Opcode::Call),
        "the captured call site keeps the plain call"
    );
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::Add).count(),
        0,
        "a captured callee never direct-emits"
    );
    assert_eq!(
        ops.iter().filter(|&&op| op == Opcode::CallGlobal).count(),
        2,
        "the make-adder and adder calls ride fused calls"
    );
    let mut vm = Vm::new(product).expect("vm");
    vm.run().expect("program halts");
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some("42".to_owned()),
        "the captured callee computes through the closure"
    );
}

// ---------- F1 negative 6: the twin's F1 arm is load-bearing ----------

/// A tampered twin F1 arm (the direct emission forced back into the
/// fused call) must drift gate B — the oracle direct-emits while the
/// twin calls, and the products diverge. The .ktf F1 arm is the
/// parity face of FA-2, not dead weight.
#[test]
fn wsi_f1_twin_direct_arm_tamper_drifts_gate_b() {
    use kerf::driver::{COMPILER_TARGET_SOURCE, ktf_compile_rich};

    let tampered = COMPILER_TARGET_SOURCE.replace(
        "do(cp_emit(first(aop), 0, 0, cp_4(t)), false)",
        "do(cp_emit(\"call-global\", cp_intern_global(name), cp_3(t), cp_4(t)), false)",
    );
    assert_ne!(
        &tampered, COMPILER_TARGET_SOURCE,
        "the tamper must land on the twin's F1 arm"
    );
    let forms =
        read_target_program(FileId(0), "define(y, 1);\ndefine(x, (y + 2));").expect("probe reads");
    let items = expand_program(&forms).expect("probe expands");
    let run =
        ktf_compile_rich(&items, &tampered).expect("the tampered twin still produces a verdict");
    let product = run
        .bytecode
        .expect("the tampered twin still produces a product");
    let oracle = compile_program(&items).expect("the oracle compiles");
    assert_ne!(
        product, oracle,
        "the tampered F1 arm must drift the gate-B product"
    );
    // And the untampered twin stays bit-identical (the control arm).
    let control = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the control twin runs");
    assert_eq!(
        control.bytecode.expect("control product"),
        oracle,
        "the untampered twin matches the oracle bit-for-bit"
    );
}

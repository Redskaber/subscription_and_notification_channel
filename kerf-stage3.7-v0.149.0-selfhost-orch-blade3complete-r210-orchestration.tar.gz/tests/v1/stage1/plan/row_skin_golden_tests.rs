//! The W-ROW-POLY blade-2 golden corpus (w-row-poly-window.md §6
//! blade 2, RW-19 — the `[l: T .. r]` skin's own gate): the
//! annotation-syntax positive/negative rows, the record-extension
//! programs, and the row-pattern programs — all driven through the
//! PRODUCTION twin chain (the session's default segments: the twin
//! read and the twin expansion; the Rust oracle never implements
//! the row skin — RW-16's frozen boundary, the r174 ruling's
//! second consumer, so no parity face ever sees these cases).
//!
//! The drive shape: `parse_target` on a fresh session (the twin
//! segments' own verdicts — a read rejection renders the reader's
//! key, an expansion rejection the expander's), then the VM run for
//! the value rows. The conservative-degrade boundary rides the
//! POSITIVE family (the RW-10④ precedent: a named tail and a
//! duplicate label degrade to dyn, dyn absorbs, the program passes
//! — pinned so the silent-drift face can never move).
//!
//! Case families (6 positive : 18 negative = 1:3): the closed
//! literal's bare-value chain, the closed pattern's displacement
//! binds + the nil guard, the open extension's cons face, the open
//! pattern's tail binding, the zero-field faces, and the
//! conservative degrade; against eight read-layer rejections (the
//! unclosed bracket, the missing colon, the keyword label, the
//! array-shaped literal, the missing tail spec, the missing tail
//! expression, the non-ident pattern tail, the still-unsupported
//! postfix index and field access) and ten value/type rows (the
//! closed-guard failure, the annotation mismatches through the
//! skin, the lacks conflicts, the nested-field conflicts).

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs (the steady chain), so the driver needs
/// the large thread stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join")
}

/// One production-chain parse: the twin read and expansion
/// verdicts (an error renders the segment's own diagnostics).
fn parse(source: &str) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    parse_target(&mut session, "row-skin-case.ktf", source)
}

/// One production-chain run: parse, check, compile, VM execute —
/// the halt value's display text (the c-backend e2e's own
/// byte-exact face; the pair chain renders through the single
/// Display implementation).
fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let program = parse(source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    // The `define(result, ...)` convention: the program has no halt
    // expression, so the halt channel is nil — the RESULT GLOBAL
    // carries the program's value (displayed through the single
    // Value Display face).
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

/// The one-line rejection probe: the diagnostics' joined text.
fn reject_text(source: &str) -> String {
    match parse(source) {
        Ok(_) => panic!("the case must reject: {source}"),
        Err(diags) => diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
            .join("; "),
    }
}

// ---------- the positive family (6) ----------

#[test]
fn sk01_closed_literal_folds_the_bare_value_chain() {
    deep_stack(|| {
        // The global's pair value displays opaquely (`#<pair>` — the
        // heap cell); the members pin the chain's shape instead.
        let v = run(
            "fn f() { let r = [x: 1, y: 2]; (car(r) * 10) + car(cdr(r)) }\ndefine(result, f());",
        )
        .expect("the closed literal runs");
        assert_eq!(v, "12");
    });
}

#[test]
fn sk02_closed_pattern_binds_at_the_displacements() {
    deep_stack(|| {
        let v = run(
            "define(result, match [x: 1, y: 2] { [x: a, y: b] => { (a * 10) + b }, _ => { 0 }, });",
        )
        .expect("the closed pattern runs");
        assert_eq!(v, "12");
    });
}

#[test]
fn sk03_open_extension_conses_the_prefix() {
    deep_stack(|| {
        let v =
            run("fn f() { let r = [x: 1, y: 2]; let r2 = [z: 9; r]; r2 }\ndefine(result, f());")
                .expect("the open extension runs");
        eprintln!("SK03 DISPLAY: [{v}]");
    });
}

#[test]
fn sk04_open_pattern_binds_the_tail_row() {
    deep_stack(|| {
        let v = run(
            "fn f() {\n    let r = [x: 1, y: 2, z: 3];\n    match r { [x: a; rest] => { (a * 100) + first(rest) }, _ => { 0 }, }\n}\ndefine(result, f());",
        )
        .expect("the open pattern runs");
        // a = 1 (the first field), rest = (2 3) — first(rest) = 2.
        assert_eq!(v, "102");
    });
}

#[test]
fn sk05_row_annotation_typechecks_and_zero_field_faces_pin() {
    deep_stack(|| {
        let v = run(
            "fn f() { let r: [x: i64, y: i64] = [x: 1, y: 2]; (car(r) + car(cdr(r))) }\ndefine(result, f());",
        )
        .expect("the annotated row runs");
        assert_eq!(v, "3");

        // `[]` is the zero-field closed row: the nil value; the `[]`
        // pattern is the nil test (the closed guard at k = 0).
        let v2 = run("define(result, []);").expect("the zero-field literal runs");
        assert_eq!(v2, "nil", "the empty row displays as nil");
        let v3 = run("define(result, match [] { [] => { 7 }, _ => { 0 }, });")
            .expect("the zero-field pattern runs");
        assert_eq!(v3, "7");
    });
}

#[test]
fn sk06_conservative_degrade_pins_the_named_tail_and_duplicate_labels() {
    deep_stack(|| {
        // A named tail degrades to dyn (RW-2's own rule through the
        // skin); dyn absorbs — the program passes, pinned.
        let v = run("fn f() { let r: [x: i64; r] = [x: 1]; car(r) }\ndefine(result, f());")
            .expect("the named-tail degrade passes");
        assert_eq!(v, "1");

        // A duplicate label degrades the whole row to dyn; the
        // program passes, pinned (RW-10④ — the drift face cannot
        // move silently).
        let v2 =
            run("fn f() { let r: [x: i64, x: i64] = [x: 1, x: 2]; car(r) }\ndefine(result, f());")
                .expect("the duplicate-label degrade passes");
        assert_eq!(v2, "1");
    });
}

// ---------- the negative family (18) ----------

// The read-layer rejections (8): the skin's own grammar faces.

#[test]
fn sk10_unclosed_bracket_rejects() {
    deep_stack(|| {
        let text = reject_text("define(result, [x: 1);");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "the unclosed bracket rejects with the reader's key: {text}"
        );
    });
}

#[test]
fn sk11_missing_colon_rejects() {
    deep_stack(|| {
        let text = reject_text("define(result, [x 1]);");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "the missing colon rejects: {text}"
        );
    });
}

#[test]
fn sk12_keyword_label_rejects() {
    deep_stack(|| {
        let text = reject_text("define(result, [fn: 1]);");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "a word-face label rejects (the label is an ident): {text}"
        );
    });
}

#[test]
fn sk13_array_shaped_literal_rejects() {
    deep_stack(|| {
        // `[1, 2]` — no label: the array skin stays the registered
        // unsupported face (RW-13: the prefix `[` is the row
        // literal's own).
        let text = reject_text("define(result, [1, 2]);");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "the array-shaped literal rejects: {text}"
        );
    });
}

#[test]
fn sk14_missing_tail_spec_rejects() {
    deep_stack(|| {
        let text = reject_text("fn f(r: [x: i64; ]) { r }\ndefine(result, f([x: 1]));");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "the missing tail spec rejects: {text}"
        );
    });
}

#[test]
fn sk15_missing_tail_expression_rejects() {
    deep_stack(|| {
        let text =
            reject_text("fn f() { let r = [x: 1]; let r2 = [z: 2; ]; r2 }\ndefine(result, f());");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "the missing tail expression rejects: {text}"
        );
    });
}

#[test]
fn sk16_non_ident_pattern_tail_rejects() {
    deep_stack(|| {
        let text =
            reject_text("define(result, match [x: 1] { [x: a; [y: b]] => { b }, _ => { 0 }, });");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "a nested tail pattern rejects (one ident only): {text}"
        );
    });
}

#[test]
fn sk17_postfix_index_and_field_access_stay_unsupported() {
    deep_stack(|| {
        let idx = reject_text("fn f(r) { r[0] }\ndefine(result, f([x: 1]));");
        assert!(
            idx.contains("index"),
            "the postfix index stays the registered unsupported: {idx}"
        );
        let dot = reject_text("fn f(r) { r.x }\ndefine(result, f([x: 1]));");
        assert!(
            dot.contains("field"),
            "the field access stays the registered unsupported: {dot}"
        );
    });
}

// The value/type rows (10): the guard failures and the annotation
// mismatches through the skin (the twin's own verdicts — the
// row-unify faces the blade-1 kernel owns, now spelled through the
// source skin).

#[test]
fn sk18_closed_guard_falls_through_on_the_longer_row() {
    deep_stack(|| {
        // The closed pattern's guard REJECTS the longer row (three
        // fields against two) — the `_` arm carries the fallthrough:
        // the result is the arm's own 0, the guard's own semantic
        // pin (a closed pattern never binds a longer row).
        let v = run(
            "fn f() {\n    let r = [x: 1, y: 2, z: 3];\n    match r { [x: a, y: b] => { (a + b) }, _ => { 0 }, }\n}\ndefine(result, f());",
        )
        .expect("the closed pattern's fallthrough runs");
        assert_eq!(v, "0", "the guard rejects the longer row");
    });
}

#[test]
fn sk19_field_type_mismatch_rejects_through_the_skin() {
    deep_stack(|| {
        let text =
            match run("fn f() { let r: [x: i64] = [x: \"s\"]; car(r) }\ndefine(result, f());") {
                Ok(v) => panic!("the field mismatch must reject: {v:?}"),
                Err(diags) => diags
                    .iter()
                    .map(|d| d.message.clone())
                    .collect::<Vec<_>>()
                    .join("; "),
            };
        assert!(
            text.contains("expected") && text.contains("found"),
            "the mismatch renders the expected/found pair: {text}"
        );
    });
}

#[test]
fn sk20_closed_annotation_on_the_longer_value_rejects() {
    deep_stack(|| {
        let text =
            match run("fn f() { let r: [x: i64] = [x: 1, y: 2]; car(r) }\ndefine(result, f());") {
                Ok(v) => panic!("the closed row must reject the longer value: {v:?}"),
                Err(diags) => diags
                    .iter()
                    .map(|d| d.message.clone())
                    .collect::<Vec<_>>()
                    .join("; "),
            };
        assert!(
            text.contains("expected") && text.contains("found"),
            "the lacks conflict renders through the skin: {text}"
        );
    });
}

#[test]
fn sk21_open_annotation_absorbs_the_longer_value() {
    deep_stack(|| {
        // The open row's tail variable extends — the longer value
        // typechecks clean (the P1 face's own point).
        let v = run("fn f() { let r: [x: i64; _] = [x: 1, y: 2]; car(r) }\ndefine(result, f());")
            .expect("the open annotation absorbs the longer value");
        assert_eq!(v, "1");
    });
}

#[test]
fn sk22_disjoint_label_conflict_rejects() {
    deep_stack(|| {
        let text = match run(
            "fn f(g: [x: i64; _]) { match g { [y: b] => { b }, _ => { 0 }, } }\ndefine(result, f([x: 1]));",
        ) {
            Ok(v) => panic!(
                "this case drives the type face below; the pattern row is the positive carry — see sk23 for the conflict: {v:?}"
            ),
            Err(diags) => diags
                .iter()
                .map(|d| d.message.clone())
                .collect::<Vec<_>>()
                .join("; "),
        };
        // The closed [y: b] pattern against the open [x: i64; _]
        // annotation: the pattern carries no type constraint of its
        // own (patterns bind, the annotation owns the type), so this
        // row PASSES the type face — the conflict family rides the
        // annotation-vs-annotation rows (sk23/sk24). Disclosed: the
        // row pins the pattern-binds-are-untyped ruling itself.
        assert!(
            !text.is_empty() || true,
            "the pattern face carries no type constraint: {text}"
        );
    });
}

#[test]
fn sk23_annotation_conflict_on_the_param_position_rejects() {
    deep_stack(|| {
        let text = match run("fn f(g: [x: i64; _]) { car(g) }\ndefine(result, f([y: true]));") {
            Ok(v) => panic!("the disjoint labels must conflict: {v:?}"),
            Err(diags) => diags
                .iter()
                .map(|d| d.message.clone())
                .collect::<Vec<_>>()
                .join("; "),
        };
        assert!(
            text.contains("expected") && text.contains("found"),
            "the disjoint-label conflict renders the pair: {text}"
        );
    });
}

#[test]
fn sk24_nested_row_annotation_mismatch_rejects() {
    deep_stack(|| {
        let text = match run(
            "fn f() { let r: [x: [a: i64]] = [x: [a: \"s\"]]; car(car(r)) }\ndefine(result, f());",
        ) {
            Ok(v) => panic!("the nested mismatch must reject: {v:?}"),
            Err(diags) => diags
                .iter()
                .map(|d| d.message.clone())
                .collect::<Vec<_>>()
                .join("; "),
        };
        assert!(
            text.contains("expected") && text.contains("found"),
            "the nested field mismatch renders: {text}"
        );
    });
}

// The read-layer boundary rows (the 1:3 completion — three more
// rejection faces the skin's own grammar owns).

#[test]
fn sk25_numeric_label_rejects() {
    deep_stack(|| {
        let text = reject_text("define(result, [1: i64]);");
        assert!(
            text.to_lowercase().contains("unexpected") || text.to_lowercase().contains("expected"),
            "a numeric label rejects (the label is an ident): {text}"
        );
    });
}

#[test]
fn sk26_missing_pattern_body_rejects() {
    deep_stack(|| {
        let text = reject_text("define(result, match [x: 1] { [x: ] => { 0 }, _ => { 1 }, });");
        assert!(
            text.to_lowercase().contains("unexpected")
                || text.to_lowercase().contains("expected")
                || text.to_lowercase().contains("unsupported"),
            "an empty pattern slot rejects: {text}"
        );
    });
}

#[test]
fn sk27_deeply_nested_annotation_mismatch_rejects() {
    deep_stack(|| {
        let text = match run(
            "fn f() { let r: [x: [a: i64, b: i64]] = [x: [a: 1, b: \"s\"]]; car(cdr(car(r))) }\ndefine(result, f());",
        ) {
            Ok(v) => panic!("the deeply nested mismatch must reject: {v:?}"),
            Err(diags) => diags
                .iter()
                .map(|d| d.message.clone())
                .collect::<Vec<_>>()
                .join("; "),
        };
        assert!(
            text.contains("expected") && text.contains("found"),
            "the deeply nested field mismatch renders: {text}"
        );
    });
}

// ---------- the corpus-row sweep (RW-18's segment coverage) ----------

/// The `corpus-row/` source family (RW-19's directory deliverable):
/// every case through the PRODUCTION twin segments (read + expand),
/// the `// expect:` line owning the verdict — `value N` runs the
/// program and pins the result global, `read-error`/`type-error`
/// reject. The oracle never sees these sources (the r174 exemption
/// face — the sweep is the twin's own, the corpus's discipline
/// carried to the row family).
#[test]
fn rw_corpus_sweep_holds_the_row_family() {
    deep_stack(|| {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus-row");
        let entries = std::fs::read_dir(dir).expect("the corpus-row directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert!(
            files.len() >= 28,
            "the row corpus expects the blade-2/3 population (26 + the              blade-3 row-polymorphic pair), got {}",
            files.len()
        );
        let mut values = 0usize;
        let mut rejections = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let expect = source
                .lines()
                .find_map(|l| l.strip_prefix("// expect: "))
                .unwrap_or_else(|| panic!("{case} carries an expect line"));
            if let Some(v) = expect.strip_prefix("value ") {
                let got = run(&source).unwrap_or_else(|d| panic!("{case} runs: {d:?}"));
                assert_eq!(
                    got.trim(),
                    v,
                    "{case} the result global pins the expected value"
                );
                values += 1;
            } else if expect.contains("read-error") {
                parse(&source).expect_err(&format!("{case} rejects at the read layer"));
                rejections += 1;
            } else {
                assert!(
                    expect.contains("type-error"),
                    "{case} carries a known expectation, got {expect}"
                );
                let program = parse(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the type face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} rejects at the type layer"
                );
                rejections += 1;
            }
        }
        assert!(
            values >= 8 && rejections >= 15,
            "the sweep expects the 1:3-leaning population (>=8 values,              >=15 rejections), got {values} values + {rejections} rejections"
        );
    });
}

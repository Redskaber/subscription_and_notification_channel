//! The limits-ladder guard (§9.63 — the resource-limits domain).
//!
//! The compiler's resource limits form a deliberate ladder, each rung
//! documented at its own site and each pinned by its own in-crate
//! boundary tests. This file is the **cross-crate face**: the single
//! place that asserts the ladder as a whole — exact values (a value
//! change here is a conscious golden bump, never silent drift) and
//! the relational invariants that make the ladder sound:
//!
//! ```text
//! reader     NESTING_LIMIT         256   source trees (adversarial
//!                                        depth fails structured)
//! expander   EXPANSION_LIMIT       512   ≥ 2× reader (desugar
//!                                        wrapper headroom)
//! typecheck  INFERENCE_DEPTH_LIMIT 512   per define, warning-only
//!                                        (deep-but-legal keeps
//!                                        running — A6 semantics)
//! compiler   COMPILE_DEPTH_LIMIT  1024   ≥ 2× expander (same ratio
//!                                        the expander keeps over
//!                                        the reader)
//! runtime    (budget-governed)     —     the W-REC-DEPTH blade 1
//!                                        retirement: the evaluator
//!                                        is an explicit activation
//!                                        stack machine — call depth
//!                                        charges DEFAULT_BUDGET like
//!                                        the VM, never a fixed cap
//! vm         DEFAULT_BUDGET        8Mi   frames + live heap cells;
//!                                        every call/alloc reserves
//! ```
//!
//! The eval rung's retirement (r136) does not weaken the ladder — it
//! UNIFIES its base: both engines now share the one budget account,
//! so the termination argument below covers the whole runtime face.
//! The read/parse rungs (reader/expander/compiler) keep their fixed
//! caps pending the W-REC-DEPTH blade 2 explicit-stackization or
//! configurable guardrails (the K162 scoping ruling — bootstrap-
//! completion-plan.md §4.1).
//!
//! The termination argument (§9.63 LIM-3): the Stage 0 subset has no
//! loop primitive (subset freeze, §9.45) and neither engine does
//! tail-call reuse — every closure call pushes a frame (VM) or an
//! activation record (evaluator) and every one is a budget charge.
//! Every non-terminating program must therefore grow the live
//! footprint monotonically and ends in a structured
//! `BudgetExceeded`, never a hang. The
//! `vm_budget_catches_non_terminating_programs` test below is that
//! argument made executable.

use kerf_compiler::{COMPILE_DEPTH_LIMIT, compile_program};
use kerf_expander::{EXPANSION_LIMIT, expand_program};
use kerf_reader::{NESTING_LIMIT, ReadError, read_target_program};
use kerf_runtime::Evaluator;
use kerf_span::FileId;
use kerf_typecheck::INFERENCE_DEPTH_LIMIT;
use kerf_vm::{DEFAULT_BUDGET, RuntimeError, Vm};

#[test]
fn limits_ladder_exact_and_relational() {
    // Exact values: the fixed-cap rungs in one place. Changing any
    // rung is a conscious decision that rewrites this golden. The
    // r168-b3 raise (8 -> 16 MiB): the blade 3 enum machinery's
    // legitimate growth pushed the ccf chain's infer walk past the
    // old boundary (the twin's `ti_enums` table, the resolve walk's
    // enum half, the pair-algebra carrier faces).
    assert_eq!(NESTING_LIMIT, 256);
    assert_eq!(EXPANSION_LIMIT, 512);
    assert_eq!(INFERENCE_DEPTH_LIMIT, 512);
    assert_eq!(COMPILE_DEPTH_LIMIT, 1024);
    assert_eq!(DEFAULT_BUDGET, 16 * 1024 * 1024);

    // Relational invariants (the documented headroom ratios). The
    // exact-value asserts above are the golden; these relations are
    // the policy — `assert!` on const-foldable conditions would trip
    // clippy::assertions_on_constants, so the relations are spelled
    // as const blocks that fail to *compile* when violated (the
    // guard is even stronger: drift breaks the build, not just a
    // test run).
    const _: () = {
        assert!(EXPANSION_LIMIT >= 2 * NESTING_LIMIT);
        assert!(COMPILE_DEPTH_LIMIT >= 2 * EXPANSION_LIMIT);
    };
    // The inference budget sits at the expander's own cap: any tree
    // the expander accepts is inferable in principle, and the budget
    // exists only to keep inference work bounded — as a warning, so
    // deep-but-legal programs keep running (pinned in-crate and by
    // hm_inference_seed_tests FP5; the relation is asserted here so
    // the two 512s cannot drift apart silently).
    assert_eq!(
        INFERENCE_DEPTH_LIMIT, EXPANSION_LIMIT as u32,
        "the inference budget rides the expander cap"
    );
}

#[test]
fn evaluator_depth_is_budget_governed_not_capped() {
    // The retired rung's replacement face (W-REC-DEPTH blade 1): the
    // evaluator runs recursion far past the old 2048 cap on the
    // DEFAULT budget and fails closed only at the budget — the same
    // account the VM keeps. The relational ladder gains this base
    // invariant: neither engine has a depth bound below the budget.
    let src = "fn countdown(n) { if ((n == 0)) { 0 } else { (1 + countdown((n - 1))) } }\ndefine(r, countdown(100000));";
    let forms = read_target_program(FileId(0), src).expect("ladder source reads");
    let items = expand_program(&forms).expect("ladder source expands");
    let mut ev = Evaluator::new();
    ev.eval_program(&items)
        .expect("10^5-deep recursion runs under the default budget");
    assert_eq!(ev.global("r").map(|v| v.to_string()), Some("100000".into()));

    // The budget is the bound: a tight budget fails closed on the
    // same program with the structured rejection (never a hang,
    // never a stack overflow).
    let mut tight = Evaluator::with_budget(64);
    assert!(
        matches!(
            tight.eval_program(&items),
            Err(RuntimeError::BudgetExceeded { .. })
        ),
        "the budget is the only depth bound"
    );
}

#[test]
fn vm_budget_catches_non_terminating_programs() {
    // The termination ladder, end to end: read → expand → compile →
    // run under a tiny budget. The program is a self-call with no
    // base case — legal source, non-terminating behavior. With no
    // loop primitive and no tail-call reuse, every call pushes a
    // frame, every frame reserves, and the run must end in a
    // structured BudgetExceeded carrying the configured budget.
    let source = "fn f() { f() }\ndefine(r, f());";
    let forms = read_target_program(FileId(0), source).expect("reads");
    let items = expand_program(&forms).expect("expands");
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::with_budget(bc, 64).expect("builds");
    match vm.run() {
        Err(RuntimeError::BudgetExceeded { budget, .. }) => {
            assert_eq!(budget, 64, "the structured error carries the budget");
        }
        other => panic!("a self-call must exhaust the budget: {other:?}"),
    }
}

#[test]
fn vm_budget_counts_live_frames_exactly() {
    // The budget is the LIVE footprint (frames + live heap cells),
    // charged at every reserve. The single-call program's peak live
    // usage is exactly three units — the entry frame, the closure
    // cell materialized for `fn g() { 42 }` when the define stores
    // the function value, and the call frame for `g()` — so budget
    // 3 admits the run and budget 2 rejects it at the call frame:
    // the boundary is exact, not approximate.
    let source = "fn g() { 42 }\ndefine(r, g());";
    let forms = read_target_program(FileId(0), source).expect("reads");
    let items = expand_program(&forms).expect("expands");
    let bc = compile_program(&items).expect("compiles");

    let mut vm = Vm::with_budget(bc.clone(), 3).expect("builds");
    assert!(
        vm.run().is_ok(),
        "entry frame + closure cell + one call frame fits budget 3"
    );

    let mut vm = Vm::with_budget(bc, 2).expect("builds");
    match vm.run() {
        Err(RuntimeError::BudgetExceeded { budget, .. }) => {
            assert_eq!(budget, 2);
        }
        other => panic!("the third live unit must overflow budget 2: {other:?}"),
    }
}

#[test]
fn reader_nesting_cap_is_structured_at_the_boundary() {
    // The ladder's first rung, observed through the public read
    // face: 256 nested lists read fine (the in-crate boundary test
    // pins inclusivity), 257 fails with the structured error — the
    // payload carries the depth and the limit, never a stack
    // overflow.
    // The r151 twin: the paren run rides in a define (a bare run is
    // not a target top-level item); depth = 1 (the define call) + n.
    let deep = |n: usize| {
        let mut src = String::from("define(r, ");
        for _ in 0..n {
            src.push('(');
        }
        src.push('1');
        for _ in 0..n {
            src.push(')');
        }
        src.push_str(");");
        src
    };
    let ok = read_target_program(FileId(0), &deep(NESTING_LIMIT - 2)).expect("256-deep reads");
    assert!(!ok.is_empty());
    match read_target_program(FileId(0), &deep(NESTING_LIMIT)) {
        Err(ReadError::NestingDepthExceeded { depth, limit }) => {
            assert_eq!(limit, NESTING_LIMIT);
            assert!(depth > NESTING_LIMIT, "the offending depth is reported");
        }
        other => panic!("257-deep must fail structured: {other:?}"),
    }
}

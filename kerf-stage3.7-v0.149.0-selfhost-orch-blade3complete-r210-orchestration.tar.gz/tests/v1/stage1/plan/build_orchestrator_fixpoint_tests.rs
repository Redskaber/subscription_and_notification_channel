//! The W-SELFHOST-ORCH blade-3 completion round's fixpoint corpus
//! entry (the window's gate ⑤): the orchestrator enters the
//! fixpoint corpus.
//!
//! * **The macro three-way** (the fast face): (1) the Rust
//!   oracle's digest over the host-composed source (the O6 byte
//!   splice + the carrier assembly prefix), (2) the orchestrator's
//!   own artifact digest for the same carrier — the two
//!   compilation paths must land the one semantic artifact; and
//!   (3) the artifact EXECUTED on a fresh VM — the compiled
//!   library program is runnable, the behavioral face.
//! * **The self-carrier budget** (the heavyweight face): the
//!   seven-unit seed (the six chain units + build.ktf as the
//!   entry, ~16k composed lines) through the orchestrator's own
//!   pipeline. The binary judgment (the window's own rule): within
//!   the tier window = the full self-application enters the corpus
//!   (the S1 run, then the S2 fixpoint execution — executing S1
//!   over the same seed must reproduce S1's own artifact,
//!   digest(S2) == digest(S1)); over the window = the
//!   harness-limit honest registration + TD. Two legal states, no
//!   third.

use kerf::driver::{
    BUILD_TARGET_SOURCE, COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    STD_ERROR_TARGET_SOURCE, Session, TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE,
    assembled_build_source, carrier_assembly_prefix, compose_selfhost, parse_target,
    read_target_source_for_bootstrap, rebuild_bytecode, semantic_projection,
};
use kerf_vm::{BufferIo, Vm};

/// The deep-stack discipline (the sibling fixpoint family's
/// convention — the self-applied walks recurse through the
/// harness's Rust walkers).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The assembled orchestrator's A pass (the shared seed face — the
/// local-copy convention, the deep_stack precedent).
fn a_pass_compile() -> kerf_compiler::Bytecode {
    let assembled = assembled_build_source();
    let mut session = Session::with_segments(
        kerf::driver::ReadSegment::Rust,
        kerf::driver::ExpandSegment::Rust,
        kerf::driver::CheckSegment::Rust,
        kerf::driver::CompileSegment::Rust,
    );
    let program = parse_target(&mut session, "build-orchestrator.ktf", &assembled)
        .expect("the assembled orchestrator must parse");
    kerf_compiler::compile_program(&program.items).expect("the assembled orchestrator must compile")
}

/// The seed contract for one carrier unit set (B2).
fn seed_lines(units: &[(&str, &str)]) -> Vec<String> {
    let mut lines = vec![units.len().to_string()];
    for (name, source) in units {
        let src_lines: Vec<&str> = source.lines().collect();
        lines.push((*name).to_string());
        lines.push(src_lines.len().to_string());
        lines.extend(src_lines.iter().map(|s| s.to_string()));
    }
    lines
}

#[test]
fn the_macro_carrier_three_way_identity() {
    deep_stack(|| {
        // (1) The Rust oracle: the host-composed source (the two
        // import lines replaced by the unit sources, the O6 byte
        // splice) + the carrier assembly prefix, read + compiled
        // through the plain production pipeline.
        let entry = "import \"std/error\";\nimport \"macro\";\n";
        let composed = compose_selfhost(entry);
        let assembled = format!("{}{}", carrier_assembly_prefix(), composed);
        let oracle_items = read_target_source_for_bootstrap("macro-family.ktf", &assembled)
            .expect("the assembled macro family must read");
        let oracle_bc = kerf_compiler::compile_program(&oracle_items)
            .expect("the oracle must compile the assembled macro family");
        let oracle_digest = semantic_projection(&oracle_bc);

        // (2) The orchestrator's own artifact for the same carrier.
        let bc = a_pass_compile();
        let seed = seed_lines(&[
            ("std/error", STD_ERROR_TARGET_SOURCE),
            ("macro", MACRO_TARGET_SOURCE),
            ("entry", entry),
        ]);
        let mut vm = Vm::with_io(bc, Box::new(BufferIo::with_input(seed.iter())))
            .expect("the vm must accept the orchestrator");
        if let Err(err) = vm.run() {
            let out = vm.take_output();
            panic!("the orchestrator run failed: {err:?} -- output so far: {out:?}");
        }
        let out = vm.take_output();
        assert!(
            out.contains(&"[orchestrator] compiled".to_string()),
            "the milestone stream must close: {out:?}"
        );
        let value = vm.global("result").expect("the result global");
        let (head, _) = value.as_pair(vm.heap()).expect("the verdict record");
        let tag = match head {
            kerf_vm::Value::Str(s) => s.to_string(),
            other => format!("{other:?}"),
        };
        assert_eq!(tag, "ok", "the macro carrier verdict must be ok");
        let orch_bc =
            rebuild_bytecode(value, vm.heap()).expect("the orchestrator's artifact must rebuild");
        let orch_digest = semantic_projection(&orch_bc);
        assert_eq!(
            orch_digest, oracle_digest,
            "the two compilation paths must land the one semantic artifact"
        );

        // (3) The artifact EXECUTED on a fresh VM: the compiled
        // macro-family program is a runnable library program — the
        // behavioral face (the corpus's executed row).
        let mut exec = Vm::with_io(
            orch_bc,
            Box::new(BufferIo::with_input(std::iter::empty::<String>())),
        )
        .expect("the vm must accept the artifact");
        exec.run()
            .expect("the compiled macro-family program must execute cleanly");
    });
}

#[test]
fn the_self_carrier_budget_measurement() {
    deep_stack(|| {
        // The seven-unit seed: the six chain units + build.ktf as
        // the entry (the LAST unit) — the orchestrator's own import
        // graph, ~16k composed lines. The budget disclosure rides
        // the elapsed lines; the tier window is the ceiling face
        // (the binary judgment's enforcement — over the window =
        // the harness-limit honest registration + TD).
        // The build unit rides the hosting tail (the A-pass
        // assembly's own convention): the entry's last form drives
        // kb_main, so the compiled artifact IS the orchestrator
        // program — executing it (the S2 fixpoint run) reproduces
        // the whole drive, and the three-way lands: the A-pass host
        // arm, the S1 self-compiled arm, the S2 fixpoint arm.
        let build_with_tail = format!("{}\ndefine(result, kb_main());\n", BUILD_TARGET_SOURCE);
        let units: Vec<(&str, &str)> = vec![
            ("std/error", STD_ERROR_TARGET_SOURCE),
            ("macro", MACRO_TARGET_SOURCE),
            ("target-lexer", TARGET_LEXER_TARGET_SOURCE),
            ("target-parser", TARGET_PARSER_TARGET_SOURCE),
            ("expander", EXPANDER_TARGET_SOURCE),
            ("compiler", COMPILER_TARGET_SOURCE),
            ("build", build_with_tail.as_str()),
        ];
        let seed = seed_lines(&units);
        let bc = a_pass_compile();
        let t0 = std::time::Instant::now();
        // The heavyweight tier's explicit budget (the r146 ex_limit
        // parameterization precedent): the self-carrier's expansion
        // measures ~19M allocation units at 16.3k composed lines —
        // the production default (16M) dies at 99% through (the
        // span lands ~500 bytes short of the carrier's end — the
        // r210 measurement, TD-037). The 64M ride is 3x the
        // measured need; the disclosure is the case's own budget
        // face, never a silent raise.
        let mut vm = Vm::with_budget_and_io(
            bc.clone(),
            67_108_864,
            Box::new(BufferIo::with_input(seed.iter())),
        )
        .expect("the vm must accept the orchestrator");
        if let Err(err) = vm.run() {
            let out = vm.take_output();
            panic!("the self-carrier S1 run failed: {err:?} -- output so far: {out:?}");
        }
        let s1_elapsed = t0.elapsed();
        let out = vm.take_output();
        if !out.contains(&"[orchestrator] compiled".to_string()) {
            // The r209 digest-probe discipline: decode the verdict
            // payload — the error's own words, never a bare red.
            let value = vm.global("result").expect("the result global");
            if let Some((_, rest)) = value.as_pair(vm.heap()) {
                let mut cur = rest.clone();
                let mut depth = 0;
                eprintln!("SELF-CARRIER VERDICT WALK:");
                while depth < 8 {
                    match cur.as_pair(vm.heap()) {
                        Some((head, tail)) => {
                            let h = match head {
                                kerf_vm::Value::Str(t) => t.to_string(),
                                kerf_vm::Value::Int(i) => i.to_string(),
                                other => format!("{other:?}"),
                            };
                            eprintln!("  [{depth}] {h}");
                            cur = tail.clone();
                            depth += 1;
                        }
                        None => break,
                    }
                }
            }
            panic!("the self-carrier milestone stream must close: {out:?}");
        }
        let value = vm.global("result").expect("the result global");
        let (head, _) = value.as_pair(vm.heap()).expect("the verdict record");
        let tag = match head {
            kerf_vm::Value::Str(s) => s.to_string(),
            other => format!("{other:?}"),
        };
        assert_eq!(tag, "ok", "the self-carrier verdict must be ok");
        let s1_bc =
            rebuild_bytecode(value, vm.heap()).expect("the self-carrier S1 artifact must rebuild");
        let s1_digest = semantic_projection(&s1_bc);
        // The host arm (the three-way's first face): the A-pass
        // bytecode — the same logical program, host-compiled — must
        // project to the same digest.
        assert_eq!(
            semantic_projection(&bc),
            s1_digest,
            "the A-pass host arm must land the self-carrier's one semantic artifact"
        );
        drop(vm);
        // RELEASE the S1 heap before the S2 run: the two ~2GB heaps
        // do not coexist on this machine (the SIGKILL lesson — the
        // S2 phase ran out of memory while the S1 heap was still
        // held; the assertions above are complete, the heap can go).

        // The fixpoint execution: S1 (the orchestrator compiled by
        // the orchestrator) drives the SAME seed on a fresh VM and
        // must reproduce its own artifact — O(O(S)) == O(S).
        let t1 = std::time::Instant::now();
        let mut exec = Vm::with_budget_and_io(
            s1_bc,
            67_108_864,
            Box::new(BufferIo::with_input(seed.iter())),
        )
        .expect("the vm must accept the S1 artifact");
        if let Err(err) = exec.run() {
            let out = exec.take_output();
            panic!("the self-carrier S2 fixpoint run failed: {err:?} -- output so far: {out:?}");
        }
        let s2_elapsed = t1.elapsed();
        let exec_out = exec.take_output();
        assert_eq!(
            exec_out, out,
            "the S1-executed milestone stream must equal the A-pass-driven one"
        );
        let s2_value = exec.global("result").expect("the S2 result global");
        let s2_bc = rebuild_bytecode(s2_value, exec.heap()).expect("the S2 artifact must rebuild");
        let s2_digest = semantic_projection(&s2_bc);
        assert_eq!(
            s2_digest, s1_digest,
            "the fixpoint must hold: the self-compiled orchestrator reproduces its own artifact"
        );
        eprintln!(
            "SELF-CARRIER BUDGET: S1 run {s1_elapsed:?} + S2 fixpoint {s2_elapsed:?} (the binary judgment's disclosure)"
        );
    });
}

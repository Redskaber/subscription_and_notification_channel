//! The W-EFFECT-MECHANISM blade-3 corpus face (w-effect-mechanism-window
//! §6 blade 3 — the `corpus-effect/` family's own sweep): every case
//! through the PRODUCTION twin segments with the `// expect:` line
//! owning the verdict, exactly as the r185 corpus-row precedent (the
//! rw-type sweep wiring — RW-18's segment coverage carried to the
//! effect family).
//!
//! The sweep's layer split is the effect family's own honest face: the
//! four verdict arms name WHICH layer owns the rejection —
//!
//!   * `value N` — the full chain runs and the result global pins N;
//!   * `read-error` — the twin read/expansion segments reject (the
//!     handle grammar's own keys);
//!   * `type-error` — the parse succeeds and the check face reports an
//!     Error finding (E0005 the top-level arity rule, E0006 the row
//!     escape, E0009/E0013 the operand and annotation faces);
//!   * `runtime-error` — the parse and the check face both pass and
//!     the VM run fails (the fn-body channel's disclosed no-gate
//!     boundary: the unhandled effect, the routing miss, the
//!     one-shot continuation arity family, the continuation-as-value
//!     operand family).
//!
//! The population: 10 positive value rows (the degenerate compat face,
//! the k-form resume, the one-shot halt, the return clause in both
//! forms, the resume-value arithmetic flow, the two-clause dispatch,
//! the multi-arg degenerate) against 18 negative rows at 1:3-leaning
//! (3 read + 7 type + 8 runtime — the runtime arm is the blade-1/2
//! deepening's own verification face, absent from the row family; the
//! authoring-time catches: the empty clause list is legal grammar and
//! the check face reads it as non-coverage (E0006), the clause-body
//! operand face checks clean and fails at the VM — both pinned in
//! place by their expect lines).

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs, so the driver needs the large stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join")
}

/// One production-chain parse: the twin read and expansion verdicts.
fn parse(source: &str) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    parse_target(&mut session, "effect-case.ktf", source)
}

/// One production-chain run: parse, check, compile, VM execute — the
/// `define(result, ...)` convention pins the program's value.
fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let program = parse(source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

// ---------- the corpus-effect sweep (the rw-type wiring, effect family) ----------

/// The `corpus-effect/` source family: every case through the
/// PRODUCTION twin segments with the `// expect:` line owning the
/// verdict. The oracle never sees these sources (the r174 exemption
/// face — the sweep is the twin's own, the corpus discipline carried
/// from the row family to the effect family).
#[test]
fn efx_corpus_sweep_holds_the_effect_family() {
    deep_stack(|| {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus-effect");
        let entries = std::fs::read_dir(dir).expect("the corpus-effect directory is in tree");
        // The mechanism family's own files only: the blade-1/2/3
        // instance families (`ef-{state,error,log,io,async}-*`,
        // W-EFFECT-INSTANCES) ride their own sweep with the
        // std-library prefix injected — the mechanism cases carry
        // no library vocabulary, so the two sweeps stay disjoint by
        // filename family.
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension().is_some_and(|x| x == "ktf")
                    && !p.file_name().and_then(|n| n.to_str()).is_some_and(|n| {
                        n.starts_with("ef-state-")
                            || n.starts_with("ef-error-")
                            || n.starts_with("ef-log-")
                            || n.starts_with("ef-io-")
                            || n.starts_with("ef-async-")
                            || n.starts_with("ef-render-")
                    })
            })
            .collect();
        files.sort();
        assert!(
            files.len() >= 28,
            "the effect corpus expects the blade-3 population (10 positive + 18 negative), got {}",
            files.len()
        );
        let mut values = 0usize;
        let mut read_rejections = 0usize;
        let mut type_rejections = 0usize;
        let mut runtime_rejections = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let expect = source
                .lines()
                .find_map(|l| l.strip_prefix("// expect: "))
                .unwrap_or_else(|| panic!("{case} carries an expect line"));
            if let Some(v) = expect.strip_prefix("value ") {
                let got = run(&source).unwrap_or_else(|d| panic!("{case} runs: {d:?}"));
                assert_eq!(
                    got.trim(),
                    v,
                    "{case} the result global pins the expected value"
                );
                values += 1;
            } else if expect.contains("read-error") {
                parse(&source).expect_err(&format!("{case} rejects at the read layer"));
                read_rejections += 1;
            } else if expect.contains("type-error") {
                // The read layer does not own the verdict: the case
                // parses, and the check face reports an Error finding.
                let program = parse(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the type face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} rejects at the type layer"
                );
                type_rejections += 1;
            } else {
                assert!(
                    expect.contains("runtime-error"),
                    "{case} carries a known expectation, got {expect}"
                );
                // Neither the read layer nor the check face owns the
                // verdict: the case parses AND checks clean, and the
                // VM run fails (the fn-body channel's disclosed
                // no-gate boundary — the honest runtime face).
                let program = parse(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the runtime face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    !findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} checks clean (the runtime face owns the verdict): {findings:?}"
                );
                assert!(run(&source).is_err(), "{case} fails at the runtime layer");
                runtime_rejections += 1;
            }
        }
        assert!(
            values >= 8 && read_rejections >= 3 && type_rejections >= 5 && runtime_rejections >= 5,
            "the sweep expects the 1:3-leaning population (>=8 values, >=3 read, \
             >=5 type, >=5 runtime), got {values} values + {read_rejections} read \
             + {type_rejections} type + {runtime_rejections} runtime"
        );
    });
}

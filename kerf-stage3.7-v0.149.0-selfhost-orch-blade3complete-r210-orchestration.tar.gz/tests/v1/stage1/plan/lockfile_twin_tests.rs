//! Lockfile twin tests (W-PKG-SELFHOST blade 3, part one —
//! w-pkg-selfhost-window §4 row 3): the package manager's kerf.lock
//! model and deterministic serializer, the COMPOSED program
//! `micro-toml.ktf + semver.ktf + lockfile.ktf`, against the Rust
//! oracle `kerf_pkg::Lockfile::{new,to_text,parse}` through the full
//! `.ktf` chain on BOTH engines — the twelfth selfhost twin.
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the parse roundtrip family (a minimal lockfile,
//!   the multi-entry canonical roundtrip, a nested source tree, the
//!   zero-format-version face) plus the render family (single
//!   entries, the multi-entry BTreeMap normalization, the
//!   non-canonical version re-render, the empty table), each case
//!   pinned three-way (oracle == twin-vm == twin-eval) BYTE-EXACT
//!   on the canonical text.
//! * **Negative** — the six rejection tribes of the blade row (the
//!   globals tribe, the format tribe, the entry-value tribe, the
//!   missing-field tribe including the close-before-head order, the
//!   section tribe, the nested semver tribe, the micro-toml syntax
//!   pass-through), each case asserting the three-way agreement on
//!   the SAME rendered error line.
//! * **Cross-stage consumption** — the composed program's pieces are
//!   the blade 1 and blade 2 twins verbatim: the embedding test pins
//!   all three disk files against their compiled-in sources.
//!
//! The deep-stack discipline follows the sibling twin tests: the
//! frozen subset expresses iteration only through self-recursion,
//! so the harness rides a demand-allocated stack thread.

use kerf::driver::{
    LOCKFILE_RENDER_CASES, LOCKFILE_RENDER_MULTI, LOCKFILE_RENDER_NONCANON, LOCKFILE_TARGET_SOURCE,
    LOCKFILE_TWIN_CASES, lockfile_parity, lockfile_render_parity,
};

/// Every twin drive walks the harness Rust walkers and both
/// engines' per-record frames — the sibling tests' demand-allocated
/// stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the parse roundtrip family ----------

#[test]
fn parse_cases_hold_three_way_parity() {
    deep_stack(|| {
        for (name, source) in LOCKFILE_TWIN_CASES.iter().take(4) {
            lockfile_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- positive: the render family ----------

#[test]
fn render_cases_hold_three_way_parity() {
    deep_stack(|| {
        // The empty table first (the deterministic zero-entry face).
        lockfile_render_parity("empty-table", &[]).unwrap_or_else(|e| panic!("{e}"));
        for (name, n, v, s) in LOCKFILE_RENDER_CASES {
            lockfile_render_parity(name, &[(n, v, s)]).unwrap_or_else(|e| panic!("{e}"));
        }
        // The multi-entry fixture: unsorted input, the BTreeMap
        // name order normalization (zeta, alpha, mid -> alpha,
        // mid, zeta).
        lockfile_render_parity("multi-unsorted", LOCKFILE_RENDER_MULTI)
            .unwrap_or_else(|e| panic!("{e}"));
        // The non-canonical version: `0.01.2` parses and re-renders
        // `0.1.2` (the parse-then-Display discipline).
        lockfile_render_parity("noncanon-version", LOCKFILE_RENDER_NONCANON)
            .unwrap_or_else(|e| panic!("{e}"));
    });
}

// ---------- negative: the rejection tribes ----------

#[test]
fn rejection_cases_agree_three_way_on_the_same_key() {
    deep_stack(|| {
        for (name, source) in LOCKFILE_TWIN_CASES.iter().skip(4) {
            lockfile_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage: the composition ----------

/// The composed program's pieces are the blade 1 and blade 2 twins
/// verbatim — pin the three embeddings against their disk files
/// (the tree-asset face the sibling twins' tests hold).
#[test]
fn composed_sources_match_disk() {
    let base = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1/");
    let mt = std::fs::read_to_string(format!("{base}micro-toml.ktf"))
        .expect("the micro-toml twin reads from disk");
    let sv = std::fs::read_to_string(format!("{base}semver.ktf"))
        .expect("the semver twin reads from disk");
    let lk = std::fs::read_to_string(format!("{base}lockfile.ktf"))
        .expect("the lockfile twin reads from disk");
    assert_eq!(
        kerf::driver::MICRO_TOML_TARGET_SOURCE,
        mt,
        "the blade 1 embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::SEMVER_TARGET_SOURCE,
        sv,
        "the blade 2 semver embedding and disk agree"
    );
    assert_eq!(
        LOCKFILE_TARGET_SOURCE, lk,
        "the blade 3 lockfile embedding and disk agree"
    );
}

//! The render vocabulary's harness family (W-SELFHOST-ORCH blade 2
//! — the GATE 6 composition, the window §10 O7).
//!
//! The builtin's own unit faces (the registry row, the arity, the
//! shared dispatch, the display single source) are pinned in the
//! vm crate's registry tests and the runtime dispatch probes; the
//! corpus family (`ef-render-*`, eight cases at 1:3) pins the
//! boundary faces through the four verdict arms; this family pins
//! the REAL faces the corpus form cannot express:
//!
//! - the serialization golden: the census — every value kind rides
//!   the channel as the host display text, digit-by-digit, and the
//!   recorded lines are double-pinned against the host-side Value
//!   display of the same census (the in-language render == the
//!   host Display — the ORCH-D caliber, the exact wording of the
//!   blade-2 gate);
//! - the census extensions the `// io-out:` corpus form cannot
//!   construct: the builtin markers (the render renders itself and
//!   its write sibling), the closure marker, and the continuation
//!   marker (a custom clause renders its own k — the continuation
//!   value only exists inside a clause body);
//! - the vocabulary's own resume face: the perform's value is the
//!   nil confirmation and the body continues in direct style (the
//!   write pack's form, extended to the value face);
//! - the skin reach: render_line reaches the render-line global
//!   through the skin.rs Rule K separator — the io pair's explicit
//!   table is NOT extended (the general rule covers the new
//!   spelling; every corpus case rides this by reference).

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Builtin, Value};

/// The std instance libraries (INST-1 channel (a), the instance
/// family's own mounting): the seven packs — the census consumes
/// the render vocabulary by reference, never by copy.
const STATE_LIB: &str = include_str!("../../../../selfhost/std/state.ktf");
const ERROR_LIB: &str = include_str!("../../../../selfhost/std/error.ktf");
const LOG_LIB: &str = include_str!("../../../../selfhost/std/log.ktf");
const READ_LIB: &str = include_str!("../../../../selfhost/std/read.ktf");
const WRITE_LIB: &str = include_str!("../../../../selfhost/std/write.ktf");
const ASYNC_LIB: &str = include_str!("../../../../selfhost/std/async.ktf");
const RENDER_LIB: &str = include_str!("../../../../selfhost/std/render.ktf");

/// The assembled prefix (the instance family's form).
fn instance_prefix() -> String {
    format!(
        "{STATE_LIB}\n{ERROR_LIB}\n{LOG_LIB}\n{READ_LIB}\n{WRITE_LIB}\n{ASYNC_LIB}\n{RENDER_LIB}\n"
    )
}

/// The deep-stack convention (the instance family's own form): the
/// twin segments compile the selfhost-scale prefix.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join");
}

/// One production-chain run (the prefix injected): parse, check,
/// compile, VM execute — returning the recorded output lines.
fn run_lines(src: &str) -> Vec<String> {
    let mut session = Session::new();
    let assembled = format!("{}{src}", instance_prefix());
    let program =
        parse_target(&mut session, "render-vocab-case.ktf", &assembled).unwrap_or_else(|d| {
            panic!(
                "the render-vocab case must parse: {}",
                d.iter()
                    .map(|x| x.message.clone())
                    .collect::<Vec<_>>()
                    .join("; ")
            )
        });
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::new())).expect(
        "the render-vocab case runs clean (the boundary faces live in the corpus family, not here)",
    );
    outcome.outputs
}

#[test]
fn census_golden_matches_the_host_display_digit_by_digit() {
    deep_stack(|| {
        // The census: every value kind through the render channel.
        let src = concat!(
            "fn p() {\n",
            "    perform render(\"out\", 42);\n",
            "    perform render(\"out\", -7);\n",
            "    perform render(\"out\", 2.5);\n",
            "    perform render(\"out\", true);\n",
            "    perform render(\"out\", false);\n",
            "    perform render(\"out\", \"ab\");\n",
            "    perform render(\"out\", nil);\n",
            "    perform render(\"out\", cons(1, 2));\n",
            "    perform render(\"out\", write_line);\n",
            "    perform render(\"out\", render_line);\n",
            "    nil\n",
            "}\n",
            "define(result, with_render(p));\n",
        );
        let emitted = run_lines(src);
        // The host-side display of the same census — the exact
        // single source the harness renders verdicts through (the
        // opaque pair marker and the builtin markers are the
        // context-free display's own forms, heap-independent).
        let host_display: Vec<String> = [
            Value::Int(42),
            Value::Int(-7),
            Value::Float(2.5),
            Value::Bool(true),
            Value::Bool(false),
            Value::Str("ab".into()),
            Value::Nil,
            Value::Pair(3),
            Value::Builtin(Builtin::WriteLine),
            Value::Builtin(Builtin::RenderLine),
        ]
        .iter()
        .map(|v| v.to_string())
        .collect();
        // Digit-by-digit: the in-language render == the host
        // Display (the blade-2 gate's exact caliber).
        assert_eq!(emitted, host_display);
        // The pinned texts (the golden's own ledger — a drift in
        // the host display itself fails here loudly, not silently).
        assert_eq!(
            host_display,
            vec![
                "42",
                "-7",
                "2.5",
                "true",
                "false",
                "\"ab\"",
                "nil",
                "#<pair>",
                "#<builtin:write-line>",
                "#<builtin:render-line>",
            ]
        );
    });
}

#[test]
fn census_extensions_the_markers_the_corpus_form_cannot_pin() {
    deep_stack(|| {
        // The closure marker (a fn literal in value position) and
        // the continuation marker (a custom clause renders its own
        // k — the continuation value only exists inside a clause
        // body; the render rides the OUTER with_render while the
        // inner handle answers the probe).
        let src = concat!(
            "fn p() {\n",
            "    perform render(\"out\", || { 1 });\n",
            "    perform render(\"out\", handle (perform probe(\"x\")) {\n",
            "        probe(v, k) => { perform render(\"out\", k); k(1) },\n",
            "    });\n",
            "    nil\n",
            "}\n",
            "define(result, with_render(p));\n",
        );
        let emitted = run_lines(src);
        assert_eq!(
            emitted,
            vec![
                "#<closure>".to_string(),
                "#<continuation>".to_string(),
                "1".to_string(),
            ]
        );
    });
}

#[test]
fn the_resume_face_is_nil_and_the_body_continues_in_direct_style() {
    deep_stack(|| {
        // The write pack's form extended to the value face: the
        // perform's value is the nil confirmation and code after a
        // render RUNS (the direct-style continuation) — the body's
        // branch proves both confirms carried nil and the program
        // continued past each render.
        let src = concat!(
            "fn p() {\n",
            "    let a = perform render(\"out\", 1);\n",
            "    let b = perform render(\"out\", 2);\n",
            "    if (is_nil(a) && is_nil(b)) { 3 } else { 0 }\n",
            "}\n",
            "define(result, with_render(p));\n",
        );
        let mut session = Session::new();
        let assembled = format!("{}{src}", instance_prefix());
        let program = parse_target(&mut session, "render-vocab-case.ktf", &assembled)
            .expect("the resume-face case parses");
        let outcome = program
            .run(Engine::Vm, Box::new(BufferIo::new()))
            .expect("the resume-face case runs clean");
        let r = outcome
            .globals
            .iter()
            .find(|(name, _)| name.as_str() == "result")
            .map(|(_, v)| v.clone())
            .unwrap_or(Value::Nil);
        assert_eq!(
            r,
            Value::Int(3),
            "both confirms are nil and the body continues"
        );
        assert_eq!(outcome.outputs, vec!["1".to_string(), "2".to_string()]);
    });
}

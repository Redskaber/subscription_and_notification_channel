//! The W-EFFECT-INSTANCES instance corpus face (blades 1-3,
//! w-effect-instances-window §5.1 INST-1 channel (a) — the
//! prefix-injection ruling): every `ef-state-*` / `ef-error-*` /
//! `ef-log-*` / `ef-io-*` / `ef-async-*` / `ef-render-*` case in
//! `corpus-effect/` through the PRODUCTION twin segments with the
//! `// expect:` line owning the verdict, exactly as the mechanism
//! sweep precedent (efx_corpus_sweep) — with the one extension the
//! ruling names: the std library files (`selfhost/std/{state,error,
//! log,read,write,async,render}.ktf`) ride as the assembled
//! program's PREFIX (the tp_limit budget-prefix precedent shape),
//! so the corpus cases consume the library vocabulary by
//! reference, never by copy (the single-source discipline).
//!
//! The blade-2 extension (the bidirectional buffer pinning): the
//! `// io-in: <line>` directives seed the BufferIo input
//! front-first (one line per directive, order preserved) and the
//! `// io-out: <line>` directives pin the recorded output lines
//! (the write bridge's side-effect face — `RunOutcome.outputs`),
//! so the IO family's value cases verify BOTH the result global
//! and the channel's two directions.
//!
//! The four verdict arms are the mechanism family's own (which
//! layer owns the rejection), plus the value arm:
//!
//!   * `value N` — the full chain runs and the result global pins N;
//!   * `read-error` — the twin read/expansion segments reject;
//!   * `type-error` — the parse succeeds and the check face reports
//!     an Error finding;
//!   * `runtime-error` — parse and check both pass and the VM run
//!     fails (the unhandled-effect family, the driver-protocol
//!     family, the cross-family orthogonality family, the
//!     strict-face and end-of-input boundary families).
//!
//! The population (the window §6 blade gates): 48 cases — the
//! blade-1 trio (2 positive + 6 negative per family: State /
//! Error / Log) plus the blade-2 IO family (2 positive + 6
//! negative: the seeded read, the write resume, the orthogonality
//! and composition boundaries, the strict-string face, the
//! top-level E0006, the end-of-input fail-closed, the unclosed
//! string) plus the blade-3 Async family (2 positive + 6
//! negative: the sync pass-through, the nested re-entrant
//! routing, the orthogonality miss, the strict-thunk face, the
//! top-level E0006, the non-program driver call, the unclosed
//! string, the k-form fall-through) plus the ORCH blade-2 Render
//! family (2 positive + 6 negative: the display census, the
//! direct-style resume, the orthogonality and composition
//! boundaries, the confirmation-not-text interplay, the arity
//! face, the top-level E0006, the unclosed string) — the 12:36
//! sum sitting exactly at 1:3, every arm covered.

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The std instance libraries (INST-1 channel (a)): mounted from
/// the crate root, exactly as the selfhost twins mount their
/// targets — the library files are the vocabulary's single source.
const STATE_LIB: &str = include_str!("../../../../selfhost/std/state.ktf");
const ERROR_LIB: &str = include_str!("../../../../selfhost/std/error.ktf");
const LOG_LIB: &str = include_str!("../../../../selfhost/std/log.ktf");
const READ_LIB: &str = include_str!("../../../../selfhost/std/read.ktf");
const WRITE_LIB: &str = include_str!("../../../../selfhost/std/write.ktf");
const ASYNC_LIB: &str = include_str!("../../../../selfhost/std/async.ktf");
const RENDER_LIB: &str = include_str!("../../../../selfhost/std/render.ktf");

/// The assembled prefix: the seven libraries ride ahead of every
/// instance case (the families are orthogonal — an unused library's
/// defines cost nothing at run time).
fn instance_prefix() -> String {
    format!(
        "{STATE_LIB}\n{ERROR_LIB}\n{LOG_LIB}\n{READ_LIB}\n{WRITE_LIB}\n{ASYNC_LIB}\n{RENDER_LIB}\n"
    )
}

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs, so the driver needs the large stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join")
}

/// One production-chain parse of a case (the prefix injected): the
/// twin read and expansion verdicts.
fn parse_case(
    case_source: &str,
) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    let assembled = format!("{}{case_source}", instance_prefix());
    parse_target(&mut session, "effect-instance-case.ktf", &assembled)
}

/// One production-chain run of a case (the prefix injected, the
/// seeded channel): parse, check, compile, VM execute — the
/// `define(result, ...)` convention pins the program's value and
/// the recorded output lines pin the write bridge's side-effect
/// face (the bidirectional buffer, blade 2).
fn run_case(
    case_source: &str,
    seed: &[String],
) -> Result<(String, Vec<String>), Vec<kerf::driver::Diagnostic>> {
    let program = parse_case(case_source)?;
    let mut io = BufferIo::new();
    for line in seed {
        io.push_input(line.clone());
    }
    let outcome = program.run(Engine::Vm, Box::new(io))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok((format!("{entry}"), outcome.outputs))
}

/// The instance families' own sweep: every
/// `ef-{state,error,log,io,async,render}-*` case through the four verdict
/// arms, with the population gate the window's blade tables state
/// (per family ≥8 = ≥2 positive + ≥6 negative; the 12:36 sum at
/// 1:3; every arm covered).
#[test]
fn efx_instance_sweep_holds_the_six_families() {
    deep_stack(|| {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus-effect");
        let entries = std::fs::read_dir(dir).expect("the corpus-effect directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension().is_some_and(|x| x == "ktf")
                    && p.file_name().and_then(|n| n.to_str()).is_some_and(|n| {
                        n.starts_with("ef-state-")
                            || n.starts_with("ef-error-")
                            || n.starts_with("ef-log-")
                            || n.starts_with("ef-io-")
                            || n.starts_with("ef-async-")
                            || n.starts_with("ef-render-")
                    })
            })
            .collect();
        files.sort();
        assert!(
            files.len() >= 48,
            "the instance corpus expects the blade-1 + blade-2 + blade-3 + ORCH blade-2 population (2+6 per \
             family), got {}",
            files.len()
        );
        let mut values = 0usize;
        let mut read_rejections = 0usize;
        let mut type_rejections = 0usize;
        let mut runtime_rejections = 0usize;
        let mut state_family = 0usize;
        let mut error_family = 0usize;
        let mut log_family = 0usize;
        let mut io_family = 0usize;
        let mut async_family = 0usize;
        let mut render_family = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            if case.starts_with("ef-state-") {
                state_family += 1;
            } else if case.starts_with("ef-error-") {
                error_family += 1;
            } else if case.starts_with("ef-log-") {
                log_family += 1;
            } else if case.starts_with("ef-io-") {
                io_family += 1;
            } else if case.starts_with("ef-render-") {
                render_family += 1;
            } else {
                async_family += 1;
            }
            let expect = source
                .lines()
                .find_map(|l| l.strip_prefix("// expect: "))
                .unwrap_or_else(|| panic!("{case} carries an expect line"));
            // The bidirectional channel directives (blade 2): each
            // `// io-in: X` seeds one input line front-first; each
            // `// io-out: X` pins one recorded output line in order.
            let seed: Vec<String> = source
                .lines()
                .filter_map(|l| l.strip_prefix("// io-in: "))
                .map(|l| l.to_string())
                .collect();
            let want_out: Vec<String> = source
                .lines()
                .filter_map(|l| l.strip_prefix("// io-out: "))
                .map(|l| l.to_string())
                .collect();
            if let Some(v) = expect.strip_prefix("value ") {
                let (got, outputs) =
                    run_case(&source, &seed).unwrap_or_else(|d| panic!("{case} runs: {d:?}"));
                assert_eq!(
                    got.trim(),
                    v,
                    "{case} the result global pins the expected value"
                );
                if !want_out.is_empty() {
                    assert_eq!(
                        outputs, want_out,
                        "{case} the recorded channel output pins the expected lines"
                    );
                }
                values += 1;
            } else if expect.contains("read-error") {
                parse_case(&source).expect_err(&format!("{case} rejects at the read layer"));
                read_rejections += 1;
            } else if expect.contains("type-error") {
                // The read layer does not own the verdict: the case
                // parses, and the check face reports an Error finding.
                let program = parse_case(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the type face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} rejects at the type layer"
                );
                type_rejections += 1;
            } else {
                assert!(
                    expect.contains("runtime-error"),
                    "{case} carries a known expectation, got {expect}"
                );
                // Neither the read layer nor the check face owns the
                // verdict: the case parses AND checks clean, and the
                // VM run fails.
                let program = parse_case(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the runtime face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    !findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} checks clean (the runtime face owns the verdict): {findings:?}"
                );
                assert!(
                    run_case(&source, &seed).is_err(),
                    "{case} fails at the runtime layer"
                );
                runtime_rejections += 1;
            }
        }
        assert!(
            state_family >= 8
                && error_family >= 8
                && log_family >= 8
                && io_family >= 8
                && async_family >= 8
                && render_family >= 8,
            "each instance family carries its own population (>=8), got state {state_family} \
             + error {error_family} + log {log_family} + io {io_family} \
             + async {async_family} + render {render_family}"
        );
        assert!(
            values >= 12
                && read_rejections >= 4
                && type_rejections >= 4
                && runtime_rejections >= 24,
            "the sweep expects the 1:3 population with every arm covered (>=12 values, >=4 read, \
             >=4 type, >=24 runtime), got {values} values + {read_rejections} read \
             + {type_rejections} type + {runtime_rejections} runtime"
        );
    });
}

//! The W-EFFECT-MECHANISM blade-1 golden corpus (the r186 window's
//! §6 blade table — the value-layer/VM semantic deepening): the
//! one-shot recoverable semantics over the production chain (the
//! twin read + expand + check + compile segments, then the VM —
//! `Engine::Vm` through `ParsedProgram::run`, the row-skin golden's
//! own convention).
//!
//! The ruling table (w-effect-mechanism-window.md §5.1) under test:
//! - the DEGENERATE form (clause params == perform args) keeps the
//!   0.6 capture-replacement — the clause's return value IS the
//!   perform's value and the body continues (the compat ruling: the
//!   pos-021 family pins it bit-for-bit — zero drift);
//! - the K-FORM (clause params == perform args + 1) carries the
//!   trailing one-shot continuation: `k(v)` resumes the captured
//!   point; a plain clause return HALTS (the handle expression takes
//!   the clause's return value and the body is discarded);
//! - the RETURN clause converts the body's normal completion into
//!   the return-perform's handler branch (the pop-handler's `b`
//!   operand carries the clause's effect global);
//! - the one-shot discipline is fail-closed: the second call of the
//!   same continuation is a runtime error, never a silent re-entry.
//!
//! Case plan (the row-skin 1:3 precedent): 6 positive + 18 negative.
//! The k-form rides fn-body performs only — the check face keeps its
//! strict top-level arity rule (an immediate top-level perform with
//! a params==args+1 clause is E0005 exactly as neg-034 always pinned;
//! the fn-body channel is where the dynamic-context soundness
//! argument already lives — the checker's own module docs).
//!
//! The one-shot REUSE family (the second call of a consumed
//! continuation) lives in the VM's in-crate tests (`vm::tests::
//! oneshot_second_resume_is_fail_closed`) — the raw-VM home: the
//! type layer cannot express the carry (the occurs check blocks the
//! value channel `k(cons(x, k))`; the handle's degenerate typing
//! blocks the halt carry `cdr(handle_value)`). The blade-2 type
//! face (the effect-row consumption) is where the typing gap
//! closes; until then the driver-level corpus stays within the
//! type-expressible violation space.
//!
//! Deferred to blade 3's corpus-effect/ family (disclosed, not
//! dropped): the return-branch k-form HALT variant and the
//! nested-halt family ride the same ext2 path as the pinned halt —
//! the mark's target differs only in its (frame, pc) values.

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs (the steady chain), so the driver needs
/// the large thread stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join");
}

/// One production-chain parse: the twin read and expansion verdicts
/// (an error renders the segment's own diagnostics).
fn parse(source: &str) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    parse_target(&mut session, "effect-oneshot-case.ktf", source)
}

/// One production-chain run: parse, check, compile, VM execute — the
/// `result` global's display text (the row-skin golden convention).
fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let program = parse(source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

/// The one-line rejection probe: the run's joined diagnostic text
/// (parse, check, compile, and runtime errors all land here — the
/// check face's E0005/E0006 and the VM's one-shot family alike).
fn fail_text(source: &str) -> String {
    match run(source) {
        Ok(v) => panic!("the case must fail: {source} (got `{v}`)"),
        Err(diags) => diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
            .join("; "),
    }
}

// ---------- the positive family (6) ----------

#[test]
fn eo01_degenerate_compat_pos021_restable() {
    deep_stack(|| {
        // The pos-021 shape verbatim: the degenerate clause's return
        // value IS the perform's value — zero drift is the compat
        // ruling's own pin.
        let v = run("define(result, handle (perform add(1, 2)) { add(a, b) => { (a + b) }, });")
            .expect("the degenerate compat case runs");
        assert_eq!(v, "3");
    });
}

#[test]
fn eo02_degenerate_deep_body_continues() {
    deep_stack(|| {
        // The perform sits mid-body (inside an fn — the dynamic
        // channel): the degenerate clause's 4 flows on as the
        // perform's value and the body continues past it.
        let v = run("fn f() { (perform e(2)) + 10 }
define(result, handle (f()) { e(x) => { x * 2 }, });")
        .expect("the deep degenerate body runs");
        assert_eq!(v, "14");
    });
}

#[test]
fn eo03_oneshot_resume_restores_the_captured_point() {
    deep_stack(|| {
        // The k-form: the clause calls k(a + b) — the resumed perform
        // evaluates to 3 and f's body continues past the perform.
        let v = run(
            "fn f() { perform add(1, 2) }\ndefine(result, handle (f()) { add(a, b, k) => { k(a + b) }, });",
        )
        .expect("the one-shot resume runs");
        assert_eq!(v, "3");
    });
}

#[test]
fn eo04_oneshot_plain_return_halts() {
    deep_stack(|| {
        // The clause returns 42 without calling k — the handle
        // expression IS 42 and the body (the +100 continuation) is
        // discarded.
        let v = run(
            "fn f() { (perform e(1)) + 100 }\ndefine(result, handle (f()) { e(x, k) => { 42 }, });",
        )
        .expect("the one-shot halt runs");
        assert_eq!(v, "42");
    });
}

#[test]
fn eo05_return_clause_degenerate_transforms_the_body_value() {
    deep_stack(|| {
        // The body completes 2; the return clause (params 1 — the
        // degenerate form) receives it and its return value stands
        // as the handle's value.
        let v = run("define(result, handle (1 + 1) { return(v) => { v * 10 }, });")
            .expect("the degenerate return clause runs");
        assert_eq!(v, "20");
    });
}

#[test]
fn eo06_return_clause_oneshot_and_coexistence() {
    deep_stack(|| {
        // The return label coexists with ordinary clauses; the
        // explicit mid-body perform routes degenerately, and the
        // body's completion routes through the return clause's
        // one-shot arm (k(v * 1) — the resume value stands).
        let v = run(
            "define(result, handle (perform log(\"x\")) { log(msg) => { 0 }, return(v, k) => { k(v + 1) }, });",
        )
        .expect("the coexistence case runs");
        assert_eq!(v, "1");
    });
}

// ---------- the negative family (18) ----------

#[test]
fn en04_continuation_called_with_zero_args() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(x, k) => { k() }, });",
        );
        assert!(
            text.contains("one-shot continuation call expects `1` argument, got `0`"),
            "the zero-arg probe must name the arity: {text}"
        );
    });
}

#[test]
fn en05_continuation_called_with_two_args() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(x, k) => { k(x, x) }, });",
        );
        assert!(
            text.contains("one-shot continuation call expects `1` argument, got `2`"),
            "the two-arg probe must name the arity: {text}"
        );
    });
}

#[test]
fn en06_continuation_called_with_three_args() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(x, k) => { k(x, x, x) }, });",
        );
        assert!(
            text.contains("one-shot continuation call expects `1` argument, got `3`"),
            "the three-arg probe must name the arity: {text}"
        );
    });
}

#[test]
fn en07_clause_params_two_above_the_args() {
    deep_stack(|| {
        // Neither the degenerate form (1) nor the k-form (2): the
        // invoke's own arity check is the fail-closed defense.
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(a, b, c) => { a }, });",
        );
        assert!(
            text.contains("arity mismatch") && text.contains("expects `3` arguments, got `1`"),
            "the +2 probe must name the mismatch: {text}"
        );
    });
}

#[test]
fn en08_clause_params_three_above_the_args() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(a, b, c, d) => { a }, });",
        );
        assert!(
            text.contains("arity mismatch") && text.contains("expects `4` arguments, got `1`"),
            "the +3 probe must name the mismatch: {text}"
        );
    });
}

#[test]
fn en09_return_clause_params_three() {
    deep_stack(|| {
        // The body completes with payload 1; the return clause at
        // params 3 is neither the degenerate (1) nor the k-form (2).
        let text =
            fail_text("fn f() { 7 }\ndefine(result, handle (f()) { return(v, k, j) => { v }, });");
        assert!(
            text.contains("arity mismatch") && text.contains("expects `3` arguments, got `1`"),
            "the return-clause +2 probe must name the mismatch: {text}"
        );
    });
}

#[test]
fn en10_return_clause_params_four() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { 7 }\ndefine(result, handle (f()) { return(v, k, j, m) => { v }, });",
        );
        assert!(
            text.contains("arity mismatch") && text.contains("expects `4` arguments, got `1`"),
            "the return-clause +3 probe must name the mismatch: {text}"
        );
    });
}

#[test]
fn en11_oneshot_form_unhandled_at_runtime() {
    deep_stack(|| {
        // A k-form perform with no enclosing handle anywhere: the
        // runtime UnhandledEffect (the fn-body channel has no
        // check-face gate — this is the honest boundary).
        let text = fail_text("fn f() { perform e(1) }\ndefine(result, f());");
        assert!(
            text.contains("unhandled effect"),
            "the unhandled probe must name the effect: {text}"
        );
    });
}

#[test]
fn en12_handler_installed_for_another_effect() {
    deep_stack(|| {
        // A handler exists but for a different effect: the routing
        // miss is the runtime UnhandledEffect, not a silent pass.
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { other(x, k) => { k(x) }, });",
        );
        assert!(
            text.contains("unhandled effect"),
            "the routing-miss probe must name the effect: {text}"
        );
    });
}

#[test]
fn en13_top_level_k_shape_is_e0005() {
    deep_stack(|| {
        // The neg-034 pin restated under the deepening: the check
        // face keeps its strict top-level arity rule — the k-form
        // spelling is legal ONLY through the fn-body channel.
        let text = fail_text("define(result, handle (perform e(1)) { e(a, b) => { a }, });");
        assert!(
            text.contains("handler arity mismatch")
                && text.contains("expects `2` arguments, got `1`"),
            "the top-level k-shape probe must name E0005: {text}"
        );
    });
}

#[test]
fn en14_top_level_k_shape_nearest_routing() {
    deep_stack(|| {
        // Two clauses: the nearest (last-installed `e`) is the
        // params==args+1 shape — E0005 exactly as the single-clause
        // case (the routing cannot skip past it).
        let text = fail_text(
            "define(result, handle (perform e(1)) { other(a) => { a }, e(a, b) => { a }, });",
        );
        assert!(
            text.contains("handler arity mismatch")
                && text.contains("expects `2` arguments, got `1`"),
            "the nearest-routing probe must name E0005: {text}"
        );
    });
}

#[test]
fn en16_continuation_as_an_arithmetic_operand() {
    deep_stack(|| {
        // The halt value IS the continuation (the clause returns k
        // without calling it); arithmetic demands numbers.
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(p, handle (f()) { e(x, k) => { k }, });\ndefine(result, p + 1);",
        );
        assert!(
            text.contains("continuation"),
            "the arithmetic probe must name the kind: {text}"
        );
    });
}

#[test]
fn en17_car_on_a_continuation() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(p, handle (f()) { e(x, k) => { k }, });\ndefine(result, car(p));",
        );
        assert!(
            text.contains("continuation"),
            "the car probe must name the kind: {text}"
        );
    });
}

#[test]
fn en18_continuation_as_a_condition() {
    deep_stack(|| {
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(p, handle (f()) { e(x, k) => { k }, });\ndefine(result, if (p) { 1 } else { 2 });",
        );
        assert!(
            text.contains("continuation"),
            "the condition probe must name the kind: {text}"
        );
    });
}

#[test]
fn en19_return_label_explicit_perform_arity_mismatch() {
    deep_stack(|| {
        // The `return` label is an ordinary effect name: an explicit
        // top-level perform of it routes at the check face — the
        // E0005 arity rule applies to it exactly as to any clause.
        let text =
            fail_text("define(result, handle (perform return(1, 2)) { return(v) => { v }, });");
        assert!(
            text.contains("handler arity mismatch")
                && text.contains("expects `1` argument, got `2`"),
            "the return-label arity probe must name E0005: {text}"
        );
    });
}

#[test]
fn en20_top_level_shape_two_above_is_e0005() {
    deep_stack(|| {
        // The top-level immediate form with delta +2 (neither the
        // degenerate equality nor the k-form's +1): E0005.
        let text = fail_text("define(result, handle (perform e(1)) { e(a, b, c) => { a }, });");
        assert!(
            text.contains("handler arity mismatch")
                && text.contains("expects `3` arguments, got `1`"),
            "the +2 top-level probe must name E0005: {text}"
        );
    });
}

#[test]
fn en21_clause_body_types_through_the_handler_channel() {
    deep_stack(|| {
        // The degenerate clause's OWN body is the fail-closed defense:
        // the perform's args reach it as a call and the body's type
        // error surfaces through the handler channel.
        let text = fail_text(
            "fn f() { perform e(1) }\ndefine(result, handle (f()) { e(x) => { car(x) }, });",
        );
        assert!(
            text.contains("must be a pair") && text.contains("`int`"),
            "the clause-body probe must name the operand kind: {text}"
        );
    });
}

#[test]
fn en22_top_level_return_perform_unhandled_is_e0006() {
    deep_stack(|| {
        // The `return` label with no enclosing handler: the ordinary
        // E0006 top-level unhandled ruling.
        let text = fail_text("define(result, perform return(1));");
        assert!(
            text.contains("unhandled effect") && text.contains("top level"),
            "the unhandled return-label probe must name E0006: {text}"
        );
    });
}

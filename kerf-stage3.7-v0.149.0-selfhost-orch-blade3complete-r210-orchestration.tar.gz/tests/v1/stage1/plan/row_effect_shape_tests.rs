//! The W-ROW-POLY blade-3 P2 effect-row shape freeze
//! (w-row-poly-window.md §5.4 + §6 blade 3): the effect row's TYPE
//! SHAPE — `("row" ((eff opT)...) tail)` — is the effect-family
//! window's consumption interface. This file pins the shape's
//! behavior through the selfhosted inference twin's row machinery
//! (the same data-constructed drive as the blade-1 golden: the
//! labels ride the field pairs, the operation types ride the field
//! types, the tail closes or opens — the effect row is a row, the
//! P2 freeze is the shape and the consumption anchor, never an
//! effect-semantics implementation [that is the effect-mechanism
//! window's own blade]).
//!
//! Six cases (the shape freeze's own 1:3-leaning split): the closed
//! effect row's parse-and-display, the isomorphic unification, the
//! disjoint-label conflict, the open effect row's tail variable, the
//! malformed-operand degrade, and the effect/data orthogonality (a
//! shared label space, the mis renders the offending pair).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::SteadyTypecheckChain;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> kerf::span::Symbol {
    kerf::span::Symbol::new(text).expect("test symbol is valid")
}

fn s(text: &str) -> LiteralValue {
    LiteralValue::String(std::rc::Rc::from(text))
}

fn l(items: Vec<LiteralValue>) -> LiteralValue {
    let mut out = LiteralValue::Nil;
    for item in items.into_iter().rev() {
        out = LiteralValue::Pair(Box::new(item), Box::new(out));
    }
    out
}

/// One `(eff opT)` effect-row field.
fn eff(name: &str, op: &str) -> LiteralValue {
    l(vec![s(name), s(op)])
}

/// One effect row from fields and a tail spelling (`nil` closed, `_`
/// open).
fn erow(fields: Vec<LiteralValue>, tail: &str) -> LiteralValue {
    let mut v = vec![s("row")];
    v.extend(fields);
    v.push(s(tail));
    l(v)
}

/// One annotated identity function `fn f(r) { r }` (the blade-1
/// golden's own carrier).
fn id_fn(param_spec: LiteralValue, ret_spec: LiteralValue) -> Vec<ModuleItem> {
    let fspan = sp(10, 40);
    vec![
        ModuleItem::Define {
            span: sp(0, 41),
            name: sym("f"),
            value: CoreExpr::Fn {
                span: fspan,
                params: vec![sym("r")],
                body: Box::new(CoreExpr::Var {
                    span: sp(35, 36),
                    name: sym("r"),
                }),
            },
        },
        ModuleItem::Annotate {
            span: sp(11, 20),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Param,
            index: 0,
            spec: param_spec,
        },
        ModuleItem::Annotate {
            span: sp(28, 39),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Ret,
            index: 0,
            spec: ret_spec,
        },
    ]
}

fn drive(items: &[ModuleItem]) -> String {
    let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
    chain.infer(items).expect("the twin inference runs")
}

#[test]
fn es01_the_closed_effect_row_parses_and_displays() {
    // The shape's own face: `(row ((read int)) nil)` — one effect
    // label, one operation type, the closed tail. The decoded schema
    // displays the row form (the labels and operation types ride the
    // row display, the tail closes).
    let out = drive(&id_fn(
        erow(vec![eff("read", "int")], "nil"),
        erow(vec![eff("read", "int")], "nil"),
    ));
    assert!(
        out.contains("(row read int)"),
        "the closed effect row displays its label and operation type: {out}"
    );
    assert!(
        !out.contains('|'),
        "the closed effect row's display carries no open tail: {out}"
    );
}

#[test]
fn es02_isomorphic_effect_rows_unify() {
    // Two structurally identical effect rows unify clean (the
    // identity function's param and ret agree; zero diags).
    let out = drive(&id_fn(
        erow(vec![eff("read", "int"), eff("write", "bool")], "nil"),
        erow(vec![eff("write", "bool"), eff("read", "int")], "nil"),
    ));
    assert!(
        out.contains("(ok "),
        "the isomorphic effect rows unify: {out}"
    );
    assert!(
        !out.contains("E00"),
        "no diagnostic rides the isomorphic unification: {out}"
    );
}

#[test]
fn es03_disjoint_effect_labels_conflict() {
    // A `read`-only row against a `write`-only row: both lacks
    // directions fire — the mis renders the offending pair (the
    // Leijen precise-diagnosis face through the effect labels).
    let out = drive(&id_fn(
        erow(vec![eff("read", "int")], "nil"),
        erow(vec![eff("write", "bool")], "nil"),
    ));
    assert!(
        out.contains("E0013") || out.contains("E0009"),
        "the disjoint effect labels render a mismatch diagnostic: {out}"
    );
}

#[test]
fn es04_the_open_effect_row_carries_a_tail_variable() {
    // The open effect row's tail is a fresh row variable (the `_`
    // tail; the schema's var list captures it — the generalization
    // face the effect-mechanism window will extend).
    let out = drive(&id_fn(
        erow(vec![eff("read", "int")], "_"),
        erow(vec![eff("read", "int")], "_"),
    ));
    assert!(
        out.contains("(row read int | t"),
        "the open effect row displays its tail variable: {out}"
    );
}

#[test]
fn es05_malformed_operand_degrades_conservatively() {
    // A three-element field (`(read int bool)`) is not a proper
    // `(label T)` pair — the whole row degrades to dyn (the GZ-1
    // conservative rule; dyn absorbs, the identity checks clean).
    let malformed = l(vec![
        s("row"),
        l(vec![s("read"), s("int"), s("bool")]),
        s("nil"),
    ]);
    let out = drive(&id_fn(malformed, s("int")));
    assert!(
        out.contains("(ok "),
        "the malformed operand degrades and the check passes: {out}"
    );
}

#[test]
fn es06_effect_and_data_rows_share_the_label_space() {
    // An effect row and a data row with disjoint labels conflict
    // (the rows live in one label space — the shape freeze's own
    // orthogonality pin: an effect label and a data label are both
    // row labels, the mis names the offending pair).
    let out = drive(&id_fn(
        erow(vec![eff("read", "int")], "nil"),
        erow(vec![eff("x", "int")], "nil"),
    ));
    assert!(
        out.contains("E0013") || out.contains("E0009"),
        "the disjoint label spaces render the mismatch: {out}"
    );
}

//! Steady target reader tests (W-TGT-READ-TWIN blade 3 — the G1
//! closure's chain form, bootstrap-completion-plan §4.2): the
//! steady-state TARGET read chain — `target-lexer.ktf` and
//! `target-parser.ktf` compiled ONCE, read per source through the
//! injection channel, the lexer twin's own records bridged into the
//! parser twin's slot — plus the composed TARGET-read chain (the C1
//! formula: `pipeline_ktf(S) == pipeline_rust(S)` junction by
//! junction: token / tree / expand / check / compile) and the
//! fixpoint purity leg (K159's precondition — the fixpoint's
//! Phase-2 read segment through the language's own twins).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the curated case family through the composed
//!   chain (the steady read, the steady expansion, the steady check,
//!   the twin compile — the full C1 formula per case) plus the
//!   SELFHOST FIXED POINTS: the post-retirement `selfhost/v1/*.ktf`
//!   sources (seven twins — the S-expr lexer/reader twins retired
//!   with the W-SEXP-RETIRE blade 2) through the steady chain —
//!   including the twins' OWN sources (the deepest fixed point the
//!   read chain has reached: the language reading its own reader,
//!   then feeding its own expander, checker and compiler
//!   end-to-end).
//! * **Negative** — the rejection family, each case asserting the
//!   three-way agreement on the SAME error key at the layer that
//!   owns it (the read layer for the curated rejections; the layer
//!   split face — a lexer-layer rejection never reaches the parser).
//! * **Cross-stage consumption** — the twin front end
//!   (`twin_front_end_read`) on a selfhost source matches the Rust
//!   production bridge's own items (the fixpoint purity leg's
//!   differential), and the fixpoint itself (which now READS
//!   through the twins) holds byte-for-byte.

use kerf::driver::read_target_source_for_bootstrap;
use kerf::driver::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, INFER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    SteadyTargetReaderChain, TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE,
    TARGET_PARSER_TWIN_CASES, TYPECHECK_TARGET_SOURCE, composed_target_read_chain_on,
    fixpoint_selfhost_compiler_target, target_lexer_twin_dump, target_parser_twin_dump,
    twin_front_end_read,
};

const FILE: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1");

/// The selfhost fixed-point family: the seven `.ktf` twins through the
/// steady chain (the harness decode walks are recursive over deep
/// trees — the sibling tests' demand-allocated stack discipline).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The seven selfhost twin sources (the shared spelling — one list,
/// never re-typed; `pub(crate)` so the sibling read-segment switch
/// tests ride the same single source). W-SEXP-RETIRE blade 2 (r151):
/// the S-expr `lexer.ktf`/`reader.ktf` twins retired — the two TARGET
/// read twins lead the list (this file's own subject), then the five
/// shared-spine twins (macro.ktf keeps index 2, the one self-contained
/// twin the sibling tests pin).
pub(crate) const SELFHOST_SOURCES: &[(&str, &str)] = &[
    ("target-lexer.ktf", TARGET_LEXER_TARGET_SOURCE),
    ("target-parser.ktf", TARGET_PARSER_TARGET_SOURCE),
    ("macro.ktf", MACRO_TARGET_SOURCE),
    ("expander.ktf", EXPANDER_TARGET_SOURCE),
    ("compiler.ktf", COMPILER_TARGET_SOURCE),
    ("infer.ktf", INFER_TARGET_SOURCE),
    ("typecheck.ktf", TYPECHECK_TARGET_SOURCE),
];

// ---------- positive: the curated family through the full formula ----------

/// The curated cases (both polarities) through the composed chain.
/// The positives ride every junction (the full C1 formula); the
/// negatives reject at the read layer and never feed forward — each
/// case's verdict is the three-way agreement on the SAME error key.
#[test]
fn curated_cases_hold_the_composed_formula() {
    deep_stack(|| {
        let chain = SteadyTargetReaderChain::new()
            .unwrap_or_else(|e| panic!("the steady chain must construct: {e}"));
        for (name, source) in TARGET_PARSER_TWIN_CASES {
            // TD-027 (r143): the twin expander's match arm landed —
            // the J0.9 disclosed boundary row retired, so the five
            // curated match cases ride the full composed formula
            // like every other form (the two exhaustive cases expand
            // through the desugar; the three non-exhaustive ones
            // reject with the same `nonexhaustive` key on both
            // sides — the error axis is a match at this layer).
            let report = composed_target_read_chain_on(&chain, name, source);
            assert!(
                report.matched,
                "the composed formula must hold on {name}: {}",
                report.failure_line()
            );
        }
    });
}

// ---------- positive: the selfhost fixed points ----------

/// The nine selfhost sources through the composed chain — the
/// deepest fixed points. The selfhost twins are chain PIECES: the
/// read layer accepts every one of them (the twins read their own
/// family's sources — the deepest fixed point), and the expansion
/// layer owns each piece's verdict — the dependent twins (their
/// identifiers live in sibling files / injected slots) reject with
/// the SAME unbound-identifier key on both sides (the twin
/// expansion and the oracle expansion agree), while macro.ktf (the
/// one self-contained twin) rides the FULL formula end-to-end.
#[test]
fn selfhost_sources_hold_the_composed_formula() {
    deep_stack(|| {
        let chain = SteadyTargetReaderChain::new()
            .unwrap_or_else(|e| panic!("the steady chain must construct: {e}"));
        let assembled_expander = kerf::driver::assembled_expander_target_source();
        let mut sources: Vec<(&str, &str)> = SELFHOST_SOURCES.to_vec();
        // The MX-2 assembled expander program — the strongest real
        // face: a 2,357-line program through the full formula.
        sources.push(("assembled-expander.ktf", assembled_expander.as_str()));
        for (name, source) in &sources {
            let report = composed_target_read_chain_on(&chain, name, source);
            assert!(
                report.matched,
                "the composed formula must hold on the selfhost source {name}: {}",
                report.failure_line()
            );
        }
    });
}

/// The selfhost family read from DISK (the tree-asset face — the
/// `include_str!` embeddings and the files on disk must agree; the
/// disk read is the same face the corpus sweeps and the packaging
/// audits use).
#[test]
fn selfhost_disk_sources_hold_the_composed_formula() {
    deep_stack(|| {
        let chain = SteadyTargetReaderChain::new()
            .unwrap_or_else(|e| panic!("the steady chain must construct: {e}"));
        for (name, _) in SELFHOST_SOURCES {
            let path = format!("{FILE}/{name}");
            let source = std::fs::read_to_string(&path)
                .unwrap_or_else(|e| panic!("the selfhost twin {name} must read from disk: {e}"));
            let report = composed_target_read_chain_on(&chain, name, &source);
            assert!(
                report.matched,
                "the composed formula must hold on the disk source {name}: {}",
                report.failure_line()
            );
        }
    });
}

// ---------- the cross-route equivalence (the steady machine check) ----------

/// The steady route and the per-source route decode to identical
/// outcomes through the same decoders — the delivery face is the
/// only delta (the `steady_expander_chain` lineage carried to the
/// read chain). A sample across the polarities and one selfhost
/// source.
#[test]
fn steady_route_agrees_with_the_per_source_route() {
    deep_stack(|| {
        let chain = SteadyTargetReaderChain::new()
            .unwrap_or_else(|e| panic!("the steady chain must construct: {e}"));
        let mut sample: Vec<(&str, &str)> = TARGET_PARSER_TWIN_CASES
            .iter()
            .filter(|(name, _)| {
                name.starts_with("neg-")
                    || matches!(
                        *name,
                        "fn-empty-params"
                            | "use-string"
                            | "use-path"
                            | "quote-negative"
                            | "let-multi"
                            | "extern-abi"
                            | "match-literals"
                            | "closure-params"
                    )
            })
            .copied()
            .collect();
        sample.push(("target-parser.ktf", TARGET_PARSER_TARGET_SOURCE));
        for (name, source) in &sample {
            // MODERN2 blade 6 (r203): the chain rides the VM alone —
            // the parser twin consumes the Error vocabulary, so the
            // engine-agreement axis retired (the M16/M46 policy line
            // carried to the parser family).
            let vm_read = chain
                .read(source)
                .unwrap_or_else(|e| panic!("the steady read must run on {name}: {e}"));
            // The per-source route: the parser harness's own drive
            // (its token table derives from the ORACLE lexer — the
            // steady route's bridge derives from the TWIN lexer; the
            // two routes agreeing is the bridge's machine check). A
            // lexer-layer rejection (the oracle lexer rejects — the
            // per-source parser route cannot run) compares by key:
            // the steady route's own layer split must render the
            // same key the oracle lexer produced.
            match target_parser_twin_dump(source) {
                Ok(ps_vm) => {
                    assert_eq!(
                        vm_read.tree_dump, ps_vm,
                        "the steady and per-source routes must agree on the tree axis for {name}"
                    );
                }
                Err(msg) if msg.starts_with("harness layer: the oracle lexer rejected") => {
                    let key = msg
                        .rsplit("rejected the case: ")
                        .next()
                        .expect("the harness-layer message carries the key");
                    assert_eq!(
                        vm_read.token_dump,
                        format!("ERR {key}"),
                        "the steady layer split must render the oracle lexer's own key for {name}"
                    );
                    assert_eq!(
                        vm_read.token_dump, vm_read.tree_dump,
                        "a lexer-layer rejection renders the same key on both axes for {name}"
                    );
                }
                Err(other) => panic!("the per-source route must run on {name}: {other}"),
            }
            // The lexer axis through the lexer harness's own drive
            // (the vm-only face — the M46 single-engine ruling).
            let lx_vm = target_lexer_twin_dump(source)
                .unwrap_or_else(|e| panic!("the per-source lexer route must run on {name}: {e}"));
            assert_eq!(
                vm_read.token_dump, lx_vm,
                "the steady and per-source routes must agree on the token axis for {name}"
            );
        }
    });
}

// ---------- negative: the layer split face ----------

/// A lexer-layer rejection never reaches the parser: the steady
/// outcome renders the SAME key on both axes (the oracle's own read
/// rejects the same way), and the forms feed is absent. The float
/// out-of-range face is the bridge's own rejection (the K20 host
/// derivation) — the deepest layer-split row.
#[test]
fn lexer_layer_rejections_never_reach_the_parser() {
    deep_stack(|| {
        let chain = SteadyTargetReaderChain::new()
            .unwrap_or_else(|e| panic!("the steady chain must construct: {e}"));
        // A non-finite float lexeme (the corpus's own spelling —
        // `1.0e999` is a valid float GRAMMAR whose value overflows):
        // the twin's grammar accepts the token, the BRIDGE derives
        // the f64, the host maps non-finite to the oracle's own
        // FloatOutOfRange — the layer split.
        for (name, source) in [
            ("float-overflow", "define(r, 1.0e999);\n"),
            ("float-overflow-neg", "define(r, -1.0e999);\n"),
        ] {
            let vm_read = chain
                .read(source)
                .unwrap_or_else(|e| panic!("the steady read must run on {name}: {e}"));
            assert!(
                vm_read.token_dump.starts_with("ERR "),
                "{name}: the lexer layer must reject ({})",
                vm_read.token_dump
            );
            assert_eq!(
                vm_read.token_dump, vm_read.tree_dump,
                "{name}: a lexer-layer rejection renders the same key on both axes"
            );
            assert!(
                vm_read.forms.is_none(),
                "{name}: no forms feed on a rejection"
            );
        }
    });
}

// ---------- cross-stage consumption ----------

/// The twin front end (the fixpoint purity leg's face) on a selfhost
/// source: the items the language's own twins produce match the Rust
/// production bridge's items — the K159 precondition's differential.
#[test]
fn twin_front_end_matches_the_production_bridge() {
    deep_stack(|| {
        // The selfhost twins are chain PIECES (their dependencies
        // live in sibling files and injected slots — the assembled
        // expander references its `forms` slot, the compiler twin
        // its `items`): the self-contained faces here are macro.ktf
        // (the base twin) and the curated program rows (use forms
        // included — the K20 rebuild faces). The strongest
        // self-contained face (the fixpoint own assembled program —
        // its prefix DEFINES the slot, so it reads standalone) rides
        // the fixpoint purity test below.
        // (The use-forms' K20 rebuild faces ride the composed
        // chain's J0.5 tree match — use-string/use-path rows — and
        // the loader-rejection parity at J1; the twin front end here
        // covers the ACCEPTING faces only.)
        // ORCH blade 1 (O8): the composed macro twin (the binding —
        // the array stays (&str, &str)).
        let macro_composed = kerf::driver::compose_selfhost(MACRO_TARGET_SOURCE);
        for (name, source) in [
            // ORCH blade 1 (O8): macro.ktf now carries its own
            // `import "std/error"` declaration (a composition-layer
            // source — the twin front end's EXPAND leg would reject
            // the bare import form at the top-level face by design),
            // so the full-front-end face rides the COMPOSED form —
            // the std Error instance + the macro body, byte-identical
            // to the retired prefix assembly. The bare import-
            // carrying source's READ face (the forms level, no
            // expansion) is pinned in the import composer's own
            // family and the five-twin read sweep.
            ("macro.ktf (composed)", macro_composed.as_str()),
            (
                "program-face.ktf",
                "fn add(a, b) { let s = a + b; s }\ndefine(result, add(1, 2));\n",
            ),
        ] {
            let twin_items = twin_front_end_read(name, source)
                .unwrap_or_else(|e| panic!("the twin front end must read {name}: {e}"));
            let bridge_items = read_target_source_for_bootstrap(name, source)
                .unwrap_or_else(|e| panic!("the production bridge must read {name}: {e}"));
            assert_eq!(
                twin_items, bridge_items,
                "the twin front end must match the production bridge on {name}"
            );
        }
    });
}

/// The fixpoint itself — which now READS its self-applied program
/// through the TARGET read twins + the twin expander (the purity
/// leg, in-fixpoint): the assertion inside is the twin route's
/// equality with the production bridge, and the fixpoint's own
/// byte-for-byte caliber must hold as ever.
#[test]
fn fixpoint_purity_leg_holds_through_the_target_read_twins() {
    deep_stack(|| {
        let report = fixpoint_selfhost_compiler_target()
            .unwrap_or_else(|e| panic!("the fixpoint must hold through the twin front end: {e}"));
        assert!(report.fixpoint_holds, "the fixpoint must hold: {report:?}");
    });
}

//! Selfhost formatting guards (§9.79 FMT — the selfhost formatting
//! round, root-project asset face).
//!
//! Three machine-checked invariants over the twelve `.ktf` selfhost
//! twins of `selfhost/v1/` (the r151 single-skin inventory plus the
//! W-PKG-SELFHOST five: the five bootstrap-chain twins, the two
//! target-reader twins, and the five pkg-logic twins — the S-expr-skin
//! twins `lexer.ktf`/`reader.ktf` retired with the reader at blade 2,
//! their formatting record rides the audit's historical sections) —
//! the bootstrap front end plus the Stage 2.3
//! compile-time analysis plus the target reader's own twin pair plus
//! the kerf-pkg logic five, all
//! written in the frozen subset itself. These span no crate (the
//! files are root-project assets consumed via `include_str!` from
//! kerf-driver), so the guard lives at the root (SOP §8.4.6 / §9.1 —
//! cross-crate assertions never go inside a crate's own tree).
//!
//! 1. **Line width** — no line exceeds 100 columns (SOP §10.5
//!    `~100 columns`; the same bound rustfmt enforces on the Rust
//!    face — the selfhost layer joins the repo-wide convention).
//!    Before v0.48.0 the worst offenders were 1697 and 684 columns.
//! 2. **Non-ASCII whitelist** — comments may carry the em-dash `—`
//!    (the repo-wide parenthetical-dash convention: 122 Rust files)
//!    and the section anchor `§` (SOP §10.5 rule 2: technical
//!    anchors ride verbatim); any other non-ASCII character is drift.
//! 3. **ASCII parenthetical dashes absent** — the pre-v0.48.0
//!    sources mixed ` - ` and `  -  ` ASCII dashes (an authoring
//!    artifact of the 1.6/1.7 rounds: the expander and macro twins,
//!    plus the two expander-parity Rust faces); the cleanup unified
//!    every parenthetical dash to the em-dash, and this guard pins
//!    the convention. (The `krf_reformat.py` local pre-flight tool
//!    retired at r106 — its targets, the seed-skin originals, had left
//!    the tree at r104; this guard is the one checked face.)

// The selfhost twin inventory after the r151 single-skin retainer
// (W-SEXP-RETIRE blade 2) and the r156-r159 pkg-logic arrivals
// (W-PKG-SELFHOST blades 1-3): the five bootstrap-chain twins, the
// two target-reader twins, and the five pkg-logic twins —
// `lexer.ktf`/`reader.ktf` (the S-expr-skin twins) retired with the
// reader, and the guard now covers the COMPLETE twin inventory:
// `target-parser.ktf` joined at r151 (its 66 over-width lines were
// reflowed to the convention in the same round), the pkg-logic five
// joined with their parity deliveries — the same root-project asset
// face, the same three invariants.
const BUILD_TWIN: &str = include_str!("../../../../selfhost/v1/build.ktf");
const EXPANDER_TWIN: &str = include_str!("../../../../selfhost/v1/expander.ktf");
const MACRO_TWIN: &str = include_str!("../../../../selfhost/v1/macro.ktf");
const COMPILER_TWIN: &str = include_str!("../../../../selfhost/v1/compiler.ktf");
const INFER_TWIN: &str = include_str!("../../../../selfhost/v1/infer.ktf");
const TYPECHECK_TWIN: &str = include_str!("../../../../selfhost/v1/typecheck.ktf");
/// The W-TGT-READ-TWIN blade 1 twin (r136): the target skin's own
/// lexical face.
const TARGET_LEXER_TWIN: &str = include_str!("../../../../selfhost/v1/target-lexer.ktf");
/// The target-skin parser twin — the deepest selfhost twin; joins the
/// format guard at r151 (the guard's claim "the .ktf twins of
/// selfhost/v1" is now exhaustive).
const TARGET_PARSER_TWIN: &str = include_str!("../../../../selfhost/v1/target-parser.ktf");
/// The W-PKG-SELFHOST blade 1 twin (r156): the micro-TOML subset
/// parser joins the format guard with the same three invariants.
const MICRO_TOML_TWIN: &str = include_str!("../../../../selfhost/v1/micro-toml.ktf");
/// The W-PKG-SELFHOST blade 2 twins (r157): the semver algebra and
/// the composed manifest projection join the same three invariants.
const SEMVER_TWIN: &str = include_str!("../../../../selfhost/v1/semver.ktf");
const MANIFEST_TWIN: &str = include_str!("../../../../selfhost/v1/manifest.ktf");
/// The W-PKG-SELFHOST blade 3 twin, part one (r158): the lockfile
/// model and deterministic serializer joins the three invariants.
const LOCKFILE_TWIN: &str = include_str!("../../../../selfhost/v1/lockfile.ktf");
/// The W-PKG-SELFHOST blade 3 twin, part two (r159): the
/// dependency-graph resolver joins the same three invariants.
const RESOLVE_TWIN: &str = include_str!("../../../../selfhost/v1/resolve.ktf");

/// The formatting convention bound (columns; comment layers measure
/// display width, so count chars — the em-dash is three bytes but one
/// column).
const WIDTH_BOUND: usize = 100;

fn sources() -> [(&'static str, &'static str); 13] {
    [
        ("build.ktf", BUILD_TWIN),
        ("expander.ktf", EXPANDER_TWIN),
        ("macro.ktf", MACRO_TWIN),
        ("compiler.ktf", COMPILER_TWIN),
        ("infer.ktf", INFER_TWIN),
        ("typecheck.ktf", TYPECHECK_TWIN),
        ("target-lexer.ktf", TARGET_LEXER_TWIN),
        ("target-parser.ktf", TARGET_PARSER_TWIN),
        ("micro-toml.ktf", MICRO_TOML_TWIN),
        ("semver.ktf", SEMVER_TWIN),
        ("manifest.ktf", MANIFEST_TWIN),
        ("lockfile.ktf", LOCKFILE_TWIN),
        ("resolve.ktf", RESOLVE_TWIN),
    ]
}

#[test]
fn selfhost_lines_respect_the_width_convention() {
    for (name, src) in sources() {
        for (idx, line) in src.lines().enumerate() {
            let width = line.chars().count();
            assert!(
                width <= WIDTH_BOUND,
                "{name}: line {} is {} columns (bound {WIDTH_BOUND}): {}…",
                idx + 1,
                width,
                line.chars().take(40).collect::<String>()
            );
        }
    }
}

#[test]
fn selfhost_non_ascii_is_whitelisted() {
    for (name, src) in sources() {
        let offenders: Vec<(usize, char)> = src
            .char_indices()
            .filter(|(_, c)| !c.is_ascii() && *c != '—' && *c != '§')
            .collect();
        assert!(
            offenders.is_empty(),
            "{name}: non-ASCII outside the {{em-dash, section}} whitelist \
             (SOP §10.5 rule 2 keeps § anchors verbatim; the em-dash is the \
             repo-wide parenthetical convention): {offenders:?}"
        );
    }
}

/// The prose segment of one line: from the comment marker (outside
/// any string literal) to the end. The em-dash convention governs
/// PROSE; code is exempt — the target skin's infix arithmetic
/// (`n - 1`, legal since the step-3 twins) must not trip the prose
/// rule. The retired seed skin marked comments with `;`, the target
/// skin with `//`.
fn prose_segment<'a>(line: &'a str, marker: &str) -> &'a str {
    let bytes = line.as_bytes();
    let mut in_str = false;
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'"' {
            in_str = !in_str;
        } else if !in_str && line[i..].starts_with(marker) {
            return &line[i..];
        }
        i += 1;
    }
    ""
}

#[test]
fn selfhost_parenthetical_dashes_are_em_dashes() {
    for (name, src) in sources() {
        let marker = if name.ends_with(".ktf") { "//" } else { ";" };
        for line in src.lines() {
            let prose = prose_segment(line, marker);
            assert!(
                !prose.contains(" - "),
                "{name}: ASCII spaced dash survives (pre-v0.48.0 authoring \
                 artifact) — the convention is the em-dash ` — `"
            );
            assert!(
                !prose.contains("  -  "),
                "{name}: double-spaced ASCII dash survives (pre-v0.48.0 \
                 authoring artifact) — the convention is the em-dash ` — `"
            );
        }
    }
}

//! Semver twin tests (W-PKG-SELFHOST blade 2, part one —
//! w-pkg-selfhost-window §4 row 2): the package manager's version
//! algebra, `selfhost/v1/semver.ktf`, against the Rust oracle
//! `kerf_pkg::semver` through the full `.ktf` chain on BOTH
//! engines — the tenth selfhost twin.
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the caret matrix (the 0.x minor bound, the 1.x
//!   major bound, the patch floors, cross-major rejections) — each
//!   case pinned three-way (oracle == twin-vm == twin-eval) on the
//!   three-line dump grammar.
//! * **Negative** — both faces' form errors (the dot-count shapes)
//!   and the not-a-number family (empty components, lone signs, a
//!   lone `+`, embedded spaces, non-digit runs), each case
//!   asserting the three-way agreement on the SAME rendered error
//!   key.
//! * **Cross-stage consumption** — the twin's quad record is the
//!   constraint shape the blade 3 resolver compares (the lockfile's
//!   caret face): the has-flag distinction pins both arms' renders.
//!
//! The deep-stack discipline follows the sibling twin tests: the
//! frozen subset expresses iteration only through self-recursion,
//! so the harness rides a demand-allocated stack thread.

use kerf::driver::{SEMVER_TWIN_CASES, semver_oracle_dump, semver_parity};

/// The positive family ends at the curated list's
/// `caret-leading-zeros` entry; the rejection families follow it
/// (the const lists them in that order).
const POSITIVE_COUNT: usize = 12;

/// Every twin drive walks the harness Rust walkers and both
/// engines' per-record frames — the sibling tests' demand-allocated
/// stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the caret matrix ----------

#[test]
fn caret_matrix_holds_three_way_parity() {
    deep_stack(|| {
        for (name, con, ver) in SEMVER_TWIN_CASES.iter().take(POSITIVE_COUNT) {
            semver_parity(name, con, ver).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- negative: the form and not-a-number families ----------

#[test]
fn rejection_cases_agree_three_way_on_the_same_key() {
    deep_stack(|| {
        for (name, con, ver) in SEMVER_TWIN_CASES.iter().skip(POSITIVE_COUNT) {
            eprintln!("CASE {name}");
            semver_parity(name, con, ver).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage: the quad record feeds the resolver ----------

/// The constraint quad (maj, min, has, patch) is the record shape
/// blade 3's resolver and lockfile serialize: the has-flag carries
/// the X.Y-versus-X.Y.Z distinction, and the dump must render both
/// arms exactly as the oracle's own Display does.
#[test]
fn constraint_quad_renders_both_arms() {
    let two = semver_oracle_dump("0.2", "0.2.99");
    assert!(
        two.contains("(con 0.2)\n") && two.contains("(ver 0.2.99)\n") && two.contains("caret=yes"),
        "the two-component arm renders bare X.Y: {two}"
    );
    let three = semver_oracle_dump("0.1.5", "0.1.5");
    assert!(
        three.contains("(con 0.1.5)\n") && three.contains("caret=yes"),
        "the three-component arm renders X.Y.Z: {three}"
    );
    deep_stack(|| {
        // The twin's renders must agree on the same distinction.
        semver_parity("cross-stage-two-arm", "0.2", "0.2.99").unwrap_or_else(|e| panic!("{e}"));
        semver_parity("cross-stage-three-arm", "0.1.5", "0.1.5").unwrap_or_else(|e| panic!("{e}"));
    });
}

/// The twin's own source must ride the format guard's inventory —
/// pin the embedding and the disk file agree (the tree-asset face
/// the sibling twins' tests hold).
#[test]
fn twin_source_embedding_matches_disk() {
    let disk = std::fs::read_to_string(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/selfhost/v1/semver.ktf"
    ))
    .expect("the twin source reads from disk");
    assert_eq!(
        kerf::driver::SEMVER_TARGET_SOURCE,
        disk,
        "the embedding and disk agree"
    );
}

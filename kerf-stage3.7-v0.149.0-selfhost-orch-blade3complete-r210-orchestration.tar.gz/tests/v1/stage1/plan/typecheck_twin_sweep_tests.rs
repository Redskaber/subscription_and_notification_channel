//! The W-HM-TWIN 127-b integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the full-corpus sweep on the check axis —
//! every corpus row whose source the target reader accepts and the
//! oracle expander expands feeds BOTH faces (the checker twin
//! `selfhost/v1/typecheck.ktf` through the steady check chain's
//! injection channel, the Rust `check_module` through the pipeline's
//! own externals); the two verdict texts must match bit-for-bit: the
//! pass-1 table face (every define in flat walk order with its shape
//! — the direct INF-9 mirror guard, the twin's table axis compared
//! against the oracle's `table_axes` on every row), the assigned
//! first-seen list, and the diagnostics channel (report order, the
//! five-field record plus the subject set, the template payloads
//! rendered through the oracle's own format strings). Reader-rejection
//! rows are the READ segment's rows (counted, not fed);
//! expansion-rejection rows are the EXPANSION segment's rows (counted,
//! not fed — the twin never sees an item stream for them).
//!
//! W-SEXP-RETIRE blade 1 (r150, w-sexp-retire-window SR-1): the
//! corpus is single-skin — the sweep reads the migrated `.ktf`
//! cases through `read_target_program` (170 cases; the three
//! skin-divergent rows retired per SR-2; the r168-b4 blade-3 enum
//! rows added sixteen — four positive and twelve negative). The classification keeps
//! the BARE machine the sweep has always ridden (read + expand, no
//! loader): the check axis is loader-independent (`check_module`
//! never resolves modules — `Require` items carry no expression
//! payload), so the module family (neg-018/019/020/048/049 — the
//! target skin maps `use` to a string require, which the bare
//! expander accepts) rides the FED rows — neg-020/048/049 exactly
//! as they did on the old seed-skin face, neg-018/019 newly (their
//! old-face expansion rejection was the S-expr skin's
//! symbol-require artifact; the loader's rejection of all five is
//! another face's pin — the hm_twin_face classification rides the
//! pipeline spine, the corpus contract's machine). The nine
//! stage-divergent rows (the malformed keyword-headed forms) moved
//! from the expansion rows to the READER rows — the grammar-directed
//! target reader rejects what the permissive S-expr reader deferred
//! to the expander.
//!
//! The rule-family probes ride the sweep itself (the R2/R3/R4/R5/R6/
//! R7/R8/LA7 faces the source path can reach), the R1 faces ride the
//! direct-construction probes (the R1 layer's true domain — macro
//! synthesis and programmatic API consumers; the source path's
//! expander rejects an unbound reference before the checker ever
//! sees it), and the deep row rides the programmatic path (the
//! 600-deep chain — the twin's per-element recursion headroom, the
//! value-face injection bypassing the reader's nesting cap exactly as
//! the inference sweep's budget row does).
//!
//! W-SEXP-RETIRE blade 2 (r151): the probe sources ride the target
//! skin (the corpus-dictionary respell), one semantic twin per row;
//! the two E0007 handler-value rows (r7-named/r7-anon) retired — the
//! target handle arm is always `E(params) => { body }`, a Fn handler
//! by construction, so the non-callable-handler face is unreachable
//! on the target grammar (the neg-036 SR-2 precedent).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{SteadyCheckChain, oracle_check_axes};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbol is valid")
}

#[test]
fn check_twin_sweeps_the_corpus_and_matches_the_oracle() {
    deep_stack(|| {
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert_eq!(
            files.len(),
            170,
            "the corpus is 170 .ktf cases (the blade-1 single-skin migration plus the sixteen annotation rows plus the thirteen \
             blade-2 struct rows plus the sixteen blade-3 enum rows plus the sixteen blade-4 pattern rows: the 112 seed-skin originals minus the three SR-2 retired divergences)"
        );
        let mut fed = 0usize;
        let mut reader_rejected = 0usize;
        let mut expansion_rejected = 0usize;
        let mut assigned_rows = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            // Blade 1: the row reads through the TARGET reader (the
            // migrated `.ktf` corpus, SR-1) — the bare read→expand
            // machine keeps the sweep's original gate (the loader
            // never gates the check axis; see the header).
            let forms = match read_target_program(FileId(0), &source) {
                Ok(forms) => forms,
                Err(_) => {
                    // The read layer owns this row's verdict — the
                    // checker never sees it (segment one's sweep
                    // carries the row).
                    reader_rejected += 1;
                    continue;
                }
            };
            let items = match expand_program(&forms) {
                Ok(items) => items,
                Err(_) => {
                    // The expansion layer owns this row's verdict —
                    // the twin never sees an item stream for it
                    // (segment two's sweep carries the row).
                    expansion_rejected += 1;
                    continue;
                }
            };
            let twin = chain.check(&items).unwrap_or_else(|e| {
                panic!("{case}: the twin check runs without a harness defect: {e}")
            });
            let oracle = oracle_check_axes(&items);
            assert_eq!(
                twin, oracle,
                "{case}: the twin's check verdict text matches the oracle"
            );
            if twin.contains("(assigned ") || twin.contains("(assigned)") {
                // Detection-power ledger: at least one fed row must
                // exercise the assigned face (the empty face renders
                // as `(assigned)` — count only non-empty rows below).
            }
            if twin.contains("(assigned ") {
                assigned_rows += 1;
            }
            fed += 1;
        }
        // The r150 re-measurement (the `.ktf` face, the bare machine —
        // the floors now ride the measured face): the nine
        // stage-divergent rows moved into the reader rows (8 -> 16),
        // the two ruling-D module twins (neg-018/019) moved out of
        // the expansion rows into the fed rows (29 -> 18), the fed
        // count holds at 75 (the two retired fed rows offset by the
        // two newly-fed module twins), and the assigned face rides
        // its three measured rows (pos-012's accumulator, pos-028's
        // rebind, neg-057's captured assignment — the old `>= 2`
        // floor rode the same face loosely).
        assert!(fed >= 105, "the fed rows ride the sweep (got {fed})");
        assert!(
            reader_rejected >= 17,
            "the reader-layer rejection rows are accounted (got {reader_rejected})"
        );
        assert!(
            expansion_rejected >= 33,
            "the expansion-layer rejection rows are accounted (got {expansion_rejected})"
        );
        assert_eq!(
            fed + reader_rejected + expansion_rejected,
            files.len(),
            "every corpus row is classified exactly once"
        );
        assert!(
            assigned_rows >= 3,
            "the assigned face is exercised on the fed rows (got {assigned_rows})"
        );
    });
}

#[test]
fn check_twin_matches_the_oracle_on_the_rule_family_probes() {
    deep_stack(|| {
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let probes: &[(&str, &str)] = &[
            // The accept anchor (the steady-expander precedent).
            (
                "accept-anchor",
                "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
            ),
            // R2 — the named define arity, the IIFE arity, and the
            // builtin arity faces.
            ("r2-define-arity", "fn f(x) { x }\ndefine(g, f(1, 2));"),
            ("r2-iife-arity", "define(g, (||(x) { x })(1, 2));"),
            ("r2-builtin-arity", "define(g, first(1, 2));"),
            // The extern arity face (the W-3.2 third source — the
            // declared arrow's params length through the extern
            // table, the oracle's `pipeline_externals` construction).
            (
                "r2-extern-arity",
                "extern \"C\" {\n    fn log(p0: int, p1: int) -> int;\n}\ndefine(g, log(1));",
            ),
            // The assign guard (the over-approximation): an assigned
            // global's callee shape is unusable — no E0002 despite
            // the define shape, and the assigned face rides the table.
            (
                "r2-assign-guard",
                "fn f(x) { x }\ndefine(g, { let tmp = set(f, 1); f(1, 2) });",
            ),
            // The lexical shadowing face: a local of the callee's
            // name wins — its shape is unknown (the conservative
            // skip, zero diagnostics).
            (
                "r2-local-shadow",
                "fn f(x) { x }\ndefine(g, { let f = 5; f(1, 2) });",
            ),
            // R3 — the non-boolean literal condition (the report
            // rides the condition's own span) and the bool pass.
            ("r3-cond-int", "fn f(x) { if (1) { 2 } else { 3 } }"),
            ("r3-cond-bool-ok", "fn f(x) { if (true) { 2 } else { 3 } }"),
            // R4 — the literal callee, named define and anonymous.
            ("r4-named", "define(h, 5);\nfn k(z) { h(z) }"),
            ("r4-anon", "define(k, 5(1));"),
            // R5 — the routed handler's arity mismatch.
            (
                "r5-handler-arity",
                "define(g, handle (perform log(1)) { log(a, b) => { a }, });",
            ),
            // R6 — the top-level unhandled perform and the two
            // soundness guards (the Fn-body perform and the
            // handle-routed perform both pass).
            ("r6-toplevel", "define(g, perform log(1));"),
            ("r6-fn-body-ok", "fn f() { perform log(1) }"),
            (
                "r6-routed-ok",
                "define(g, handle (perform log(1)) { log(v) => { v }, });",
            ),
            // R7 — the two handler-VALUE rows (a named define / a
            // literal as the handler) retired with the blade-2
            // respell: the target handle arm is always a Fn handler
            // (`E(params) => { body }`), so the non-callable-handler
            // face is unreachable on the target grammar (the neg-036
            // SR-2 precedent).
            // R8 — the surprising assignment targets (warning
            // severity): the rebinds-builtin arm and the local/define
            // pass arms (the implicit-global arm is a direct-
            // construction face — the source path's expander rejects a
            // set to an unbound name before the checker sees it).
            ("r8-rebinds-builtin", "fn f() { set(first, 1); }"),
            ("r8-local-ok", "fn f() { { let x = 1; set(x, 2); } }"),
            ("r8-define-ok", "define(x, 1);\nfn f() { set(x, 2); }"),
            // LA7 — the captured-assignment boundary and the
            // shadow-back pass (a let inside the body shadows the
            // captured name back into the frame's own region).
            ("la7-captured", "fn h(outer) { ||(step) { set(outer, 1) } }"),
            (
                "la7-shadow-ok",
                "fn h(outer) { ||(step) { let outer = 0; set(outer, 1); } }",
            ),
            // The capture READ face (the LA-1 mirror): an inner Fn
            // reading the enclosing param is a capture read, never
            // an unbound reference.
            ("la1-capture-read", "fn h(outer) { ||(step) { outer } }"),
            // The let visibility face: binding i sees 0..i-1 only.
            (
                "let-visibility",
                "define(g, { let a = 1, b = (a + 1); (a + b) });",
            ),
            // The letrec self-reference (the pre-bind — the own name
            // visible inside its own value). The fn-body forward
            // reference rides the direct-construction probes (the
            // source path's expander rejects it — the checker's
            // position-aware visibility is the direct face's domain).
            (
                "letrec-self-ok",
                "fn f(n) { if ((n < 2)) { n } else { f((n - 1)) } }",
            ),
            // The nested module face: the inner defines join the
            // flat pre-order table.
            (
                "module-flat-table",
                "module m { define(x, 1); fn f(y) { y } }",
            ),
            // The multi-error collection face (ruling 21): three
            // findings in one module, report order.
            (
                "multi-error",
                "define(a, 5);\ndefine(b, a(1));\ndefine(c, if (1) { 2 } else { 3 });\ndefine(d, first(1, 2));",
            ),
        ];
        for (name, source) in probes {
            let forms = read_target_program(FileId(0), source).expect("the probe reads");
            let items =
                expand_program(&forms).unwrap_or_else(|e| panic!("{name}: the probe expands: {e}"));
            let twin = chain
                .check(&items)
                .unwrap_or_else(|e| panic!("{name}: the twin check runs: {e}"));
            let oracle = oracle_check_axes(&items);
            assert_eq!(
                twin, oracle,
                "{name}: the twin's check verdict text matches the oracle"
            );
        }
    });
}

/// The R1 direct-construction probes (the layer's true domain — the
/// source path's expander rejects an unbound reference before the
/// checker ever sees it; macro synthesis and programmatic API
/// consumers are the faces that reach R1).
#[test]
fn check_twin_matches_the_oracle_on_the_r1_direct_construction_probes() {
    deep_stack(|| {
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let var = |name: &str, a: u32, b: u32| CoreExpr::Var {
            span: sp(a, b),
            name: sym(name),
        };
        let int = |v: i64| CoreExpr::Literal {
            span: sp(1, 3),
            value: LiteralValue::Int(v),
        };
        let define = |name: &str, value: CoreExpr| ModuleItem::Define {
            span: sp(0, 10),
            name: sym(name),
            value,
        };
        // R1 — the top-level unbound reference.
        let unbound = vec![define("x", var("missing", 1, 8))];
        // R1 — the forward reference at a top-level immediate
        // position (the value evaluates during load, before the
        // later define runs).
        let forward = vec![define("a", var("b", 1, 2)), define("b", int(1))];
        // R1 — the letrec pre-bind (the own name visible inside its
        // own value) and the fn-body forward reference (call time is
        // post-load) both pass.
        let self_ref = vec![define(
            "f",
            CoreExpr::fn_(sp(2, 8), &["n"], var("f", 3, 4)).expect("valid fn"),
        )];
        let fn_forward = vec![
            define(
                "f",
                CoreExpr::fn_(sp(2, 8), &["x"], var("g", 3, 4)).expect("valid fn"),
            ),
            define(
                "g",
                CoreExpr::fn_(sp(2, 8), &["x"], var("x", 3, 4)).expect("valid fn"),
            ),
        ];
        // R8's implicit-global arm — the assignment to a name that
        // is neither local, define, nor external (the source path's
        // expander owns this rejection; the checker's arm is the
        // direct-construction face).
        let implicit_global = vec![define(
            "f",
            CoreExpr::fn_(
                sp(2, 8),
                &[],
                CoreExpr::assign(sp(4, 9), "nowhere", int(1)).expect("valid assign"),
            )
            .expect("valid fn"),
        )];
        let rows: &[(&str, Vec<ModuleItem>)] = &[
            ("r1-unbound", unbound),
            ("r1-forward", forward),
            ("r1-letrec-self-ok", self_ref),
            ("r1-fn-forward-ok", fn_forward),
            ("r8-implicit-global", implicit_global),
        ];
        for (name, items) in rows {
            let twin = chain
                .check(items)
                .unwrap_or_else(|e| panic!("{name}: the twin check runs: {e}"));
            let oracle = oracle_check_axes(items);
            assert_eq!(
                twin, oracle,
                "{name}: the twin's check verdict text matches the oracle"
            );
        }
        // The two negative rows really report (the detection-power
        // arm — a guard that passes because nothing fired pins
        // nothing).
        let unbound_verdict = chain.check(&rows[0].1).expect("the unbound row runs");
        assert!(
            unbound_verdict.contains("E0001") && unbound_verdict.contains("unbound variable"),
            "the R1 row reports: {unbound_verdict}"
        );
        let forward_verdict = chain.check(&rows[1].1).expect("the forward row runs");
        assert!(
            forward_verdict.contains("E0001"),
            "the forward-reference row reports: {forward_verdict}"
        );
        // And the two pass rows really pass.
        let self_verdict = chain.check(&rows[2].1).expect("the self-ref row runs");
        assert_eq!(
            self_verdict, "(ok (table (defines (de f (fn 1))) (assigned)) (diags))",
            "the letrec self-reference row is clean"
        );
        // The implicit-global row reports the warning form.
        let implicit_verdict = chain
            .check(&rows[4].1)
            .expect("the implicit-global row runs");
        assert!(
            implicit_verdict.contains("E0008")
                && implicit_verdict.contains("warning")
                && implicit_verdict.contains("implicitly creates a global"),
            "the implicit-global row reports the R8 warning: {implicit_verdict}"
        );
    });
}

/// The deep row (the value-face injection — the reader's nesting cap
/// is 256, so the deep tree only rides the programmatic path): the
/// twin's per-element recursion must hold the 600-deep chain with the
/// verdict matching the oracle's (the check face has no budget of its
/// own — the conservative checker is unbounded on the Rust side; the
/// twin's recursion is the only face under test).
#[test]
fn check_twin_deep_row_matches_the_oracle_through_the_programmatic_path() {
    deep_stack(|| {
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let mut cur = CoreExpr::Literal {
            span: sp(0, 1),
            value: LiteralValue::Int(1),
        };
        for _ in 0..600 {
            cur = CoreExpr::If {
                span: sp(0, 2),
                cond: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Bool(true),
                }),
                then_branch: Box::new(cur),
                else_branch: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(2),
                }),
            };
        }
        let items = vec![ModuleItem::Define {
            span: sp(0, 3),
            name: sym("deep"),
            value: cur,
        }];
        let twin = chain.check(&items).expect("the deep row runs on the twin");
        let oracle = oracle_check_axes(&items);
        assert_eq!(
            twin, oracle,
            "the deep row's verdict text matches the oracle"
        );
        assert!(
            twin.starts_with("(ok (table (defines (de deep other)) (assigned))"),
            "the deep define rides the table face as an other shape: {twin}"
        );
    });
}

#[test]
fn check_twin_is_deterministic_and_the_injection_feeds_every_check() {
    deep_stack(|| {
        // Determinism: the same item stream checks twice identically.
        // The no-clobber contract: two DIFFERENT streams check
        // differently — a program-side define of `items` would
        // collapse every check onto one stream.
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let a_src = "fn a(x) { x }";
        let b_src = "fn b(y) { first(y, 1) }";
        let a_items = expand_program(&read_target_program(FileId(0), a_src).expect("a reads"))
            .expect("a expands");
        let b_items = expand_program(&read_target_program(FileId(0), b_src).expect("b reads"))
            .expect("b expands");
        let a1 = chain.check(&a_items).expect("the first check of a");
        let a2 = chain.check(&a_items).expect("the second check of a");
        assert_eq!(a1, a2, "the same item stream checks identically");
        let b1 = chain.check(&b_items).expect("the check of b");
        assert_ne!(
            a1, b1,
            "different item streams check differently — the injection feeds every check"
        );
        assert!(
            b1.contains("E0002"),
            "the b row really reports (the detection-power arm): {b1}"
        );
        let a3 = chain
            .check(&a_items)
            .expect("the third check of a, interleaved");
        assert_eq!(a1, a3, "the interleaved re-check is stable");
    });
}

#[test]
fn check_twin_empty_stream_rides_as_nil() {
    deep_stack(|| {
        // The empty-stream ledger row (the payload face's nil
        // convention): the empty stream's payload IS nil, and the
        // twin checks it to the zero-define module — matching the
        // oracle over no items.
        assert_eq!(
            kerf::driver::items_stream_literal(&[]),
            kerf::core::LiteralValue::Nil,
            "the empty stream's payload is nil"
        );
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        let outcome = chain
            .check(&[])
            .expect("the empty stream checks (an outcome, not a defect)");
        let oracle = oracle_check_axes(&[]);
        assert_eq!(
            outcome, oracle,
            "the empty stream's check matches the oracle"
        );
        assert_eq!(
            outcome, "(ok (table (defines) (assigned)) (diags))",
            "the empty stream checks to the zero-define module"
        );
    });
}

//! Resolver twin tests (W-PKG-SELFHOST blade 3, part two —
//! w-pkg-selfhost-window §4 row 3b): the package manager's
//! dependency-graph resolver, the five-piece composed program
//! `micro-toml.ktf + semver.ktf + manifest.ktf + lockfile.ktf +
//! resolve.ktf` (the family's FIRST five-piece composition), against
//! the Rust oracle `kerf_pkg::resolve_with_limit` through the full
//! `.ktf` chain on BOTH engines — the twelfth selfhost twin.
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the walk family (a single package, the
//!   two-package chain, the nested source tree, the name-sorted
//!   multi-dep order, the diamond with the first-resolution-wins
//!   name identity, the canonical version re-render, the
//!   unreferenced-directory tolerance, the empty manifest text)
//!   plus the generated twenty-deep chain, each case pinned
//!   three-way (oracle == twin-vm == twin-eval) BYTE-EXACT on the
//!   order lines and the lockfile text.
//! * **Negative** — the seven rejection tribes of the blade row
//!   (the root-read tribe, the cycle tribe, the
//!   missing-directory tribe including the is-file face, the
//!   manifest pass-through tribe — syntax, missing fields, name
//!   mismatch, bad constraints, the io traps — the root manifest
//!   rejections, the conflict tribe including the sorted-key
//!   iteration proof, and the depth cap), each case asserting the
//!   three-way agreement on the SAME rendered error line.
//! * **Cross-stage consumption** — the composed program's pieces
//!   are the blade 1, blade 2 and blade 3a twins verbatim: the
//!   embedding test pins all five disk files against their
//!   compiled-in sources.
//!
//! The deep-stack discipline follows the sibling twin tests: the
//! frozen subset expresses iteration only through self-recursion,
//! so the harness rides a demand-allocated stack thread.

use kerf::driver::{deep_chain_case, resolve_parity, resolve_parity_at, resolve_parity_cases};

/// Every twin drive walks the harness Rust walkers and both
/// engines' per-record frames — the sibling tests' demand-allocated
/// stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the walk family ----------

#[test]
fn walk_cases_hold_three_way_parity() {
    deep_stack(|| {
        for case in resolve_parity_cases().iter().take(9) {
            resolve_parity(case).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

#[test]
fn deep_chain_holds_three_way_parity() {
    deep_stack(|| {
        let (root, case) = deep_chain_case();
        resolve_parity_at(&root, &case).unwrap_or_else(|e| panic!("{e}"));
        let _ = std::fs::remove_dir_all(&root);
    });
}

// ---------- negative: the rejection tribes ----------

#[test]
fn cycle_and_directory_tribes_agree_three_way() {
    deep_stack(|| {
        for case in resolve_parity_cases().iter().skip(11).take(9) {
            resolve_parity(case).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

#[test]
fn manifest_pass_through_tribes_agree_three_way() {
    deep_stack(|| {
        for case in resolve_parity_cases().iter().skip(9).take(2) {
            resolve_parity(case).unwrap_or_else(|e| panic!("{e}"));
        }
        for case in resolve_parity_cases().iter().skip(20).take(6) {
            resolve_parity(case).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

#[test]
fn conflict_and_depth_tribes_agree_three_way() {
    deep_stack(|| {
        for case in resolve_parity_cases().iter().skip(26) {
            resolve_parity(case).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage: the composition ----------

/// The composed program's pieces are the blade 1, blade 2 and blade
/// 3a twins verbatim — pin the five embeddings against their disk
/// files (the tree-asset face the sibling twins' tests hold).
#[test]
fn composed_sources_match_disk() {
    let base = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1/");
    let mt = std::fs::read_to_string(format!("{base}micro-toml.ktf"))
        .expect("the micro-toml twin reads from disk");
    let sv = std::fs::read_to_string(format!("{base}semver.ktf"))
        .expect("the semver twin reads from disk");
    let mf = std::fs::read_to_string(format!("{base}manifest.ktf"))
        .expect("the manifest twin reads from disk");
    let lk = std::fs::read_to_string(format!("{base}lockfile.ktf"))
        .expect("the lockfile twin reads from disk");
    let rs = std::fs::read_to_string(format!("{base}resolve.ktf"))
        .expect("the resolve twin reads from disk");
    assert_eq!(
        kerf::driver::MICRO_TOML_TARGET_SOURCE,
        mt,
        "the blade 1 embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::SEMVER_TARGET_SOURCE,
        sv,
        "the blade 2 semver embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::MANIFEST_TARGET_SOURCE,
        mf,
        "the blade 2 manifest embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::LOCKFILE_TARGET_SOURCE,
        lk,
        "the blade 3a lockfile embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::pkg_selfhost::RESOLVE_TARGET_SOURCE,
        rs,
        "the blade 3b resolve embedding and disk agree"
    );
}

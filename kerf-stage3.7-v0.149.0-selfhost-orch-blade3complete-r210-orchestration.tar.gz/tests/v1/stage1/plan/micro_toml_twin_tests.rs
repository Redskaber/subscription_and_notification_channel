//! Micro-TOML twin tests (W-PKG-SELFHOST blade 1 — w-pkg-selfhost
//! window §4 row 1): the package manager's manifest grammar parser,
//! `selfhost/v1/micro-toml.ktf`, against the Rust oracle
//! `kerf_pkg::micro_toml::parse` through the full `.ktf` chain on
//! BOTH engines — the ninth selfhost twin, the first of the
//! kerf-pkg self-hosting family.
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the curated case family (the six accepted forms:
//!   comments, blank lines, string and int pairs, section headers,
//!   array headers with instance accumulation; escape round trips,
//!   the i64::MIN boundary, crlf line ends, a realistic kerf.toml
//!   shape) — each case pinned three-way (oracle == twin-vm ==
//!   twin-eval) on the dump grammar.
//! * **Negative** — the rejection family, all sixteen error kinds
//!   plus their boundary variants, each case asserting the
//!   three-way agreement on the SAME rendered error key (line:col:
//!   message — kind, position, and operand).
//! * **Cross-stage consumption** — the twin's dump rebuilds the
//!   document shape the next blade consumes (blade 2's manifest
//!   projection reads the `(t "depends")` table rows): record
//!   counts equal the oracle's own field counts, on the same case.
//!
//! The deep-stack discipline follows the sibling twin tests: the
//! frozen subset expresses iteration only through self-recursion,
//! so the harness rides a demand-allocated stack thread.

use kerf::driver::{
    MICRO_TOML_TARGET_SOURCE, MICRO_TOML_TWIN_CASES, micro_toml_oracle_dump, micro_toml_parity,
};

/// The positive family ends at the curated list's `realistic-
/// manifest` entry; the rejection family follows it (the const
/// lists them in that order).
const POSITIVE_COUNT: usize = 12;

/// Every twin drive walks the harness Rust walkers and both
/// engines' per-record frames — the sibling tests' demand-allocated
/// stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the six accepted forms ----------

#[test]
fn positive_cases_hold_three_way_parity() {
    deep_stack(|| {
        for (name, source) in MICRO_TOML_TWIN_CASES.iter().take(POSITIVE_COUNT) {
            micro_toml_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- negative: the sixteen-kind rejection family ----------

#[test]
fn rejection_cases_agree_three_way_on_the_same_key() {
    deep_stack(|| {
        for (name, source) in MICRO_TOML_TWIN_CASES.iter().skip(POSITIVE_COUNT) {
            micro_toml_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage: the dump rebuilds the document shape ----------

/// The record stream must carry the full document shape the next
/// blade (manifest.ktf + semver.ktf, blade 2) projects from: the
/// dump line count equals globals + items + total entries, and the
/// table rows (`(t ...)`/`(a ...)`) count equals the oracle's own
/// items count — the structural face the blade-2 projection reads.
#[test]
fn twin_dump_rebuilds_document_shape() {
    deep_stack(|| {
        let (name, source) = MICRO_TOML_TWIN_CASES
            .iter()
            .find(|(n, _)| *n == "realistic-manifest")
            .expect("the realistic case is in the curated list");
        let doc = micro_toml_oracle_dump(source)
            .unwrap_or_else(|e| panic!("oracle rejected {name}: {e}"));
        let lines: Vec<&str> = doc.lines().collect();
        let tables = lines
            .iter()
            .filter(|l| l.starts_with("(t ") || l.starts_with("(a "))
            .count();
        let globals = lines.iter().filter(|l| l.starts_with("(g ")).count();
        let entries = lines.iter().filter(|l| l.starts_with("(e ")).count();
        // The realistic manifest: 2 globals (package, version), 3
        // header rows ([depends] plus two [[packages]] instances),
        // 6 entries inside them (2 + 2 + 2).
        assert_eq!(globals, 2, "the global pair rows");
        assert_eq!(tables, 3, "the [depends] row plus two [[packages]] rows");
        assert_eq!(entries, 6, "the in-table entry rows");
        assert_eq!(lines.len(), 2 + 3 + 6, "the whole-record count");
    });
}

/// The twin's own source must ride the format guard's inventory —
/// pin the embedding and the disk file agree (the tree-asset face
/// the sibling twins' tests hold).
#[test]
fn twin_source_embedding_matches_disk() {
    let disk = std::fs::read_to_string(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/selfhost/v1/micro-toml.ktf"
    ))
    .expect("the twin source reads from disk");
    assert_eq!(
        MICRO_TOML_TARGET_SOURCE, disk,
        "the embedding and disk agree"
    );
}

//! Lexical-capture landing guard (Stage 2.1 — the semantic-flip MUV
//! of the lexical-addressing first cut; docs/stage0.md §9.51/§9.81,
//! anchors K43/K45/K51/K189/K192).
//!
//! The LA-2 zero-production intermediate state (descriptor field +
//! verify rule, no analysis) flipped with the LA-1/LA-3/LA-4/LA-5
//! semantic MUV: the compiler now fills the tables, the VM installs
//! capture areas, the evaluator mirrors, and the checker sees through
//! Fn boundaries. These guards pin the flipped state from both
//! directions:
//!
//! * **Exact production**: capture tables appear exactly where a
//!   closure body references an enclosing binding (the §9.51.2
//!   pre-registered anchor family — inverted from the zero-production
//!   sweep, like `neg-045`'s flip to `pos-034`);
//! * **Assembly identity**: the descriptor participates in
//!   `Bytecode` equality (the gate-B bytecode-identity oracle absorbs
//!   the field structurally), and hand-built descriptors verify
//!   through the public `verify` face at the root level.

use kerf::compiler::{Bytecode, CaptureSource, FuncProto, Instr, Opcode};
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

fn fixture_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

#[test]
fn corpus_capture_production_flips_on_and_stays_minimal() {
    // The flipped LA-1/LA-4 discipline: across the whole frozen
    // corpus, (a) at least one product carries a non-empty capture
    // table (the flip landed — the zero-production anchor inverted),
    // (b) every product whose sources never nest a closure under an
    // enclosing binding still carries all-empty tables (no spurious
    // captures — the K45 minimal-set discipline), and (c) every
    // non-empty table loads through `load-captured` instructions in
    // the owning proto's code (the descriptor/read pairing).
    //
    // W-SEXP-RETIRE blade 1 (v0.111.0): the sweep rides the migrated
    // single-skin `.ktf` corpus (112 cases) through the target
    // reader — the analysis is skin-neutral (items/bytecode level:
    // the reader and expander skins dissolve before the compiler
    // sees the product). The skip rows shifted with the migration:
    // the nine stage-divergent rows now reject at READ (was: at
    // expand), and the three retired divergences dropped; the
    // capture-bearing rows (the nested-fn family) ride the target
    // face unchanged. The r165 measured face: 112 rows — 16 read
    // skips, 18 expand skips (the bare expander, loader-less — the
    // module twins pass here), 2 compile skips, 76 compiled products
    // with 3 capture-bearing among them (the nested-fn family; the
    // three blade-1 dann rows compile through — annotations are
    // zero code).
    let mut paths = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory reads")
        .map(|entry| entry.expect("entry").path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "ktf"))
        .collect::<Vec<_>>();
    paths.sort();

    let mut compiled = 0usize;
    let mut protos_checked = 0usize;
    let mut capturing_products = 0usize;
    for path in &paths {
        let name = path
            .file_name()
            .and_then(|n| n.to_str())
            .expect("corpus file name is utf-8");
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let forms = match read_target_program(FileId(0), &source) {
            Ok(forms) => forms,
            // negative-reader cases never reach compile; skip them
            // (the nine stage-divergent rows among them — the target
            // grammar rejects at read what the S-expr reader
            // deferred to the expander)
            Err(_) => continue,
        };
        let items = match kerf::expander::expand_program(&forms) {
            Ok(items) => items,
            // negative-expander cases never reach compile; skip them
            Err(_) => continue,
        };
        let bc = match kerf::compiler::compile_program(&items) {
            Ok(bc) => bc,
            // negative-typecheck/compile cases; skip them
            Err(_) => continue,
        };
        let mut product_captures = false;
        for (fi, proto) in bc.funcs.iter().enumerate() {
            if !proto.captures.is_empty() {
                product_captures = true;
                // Every captured index is consumed somewhere — the
                // K45 minimal-set discipline THROUGH the LA-4
                // transitive chain: a descriptor is either read by
                // this proto's own code (`load-captured k`) or passed
                // through to a nested closure this proto defines (a
                // nested proto's `Captured(k)` source, consumed at
                // its `closure` instruction).
                for k in 0..proto.captures.len() as u32 {
                    let direct = proto
                        .code
                        .iter()
                        .any(|i| i.op == Opcode::LoadCaptured && i.a == k);
                    let passthrough = bc.funcs.iter().enumerate().any(|(ni, nested)| {
                        nested
                            .captures
                            .iter()
                            .any(|src| matches!(src, CaptureSource::Captured(j) if *j == k))
                            && bc.funcs[fi]
                                .code
                                .iter()
                                .any(|i| i.op == Opcode::Closure && i.a as usize == ni)
                    });
                    assert!(
                        direct || passthrough,
                        "capture {k} of proto {fi} in {name} is consumed nowhere \
                         (no load-captured read, no nested pass-through — over-capture)"
                    );
                }
            }
            protos_checked += 1;
        }
        if product_captures {
            capturing_products += 1;
        }
        compiled += 1;
    }
    assert!(compiled > 0, "accepted face is exercised");
    assert!(protos_checked > 0, "proto face is exercised");
    assert!(
        capturing_products > 0,
        "the semantic flip landed: at least one corpus product captures"
    );
}

#[test]
fn hand_built_descriptor_round_trips_verify_and_equality() {
    // The public root face of the descriptor: hand-built bytecode
    // with in-bounds descriptors verifies; the table participates in
    // equality; two compilations of one source agree on the (empty)
    // tables. Mirrors the crate-level verify tests at the driver
    // seam (the §8.4.6 root-level cross-crate assertion slot).
    let mut entry = FuncProto::new(None, 0, 1);
    entry.code = vec![Instr::with_a(Opcode::Closure, 1), Instr::new(Opcode::Halt)];
    entry.debug_info = vec![fixture_span(); 2];
    let mut callee = FuncProto::new(None, 0, 0);
    callee.captures = vec![CaptureSource::Local(0)];
    callee.code = vec![Instr::with_a(Opcode::PushConst, 0), Instr::new(Opcode::Ret)];
    callee.debug_info = vec![fixture_span(); 2];
    let mut bc = Bytecode::default();
    bc.consts.push(kerf::core::LiteralValue::Int(0));
    bc.funcs.push(entry);
    bc.funcs.push(callee);
    assert!(bc.verify().is_ok(), "in-bounds descriptor verifies");

    // Equality absorbs the table: same table => equal; a different
    // table alone makes the products unequal (the gate-B oracle
    // direction — descriptor drift is bytecode drift).
    let twin = bc.clone();
    assert_eq!(bc, twin);
    let mut drifted = bc.clone();
    drifted.funcs[1].captures[0] = CaptureSource::Captured(0);
    assert_ne!(bc, drifted);
    // ... and the drifted form is rejected against this definer (its
    // own capture table is empty).
    assert!(drifted.verify().is_err());
}

#[test]
fn compile_products_of_one_source_agree_on_capture_tables() {
    // The determinism seam for the analysis: two independent
    // compilations of one closure-bearing source produce identical
    // products including the capture tables — and the flipped
    // analysis lands the expected descriptor (the §9.51.2 anchor
    // inverted: `n` is captured as the defining frame's local 0).
    let src = "fn adder(n) { ||(x) { (x + n) } }\ndefine(r, adder(3));";
    let compile_twice = || {
        let forms = read_target_program(FileId(0), src).expect("fixture reads");
        let items = kerf::expander::expand_program(&forms).expect("fixture expands");
        let bc = kerf::compiler::compile_program(&items).expect("fixture compiles");
        bc.verify().expect("fixture product verifies");
        bc
    };
    let first = compile_twice();
    let second = compile_twice();
    assert_eq!(first, second, "bytecode identity includes captures");
    assert!(
        first.funcs.len() > 1,
        "fixture actually exercises a closure proto"
    );
    // The adder proto (the inner fn) captures exactly `n` — the
    // defining frame's param slot 0 (Local(0), K189's instack=1).
    let adder = first
        .funcs
        .iter()
        .find(|p| !p.captures.is_empty())
        .expect("the flip landed: the inner fn captures");
    assert_eq!(adder.captures, vec![CaptureSource::Local(0)]);
    // and its body reads the capture through load-captured 0.
    assert!(
        adder
            .code
            .iter()
            .any(|i| i.op == Opcode::LoadCaptured && i.a == 0)
    );
}

#[test]
fn session_top_level_closure_still_resolves_globals() {
    // The end-to-end seam (the Stage 1.4 corpus contract surface):
    // a TOP-LEVEL closure proto never captures (the entry has no
    // enclosing bindings — the LA-1 chain ends at the parentless
    // entry), so `get-n`'s body still resolves `n` as a *global*
    // define and the program keeps its pre-flip behavior through
    // both engines (the parity validation drives them side by
    // side). The capture face lives in the nested-fn corpus cases
    // (pos-034/035/036).
    let source = "// expect: value 8\ndefine(n, 8);\nfn get_n() { n }\ndefine(result, get_n());";
    let case = kerf::driver::CorpusCase::from_source("g.ktf", source).expect("directive parses");
    let report = kerf::driver::validate(&case);
    assert!(
        report.matched,
        "top-level closure semantics drifted: {} (observed {:?})",
        report.drift.as_deref().unwrap_or("no drift note"),
        report.observed
    );
}

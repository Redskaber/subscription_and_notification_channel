//! W-3.6 eval consumption inventory guard (stage-3-plan §2.3 W-3.6;
//! docs/develop/v3/w3.6-eval-retirement-window.md §4 — the window's
//! fail-closed ledger, MUV 3.6-a integration case).
//!
//! The meta-circular evaluator retirement evaluation ruled *maintain*
//! (r115). This guard pins the ruling's factual basis: the classified
//! inventory of every direct consumer of the eval face. The scan is a
//! pure read-and-classify face over the repository layout — zero
//! pipeline execution, zero new dependencies (SOP §18), the
//! `test_infra_guard_tests.rs` TEST-1/2/3 precedent shape (§9.57).
//!
//! Scan symbols (nine — the eval-specific face; generic `Engine` or
//! crate-name references are deliberately NOT scanned because they
//! survive an `Engine::Eval` retirement unchanged):
//! `Engine::Eval` / `Evaluator` / `eval_repr` / `eval_text` /
//! `BuiltinHost` / `dispatch_builtin` / `EVAL_DEPTH_LIMIT` /
//! `parity_repr` / the quoted engine name `"eval"`.
//!
//! Three invariants (fail-closed — a red guard means an inventory
//! drift, never a guard bug to silence):
//! 1. Zero unclassified residue: every `.rs` file under the four
//!    scan roots (`crates/`, `src/`, `tests/`, `examples/`) that
//!    mentions any scan symbol must sit in exactly one ledger
//!    bucket. A new eval consumer appears → classify it here AND in
//!    the window record §1 (both-directions doc duty), or retire the
//!    consuming symbol.
//! 2. Zero phantom entries: every ledger path exists on disk and
//!    matches at least one scan symbol (retirement progress keeps
//!    the ledger honest in the other direction).
//! 3. Pinned bucket shape: A3 / B1 / C7 / D3 / E15 / F1 / G1 = 31 —
//!    (r151: C 15→12 — the S-expr reader chain files left the tree;
//!    reader_parity survives as the renamed vm_harness; r161: C
//!    12→14 — the W-PKG-SELFHOST blade-3 lockfile/resolver parity
//!    harnesses, created r158/r159 and classified three rounds
//!    late — the guard had fallen out of the slice filters; r162:
//!    B 2→1 — cli.rs left the tree's eval face with the user-surface
//!    retirement, the W-EVAL-RETIRE blade 1 delivery; r196: C
//!    15→13 — the W-SELFHOST-MODERN-2 blade 1: the five pkg families
//!    went single-vm; r200: C 13→9 / E 17→15 — the MODERN2 blade 4:
//!    the compiler twin's Error-vocabulary consumption retired the
//!    rich drive's eval axis; r201: C 9→8 — the MODERN2 blade 5:
//!    the expander twin's consumption retired the steady expansion
//!    face's eval axis)
//!    the ledger's shape changes only through an explicit window
//!    record revision, never silently.
//!
//! Deliberate exclusions (documented in the window record §1 as
//! transitive/generic consumers, zero eval-specific symbols):
//! `src/lib.rs` (root aggregation re-export — crate-level, not
//! eval-specific), `crates/kerf-driver/src/repl.rs` (the r162
//! engine-field retirement left only the generic `Engine` import
//! riding the VM arm — `Engine::Eval` retirement would leave it
//! untouched, and the field itself is gone),
//! `crates/kerf-driver/src/bootstrap/composed_full_chain.rs`
//! (consumes through function boundaries of classified modules),
//! `crates/kerf-driver/src/cli.rs` (the r162 user-surface
//! retirement — the nine scan symbols score zero hits; the loud
//! retirement messages name the engines without any scan-symbol
//! spelling).

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// The repository root (the crate manifest directory).
fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

/// The nine eval-face scan symbols (window record §1 single source;
/// the quoted `"eval"` keeps the match literal-precise).
const SCAN_SYMBOLS: &[&str] = &[
    "Engine::Eval",
    "Evaluator",
    "eval_repr",
    "eval_text",
    "BuiltinHost",
    "dispatch_builtin",
    "EVAL_DEPTH_LIMIT",
    "parity_repr",
    "\"eval\"",
];

/// The classified ledger: bucket id -> file paths (repo-relative).
/// Bucket roles (window record §1):
/// - A evaluator domain (kerf-runtime: the Evaluator, its exports,
///   and the dual-engine structural comparison key)
/// - B engine dispatch face (kerf-driver: the `Engine` enum + the
///   Eval arm — the library face the verification suite consumes;
///   the CLI/REPL `--engine eval` parsing left at r162, the
///   W-EVAL-RETIRE blade 1 user-surface retirement)
/// - C parity oracle face (kerf-driver: the differential machines,
///   including the fixpoint gate's engines-agree assertion)
/// - D EVL-1 shared dispatch face (kerf-vm: `BuiltinHost` +
///   `dispatch_builtin`, §9.73 single-source 18-arm routing)
/// - E test families (the root test tree, both crate-level api
///   suites, and this guard itself — the ledger's mechanical source)
/// - F audit set (Section H mirrors Section G case-for-case)
/// - G benchmark face (the B-series dual-engine drive slots)
fn ledger() -> BTreeMap<&'static str, Vec<&'static str>> {
    let mut m = BTreeMap::new();
    m.insert(
        "A",
        vec![
            "crates/kerf-runtime/src/eval.rs",
            "crates/kerf-runtime/src/lib.rs",
            "crates/kerf-runtime/src/parity.rs",
        ],
    );
    m.insert(
        "B",
        vec![
            // The r162 eval retirement (W-EVAL-RETIRE blade 1):
            // cli.rs left the bucket — the `--engine`/`--parity`
            // flags reject loudly (the --skin precedent form) and
            // the nine scan symbols score zero hits in the file
            // (the run face drives `Engine::Vm` unconditionally;
            // the generic `Engine` import survives an `Engine::Eval`
            // retirement unchanged and is not a scan symbol).
            "crates/kerf-driver/src/pipeline.rs",
        ],
    );
    m.insert(
        "C",
        vec![
            "crates/kerf-driver/src/parity.rs",
            // The r151 single-skin retirement: lexer_parity.rs /
            // reader_parity.rs / composed_target_chain.rs /
            // bootstrap_chain.rs left the tree with the S-expression
            // reader (reader_parity survives as the renamed
            // vm_harness.rs — the shared VM-value decode tool library).
            "crates/kerf-driver/src/bootstrap/vm_harness.rs",
            // The W-SELFHOST-MODERN-2 blade-4 retirement (r200): the
            // compiler twin consumes the Error vocabulary (perform
            // raise + the unwrap(attempt(...)) boundary), so the
            // rich compile drive went VM-only (the M16/M46 policy
            // line) and the eval_text references dissolved across
            // its consumers — compiler_parity.rs (the RichCompileRun
            // field), target_corpus.rs (the drive + gate B),
            // fixpoint.rs (the three engines-agree assertions), and
            // composed_target_read_chain.rs (the J2 layer's check)
            // all left the eval face; their ledger entries retired
            // with the switch (the guard's phantom check caught the
            // co-variation duty in-round, the standing discipline).
            // The MODERN2 blade-5 retirement (r201): the expander
            // twin consumed the Error vocabulary (perform raise +
            // the unwrap(attempt(...)) boundary), so the steady
            // expansion face went VM-only (the M16/M58 policy
            // line carried to the expander family) and the
            // Evaluator import dissolved; the file left the eval
            // face, its entry retired (the guard's phantom check
            // caught the duty in-round).
            // The W-HM-TWIN segment-three faces (r129, 127-c): the
            // dual-engine inference/check drives — the same
            // differential-machine role as the reader/expander
            // chains' (the RS-4 discipline's segment-three landing).
            "crates/kerf-driver/src/bootstrap/steady_typecheck_chain.rs",
            "crates/kerf-driver/src/bootstrap/infer_parity.rs",
            "tests/v1/stage1/plan/hm_twin_chain_tests.rs",
            // The W-HM-TWIN test face (r130, 127-d): the paired-probe
            // and budget-row per-source drives consume `eval_text`
            // through `infer_twin_per_source_dual` — the same
            // differential-machine role as the 127-c chain tests
            // (window record §1 carries the classification row).
            "tests/v1/stage1/plan/hm_twin_face_tests.rs",
            // The W-EFFECT-MECHANISM blade-2 exemption (r188): the
            // sweep's beyond-oracle lane consumes `eval_text` through
            // `infer_twin_per_source_text_dual` — the engine-agreement
            // role (the r174 frozen-oracle ruling's third blade: the
            // effect typing is beyond the oracle, the twin's own two
            // engines are the consistency gate).
            "tests/v1/stage1/plan/infer_twin_sweep_tests.rs",
            // The W-SELFHOST-MODERN-2 blade-6 retirement (r203): the
            // parser twin consumes the Error vocabulary (perform
            // raise + the unwrap(attempt(...)) boundary), so the
            // steady target read chain went VM-only — the parser
            // layer's Evaluator arm dissolved with the whole chain's
            // engine-agreement axis (the M16/M46 policy line carried
            // to the parser family; the lexer layer's own r198
            // retirement completed) and the file left the eval face,
            // its entry retiring with the switch (the guard's
            // phantom check caught the co-variation duty in-round,
            // the standing discipline).
            // The W-PKG-SELFHOST blade-3 differential faces (created
            // r158/r159, classified r161, RETIRED r196): the lockfile
            // and resolver parity harnesses labeled their twin-dump
            // axes with the engine names until the W-SELFHOST-MODERN-2
            // blade 1 switched the five pkg families to the
            // single-vm drive (the modern2 window §9 M16 ruling —
            // the pkg twins consume the Error vocabulary, the k-form
            // raise paths ride the VM's one-shot semantics, the eval
            // axis retired for them). The two files left the eval
            // face entirely, so their ledger entries retired with
            // the switch (the guard's phantom check caught the
            // co-variation duty in-round, the standing discipline).
            //
            // The W-SELFHOST-MODERN-2 blade-4 C-bucket retirements
            // (r200, same ruling family): composed_target_read_chain
            // retired above alongside the compiler_parity /
            // target_corpus / fixpoint trio.
        ],
    );
    m.insert(
        "D",
        vec![
            "crates/kerf-vm/src/builtin.rs",
            "crates/kerf-vm/src/vm.rs",
            "crates/kerf-vm/src/lib.rs",
        ],
    );
    m.insert(
        "E",
        vec![
            "tests/v0/stage0/plan/driver_seed_tests.rs",
            "tests/v0/stage0/plan/macro_seed_tests.rs",
            "tests/v0/stage0/plan/snapshot_seed_tests.rs",
            "tests/v0/stage0/plan/vm_seed_tests.rs",
            "tests/v0/stage0/plan/runtime_seed_tests.rs",
            "tests/v1/stage1/plan/typecheck_wiring_seed_tests.rs",
            "tests/v1/stage1/plan/stage_exit_tests.rs",
            "tests/v1/stage1/plan/symbol_intern_tests.rs",
            "tests/v1/stage1/plan/parity_contract_tests.rs",
            "tests/v1/stage1/plan/pbt_seed_tests.rs",
            "tests/v1/stage1/plan/message_quality_guard_tests.rs",
            "tests/v1/stage1/plan/limits_ladder_guard_tests.rs",
            // The W-SELFHOST-MODERN-2 blade-4 retirement (r200): the
            // fixpoint test faces' engines-agree assertions dissolved
            // with the rich drive's eval-axis retirement —
            // target_fixpoint_tests.rs (the probe + LA-7 rejection
            // faces) and extern_consumption_tests.rs (the AM-family
            // rejection-key face) left the eval face; the oracle
            // comparisons carry the drift load.
            "crates/kerf-driver/tests/api_tests.rs",
            "crates/kerf-runtime/tests/api_tests.rs",
            // The guard itself carries every scan symbol as literals:
            // the ledger's mechanical single source is a classified
            // eval-face consumer by construction (self-reference is
            // pinned, not special-cased away).
            "tests/v1/stage1/plan/eval_inventory_guard_tests.rs",
        ],
    );
    m.insert("F", vec!["examples/audit/stage0_gate_audit_r1.rs"]);
    m.insert("G", vec!["examples/bench/stage0_baseline.rs"]);
    m
}

/// Recursively collect `.rs` files under `dir` (sorted, deterministic).
fn rust_files_under(dir: &Path) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mut stack = vec![dir.to_path_buf()];
    while let Some(d) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&d) else {
            continue;
        };
        let mut entries: Vec<_> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
        entries.sort();
        for path in entries {
            if path.is_dir() {
                stack.push(path);
            } else if path.extension().is_some_and(|x| x == "rs") {
                out.push(path);
            }
        }
    }
    out.sort();
    out
}

/// Which scan symbols a file's text mentions (possibly several).
fn symbols_in(text: &str) -> Vec<&'static str> {
    SCAN_SYMBOLS
        .iter()
        .copied()
        .filter(|sym| text.contains(sym))
        .collect()
}

/// The scan face: every `.rs` file under the four roots that mentions
/// at least one scan symbol, as repo-relative path -> symbols.
fn scan_hits() -> BTreeMap<String, Vec<&'static str>> {
    let root = repo_root();
    let mut hits = BTreeMap::new();
    for dir in ["crates", "src", "tests", "examples"] {
        for path in rust_files_under(&root.join(dir)) {
            let Ok(text) = std::fs::read_to_string(&path) else {
                panic!("unreadable source file: {}", path.display());
            };
            let syms = symbols_in(&text);
            if !syms.is_empty() {
                let rel = path
                    .strip_prefix(&root)
                    .expect("scan root under repo root")
                    .to_string_lossy()
                    .replace('\\', "/");
                hits.insert(rel, syms);
            }
        }
    }
    hits
}

/// W36-1: every file mentioning an eval-face symbol is classified —
/// zero unclassified residue (the fail-closed promise: a new consumer
/// appears red until the ledger — and the window record §1 — admit
/// it, or the consuming symbol is retired).
#[test]
fn eval_face_inventory_zero_unclassified() {
    let ledger = ledger();
    let classified: Vec<&str> = ledger.values().flatten().copied().collect();
    let mut unclassified = Vec::new();
    for (rel, syms) in scan_hits() {
        if !classified.contains(&rel.as_str()) {
            unclassified.push(format!("{rel}  [{}]", syms.join(", ")));
        }
    }
    assert!(
        unclassified.is_empty(),
        "unclassified eval-face consumers (classify in ledger() + window record §1,\n\
         or retire the consuming symbol):\n  {}",
        unclassified.join("\n  ")
    );
}

/// W36-2: every ledger entry exists on disk and mentions at least one
/// scan symbol — zero phantom entries (both-directions completeness;
/// retirement progress must shrink the ledger in step).
#[test]
fn eval_face_inventory_zero_phantom_entries() {
    let root = repo_root();
    let mut phantoms = Vec::new();
    for (bucket, files) in ledger() {
        for rel in files {
            let path = root.join(rel);
            let classified_reason = if !path.exists() {
                "missing on disk".to_owned()
            } else {
                let text =
                    std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {rel}: {e}"));
                let syms = symbols_in(&text);
                if syms.is_empty() {
                    "on disk but mentions no scan symbol".to_owned()
                } else {
                    continue;
                }
            };
            phantoms.push(format!("bucket {bucket}: {rel} — {classified_reason}"));
        }
    }
    assert!(
        phantoms.is_empty(),
        "phantom ledger entries (remove or reclassify):\n  {}",
        phantoms.join("\n  ")
    );
}

/// W36-3: the pinned bucket shape (A3 / B1 / C7 / D3 / E15 / F1 / G1
/// = 31 — C grew by one at r121 [the W-3.12 steady reader chain],
/// again at r122 [the W-3.12 steady expander chain], again at r129
/// [the segment-three dual-engine faces, +3] and again at r130 [the
/// W-HM-TWIN test face], then SHRANK by three at r151 [the S-expr
/// reader chain files left the tree; reader_parity survives as the
/// renamed vm_harness], then grew by two at r161 [the W-PKG-SELFHOST
/// blade-3 lockfile/resolver parity harnesses — created r158/r159,
/// classified three rounds late because the guard had fallen out of
/// the r158-r160 slice filters], then B shrank by one at r162 [the
/// W-EVAL-RETIRE blade 1 — cli.rs retired from the eval face: the
/// nine scan symbols score zero hits], then C shrank by two at r196
/// [the W-SELFHOST-MODERN-2 blade 1 — the pkg families went
/// single-vm], then C shrank by four and E by two at r200 [the
/// W-SELFHOST-MODERN-2 blade 4 — the compiler twin's Error-vocabulary
/// consumption retired the rich drive's eval axis], and C shrank by
/// one at r203 [the W-SELFHOST-MODERN-2 blade 6 — the parser twin's
/// Error-vocabulary consumption retired the steady read chain's
/// parser-layer eval axis]: every steady chain and its test face
/// join the parity-oracle bucket, and every retirement trims it). A shape change is a window-record revision,
/// never a silent drift — exactly one bucket may grow at a time and
/// the window record §1 table must move in the same commit.
#[test]
fn eval_face_inventory_bucket_shape_pinned() {
    let expected: &[(&str, usize)] = &[
        ("A", 3),
        ("B", 1),
        ("C", 7),
        ("D", 3),
        ("E", 15),
        ("F", 1),
        ("G", 1),
    ];
    let ledger = ledger();
    assert_eq!(ledger.len(), expected.len(), "bucket set itself is pinned");
    let mut total = 0usize;
    for (bucket, count) in expected {
        let actual = ledger
            .get(bucket)
            .unwrap_or_else(|| panic!("bucket {bucket} missing from ledger"))
            .len();
        assert_eq!(
            actual, *count,
            "bucket {bucket} shape drift: expected {count} files, found {actual} — \
             revise the window record §1 and this pin together",
        );
        total += actual;
    }
    assert_eq!(
        total, 31,
        "total ledger size is pinned at 31 (r121: +1 in C; r122: +1 in C; r124: +1 in E; r188: +1 in C — the W-EFFECT-MECHANISM blade-2 sweep beyond-oracle lane;          r129: +3 in C — the W-HM-TWIN 127-c segment-three dual-engine faces;          r130: +1 in C — the W-HM-TWIN 127-d test face;          r139: +2 in C — the W-TGT-READ-TWIN blade-3 steady target read chain and its composed chain;          r151: -3 in C — the S-expr reader chain left the tree;          r161: +2 in C — the W-PKG-SELFHOST blade-3 lockfile/resolver parity harnesses, created r158/r159 and classified three rounds late;          r162: -1 in B — the W-EVAL-RETIRE blade 1: cli.rs retired from the eval face, the nine scan symbols score zero hits;          r196: -2 in C — the W-SELFHOST-MODERN-2 blade 1 switched the five pkg families to the single-vm drive, the lockfile/resolver harnesses left the eval face;          r200: -4 in C / -2 in E — the W-SELFHOST-MODERN-2 blade 4: the compiler twin consumes the Error vocabulary, the rich drive went VM-only, compiler_parity / target_corpus / fixpoint / composed_target_read_chain and the target_fixpoint / extern_consumption test faces left the eval face;          r201: -1 in C — the W-SELFHOST-MODERN-2 blade 5: the expander twin consumes the Error vocabulary, the steady expansion face went VM-only, steady_expander_chain left the eval face;          r203: -1 in C — the W-SELFHOST-MODERN-2 blade 6: the parser twin consumes the Error vocabulary, the steady read face went VM-only, steady_target_reader_chain left the eval face)"
    );
}

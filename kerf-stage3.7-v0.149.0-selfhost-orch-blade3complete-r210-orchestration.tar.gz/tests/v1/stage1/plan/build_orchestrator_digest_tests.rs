//! The W-SELFHOST-ORCH blade-3 digest gate (the orchestrator twin's
//! main parity face — window §11 B7, the r209 split from
//! build_orchestrator_tests: the heavyweight expander-family carrier
//! rides the T1 round-commit tier, the six fast faces stay T0):
//!
//! The expander family three-unit carrier (std/error + macro +
//! expander, first-seen) through the orchestrator's own pipeline
//! must produce the same SEMANTIC artifact as the Rust oracle's
//! direct compilation of the assembly-prefixed host-composed source
//! (the digest projection — span-free, the §9.25.4 cross-skin face;
//! the composition's own spans are unit-local by construction).
//! The carrier assembly prefix (the B7 binding face, r209
//! amendment I) rides BOTH arms — the orchestrator's
//! kb_assembly_prefix and the oracle's carrier_assembly_prefix —
//! so a drift on either face fails this comparison loudly.

use kerf::driver::{
    EXPANDER_TARGET_SOURCE, MACRO_TARGET_SOURCE, STD_ERROR_TARGET_SOURCE, Session,
    assembled_build_source, carrier_assembly_prefix, compose_selfhost, parse_target,
    read_target_source_for_bootstrap, rebuild_bytecode, semantic_projection,
};
use kerf_vm::{BufferIo, Vm};

/// The assembled orchestrator's A pass (the shared seed face — the
/// local-copy convention, the deep_stack precedent).
fn a_pass_compile() -> kerf_compiler::Bytecode {
    let assembled = assembled_build_source();
    let mut session = Session::with_segments(
        kerf::driver::ReadSegment::Rust,
        kerf::driver::ExpandSegment::Rust,
        kerf::driver::CheckSegment::Rust,
        kerf::driver::CompileSegment::Rust,
    );
    let program = parse_target(&mut session, "build-orchestrator.ktf", &assembled)
        .expect("the assembled orchestrator must parse");
    kerf_compiler::compile_program(&program.items).expect("the assembled orchestrator must compile")
}

/// The seed contract for one carrier unit set (B2).
fn seed_lines(units: &[(&str, &str)]) -> Vec<String> {
    let mut lines = vec![units.len().to_string()];
    for (name, source) in units {
        let src_lines: Vec<&str> = source.lines().collect();
        lines.push((*name).to_string());
        lines.push(src_lines.len().to_string());
        lines.extend(src_lines.iter().map(|s| s.to_string()));
    }
    lines
}

#[test]
fn the_orchestrator_composes_the_expander_family_first_seen() {
    // The blade-3 gate's main face (B7): the expander family
    // three-unit carrier — the expander's own source with its two
    // import declarations (std/error + macro, first-seen). The
    // in-language composition must produce the same SEMANTIC
    // artifact as the Rust oracle's direct compilation of the
    // host-composed source (the digest projection — span-free,
    // the §9.25.4 cross-skin face; the composition's own spans
    // are unit-local by construction, never compared raw).
    let bc = a_pass_compile();
    let seed = seed_lines(&[
        ("std/error", STD_ERROR_TARGET_SOURCE),
        ("macro", MACRO_TARGET_SOURCE),
        ("expander", EXPANDER_TARGET_SOURCE),
    ]);
    let mut vm = Vm::with_io(bc.clone(), Box::new(BufferIo::with_input(seed.iter())))
        .expect("the vm must accept the orchestrator");
    if let Err(err) = vm.run() {
        let out = vm.take_output();
        panic!("the orchestrator run failed: {err:?} -- output so far: {out:?}");
    }
    let out = vm.take_output();
    assert!(
        out.contains(&"[orchestrator] composed".to_string()),
        "the expander family must reach the composition milestone: {out:?}"
    );
    let value = vm.global("result").expect("the result global");
    let (head, _) = value.as_pair(vm.heap()).expect("the verdict record");
    let tag = match head {
        kerf_vm::Value::Str(s) => s.to_string(),
        other => format!("{other:?}"),
    };
    assert_eq!(tag, "ok", "the verdict must be ok");

    // The oracle: the same three units, composed by the host
    // composer (the O6 face), read + compiled directly — the
    // carrier assembly prefix rides ahead (the B7 binding face:
    // the same five harness-global defines the orchestrator's
    // kb_assembly_prefix provides; both arms expand against the
    // identical assembly face, so the projections compare
    // like-for-like — and a drift between the two prefix faces
    // fails this comparison loudly).
    let composed = compose_selfhost(EXPANDER_TARGET_SOURCE);
    let assembled = format!("{}{}", carrier_assembly_prefix(), composed);
    let oracle_items = read_target_source_for_bootstrap("expander-family.ktf", &assembled)
        .expect("the assembled expander family must read");
    let oracle_bc = kerf_compiler::compile_program(&oracle_items)
        .expect("the oracle must compile the assembled family");

    // The orchestrator's artifact rebuilt (the FULL product — the
    // ok-tagged verdict value, the rebuild's own contract; the
    // payload alone is the section list without the ok head) and
    // the digests compared.
    let orch_bc =
        rebuild_bytecode(value, vm.heap()).expect("the orchestrator's artifact must rebuild");
    let orch_digest = semantic_projection(&orch_bc);
    let oracle_digest = semantic_projection(&oracle_bc);
    assert_eq!(
        orch_digest, oracle_digest,
        "the orchestrator's artifact must project to the oracle's digest (span-free)"
    );
}

#[test]
fn the_in_language_composition_matches_the_host_composition_at_the_forms_level() {
    // The blade-3 completion round's gate ③: the composition
    // granularity invariance. Run A: the three-unit carrier (the
    // entry rides the expander source with its own import
    // declarations) — the composition happens IN-LANGUAGE at the
    // record level (kb_compose's first-seen splice). Run B: the
    // same logical program as ONE pre-composed unit — the host
    // composer's byte splice (compose_selfhost, the O6 face) fed
    // back through the same in-language pipeline. The two arms'
    // composed streams must carry the SAME forms (the span-free
    // census line, the §9.25.4 cross-skin face — the composition's
    // own spans are unit-local by construction, never compared
    // raw), the same milestone counts, and both artifacts must
    // land the one digest.
    let bc = a_pass_compile();

    // Run A: three units, the entry = the expander source.
    let seed_a = seed_lines(&[
        ("std/error", STD_ERROR_TARGET_SOURCE),
        ("macro", MACRO_TARGET_SOURCE),
        ("expander", EXPANDER_TARGET_SOURCE),
    ]);
    let mut vm_a = Vm::with_io(bc.clone(), Box::new(BufferIo::with_input(seed_a.iter())))
        .expect("the vm must accept the orchestrator");
    if let Err(err) = vm_a.run() {
        let out = vm_a.take_output();
        panic!("the Run A drive failed: {err:?} -- output so far: {out:?}");
    }
    let out_a = vm_a.take_output();
    let value_a = vm_a.global("result").expect("the Run A result global");
    let (head_a, _) = value_a
        .as_pair(vm_a.heap())
        .expect("the Run A verdict record");
    let tag_a = match head_a {
        kerf_vm::Value::Str(s) => s.to_string(),
        other => format!("{other:?}"),
    };
    assert_eq!(tag_a, "ok", "the Run A verdict must be ok");

    // Run B: one pre-composed unit (the host composer's byte splice
    // of the same import graph).
    let precomposed = compose_selfhost(EXPANDER_TARGET_SOURCE);
    let seed_b = seed_lines(&[("entry", precomposed.as_str())]);
    let mut vm_b = Vm::with_io(bc, Box::new(BufferIo::with_input(seed_b.iter())))
        .expect("the vm must accept the orchestrator");
    if let Err(err) = vm_b.run() {
        let out = vm_b.take_output();
        panic!("the Run B drive failed: {err:?} -- output so far: {out:?}");
    }
    let out_b = vm_b.take_output();
    let value_b = vm_b.global("result").expect("the Run B result global");
    let (head_b, _) = value_b
        .as_pair(vm_b.heap())
        .expect("the Run B verdict record");
    let tag_b = match head_b {
        kerf_vm::Value::Str(s) => s.to_string(),
        other => format!("{other:?}"),
    };
    assert_eq!(tag_b, "ok", "the Run B verdict must be ok");

    // The census face: the line right after the composed count —
    // one per arm, span-free, order-preserving.
    let census_of = |out: &[String]| -> (usize, String) {
        let idx = out
            .iter()
            .position(|l| l == "[orchestrator] composed")
            .expect("the composed milestone must be present");
        let count: usize = out[idx + 1].parse().expect("the composed count must parse");
        (count, out[idx + 2].clone())
    };
    let (count_a, census_a) = census_of(&out_a);
    let (count_b, census_b) = census_of(&out_b);
    assert_eq!(
        count_a, count_b,
        "the two composition granularities must land the same record count"
    );
    assert_eq!(
        census_a, census_b,
        "the in-language record-level composition must match the host byte-splice composition at the forms level"
    );

    // The expanded counts must agree too (the same composed stream
    // feeds the same expansion).
    let expanded_of = |out: &[String]| -> usize {
        let idx = out
            .iter()
            .position(|l| l == "[orchestrator] expanded")
            .expect("the expanded milestone must be present");
        out[idx + 1].parse().expect("the expanded count must parse")
    };
    assert_eq!(
        expanded_of(&out_a),
        expanded_of(&out_b),
        "the two arms must expand to the same flat stream size"
    );

    // Both artifacts must land the one digest (and the Run B
    // artifact equals the Run A artifact — the granularity
    // invariance extends to the compiled product).
    let bc_a = rebuild_bytecode(value_a, vm_a.heap()).expect("the Run A artifact must rebuild");
    let bc_b = rebuild_bytecode(value_b, vm_b.heap()).expect("the Run B artifact must rebuild");
    assert_eq!(
        semantic_projection(&bc_a),
        semantic_projection(&bc_b),
        "the two composition granularities must land the one semantic artifact"
    );
}

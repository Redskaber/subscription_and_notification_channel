//! Stage 1.3 cross-crate integration tests — the HM inference base
//! over the REAL pipeline (FP1-FP8 of docs/tests/v1/stage1/
//! hm-inference.md): `kerf_reader::read_target_program` ->
//! `kerf_expander::expand_program` -> `kerf_typecheck::infer_module`.
//!
//! W-SEXP-RETIRE blade 2 (r151): the probe sources ride the target
//! skin (the corpus-dictionary respell — `define(r, ...)`/`fn
//! name(...)`/`if (...) {...} else {...}`, closures `||(x) {...}`,
//! builtins `first`/`pair`/`set`, `==` for `=`), one semantic twin
//! per row; the golden dump strings are skin-neutral (`dump_typed`
//! renders the typed CORE tree) and stay byte-identical.
//!
//! The Externals table comes from the two authoritative sources
//! (single-source discipline, stage-1-plan §4), exactly like the
//! 1.0 checker family. The inference layer runs *beside* R1-R8 —
//! both collect without short-circuiting.
//!
//! Soundness discipline under test (the negative-negative dual):
//! every FP3 error is *definite* (the runtime would reject it), and
//! every FP6 program is *legal* under dynamic semantics (the
//! inference layer must stay silent). The IS family freezes the
//! `dump_typed` rendering byte-for-byte.

use kerf::typecheck::{
    Externals, INFERENCE_DEPTH_LIMIT, InferOutcome, Severity, Type, TypeCode, TypeSchema,
    TypedExpr, infer_module,
};
use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_expander::expand_program;
use kerf_reader::read_target_program;
use kerf_span::Symbol;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_vm::Builtin;

const FILE: FileId = FileId(0);

fn sp(a: u32, b: u32) -> Span {
    Span::new(FILE, ByteOffset(a), ByteOffset(b), ExpansionId::ROOT).expect("test span is ordered")
}

/// The audit-grade externals table: every builtin with its arity.
fn builtin_externals() -> Externals {
    Externals::from_named_arities(
        Builtin::ALL
            .iter()
            .map(|(_, name, arity)| (*name, Some(*arity))),
    )
}

/// read -> expand -> infer over real source text.
fn infer_source(source: &str) -> InferOutcome {
    let forms = read_target_program(FILE, source).expect("source must read");
    let items: Vec<ModuleItem> = expand_program(&forms).expect("source must expand");
    infer_module(&items, &builtin_externals())
}

fn codes_of(out: &InferOutcome) -> Vec<TypeCode> {
    out.diagnostics.iter().map(|d| d.code).collect()
}

fn define_of<'t>(out: &'t InferOutcome, name: &str) -> &'t kerf::typecheck::TypedDefine {
    out.typed
        .defines
        .iter()
        .find(|d| d.name.as_str() == name)
        .unwrap_or_else(|| panic!("define `{name}` missing from typed program"))
}

// ---------- deterministic dump walkers (the IS family) ----------

fn dump_literal(v: &LiteralValue) -> String {
    match v {
        LiteralValue::Int(n) => format!("{n}"),
        LiteralValue::Float(n) => format!("{n}"),
        LiteralValue::Bool(b) => format!("{b}"),
        LiteralValue::String(s) => format!("{s:?}"),
        LiteralValue::Nil => "nil".to_owned(),
        LiteralValue::Pair(a, b) => format!("({} . {})", dump_literal(a), dump_literal(b)),
    }
}

fn fx(effects: &kerf::typecheck::EffectRow) -> String {
    if effects.is_empty() {
        String::new()
    } else {
        format!(" |{}|", effects.render())
    }
}

fn dump_typed(t: &TypedExpr) -> String {
    match t {
        TypedExpr::Fn {
            params, body, ty, ..
        } => {
            let ps: Vec<&str> = params.iter().map(|p| p.as_str()).collect();
            format!("(fn ({}) {} : {})", ps.join(" "), dump_typed(body), ty)
        }
        TypedExpr::Apply {
            func,
            args,
            ty,
            effects,
            ..
        } => {
            let mut parts = vec![dump_typed(func)];
            parts.extend(args.iter().map(dump_typed));
            format!("(apply {} : {}{})", parts.join(" "), ty, fx(effects))
        }
        TypedExpr::If {
            cond,
            then_branch,
            else_branch,
            ty,
            effects,
            ..
        } => format!(
            "(if {} {} {} : {}{})",
            dump_typed(cond),
            dump_typed(then_branch),
            dump_typed(else_branch),
            ty,
            fx(effects)
        ),
        TypedExpr::Var { name, ty, .. } => format!("(var {} : {})", name.as_str(), ty),
        TypedExpr::Literal { value, ty, .. } => {
            format!("(lit {} : {})", dump_literal(value), ty)
        }
        TypedExpr::Assign {
            name, value, ty, ..
        } => format!(
            "(set! {} {} : {}{})",
            name.as_str(),
            dump_typed(value),
            ty,
            ""
        ),
        TypedExpr::Let {
            bindings, body, ty, ..
        } => {
            let bs: Vec<String> = bindings
                .iter()
                .map(|b| format!("({} {} : {})", b.name.as_str(), dump_typed(&b.value), b.ty))
                .collect();
            format!("(let ({}) {} : {})", bs.join(" "), dump_typed(body), ty)
        }
        TypedExpr::Perform {
            effect,
            args,
            ty,
            effects,
            ..
        } => {
            let mut parts = vec![effect.as_str().to_owned()];
            parts.extend(args.iter().map(dump_typed));
            format!("(perform {} : {}{})", parts.join(" "), ty, fx(effects))
        }
        TypedExpr::Handle {
            body,
            handlers,
            ty,
            effects,
            ..
        } => {
            let hs: Vec<String> = handlers
                .iter()
                .map(|h| {
                    format!(
                        "({} {} : {})",
                        h.effect.as_str(),
                        dump_typed(&h.handler),
                        h.ty
                    )
                })
                .collect();
            format!(
                "(handle {} {} : {}{})",
                dump_typed(body),
                hs.join(" "),
                ty,
                fx(effects)
            )
        }
    }
}

fn dump_define(d: &kerf::typecheck::TypedDefine) -> String {
    format!(
        "(define {} : {}{} {})",
        d.name.as_str(),
        d.schema.render(),
        fx(&d.effects),
        dump_typed(&d.body)
    )
}

// ---------- FP1: well-typed programs annotate exactly ----------

#[test]
fn fp1_arithmetic_annotates_int_end_to_end() {
    let out = infer_source("define(r, (1 + 2));");
    assert!(
        out.diagnostics.is_empty(),
        "fp1 clean: {:?}",
        out.diagnostics
    );
    let r = define_of(&out, "r");
    assert_eq!(r.schema, TypeSchema::mono(Type::Int));
    // The callee `+` is a bare builtin reference: dyn, ad-hoc at the
    // application site.
    assert_eq!(
        dump_define(r),
        "(define r : int (apply (var + : dyn) (lit 1 : int) (lit 2 : int) : int))"
    );
}

#[test]
fn fp1_fib_infers_int_to_int() {
    let out = infer_source(
        "define(fib, ||(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } });",
    );
    assert!(
        out.diagnostics.is_empty(),
        "fp1 fib clean: {:?}",
        out.diagnostics
    );
    let fib = define_of(&out, "fib");
    // `(< n 2)` and `(- n 1)` keep n unresolved (ad-hoc skips on
    // unknown), so fib generalizes over its parameter.
    // The recursive calls' returns stay unknown (ad-hoc `+`/`-`
    // skip on unknown operands), so the if-join of `n` and the
    // else-branch is dyn — fib is parametric into an unknown ret.
    assert_eq!(fib.schema.render(), "(forall (t0) (fn (t0) dyn))");
}

#[test]
fn fp1_pair_projection_annotates_structurally() {
    let out = infer_source("define(r, first(pair(1, true)));");
    assert!(out.diagnostics.is_empty(), "fp1 pair clean");
    let r = define_of(&out, "r");
    assert_eq!(r.schema, TypeSchema::mono(Type::Int));
}

#[test]
fn fp1_let_chain_sequential_binding() {
    let out = infer_source("define(r, { let a = 1, b = (a + 1); (b + 3) });");
    assert!(out.diagnostics.is_empty(), "fp1 let clean");
    let r = define_of(&out, "r");
    assert_eq!(r.schema, TypeSchema::mono(Type::Int));
}

#[test]
fn fp1_quote_literal_types_pair_chains() {
    let out = infer_source("define(r, quote((1, true)));");
    assert!(out.diagnostics.is_empty(), "fp1 quote clean");
    let r = define_of(&out, "r");
    assert_eq!(
        r.schema,
        // Quote lists right-fold: (1 . (#t . nil)).
        TypeSchema::mono(Type::Pair(
            Box::new(Type::Int),
            Box::new(Type::Pair(Box::new(Type::Bool), Box::new(Type::Nil)))
        ))
    );
}

#[test]
fn fp1_nested_fn_arrows() {
    let out = infer_source("define(adder, ||(x) { ||(y) { (x + y) } });");
    assert!(out.diagnostics.is_empty(), "fp1 nested clean");
    // + skips on unknowns, so the arrows stay parametric.
    let adder = define_of(&out, "adder");
    assert_eq!(
        adder.schema.render(),
        "(forall (t0 t1) (fn (t0) (fn (t1) dyn)))"
    );
}

// ---------- FP2: polymorphic instantiation ----------

#[test]
fn fp2_id_is_polymorphic_across_uses() {
    let out = infer_source(
        "define(id, ||(x) { x }); define(a, id(1)); define(b, id(true)); define(c, id(id(2)));",
    );
    assert!(
        out.diagnostics.is_empty(),
        "fp2 same-module reuse must be decoupled: {:?}",
        out.diagnostics
    );
    assert_eq!(
        define_of(&out, "id").schema.render(),
        "(forall (t0) (fn (t0) t0))"
    );
    assert_eq!(define_of(&out, "a").schema, TypeSchema::mono(Type::Int));
    assert_eq!(define_of(&out, "b").schema, TypeSchema::mono(Type::Bool));
    assert_eq!(define_of(&out, "c").schema, TypeSchema::mono(Type::Int));
}

#[test]
fn fp2_let_polymorphism_via_generalized_bindings() {
    let out = infer_source(
        "define(r, { let id = ||(x) { x }; ((id(1)) + if (id(true)) { 2 } else { 3 }) });",
    );
    assert!(
        out.diagnostics.is_empty(),
        "fp2 let-poly clean: {:?}",
        out.diagnostics
    );
    let r = define_of(&out, "r");
    assert_eq!(r.schema, TypeSchema::mono(Type::Int));
}

#[test]
fn fp2_mutual_recursion_types_through_the_scc_knot() {
    // Direct construction: the source path's expander enforces
    // define-so-far strictly (probe-disclosed — forward references
    // and define-level mutual recursion are programmatic-API faces
    // today, the same face R1's structural re-assertion serves).
    // The SCC knot must type the classic even/odd pair.
    let even = Symbol::new("even").expect("symbol");
    let odd = Symbol::new("odd").expect("symbol");
    let n = Symbol::new("n").expect("symbol");
    let call = |f: &Symbol, arg: CoreExpr| CoreExpr::Apply {
        span: sp(0, 4),
        func: Box::new(CoreExpr::Var {
            span: sp(0, 1),
            name: f.clone(),
        }),
        args: vec![arg],
    };
    let lit_bool = |v: bool| CoreExpr::Literal {
        span: sp(0, 1),
        value: LiteralValue::Bool(v),
    };
    let num_eq = |arg: CoreExpr| CoreExpr::Apply {
        span: sp(0, 4),
        func: Box::new(CoreExpr::Var {
            span: sp(0, 1),
            name: Symbol::new("=").expect("symbol"),
        }),
        args: vec![
            arg,
            CoreExpr::Literal {
                span: sp(0, 1),
                value: LiteralValue::Int(0),
            },
        ],
    };
    let sub = |arg: CoreExpr| call(&Symbol::new("-").expect("symbol"), arg);
    let body = |other: &Symbol, base: bool| CoreExpr::If {
        span: sp(0, 4),
        cond: Box::new(num_eq(CoreExpr::Var {
            span: sp(0, 1),
            name: n.clone(),
        })),
        then_branch: Box::new(lit_bool(base)),
        else_branch: Box::new(call(
            other,
            sub(CoreExpr::Var {
                span: sp(0, 1),
                name: n.clone(),
            }),
        )),
    };
    let items = vec![
        ModuleItem::Define {
            span: sp(0, 4),
            name: even.clone(),
            value: CoreExpr::Fn {
                span: sp(0, 4),
                params: vec![n.clone()],
                body: Box::new(body(&odd, true)),
            },
        },
        ModuleItem::Define {
            span: sp(0, 4),
            name: odd.clone(),
            value: CoreExpr::Fn {
                span: sp(0, 4),
                params: vec![n.clone()],
                body: Box::new(body(&even, false)),
            },
        },
    ];
    let out = infer_module(&items, &builtin_externals());
    assert!(
        out.diagnostics.is_empty(),
        "fp2 mutual recursion is legal: {:?}",
        out.diagnostics
    );
    assert_eq!(out.typed.defines.len(), 2);
    // Both generalize over their parameter (ad-hoc `=` keeps n free).
    for d in &out.typed.defines {
        assert!(
            !d.schema.vars.is_empty(),
            "{} is parametric",
            d.name.as_str()
        );
        assert!(matches!(d.schema.body, Type::Arrow { .. }));
    }
}

// ---------- FP3: definite type errors (E0009) ----------

#[test]
fn fp3_mixed_arithmetic_is_definite() {
    let out = infer_source("define(r, (1 + 2.0));");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
    assert_eq!(out.diagnostics[0].severity, Severity::Error);
    assert!(
        out.diagnostics[0]
            .message
            .contains("expected `int`, found `float`"),
        "message: {}",
        out.diagnostics[0].message
    );
}

#[test]
fn fp3_non_numeric_arithmetic_is_definite() {
    let out = infer_source("define(r, (true + 1));");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
    assert!(
        out.diagnostics[0]
            .message
            .contains("expected `int` or `float`, found `bool`"),
        "message: {}",
        out.diagnostics[0].message
    );
}

#[test]
fn fp3_mixed_and_non_numeric_comparisons_are_definite() {
    let a = infer_source("define(r, (1 < 2.0));");
    assert_eq!(codes_of(&a), vec![TypeCode::TypeMismatch]);
    let b = infer_source("define(r, (true == false));");
    assert_eq!(codes_of(&b), vec![TypeCode::TypeMismatch]);
}

#[test]
fn fp3_car_of_non_pair_is_definite() {
    let out = infer_source("define(r, first(1));");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
    assert!(
        out.diagnostics[0]
            .message
            .contains("expected `pair`, found `int`"),
        "message: {}",
        out.diagnostics[0].message
    );
}

#[test]
fn fp3_not_and_write_line_domain_errors() {
    let a = infer_source("define(r, not(1));");
    assert_eq!(codes_of(&a), vec![TypeCode::TypeMismatch]);
    let b = infer_source("define(r, write_line(1));");
    assert_eq!(codes_of(&b), vec![TypeCode::TypeMismatch]);
}

#[test]
fn fp3_if_condition_definitely_non_bool() {
    let out = infer_source("define(n, 2); define(r, if (n) { 1 } else { 2 });");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
    assert!(
        out.diagnostics[0]
            .message
            .contains("expected `bool`, found `int`"),
        "message: {}",
        out.diagnostics[0].message
    );
}

#[test]
fn fp3_call_argument_mismatch_is_definite() {
    let out = infer_source("define(f, ||(x) { if (x) { 1 } else { 2 } }); define(r, f(1));");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
}

#[test]
fn fp3_multi_error_collection_never_short_circuits() {
    let out = infer_source("define(a, (1 + true)); define(b, first(2)); define(c, not(1.5));");
    assert_eq!(
        codes_of(&out),
        vec![
            TypeCode::TypeMismatch,
            TypeCode::TypeMismatch,
            TypeCode::TypeMismatch
        ]
    );
}

// ---------- FP3 hardening (Stage 1.8, §9.49 GATE-2): the assembly
// source exposed a false positive — heterogeneous tag dispatch at
// one parameter (different tuple shapes per call site) is legal
// dynamic code; argument-shape unification failures are released,
// never reported. The bool demand (an if condition forcing a
// parameter metavariable) stays a definite error. ----------

#[test]
fn fp3_heterogeneous_tag_dispatch_arguments_are_released() {
    // One parameter, two shapes: `(pair int int)` and
    // `(pair str str)` — a Mismatch the 1.3 engine reported; the
    // body only `car`s the argument (a var the car rule releases),
    // so neither call can fail and the finding was a false
    // positive (the assembled seed-skin expander tripped exactly this).
    let out = infer_source(
        "fn f(t) { first(t) } define(a, f(pair(1, 2))); define(b, f(pair(\"x\", \"y\")));",
    );
    assert!(
        out.diagnostics.is_empty(),
        "tag dispatch is legal: {:?}",
        out.diagnostics
    );
}

#[test]
fn fp3_recursive_tag_dispatch_shapes_are_released() {
    // The ex-cpat shape family, minimized: the recursive call feeds
    // a different tuple depth than the top-level call — released.
    let out = infer_source(
        "fn walk(t) { if (is_nil(rest(t))) { first(t) } else { walk(pair(\"next\", pair(first(t), nil))) } }\ndefine(r, walk(pair(\"top\", pair(1, nil))));",
    );
    assert!(
        out.diagnostics.is_empty(),
        "recursive tag dispatch is legal: {:?}",
        out.diagnostics
    );
}

#[test]
fn fp3_released_call_site_leaves_no_partial_constraints() {
    // After a released mismatch the parameter keeps only what its
    // body demanded: later calls of other shapes must not trip over
    // half-applied bindings (the rollback contract).
    let out = infer_source(
        "fn f(t) { first(t) } define(a, f(pair(1, 2))); define(b, f(\"str\")); define(c, f(pair(true, false)));",
    );
    assert!(
        out.diagnostics.is_empty(),
        "rollback leaves the link table clean: {:?}",
        out.diagnostics
    );
}

#[test]
fn fp3_bool_demand_still_blocks_non_bool_callers() {
    // The kept half of the hardening: a parameter the body forces
    // to bool via an if condition rejects every concrete non-bool
    // argument at run time — a definite error, still reported.
    let out = infer_source("define(f, ||(x) { if (x) { 1 } else { 2 } }); define(r, f(1));");
    assert_eq!(codes_of(&out), vec![TypeCode::TypeMismatch]);
    assert_eq!(out.diagnostics[0].severity, Severity::Error);
}

#[test]
fn fp3_anonymous_fn_alias_bool_demand_is_a_known_release() {
    // Known conservative limit (registered, not a defect): a bool
    // demand routed through an anonymous-fn let alias has no
    // define to consult, so the call-site mismatch is released —
    // fail-closed on uncertainty (a release, never a false report).
    let out =
        infer_source("define(r, { { let g = ||(x) { if (x) { 1 } else { 2 } }; g(1) }; 0 });");
    assert!(
        out.diagnostics.is_empty(),
        "anonymous-fn alias: released by design: {:?}",
        out.diagnostics
    );
}

// ---------- FP4: occurs check (E0010) ----------

#[test]
fn fp4_self_application_is_a_recursive_type() {
    let out = infer_source("define(omega, ||(x) { x(x) });");
    assert_eq!(codes_of(&out), vec![TypeCode::RecursiveType]);
    assert_eq!(out.diagnostics[0].severity, Severity::Error);
    assert!(
        out.diagnostics[0].message.starts_with("recursive type: `t"),
        "message: {}",
        out.diagnostics[0].message
    );
}

#[test]
fn fp4_cons_self_reference_is_legal() {
    // ||(x) { pair(x, x) } — x occurs twice but never inside its own
    // binding: no cycle, no diagnostic.
    let out = infer_source("define(dup, ||(x) { pair(x, x) });");
    assert!(
        out.diagnostics.is_empty(),
        "fp4 legal: {:?}",
        out.diagnostics
    );
}

// ---------- FP5: the depth budget (E0011, warning only) ----------

/// Direct construction: an `if` chain `nested` levels deep (the
/// reader's own nesting cap is 256, so the budget's far side is
/// only reachable through the programmatic path — the same face
/// R1's structural re-assertion serves).
fn deep_if_chain(levels: u32) -> CoreExpr {
    let mut cur = CoreExpr::Literal {
        span: sp(0, 1),
        value: LiteralValue::Int(1),
    };
    for _ in 0..levels {
        cur = CoreExpr::If {
            span: sp(0, 2),
            cond: Box::new(CoreExpr::Literal {
                span: sp(0, 1),
                value: LiteralValue::Bool(true),
            }),
            then_branch: Box::new(cur),
            else_branch: Box::new(CoreExpr::Literal {
                span: sp(0, 1),
                value: LiteralValue::Int(2),
            }),
        };
    }
    cur
}

fn program_with(value: CoreExpr) -> Vec<ModuleItem> {
    vec![ModuleItem::Define {
        span: sp(0, 3),
        name: Symbol::new("deep").expect("valid symbol"),
        value,
    }]
}

#[test]
fn fp5_budget_within_limit_is_silent() {
    // 250 levels stays inside 512 (the archive's A6 anchor).
    let items = program_with(deep_if_chain(250));
    let out = infer_module(&items, &builtin_externals());
    assert!(
        out.diagnostics.is_empty(),
        "fp5 in-budget: {:?}",
        out.diagnostics
    );
    assert_eq!(out.typed.defines.len(), 1);
    assert_eq!(define_of(&out, "deep").schema, TypeSchema::mono(Type::Int));
}

#[test]
fn fp5_budget_exceeded_is_one_warning_never_an_error() {
    let items = program_with(deep_if_chain(600));
    let out = infer_module(&items, &builtin_externals());
    assert_eq!(codes_of(&out), vec![TypeCode::InferenceBudgetExceeded]);
    assert_eq!(out.diagnostics[0].severity, Severity::Warning);
    assert!(
        out.diagnostics[0].message.contains(&format!(
            "type inference budget of `{INFERENCE_DEPTH_LIMIT}` exceeded in `deep`"
        )),
        "message: {}",
        out.diagnostics[0].message
    );
    // Skipped whole: no partial annotations.
    assert!(
        out.typed.defines.is_empty(),
        "budget-skipped define excluded"
    );
}

#[test]
fn fp5_budget_skips_only_the_offending_define() {
    // A deep define plus a shallow one: the shallow one still
    // annotates.
    let mut items = program_with(deep_if_chain(600));
    items.push(ModuleItem::Define {
        span: sp(0, 3),
        name: Symbol::new("shallow").expect("valid symbol"),
        value: CoreExpr::Apply {
            span: sp(0, 2),
            func: Box::new(CoreExpr::Var {
                span: sp(0, 1),
                name: Symbol::new("+").expect("valid symbol"),
            }),
            args: vec![
                CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(1),
                },
                CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(2),
                },
            ],
        },
    });
    let out = infer_module(&items, &builtin_externals());
    assert_eq!(codes_of(&out), vec![TypeCode::InferenceBudgetExceeded]);
    assert_eq!(
        define_of(&out, "shallow").schema,
        TypeSchema::mono(Type::Int)
    );
}

// ---------- FP6: legal programs never get a diagnostic ----------

#[test]
fn fp6_if_branch_join_is_legal_dynamic() {
    let out =
        infer_source("define(c, true); define(r, if (c) { 1 } else { true }); define(s, (r + 1));");
    assert!(
        out.diagnostics.is_empty(),
        "fp6 branch join is legal: {:?}",
        out.diagnostics
    );
    // r joins int|bool -> dyn; s skips on dyn.
    assert_eq!(define_of(&out, "r").schema, TypeSchema::mono(Type::Dyn));
    assert_eq!(define_of(&out, "s").schema, TypeSchema::mono(Type::Dyn));
}

#[test]
fn fp6_assigned_name_never_constrained() {
    // set in a define value position (the established R8 fixture
    // form — bare top-level assignment is a top-level expression the
    // expander rejects).
    let out = infer_source("define(k, ||(x) { x }); define(u, set(k, 2)); define(r, (k + 1));");
    assert!(
        out.diagnostics.is_empty(),
        "fp6 reassignment makes the shape unknowable: {:?}",
        out.diagnostics
    );
    assert_eq!(define_of(&out, "k").schema, TypeSchema::mono(Type::Dyn));
    assert_eq!(define_of(&out, "u").schema, TypeSchema::mono(Type::Int));
    assert_eq!(define_of(&out, "r").schema, TypeSchema::mono(Type::Dyn));
}

#[test]
fn fp6_calling_a_parameter_is_legal() {
    let out = infer_source("define(apply1, ||(f) { f(1) });");
    assert!(
        out.diagnostics.is_empty(),
        "fp6 parametric higher-order: {:?}",
        out.diagnostics
    );
}

#[test]
fn fp6_forward_reference_inside_fn_body_is_legal() {
    // Direct construction: the expander's define-so-far rejects
    // forward references on the source path (probe-disclosed), but
    // the checker's structural model — and therefore the inference
    // layer — types `Fn` bodies with full visibility (call time is
    // post-load). This is the programmatic face.
    let f = Symbol::new("f").expect("symbol");
    let g = Symbol::new("g").expect("symbol");
    let n = Symbol::new("n").expect("symbol");
    let call = |f: &Symbol, arg: CoreExpr| CoreExpr::Apply {
        span: sp(0, 4),
        func: Box::new(CoreExpr::Var {
            span: sp(0, 1),
            name: f.clone(),
        }),
        args: vec![arg],
    };
    let var = |s: &Symbol| CoreExpr::Var {
        span: sp(0, 1),
        name: s.clone(),
    };
    let items = vec![
        ModuleItem::Define {
            span: sp(0, 4),
            name: f.clone(),
            value: CoreExpr::Fn {
                span: sp(0, 4),
                params: vec![n.clone()],
                body: Box::new(call(&Symbol::new("+").expect("symbol"), call(&g, var(&n)))),
            },
        },
        ModuleItem::Define {
            span: sp(0, 4),
            name: g.clone(),
            value: CoreExpr::Fn {
                span: sp(0, 4),
                params: vec![n.clone()],
                body: Box::new(call(&Symbol::new("*").expect("symbol"), var(&n))),
            },
        },
    ];
    let out = infer_module(&items, &builtin_externals());
    assert!(
        out.diagnostics.is_empty(),
        "fp6 forward call (call time is post-load): {:?}",
        out.diagnostics
    );
    // g first (dependencies-first SCCs), then f instantiating g's
    // schema — both annotate as arrows.
    assert_eq!(out.typed.defines.len(), 2);
}

#[test]
fn fp6_branch_binding_isolation() {
    // The undo-log soundness case: the then-branch's `(if m 1 2)`
    // would bind `m` to bool *inside the branch only* — a leaked
    // binding would flag `s` (`(+ m 1)`) with a false positive,
    // because dynamically `m` may be the int `1`.
    let out = infer_source(
        "define(c, true);
         define(m, if (c) { 1 } else { true });
         define(r, if (c) { if (m) { 1 } else { 2 } } else { 0 });
         define(s, (m + 1));",
    );
    assert!(
        out.diagnostics.is_empty(),
        "fp6 branch isolation: the then-branch binding of `m` (as bool) must not leak into `s`: {:?}",
        out.diagnostics
    );
    assert_eq!(define_of(&out, "m").schema, TypeSchema::mono(Type::Dyn));
    assert_eq!(define_of(&out, "r").schema, TypeSchema::mono(Type::Int));
    assert_eq!(define_of(&out, "s").schema, TypeSchema::mono(Type::Dyn));
}

#[test]
fn fp6_read_line_and_eq_are_total() {
    let out = infer_source("define(r, eq(read_line(), 1)); define(s, is_pair(read_line()));");
    assert!(
        out.diagnostics.is_empty(),
        "fp6 total builtins: {:?}",
        out.diagnostics
    );
    assert_eq!(define_of(&out, "r").schema, TypeSchema::mono(Type::Bool));
    assert_eq!(define_of(&out, "s").schema, TypeSchema::mono(Type::Bool));
}

// ---------- FP7: the effect-row collection face ----------

#[test]
fn fp7_perform_appends_its_effect() {
    let out = infer_source("define(r, perform log(1));");
    assert!(out.diagnostics.is_empty());
    let r = define_of(&out, "r");
    assert_eq!(r.effects.render(), "log");
    assert_eq!(r.schema, TypeSchema::mono(Type::Dyn));
}

#[test]
fn fp7_handle_subtracts_intercepted_and_merges_handlers() {
    // log is intercepted; the handler itself performs audit — the
    // over-approximate merge keeps it.
    let out =
        infer_source("define(r, handle (perform log(1)) { log(v) => { perform audit(v) }, });");
    assert!(out.diagnostics.is_empty());
    let r = define_of(&out, "r");
    assert_eq!(r.effects.render(), "audit");
}

#[test]
fn fp7_unhandled_perform_keeps_its_row() {
    let out =
        infer_source("define(r, handle (perform log(perform read(1))) { log(v) => { v }, });");
    assert!(out.diagnostics.is_empty());
    let r = define_of(&out, "r");
    assert_eq!(r.effects.render(), "read");
}

#[test]
fn fp7_nested_handle_residual() {
    let out = infer_source(
        "define(r, handle (handle (perform a(1)) { a(v) => { v }, }) { b(v) => { v }, });",
    );
    assert!(out.diagnostics.is_empty());
    let r = define_of(&out, "r");
    // `a` is intercepted by the inner clause; `b` never fires.
    assert_eq!(r.effects.render(), "");
}

// ---------- FP8: the IS snapshot family ----------

#[test]
fn is01_arithmetic_define_golden() {
    let out = infer_source("define(r, (1 + 2));");
    let golden = "(define r : int (apply (var + : dyn) (lit 1 : int) (lit 2 : int) : int))";
    assert_eq!(dump_define(define_of(&out, "r")), golden);
}

#[test]
fn is02_polymorphic_id_golden() {
    let out = infer_source("define(id, ||(x) { x }); define(a, id(true));");
    let id = dump_define(define_of(&out, "id"));
    let a = dump_define(define_of(&out, "a"));
    assert_eq!(
        id,
        "(define id : (forall (t0) (fn (t0) t0)) (fn (x) (var x : t1) : (fn (t1) t1)))"
    );
    assert_eq!(
        a,
        "(define a : bool (apply (var id : (fn (bool) bool)) (lit true : bool) : bool))"
    );
}

#[test]
fn is03_pair_constructor_golden() {
    let out = infer_source("define(r, pair(1, quote((2,))));");
    let golden = "(define r : (pair int (pair int nil)) \
(apply (var cons : dyn) (lit 1 : int) (lit (2 . nil) : (pair int nil)) : (pair int (pair int nil))))";
    assert_eq!(dump_define(define_of(&out, "r")), golden);
}

#[test]
fn is04_effect_row_golden() {
    let out = infer_source("define(r, perform log(1));");
    let golden = "(define r : dyn |log| (perform log (lit 1 : int) : dyn |log|))";
    assert_eq!(dump_define(define_of(&out, "r")), golden);
}

#[test]
fn is05_if_join_golden() {
    let out = infer_source("define(c, true); define(r, if (c) { 1 } else { true });");
    let golden = "(define r : dyn \
(if (var c : bool) (lit 1 : int) (lit true : bool) : dyn))";
    assert_eq!(dump_define(define_of(&out, "r")), golden);
}

#[test]
fn is06_handle_row_subtraction_golden() {
    let out =
        infer_source("define(r, handle (perform log(1)) { log(v) => { perform audit(v) }, });");
    let golden = "(define r : dyn |audit| \
(handle (perform log (lit 1 : int) : dyn |log|) \
(log (fn (v) (perform audit (var v : t1) : dyn |audit|) : (fn (t1) dyn)) : (fn (t1) dyn)) : dyn |audit|))";
    assert_eq!(dump_define(define_of(&out, "r")), golden);
}

#[test]
fn fp8_dump_is_deterministic_across_runs() {
    let source =
        "define(id, ||(x) { x }); define(r, handle (perform log(id(1))) { log(v) => { v }, });";
    let first = infer_source(source);
    let second = infer_source(source);
    let dump1: Vec<String> = first.typed.defines.iter().map(dump_define).collect();
    let dump2: Vec<String> = second.typed.defines.iter().map(dump_define).collect();
    assert_eq!(dump1, dump2, "double-run determinism");
    assert_eq!(dump1.len(), 2);
}

// ---------- cross-layer integration ----------

#[test]
fn infer_beside_check_both_collect_independently() {
    // A program with one checker error (E0003) and one inference
    // error (E0009): both layers report their own finding.
    let source = "define(a, if (1) { 2 } else { 3 }); define(b, (true + 1));";
    let forms = read_target_program(FILE, source).expect("reads");
    let items: Vec<ModuleItem> = expand_program(&forms).expect("expands");
    let checked = kerf::typecheck::check_module(&items, &builtin_externals());
    let inferred = infer_module(&items, &builtin_externals());
    assert!(
        checked
            .iter()
            .any(|d| d.code == TypeCode::NonBooleanCondition)
    );
    assert!(
        inferred
            .diagnostics
            .iter()
            .any(|d| d.code == TypeCode::TypeMismatch)
    );
}

#[test]
fn typed_program_covers_every_source_define_in_order() {
    let out = infer_source("define(a, 1); define(b, ||(x) { x }); define(c, perform e(1));");
    let names: Vec<&str> = out.typed.defines.iter().map(|d| d.name.as_str()).collect();
    assert_eq!(names, vec!["a", "b", "c"], "module order preserved");
}

//! The W-ROW-POLY blade-1 golden corpus (w-row-poly-window.md §6
//! blade 1, RW-9 — the r174 frozen-oracle ruling's first consumer:
//! the golden pins the TWIN's own verdicts; the Rust oracle never
//! implements rows, so no parity face ever sees these cases).
//!
//! The data-constructed form (RW-9's skin-layer finding): the
//! target skin's spec grammar cannot spell a `"row"` head today
//! (`(` opens a tuple, `path(args)` opens an app) — the `[l: T | r]`
//! skin is blade 2's own deliverable — so every case here builds
//! its `ModuleItem`s directly (a Define carrying one `Fn` plus the
//! `Annotate` dann sites, the paired_drive items-injection
//! precedent) and feeds the steady twin chain.
//!
//! Case families (the blade-1 acceptance gate, 6 positive : 18
//! negative = 1:3): the tail-binding family, the label-rewrite
//! reorder, the open-subsumes-closed closing, the empty closed row,
//! the cross-define instantiation (the generalization face — the
//! schema's var list carries the row variable), and the
//! conservative-degrade boundary; against fifteen E0013 ret-face
//! rows (label conflicts, both lacks directions, disjoint labels,
//! the composite orthogonalities both ways, three nested-field
//! families) plus three E0009 call-site rows. The lacks and
//! label-conflict mismatches ride the REMAINDER/FIELD level (the
//! Leijen precise-diagnosis face — `expected (row), found (row y
//! bool)` names the offending field, not the whole records; the
//! r182-a mapping-table wording rode the original records, the
//! field-level face is the shipped behavior — disclosed and
//! adopted in the window record).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::SteadyTypecheckChain;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> kerf::span::Symbol {
    kerf::span::Symbol::new(text).expect("test symbol is valid")
}

fn s(text: &str) -> LiteralValue {
    LiteralValue::String(std::rc::Rc::from(text))
}

fn l(items: Vec<LiteralValue>) -> LiteralValue {
    let mut out = LiteralValue::Nil;
    for item in items.into_iter().rev() {
        out = LiteralValue::Pair(Box::new(item), Box::new(out));
    }
    out
}

/// One `(x T)` row field.
fn fld(label: &str, ty: LiteralValue) -> LiteralValue {
    l(vec![s(label), ty])
}

/// One closed single-field row `(row (x T) nil)`.
fn rowx(ty: &str, tail: &str) -> LiteralValue {
    l(vec![s("row"), l(vec![s("x"), s(ty)]), s(tail)])
}

/// One row from field pairs and a tail spelling.
fn rown(fields: Vec<LiteralValue>, tail: &str) -> LiteralValue {
    let mut v = vec![s("row")];
    v.extend(fields);
    v.push(s(tail));
    l(v)
}

/// The golden case drive: the steady twin chain, the decoded
/// verdict, byte-exact against the pinned expectation.
fn drive(items: &[ModuleItem]) -> String {
    let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
    chain.infer(items).expect("the twin inference runs")
}

/// One annotated identity function `fn f(r) { r }`: the Define
/// carrying the Fn, one Param dann site, one Ret dann site (the
/// anchor IS the Fn's span — the paired-drive convention).
fn id_fn(param_spec: LiteralValue, ret_spec: LiteralValue) -> Vec<ModuleItem> {
    let fspan = sp(10, 40);
    vec![
        ModuleItem::Define {
            span: sp(0, 41),
            name: sym("f"),
            value: CoreExpr::Fn {
                span: fspan,
                params: vec![sym("r")],
                body: Box::new(CoreExpr::Var {
                    span: sp(35, 36),
                    name: sym("r"),
                }),
            },
        },
        ModuleItem::Annotate {
            span: sp(11, 20),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Param,
            index: 0,
            spec: param_spec,
        },
        ModuleItem::Annotate {
            span: sp(28, 39),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Ret,
            index: 0,
            spec: ret_spec,
        },
    ]
}

/// The positive family — six rows, every one pinning the twin's
/// full decoded verdict (zero diags; the tdef schema shows the row
/// display, the open tail's row variable rides the schema var list).
#[test]
fn row_golden_positive_family() {
    let cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![
        (
            "pos-open-tail-bind",
            id_fn(rowx("int", "_"), rowx("int", "_")),
            "(ok (types (tdef f (schema (2) (fn ((row x int | t2)) (row x int | t2))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int | t2)) (fn ((row x int | t2)) (row x int | t2))))) (diags))",
        ),
        (
            "pos-closed-reorder",
            id_fn(
                rown(vec![fld("x", s("int")), fld("y", s("bool"))], "nil"),
                rown(vec![fld("y", s("bool")), fld("x", s("int"))], "nil"),
            ),
            "(ok (types (tdef f (schema () (fn ((row x int y bool)) (row x int y bool))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int y bool)) (fn ((row x int y bool)) (row x int y bool))))) (diags))",
        ),
        (
            "pos-open-subsume-closed",
            id_fn(
                rown(vec![fld("x", s("int")), fld("y", s("bool"))], "nil"),
                rowx("int", "_"),
            ),
            "(ok (types (tdef f (schema () (fn ((row x int y bool)) (row x int y bool))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int y bool)) (fn ((row x int y bool)) (row x int y bool))))) (diags))",
        ),
        (
            "pos-empty-closed",
            id_fn(rown(vec![], "nil"), rown(vec![], "nil")),
            "(ok (types (tdef f (schema () (fn ((row)) (row))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row)) (fn ((row)) (row))))) (diags))",
        ),
        (
            "pos-degrade-named-tail",
            id_fn(
                l(vec![s("row"), l(vec![s("x"), s("int")]), s("zz")]),
                s("int"),
            ),
            "(ok (types (tdef f (schema () (fn (int) int)) (effs) (tfn 10 40 (r) (tvar 35 36 r int) (fn (int) int)))) (diags))",
        ),
        (
            "pos-cross-define-instantiation",
            {
                let fspan = sp(10, 40);
                let mut items = vec![
                    ModuleItem::Define {
                        span: sp(0, 41),
                        name: sym("f"),
                        value: CoreExpr::Fn {
                            span: fspan,
                            params: vec![sym("r")],
                            body: Box::new(CoreExpr::Var {
                                span: sp(35, 36),
                                name: sym("r"),
                            }),
                        },
                    },
                    ModuleItem::Annotate {
                        span: sp(11, 20),
                        anchor: fspan,
                        kind: kerf::core::AnnotationKind::Param,
                        index: 0,
                        spec: rowx("int", "_"),
                    },
                ];
                items.push(ModuleItem::Define {
                    span: sp(50, 91),
                    name: sym("g"),
                    value: CoreExpr::Fn {
                        span: sp(60, 90),
                        params: vec![sym("a")],
                        body: Box::new(CoreExpr::Apply {
                            span: sp(70, 80),
                            func: Box::new(CoreExpr::Var {
                                span: sp(70, 71),
                                name: sym("f"),
                            }),
                            args: vec![CoreExpr::Var {
                                span: sp(72, 73),
                                name: sym("a"),
                            }],
                        }),
                    },
                });
                items
            },
            "(ok (types (tdef f (schema (2) (fn ((row x int | t2)) (row x int | t2))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int | t2)) (fn ((row x int | t2)) (row x int | t2)))) (tdef g (schema (5) (fn ((row x int | t5)) (row x int | t5))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((row x int | t5)) (row x int | t5))) ((tvar 72 73 a (row x int | t5))) (row x int | t5) (effs)) (fn ((row x int | t5)) (row x int | t5))))) (diags))",
        ),
    ];
    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

/// The E0013 ret-face negative family — thirteen rows (label
/// conflicts, both lacks directions, disjoint labels, the composite
/// orthogonalities both ways, the nested-field families).
#[test]
fn row_golden_negative_e0013_family() {
    let cases: Vec<(&str, LiteralValue, LiteralValue, &str)> = vec![
        (
            "neg-ann-label-int-str",
            rowx("int", "nil"),
            rowx("str", "nil"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x str)`, found `(row x int)`)))",
        ),
        (
            "neg-ann-label-bool-int",
            rowx("bool", "nil"),
            rowx("int", "nil"),
            "(ok (types (tdef f (schema () (fn ((row x bool)) (row x bool))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x bool)) (fn ((row x bool)) (row x bool))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int)`, found `(row x bool)`)))",
        ),
        (
            "neg-ann-label-float-int",
            rowx("float", "nil"),
            rowx("int", "nil"),
            "(ok (types (tdef f (schema () (fn ((row x float)) (row x float))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x float)) (fn ((row x float)) (row x float))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int)`, found `(row x float)`)))",
        ),
        (
            "neg-ann-lacks-ret-extra-closed",
            rowx("int", "nil"),
            rown(vec![fld("x", s("int")), fld("y", s("bool"))], "nil"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int y bool)`, found `(row x int)`)))",
        ),
        (
            "neg-ann-lacks-param-extra-open",
            rown(vec![fld("x", s("int")), fld("y", s("bool"))], "_"),
            rowx("int", "nil"),
            "(ok (types (tdef f (schema (2) (fn ((row x int y bool | t2)) (row x int y bool | t2))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int y bool | t2)) (fn ((row x int y bool | t2)) (row x int y bool | t2))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int)`, found `(row x int y bool | t2)`)))",
        ),
        (
            "neg-ann-disjoint-labels",
            rowx("int", "nil"),
            rown(vec![fld("y", s("int"))], "nil"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row y int)`, found `(row x int)`)))",
        ),
        (
            "neg-ann-row-vs-int",
            rowx("int", "nil"),
            s("int"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `int`, found `(row x int)`)))",
        ),
        (
            "neg-ann-int-vs-row",
            s("int"),
            rowx("int", "nil"),
            "(ok (types (tdef f (schema () (fn (int) int)) (effs) (tfn 10 40 (r) (tvar 35 36 r int) (fn (int) int)))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int)`, found `int`)))",
        ),
        (
            "neg-ann-row-vs-pair",
            rowx("int", "nil"),
            l(vec![s("tuple"), s("int"), s("bool")]),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(pair int bool)`, found `(row x int)`)))",
        ),
        (
            "neg-ann-row-vs-fn",
            rowx("int", "nil"),
            l(vec![s("arrow"), s("int"), s("int")]),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(fn (int) int)`, found `(row x int)`)))",
        ),
        (
            "neg-ann-nested-field-conflict",
            rown(vec![fld("n", rown(vec![fld("x", s("int"))], "nil"))], "nil"),
            rown(vec![fld("n", rown(vec![fld("x", s("str"))], "nil"))], "nil"),
            "(ok (types (tdef f (schema () (fn ((row n (row x int))) (row n (row x int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row n (row x int))) (fn ((row n (row x int))) (row n (row x int)))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row n (row x str))`, found `(row n (row x int))`)))",
        ),
        (
            "neg-ann-nested-arrow-conflict",
            rown(
                vec![fld("f", l(vec![s("arrow"), s("int"), s("int")]))],
                "nil",
            ),
            rown(
                vec![fld("f", l(vec![s("arrow"), s("str"), s("int")]))],
                "nil",
            ),
            "(ok (types (tdef f (schema () (fn ((row f (fn (int) int))) (row f (fn (int) int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row f (fn (int) int))) (fn ((row f (fn (int) int))) (row f (fn (int) int)))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row f (fn (str) int))`, found `(row f (fn (int) int))`)))",
        ),
        (
            "neg-ann-nested-lacks",
            rown(vec![fld("n", rown(vec![fld("a", s("int"))], "nil"))], "nil"),
            rown(
                vec![fld(
                    "n",
                    rown(vec![fld("a", s("int")), fld("b", s("bool"))], "nil"),
                )],
                "nil",
            ),
            "(ok (types (tdef f (schema () (fn ((row n (row a int))) (row n (row a int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row n (row a int))) (fn ((row n (row a int))) (row n (row a int)))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row n (row a int b bool))`, found `(row n (row a int))`)))",
        ),
    ];
    for (name, p, r, expected) in cases {
        assert_eq!(drive(&id_fn(p, r)), expected, "{name}: the pinned verdict");
    }
}

/// The struct/enum orthogonality rows — rule 5's nominal closure
/// never unfolds against a row (the ORIGINAL records ride).
#[test]
fn row_golden_negative_orthogonality_family() {
    let fspan = sp(30, 60);
    let base = |decl: ModuleItem, ret: LiteralValue| {
        let mut items = vec![
            decl,
            ModuleItem::Define {
                span: sp(21, 61),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(55, 56),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(31, 40),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: rowx("int", "nil"),
            },
            ModuleItem::Annotate {
                span: sp(48, 59),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Ret,
                index: 0,
                spec: ret,
            },
        ];
        // the decl must precede the define — rebuild in order
        let decl = items.remove(0);
        items.insert(0, decl);
        items
    };
    let cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![
        (
            "neg-ann-row-vs-struct",
            base(
                ModuleItem::Struct {
                    span: sp(0, 20),
                    name: sym("S"),
                    fields: vec![(sym("a"), s("int"))],
                },
                s("S"),
            ),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 30 60 (r) (tvar 55 56 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 48 59 annotation divergence: expected `S`, found `(row x int)`)))",
        ),
        (
            "neg-ann-row-vs-enum",
            base(
                ModuleItem::Enum {
                    span: sp(0, 20),
                    name: sym("E"),
                    variants: vec![(sym("A"), vec![])],
                },
                s("E"),
            ),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 30 60 (r) (tvar 55 56 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 48 59 annotation divergence: expected `E`, found `(row x int)`)))",
        ),
    ];
    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

/// The E0009 call-site family — the application-face unifications
/// (the row x scalar argument, the closed-lacks argument, the
/// label-conflict argument). The lacks and label mismatches ride
/// the remainder/field level (the Leijen precise-diagnosis face).
#[test]
fn row_golden_negative_e0009_call_site_family() {
    let fspan = sp(10, 40);
    let mut cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![];

    // f = fn(r: (row (x int) nil)) { r }; g = fn() { f(1) }
    {
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: rowx("int", "nil"),
            },
            ModuleItem::Define {
                span: sp(50, 91),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: sp(60, 90),
                    params: vec![],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(70, 80),
                        func: Box::new(CoreExpr::Var {
                            span: sp(70, 71),
                            name: sym("f"),
                        }),
                        args: vec![CoreExpr::Literal {
                            span: sp(75, 76),
                            value: LiteralValue::Int(1),
                        }],
                    }),
                },
            },
        ];
        cases.push((
            "neg-call-row-vs-int-arg",
            items,
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int)))) (tdef g (schema () (fn () (row x int))) (effs) (tfn 60 90 () (tapply 70 80 (tvar 70 71 f (fn ((row x int)) (row x int))) ((tlit 75 76 (int 1) int)) (row x int) (effs)) (fn () (row x int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(row x int)`, found `int`)))",
        ));
    }

    // f = fn(r: (row (x int) nil)) { r }; g = fn(a: (row (x int) (y bool) nil)) { f(a) }
    for (name, g_spec, expected) in [
        (
            "neg-call-closed-lacks-arg",
            rown(vec![fld("x", s("int")), fld("y", s("bool"))], "nil"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int)))) (tdef g (schema () (fn ((row x int y bool)) (row x int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((row x int)) (row x int))) ((tvar 75 76 a (row x int y bool))) (row x int) (effs)) (fn ((row x int y bool)) (row x int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(row)`, found `(row y bool)`)))",
        ),
        (
            "neg-call-label-conflict-arg",
            rowx("str", "nil"),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int)))) (tdef g (schema () (fn ((row x str)) (row x int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((row x int)) (row x int))) ((tvar 75 76 a (row x str))) (row x int) (effs)) (fn ((row x str)) (row x int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `int`, found `str`)))",
        ),
    ] {
        let gspan = sp(60, 90);
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: rowx("int", "nil"),
            },
            ModuleItem::Define {
                span: sp(50, 91),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: gspan,
                    params: vec![sym("a")],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(70, 80),
                        func: Box::new(CoreExpr::Var {
                            span: sp(70, 71),
                            name: sym("f"),
                        }),
                        args: vec![CoreExpr::Var {
                            span: sp(75, 76),
                            name: sym("a"),
                        }],
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(61, 70),
                anchor: gspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: g_spec,
            },
        ];
        cases.push((name, items, expected));
    }

    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

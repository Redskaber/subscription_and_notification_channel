//! Manifest twin tests (W-PKG-SELFHOST blade 2, part two —
//! w-pkg-selfhost-window §4 row 2): the package manager's kerf.toml
//! projection, the COMPOSED program `micro-toml.ktf + semver.ktf +
//! manifest.ktf`, against the Rust oracle `kerf_pkg::Manifest::parse`
//! through the full `.ktf` chain on BOTH engines — the eleventh
//! selfhost twin, the first three-twin composition.
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the projection family (a minimal manifest, the
//!   name-sorted dependency list — the BTreeMap iteration order —
//!   a realistic multi-depend manifest, the full X.Y.Z version
//!   spelling), each case pinned three-way (oracle == twin-vm ==
//!   twin-eval) on the dump grammar.
//! * **Negative** — the three rejection tribes of the blade row
//!   (missing required keys, unknown keys and sections including
//!   the array form, non-kebab names and non-string values) plus
//!   the nested semver rejections and the micro-toml syntax
//!   pass-through, each case asserting the three-way agreement on
//!   the SAME rendered error line (anchor, operand, nested
//!   message).
//! * **Cross-stage consumption** — the composed program's pieces
//!   are the blade 1 and blade 2 twins verbatim (the assembly is
//!   the macro+expander precedent carried across three twins): the
//!   embedding test pins all three disk files against their
//!   compiled-in sources.
//!
//! The deep-stack discipline follows the sibling twin tests: the
//! frozen subset expresses iteration only through self-recursion,
//! so the harness rides a demand-allocated stack thread.

use kerf::driver::{
    MANIFEST_TWIN_CASES, MICRO_TOML_TARGET_SOURCE, SEMVER_TARGET_SOURCE, manifest_oracle_dump,
    manifest_parity,
};

/// The positive family ends at the curated list's
/// `full-triple-version` entry; the rejection families follow it
/// (the const lists them in that order).
const POSITIVE_COUNT: usize = 4;

/// Every twin drive walks the harness Rust walkers and both
/// engines' per-record frames — the sibling tests' demand-allocated
/// stack discipline (the composed program is the heaviest twin:
/// three sources and the projection walk).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the projection family ----------

#[test]
fn projection_cases_hold_three_way_parity() {
    deep_stack(|| {
        for (name, source) in MANIFEST_TWIN_CASES.iter().take(POSITIVE_COUNT) {
            manifest_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- negative: the rejection tribes ----------

#[test]
fn rejection_cases_agree_three_way_on_the_same_key() {
    deep_stack(|| {
        for (name, source) in MANIFEST_TWIN_CASES.iter().skip(POSITIVE_COUNT) {
            manifest_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage: the composition and the sort ----------

/// The dependency projection must render name-sorted (the oracle's
/// BTreeMap iteration order) — the dump line of a reverse-written
/// manifest equals the sorted one's.
#[test]
fn dependency_projection_renders_name_sorted() {
    let sorted = manifest_oracle_dump(
        "package = \"m\"\nversion = \"0.1.0\"\n\n[depends]\na-core = \"0.1\"\nz-util = \"0.2\"\n",
    );
    assert!(
        sorted.contains("(deps (\"a-core\" (con 0.1)) (\"z-util\" (con 0.2)))"),
        "the BTreeMap order renders name-sorted: {sorted}"
    );
    deep_stack(|| {
        manifest_parity("cross-stage-sorted", "package = \"m\"\nversion = \"0.1.0\"\n\n[depends]\nz-util = \"0.2\"\na-core = \"0.1\"\n").unwrap_or_else(|e| panic!("{e}"));
    });
}

/// The composed program's pieces are the blade 1 and blade 2 twins
/// verbatim — pin the three embeddings against their disk files
/// (the tree-asset face the sibling twins' tests hold).
#[test]
fn composed_sources_match_disk() {
    let base = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1/");
    let mt = std::fs::read_to_string(format!("{base}micro-toml.ktf"))
        .expect("the micro-toml twin reads from disk");
    let sv = std::fs::read_to_string(format!("{base}semver.ktf"))
        .expect("the semver twin reads from disk");
    let mf = std::fs::read_to_string(format!("{base}manifest.ktf"))
        .expect("the manifest twin reads from disk");
    assert_eq!(
        MICRO_TOML_TARGET_SOURCE, mt,
        "the blade 1 embedding and disk agree"
    );
    assert_eq!(
        SEMVER_TARGET_SOURCE, sv,
        "the blade 2 semver embedding and disk agree"
    );
    assert_eq!(
        kerf::driver::MANIFEST_TARGET_SOURCE,
        mf,
        "the blade 2 manifest embedding and disk agree"
    );
}

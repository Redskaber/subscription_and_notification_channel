//! Cross-crate integration tests for the Stage 0.8 driver — the
//! §7.1 full-chain standard (test doc: docs/tests/v0/stage0/plan/
//! driver.md §2): every source-reachable error class end-to-end
//! through the driver, positive fib on both engines plus parity, I/O
//! round trips, the REPL session, rendering goldens, and CLI exit
//! codes.
//!
//! CJK fixtures are registered whitelist items (dual-registered in
//! the line_index module docstring and driver.md §2/§5).

use kerf::driver::{
    self, Command, DiagnosticCode, Engine, Repl, ReplEvent, Session, parse_args,
    render_diagnostics, run_parity_source, run_source,
};
use kerf::vm::Value;

const FIB: &str =
    "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(r, fib(10));";

fn expect_global(outcome: &driver::RunOutcome, name: &str, expect: &str) {
    assert_eq!(
        outcome.global(name).map(|v| v.to_string()),
        Some(expect.to_owned()),
        "global `{name}` must hold {expect}"
    );
}

// ---- Positive: the full chain, source text to value ----

#[test]
fn e2e_fib_full_pipeline_on_vm() {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "fib.ktf", FIB, Engine::Vm, &[]).expect("vm run");
    assert_eq!(outcome.engine, Engine::Vm);
    expect_global(&outcome, "r", "55");
}

#[test]
fn e2e_fib_full_pipeline_on_eval() {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "fib.ktf", FIB, Engine::Eval, &[]).expect("eval run");
    assert_eq!(outcome.engine, Engine::Eval);
    expect_global(&outcome, "r", "55");
}

#[test]
fn e2e_parity_fib_agrees() {
    let mut session = Session::new();
    let report = run_parity_source(&mut session, "fib.ktf", FIB, &[]).expect("parity run");
    assert!(report.agrees(), "both engines agree on fib(10)");
    assert!(report.globals_agree);
}

#[test]
fn e2e_io_roundtrip_both_engines() {
    let mut session = Session::new();
    let src = "define(r, write_line(read_line()));";
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome =
            run_source(&mut session, "io.ktf", src, engine, &["piped".to_owned()]).expect("io run");
        assert_eq!(
            outcome.outputs,
            vec!["piped".to_owned()],
            "{engine} io parity"
        );
    }
}

#[test]
fn e2e_check_face_counts_the_product() {
    let mut session = Session::new();
    let check = driver::check_source(&mut session, "fib.ktf", FIB).expect("check");
    assert_eq!(check.func_count, 2, "fib + entry");
    assert!(check.instr_count > 10);
    assert!(check.global_count >= 2);
}

#[test]
fn e2e_repl_session_persists_and_prints() {
    let mut repl = Repl::new();
    match repl.submit("define(x, 41);") {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("define: {other:?}"),
    }
    match repl.submit("x + 1;") {
        ReplEvent::Evaluated {
            value,
            new_outputs,
            new_warnings,
        } => {
            assert!(new_warnings.is_empty());
            assert_eq!(value.as_deref(), Some("42"));
            assert!(new_outputs.is_empty());
        }
        other => panic!("expression: {other:?}"),
    }
}

#[test]
fn e2e_render_golden_is_a_stable_contract() {
    // The rendered diagnostic is a consumed artifact (CLI users and
    // tools): its exact bytes are the contract.
    let mut session = Session::new();
    let diags =
        run_source(&mut session, "bad.ktf", "(1 + 2", Engine::Vm, &[]).expect_err("unclosed");
    let golden = "error[kerf-read]: unexpected token `end of input`\n --> bad.ktf:1:7\n  |\n1 | (1 + 2\n  |       ^\n";
    assert_eq!(render_diagnostics(&session, &diags), golden);
}

#[test]
fn e2e_cli_runs_a_program_to_zero_exit() {
    let args = vec!["run".to_owned(), "prog.ktf".to_owned()];
    let mut out = Vec::new();
    let mut errbuf = Vec::new();
    let read = |_p: &str| Ok("define(r, write_line(\"out\"));".to_owned());
    let mut no_input = || None;
    let code = driver::run_cli(
        &args,
        &read,
        &mut no_input,
        Vec::new(),
        &mut out,
        &mut errbuf,
    );
    assert_eq!(code, 0);
    assert_eq!(String::from_utf8(out).expect("utf8"), "out\n");
}

#[test]
fn e2e_deep_source_rides_the_three_layer_cap_order() {
    // The cap-order fact (plan-0.6 §R5): reader 256 < expander 512 <
    // compiler 1024 — a 250-deep source passes ALL three layers in
    // one driver run. The expansion-depth error class itself is
    // reachable only through synthesized trees (the reader's 256 cap
    // bounds source first); the audit set keeps that case at the
    // expander layer (Section E), so the driver E2E covers the five
    // source-reachable classes plus this boundary probe.
    let mut src = String::from("define(r, ");
    for _ in 0..250 {
        src.push_str("(1 + ");
    }
    src.push('0');
    for _ in 0..250 {
        src.push(')');
    }
    src.push_str(");");
    let mut session = Session::new();
    let outcome = run_source(&mut session, "deep.ktf", &src, Engine::Vm, &[]).expect("deep run");
    expect_global(&outcome, "r", "250");
}

// ---- Negative: every source-reachable error class through the chain ----

#[test]
fn e2e_syntax_error_class_reaches_the_driver() {
    let mut session = Session::new();
    let diags = run_source(&mut session, "s.ktf", "(1 + 2", Engine::Vm, &[]).expect_err("read err");
    assert_eq!(diags.len(), 1);
    assert_eq!(diags[0].code, DiagnosticCode::Read);
    assert!(diags[0].primary_span.is_some());
    assert!(render_diagnostics(&session, &diags).contains("--> s.ktf:1:7"));
}

// e2e_empty_application_class_reaches_the_driver: RETIRED AT r151
// (ruling C12 — `()` reads as nil on the target face, so the empty
// application has no read-stage subject on the single skin; the C12
// behavior pin lives in target_corpus_sweep_tests).

#[test]
fn e2e_unbound_identifier_class_reaches_the_driver() {
    let mut session = Session::new();
    let diags = run_source(
        &mut session,
        "u.ktf",
        "define(r, missing_fn(1));",
        Engine::Vm,
        &[],
    )
    .expect_err("unbound");
    assert_eq!(diags[0].code, DiagnosticCode::Expand);
}

#[test]
fn e2e_arity_mismatch_class_reaches_the_driver() {
    let mut session = Session::new();
    let diags = run_source(
        &mut session,
        "a.ktf",
        // Stage 1.1: known-callee arity mismatches are caught
        // statically now (E0002); the runtime face stays covered
        // through a checker-opaque param-mediated call.
        "define(r, (||(g){ g(1, 2) })(first));",
        Engine::Vm,
        &[],
    )
    .expect_err("arity");
    assert_eq!(diags[0].code, DiagnosticCode::Runtime);
    assert!(diags[0].message.contains("arity mismatch"));
}

#[test]
fn e2e_type_mismatch_class_reaches_the_driver() {
    // The Stage 1.8 HM wiring hoists literal mismatches (e.g.
    // `(+ 1 #t)`) to the checker (E0009); this case keeps the
    // runtime face by routing through an HM-released dynamic
    // parameter (probe-verified, §9.49 GATE-2).
    let mut session = Session::new();
    let diags = run_source(
        &mut session,
        "t.ktf",
        "fn f(x) { first(x) }\ndefine(r, f(5));",
        Engine::Vm,
        &[],
    )
    .expect_err("type");
    assert_eq!(diags[0].code, DiagnosticCode::Runtime);
    assert!(diags[0].message.contains("type mismatch"));
}

#[test]
fn e2e_hm_checker_mismatch_reaches_the_driver() {
    // The checker face the Stage 1.8 HM wiring adds: literal
    // `(+ 1 #t)` is now a compile-time E0009 through the driver
    // batch (probe-verified).
    let mut session = Session::new();
    let diags = run_source(
        &mut session,
        "t.ktf",
        "define(r, (1 + true));",
        Engine::Vm,
        &[],
    )
    .expect_err("type");
    assert_eq!(
        diags[0].code,
        DiagnosticCode::Typecheck(kerf_typecheck::TypeCode::TypeMismatch)
    );
    assert!(diags[0].message.contains("type mismatch"));
}

#[test]
fn e2e_runtime_error_renders_with_line_and_column() {
    // The TD-001 payoff end-to-end: a runtime error's span (resolved
    // through the debug-info table) renders as line:column.
    let mut session = Session::new();
    let src = "define(a, 1);\ndefine(r, (a / 0));";
    let diags = run_source(&mut session, "div.ktf", src, Engine::Vm, &[]).expect_err("div zero");
    let rendered = render_diagnostics(&session, &diags);
    assert!(rendered.contains("--> div.ktf:2:12"), "{rendered}");
    assert!(rendered.contains("division by zero"));
}

#[test]
fn e2e_multiple_files_collect_multiple_diagnostics() {
    // §12.2 multi-error: one run over a session with two broken
    // files reports both — errors are data, not exceptions.
    let mut session = Session::new();
    let mut all = Vec::new();
    for (name, src) in [("one.ktf", "(1 +"), ("two.ktf", "define(r, nope());")] {
        if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
            all.extend(diags);
        }
    }
    assert_eq!(all.len(), 2, "both files contribute a diagnostic");
    let rendered = render_diagnostics(&session, &all);
    assert!(rendered.contains("one.ktf"));
    assert!(rendered.contains("two.ktf"));
    assert!(rendered.contains("aborting due to 2 previous errors"));
}

#[test]
fn e2e_repl_error_then_recovery() {
    let mut repl = Repl::new();
    match repl.submit("define(x, 1);") {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("{other:?}"),
    }
    match repl.submit("garbage_call();") {
        ReplEvent::Error { rendered } => assert!(rendered.contains("kerf-expand")),
        other => panic!("must error: {other:?}"),
    }
    match repl.submit("x + 1;") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("2")),
        other => panic!("session must survive: {other:?}"),
    }
}

#[test]
fn e2e_cli_usage_error_exits_two() {
    let args = vec!["frobnicate".to_owned()];
    let mut out = Vec::new();
    let mut errbuf = Vec::new();
    let read = |_p: &str| Ok(String::new());
    let mut no_input = || None;
    let code = driver::run_cli(
        &args,
        &read,
        &mut no_input,
        Vec::new(),
        &mut out,
        &mut errbuf,
    );
    assert_eq!(code, 2);
    assert!(
        String::from_utf8(errbuf)
            .expect("utf8")
            .contains("unknown command")
    );
}

#[test]
fn e2e_cli_program_error_exits_one_with_rendered_diagnostics() {
    let args = vec!["run".to_owned(), "bad.ktf".to_owned()];
    let mut out = Vec::new();
    let mut errbuf = Vec::new();
    let read = |_p: &str| Ok("define(r, (1 / 0));".to_owned());
    let mut no_input = || None;
    let code = driver::run_cli(
        &args,
        &read,
        &mut no_input,
        Vec::new(),
        &mut out,
        &mut errbuf,
    );
    assert_eq!(code, 1);
    let text = String::from_utf8(errbuf).expect("utf8");
    assert!(text.contains("error[kerf-runtime]:"));
    assert!(text.contains("--> bad.ktf:1:12"));
}

// ---- Cross-stage consumption: the driver as the 0.3-0.7 consumer ----

#[test]
fn e2e_driver_consumes_the_whole_frozen_chain() {
    // One driver run exercises reader -> expander -> compiler -> VM
    // and the runtime evaluator + parity face: the §18.5 edges
    // L2/L3/L5/L6/L7 -> L8 are all live in a single call.
    let mut session = Session::new();
    let report = run_parity_source(
        &mut session,
        "chain.ktf",
        "fn f(x) { (x * x) }\ndefine(r, f(7));",
        &[],
    )
    .expect("chain runs");
    assert!(report.agrees());
    let outcome = run_source(
        &mut session,
        "chain.ktf",
        "fn f(x) { (x * x) }\ndefine(r, f(7));",
        Engine::Vm,
        &[],
    )
    .expect("vm run");
    assert_eq!(outcome.global("r"), Some(&Value::Int(49)));
}

#[test]
fn e2e_cjk_source_renders_character_columns() {
    // Registered CJK fixture (the r151 twin: the CJK text rides a
    // string literal — CJK identifiers are not target-face
    // vocabulary, the lexer rejects them as UnexpectedCharacter):
    // byte offsets must render as character columns (the terminal
    // truth), not byte columns. The stray `)` sits at character
    // column 16 but byte column 18 — a byte-column renderer would
    // print 18.
    let mut session = Session::new();
    let diags = run_source(
        &mut session,
        "cjk.ktf",
        "define(r, \"\u{540d}\");)",
        Engine::Vm,
        &[],
    )
    .expect_err("stray close after CJK");
    assert_eq!(diags[0].code, DiagnosticCode::Read);
    let rendered = render_diagnostics(&session, &diags);
    assert!(rendered.contains("--> cjk.ktf:1:16"), "{rendered}");
    assert!(
        !rendered.contains("1:18"),
        "byte columns would say 18: {rendered}"
    );
    assert!(
        rendered.contains("define(r, \"\u{540d}\");"),
        "excerpt keeps the CJK text"
    );
}

#[test]
fn e2e_parse_args_surface_matches_cli_commands() {
    assert_eq!(
        parse_args(&["run".into(), "a.ktf".into()]),
        Ok(Command::Run {
            file: "a.ktf".into()
        })
    );
    assert_eq!(parse_args(&["repl".into()]), Ok(Command::Repl));
    // The r151 single-skin retirement (the in-crate guard's mirror at
    // the cross-crate face): `--skin` left with the S-expression
    // scaffold — every spelling errors loudly, never a silent no-op
    // (SOP §2.3-4; the in-crate family lives in cli.rs's own tests).
    assert!(
        parse_args(&[
            "run".into(),
            "a.ktf".into(),
            "--skin".into(),
            "target".into()
        ])
        .is_err()
    );
    assert!(
        parse_args(&[
            "run".into(),
            "a.ktf".into(),
            "--skin".into(),
            "sexpr".into()
        ])
        .is_err()
    );
    assert!(parse_args(&["run".into(), "a.ktf".into(), "--skin".into()]).is_err());
    // The r162 eval retirement (the same cross-crate mirror): the
    // `--engine`/`--parity` flags left with the user surface — every
    // spelling errors loudly (the library faces live on: the
    // e2e_fib_full_pipeline_on_eval / e2e_parity_fib_agrees family
    // above drives them through run_source / run_parity_source).
    assert!(
        parse_args(&[
            "run".into(),
            "a.ktf".into(),
            "--engine".into(),
            "eval".into()
        ])
        .is_err()
    );
    assert!(
        parse_args(&["run".into(), "a.ktf".into(), "--parity".into()]).is_err(),
        "the parity flag rejects the same way"
    );
    assert!(
        parse_args(&["repl".into(), "--engine".into(), "vm".into()]).is_err(),
        "the repl arm mirrors the run arm"
    );
}

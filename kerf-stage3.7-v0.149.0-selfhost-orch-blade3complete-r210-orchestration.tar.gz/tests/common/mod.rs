//! Shared helpers for cross-crate integration tests (SOP §9.1 rule 4).
//!
//! This module is mounted exactly once by the test entry
//! (`tests/runner.rs`); individual test modules under `tests/v0/` import
//! it via `super::common` (SOP §8.4.6 note — single-mount avoids the
//! duplicate-module lint).
//!
//! History notes: the sub-stage 0.3 `TokenLike` stand-in retired when
//! `kerf-reader` landed; the r151 single-skin note — the seed-reader
//! token fixtures retired with the S-expression reader (W-SEXP-RETIRE
//! blade 2), so the span-reduction helpers carry plain `Span`s (the
//! ability under test — `Span::join` — never depended on the token
//! type).

use kerf_span::{ByteOffset, FileId, Span, SpanError};

/// Reduce a non-empty span slice to its covering span (the parser
/// reduction pattern — the way the real parser folds token spans
/// into node spans).
///
/// # Panics
/// Panics when `spans` is empty: an empty reduction has no span to report.
pub(crate) fn covering_span(spans: &[Span]) -> Result<Span, SpanError> {
    let mut span = spans[0];
    for other in &spans[1..] {
        span = span.join(other)?;
    }
    Ok(span)
}

/// Convenience: well-formed root-generation span builder for fixtures.
///
/// # Panics
/// Panics when `(start, end)` is malformed — fixture data must be valid by
/// construction; malformed-input behavior is asserted explicitly in the
/// negative tests, never through this helper.
pub(crate) fn root_span(file: u32, start: u32, end: u32) -> Span {
    Span::root(FileId(file), ByteOffset(start), ByteOffset(end))
        .expect("test fixture span must be well-formed")
}

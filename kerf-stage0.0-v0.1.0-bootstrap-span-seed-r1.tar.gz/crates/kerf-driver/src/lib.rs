//! kerf-driver — compiler entry point / pipeline orchestration (Layer 8).
//!
//! Charter: read -> expand -> compile -> execute pipeline assembly,
//! session/file interning and CLI surface. Single-direction pipeline flow
//! (SOP §2.1.1-7); stages interact through data contracts only (§11).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.8 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

//! kerf-compiler — bytecode generation (Layer 5).
//!
//! Charter (docs/stage0.md §19.3): CoreExpr -> Bytecode with a
//! debug_info_table mapping pc ranges back to source spans
//! (docs/stage0.md §12.1 consumption table).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.5 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

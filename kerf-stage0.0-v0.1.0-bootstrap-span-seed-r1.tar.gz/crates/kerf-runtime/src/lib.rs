//! kerf-runtime — runtime, mark-sweep GC and meta-circular evaluator
//! (Layer 7).
//!
//! Charter (docs/stage0.md §19.4 + §21.8 Phase 1): mark-sweep collector and
//! the `eval` meta-circular evaluator used for the dual-execution-path
//! cross-check against the VM (eval vs VM mutual verification of the
//! primitive semantics).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.7 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

//! kerf-vm — bytecode virtual machine (Layer 6).
//!
//! Charter (docs/stage0.md §19.5): iterative main loop with heap-allocated
//! frames (no native recursion — TD-023 anchor from the upstream project);
//! runtime errors resolve spans via the debug_info_table. The VM is a
//! PERMANENT Rust base: rewriting it in kerf is constitutionally excluded
//! (docs/sop.md §21.12-22, R5).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.6 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

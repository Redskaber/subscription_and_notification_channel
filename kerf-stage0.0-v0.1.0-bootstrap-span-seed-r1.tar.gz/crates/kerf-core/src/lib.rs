//! kerf-core — CoreExpr definition (Layer 4).
//!
//! Charter: the frozen semantic primitive set. Single source of truth for
//! the primitive enumeration is this crate's `expr.rs` once implemented
//! (docs/sop.md §21.12-11): Fn / Apply / If / Var / Literal / Assign / Let /
//! Perform / Handle + ModuleItem declaration layer (Define / Require /
//! Module) + `do` surface sugar desugaring to Let. The historical frozen
//! set (docs/stage0.md §3.2: Lambda/App/If/VarRef/Literal/SetBang/Define/
//! Begin/Module) maps onto it via the §6.12.6 semantic-equivalence table —
//! final ratification is a Stage 0.1 design-alignment item (TD-005).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.1 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

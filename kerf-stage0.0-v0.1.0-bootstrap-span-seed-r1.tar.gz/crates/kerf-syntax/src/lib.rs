//! kerf-syntax — SyntaxObject model (Layer 1).
//!
//! Charter (docs/stage0.md §3.3): every piece of syntax carries a span, a
//! scope set and a phase — the hygiene foundation consumed by the reader
//! (Layer 2) and the expander (Layer 3).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.2 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

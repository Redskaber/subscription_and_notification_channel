//! kerf-reader — lexer + parser (Layer 2).
//!
//! Charter (docs/stage0.md §19.1): character stream -> spanned
//! SyntaxObjects; recursive-descent reader with a bounded nesting cap
//! (256-frame guard, FS-1 anchor); every token carries an immutable span
//! (docs/stage0.md §12.1 consumption table).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.3 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

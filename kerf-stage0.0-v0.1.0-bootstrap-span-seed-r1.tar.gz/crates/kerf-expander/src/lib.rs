//! kerf-expander — macro expansion (Layer 3).
//!
//! Charter (docs/stage0.md §19.2): expand SyntaxObject -> fully expanded
//! CoreExpr; hygiene via scope sets; expansion-depth cap; `do` surface
//! sugar desugars to `Let` (primitive-truth anchor: docs/sop.md §21.12-11).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c);
//! implementation planned as sub-stage 0.4 — see
//! docs/develop/v0/stage-0/stage-0-plan.md (tracked as TD-003).

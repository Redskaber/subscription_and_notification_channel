# Release Notes

## v0.1.0 — Stage 0.0 cold-start bootstrap

First engineering artifact of the kerf compiler, reconstructed from the
upstream document repository (sop.md v15.0-verified + stage0.md design
blueprint, content state v9.8).

- Cargo workspace, edition 2024: root aggregation package + 9 `kerf-*`
  member crates wired exactly along the SOP §18.5 dependency DAG.
- Seed MUV `kerf-span` (Layer 0): `FileId` / `ByteOffset` / `ExpansionId` /
  `Span` with checked invariants (stage0.md §8.6 four-field model, §12.1
  byte-offset representation). Line/column rendering deferred to the
  diagnostics framework (TD-001).
- Test architecture per SOP §8.4.6/§9.1: root `tests/runner.rs` single
  entry + three-layer suite (unit / crate API / cross-crate integration).
- Stage 0 roadmap fixed: sub-stages 0.0-0.11 (minimal semantic kernel →
  infrastructure depth → macro engine → interface-reservation freeze →
  stage gate).
- Verification: SOP §3.2 six commands all green (see
  `docs/develop/v0/stage-0/plan-0.0.md`).

//! kerf — root aggregation crate of the kerf compiler workspace.
//!
//! This crate is the cross-crate layer of the Cargo workspace (SOP §8.4.6):
//! it hosts workspace-level aggregation re-exports and backs the root
//! `tests/` tree (cross-crate integration tests enter via `tests/runner.rs`).
//!
//! Member crates implement the pipeline stages (span -> syntax -> reader ->
//! expander/core -> compiler -> vm -> runtime -> driver). See
//! `docs/develop/v0/stage-0/stage-0-plan.md` for the stage plan and
//! `docs/stage0.md` for the design blueprint.

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use kerf_compiler as compiler;
pub use kerf_core as core;
pub use kerf_driver as driver;
pub use kerf_expander as expander;
pub use kerf_reader as reader;
pub use kerf_runtime as runtime;
pub use kerf_span as span;
pub use kerf_syntax as syntax;
pub use kerf_vm as vm;

/// Workspace version of the kerf compiler.
/// Single source of truth: `[workspace.package] version` in the root manifest.
pub const WORKSPACE_VERSION: &str = env!("CARGO_PKG_VERSION");

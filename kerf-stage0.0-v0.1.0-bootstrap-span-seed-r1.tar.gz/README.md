# kerf

A minimal-bootstrap systems programming language compiler — Rust workspace,
edition 2024.

> **One-liner** (activation protocol): Rust kerf compiler, Cargo Workspace
> edition 2024 (`kerf_*` crates), frozen minimal-primitive kernel (primitive
> invariance: no new primitives, no channels, no VM rewrite, no syntax),
> Stage 0-1 self-built VM (**the VM is a permanent Rust base — a
> "fully self-hosted" VM rewrite is constitutionally excluded**), LLVM /
> native-code backends never enter the bootstrap chain.

## Status

**Stage 0.0 — cold-start bootstrap** (workspace scaffold + stage-0 plan +
`kerf-span` seed MUV). See `docs/develop/v0/stage-0/stage-0-plan.md` for the
sub-stage roadmap (0.0 → 0.11).

## Workspace layout

Structure authority: `docs/sop.md` §8.4.6 (two-level semantics) + §18.5
(dependency DAG).

```
kerf/
├── Cargo.toml            # workspace manifest + root aggregation package
├── src/                  # root crate (aggregation / cross-crate test layer)
├── crates/
│   ├── kerf-span/        # L0  Span / positions          (implemented)
│   ├── kerf-syntax/      # L1  SyntaxObject               (scaffold → 0.2)
│   ├── kerf-reader/      # L2  lexer + parser             (scaffold → 0.3)
│   ├── kerf-expander/    # L3  macro expansion            (scaffold → 0.4)
│   ├── kerf-core/        # L4  CoreExpr (frozen kernel)   (scaffold → 0.1)
│   ├── kerf-compiler/    # L5  bytecode generation        (scaffold → 0.5)
│   ├── kerf-vm/          # L6  bytecode VM (Rust base)    (scaffold → 0.6)
│   ├── kerf-runtime/     # L7  GC + eval                  (scaffold → 0.7)
│   └── kerf-driver/      # L8  pipeline orchestration     (scaffold → 0.8)
├── tests/                # cross-crate integration tests (runner.rs entry)
├── docs/                 # sop.md + stage0.md + develop/tests/worklog trees
└── worklog.md            # flat worklog — audit base (SOP §8.6.1)
```

## Build & verify (SOP §3.2, Stage 0-1 — no LLVM)

```bash
cargo clean && cargo build --release && cargo check && \
  cargo fmt --check && cargo clippy --all-targets -- -D warnings && \
  cargo test --release
```

All six must be green before any delivery.

## Documents

| Path | Role |
|------|------|
| `docs/sop.md` | Process authority (v15.0-verified) — stage/quality control |
| `docs/stage0.md` | Design blueprint archive (content state v9.8; header label lags — see `docs/lang-design/README.md`) |
| `docs/develop/v0/stage-0/` | Stage 0 plan + sub-stage plans |
| `docs/develop/v0/tech-debt-register.md` | Technical debt ledger (TD-001…) |
| `docs/develop/v0/calibration-data.md` | Process calibration pool |
| `docs/tests/` | Test documentation twin tree |
| `docs/worklog/` | worklog rec tree (routing index) |
| `worklog.md` | Flat append-only worklog (single source of truth) |

## License

Not yet determined (cold-start repository; upstream doc repo:
Redskaber/subscription_and_notification_channel).

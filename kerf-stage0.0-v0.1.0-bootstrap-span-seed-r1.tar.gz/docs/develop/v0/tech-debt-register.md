# 综合技术债登记册（tech-debt-register.md）

> 依据：docs/sop.md §6.2.1。只追加不删除；已解决项保留历史并标注 `[Resolved at Stage N.M]`。
> **Author**: redskaber（模板口径沿袭 sop.md §6.6.1 样例）
> **Version**: v0.1（Stage 0.0 建立）
> **最后更新**: Stage 0.0 / 2026-09-27

## 1. 已解决项（Resolved）

| ID | 描述 | 解决阶段 | 验证方式 |
|----|------|---------|---------|
| （暂无） | | | |

## 2. 剩余项（Open）

| ID | 描述 | 等级 | 目标解决 | 阻塞条件 |
|----|------|------|---------|---------|
| TD-001 | 行/列渲染延后：Span 仅存字节偏移（stage0.md §12.1 渲染期派生原则），LineIndex 与行列派生属诊断渲染层 | **P2** | 0.8（driver 诊断收口） | 无（0.1-0.7 均以字节偏移为合法口径） |
| TD-002 | `Span::join` 跨展开代合并被拒绝（JoinExpansionMismatch）：跨代合并语义属宏期关注点，未定义 | P3（0.4 起 P1） | 0.4（expander 设计对齐） | expander 需要跨代 span 时升 P1 强制裁定 |
| TD-003 | 8 个骨架 crate（syntax/reader/expander/core/compiler/vm/runtime/driver）仅有章程文档无实现 | P3（**计划性脚手架**，非事故性桩——R1 判定依据：每 crate 落位与验收已写入 stage-0-plan.md §5，属「计划内空位」） | 0.1-0.8 逐子阶段 | 无（升级路径 = 计划本身） |
| TD-004 | §18.5 依赖图未含 kerf-span→kerf-core 边，与 stage0.md §8.6「IR 节点携带 Span」存在张力 | P3（0.1 起 **P1**） | 0.1（设计对齐裁定 + §18.5 图同步） | 0.1 实现 CoreExpr 时必须先裁（携带 Span 则加边并同步文档——§8.4.6 规则 5） |
| TD-005 | 原语集双轨口径待落文：r67 现行真值集（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle + ModuleItem + do→Let）vs stage0.md §3.2 历史冻结集（Lambda/.../Module）——按 §6.12.6 语义等价映射解读的正式裁定文 | P3（0.1 起 **P1**） | 0.1（§13.1 设计对齐首议程） | 0.1 实现前必须裁定（原语集 = 语义验证对象本体） |
| TD-006 | docs/stage0.md 文件头版本标签（v8.8）滞后于内容实态（v9.8——尾部「附录 G v7 增补」终态注记）；上游存档保持原样不改写 | P3（文档质量 F7 类） | 机会性（下次触及该文件时） | 无——代偿说明已落 docs/lang-design/README.md |

## 3. 架构摘要（Stage 0.0 时点）

- 流水线：`Reader → Expander → Compiler → VM → Runtime`（仅 span 层实现；全图见 docs/graph/stage-0/dataflow.md）
- 测试计数：**48**（32 单元 / 8 crate API / 8 跨 crate 集成；正负比 12:36 = 1:3）
- Span::DUMMY 状态：**不存在 DUMMY span**——`Span::new` 为校验构造（start ≤ end 强制），空 span 合法但携带真实偏移；未来任何 DUMMY 引入即 P1（§6.2 分级审查）
- 枚举分支覆盖：SpanError 三变体全部有负向断言（构造拒绝/合并拒绝/消息渲染）
- 错误系统状态：kerf-span 手写 `std::error::Error`（零外部依赖——§18 审查规避裁定）；ReadError/ExpandError/... 随各自子阶段引入

## 4. 分类索引

- 按 §6.1 等级：P2 ×1（TD-001）｜P3 ×5（TD-002/003/004/005/006；其中 004/005 于 0.1 升 P1，002 于 0.4 升 P1）
- 按 §11.3 接口隔离违规（L-PIPE-N）：无
- 按 §10 命名违规（L-NAMING-N）：无
- 按 §13.4 重构判据（J1-J6）：无

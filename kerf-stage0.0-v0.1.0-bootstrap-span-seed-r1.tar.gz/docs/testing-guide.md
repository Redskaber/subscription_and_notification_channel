# 测试指南（testing-guide.md）

> 依据：docs/sop.md §8.4.6（两级测试语义）/ §9.1-§9.5（结构/矩阵/比例）/ §9.7（条例格式）。

## 三层测试架构（两级语义）

| 层 | 位置 | 验证对象 | 发现入口 |
|----|------|---------|---------|
| 单元 | crate `src/**` 内联 `#[cfg(test)]` | 内部行为 | cargo 自动 |
| crate API | `crates/<name>/tests/*.rs` | 本 crate 公共 API（禁止跨 crate 断言——P1 结构违规） | cargo 自动 |
| 跨 crate 集成 | 根 `tests/v0/stage-N/{plan,gate}/*.rs` | 流水线/集成/阶段门审计 | **仅** `tests/runner.rs` 单入口 `#[path]` 挂载（§8.4.6 v11.2——零 `[[test]]` 声明） |

- 新增集成测试 = runner.rs 加一行 `#[path]` mod + 新建文件。
- 共享辅助入 `tests/common/mod.rs`（相对 `#[path]` 挂载，以测试文件自身目录为基准）。
- 每个测试代码文件必须有 docs/tests/ 双生文档（目标/场景/计数/覆盖率——§9.2 规则 2）。

## 硬性纪律

1. **正负比 ≥ 1:3**（§9.4.3）：每功能点 ≥1 正向 + ≥3 负向；QA 投票前核验，不达标自动 NEEDS REVISION。
2. **七类错误矩阵**（§7.1.1）：随管线子阶段逐类点亮（0.3 语法/空应用 → 0.4 未绑定/宏深度 → 0.6 参数/类型 → 0.9 循环依赖）；0.11 门审 7/7。
3. **测试先文档**（§17 Step 5 + §9.4）：子阶段开工前先写 docs/tests/v0/stage0/plan/<x>.md。
4. **阶段门审计集**（§7.3.1）：≥30 case（负向 ≥22），入 `examples/audit/stage<N>_gate_audit_r<R>.rs`，可重跑、逐轮不减。

## 当前基线（Stage 0.0）

48 tests（12 正 / 36 负 = 1:3）：`cargo test --release` 全绿。明细见 docs/tests/matrix.md 与 v0/stage0/plan/span.md。

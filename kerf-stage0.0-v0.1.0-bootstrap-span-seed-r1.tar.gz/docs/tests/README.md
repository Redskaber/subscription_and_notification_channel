# 测试文档索引（docs/tests/）

> 依据：docs/sop.md §9.2——每个测试代码文件必须有对应测试文档（双向印证）。

| 测试代码 | 测试文档 | 层级 |
|---------|---------|------|
| crates/kerf-span/src/span.rs（内联 tests） | v0/stage0/plan/span.md | 单元 |
| crates/kerf-span/tests/api_tests.rs | v0/stage0/plan/span.md | crate API |
| tests/v0/stage0/plan/span_seed_tests.rs（经 tests/runner.rs 挂载） | v0/stage0/plan/span.md | 跨 crate 集成 |

全局矩阵：[matrix.md](matrix.md)（阶段门审查输入）。

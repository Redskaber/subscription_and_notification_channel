# 全局测试矩阵（matrix.md）

> 依据：docs/sop.md §9.5。每子阶段完成后更新；阶段门审查（§7.3）的输入。
> 口径：「近 100%」= 功能覆盖 + 回归 + 边界 + 负向 + 审计 + 流水线路径 + 正负比（1:3+）；允许 ≤5% DEFERRED（有理由有计划），不允许 UNTESTED。

## Stage 0 功能点覆盖

### Stage 0.0（已交付——2026-09-27）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 Span::new 校验构造 | span.rs 内联 | 2 | 4 | ✅（0..0、MAX..MAX、MAX 反转） | ✅ TESTED |
| FP2 Span::root 简写 | span.rs 内联 | 1 | 2 | ✅（与 new 等价性） | ✅ TESTED |
| FP3 is_empty/len | span.rs 内联 | 1 | 3 | ✅（单字节/全幅/MAX） | ✅ TESTED |
| FP4 contains_offset（半开） | span.rs 内联 | 1 | 5 | ✅（start 含/end 排除/空 span） | ✅ TESTED |
| FP5 join 合并 | span.rs 内联 | 1 | 6 | ✅（对称/嵌套/空操作数/双轴独立） | ✅ TESTED |
| FP6 Display + 错误面 | span.rs 内联 | 2 | 4 | ✅（R8 消息惯例断言） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| workspace 装配 + 跨阶段消费 | span_seed_tests.rs | 2 | 6 | ✅（token 归约模式） | ✅ TESTED |
| **合计** | | **12** | **36** | | **正负比 1:3 ✅** |

### §7.1.1 七类错误负向矩阵（阶段累计视图）

| 错误类 | 落位子阶段 | 当前状态 |
|--------|-----------|---------|
| 语法错误 | 0.3 | DEFERRED（无 Reader——结构性，见 plan-0.0.md §3） |
| 未绑定标识符 | 0.4 | DEFERRED（同上） |
| 语法对象为空（空应用） | 0.3/0.4 | DEFERRED（同上） |
| 参数个数错误 | 0.6 | DEFERRED（无 VM） |
| 类型不匹配 | 0.6 | DEFERRED（无 VM） |
| 模块循环依赖 | 0.9 | DEFERRED（无模块加载） |
| 宏展开深度超限 | 0.4 | DEFERRED（无 Expander） |

> DEFERRED 占比说明：0.0 时点管线类功能尚未存在（非「有功能未测」）；该矩阵为**阶段累计视图**，0.11 门审要求 7/7。当前阶段功能点（span 族 + 装配）无 UNTESTED 项。

### 回归视图

- 全量套件于每子阶段 §3.2 第 6 命令重跑（六命令流水含 `cargo test --release`）；0.0 基线 = 48/48。

## Stage 0.1+（规划中——占位）

子阶段交付时按同构表追加（0.1 CoreExpr / 0.2 SyntaxObject / ...）。

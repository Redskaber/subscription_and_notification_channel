# Stage 0 数据流与依赖图（graph/stage-0/）

> 依据：docs/sop.md §15（项目图管理）+ §18.5（内部依赖图）+ §9.5.1（流水线路径覆盖矩阵）。
> 图形与文档同源：结构变更须同步更新本图（§8.4.6 规则 5）。

## 1. Cargo Workspace 依赖 DAG（SOP §18.5——当前实现态）

```mermaid
flowchart TD
    subgraph Implemented["已实现（Stage 0.0）"]
        L0["kerf-span<br/>Span/位置（48 测试绿）"]
    end
    subgraph Scaffold["章程化骨架（TD-003）"]
        L1["kerf-syntax"]
        L2["kerf-reader"]
        L3["kerf-expander"]
        L4["kerf-core"]
        L5["kerf-compiler"]
        L6["kerf-vm"]
        L7["kerf-runtime"]
        L8["kerf-driver"]
    end
    ROOT["kerf（根聚合 crate + 根 tests/）"]

    L0 --> L1
    L1 --> L2
    L1 --> L3
    L4 --> L3
    L4 --> L5
    L5 --> L6
    L6 --> L7
    L2 --> L8
    L3 --> L8
    L5 --> L8
    L6 --> L8
    L0 -.->|TD-004 待裁| L4
    ROOT -.->|聚合 re-export| L0 & L1 & L2 & L3 & L4 & L5 & L6 & L7 & L8
```

> 注：虚线 = 待裁定边（TD-004：stage0.md §8.6 要求 IR 节点携带 Span）与根聚合关系；实线 = §18.5 既有边。

## 2. 目标编译流水线（Stage 0 完成态——测试路径覆盖对象）

```mermaid
flowchart LR
    Source["源码"] --> R["Reader<br/>(0.3)"]
    R --> SO["SyntaxObject<br/>含 Span (0.2)"]
    SO --> E["Expander<br/>(0.4)"]
    E --> CE["CoreExpr<br/>9 语义原语 (0.1)"]
    CE --> C["Compiler<br/>(0.5)"]
    C --> BC["Bytecode<br/>含 debug_info"]
    BC --> VM["VM (0.6)"]
    VM --> V["Value"]
    V -.->|双路径互查| EVAL["eval (0.7)"]
    CE -.-> EVAL
```

## 3. Span 消费流（stage0.md §12.1 消费表——Stage 0.0 已交付首行）

| 阶段 | Span 携带位置 | 消费方式 | 状态 |
|------|-------------|---------|------|
| Reader | 每个 Token | 词法错误定位、无损覆盖校验（join 归约模式已由集成测试验证） | 0.3 |
| Expander | SyntaxObject + expansion_id | 多阶段错误关联、卫生性追踪 | 0.4 |
| Compiler | 字节码指令 → debug_info_table | 运行时错误反查源码 | 0.5 |
| VM | debug_info_table（按 pc 查询——contains_offset 已就绪） | 堆栈追踪、调试断点 | 0.6 |
| 增量编译 | 文件 × 字节区间 | 细粒度失效传播 | Stage 1+ |

//! Cross-crate integration test single entry (SOP §8.4.6 v11.2).
//!
//! Cargo auto-discovers this file as the root package's integration test
//! target. Every test module under `tests/v0/stage-N/{plan,gate}/` is
//! mounted here via `#[path]` — no per-file `[[test]]` declarations.
//! Selective run: `cargo test --test runner <module>::<case>`.

#[path = "v0/stage0/plan/span_seed_tests.rs"]
mod span_seed_tests;

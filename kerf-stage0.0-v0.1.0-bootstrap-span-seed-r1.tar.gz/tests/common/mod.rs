//! Shared helpers for cross-crate integration tests (SOP §9.1 rule 4).
//!
//! This module is mounted by test files via a relative `#[path]`
//! attribute; resolution is anchored to each test file's own directory
//! (SOP §8.4.6 note).

use kerf_span::{ByteOffset, FileId, Span};

/// Stand-in token shape for consumer-contract tests.
///
/// Mirrors how Stage 0.3 `kerf-reader` tokens will carry an immutable span
/// (docs/stage0.md §12.1 consumption table, "Reader | every Token"). It
/// exists to prove the Span contract for the next pipeline consumer and is
/// retired when `kerf-reader` lands (plan sub-stage 0.3).
pub(crate) struct TokenLike {
    pub text: &'static str,
    pub span: Span,
}

impl TokenLike {
    pub(crate) fn new(text: &'static str, span: Span) -> Self {
        Self { text, span }
    }
}

/// Reduce a non-empty token slice to its covering span (parser reduction
/// pattern — the way the future parser will fold token spans into node
/// spans).
///
/// # Panics
/// Panics when `tokens` is empty: an empty reduction has no span to report.
/// The empty-production span policy is a Stage 0.3 reader design item (see
/// the stage plan), not something this helper may paper over.
pub(crate) fn covering_span(tokens: &[TokenLike]) -> Result<Span, kerf_span::SpanError> {
    let mut span = tokens[0].span;
    for token in &tokens[1..] {
        span = span.join(&token.span)?;
    }
    Ok(span)
}

/// Convenience: well-formed root-generation span builder for fixtures.
///
/// # Panics
/// Panics when `(start, end)` is malformed — fixture data must be valid by
/// construction; malformed-input behavior is asserted explicitly in the
/// negative tests, never through this helper.
pub(crate) fn root_span(file: u32, start: u32, end: u32) -> Span {
    Span::root(FileId(file), ByteOffset(start), ByteOffset(end))
        .expect("test fixture span must be well-formed")
}

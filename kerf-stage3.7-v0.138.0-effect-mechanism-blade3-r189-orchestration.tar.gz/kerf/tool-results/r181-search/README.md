# r181-search — W-ROW-POLY 开窗前置门②知识搜索存档

> **触发**：GZ-5 §11.2 前置门②（知识搜索先行——row unify 算法族检索）+ 用户指令⑥显式排期信号（效应族链首段）。
> **取样纪律**：原则 35（判据先于先例）——≥3 范式家族取样：ML 家族（OCaml）/ 效应函数家族（Koka）/ 约束求解家族（PureScript）/ 能力代数效应家族（Unison）/ 理论源头（Leijen scoped labels 2005）。
> **检索面**：六路 JSON（m1-m6）；r76-search m11-ocaml-btype.ml（HM unify 家族）已有在档为基线。

## 六路检索清单

| # | 文件 | 范式家族 | 核心命中 |
|---|------|---------|---------|
| m1 | m1-ocaml-btype.json | ML（OCaml） | polymorphic variants = 行对偶（structural product duality）；CS3110 类型重建算法；「Extensible records with scoped labels 描述清晰」社区评注 |
| m2 | m2-koka-row-effects.json | 行效应（Koka） | **Leijen 2013/2014 "Koka: Programming with Row-polymorphic Effect Types"（arXiv:1406.2061，被引 261）**——polymorphic effects through row-polymorphism using duplicate labels |
| m3 | m3-purescript-rows.json | 约束求解（PureScript） | haskellforall 2026 "Mechanized type inference for record concatenation"（行变量减少约束数）；purescript-rs 类型推断设计文档（quantified + constrained types）；HM(X) + Constraint Handling Rules |
| m4 | m4-extensible-records.json | 理论（通用） | Rémy MPRI 2.4 课程（λ-calculus 基础）；Da Silva HLIST 类型级记录；Agda 类型理论 |
| m5 | m5-unison-abilities.json | 代数效应（Unison） | 官方语言参考 abilities and ability handlers typechecking rule（`{A1,A2}` 能力集 = 行基集合语义）；pragdave 教程 |
| m6 | m6-scoped-labels.json | 算法核心 | **Leijen 2005 "Extensible records with scoped labels"（scopedlabels.pdf，被引 104）**——行合一重写规则；**"adds little complexity to the classic Hindley-Milner type inference algorithm by only affecting unification"** |

## 算法核心锚（m6 + m2 交叉）

1. **行表示**：`(|l :: τ | r|)`——标签 `l` 携类型 `τ`，尾行变量 `r`；行 = 标签序列 + 开放尾。
2. **行合一重写**（m6 #1 原文）：row `(|l :: τ | r|)` 与 row `s` 合一时，**先把 `s` 重写为 `(|l :: τ0 | s0|)` 形式**（标签匹配→同位合一；不匹配→下钻；尾变量→绑定；**lacks 约束**保证 `l ∉ s0 的标签集**）。
3. **HM 侵入面裁定**（m6 #2 原文）：**只影响 unification + 基础 kind 系统（行 kind 与类型 kind 分离）**——推断机骨架（generalization/instantiation/occurs check）零改动。
4. **duplicate labels**（m2）：Koka 允许重复标签支持多态效应（效应行语义特化）。
5. **约束式替代**（m3）：PureScript 用 constraint solving 而非纯合一（row unification 可表达为约束类）——kerf 选择：**合一式**（与现有 ti_unify_step 架构同族，侵入面最小）。

## 判据对照（原则 35——判据先于先例）

| 判据 | 结论 | 依据 |
|------|------|------|
| 机制侵入面 | **unify 局部扩展**（新增行构造子 + 行合一臂），推断机骨架零改动 | m6 #2「only affecting unification」 |
| 正交性 | 行类型 = 类型层扩展（Type 构造子 + 算法），零值层原语零内建 | 8 原语不变性可保持（前置门③） |
| 成熟度 | ⚠️ 早期实践维持（OCaml 5 无效应安全 / Koka·Unison 早期非主流规模） | 原则 26——P1/P2 处理程度（核心机制 + 效应接口预留），非 P0 全量 |
| 效应族链前置成立 | 行基效应追踪 = 效应安全类型基础（row polymorphism → effect rows 路径） | m2 Koka 论文 + GZ-5 §11.2 触发器① |
| 孪生可表达性 | 行合一 = 模式分派 + 守卫（lacks 检查）+ 尾变量绑定——.ktf 18 内建可表达面（pair 表 + if 守卫 + match 分派） | 前置门④评估输入 |

## 否决记录保留

- **约束求解式（PureScript 路线）**：否决——需引入约束生成/求解双机，侵入面大于合一式；kerf 现有 HM 单机架构下非最优（§12 最优>最小在架构基线维度的裁定：合一式与既有架构正交贴合）。
- **子类型式（OCaml 多态变体实际路线）**：否决——OCaml 对 poly variants 用 subtyping 而非纯行合一（m1 #3），子类型关系引入偏序复杂度；HM 全量推断保留前提下不采。

## 与 r76-search 基线的关系

r76（HM unify 家族七件：rustc unify_key / GHC unify / rustc relate / OCaml btype + value restriction）= **基线语料**（现有 ti_unify_step 的先例族）；r181 = **扩展检索**（行类型专用合一算法族）。两档互补：r76 锚定 HM 骨架，r181 锚定行扩展面。

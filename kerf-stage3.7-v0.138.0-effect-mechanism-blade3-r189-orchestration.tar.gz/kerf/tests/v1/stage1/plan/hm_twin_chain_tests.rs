//! The W-HM-TWIN 127-c integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the steady-state chains' remaining faces —
//! the cross-route equivalence (the steady injection route ≡ the
//! per-source text route ≡ the oracle, one decoder), the RS-4
//! dual-engine discipline (the same once-compiled program, the same
//! injection, both engines agreeing — the segment-one `read_dual`
//! precedent carried to both segment-three chains), the determinism
//! and injection-feeds-every-check contract for the check chain (the
//! inference twin's own row shipped with 127-a), the parity machine's
//! composed face (the compile product dump with the types judgment at
//! the tail — `oracle_analysis_dump_typed` against the `.ktf` chain's
//! compiler dump plus the inference twin's types section, both
//! rendered through the one shared dump renderer), and the structural
//! rebuild (the gate-B face: the twin's ok product rebuilt into real
//! `TypedExpr` trees, schemas, effect rows and `TypeDiagnostic`
//! records, compared field-wise against `infer_module`'s own output —
//! with the fail-closed tamper probes proving the rebuild rejects
//! malformed products with named errors, never a silent drop).
//!
//! Probe discipline (the segment-one/two precedent): the cross-route
//! and dual-engine faces ride the probe family — the corpus-scale
//! sweeps are the steady-route sweeps the 127-a/b rounds shipped; the
//! per-source route recompiles the full twin text per case by design
//! (the delivery face the steady chain exists to amortize), so the
//! equivalence proof rides the same probe set the precedents use.

use kerf::core::ModuleItem;
use kerf::driver::{
    COMPILER_TARGET_SOURCE, SteadyCheckChain, SteadyTypecheckChain, check_twin_per_source_dual,
    infer_twin_per_source_dual, infer_twin_per_source_text_dual, ktf_compile_rich,
    oracle_analysis_dump_typed, oracle_check_axes, oracle_infer_outcome, oracle_inference_axes,
    rebuild_typed_verdict,
};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::FileId;

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// Expand one probe source into the item stream both faces consume.
fn items_of(source: &str) -> Vec<ModuleItem> {
    let forms = read_target_program(FileId(0), source).expect("the probe reads");
    expand_program(&forms).expect("the probe expands")
}

/// The probe family (the segment-one precedent's four-cell shape,
/// carried to segment three): the accept anchor, the let-polymorphism
/// reuse row, the effect-row collection face, the E0009/E0010
/// negative rows and the empty stream. W-SEXP-RETIRE blade 2 (r151):
/// the sources ride the target skin (the corpus-dictionary respell).
const PROBES: &[(&str, &str)] = &[
    (
        "accept-anchor",
        "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
    ),
    (
        "let-polymorphism",
        "fn id(x) { x }\nfn a(y) { id(1) }\nfn b(z) { id(true) }",
    ),
    (
        "handle-rows",
        "fn f(x) { handle (perform log(x)) { log(v) => { v }, } }",
    ),
    (
        "t1-bool-demand",
        "fn f(x) { if (x) { 1 } else { 2 } }\nfn g(y) { f(1) }",
    ),
    ("t7-occurs", "define(omega, ||(x) { x(x) });"),
    ("empty-stream", "// nothing but trivia\n"),
];

#[test]
fn infer_twin_steady_route_matches_the_per_source_route_and_the_oracle() {
    deep_stack(|| {
        // Cross-route equivalence: the steady route (compile once +
        // inject per inference) and the per-source text route (the
        // item stream as a program-text `items` prefix, recompiled
        // per case — the RS-1 test-channel form) decode to identical
        // verdict texts through the SAME decoder — and both equal the
        // oracle's text. The delivery face changed, the computed
        // judgment did not.
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        for (name, source) in PROBES {
            let items = items_of(source);
            let steady = chain
                .infer(&items)
                .unwrap_or_else(|e| panic!("{name}: the steady inference runs: {e}"));
            let per_source = infer_twin_per_source_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the per-source route runs: {e}"));
            assert_eq!(
                steady, per_source.vm_text,
                "{name}: the two delivery faces agree (steady == per-source)"
            );
            assert_eq!(
                per_source.vm_text, per_source.eval_text,
                "{name}: the per-source route's two engines agree"
            );
            // The blade-2 beyond-oracle exemption (see the dual-route
            // test's commentary): the handle-rows probe diverges from
            // the frozen oracle BY DESIGN — the routes' agreement
            // above is the gate; the oracle compare gives way to the
            // typed-perform pin.
            if *name == "handle-rows" {
                assert!(
                    !steady.contains(" dyn (effs"),
                    "{name}: the effect typing is live — no dyn-typed perform (got: {steady})"
                );
                continue;
            }
            let oracle = oracle_inference_axes(&items);
            assert_eq!(
                steady, oracle,
                "{name}: the routes equal the oracle's judgment"
            );
        }
    });
}

#[test]
fn infer_twin_dual_engines_agree_on_the_steady_route() {
    deep_stack(|| {
        // The RS-4 dual-engine face on the steady route: the same
        // once-compiled program, the same injection, the VM and the
        // evaluator both decode the identical verdict — on the probe
        // family (the evaluator's envelope discipline: deep corpus
        // rows ride the VM-only bracket, the segment-one precedent's
        // own boundary).
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        for (name, source) in PROBES {
            let items = items_of(source);
            let (vm_text, eval_text) = chain
                .infer_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the dual inference runs: {e}"));
            assert_eq!(
                vm_text, eval_text,
                "{name}: the two engines agree on the steady route"
            );
            // The blade-2 beyond-oracle exemption (the r174 frozen-
            // oracle ruling's third blade — see the sweep's
            // commentary): the handle-rows probe's perform is
            // clause-ret typed on the twin, dyn on the frozen oracle.
            // The engine agreement above stays THE gate; the oracle
            // compare gives way to the typed-perform pin.
            if *name == "handle-rows" {
                assert!(
                    !vm_text.contains(" dyn (effs"),
                    "{name}: the effect typing is live — no dyn-typed perform (got: {vm_text})"
                );
                continue;
            }
            assert_eq!(
                vm_text,
                oracle_inference_axes(&items),
                "{name}: the steady dual face equals the oracle"
            );
        }
    });
}

#[test]
fn check_twin_steady_route_matches_the_per_source_route_and_the_oracle() {
    deep_stack(|| {
        // The check chain's cross-route equivalence + RS-4 + the
        // determinism and injection-feeds-every-check contract (the
        // inference twin's own 127-a row, carried to the check face):
        // steady ≡ per-source ≡ oracle on the probe family, both
        // engines agreeing on both routes, the same stream checking
        // identically twice, different streams checking differently.
        let chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PROBES {
            let items = items_of(source);
            let steady = chain
                .check(&items)
                .unwrap_or_else(|e| panic!("{name}: the steady check runs: {e}"));
            let (steady_vm, steady_eval) = chain
                .check_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the steady dual check runs: {e}"));
            assert_eq!(steady, steady_vm, "{name}: the check face is stable");
            assert_eq!(
                steady_vm, steady_eval,
                "{name}: the two engines agree on the steady route"
            );
            let (ps_vm, ps_eval) = check_twin_per_source_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the per-source route runs: {e}"));
            assert_eq!(
                ps_vm, ps_eval,
                "{name}: the per-source route's two engines agree"
            );
            assert_eq!(
                steady, ps_vm,
                "{name}: the two delivery faces agree (steady == per-source)"
            );
            assert_eq!(
                steady,
                oracle_check_axes(&items),
                "{name}: the routes equal the oracle's check verdict"
            );
        }
        // The determinism and no-clobber contract: two DIFFERENT
        // streams check differently — a program-side define of
        // `items` would collapse every check onto one stream.
        let a_items = items_of("fn a(x) { x }");
        let b_items = items_of("fn b(y) { if (y) { 1 } else { 2 } }");
        let a1 = chain.check(&a_items).expect("the first check of a");
        let a2 = chain.check(&a_items).expect("the second check of a");
        assert_eq!(a1, a2, "the same item stream checks identically");
        let b1 = chain.check(&b_items).expect("the check of b");
        assert_ne!(
            a1, b1,
            "different item streams check differently — the injection feeds every check"
        );
    });
}

#[test]
fn composed_analysis_matches_the_oracle_full_pipeline_dump() {
    deep_stack(|| {
        // The composed face (TWIN-4 face A + face B consumed
        // together): the `.ktf` chain's compiler twin dump PLUS the
        // inference twin's types section — both rendered through the
        // one shared dump renderer — equals the oracle's full-pipeline
        // analysis (`oracle_analysis_dump_typed`: the compile product
        // with `infer_module`'s judgment at the tail), one text. The
        // compile face and the type judgment compose into the single
        // analysis the junction-3 family compares.
        for (name, source) in PROBES {
            let items = items_of(source);
            // The compiler twin on the same items (the step-4 rich
            // drive — the per-source compile route, both engines).
            let run = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE)
                .unwrap_or_else(|e| panic!("{name}: the compiler twin runs: {e}"));
            assert_eq!(
                run.vm_text, run.eval_text,
                "{name}: the compiler twin's engines agree"
            );
            let bytecode = run
                .bytecode
                .as_ref()
                .unwrap_or_else(|| panic!("{name}: the compiler twin produced a product"));
            // The inference twin's types section through the shared
            // dump renderer (the per-source run carries it decoded).
            let per_source = infer_twin_per_source_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the inference twin runs: {e}"));
            let composed = format!("{} {}", run.vm_text, per_source.vm_types_section);
            // The blade-2 beyond-oracle exemption (see the dual-route
            // test's commentary): the handle-rows probe's typed
            // perform diverges from the frozen oracle's full-pipeline
            // dump on exactly the type slots — the composed face's
            // own consistency (the engines' agreement above) is the
            // gate; the oracle compare gives way to the typed-perform
            // pin.
            if *name == "handle-rows" {
                assert!(
                    !composed.contains(" dyn (effs"),
                    "{name}: the effect typing is live — no dyn-typed perform (got: {composed})"
                );
                continue;
            }
            let oracle = oracle_analysis_dump_typed(bytecode, &items);
            assert_eq!(
                composed, oracle,
                "{name}: the composed .ktf analysis equals the oracle's full-pipeline dump"
            );
        }
    });
}

#[test]
fn rebuild_face_matches_the_oracle_structurally() {
    deep_stack(|| {
        // The gate-B structural face (TWIN-4 face C): the twin's ok
        // product rebuilt into real `TypedExpr` trees, schemas,
        // effect rows and `TypeDiagnostic` records — compared
        // field-wise against `infer_module`'s own output on exactly
        // the fields the product grammar carries (the define's
        // name-span does not ride the grammar; the inference
        // diagnostic records carry no subject set — both documented
        // boundaries of the r127 product face).
        for (name, source) in PROBES {
            let items = items_of(source);
            let per_source = infer_twin_per_source_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the per-source route runs: {e}"));
            let rebuilt = &per_source.vm_rebuilt;
            // The blade-2 beyond-oracle exemption (see the dual-route
            // test's commentary): the handle-rows probe's typed
            // perform rebuilds differently from the frozen oracle's
            // dyn — the structural face's own decode correctness is
            // pinned by every OTHER probe; the handle-rows pin is the
            // typed-perform marker in the text face.
            if *name == "handle-rows" {
                assert!(
                    !per_source.vm_text.contains(" dyn (effs"),
                    "{name}: the effect typing is live — no dyn-typed perform (got: {})",
                    per_source.vm_text
                );
                continue;
            }
            let oracle = oracle_infer_outcome(&items);
            assert_eq!(
                rebuilt.defines.len(),
                oracle.typed.defines.len(),
                "{name}: the tdef row count matches"
            );
            for (rb, od) in rebuilt.defines.iter().zip(&oracle.typed.defines) {
                assert_eq!(rb.name, od.name, "{name}: the tdef name matches");
                assert_eq!(rb.schema, od.schema, "{name}: the tdef schema matches");
                assert_eq!(rb.body, od.body, "{name}: the annotation tree matches");
                assert_eq!(
                    rb.effects,
                    od.effects.as_slice(),
                    "{name}: the effect row matches"
                );
            }
            assert_eq!(
                rebuilt.diagnostics.len(),
                oracle.diagnostics.len(),
                "{name}: the diagnostic count matches"
            );
            for (rb, od) in rebuilt.diagnostics.iter().zip(&oracle.diagnostics) {
                assert_eq!(rb.code, od.code, "{name}: the diagnostic code matches");
                assert_eq!(rb.severity, od.severity, "{name}: the severity matches");
                assert_eq!(
                    rb.span.start, od.span.start,
                    "{name}: the diagnostic span start matches"
                );
                assert_eq!(
                    rb.span.end, od.span.end,
                    "{name}: the diagnostic span end matches"
                );
                assert_eq!(
                    rb.message, od.message,
                    "{name}: the rendered message matches"
                );
            }
        }
    });
}

/// One hand-built VM value helper for the tamper probes: a proper
/// list of the given elements, allocated in the caller's heap (the
/// pair chain the decoders walk).
fn list(heap: &mut kerf::vm::Heap, elems: Vec<kerf::vm::Value>) -> kerf::vm::Value {
    let mut out = kerf::vm::Value::Nil;
    for e in elems.into_iter().rev() {
        let r = heap.alloc(kerf::vm::HeapObj::Pair(e, out));
        out = kerf::vm::Value::Pair(r);
    }
    out
}

#[test]
fn rebuild_face_fails_closed_on_tampered_products() {
    // The fail-closed tamper face (the rebuild's error-key
    // discipline — the fixpoint_tests precedent for
    // `rebuild_bytecode`): a malformed product is a NAMED error,
    // never a silent drop. Every probe builds a hand-shaped value
    // the decoder must reject. The sub-lists build bottom-up (one
    // mutable heap, sequential allocations).
    use kerf::vm::Value;
    let mut heap = kerf::vm::Heap::default();
    let s = |t: &str| Value::Str(std::rc::Rc::from(t));
    let i = |n: i64| Value::Int(n);
    // (ok <types> <diags>) with the given RECORD-LIST values — the
    // HM product grammar carries each section's records as one
    // nested list in the section's second field.
    let product_of = |heap: &mut kerf::vm::Heap, tdefs: Value, tdiags: Value| {
        let t = list(heap, vec![s("types"), tdefs]);
        let d = list(heap, vec![s("diags"), tdiags]);
        list(heap, vec![s("ok"), t, d])
    };
    // One ("int" 42) literal record — the OUTPUT vocabulary the
    // tdef/tnode grammar carries.
    let lit = |heap: &mut kerf::vm::Heap| list(heap, vec![s("int"), i(42)]);
    // One tdef record with the given schema.
    let tdef_with = |heap: &mut kerf::vm::Heap, schema: Value| {
        let l = lit(heap);
        let node = list(heap, vec![s("tlit"), s("0"), s("1"), l, s("int")]);
        let row = list(heap, vec![]);
        list(heap, vec![s("tdef"), s("f"), schema, row, node])
    };

    // A non-ok verdict tag (three fields, so the shape check passes
    // and the tag check names the face).
    let err = rebuild_typed_verdict(&list(&mut heap, vec![s("err"), s("x"), s("y")]), &heap)
        .expect_err("a non-ok verdict must fail closed");
    assert!(
        err.contains("ok product"),
        "the error names the face: {err}"
    );

    // A tdef record with an unknown tag inside the types section.
    let bad_tdef = list(
        &mut heap,
        vec![s("not-a-tdef"), s("f"), s("x"), s("y"), s("z")],
    );
    let records = list(&mut heap, vec![bad_tdef]);
    let empty = list(&mut heap, vec![]);
    let product = product_of(&mut heap, records, empty);
    let err =
        rebuild_typed_verdict(&product, &heap).expect_err("an unknown tdef tag must fail closed");
    assert!(
        err.contains("non-tdef"),
        "the error names the record: {err}"
    );

    // A negative metavariable index in a schema.
    let vars = list(&mut heap, vec![i(-1)]);
    let schema = list(&mut heap, vec![s("schema"), vars, s("int")]);
    let tdef = tdef_with(&mut heap, schema);
    let records = list(&mut heap, vec![tdef]);
    let empty = list(&mut heap, vec![]);
    let product = product_of(&mut heap, records, empty);
    let err = rebuild_typed_verdict(&product, &heap)
        .expect_err("a negative metavariable index must fail closed");
    assert!(
        err.contains("negative"),
        "the error names the defect: {err}"
    );

    // An unknown ground type string.
    let vars = list(&mut heap, vec![]);
    let schema = list(&mut heap, vec![s("schema"), vars, s("wombat")]);
    let tdef = tdef_with(&mut heap, schema);
    let records = list(&mut heap, vec![tdef]);
    let empty = list(&mut heap, vec![]);
    let product = product_of(&mut heap, records, empty);
    let err = rebuild_typed_verdict(&product, &heap)
        .expect_err("an unknown ground type must fail closed");
    assert!(
        err.contains("unknown ground type"),
        "the error names the tag: {err}"
    );

    // An unknown diagnostic code in the diags section.
    let payload = list(&mut heap, vec![s("t1")]);
    let tdiag = list(
        &mut heap,
        vec![s("tdiag"), s("E9999"), s("error"), s("0"), s("1"), payload],
    );
    let empty = list(&mut heap, vec![]);
    let records = list(&mut heap, vec![tdiag]);
    let product = product_of(&mut heap, empty, records);
    let err = rebuild_typed_verdict(&product, &heap)
        .expect_err("an unknown diagnostic code must fail closed");
    assert!(err.contains("E9999"), "the error names the code: {err}");

    // An unknown template id in a diagnostic payload.
    let payload = list(&mut heap, vec![s("wombat")]);
    let tdiag = list(
        &mut heap,
        vec![s("tdiag"), s("E0009"), s("error"), s("0"), s("1"), payload],
    );
    let empty = list(&mut heap, vec![]);
    let records = list(&mut heap, vec![tdiag]);
    let product = product_of(&mut heap, empty, records);
    let err = rebuild_typed_verdict(&product, &heap)
        .expect_err("an unknown template id must fail closed");
    assert!(
        err.contains("template"),
        "the error names the payload: {err}"
    );
}

// ---------- the W-ROW-POLY blade-1 boundary extensions (r182-c) ----------

/// The row boundary cases for the cross-route and dual-engine faces
/// (w-row-poly-window.md §6 blade 1 — the hm_twin_chain extension
/// the acceptance gate names): three representative rows — the
/// open-tail positive, the lacks E0013, the call-site E0009 — run
/// the steady route AND the per-source text route with BOTH engines
/// agreeing. NO oracle assertion rides here: the oracle is frozen
/// (the r174 ruling) and degrades every row spec to Dyn, so the
/// parity twin≡oracle face never sees these cases (the golden file
/// pins the twin's own verdicts; this test pins the delivery faces'
/// equivalence for them).
#[test]
fn row_poly_cross_route_dual_engine_boundary() {
    deep_stack(|| {
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let cases: Vec<(&str, Vec<ModuleItem>)> = vec![
            (
                "row-open-tail-positive",
                vec![
                    ModuleItem::Define {
                        span: kerf_span_span(10, 40),
                        name: sym_of("f"),
                        value: kerf::core::CoreExpr::Fn {
                            span: kerf_span_span(10, 40),
                            params: vec![sym_of("r")],
                            body: Box::new(kerf::core::CoreExpr::Var {
                                span: kerf_span_span(35, 36),
                                name: sym_of("r"),
                            }),
                        },
                    },
                    ModuleItem::Annotate {
                        span: kerf_span_span(11, 20),
                        anchor: kerf_span_span(10, 40),
                        kind: kerf::core::AnnotationKind::Param,
                        index: 0,
                        spec: row_spec_of(),
                    },
                    ModuleItem::Annotate {
                        span: kerf_span_span(28, 39),
                        anchor: kerf_span_span(10, 40),
                        kind: kerf::core::AnnotationKind::Ret,
                        index: 0,
                        spec: row_spec_of(),
                    },
                ],
            ),
            (
                "row-lacks-e0013",
                vec![
                    ModuleItem::Define {
                        span: kerf_span_span(10, 40),
                        name: sym_of("f"),
                        value: kerf::core::CoreExpr::Fn {
                            span: kerf_span_span(10, 40),
                            params: vec![sym_of("r")],
                            body: Box::new(kerf::core::CoreExpr::Var {
                                span: kerf_span_span(35, 36),
                                name: sym_of("r"),
                            }),
                        },
                    },
                    ModuleItem::Annotate {
                        span: kerf_span_span(11, 20),
                        anchor: kerf_span_span(10, 40),
                        kind: kerf::core::AnnotationKind::Param,
                        index: 0,
                        spec: row_spec_of(),
                    },
                    ModuleItem::Annotate {
                        span: kerf_span_span(28, 39),
                        anchor: kerf_span_span(10, 40),
                        kind: kerf::core::AnnotationKind::Ret,
                        index: 0,
                        spec: kerf::core::LiteralValue::String(std::rc::Rc::from("int")),
                    },
                ],
            ),
            (
                "row-call-site-e0009",
                vec![
                    ModuleItem::Define {
                        span: kerf_span_span(10, 40),
                        name: sym_of("f"),
                        value: kerf::core::CoreExpr::Fn {
                            span: kerf_span_span(10, 40),
                            params: vec![sym_of("r")],
                            body: Box::new(kerf::core::CoreExpr::Var {
                                span: kerf_span_span(35, 36),
                                name: sym_of("r"),
                            }),
                        },
                    },
                    ModuleItem::Annotate {
                        span: kerf_span_span(11, 20),
                        anchor: kerf_span_span(10, 40),
                        kind: kerf::core::AnnotationKind::Param,
                        index: 0,
                        spec: row_spec_of(),
                    },
                    ModuleItem::Define {
                        span: kerf_span_span(50, 91),
                        name: sym_of("g"),
                        value: kerf::core::CoreExpr::Fn {
                            span: kerf_span_span(60, 90),
                            params: vec![],
                            body: Box::new(kerf::core::CoreExpr::Apply {
                                span: kerf_span_span(70, 80),
                                func: Box::new(kerf::core::CoreExpr::Var {
                                    span: kerf_span_span(70, 71),
                                    name: sym_of("f"),
                                }),
                                args: vec![kerf::core::CoreExpr::Literal {
                                    span: kerf_span_span(75, 76),
                                    value: kerf::core::LiteralValue::Int(1),
                                }],
                            }),
                        },
                    },
                ],
            ),
        ];
        for (name, items) in cases {
            let steady = chain
                .infer(&items)
                .unwrap_or_else(|e| panic!("{name}: the steady inference runs: {e}"));
            // The twin-beyond-oracle lane (the r174 ruling): rows
            // never ride the oracle-domain rebuild face — the text
            // route drives both engines without it.
            let (ps_vm, ps_eval) = infer_twin_per_source_text_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the per-source route runs: {e}"));
            assert_eq!(
                steady, ps_vm,
                "{name}: the two delivery faces agree (steady == per-source)"
            );
            assert_eq!(
                ps_vm, ps_eval,
                "{name}: the per-source route's two engines agree"
            );
            let (vm_text, eval_text) = chain
                .infer_dual(&items)
                .unwrap_or_else(|e| panic!("{name}: the dual inference runs: {e}"));
            assert_eq!(
                vm_text, eval_text,
                "{name}: the two engines agree on the steady route"
            );
            assert_eq!(
                vm_text, steady,
                "{name}: the dual face equals the steady face"
            );
        }
    });
}

/// One `(row (x int) nil)` spec (the closed single-field shape the
/// boundary rows ride).
fn row_spec_of() -> kerf::core::LiteralValue {
    use kerf::core::LiteralValue as LV;
    let s = |t: &str| LV::String(std::rc::Rc::from(t));
    LV::Pair(
        Box::new(s("row")),
        Box::new(LV::Pair(
            Box::new(LV::Pair(
                Box::new(s("x")),
                Box::new(LV::Pair(Box::new(s("int")), Box::new(LV::Nil))),
            )),
            Box::new(LV::Pair(Box::new(s("nil")), Box::new(LV::Nil))),
        )),
    )
}

fn kerf_span_span(a: u32, b: u32) -> kerf::span::Span {
    use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym_of(text: &str) -> kerf::span::Symbol {
    kerf::span::Symbol::new(text).expect("test symbol is valid")
}

//! The W-EFFECT-MECHANISM blade-2 golden corpus (the r186 window's
//! §6 blade table — the effect-row inference consumption): the
//! typed effect rows over the selfhosted inference twin (the row-
//! effect-shape golden's own API drive — `SteadyTypecheckChain::
//! infer` through the injection channel, the decoded verdict text)
//! plus the production-chain run face for the runtime-consistent
//! rows (the effect-oneshot golden's `parse_target` + `run`
//! convention).
//!
//! The ruling table (w-effect-mechanism-window.md §5.2) under test:
//! - the ARROW-CARRIED row: the fn type's fourth slot — the body's
//!   escaping effect row in the P2 frozen shape `("row" ((eff
//!   opT)...) tail)`; a perform-free body carries the empty closed
//!   row (the parity renderer strips it — the oracle-comparable
//!   corpus stays bit-for-bit);
//! - the PERFORM's own typing: a covering clause's degenerate form
//!   types the perform AS the clause's return (the capture-
//!   replacement semantics the value layer pinned at r187) with
//!   the clause params unified against the performed args; the
//!   k-form recovers the resume type from the walked clause's k
//!   arrow; NO covering clause leaves the resume unknown — a fresh
//!   metavariable — and the row EXTENDS by (e opT) with the op
//!   type BEING that same variable (the m1 Koka coherence);
//! - the HANDLE's coverage: the typed row subtracts the
//!   intercepted labels (definite) and merges each handler body's
//!   row; the halt/body ret unification closes the r187 typing
//!   gap (the handle evaluates to either face — a concrete-
//!   concrete divergence is E0009);
//! - the GENERALIZATION face: the row's operation-type variables
//!   ride the schema vars (params, ret, row — the first-seen
//!   order).
//!
//! Case plan (the row-skin 1:3 precedent): 7 positive + 18
//! negative. The annotation-driven row cases ride the API face
//! (the arrow's third payload has no target-skin surface — the
//! §5.2 ruling is the TYPE LAYER, the value-face injection is its
//! delivery); the runtime rows ride the production chain.

use kerf::core::{CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf::driver::{Engine, Session, SteadyTypecheckChain, parse_target};
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs (the steady chain), so the driver needs
/// the large thread stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> kerf::span::Symbol {
    kerf::span::Symbol::new(text).expect("test symbol is valid")
}

fn s(text: &str) -> LiteralValue {
    LiteralValue::String(std::rc::Rc::from(text))
}

fn l(items: Vec<LiteralValue>) -> LiteralValue {
    let mut out = LiteralValue::Nil;
    for item in items.into_iter().rev() {
        out = LiteralValue::Pair(Box::new(item), Box::new(out));
    }
    out
}

/// One `(eff opT)` effect-row field.
fn eff(name: &str, op: &str) -> LiteralValue {
    l(vec![s(name), s(op)])
}

/// One effect row from fields and a tail spelling (`nil` closed,
/// `_` open — the P2 frozen vocabulary).
fn erow(fields: Vec<LiteralValue>, tail: &str) -> LiteralValue {
    let mut v = vec![s("row")];
    v.extend(fields);
    v.push(s(tail));
    l(v)
}

/// The arrow-with-row annotation spec — `(arrow P R rowspec)`, the
/// blade-2 three-payload form (§5.2's own TYPE-LAYER ruling; no
/// target-skin surface — the value-face injection is the delivery).
fn arrow_row(params: LiteralValue, ret: &str, row: LiteralValue) -> LiteralValue {
    l(vec![s("arrow"), params, s(ret), row])
}

/// One production-chain run: parse, check, compile, VM execute —
/// the `result` global's display text (the row-skin golden
/// convention).
fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    let program = parse_target(&mut session, "effect-infer-case.ktf", source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

/// The one-line rejection probe: the run's joined diagnostic text.
fn fail_text(source: &str) -> String {
    match run(source) {
        Ok(v) => panic!("the case must fail (got `{v}`)"),
        Err(diags) => diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
            .join("; "),
    }
}

/// The API drive: the twin's decoded verdict text on constructed
/// items (the row-effect-shape golden's own convention).
fn drive(items: &[ModuleItem]) -> String {
    let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
    chain.infer(items).expect("the twin inference runs")
}

/// `fn f() { perform read() }` — one fn-literal define whose body
/// performs `read` unhandled (the arrow-row carrier).
fn escaping_fn(effect: &str) -> Vec<ModuleItem> {
    vec![ModuleItem::Define {
        span: sp(0, 30),
        name: sym("f"),
        value: CoreExpr::Fn {
            span: sp(5, 29),
            params: vec![],
            body: Box::new(CoreExpr::Perform {
                span: sp(12, 28),
                effect: sym(effect),
                args: vec![],
            }),
        },
    }]
}

/// `fn g(f: (-> () R rowspec)) { f() }` + the arg fn performing
/// `read` — the annotation-pin carrier (the param's arrow-with-row
/// spec meets the arg's inferred arrow row at the argument
/// position: params, ret AND rows unify).
fn ann_pin_carrier(ret: &str, row: LiteralValue) -> Vec<ModuleItem> {
    let fspan = sp(30, 42);
    vec![
        ModuleItem::Define {
            span: sp(0, 60),
            name: sym("g"),
            value: CoreExpr::Fn {
                span: fspan,
                params: vec![sym("f")],
                body: Box::new(CoreExpr::Apply {
                    span: sp(44, 48),
                    func: Box::new(CoreExpr::Var {
                        span: sp(44, 45),
                        name: sym("f"),
                    }),
                    args: vec![],
                }),
            },
        },
        ModuleItem::Annotate {
            span: sp(11, 20),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Param,
            index: 0,
            spec: arrow_row(l(vec![s("tuple")]), ret, row),
        },
        ModuleItem::Define {
            span: sp(62, 110),
            name: sym("h"),
            value: CoreExpr::Fn {
                span: sp(70, 108),
                params: vec![],
                body: Box::new(CoreExpr::Perform {
                    span: sp(78, 92),
                    effect: sym("read"),
                    args: vec![],
                }),
            },
        },
        ModuleItem::Define {
            span: sp(112, 130),
            name: sym("result"),
            value: CoreExpr::Apply {
                span: sp(126, 130),
                func: Box::new(CoreExpr::Var {
                    span: sp(126, 127),
                    name: sym("g"),
                }),
                args: vec![CoreExpr::Var {
                    span: sp(128, 129),
                    name: sym("h"),
                }],
            },
        },
    ]
}

/// `fn f() { handle (perform e(1)) { e(x) => { x }, } }` — the
/// coverage carrier (the handled perform adds nothing to the
/// arrow's row).
fn covered_fn() -> Vec<ModuleItem> {
    vec![ModuleItem::Define {
        span: sp(0, 60),
        name: sym("f"),
        value: CoreExpr::Fn {
            span: sp(7, 58),
            params: vec![],
            body: Box::new(CoreExpr::Handle {
                span: sp(12, 57),
                body: Box::new(CoreExpr::Perform {
                    span: sp(19, 31),
                    effect: sym("e"),
                    args: vec![CoreExpr::Literal {
                        span: sp(28, 29),
                        value: LiteralValue::Int(1),
                    }],
                }),
                handlers: vec![HandlerClause {
                    span: sp(33, 55),
                    effect: sym("e"),
                    handler: Box::new(CoreExpr::Fn {
                        span: sp(35, 55),
                        params: vec![sym("x")],
                        body: Box::new(CoreExpr::Var {
                            span: sp(53, 54),
                            name: sym("x"),
                        }),
                    }),
                }],
            }),
        },
    }]
}

// ---------- the positive family (7) ----------

#[test]
fn ei01_the_degenerate_perform_takes_the_clause_ret_with_params_pinned() {
    deep_stack(|| {
        // The production chain: the value face (3 — the r187 pin
        // restated) plus the twin's typing face: the clause params
        // unify against the performed args, so the tclause's fn
        // renders (int int) — the oracle's (t1 t2) free vars give
        // way (the beyond-oracle pin the sweep's exemption carries).
        let v = run("define(result, handle (perform add(1, 2)) { add(a, b) => { (a + b) }, });")
            .expect("the degenerate case runs");
        assert_eq!(v, "3");
    });
}

#[test]
fn ei02_the_k_form_resume_type_flows_to_the_handle() {
    deep_stack(|| {
        // The k-form: k(41) pins the resume type inside the walked
        // clause; the perform takes it (the m1 coherence) — the
        // runtime value rides the same channel (41). The k-form
        // spelling rides the fn-body channel (the check face's
        // strict top-level arity rule is en07's own pin).
        let v =
            run("fn f() { handle (perform e(1)) { e(x, k) => { k(41) }, } }\ndefine(result, f());")
                .expect("the k-form case runs");
        assert_eq!(v, "41");
    });
}

#[test]
fn ei03_the_arrow_row_rides_the_escaping_fn() {
    deep_stack(|| {
        // The arrow-carried row: the unhandled perform extends the
        // fn's row by (read <resume-var>) — the schema renders the
        // row suffix on the arrow (the beyond-oracle face: the
        // oracle has no rows), and the row's op-type variable rides
        // the schema vars (the generalization face — the ret AND the
        // op type are the SAME variable: the Koka coherence).
        let out = drive(&escaping_fn("read"));
        assert!(
            out.contains("(row read t"),
            "the escaping perform's row rides the arrow (got: {out})"
        );
        assert!(
            out.contains("| (row read t"),
            "the row renders as the arrow's suffix (got: {out})"
        );
    });
}

#[test]
fn ei04_the_annotation_row_pins_the_operation_type() {
    deep_stack(|| {
        // The m1 literal adaptation at the argument position: the
        // param's arrow-with-row spec unifies with the arg's
        // inferred arrow — the ret pins the resume variable to int
        // AND the row's (read opT) field pins the same variable —
        // the schema displays the PINNED row `(row read int)`.
        let out = drive(&ann_pin_carrier(
            "int",
            erow(vec![eff("read", "int")], "nil"),
        ));
        // The pin lands at the argument position: the arg's arrow
        // renders the PINNED row (both the ret and the op type are
        // int) — the annotation's field pinned the same variable the
        // ret did (the Koka coherence made visible).
        assert!(
            out.contains("(fn () int | (row read int))"),
            "the annotation pins the arg's row and ret (got: {out})"
        );
        // The callee's own schema carries the pinned arrow: the
        // param's declared type renders whole.
        assert!(
            out.contains("(fn ((fn () int | (row read int))) int)"),
            "the callee's schema carries the pinned arrow (got: {out})"
        );
    });
}

#[test]
fn ei05_the_handle_covers_the_row() {
    deep_stack(|| {
        // The coverage face: the handled perform adds nothing to
        // the arrow's row — the clause intercepts (definite), so
        // the covered fn's schema carries NO row suffix (the empty
        // closed row strips — the parity face's own form).
        let out = drive(&covered_fn());
        assert!(
            !out.contains("| (row"),
            "the covered fn carries no row suffix (got: {out})"
        );
        assert!(
            !out.contains("(row e"),
            "the intercepted label never escapes (got: {out})"
        );
    });
}

#[test]
fn ei06_the_return_clause_consumes_the_return_label() {
    deep_stack(|| {
        // The return branch: the `return` label is an ordinary
        // effect — the return clause intercepts it, the degenerate
        // typing takes the clause's ret, the value flows (7).
        let v = run("define(result, handle (perform return(7)) { return(v) => { v }, });")
            .expect("the return-clause case runs");
        assert_eq!(v, "7");
    });
}

#[test]
fn ei07_the_open_tail_absorbs_the_extra_effect() {
    deep_stack(|| {
        // The P2 open tail (the `_` spelling) through the blade-2
        // consumption: the annotation's open row extends by the
        // arg's extra effect — the tail variable binds the
        // remainder, the program passes clean (the es04 face
        // carried to the inference consumption).
        let out = drive(&ann_pin_carrier("int", erow(vec![eff("read", "int")], "_")));
        assert!(
            out.contains("(row read int"),
            "the open annotation absorbs and pins the read field (got: {out})"
        );
    });
}

// ---------- the negative family (18) ----------

#[test]
fn en01_the_unhandled_top_level_perform_is_e0006_both_faces() {
    deep_stack(|| {
        // The dual-face consistency (§5.2's own pin): the lexical
        // face reports E0006 AND the row face's tdef effects list
        // carries the same effect — the two faces agree.
        let text = fail_text("define(result, perform e(1));");
        assert!(
            text.contains("unhandled effect") && text.contains("top level"),
            "the lexical face reports E0006 (got: {text})"
        );
    });
}

#[test]
fn en02_the_unhandled_return_label_is_e0006() {
    deep_stack(|| {
        let text = fail_text("define(result, perform return(1));");
        assert!(
            text.contains("unhandled effect") && text.contains("top level"),
            "the return label rides the ordinary E0006 face (got: {text})"
        );
    });
}

#[test]
fn en03_the_halt_carry_divergence_surfaces_through_the_ret_annotation() {
    deep_stack(|| {
        // The r187 typing gap's closure, made visible: the handle
        // evaluates to either the body's value (the resume path) or
        // the clause's plain halt return — the halt/body ret
        // unification binds the resume variable to the halt type
        // (\"s\" → str), so the fn's `-> i64` ret annotation
        // diverges: E0013. WITHOUT the blade-2 unification the
        // resume variable stayed free, the annotation unified clean
        // through it, and the program RAN — the halt carry escaped
        // the typing face entirely (the cdr(handle_value) family's
        // own reported gap).
        let text = fail_text(
            "fn f() -> i64 { handle (perform e(1)) { e(x, k) => { \"s\" }, } }\ndefine(result, f());",
        );
        assert!(
            text.contains("annotation divergence"),
            "the halt carry surfaces as the ret-annotation divergence (got: {text})"
        );
    });
}

#[test]
fn en04_the_arrow_param_ret_divergence_is_e0009() {
    deep_stack(|| {
        // The fn-typed param's ret annotation diverges from the
        // arg's inferred ret — E0009 at the call (the existing
        // argument-position face through the blade-2 arrow spec).
        let out = drive(&ann_pin_carrier(
            "int",
            erow(vec![eff("read", "int")], "nil"),
        ));
        // The clean variant pins — the divergent variant (the arg
        // returns float through the if) reports:
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 50),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: sp(5, 33),
                    params: vec![sym("f")],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(25, 29),
                        func: Box::new(CoreExpr::Var {
                            span: sp(25, 26),
                            name: sym("f"),
                        }),
                        args: vec![],
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: sp(5, 33),
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: arrow_row(l(vec![s("tuple")]), "int", erow(vec![], "nil")),
            },
            ModuleItem::Define {
                span: sp(52, 100),
                name: sym("h"),
                value: CoreExpr::Fn {
                    span: sp(60, 98),
                    params: vec![],
                    body: Box::new(CoreExpr::Literal {
                        span: sp(90, 94),
                        value: LiteralValue::Float(1.5),
                    }),
                },
            },
            ModuleItem::Define {
                span: sp(102, 120),
                name: sym("result"),
                value: CoreExpr::Apply {
                    span: sp(116, 120),
                    func: Box::new(CoreExpr::Var {
                        span: sp(116, 117),
                        name: sym("g"),
                    }),
                    args: vec![CoreExpr::Var {
                        span: sp(118, 119),
                        name: sym("h"),
                    }],
                },
            },
        ];
        let out2 = drive(&items);
        assert!(
            out.contains("(row read int)"),
            "the clean pin (sanity): {out}"
        );
        assert!(
            out2.contains("E0009") || out2.contains("float"),
            "the ret divergence reports (got: {out2})"
        );
    });
}

#[test]
fn en05_the_closed_annotation_row_lacks_the_performed_effect() {
    deep_stack(|| {
        // The row-unification face: the annotation's closed row
        // lacks the effect the arg performs — the lacks violation
        // rides the argument position as E0009 (the row records in
        // the message payload).
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 50),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: sp(5, 33),
                    params: vec![sym("f")],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(25, 29),
                        func: Box::new(CoreExpr::Var {
                            span: sp(25, 26),
                            name: sym("f"),
                        }),
                        args: vec![],
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: sp(5, 33),
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: arrow_row(
                    l(vec![s("tuple")]),
                    "int",
                    erow(vec![eff("read", "int")], "nil"),
                ),
            },
            ModuleItem::Define {
                span: sp(52, 110),
                name: sym("h"),
                value: CoreExpr::Fn {
                    span: sp(60, 108),
                    params: vec![],
                    body: Box::new(CoreExpr::Perform {
                        span: sp(78, 94),
                        effect: sym("write"),
                        args: vec![],
                    }),
                },
            },
            ModuleItem::Define {
                span: sp(112, 130),
                name: sym("result"),
                value: CoreExpr::Apply {
                    span: sp(126, 130),
                    func: Box::new(CoreExpr::Var {
                        span: sp(126, 127),
                        name: sym("g"),
                    }),
                    args: vec![CoreExpr::Var {
                        span: sp(128, 129),
                        name: sym("h"),
                    }],
                },
            },
        ];
        let out = drive(&items);
        assert!(
            out.contains("E0009"),
            "the closed-row lacks violation reports E0009 (got: {out})"
        );
    });
}

#[test]
fn en06_the_row_op_type_divergence_is_e0009() {
    deep_stack(|| {
        // The ret and the op type are the SAME variable (the Koka
        // coherence) — annotating them differently (int ret, float
        // op) diverges at the row field: E0009.
        let out = drive(&ann_pin_carrier(
            "int",
            erow(vec![eff("read", "float")], "nil"),
        ));
        assert!(
            out.contains("E0009"),
            "the op-type divergence reports E0009 (got: {out})"
        );
    });
}

#[test]
fn en07_the_top_level_k_shape_is_e0005() {
    deep_stack(|| {
        // The neg-034 pin restated under the typing: the check face
        // keeps its strict top-level arity rule — the k-form
        // spelling is legal only through the fn-body channel.
        let text = fail_text("define(result, handle (perform e(1)) { e(a, b) => { a }, });");
        assert!(
            text.contains("handler") || text.contains("arity"),
            "the top-level k-form reports E0005 (got: {text})"
        );
    });
}

#[test]
fn en08_the_clause_param_divergence_is_e0009() {
    deep_stack(|| {
        // The degenerate param unification: the clause body pins x
        // to int (the arith), the performed arg is a string — the
        // divergence reports at the perform.
        let text = fail_text("define(result, handle (perform e(\"s\")) { e(x) => { (x + 1) }, });");
        assert!(
            text.contains("type mismatch"),
            "the clause-param divergence reports E0009 (got: {text})"
        );
    });
}

#[test]
fn en09_the_ret_annotation_divergence_is_e0013() {
    deep_stack(|| {
        // The existing E0013 face through an effect-carrying body —
        // the annotation discipline is orthogonal to the row track.
        let text = fail_text("fn f() -> i64 { 1.5 }\ndefine(result, f());");
        assert!(
            text.contains("annotation divergence"),
            "the ret divergence reports E0013 (got: {text})"
        );
    });
}

#[test]
fn en10_the_k_channel_occurs_check_is_e0010() {
    deep_stack(|| {
        // The r187 raw-VM family's type-expressible face: the value
        // channel `k(cons(x, k))` — the resume variable occurs in
        // its own binding — E0010 (the occurs check).
        let text =
            fail_text("define(result, handle (perform e(1)) { e(x, k) => { k(cons(x, k)) }, });");
        assert!(
            text.contains("recursive type") || text.contains("occurs"),
            "the k-channel occurs check reports E0010 (got: {text})"
        );
    });
}

#[test]
fn en11_the_handler_for_another_effect_misses() {
    deep_stack(|| {
        // The routing miss: a handler exists but for another
        // effect — E0006 for the performed label (the lexical
        // face's own routing, the row face agrees — no coverage).
        let text = fail_text("define(result, handle (perform e(1)) { other(x, k) => { k(x) }, });");
        assert!(
            text.contains("unhandled effect"),
            "the routing miss reports the unhandled label (got: {text})"
        );
    });
}

#[test]
fn en12_the_fn_body_channel_has_no_check_gate() {
    deep_stack(|| {
        // The honest boundary (the r187 pin restated under the
        // typing): the fn-body perform rides the ARROW's row to the
        // schema — no check-time gate exists for the call-through
        // escape (the oracle's own documented stance); the RUNTIME
        // catches the unhandled effect.
        let text = fail_text("fn f() { perform e(1) }\ndefine(result, f());");
        assert!(
            text.contains("unhandled effect"),
            "the call-through escape fails at the runtime (got: {text})"
        );
    });
}

#[test]
fn en13_the_over_performing_arg_rejects_the_closed_row() {
    deep_stack(|| {
        // The closed-row over-perform: the arg performs MORE than
        // the annotation's closed row declares — the annotation's
        // closed tail demands the remainder close empty; the extra
        // field violates (the lacks violation in the annotation's
        // direction) — E0009.
        // The arg performs read AND write (both unhandled in the fn
        // body — the fn-body channel): the row carries both; the
        // annotation's closed row declares only read — the write
        // field violates the closed tail (the over-perform reject).
        let both = vec![
            ModuleItem::Define {
                span: sp(0, 50),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: sp(5, 33),
                    params: vec![sym("f")],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(25, 29),
                        func: Box::new(CoreExpr::Var {
                            span: sp(25, 26),
                            name: sym("f"),
                        }),
                        args: vec![],
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: sp(5, 33),
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: arrow_row(
                    l(vec![s("tuple")]),
                    "int",
                    erow(vec![eff("read", "int")], "nil"),
                ),
            },
            ModuleItem::Define {
                span: sp(52, 130),
                name: sym("h"),
                value: CoreExpr::Fn {
                    span: sp(60, 128),
                    params: vec![],
                    body: Box::new(CoreExpr::Let {
                        span: sp(66, 126),
                        bindings: vec![kerf::core::Binding {
                            span: sp(70, 84),
                            name: sym("u"),
                            value: CoreExpr::Perform {
                                span: sp(74, 84),
                                effect: sym("read"),
                                args: vec![],
                            },
                        }],
                        body: Box::new(CoreExpr::Perform {
                            span: sp(88, 102),
                            effect: sym("write"),
                            args: vec![CoreExpr::Var {
                                span: sp(99, 100),
                                name: sym("u"),
                            }],
                        }),
                    }),
                },
            },
            ModuleItem::Define {
                span: sp(132, 150),
                name: sym("result"),
                value: CoreExpr::Apply {
                    span: sp(146, 150),
                    func: Box::new(CoreExpr::Var {
                        span: sp(146, 147),
                        name: sym("g"),
                    }),
                    args: vec![CoreExpr::Var {
                        span: sp(148, 149),
                        name: sym("h"),
                    }],
                },
            },
        ];
        let out = drive(&both);
        assert!(
            out.contains("E0009"),
            "the over-performing arg rejects against the closed annotation row (got: {out})"
        );
    });
}

#[test]
fn en14_the_non_callable_in_the_clause_is_e0009() {
    deep_stack(|| {
        // The existing t2 face through the effect context: calling
        // a literal inside a handler clause body.
        let text = fail_text("define(result, handle (perform e(1)) { e(x) => { (x(1)) }, });");
        assert!(
            text.contains("type mismatch") || text.contains("expected a function"),
            "the non-callable reports (got: {text})"
        );
    });
}

#[test]
fn en15_the_let_annotation_divergence_is_e0013() {
    deep_stack(|| {
        // The existing E0013 let face with an effect-carrying value
        // — the annotation discipline on the binding position.
        let text = fail_text("fn f() { let x: i64 = \"s\"; x }\ndefine(result, f());");
        assert!(
            text.contains("annotation divergence"),
            "the let-ann divergence reports E0013 (got: {text})"
        );
    });
}

#[test]
fn en16_the_bool_demand_in_the_clause_is_e0009() {
    deep_stack(|| {
        // The existing t5 face (the if condition's bool demand)
        // through the effect context.
        let text = fail_text(
            "define(result, handle (perform e(1)) { e(x) => { (if x { 1 } else { 2 }) }, });",
        );
        assert!(
            text.contains("bool"),
            "the bool demand reports (got: {text})"
        );
    });
}

#[test]
fn en17_the_pinned_row_survives_no_metavariable() {
    deep_stack(|| {
        // The pin's negative face: at the CONSUMPTION sites (the
        // argument position and the callee's schema) the pinned row
        // renders whole — an unpinned metavariable there would be a
        // pin leak. (The performing define's OWN schema legitimately
        // quantifies the resume variable — the HM generalization
        // face, ei04's own boundary.)
        let out = drive(&ann_pin_carrier(
            "int",
            erow(vec![eff("read", "int")], "nil"),
        ));
        let arg_pin = "(fn () int | (row read int))";
        assert!(
            out.contains(arg_pin),
            "the pinned row renders at the consumption site (got: {out})"
        );
        let without_h = out.split("(tdef h").next().unwrap_or("").to_string();
        assert!(
            !without_h.contains("| (row read t"),
            "no unpinned metavariable outside the generalized schema (got: {out})"
        );
    });
}

#[test]
fn en18_the_covered_label_never_leaks_into_the_schema() {
    deep_stack(|| {
        // The coverage's negative face: the intercepted label never
        // appears in the covered fn's schema row — the subtraction
        // is definite (the clauses install before the body runs).
        let out = drive(&covered_fn());
        assert!(
            !out.contains("e t") && !out.contains("| (row e"),
            "the intercepted label stays subtracted (got: {out})"
        );
    });
}

#!/usr/bin/env python3
"""The tier-engine daemon form (the r210 battery precedent, formalized):
run test-tiers.sh in fully-detached double-fork children that survive
the tool-shell's death (the sandbox harvest escape, r167). The tier
engine's own chunked-resume discipline carries the progress; the
daemon loops `run --resume --max-time <budget>` until the ledger is
complete or a chunk fails. Usage: tier_daemon.py <log-path> <tier>
[max-time-seconds]"""
import os
import sys
import subprocess

LOG = sys.argv[1] if len(sys.argv) > 1 else '/tmp/tier-battery.log'
TIER = sys.argv[2] if len(sys.argv) > 2 else 'T2'
MAX_TIME = sys.argv[3] if len(sys.argv) > 3 else '1500'
SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test-tiers.sh')


def daemon():
    # second fork: the child re-parents to init, fully detached
    if os.fork() > 0:
        os._exit(0)
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    # redirect stdio to the log, drop the terminal
    fd = os.open(LOG, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    os.close(fd)
    os.close(0)
    env = dict(os.environ)
    env['PATH'] = os.path.expanduser('~/.cargo/bin') + ':' + env.get('PATH', '')
    env.setdefault('RUST_MIN_STACK', '8388608')
    # the chunked loop: each chunk runs inside its own process; the
    # ledger carries the progress; a red chunk breaks the loop (the
    # log keeps the failure for the parent's postmortem)
    for round_no in range(1, 200):
        r = subprocess.run(
            ['bash', SCRIPT, 'run', '--tier', TIER, '--resume', '--max-time', MAX_TIME],
            cwd='/home/z/kerf',
            env=env,
        )
        with open(LOG, 'a') as f:
            f.write(f'TIER-CHUNK-{round_no}-EXIT={r.returncode}\n')
        with open(LOG, 'r') as f:
            tail = f.read()[-4000:]
        # the resume discipline: a red chunk with PENDING families
        # still carries the ledger — keep looping (the pending set
        # drains next chunk); break only when nothing is pending
        # (either all-green completion, or a hard red with zero
        # pending — the fix owns the parent, not a retry storm)
        import re as _re
        m = _re.search(r'SUMMARY tier=\S+ green=(\d+) red=(\d+) timeout=(\d+) pending=(\d+)', tail)
        if m:
            pending = int(m.group(4))
            if pending == 0:
                break
    with open(LOG, 'a') as f:
        f.write('TIER-DAEMON-DONE\n')


if os.fork() > 0:
    # parent (the tool shell's child): print and exit fast
    print('tier daemon launched, log: %s' % LOG)
else:
    daemon()

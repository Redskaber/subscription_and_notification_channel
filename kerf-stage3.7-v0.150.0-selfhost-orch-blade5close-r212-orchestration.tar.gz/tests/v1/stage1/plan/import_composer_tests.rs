//! The import composer's harness family (W-SELFHOST-ORCH blade 1 —
//! O9, the GATE 6 composition).
//!
//! The composition layer's own discipline (first-seen, once-only,
//! cycle-closed) is unit-pinned in
//! `crates/kerf-driver/src/bootstrap/import_composer.rs`; this
//! family pins the REAL faces:
//!
//! - the byte-identity goldens: the composed expander family and
//!   the composed resolver family reproduce the retired host-side
//!   `format!` splices' file chains byte-for-byte (the import lines
//!   resolve to exactly the unit order the old concatenations
//!   hardcoded — the O6 parity caliber);
//! - the diamond: the expander imports `std/error` AND `macro`
//!   (whose own first line imports `std/error`) — the unit
//!   contributes exactly ONCE, at its first-seen site;
//! - the cross-stage consumption: the composed programs walk the
//!   production bridge (read + expand to real items);
//! - the negative family: an unregistered unit, an import cycle
//!   (both directions), a self-import, and a broken entry all
//!   reject fail-closed with their structured errors.
//!
//! The reader's own import faces (both spellings, the keyword
//! reservation) are pinned in the reader crate; the twin lexer /
//! parser parity cases (the keyword classification, the
//! import-str/import-path records vs the oracle dump) ride
//! `TARGET_LEXER_TWIN_CASES` / `TARGET_PARSER_TWIN_CASES`.

use kerf::driver::pkg_selfhost::RESOLVE_TARGET_SOURCE;
use kerf::driver::{
    EXPANDER_TARGET_SOURCE, ImportError, LOCKFILE_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    MANIFEST_TARGET_SOURCE, MICRO_TOML_TARGET_SOURCE, SEMVER_TARGET_SOURCE, compose_imports,
    compose_selfhost, selfhost_unit_source,
};
use kerf::span::FileId;

const FILE: FileId = FileId(0);

/// Run one probe on a deep stack (the sibling-plan convention: the
/// near-cap nesting probes and the twin drives recurse deeply in
/// debug builds).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The real unit registry as a composer resolver (the owned-String
/// face `compose_imports` takes).
fn registry() -> impl Fn(&str) -> Option<String> {
    |name: &str| selfhost_unit_source(name).map(str::to_string)
}

/// Strip the import-declaration lines from one carrier's source
/// (the golden's expected side: everything but the `import ...;`
/// lines is the carrier's own content, verbatim).
fn strip_import_lines(source: &str) -> String {
    let mut out = String::with_capacity(source.len());
    for line in source.split_inclusive('\n') {
        if line.trim_start().starts_with("import ") && line.trim_end().ends_with(';') {
            continue;
        }
        out.push_str(line);
    }
    out
}

#[test]
fn the_composed_expander_reproduces_the_retired_splice_byte_identically() {
    deep_stack(|| {
        // The golden: compose(expander.ktf) ==
        // format!("{STD}\n{MACRO}\n{expander-minus-imports}") — the
        // retired `assembled_expander_target_source_with_limit`
        // hardcoded exactly this unit order; the import surface
        // reproduces it through the source's own declarations.
        let composed = compose_selfhost(EXPANDER_TARGET_SOURCE);
        let std_error = selfhost_unit_source("std/error").unwrap();
        let expected = format!(
            "{std_error}\n{}\n{}",
            strip_import_lines(MACRO_TARGET_SOURCE),
            strip_import_lines(EXPANDER_TARGET_SOURCE),
        );
        assert_eq!(
            composed, expected,
            "the composed expander must be byte-identical to the retired splice"
        );
    });
}

#[test]
fn the_composed_resolver_reproduces_the_retired_splice_byte_identically() {
    deep_stack(|| {
        // The golden: compose(resolve.ktf) ==
        // format!("{STD}\n{MT}\n{SEMVER}\n{MANIFEST}\n{LOCKFILE}\n{resolve}")
        // — the retired `resolve_twin_program` hardcoded exactly
        // this dependency order (the §9.142 five-piece form); the
        // import surface reproduces it through resolve.ktf's own
        // declarations.
        let composed =
            compose_imports(RESOLVE_TARGET_SOURCE, &registry()).expect("the resolver composes");
        let std_error = selfhost_unit_source("std/error").unwrap();
        // ORCH blade 4 (P1): semver and manifest now carry their own
        // import declarations — every dependency is already seen by
        // the time they splice mid-chain, so their import lines
        // vanish (the strip mirrors the composer's seen-skip).
        let expected = format!(
            "{std_error}\n{MICRO_TOML_TARGET_SOURCE}\n{}\n{}\n{LOCKFILE_TARGET_SOURCE}\n{}",
            strip_import_lines(SEMVER_TARGET_SOURCE),
            strip_import_lines(MANIFEST_TARGET_SOURCE),
            strip_import_lines(RESOLVE_TARGET_SOURCE),
        );
        assert_eq!(
            composed.text, expected,
            "the composed resolver must be byte-identical to the retired splice"
        );
        // The O3-revised M49 disclosure: the row-literal carriers
        // (micro-toml, lockfile) ride verbatim — beyond the frozen
        // seed's grammar by design, their parsing the twin chain's
        // production position; every unit still contributes.
        assert_eq!(
            composed.units,
            vec!["std/error", "micro-toml", "semver", "manifest", "lockfile"]
        );
        assert_eq!(composed.verbatim, vec!["micro-toml", "lockfile"]);
    });
}

#[test]
fn the_std_error_unit_splices_once_in_the_diamond() {
    deep_stack(|| {
        // The real diamond: the expander imports `std/error` and
        // `macro`; macro's own first declaration imports
        // `std/error` too — the unit contributes ONCE (first-seen,
        // at the expander's own site), and the composed program
        // carries exactly one copy of the library's body.
        let composed = compose_selfhost(EXPANDER_TARGET_SOURCE);
        let marker = "fn attempt(";
        let count = composed.match_indices(marker).count();
        assert_eq!(
            count, 1,
            "the std Error instance must splice exactly once in the diamond"
        );
        // The composed text starts with the std unit's own body
        // (the first-seen site is the expander's first import).
        assert!(
            composed.starts_with(selfhost_unit_source("std/error").unwrap()),
            "the first-seen site brings the std unit at the head"
        );
    });
}

#[test]
fn the_composed_programs_walk_the_production_bridge() {
    deep_stack(|| {
        // The cross-stage consumption face: the composed programs
        // READ and EXPAND through the production bridge to real
        // items (the composed program is a flat ordinary program —
        // no import form survives the composition). The channel
        // defines ride the ASSEMBLED forms (the budget/table
        // channels are the blade-4 prefix family's territory — the
        // composed source alone is channel-free by design, its
        // twin references the globals the assembly defines).
        // The expander row: the twin references the injected channel
        // names (forms/ex-struct-accs/ex-enum-ctors — the steady
        // chain's own injection face), so the walk declares them
        // (the steady chain's exact pattern). The resolve family's
        // rows ride its OWN twin-run faces (resolve_twin_tests /
        // kp_selfhost_tests — the composed resolver's read is the
        // twin chain's production position, the row carriers beyond
        // the seed's grammar, the M49 boundary again).
        // ORCH blade 4 (P3): the accs/ctors channels retired —
        // the expander twin self-declares both state globals
        // (ex_struct_accs/ex_enum_ctors, the in-source defines); the
        // walk declares only the `forms` channel now.
        let injected = [kerf::span::Symbol::new("forms").unwrap()];
        for (name, source) in [
            ("macro.ktf", compose_selfhost(MACRO_TARGET_SOURCE)),
            (
                "expander.ktf",
                kerf::driver::assembled_expander_target_source(),
            ),
        ] {
            let mut session = kerf::driver::Session::new();
            let program =
                kerf::driver::parse_target_with_injected(&mut session, name, &source, &injected)
                    .unwrap_or_else(|d| panic!("the composed {name} must walk the bridge: {d:?}"));
            assert!(
                !program.items.is_empty(),
                "the composed {name} expands to real items"
            );
        }
    });
}

#[test]
fn an_unknown_unit_rejects_fail_closed() {
    deep_stack(|| {
        // The real registry's negative face: a probe importing a
        // unit the registry never declares.
        let probe = "import \"ghost\";\ndefine(x, 1);\n";
        let err = compose_imports(probe, &|name| {
            selfhost_unit_source(name).map(str::to_string)
        })
        .expect_err("an unregistered unit rejects");
        assert_eq!(
            err,
            ImportError::ImportNotFound {
                name: "ghost".to_string()
            }
        );
    });
}

#[test]
fn an_import_cycle_rejects_with_the_path() {
    deep_stack(|| {
        // A two-unit cycle on a synthetic registry: the path names
        // every segment, the loader's own cycle face.
        let units = [
            ("a", "import \"b\";\ndefine(a, 1);\n"),
            ("b", "import \"a\";\ndefine(b, 2);\n"),
        ];
        let resolve = |name: &str| {
            units
                .iter()
                .find(|(n, _)| *n == name)
                .map(|(_, src)| (*src).to_string())
        };
        let err =
            compose_imports("import \"a\";\n", &resolve).expect_err("a two-unit cycle rejects");
        assert_eq!(
            err,
            ImportError::ImportCycle {
                path: vec!["a".to_string(), "b".to_string(), "a".to_string()]
            }
        );
        assert_eq!(err.to_string(), "import cycle detected: `a` -> `b` -> `a`");
    });
}

#[test]
fn a_self_import_rejects() {
    deep_stack(|| {
        let units = [("a", "import \"a\";\ndefine(a, 1);\n")];
        let resolve = |name: &str| {
            units
                .iter()
                .find(|(n, _)| *n == name)
                .map(|(_, src)| (*src).to_string())
        };
        let err = compose_imports("import \"a\";\n", &resolve).expect_err("a self-import rejects");
        assert_eq!(
            err,
            ImportError::ImportCycle {
                path: vec!["a".to_string(), "a".to_string()]
            }
        );
    });
}

#[test]
fn the_row_carriers_ride_verbatim_and_reject_loudly_downstream() {
    deep_stack(|| {
        // The O3-revised M49 boundary, pinned on the real registry:
        // micro-toml and lockfile (the row-literal carriers) do not
        // read through the frozen seed — they ride VERBATIM in the
        // resolve composition (disclosed), and an import line
        // spliced into such a rider REJECTS loudly at the
        // downstream expansion face (never a silent skip).
        let probe = "import \"micro-toml\";\nimport \"lockfile\";\n";
        let composed = compose_imports(probe, &registry()).expect("the carriers compose");
        assert_eq!(
            composed.units,
            vec!["micro-toml", "lockfile"],
            "both carriers contribute"
        );
        assert_eq!(
            composed.verbatim,
            vec!["micro-toml", "lockfile"],
            "both carriers ride verbatim (the M49 disclosure)"
        );
        // A verbatim rider's own import line SURVIVES the
        // composition (no walk — the seed never read the rider), so
        // the downstream faces own its rejection: through the seed
        // the rider's own row grammar rejects at the read, and
        // through the twin chain (the production read position,
        // which parses both the row skin and the import keyword —
        // the twin parity cases pin those parses) the twin
        // expander's top-level face rejects the surviving import
        // form. Never a silent skip, at every position.
        let rider_with_import = "import \"std/error\";\ndefine(rec, [f: 1]);\n";
        let entry = "import \"rider\";\ndefine(x, 1);\n";
        let units = [("rider", rider_with_import.to_string())];
        let composed = compose_imports(entry, &|name: &str| {
            units
                .iter()
                .find(|(n, _)| *n == name)
                .map(|(_, src)| src.clone())
        })
        .expect("the rider composes");
        assert_eq!(composed.verbatim, vec!["rider"]);
        assert!(
            composed.text.contains("import \"std/error\";"),
            "the rider's import line survives the composition (no walk)"
        );
        assert!(
            kerf::reader::read_target_program(FILE, &composed.text).is_err(),
            "the seed read rejects the composed text (the rider's own row grammar — fail-closed)"
        );
    });
}

#[test]
fn the_bare_carriers_read_but_reject_at_the_top_level_face() {
    deep_stack(|| {
        // The O2 consumption-layering pin: an import-carrying
        // source READS through the frozen reader (the keyword face
        // makes it a form) — the composition layer's own contract —
        // while the RAW pipeline's expansion face rejects it
        // fail-closed (the expander's declaration dispatch never
        // claims the import head; the composer is its only
        // consumer).
        for (name, source) in [
            ("macro.ktf", MACRO_TARGET_SOURCE),
            ("expander.ktf", EXPANDER_TARGET_SOURCE),
        ] {
            let forms = kerf::reader::read_target_program(FILE, source)
                .unwrap_or_else(|e| panic!("the bare {name} must read: {e}"));
            assert!(
                forms.len() > 1,
                "the bare {name} reads to its full form list"
            );
            let err = kerf::expander::expand_program(&forms)
                .expect_err("the bare import-carrying source must reject at the top-level face");
            assert!(
                matches!(err, kerf::expander::ExpandError::TopLevelExpression { .. }),
                "the rejection is the existing top-level face on {name}: {err:?}"
            );
        }
    });
}

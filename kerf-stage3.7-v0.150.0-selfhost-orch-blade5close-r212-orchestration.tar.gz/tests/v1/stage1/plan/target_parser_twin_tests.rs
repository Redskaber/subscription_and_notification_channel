//! Target-parser twin tests (W-TGT-READ-TWIN blade 2 — gap G1 of
//! bootstrap-completion-plan.md §4.2): the target skin's own PARSER
//! layer, `selfhost/v1/target-parser.ktf`, against the Rust target
//! parser oracle (`kerf_reader::read_target_program`) through the
//! full `.ktf` chain on BOTH engines — the ninth selfhost twin, the
//! second that mirrors the TARGET read chain (the language parsing
//! its own `.ktf` sources; blade 1 lexed them, blade 3 composes the
//! steady read chain).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the curated case family (every frame mode's
//!   happy path: the declaration family, the statement family, the
//!   do/let backwards fold, all fourteen precedence levels with
//!   their desugars, the quote datum carrier, the pattern family,
//!   the type annotation drop, the handle arm discipline) plus the
//!   SELFHOST FIXED POINTS: the post-retirement `selfhost/v1/*.ktf`
//!   family (seven sources — the S-expr lexer/reader twins retired
//!   with the W-SEXP-RETIRE blade 2) through the twin — including
//!   the twin's OWN source (the self-application face: the target
//!   skin parsing its own parser, the deepest fixed point the read
//!   chain has reached).
//! * **Negative** — the rejection family, each case asserting the
//!   three-way agreement on the SAME error key (kind and payload:
//!   the five type-declaration items, the raw require call, the
//!   generics faces, the use tree/alias/bad-form faces, the macro
//!   spec faces, the index/field/cast faces, the positional
//!   keyword faces, the comparison chain, the range form, the
//!   or-pattern/guard/tuple3/pattern-syntax faces, the stray and
//!   unclosed delimiters, the empty quoted list, the missing semi).
//! * **Cross-stage consumption** — the twin's item dump for a
//!   selfhost source matches the oracle's tree structurally (the
//!   token count face: the twin consumed exactly the oracle's
//!   tokens), and the twin's own source parses its `fn` heads (the
//!   declaration face).

use kerf::driver::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, INFER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE, TARGET_PARSER_TWIN_CASES,
    TYPECHECK_TARGET_SOURCE, target_parser_parity,
};

const FILE: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1");

/// The selfhost fixed-point family: the seven `.ktf` twins through
/// the parity driver (the sources walk the harness Rust walkers and
/// both engines' per-record frames — the sibling tests'
/// demand-allocated stack discipline; the parser twin's frame
/// machine is heap-allocated but the harness decode walks are
/// recursive over deep trees).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the curated case family ----------

#[test]
fn curated_cases_hold_three_way_parity() {
    deep_stack(|| {
        for (name, source) in TARGET_PARSER_TWIN_CASES {
            if name.starts_with("neg-") {
                continue;
            }
            target_parser_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- positive: the selfhost fixed points ----------

#[test]
fn selfhost_sources_hold_three_way_parity() {
    deep_stack(|| {
        // The seven selfhost twins — the five chain twins plus the
        // target-lexer twin AND the target-parser twin ITSELF (the
        // self-application face: the deepest fixed point). The
        // S-expr lexer/reader twins retired with blade 2 (r151).
        let sources = [
            ("macro.ktf", MACRO_TARGET_SOURCE),
            ("expander.ktf", EXPANDER_TARGET_SOURCE),
            ("compiler.ktf", COMPILER_TARGET_SOURCE),
            ("infer.ktf", INFER_TARGET_SOURCE),
            ("typecheck.ktf", TYPECHECK_TARGET_SOURCE),
            ("target-lexer.ktf", TARGET_LEXER_TARGET_SOURCE),
            ("target-parser.ktf", TARGET_PARSER_TARGET_SOURCE),
        ];
        for (name, source) in &sources {
            target_parser_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

/// The selfhost family read from DISK (the tree-asset face — the
/// `include_str!` embeddings and the files on disk must agree, and
/// the disk read exercises the same face the corpus sweeps use).
#[test]
fn selfhost_disk_sources_hold_three_way_parity() {
    deep_stack(|| {
        for name in [
            "macro.ktf",
            "expander.ktf",
            "compiler.ktf",
            "infer.ktf",
            "typecheck.ktf",
            "target-lexer.ktf",
            "target-parser.ktf",
        ] {
            let path = format!("{FILE}/{name}");
            let source = std::fs::read_to_string(&path)
                .unwrap_or_else(|e| panic!("the selfhost twin {name} must read from disk: {e}"));
            target_parser_parity(name, &source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- negative: the rejection family ----------

/// The curated negative cases ride the SAME three-way driver (their
/// agreement is on the error KEY — kind and payload); this test
/// pins the family's breadth so a case lost from the list cannot
/// hide behind the positive sweep.
#[test]
fn rejection_family_agrees_on_the_same_error_key() {
    deep_stack(|| {
        let negative: Vec<(&str, &str)> = TARGET_PARSER_TWIN_CASES
            .iter()
            .filter(|(name, _)| name.starts_with("neg-"))
            .copied()
            .collect();
        assert!(
            negative.len() >= 35,
            "the rejection family must stay curated (found {})",
            negative.len()
        );
        for (name, source) in &negative {
            target_parser_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

/// The anchor faces: the exact parity keys, one per error family —
/// a drift in the twin's error rendering cannot hide behind an
/// agreeing-but-wrong pair.
#[test]
fn anchor_rejections_render_the_oracle_keys() {
    deep_stack(|| {
        // (case, source, the expected `ERR {key}` line)
        let anchors: &[(&str, &str, &str)] = &[
            (
                "type declarations",
                "type T = i64;\n",
                "ERR unsupported form: type declarations is not part of the current language subset",
            ),
            (
                "the raw require call",
                "require(\"m\");\n",
                "ERR unsupported form: the `require` call form (the target skin spells it `use \"name\";` or `use path;`) is not part of the current language subset",
            ),
            (
                "the comparison chain",
                "fn f(a, b, c) { a < b < c }\n",
                "ERR unexpected token `<`",
            ),
            (
                "the stray brace",
                "fn f() { 1 } }\n",
                "ERR unexpected closing delimiter `}` @ byte 13",
            ),
            (
                "the unclosed block",
                "fn f() { 1\n",
                "ERR unclosed delimiter: `{` is never closed @ byte 7",
            ),
            (
                "the empty quoted list",
                "quote(());\n",
                "ERR unsupported form: the empty quoted list (write `nil` \u{2014} the datum face of the empty list) is not part of the current language subset",
            ),
        ];
        for (case, source, want) in anchors {
            let oracle = match kerf::driver::target_parser_oracle_dump(source) {
                Ok(_) => panic!("the anchor case {case} must reject"),
                Err(err) => format!("ERR {}", kerf::driver::error_parity_key(&err)),
            };
            assert_eq!(
                oracle, *want,
                "the anchor case {case} must render the oracle key"
            );
            // The twin agrees on the same key.
            target_parser_parity(case, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- cross-stage consumption ----------

/// The twin's parse of a selfhost source consumed exactly the
/// oracle's tokens (the stream-position face: both engines end at
/// the same eof — a short- or long-consuming twin drifts the dump
/// and fails the parity above; this test additionally asserts the
/// positive-decision breadth with the twin's own declaration
/// heads: the disk source parses to a non-empty item list whose
/// first items are the file's `fn` and `define` forms in order).
#[test]
fn twin_own_source_parses_its_declaration_heads() {
    deep_stack(|| {
        let oracle = kerf::driver::target_parser_oracle_dump(TARGET_PARSER_TARGET_SOURCE)
            .expect("the twin's own source parses under the oracle");
        // The dump grammar: every record opens "(ident START END
        // NAME)". The import declarations (the ORCH blade 4 P1
        // riders) open the file now — the first LIBRARY form is
        // still the first helper fn's define, so locate the first
        // `define` keyword record: the SKIN-MAPPED name (tp_2 ->
        // tp-2 — the K20 canonical identity) rides the very next
        // ident's third field.
        let idents: Vec<&str> = oracle
            .split("(ident ")
            .skip(1)
            .filter_map(|rest| rest.split(' ').nth(2))
            .map(|name| name.trim_end_matches(')'))
            .collect();
        let define_at = idents
            .iter()
            .position(|name| *name == "define")
            .expect("the twin's own dump carries a define form");
        let first_head = idents.get(define_at + 1).copied().unwrap_or("");
        assert_eq!(
            first_head, "tp-2",
            "the twin's first library form head must be its first helper fn, \
             skin-mapped (found {first_head:?})"
        );
        assert!(
            oracle.contains("(ident 0 6 require)") || oracle.matches("(list ").count() > 100,
            "the twin's own dump must carry its real form structure"
        );
    });
}

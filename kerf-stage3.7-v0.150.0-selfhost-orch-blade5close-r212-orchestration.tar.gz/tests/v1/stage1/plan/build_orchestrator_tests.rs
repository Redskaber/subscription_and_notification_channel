//! The W-SELFHOST-ORCH blade-3 orchestrator tests (the kerf-build
//! twin's parity faces — window §11 B1-B9, the blade-3 gate):
//!
//! * **The A pass** — the assembled orchestrator (the six-unit
//!   composed chain + the kb_ driver, ~16k lines) must compile
//!   through the plain production pipeline (the seed face — the
//!   orchestrator is a CLOSED program, no injected slots);
//! * **The digest gate** — the heavyweight expander-family parity
//!   face rides its own module (build_orchestrator_digest_tests,
//!   the T1 round-commit tier — the r209 split; the six fast
//!   faces here stay the T0 smoke tier);
//! * **The parity faces** — the orchestrator's own full pipeline
//!   (read the seeded carrier, parse each unit through the twin
//!   lexer/parser, compose the carrier's imports first-seen,
//!   expand through the twin expander, compile through the twin
//!   compiler) against the Rust drive path on the same carriers:
//!   the SemanticDigest projection (span-free, the §9.25.4
//!   cross-skin face — the in-language composition's own spans
//!   are the unit-local ones, never the host's concatenated ones);
//! * **The negative faces** — the composition's fail-closed
//!   family (an unregistered unit, an import cycle) and the
//!   honest K20 boundary (a float carrier fails closed).

use kerf::driver::{
    MACRO_TARGET_SOURCE, Session, assembled_build_source, parse_target, selfhost_unit_source,
};
use kerf_vm::{BufferIo, Value, Vm};

/// The assembled orchestrator's A pass: parse + check + compile
/// through the plain production pipeline (the SEED pin — all four
/// segments Rust, the `rust_compile_ccf` discipline).
fn a_pass_compile() -> kerf_compiler::Bytecode {
    let assembled = assembled_build_source();
    let mut session = Session::with_segments(
        kerf::driver::ReadSegment::Rust,
        kerf::driver::ExpandSegment::Rust,
        kerf::driver::CheckSegment::Rust,
        kerf::driver::CompileSegment::Rust,
    );
    let program = parse_target(&mut session, "build-orchestrator.ktf", &assembled)
        .expect("the assembled orchestrator must parse");
    let findings = program.typecheck();
    let errors: Vec<_> = findings
        .iter()
        .filter(|d| d.severity == kerf::driver::Severity::Error)
        .collect();
    assert!(
        errors.is_empty(),
        "the assembled orchestrator must check clean: {errors:?}"
    );
    kerf_compiler::compile_program(&program.items).expect("the assembled orchestrator must compile")
}

/// The seed contract for one carrier unit set (B2): the count
/// line, then per unit (name, line count, the source lines); the
/// LAST unit is the entry.
fn seed_lines(units: &[(&str, &str)]) -> Vec<String> {
    let mut lines = vec![units.len().to_string()];
    for (name, source) in units {
        let src_lines: Vec<&str> = source.lines().collect();
        lines.push((*name).to_string());
        lines.push(src_lines.len().to_string());
        lines.extend(src_lines.iter().map(|s| s.to_string()));
    }
    lines
}

/// Drive the assembled orchestrator over one seeded carrier set:
/// the milestone lines ride the recorded output, the verdict stays
/// on the live heap (the rebuild face needs it).
fn drive_orchestrator(bc: &kerf_compiler::Bytecode, seed: &[String]) -> Vm {
    let mut vm = Vm::with_io(bc.clone(), Box::new(BufferIo::with_input(seed.iter())))
        .expect("the vm must accept the orchestrator");
    if let Err(err) = vm.run() {
        let out = vm.take_output();
        panic!("the orchestrator run failed: {err:?} -- output so far: {out:?}");
    }
    vm
}

/// The two-tag verdict's head text (the ("ok" ...) / ("err" ...)
/// grammar's own face).
fn verdict_tag(vm: &Vm) -> String {
    let value = vm.global("result").expect("the result global");
    match value.as_pair(vm.heap()) {
        Some((head, _)) => match head {
            Value::Str(s) => s.to_string(),
            other => format!("{other:?}"),
        },
        None => format!("{value:?}"),
    }
}

/// The verdict's second field (the ok arm's payload).
fn verdict_payload(vm: &Vm) -> &Value {
    let value = vm.global("result").expect("the result global");
    let (_, rest) = value.as_pair(vm.heap()).expect("the verdict record");
    rest
}

#[test]
fn the_assembled_orchestrator_compiles_through_the_seed_pipeline() {
    // The A pass: the composed ~16k-line chain (std/error + macro
    // + the four chain units + the kb_ driver) is a closed
    // program — the seed face accepts it whole (the cmd-go
    // moment: the orchestrator itself is now one language unit).
    let bc = a_pass_compile();
    assert!(
        !bc.funcs.is_empty(),
        "the orchestrator product must carry the chain's functions"
    );
}

#[test]
fn the_orchestrator_tables_probe_on_a_minimal_struct() {
    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nstruct S { x: int, }\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    let mut vm = vm;
    let out = vm.take_output();
    eprintln!("PROBE OUTPUT: {out:?}");
    if verdict_tag(&vm) != "ok" {
        // The prefix's own audit: the Rust single source, at the
        // error's own position.
        {
            let prefix_text = kerf::driver::carrier_assembly_prefix();
            eprintln!(
                "PROBE PREFIX LEN: {} | at 8034..8046: {:?}",
                prefix_text.len(),
                &prefix_text[8030.min(prefix_text.len())..8050.min(prefix_text.len())]
            );
            if let Some(v) = vm.global("kb_parser_slots") {
                if let kerf_vm::Value::Str(t) = v {
                    eprintln!(
                        "PROBE BLOB LEN: {} | head: {:?} | tail: {:?}",
                        t.len(),
                        &t[..60.min(t.len())],
                        &t[t.len().saturating_sub(60)..]
                    );
                } else {
                    eprintln!("PROBE BLOB: non-str {v:?}");
                }
            } else {
                eprintln!("PROBE BLOB: absent");
            }
        }
        // The full chain decode: walk the verdict spine, both fields
        // at every level — the error's own words.
        let payload = verdict_payload(&vm);
        let mut cur = payload.clone();
        let mut depth = 0;
        while depth < 12 {
            match cur.as_pair(vm.heap()) {
                Some((head, tail)) => {
                    let h = match head {
                        Value::Str(t) => t.to_string(),
                        Value::Int(i) => i.to_string(),
                        Value::Nil => "nil".to_string(),
                        other => format!("{other:?}"),
                    };
                    eprintln!("PROBE CHAIN[{depth}]: {h}");
                    cur = tail.clone();
                    depth += 1;
                }
                None => {
                    eprintln!("PROBE CHAIN[{depth}] END: {cur:?}");
                    break;
                }
            }
        }
    }
    assert_eq!(
        verdict_tag(&vm),
        "ok",
        "the minimal struct carrier must succeed"
    );
}

#[test]
fn the_orchestrator_drives_the_macro_carrier_end_to_end() {
    // The smoke carrier: the std/error + macro family through a
    // minimal entry's own import declarations. The orchestrator
    // reads the seeded lines, parses the units, composes
    // first-seen, expands, compiles — the verdict's ok arm carries
    // the artifact value, the milestone stream closes the §8.8
    // loop (B4's Write face).
    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nimport \"macro\";\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("macro", MACRO_TARGET_SOURCE),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    let mut vm = vm;
    let out = vm.take_output();
    assert!(
        out.contains(&"[orchestrator] units".to_string()),
        "the milestone stream: {out:?}"
    );
    assert!(
        out.contains(&"[orchestrator] compiled".to_string()),
        "the milestone stream: {out:?}"
    );
    assert_eq!(verdict_tag(&vm), "ok", "the verdict must be ok");
}

#[test]
fn the_orchestrator_fails_closed_on_an_unregistered_unit() {
    // The composition's fail-closed family (B6): an import naming
    // a unit the seed pool does not carry rejects loudly — never
    // a silent skip.
    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nimport \"no-such-unit\";\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    let tag = verdict_tag(&vm);
    assert_eq!(tag, "err", "the unregistered unit must reject loudly");
}

#[test]
fn the_orchestrator_fails_closed_on_an_import_cycle() {
    // The composition's cycle face (B6): a unit whose import
    // names itself — the first-seen walk already spliced the unit
    // (the entry's own name rides the seen set), so the repeat
    // splices nothing and the composition completes; the HONEST
    // cycle (a→b→a through two units) must reject through the
    // unregistered face (the pool carries no third unit) — the
    // in-progress stack discipline of the host composer has no
    // in-language equivalent at the flat-stream layer, so the
    // self-import splice is the pinned face here.
    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nimport \"macro\";\nimport \"entry\";\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("macro", MACRO_TARGET_SOURCE),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    // The self-import: the entry unit IS in the pool (it rides
    // the parsed units), so "entry" resolves and splices — the
    // recursion terminates through first-seen (the second
    // occurrence splices nothing). The composition completes.
    let tag = verdict_tag(&vm);
    assert_eq!(tag, "ok", "the self-import resolves through first-seen");
}

#[test]
fn the_orchestrator_holds_the_float_boundary_fail_closed() {
    // The honest K20 boundary (B4): a carrier with a float
    // literal fails closed at the token bridge (the float payload
    // is the host's Debug-text face — the carrier domain rides
    // the int-only set; the TD-registered boundary).
    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nfn f(x) { x }\ndefine(result, 1.5);\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    let tag = verdict_tag(&vm);
    assert_eq!(
        tag, "err",
        "a float carrier must fail closed at the bridge (the K20 boundary)"
    );
}

#[test]
fn the_orchestrator_milestone_stream_is_the_exact_gold() {
    // The blade-3 completion round's gate ④: the Write-channel
    // closure pinned as the EXACT line-order gold (never a
    // contains-scattered assertion). Re-pinned at the ORCH blade-4
    // surgery (r211): the carrier assembly prefix retired its two
    // accs/ctors nil defines (the expander twin now self-declares
    // and self-seeds), so the carrier's expansion input shrank by
    // those two items — expanded 4,396 → 4,390 (the r210 amendment
    // precedent: the gold comes from the deterministic drive). The
    // macro family carrier: the
    // full milestone sequence — units, parsed, composed (count +
    // the span-free forms census), expanded, compiled — one
    // deterministic stream, generated from the drive and pinned
    // whole (the census line rides it verbatim; the r210 prefix
    // amendment's parser slots ride the expanded count).
    const GOLD: &str = r#"[orchestrator] units
3
[orchestrator] parsed
3
[orchestrator] composed
2697
"list:3 ident:define list:2 ident:attempt ident:program list:4 ident:handle list:1 ident:program list:2 ident:raise list:3 ident:fn list:2 ident:e ident:k list:3 ident:cons string:114,97,105,115,101 ident:e list:2 ident:return list:3 ident:fn list:1 ident:r list:3 ident:cons string:111,107 ident:r list:3 ident:define list:3 ident:unwrap ident:result ident:fallback list:5 ident:match ident:result list:2 list:2 string:111,107 ident:r ident:r list:2 list:2 string:114,97,105,115,101 ident:e list:2 ident:fallback ident:e list:2 ident:_ ident:result list:3 ident:define list:2 ident:ex-2 ident:x list:2 ident:car list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-3 ident:x list:2 ident:car list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-4 ident:x list:2 ident:car list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-5 ident:x list:2 ident:car list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-6 ident:x list:2 ident:car list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-7 ident:x list:2 ident:car list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-cdr3 ident:x list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:3 ident:define list:2 ident:ex-cdr4 ident:x list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr list:2 ident:cdr ident:x list:4 ident:define-ann list:2 ident:ex-list? ident:t ident:bool list:3 ident:eq? list:2 ident:car ident:t string:108,105,115,116 list:4 ident:define-ann list:2 ident:ex-ident? ident:t ident:bool list:3 ident:eq? list:2 ident:car ident:t string:105,100,101,110,116 list:3 ident:define list:2 ident:ex-text ident:t list:2 ident:ex-4 ident:t list:3 ident:define list:2 ident:ex-s ident:t list:2 ident:ex-2 ident:t list:3 ident:define list:2 ident:ex-e ident:t list:2 ident:ex-3 ident:t list:3 ident:define list:2 ident:ex-children ident:t list:2 ident:ex-cdr4 ident:t list:3 ident:define list:3 ident:ex-rev ident:lst ident:acc list:4 ident:if list:2 ident:nil? ident:lst ident:acc list:3 ident:ex-rev list:2 ident:cdr ident:lst list:3 ident:cons list:2 ident:car ident:lst ident:acc list:3 ident:define list:3 ident:ex-append ident:a ident:b list:4 ident:if list:2 ident:nil? ident:a ident:b list:3 ident:cons list:2 ident:car ident:a list:3 ident:ex-append list:2 ident:cdr ident:a ident:b list:4 ident:define-ann list:3 ident:ex-len ident:lst list:2 ident:acc ident:i64 ident:i64 list:4 ident:if list:2 ident:nil? ident:lst ident:acc list:3 ident:ex-len list:2 ident:cdr ident:lst list:3 ident:+ ident:acc int:1 list:4 ident:define-ann list:3 ident:ex-nth ident:lst list:2 ident:n ident:i64 ident:nil list:4 ident:if list:3 ident:< ident:n int:1 list:2 ident:car ident:lst list:3 ident:ex-nth list:2 ident:cdr ident:lst list:3 ident:- ident:n int:1 list:4 ident:define-ann list:3 ident:ex-member? ident:name ident:lst ident:bool list:4 ident:if list:2 ident:nil? ident:lst bool:false list:4 ident:if list:3 ident:eq? ident:name list:2 ident:car ident:lst bool:true list:3 ident:ex-member? ident:name list:2 ident:cdr ident:lst list:4 ident:define-ann list:3 ident:ex-assoc list:2 ident:key ident:str ident:alist ident:nil list:4 ident:if list:2 ident:nil? ident:alist ident:nil list:4 ident:if list:3 ident:eq? ident:key list:2 ident:car list:2 ident:car ident:alist list:2 ident:car ident:alist list:3 ident:ex-assoc ident:key list:2 ident:cdr ident:alist list:3 ident:define list:2 ident:ex-gen ident:t list:5 ident:match list:2 ident:car ident:t list:2 string:108,105,115,116 list:2 ident:ex-4 ident:t list:2 string:109,97,110,103,108,101,100 list:2 ident:ex-6 ident:t list:2 ident:_ list:2 ident:ex-5 ident:t list:3 ident:define list:2 ident:ex-fail ident:tail list:3 ident:perform ident:raise list:3 ident:cons string:101,114,114 ident:tail list:3 ident:define ident:ex-globals list:2 ident:quote list:21 string:43 string:45 string:42 string:47 string:60 string:60,61 string:62 string:62,61 string:61 string:99,97,114 string:99,100,114 string:99,111,110,115 string:112,97,105,114,63 string:110,105,108,63 string:101,113,63 string:110,111,116 string:114,101,97,100,45,108,105,110,101 string:119,114,105,116,101,45,108,105,110,101 string:114,101,110,100,101,114,45,108,105,110,101 string:115,116,114,105,110,103,45,98,121,116,101,115 string:98,121,116,101,115,45,115,116,114,105,110,103 list:4 ident:define-ann list:2 ident:ex-mangled? ident:t ident:bool list:3 ident:eq? list:2 ident:car ident:t string:109,97,110,103,108,101,100 list:4 ident:define-ann list:2 ident:ex-name? ident:t ident:bool list:4 ident:if list:2 ident:ex-ident? ident:t bool:true list:2 ident:ex-mangled? ident:t list:3 ident:define list:2 ident:ex-name-of ident:t list:4 ident:if list:2 ident:ex-ident? ident:t list:2 ident:ex-text ident:t ident:t list:4 ident:define-ann list:3 ident:ex-name-eq? ident:a ident:b ident:bool list:4 ident:if list:2 ident:pair? ident:a list:4 ident:if list:2 ident:pair? ident:b list:4 ident:if list:3 ident:eq? list:2 ident:ex-4 ident:a list:2 ident:ex-4 ident:b list:3 ident:= list:2 ident:ex-5 ident:a list:2 ident:ex-5 ident:b bool:false bool:false list:4 ident:if list:2 ident:pair? ident:b bool:false list:3 ident:eq? ident:a ident:b list:4 ident:define-ann list:3 ident:ex-name-member? ident:name ident:lst ident:bool list:4 ident:if list:2 ident:nil? ident:lst bool:false list:4 ident:if list:3 ident:ex-name-eq? ident:name list:2 ident:car ident:lst bool:true list:3 ident:ex-name-member? ident:name list:2 ident:cdr ident:lst list:3 ident:define ident:ex-macros ident:nil list:4 ident:define-ann list:2 ident:ex-macro-resolve list:2 ident:name ident:str ident:nil list:3 ident:let list:2 ident:hit list:3 ident:ex-assoc ident:name ident:ex-macros list:4 ident:if list:2 ident:nil? ident:hit ident:nil list:2 ident:ex-2 ident:hit list:3 ident:define ident:ex-mfs string:48 list:3 ident:define ident:ex-mfe string:48 list:3 ident:define ident:ex-mlits ident:nil list:3 ident:define ident:ex-reserved list:2 ident:quote list:21 string:102,110 string:105,102 string:108,101,116 string:100,111 string:115,101,116,33 string:112,101,114,102,111,114,109 string:104,97,110,100,108,101 string:113,117,111,116,101 string:109,97,116,99,104 string:100,101,102,105,110,101 string:100,101,102,105,110,101,45,97,110,110 string:102,110,45,97,110,110 string:114,101,113,117,105,114,101 string:109,111,100,117,108,101 string:100,101,102,105,110,101,45,115,121,110,116,97,120 string:101,120,116,101,114,110 string:115,116,114,117,99,116 string:101,110,117,109 string:110,105,108 string:95 string:46,46,46 list:3 ident:define list:2 ident:ex-cpat ident:t list:4 ident:match list:2 ident:car ident:t list:2 string:99,112,108 list:4 ident:if list:2 ident:nil? list:2 ident:ex-2 ident:t list:3 ident:cons list:3 ident:cons string:112,108,105,115,116 list:3 ident:ex-rev list:2 ident:ex-4 ident:t ident:nil list:2 ident:ex-3 ident:t list:3 ident:let list:2 ident:r list:2 ident:ex-cpat list:3 ident:cons string:99,112 list:3 ident:cons list:2 ident:car list:2 ident:ex-2 ident:t list:3 ident:cons list:2 ident:ex-3 ident:t ident:nil list:4 ident:if list:2 ident:nil? ident:r ident:nil list:2 ident:ex-cpat list:3 ident:cons string:99,112,108 list:3 ident:cons list:2 ident:cdr list:2 ident:ex-2 ident:t list:3 ident:cons list:2 ident:cdr ident:r list:3 ident:cons list:3 ident:cons list:2 ident:car ident:r list:2 ident:ex-4 ident:t ident:nil list:2 ident:_ list:3 ident:let list:2 list:2 ident:node list:2 ident:ex-2 ident:t list:2 ident:seen list:2 ident:ex-3 ident:t list:4 ident:if list:2 ident:ex-ident? ident:node list:3 ident:let list:2 ident:x list:2 ident:ex-text ident:node list:4 ident:if list:3 ident:eq? ident:x string:95 list:3 ident:cons list:3 ident:cons string:119,105,108,100 ident:nil ident:seen list:4 ident:if list:3 ident:eq? ident:x string:46,46,46 ident:nil list:4 ident:if list:4 ident:if list:3 ident:eq? ident:x string:110,105,108 bool:true list:3 ident:ex-member? ident:x ident:ex-mlits list:3 ident:cons list:3 ident:cons string:108,105,116 list:3 ident:cons ident:x ident:nil ident:seen list:4 ident:if list:3 ident:ex-member? ident:x ident:seen ident:nil list:3 ident:cons list:3 ident:cons string:118,97,114 list:3 ident:cons ident:x ident:nil list:3 ident:cons ident:x ident:seen list:4 ident:if list:2 ident:ex-list? ident:node list:2 ident:ex-cpat list:3 ident:cons string:99,112,108 list:3 ident:cons list:2 ident:ex-children ident:node list:3 ident:cons ident:seen list:3 ident:cons ident:nil ident:nil list:3 ident:cons list:3 ident:cons string:97,116,111,109 list:3 ident:cons list:2 ident:car ident:node list:3 ident:cons list:2 ident:ex-4 ident:node ident:nil ident:seen list:3 ident:define list:2 ident:ex-lits-walk ident:nodes list:4 ident:if list:2 ident:nil? ident:nodes ident:nil list:3 ident:let list:2 ident:n list:2 ident:car ident:nodes list:4 ident:if list:2 ident:ex-ident? ident:n list:3 ident:let list:2 ident:x list:2 ident:ex-text ident:n list:4 ident:if list:4 ident:if list:3 ident:eq? ident:x string:95 bool:true list:4 ident:if list:3 ident:eq? ident:x string:46,46,46 bool:true list:3 ident:eq? ident:x string:110,105,108 bool:false list:3 ident:let list:2 ident:remaining list:2 ident:ex-lits-walk list:2 ident:cdr ident:nodes list:4 ident:if list:3 ident:eq? ident:remaining bool:false bool:false list:3 ident:cons ident:x ident:remaining bool:false list:3 ident:define list:3 ident:ex-clause-walk ident:clauses ident:acc list:4 ident:if list:2 ident:nil? ident:clauses list:3 ident:ex-rev ident:acc ident:nil list:3 ident:let list:2 ident:c list:2 ident:car ident:clauses list:4 ident:if list:2 ident:ex-list? ident:c list:4 ident:if list:3 ident:= list:3 ident:ex-len list:2 ident:ex-children ident:c int:0 int:2 list:3 ident:let list:2 ident:p list:3 ident:ex-nth list:2 ident:ex-children ident:c int:0 list:4 ident:if list:2 ident:ex-list? ident:p list:3 ident:let list:2 ident:cp list:2 ident:ex-cpat list:3 ident:cons string:99,112 list:3 ident:cons ident:p list:3 ident:cons ident:nil ident:nil list:4 ident:if list:2 ident:nil? ident:cp list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons ident:ex-mfs list:3 ident:cons ident:ex-mfe ident:nil list:3 ident:ex-clause-walk list:2 ident:cdr ident:clauses list:3 ident:cons list:3 ident:cons list:2 ident:car ident:cp list:3 ident:cons list:3 ident:ex-nth list:2 ident:ex-children ident:c int:1 ident:nil ident:acc list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons ident:ex-mfs list:3 ident:cons ident:ex-mfe ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons ident:ex-mfs list:3 ident:cons ident:ex-mfe ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons ident:ex-mfs list:3 ident:cons ident:ex-mfe ident:nil list:3 ident:define list:2 ident:ex-macro-define ident:x list:3 ident:let list:2 ident:items list:2 ident:ex-children ident:x list:4 ident:if list:2 ident:not list:3 ident:= list:3 ident:ex-len ident:items int:0 int:3 list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:let list:2 ident:nt list:3 ident:ex-nth ident:items int:1 list:4 ident:if list:2 ident:ex-ident? ident:nt list:4 ident:if list:3 ident:ex-member? list:2 ident:ex-text ident:nt ident:ex-reserved list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:let list:2 ident:spec list:3 ident:ex-nth ident:items int:2 list:4 ident:if list:2 ident:ex-list? ident:spec list:3 ident:let list:2 ident:sitems list:2 ident:ex-children ident:spec list:4 ident:if list:2 ident:nil? ident:sitems list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:let list:2 ident:h0 list:2 ident:car ident:sitems list:4 ident:if list:2 ident:ex-ident? ident:h0 list:4 ident:if list:3 ident:eq? list:2 ident:ex-text ident:h0 string:115,121,110,116,97,120,45,114,117,108,101,115 list:4 ident:if list:3 ident:< list:3 ident:ex-len ident:sitems int:0 int:2 list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:let list:2 ident:litt list:3 ident:ex-nth ident:sitems int:1 list:3 ident:let list:2 ident:lits list:4 ident:if list:2 ident:ex-ident? ident:litt list:4 ident:if list:3 ident:eq? list:2 ident:ex-text ident:litt string:110,105,108 ident:nil bool:false list:4 ident:if list:2 ident:ex-list? ident:litt list:4 ident:if list:2 ident:nil? list:2 ident:ex-children ident:litt bool:false list:2 ident:ex-lits-walk list:2 ident:ex-children ident:litt bool:false list:4 ident:if list:3 ident:eq? ident:lits bool:false list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:let list:2 ident:n list:2 ident:ex-text ident:nt list:5 ident:do list:3 ident:set! ident:ex-mlits ident:lits list:3 ident:set! ident:ex-mfs list:2 ident:ex-s ident:x list:3 ident:set! ident:ex-mfe list:2 ident:ex-e ident:x list:3 ident:let list:2 ident:rules list:3 ident:ex-clause-walk list:2 ident:cdr list:2 ident:cdr ident:sitems ident:nil list:3 ident:do list:3 ident:set! ident:ex-macros list:3 ident:cons list:3 ident:cons ident:n list:3 ident:cons ident:rules ident:nil ident:ex-macros list:3 ident:cons string:100,101,102,115,121,110 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x list:3 ident:cons ident:n ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:2 ident:ex-fail list:3 ident:cons string:109,97,108,102,111,114,109,101,100 list:3 ident:cons string:100,101,102,105,110,101,45,115,121,110,116,97,120 list:3 ident:cons list:2 ident:ex-s ident:x list:3 ident:cons list:2 ident:ex-e ident:x ident:nil list:3 ident:define list:2 ident:ex-mx ident:t list:4 ident:match list:2 ident:car ident:t list:2 string:109,120,122,105,112 list:4 ident:if list:2 ident:nil? list:2 ident:ex-2 ident:t list:3 ident:cons bool:true list:2 ident:ex-4 ident:t list:3 ident:let list:2 ident:r list:2 ident:ex-mx list:3 ident:cons string:109,120 list:3 ident:cons list:2 ident:car list:2 ident:ex-2 ident:t list:3 ident:cons list:2 ident:car list:2 ident:ex-3 ident:t list:3 ident:cons list:2 ident:ex-4 ident:t ident:nil list:4 ident:if list:2 ident:car ident:r list:2 ident:ex-mx list:3 ident:cons string:109,120,122,105,112 list:3 ident:cons list:2 ident:cdr list:2 ident:ex-2 ident:t list:3 ident:cons list:2 ident:cdr list:2 ident:ex-3 ident:t list:3 ident:cons list:2 ident:cdr ident:r ident:nil ident:r list:2 ident:_ list:3 ident:let list:3 list:2 ident:p list:2 ident:ex-2 ident:t list:2 ident:f list:2 ident:ex-3 ident:t list:2 ident:b list:2 ident:ex-4 ident:t list:7 ident:match list:2 ident:car ident:p list:2 string:119,105,108,100 list:3 ident:cons bool:true ident:b list:2 string:108,105,116 list:4 ident:if list:2 ident:ex-ident? ident:f list:4 ident:if list:3 ident:eq? list:2 ident:ex-text ident:f list:2 ident:ex-2 ident:p list:3 ident:cons bool:true ident:b list:3 ident:cons bool:false ident:nil list:3 ident:cons bool:false ident:nil list:2 string:118,97,114 list:3 ident:cons bool:true list:3 ident:cons list:3 ident:cons list:2 ident:ex-2 ident:p list:3 ident:cons ident:f ident:nil ident:b list:2 string:97,116,111,109 list:4 ident:if list:2 ident:ex-list? ident:f list:3 ident:cons bool:false ident:nil list:4 ident:if list:2 ident:ex-ident? ident:f list:3 ident:cons bool:false ident:nil list:4 ident:if list:3 ident:eq? list:2 ident:car ident:f list:2 ident:ex-2 ident:p list:4 ident:if list:3 ident:eq? list:2 ident:ex-2 ident:p string:105,110,116 list:4 ident:if list:3 ident:= list:2 ident:ex-4 ident:f list:2 ident:ex-3 ident:p list:3 ident:cons bool:true ident:b list:3 ident:cons bool:false ident:nil list:4 ident:if list:3 ident:eq? list:2 ident:ex-4 ident:f list:2 ident:ex-3 ident:p list:3 ident:cons bool:true ident:b list:3 ident:cons bool:false ident:nil list:3 ident:cons bool:false ident:nil list:2 ident:_ list:4 ident:if list:2 ident:ex-list? ident:f list:4 ident:if list:3 ident:= list:3 ident:ex-len list:2 ident:cdr ident:p int:0 list:3 ident:ex-len list:2 ident:ex-children ident:f int:0 list:2 ident:ex-mx list:3 ident:cons string:109,120,122,105,112 list:3 ident:cons list:2 ident:cdr ident:p list:3 ident:cons list:2 ident:ex-children ident:f list:3 ident:cons ident:b ident:nil list:3 ident:cons bool:false ident:nil list:3 ident:cons bool:false ident:nil list:3 ident:define list:2 ident:ex-colls ident:t list:4 ident:match list:2 ident:car ident:t list:2 string:99,115,108 list:4 ident:if list:2 ident:nil? list:2 ident:ex-2 ident:t list:2 ident:ex-3 ident:t list:3 ident:let list:2 ident:acc2 list:2 ident:ex-colls list:3 ident:cons string:99,115 list:3 ident:cons list:2 ident:car list:2 ident:ex-2 ident:t list:3 ident:cons list:2 ident:ex-3 ident:t ident:nil list:2 ident:ex-colls list:3 ident:cons string:99,115,108 list:3 ident:cons list:2 ident:cdr list:2 ident:ex-2 ident:t list:3 ident:cons ident:acc2 ident:nil list:2 ident:_ list:3 ident:let list:2 list:2 ident:n list:2 ident:ex-2 ident:t list:2 ident:acc list:2 ident:ex-3 ident:t list:4 ident:if list:2 ident:ex-ident? ident:n list:3 ident:cons list:2 ident:ex-text ident:n ident:acc list:4 ident:if list:2 ident:ex-list? ident:n list:2 ident:ex-colls list:3 ident:cons string:99,115,108 list:3 ident:cons list:2 ident:ex-children ident:n list:3 ident:cons ident:acc ident:nil ident:acc list:3 ident:define list:2 ident:ex-trig-of ident:bind list:4 ident:if list:2 ident:nil? ident:bind list:3 ident:ex-append ident:ex-globals ident:ex-reserved list:3 ident:let list:2 ident:acc list:2 ident:ex-colls list:3 ident:cons string:99,115 list:3 ident:cons list:2 ident:ex-2 list:2 ident:car ident:bind list:3 ident:cons ident:nil ident:nil list:3 ident:ex-append ident:acc list:2 ident:ex-trig-of list:2 ident:cdr ident:bind list:3 ident:define list:2 ident:ex-syms2 ident:trees list:4 ident:if list:2 ident:nil? ident:trees ident:nil list:4 ident:if list:2 ident:ex-ident? list:2 ident:car ident:trees list:3 ident:cons list:2 ident:ex-text list:2 ident:car ident:trees list:2 ident:ex-syms2 list:2 ident:cdr ident:trees bool:false list:3 ident:define list:2 ident:ex-pairnames ident:spec list:4 ident:if list:2 ident:nil? ident:spec ident:nil list:3 ident:let list:2 ident:pr list:2 ident:car ident:spec list:4 ident:if list:2 ident:ex-list? ident:pr list:4 ident:if list:3 ident:= list:3 ident:ex-len list:2 ident:ex-children ident:pr int:0 int:2 list:4 ident:if list:2 ident:ex-ident? list:2 ident:car list:2 ident:ex-children ident:pr list:3 ident:let list:2 ident:remaining list:2 ident:ex-pairnames list:2 ident:cdr ident:spec list:4 ident:if list:3 ident:eq? ident:remaining bool:false bool:false list:3 ident:cons list:2 ident:ex-text list:2 ident:car list:2 ident:ex-children ident:pr ident:remaining bool:false bool:false bool:false list:3 ident:define list:2 ident:ex-binder-names ident:items list:4 ident:if list:2 ident:nil? ident:items ident:nil list:3 ident:let list:2 ident:h list:2 ident:car ident:items list:4 ident:if list:2 ident:ex-ident? ident:h list:3 ident:let list:2 ident:hx list:2 ident:ex-text ident:h list:5 ident:match ident:hx list:2 string:102,110 list:4 ident:if list:3 ident:= list:3 ident:ex-len ident:items int:0 int:3 list:3 ident:let list:2 ident:ps list:3 ident:ex-nth ident:items int:1 list:4 ident:if list:2 ident:ex-list? ident:ps list:2 ident:ex-syms2 list:2 ident:ex-children ident:ps ident:nil ident:nil list:2 string:108,101,116 list:4 ident:if list:3 ident:= list:3 ident:ex-len ident:items int:0 int:3 list:3 ident:let list:2 ident:spec list:3 ident:ex-nth ident:items int:1 list:4 ident:if list:2 ident:ex-list? ident:spec list:3 ident:let list:2 ident:sc list:2 ident:ex-children ident:spec list:4 ident:if list:2 ident:nil? ident:sc ident:nil list:4 ident:if list:2 ident:ex-list? list:2 ident:car ident:sc list:2 ident:ex-pairnames ident:sc list:4 ident:if list:3 ident:= list:3 ident:ex-len ident:sc int:0 int:2 list:4 ident:if list:2 ident:ex-ident? list:2 ident:car ident:sc list:3 ident:cons list:2 ident:ex-text list:2 ident:car ident:sc ident:nil ident:nil ident:nil ident:nil ident:nil list:2 ident:_ ident:nil ident:nil list:3 ident:define list:4 ident:ex-bcols ident:names ident:trigger ident:acc list:4 ident:if list:2 ident:nil? ident:names list:3 ident:ex-rev ident:acc ident:nil list:3 ident:let list:2 ident:n list:2 ident:car ident:names list:4 ident:if list:4 ident:if list:3 ident:ex-member? ident:n ident:trigger list:2 ident:not list:3 ident:ex-member? ident:n ident:acc bool:false list:4 ident:ex-bcols list:2 ident:cdr ident:names ident:trigger list:3 ident:cons ident:n ident:acc list:4 ident:ex-bcols list:2 ident:cdr ident:names ident:trigger ident:acc list:3 ident:define ident:ex-mren ident:nil list:3 ident:define ident:ex-mcount int:0 list:3 ident:define ident:ex-mgen int:0 list:3 ident:define ident:ex-mbind ident:nil list:3 ident:define ident:ex-mtrigger ident:nil list:3 ident:define list:2 ident:ex-push-renames ident:cols list:4 ident:if list:2 ident:nil? ident:cols ident:nil list:4 ident:do list:3 ident:set! ident:ex-mren list:3 ident:cons list:3 ident:cons list:2 ident:car ident:cols list:3 ident:cons ident:ex-mcount ident:nil ident:ex-mren list:3 ident:set! ident:ex-mcount list:3 ident:+ ident:ex-mcount int:1 list:2 ident:ex-push-renames list:2 ident:cdr ident:cols list:3 ident:define list:2 ident:ex-pop-renames ident:cols list:4 ident:if list:2 ident:nil? ident:cols ident:nil list:3 ident:do list:3 ident:set! ident:ex-mren list:2 ident:cdr ident:ex-mren list:2 ident:ex-pop-renames list:2 ident:cdr ident:cols list:4 ident:define-ann list:3 ident:ex-ar list:2 ident:text ident:str ident:stack ident:nil list:4 ident:if list:2 ident:nil? ident:stack ident:nil list:4 ident:if list:3 ident:eq? list:2 ident:car list:2 ident:car ident:stack ident:text list:2 ident:ex-2 list:2 ident:car ident:stack list:3 ident:ex-ar ident:text list:2 ident:cdr ident:stack list:4 ident:define-ann list:2 ident:ex-active-rename list:2 ident:text ident:str ident:nil list:3 ident:ex-ar ident:text ident:ex-mren list:3 ident:define list:2 ident:ex-inst ident:t list:4 ident:match list:2 ident:car ident:t list:2 string:105,109,97,112 list:4 ident:if list:2 ident:nil? list:2 ident:ex-2 ident:t list:3 ident:ex-rev list:2 ident:ex-3 ident:t ident:nil list:3 ident:let list:2 ident:r list:2 ident:ex-inst list:2 ident:car list:2 ident:ex-2 ident:t list:2 ident:ex-inst list:3 ident:cons string:105,109,97,112 list:3 ident:cons list:2 ident:cdr list:2 ident:ex-2 ident:t list:3 ident:cons list:3 ident:cons ident:r list:2 ident:ex-3 ident:t ident:nil list:2 ident:_ list:4 ident:if list:2 ident:ex-ident? ident:t list:3 ident:let list:2 ident:bv list:3 ident:ex-assoc list:2 ident:ex-text ident:t ident:ex-mbind list:4 ident:if list:2 ident:nil? ident:bv list:3 ident:let list:2 ident:c list:2 ident:ex-active-rename list:2 ident:ex-text ident:t list:4 ident:if list:2 ident:nil? ident:c list:3 ident:cons string:105,100,101,110,116 list:3 ident:cons list:2 ident:ex-s ident:t list:3 ident:cons list:2 ident:ex-e ident:t list:3 ident:cons list:2 ident:ex-text ident:t list:3 ident:cons list:3 ident:+ ident:ex-mgen int:1 ident:nil list:3 ident:cons string:109,97,110,103,108,101,100 list:3 ident:cons list:2 ident:ex-s ident:t list:3 ident:cons list:2 ident:ex-e ident:t list:3 ident:cons list:2 ident:ex-text ident:t list:3 ident:cons ident:c list:3 ident:cons list:3 ident:+ ident:ex-mgen int:1 ident:nil list:2 ident:ex-2 ident:bv list:4 ident:if list:2 ident:ex-list? ident:t list:3 ident:let list:2 ident:cols list:4 ident:ex-bcols list:2 ident:ex-binder-names list:2 ident:ex-children ident:t ident:ex-mtrigger ident:nil list:3 ident:do list:2 ident:ex-push-renames ident:cols list:3 ident:let list:2 ident:kids list:2 ident:ex-inst list:3 ident:cons string:105,109,97,112 list:3 ident:cons list:2 ident:ex-children ident:t list:3 ident:cons ident:nil ident:nil list:3 ident:do list:2 ident:ex-pop-renames ident:cols list:3 ident:cons string:108,105,115,116 list:3 ident:cons list:2 ident:ex-s ident:t list:3 ident:cons list:2 ident:ex-e ident:t list:3 ident:cons list:3 ident:+ ident:ex-mgen int:1 ident:kids list:3 ident:cons list:2 ident:car ident:t list:3 ident:cons list:2 ident:ex-s ident:t list:3 ident:cons list:2 ident:ex-e ident:t list:3 ident:cons list:2 ident:ex-4 ident:t list:3 ident:cons list:3 ident:+ ident:ex-mgen int:1 ident:nil list:4 ident:define-ann list:4 ident:ex-macro-use ident:rules list:2 ident:name ident:str ident:x ident:nil list:4 ident:if list:2 ident:nil? ident:rules list:3 ident:let list:2 ident:h list:2 ident:car list:2 ident:ex-children ident:x list:2 ident:ex-fail list:3 ident:cons string:109,97,99,114,111,45,109,105,115,109,97,116,99,104 list:3 ident:cons ident:name list:3 ident:cons list:2 ident:ex-s ident:h list:3 ident:cons list:2 ident:ex-e ident:h ident:nil list:3 ident:let list:2 ident:r list:2 ident:ex-mx list:3 ident:cons string:109,120 list:3 ident:cons list:2 ident:car list:2 ident:car ident:rules list:3 ident:cons ident:x list:3 ident:cons ident:nil ident:nil list:4 ident:if list:2 ident:car ident:r list:6 ident:do list:3 ident:set! ident:ex-mbind list:2 ident:cdr ident:r list:3 ident:set! ident:ex-mcount int:0 list:3 ident:set! ident:ex-mgen list:2 ident:ex-gen list:2 ident:car list:2 ident:ex-children ident:x list:3 ident:set! ident:ex-mtrigger list:2 ident:ex-trig-of list:2 ident:cdr ident:r list:2 ident:ex-inst list:2 ident:ex-2 list:2 ident:car ident:rules list:4 ident:ex-macro-use list:2 ident:cdr ident:rules ident:name ident:x "
[orchestrator] expanded
4390
[orchestrator] compiled"#;

    let bc = a_pass_compile();
    let entry = "import \"std/error\";\nimport \"macro\";\n";
    let seed = seed_lines(&[
        ("std/error", selfhost_unit_source("std/error").unwrap()),
        ("macro", MACRO_TARGET_SOURCE),
        ("entry", entry),
    ]);
    let vm = drive_orchestrator(&bc, &seed);
    let mut vm = vm;
    let out = vm.take_output();
    let expected: Vec<String> = GOLD.split('\n').map(|s| s.to_string()).collect();
    assert_eq!(
        out, expected,
        "the milestone stream must equal the exact gold (the Write-channel closure)"
    );
    assert_eq!(verdict_tag(&vm), "ok", "the verdict must be ok");
}

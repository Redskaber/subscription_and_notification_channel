//! Stage 1.9 stage-exit evidence — the §21.5 nine-signal claims as
//! re-runnable cargo tests (docs/develop/v1/stage-1/
//! deep-review-round1.9.md D3/D8; the audit section V carries the
//! same anchors in the gate-audit binary).
//!
//! One test per signal-adjacent behavior: semantic stability (both
//! engines over the builtin families), bootstrap verification (gate
//! B on a composite source), the frozen acceptance face (the corpus
//! directory contract), the budget face, the render goldens, the
//! frozen cardinalities, the zero-finding dual, the full-pipeline
//! dataflow, the two-layer batch, and the recovery close.

use kerf::driver::{
    Engine, Session, assembled_expander_target_source, check_source, gate_b_bytecode,
    run_parity_source_with, run_source,
};

fn corpus_dir() -> String {
    format!("{}/tests/v1/stage1/corpus", env!("CARGO_MANIFEST_DIR"))
}

// ---------- signal 1: semantic stability ----------

#[test]
fn exit_semantic_stability_builtin_families_both_engines() {
    // The r151 single-skin retarget: the builtin-family probe rides
    // the target skin (the skin map: cons->pair, car->first,
    // nil?->is_nil, eq?->eq; the corpus spelling discipline).
    let src = "define(p, pair(1, pair(2.5, nil))); define(a, (1 + 2)); define(b, (1 < 2)); define(c, first(p)); define(e, is_nil(nil)); define(f, eq(a, a)); define(g, not(b));";
    let mut s = Session::new();
    let vm = run_source(&mut s, "st.ktf", src, Engine::Vm, &[]).expect("vm run");
    let mut s = Session::new();
    let ev = run_source(&mut s, "st.ktf", src, Engine::Eval, &[]).expect("eval run");
    for name in ["a", "b", "c", "e", "f", "g"] {
        let vv = vm.global(name).map(|v| v.to_string());
        let ve = ev.global(name).map(|v| v.to_string());
        assert_eq!(vv, ve, "engines disagree on `{name}`");
    }
    assert_eq!(vm.global("a").map(|v| v.to_string()), Some("3".into()));
    assert_eq!(vm.global("c").map(|v| v.to_string()), Some("1".into()));
}

// ---------- signal 2: bootstrap verification ----------

#[test]
fn exit_bootstrap_gate_b_on_a_composite_source() {
    // A macro + let + tail-if composite through the assembled `.ktf`
    // expander: oracle and rebuilt items compile to identical
    // bytecode (the fixpoint contract at the stage close). The r151
    // retarget: the composite rides the target skin (the block
    // let-fold carries the let; the swap template's `pair` datum
    // reads as the canonical `cons` through the skin map).
    let src = "macro swap { (syntax_rules, nil, ((_, a, b), (pair, b, (pair, a, nil)))) } define(r, { let q = swap(1, 2); if (is_nil(rest(q))) { first(q) } else { 9 }; 0 });";
    gate_b_bytecode("exit-gate-b", src).expect("gate B holds on the composite");
}

// ---------- signal 3: the frozen acceptance face ----------

#[test]
fn exit_corpus_directory_contract_holds() {
    // The corpus directory contract on the TARGET face (W-SEXP-RETIRE
    // blade 1, v0.111.0): the migrated single-skin `.ktf` corpus (125
    // cases — three skin-divergent rows retired per
    // w-sexp-retire-window SR-2), every file through the parity core
    // (`run_parity_source_with` — the single-skin read +
    // `ParsedProgram::run_parity`, the same machine `validate_target`
    // drives for the corpus contract; the r151 state: the face
    // argument retired with the second skin). The contract
    // itself is unchanged: accepted files agree across both engines,
    // rejected files produce a non-empty diagnostic batch (the nine
    // stage-divergent rows among them — the target grammar rejects at
    // read what the S-expr reader deferred to the expander). The
    // r150 measured face: 52 accepted rows (the value family plus
    // the warning row) and 57 rejected rows (16 read + 23
    // expand/loader + 12 type-error + 1 compile-error + 5
    // runtime-error).
    //
    // The r168-b3 stack discipline (the r168-b1 environment family's
    // own): the parity walks recurse over deep trees on the Rust
    // stack — this case now needs the plan-family deep-stack thread
    // (768 MiB), the seven-file precedent's own.
    deep_stack(|| {
        let mut paths: Vec<_> = std::fs::read_dir(corpus_dir())
            .expect("corpus directory")
            .flatten()
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        paths.sort();
        assert!(
            paths.len() >= 170,
            "corpus floor: {} < 170 (the single-skin .ktf corpus — 109 blade-1 cases + the sixteen annotation rows + the thirteen \
             blade-2 struct rows + the sixteen blade-3 enum rows + the sixteen blade-4 pattern rows)",
            paths.len()
        );
        for path in paths {
            let source = std::fs::read_to_string(&path).expect("corpus file");
            let mut s = Session::new();
            match run_parity_source_with(&mut s, "c.ktf", &source, &[]) {
                Ok(report) => assert!(
                    report.agrees(),
                    "parity drift in {:?}: vm=`{}` eval=`{}`",
                    path.file_name(),
                    report.vm_repr,
                    report.eval_repr
                ),
                // Negative directives reject before parity — the
                // non-empty batch is the frozen expectation.
                Err(diags) => assert!(!diags.is_empty()),
            }
        }
    });
}

/// The deep-stack thread (the plan-family convention — the harness
/// walks recurse over deep trees; the default test-thread stack
/// overflows on them, the r168-b1 environment family's own).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- signal 4: the budget face ----------

#[test]
fn exit_budget_is_live_and_fails_closed() {
    use kerf_vm::Vm;
    let bc = kerf_compiler::compile_program(&[]).expect("empty program compiles");
    let mut vm = Vm::with_budget(bc, 4).expect("budgeted vm");
    let value = vm.run().expect("one entry frame fits");
    assert_eq!(value.to_string(), "nil");
    assert!(vm.allocations() >= 1, "the entry frame is budgeted");
    let bc = kerf_compiler::compile_program(&[]).expect("empty program compiles again");
    let mut vm0 = Vm::with_budget(bc, 0).expect("zero-budget vm");
    assert!(
        vm0.run().is_err(),
        "zero budget fails closed — the entry frame cannot allocate"
    );
}

// ---------- signal 5: render goldens stay byte-stable ----------

#[test]
fn exit_render_golden_e0009_call_site_anchor() {
    let mut s = Session::new();
    // The r151 retarget: the golden rides the target skin (closure
    // `||(x) { ... }`, if the corpus spelling). The anchor is the
    // offending argument `1` at its call site — column 61 of the
    // respelled line (probe-verified at the 1.9 close, re-pinned at
    // the same judgment).
    let err = run_source(
        &mut s,
        "g.ktf",
        "define(f, (||(x) { if (x) { 1 } else { 2 } })); define(r, f(1));",
        Engine::Vm,
        &[],
    )
    .expect_err("the bool-demand mismatch blocks");
    let rendered = kerf::driver::render_diagnostics(&s, &err);
    assert!(
        rendered.contains("error[E0009]: type mismatch: expected `bool`, found `int`"),
        "{rendered}"
    );
    assert!(rendered.contains("--> g.ktf:1:61"), "{rendered}");
}

// ---------- signal 6: frozen cardinalities (handling degrees) ----------

#[test]
fn exit_frozen_faces_hold_their_cardinality() {
    // The builtin count: 18 through W-SELFHOST-MODERN-2; 19 at
    // W-SELFHOST-ORCH blade 2 (r207 — the render-line library face,
    // the MX-1 retirement: the value display render over the §8.8
    // channel; the kernel's eight primitives untouched).
    assert_eq!(
        kerf_vm::Builtin::ALL.len(),
        21,
        "the builtin set carries 21 (the ORCH blade-3 read-edge rows)"
    );
    // The opcode set grew 24 -> 25 at the Stage 2.1 semantic MUV
    // (load-captured, LA-3 — the K192 separated-opcode ruling; the
    // store twin stays unlanded with the immutable-capture subset,
    // LA-7), then 25 -> 26 at W-VM-SUPERINSTR (call-global, the
    // fused load-global + call — w-vm-superinstr-window.md SI-2),
    // then 26 -> 27 at W-JIT-METHOD-T1 (load-local-const, the fused
    // copy pair — w-jit-method-t1-window.md TJ-1; still within the
    // "about 35 opcodes" capability model).
    assert_eq!(
        kerf_compiler::Opcode::ALL.len(),
        27,
        "the opcode set is frozen"
    );
}

// ---------- signal 7: the zero-finding dual ----------

#[test]
fn exit_zero_findings_on_the_two_largest_legal_programs() {
    // (a) the assembled `.ktf` expander twin (self-forms — the 1.8
    // release-and-demand hardening anchor, on the production-chain
    // skin since the r104 E5 batch-3 teardown). The b2 injection
    // channel made the twin channel-legal rather than bare-legal:
    // the struct machinery references the harness-injected
    // `ex-struct-accs` table (the twin-expressibility ruling — no
    // string-building primitive, so the JOIN cannot be computed
    // in-twin), so the attestation rides the deployment face (the
    // steady chain's own build contract: the channel names declared
    // as injected globals, `parse_target_with_injected`). The r168-b2
    // third channel (`ex-enum-ctors`, the injection channel's third
    // case) rides the same face here — the b2 delivery left this
    // list stale (the b3 verification surfaces it; same-family
    // cleanup, §20.3).
    let assembled = assembled_expander_target_source();
    let self_forms = assembled.replace("\ndefine(result, ex_run(forms));", "");
    let injected = [kerf_span::Symbol::new("forms").expect("the forms channel name")];
    let mut s = Session::new();
    let program = kerf::driver::parse_target_with_injected(&mut s, "a.ktf", &self_forms, &injected)
        .expect("the assembly parses");
    let findings = program.typecheck();
    assert!(
        findings
            .iter()
            .all(|d| d.severity != kerf::driver::Severity::Error),
        "assembled expander: {findings:?}"
    );
    // (b) a clean recursive program through the check face (the
    // pipeline's own FIB attestation spelling, r151).
    let mut s = Session::new();
    let out = check_source(
        &mut s,
        "f.ktf",
        "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(r, fib(15));",
    )
    .expect("clean program checks");
    assert!(out.warnings.is_empty(), "zero findings: {:?}", out.warnings);
}

// ---------- signal 9: the full-pipeline dataflow ----------

#[test]
fn exit_full_pipeline_dataflow_end_to_end() {
    let src = "fn add(a, b) { (a + b) }\ndefine(result, add(20, 22));";
    let mut s = Session::new();
    let out = run_source(&mut s, "e2e.ktf", src, Engine::Vm, &[]).expect("full chain");
    assert_eq!(
        out.global("result").map(|v| v.to_string()),
        Some("42".into())
    );
    let mut s = Session::new();
    let check = check_source(&mut s, "e2e.ktf", src).expect("check face");
    assert!(check.func_count >= 2, "entry + one closure proto");
    assert!(check.instr_count >= 5, "instructions emitted");
}

// ---------- the two-layer batch ----------

#[test]
fn exit_two_static_layers_coexist_in_one_batch() {
    let mut s = Session::new();
    let err = check_source(&mut s, "two.ktf", "define(r, if (1) { 2 } else { 3 });")
        .expect_err("the definite condition error");
    let tags: Vec<&str> = err.iter().map(|d| d.code.tag()).collect();
    assert!(
        tags.contains(&"E0003") && tags.contains(&"E0009"),
        "both layers report: {tags:?}"
    );
}

// ---------- the recovery close ----------

#[test]
fn exit_recovery_clean_run_after_a_rejection() {
    let mut s = Session::new();
    let _ = run_source(&mut s, "bad.ktf", "define(r, first(5));", Engine::Vm, &[]);
    let out = run_source(&mut s, "good.ktf", "define(r, (40 + 2));", Engine::Vm, &[])
        .expect("a clean program runs after a rejection");
    assert_eq!(out.global("r").map(|v| v.to_string()), Some("42".into()));
}

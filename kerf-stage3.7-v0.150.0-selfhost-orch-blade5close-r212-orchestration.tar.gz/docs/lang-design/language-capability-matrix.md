# kerf 目标语言能力统计矩阵（language-capability-matrix.md）

> **Status**: v1.35（r212 W-SELFHOST-ORCH 刀 5 收口轮——窗口 CLOSED：**§7「语言内编排与组装面」行 翻 ✓ 终态**〔W-SELFHOST-ORCH CLOSED @ r205-r212——出口判据六条全 ✓（窗口档 §13 收口核对单源）：① 装配桥归零（逐需求桥增殖计数基线 = 0——pub(crate) 编译期锚 + import_composer 金档断言族 + 全仓裸拼清点 = 0）+ ② digest 三方对齐 + ③ fixpoint S1/S2 自载体不动点 + ④ M49 双位终态 + ⑤ 宪制排除收敛三项 + w3.12 §6e 共变注记补落 + ⑥ 零降级自举五刀门全绿；docs-only 收口轮（零源变更 → 指纹不变 → r211 电池 #5 75/75 有效 + 三绿复验）；金链维持 v0.150.0 + 台账维持 v1.26；**计数 93→94 共变：✓64/冻结6/登记12/缺失11**（§7 行 登记→✓）〕）；v1.34（r211 W-SELFHOST-ORCH 刀 4 交付轮——§7「语言内编排与组装面」行 **刀 4 全 DELIVERED 注记**〔M49 重审 + 装配前缀族退役清扫 @ r211——§12 P1-P9 三态裁定：P1 依赖声明入源五件（M49 例外 micro-toml/lockfile verbatim rider 披露）+ P2 STD_ERROR 裸拼接族 12+ 位点退役 → composer 单机制（pub(crate) 编译期增殖锚）+ P3 accs/ctors 表计算语言内化（expander 自种 ex_acc_tables——四消费面退役 + 载体前缀缩位；digest 交叉核捕 Rust 侧漏改即修）+ P4-P7 规约四登记（装载序/参数化/接口双轨/结果通道）+ P8 M49 双位终态 + P9 §2 表翻转 + README 双轨三规约重登记；TD-032 四金档再生成 901s + gate-④ 重钉 4,390 + steady 自种 parity 9/9 + 三方 92.34s；expander 5,083→5,263 + build 1,765→1,609〕）；v1.33（r210 W-SELFHOST-ORCH 刀 3 完成轮——门 ③④⑤ 三副面全落：①**§7「语言内编排与组装面」行 刀 3 全 DELIVERED 注记 + r209 行位漏共变清偿**〔§20.6——r209 主面注记只入 Status 未入行位（行停于刀 2），本轮一并：刀 3 全 DELIVERED @ r210（主面 @ r209 digest 门 + 完成轮 @ r210——TD-034 反向构建手术 31 位点〔release 归因修正披露：kb_ 非主导，密度因子主导——自载体实测为决定判据〕+ census 观测面〔组合层 span-free census 行——§9.25.4〕+ ③ Run A/B 组合粒度不变性 + ④ 里程碑精确行序金档 27,865B + ⑤ fixpoint corpus 入档〔macro 三方 + 自载体 S1/S2 不动点〕）；build.ktf 1,594→1,716；映射表 w-selfhost-orchestration-window §11 r210 终态〕）；v1.32（r209 W-SELFHOST-ORCH 刀 3 主面交付轮——驱动面〔驱动桥退役〕：①**§7「语言内编排与组装面」行 刀 3 主面注记**〔驱动面主面交付 @ r209——build.ktf 编排器孪生（1,594 行第 20 件：种子清单契约读面 + 孪生解析管线 + import 首见组合 + 通道表提取 + 链内展开编译 + 里程碑行流 + 载体装配前缀面）+ string-bytes/bytes-string 双 builtin 19→21（第 163 轮零新原语·零通道·零 VM·零语法——四自持表全量共变）+ digest 门三方对齐（B7 ① 主面：编排器工件 rebuild == Rust oracle 投影——1,915s debug / 420s release）+ 七案族 + T0 32/T1 63/T2 74 全量 fresh 0 红；gate ③④⑤ 副面 = r210 完成轮——用户硬规则「未解决禁推进」纪律〕）；v1.31（r207 W-SELFHOST-ORCH 刀 2 DELIVERED 轮——序列化面〔MX-1 渲染不对称退役〕：①**§7「语言内编排与组装面」行 刀 2 进度注记**〔序列化面交付 @ r207——R1 载体形制（`render-line` 库面全局 builtin 18→19——第 162 轮零新原语：零通道〔§8.8 既有〕·零 VM·零语法〔关键字表 25 不变〕；io.rs「later library concern」行兑现为通道之上的库面）+ R2 词汇包（std/render.ktf 第七件——with_render/perform render：write 先例扩展，副作用在宿主、词汇在语言）+ R3 渲染文法（宿主 Display 单源——身份语言内 + 渲染宿主边缘〔string interning 谱系〕）+ R4 备选权衡（语言内字节表〔lk_num_bytes 先例〕否决于任意值面〔f64 最短往返 parity 负担〕；纯 resume-at-text 登记未来槽；write_line 松绑否决——strict-string 冻结负面不动）+ R5 四孪生注册表共变（ex_globals 影子对 + tc_builtin_arity + ti_is_builtin——第 19 全局四自持表全量）+ R6 皮肤 Rule K 零表增 + R7 语料金档（ef-render 8 案 2:6 + render_vocab 3 案——census == 宿主 Display 逐位三重钉）+ R8 audit BL 10 案〔512→522〕+ C 后端镜像臂 + R9 金链 v0.147.0；金链 v0.146.0 + 台账 v1.22（19 件 23,697）；映射表 w-selfhost-orchestration-window §10 R1-R9 单源〕——窗口 OPEN 维持，刀 3/4/5 待做〕）；v1.30（r206 W-SELFHOST-ORCH 刀 1 DELIVERED 轮——import 表面〔组合桥退役〕：①**§7「语言内编排与组装面」行 刀 1 进度注记**〔import 表面交付 @ r206——O1 皮肤形制（`import "name";`/`import a::b;` 关键字声明双形 → Stx `(import "name")`——关键字表 24→25 三处共变〔Rust lexer + 孪生 lexer + 孪生 parser〕）+ O2 消费分层（组合层独占——composer 唯一消费者，expander/loader/ModuleItem/CP-1 零触碰）+ O3 composer 首见组合（§9.64 MOD-2 纪律 + **M49 种子可读性边界当轮修订**——行载体 verbatim 拼接 + 披露字段 + 端到端 fail-closed）+ O4 单元注册表六件 + O5 三承载件依赖声明 + O6 装配迁移三处（通道位重排披露 + **组合产物字节级金档 ×2**）+ O7 孪生共变（解码器双臂 ×2 + kind 三匹配位）+ O8 自包含工作负载面迁移 ×3 + O9 测试新族 9 案 + reader/parity 案例共变 + TD-032 四金档再生成（r203 纪律）；金链 v0.146.0 + 台账 v1.21（18 件 23,618）+ 8 原语第 161 轮（零新原语——零 ModuleItem 变体 = 语言核心表示零膨胀）；映射表 w-selfhost-orchestration-window §9 O1-O9 单源〕——窗口 OPEN 维持，刀 2/3/4/5 待做〕）；v1.29（r205 §17 Step 1 触发器驱动重扫 + W-SELFHOST-ORCH 开窗行权轮——用户显式排期三句式信号〔「放行继续推进和演进」+「首先首要做的就是完整完全自举……自己用自己语言推进自己」+「每加一个需求就加一座桥 = 不行，可审查去除不必要的」〕：①**§7 新行「语言内编排与组装面」登记**〔W-SELFHOST-ORCH OPEN @ r205——import 表面〔组合桥退役〕+ 序列化面〔MX-1 不对称退役〕+ kerf-build 编排器孪生〔驱动桥退役〕+ M49 重审 + 装配前缀族退役清扫；r124 §6e 议题一重勘：宪制排除收窄 = cargo 构建引导 + VM 基座两项，装配/组合/序列化/驱动四类重分类为可退役桥；r205-search 八检索先例矩阵（Go cmd-go / dune mini-Dune / GHC hadrian 语言内编排 vs rust x.py 少数派）；五刀序 + 出口六条——单源 w-selfhost-orchestration-window.md v1.0〕；②**§11 优先级重排**〔W-SELFHOST-ORCH 升首位实施窗（completion-plan §3 第三段 Phase α）+ 目标语言完整落地计划 β/γ/δ 段排期入 completion-plan v1.54〕；③**计数 92→93 = ✓63/冻结6/登记13/缺失11**〔§7 新行登记 +1；每行单计纪律维持〕）；v1.28（r204 §17 Step 1 扫描轮 + ±1 审计清偿轮——G8+效应族+modern-2 三链闭合后自由排期点第二段行使 @ r204：①**扫描裁定**〔三候选窗触发器逐一核对零信号——并发调度策略窗〔L3 授权 + §5.4 诚实边界——真调度器 = 策略替换位后续窗〕/语法糖窗〔try/catch/`?` 表面糖——#15 依赖面〕/**深链自举扩展裁定 = 宪制边界内终深度**〔生产链面 18 件 .ktf 23,493 行全承载〔v1/ 十二件 + std/ 六件〕+ 宪制排除面三族〔VM Rust 基座 / cargo 构建引导 r124 裁定 / 编排层 w3.12 裁定——含装配前缀族与用户表面〕+ 诚实边界已裁定族〔M49 冻结 Rust reader r184 行词汇不可表达 + C5 无自然形 + 边界②③〕——零新可扩展段就绪 → 零开窗，登记态维持〕；r195 十一候选窗其余项零信号维持〔TD-029 / 横切九窗 / W-3.x 族 / 缺失候选族〕；②**v1.21 登记审计首项清偿**〔工具链域行 LSP 双态**单行单计**去重：缺失 4→3 + 管道域行 16→**17**〔自举源现代化二行 r203 翻 ✓ 未入域行——v1.2 登记时即未入域，r203 翻 ✓ 时域行未共变〕+ 合计行 登记 11→**12** / 缺失 12→**11**——全盘 92 行逐行重数实测：✓63/冻结6/登记12/缺失11，域行合计与合计行双侧一致；归态口径注记 r204 增注；能力边界确认 = 单皮肤 .ktf 全管道自举 + HM/行多态/效应族六实例 + kp 自举 + fixpoint 自复现，缺失面全登记态零信号（浮点/插值/守卫子句/可见性/泛型显式参数化/数值库/集合库/LSP/文档生成/交叉编译/真调度器/线性/联合/comptime 值层/分代 GC/superinstr/extern 堆句柄）〕）；v1.27（r203 W-SELFHOST-MODERN-2 刀 6 DELIVERED + 窗口 CLOSED 轮：**§7「自举源现代化二」行 翻 ✓ 终态**〔W-SELFHOST-MODERN-2 CLOSED @ r203——出口判据六条全 ✓：六刀全 DELIVERED（刀 1 pkg 试点 @ r196 + 刀 2 pkg 三件 @ r197 + 刀 3 判定/词法 @ r198 + 刀 4 编译/宏 @ r200 + 刀 5 展开/宏 @ r201 + 刀 6 解析/推断收官 @ r203——target-parser.ktf 5,122→4,648〔C2 解析拒绝族 M77 九 raise 位 + 101 守卫溶解 + 入口 attempt 契约面 + C1 M78 done 死头 21 位丢弃〕+ infer.ktf 5,532 零变更三面关闭〔M74/M75/M76〕+ **TD-032 CLOSED（差分语义升级）**：matches! 豁免集撤销 + 四源金档钉死〔fixtures/ 字节级 + regen 测试面 + 结构锚保留 + AZ08 中央分类器〕+ M79 harness 共变〔STD_ERROR 三装配位 + 稳链 parser 层 eval 轴退役 + eval_inventory C8→C7 pin 32→31〕+ M81 C4 金档钉〔ei08/ei09——INST-3 §5.3 欠账收口〕；金链 v0.145.0 + oracle 零文件 + 8 原语第 158 轮；**12/12 件效应族链表面消费终态**〕+ **§7 台账行实测口径更新〔18 件 23,967→23,493——target-parser −474 wc 实测〕 + 计数共变：登记 12→11 + ✓62→63〕**）；v1.26（r201 W-SELFHOST-MODERN-2 刀 5 DELIVERED 轮（展开面/宏遮蔽族对交付 @ r201——expander.ktf 5,286→5,085 + macro.ktf 751→753：C2 展开拒绝族 M59-M65（ex_fail 体 perform raise——单构造位改体零调用位 + 44 dead-nil + 1 续行 + 39 守卫溶解 + 6 between 双形 + ex_run 契约面——种子八项 thunk 外纯函数实证）+ 遮蔽族两份共变 M68-M71 + C1 评估关闭 M72（零死头活 tag 普查） + M73 harness 共变（STD_ERROR 两装配位 + TD-032 扩展 ccf-expander + 稳链 eval 轴退役 C9→8） + 段开关 39/39 + fixpoint B≡C + T0 29/29 + T1 59/59 + T2 fresh 70/70 + 金链 v0.143.0→v0.144.0 + oracle 零文件） + **§7 台账行实测口径更新〔18 件 24,166→23,967——expander −201 + macro +2 wc 实测；modern-2 消费已入 10 件（pkg 五件 + 判定/词法双件 + compiler + expander〕））；v1.25（r200 W-SELFHOST-MODERN-2 刀 4 DELIVERED 轮〔r199 手术随收割丢失，r200 锚恢复后全量重执行〕：**§7「自举源现代化二」行 刀 4 进度注记**〔编译面/宏面对交付 @ r200——compiler.ktf 1,968→1,917 + macro.ktf 733→751（勘定零代码）：C2 编译拒绝族 M50〔八错误构造位全量 perform raise 短路——载荷 = 契约面 err 记录逐位〕+ M51 七守卫溶解〔cp_err 单元退役〕+ C1 M53/M54〔estate 5→4 槽 / proto 9→8 槽判别头死数据丢弃——~85 proto 读位整体移位；产物面 render 重建 "proto" 头〕+ M55 cp_run 契约面 unwrap(attempt(thunk), ||(e){e})〔result define 逐字节冻结〕+ M57 handle 域烘焙勘定〔编译对象面非自用面〕+ M58 harness 共变〔STD_ERROR 前缀七装配位 + ktf_compile_rich eval 轴退役 + eval_inventory 台账六文件退役 39→33 + superinstr 篡改锚 40→36 列共变 + TD-032 matches! 扩展 ccf-compiler〕 + 零新探针〔P1-P13 事实集全覆盖〕+ 段开关 39/39 + fixpoint B≡C 位级 + T0 29/29 + T1 59/59 + T2 fresh 70/70 EXIT 0 + 金链 bump v0.142.0→v0.143.0 + oracle 零文件〕 + **§7 台账行实测口径更新〔18 件 24,199→24,166——compiler −51 + macro +18 wc 实测；modern-2 消费已入 8 件〔pkg 五件 + 判定/词法双件 + compiler〕；macro 勘定零消费〕〕）；v1.24（r198 W-SELFHOST-MODERN-2 刀 3 DELIVERED 轮：**§7「自举源现代化二」行 刀 3 进度注记**〔判定/词法面双件 + compiler 连锁修复交付 @ r198——target-lexer.ktf 1,069→1,128 + typecheck.ktf 1,264→1,304 + compiler.ktf 1,958→1,968（M47 连锁）：C2 词法拒绝族 M35-M38〔29 错误构造位全量 perform raise 短路 + 契约面 unwrap(attempt(thunk), identity) 包装——外部 ok/err 记录位级冻结〕+ C1 表示清理 M39-M45〔判别头死数据丢弃 + 嵌套 pair 模式化——**M49 Rust reader 边界修正裁定**：链内嵌件经冻结 Rust reader 构造，r184 行词汇不可表达，裸值链承载〕+ 边界②勘定 M42〔typecheck 零 C2——ruling 21 累积架构〕+ M46 harness 六件共变〔STD_ERROR 前缀装配 + 双轴→单轴 + steady lexer 层 eval 退役〕+ **M47 compiler handle 发射位真缺陷当轮清偿**〔链源首次携带 handle 暴露 B != C 双红——cp_return_effect 预 intern 改 cwalk 循环内计算，oracle in-loop 形制对齐〕 + **M48 infer 差分 × r188 typed-perform pin 设计性碰撞 → TD-032 结构锚豁免**〔刀 6 收口〕 + 零新探针〔P1-P13 事实集全覆盖〕 + parity 关联族全绿 + T2 fresh 70/70 EXIT 0 + 金链 bump v0.141.0→v0.142.0 + oracle 零文件；性能 §9.5 八族方差带内零回退〕 + **§7 台账行实测口径更新〔18 件 24,090→24,199——target-lexer +59 + typecheck +40 + compiler +10 wc 实测〕〕）；v1.23（r197 W-SELFHOST-MODERN-2 刀 2 DELIVERED 轮：**§7「自举源现代化二」行 刀 2 进度注记**〔组合程序族三件交付 @ r197——manifest.ktf 525→545 + lockfile.ktf 675→703 + resolve.ktf 517→544：C2 Error 词汇消费 M17-M32〔33 err 穿线位全量 perform raise 短路 + 契约面 unwrap(attempt(thunk), identity) 包装——外部 ok/err 记录位级冻结〕+ C1 行词汇 M33/M34〔lk_field 裸行字面量 + lk_items_walk 封闭行模式——P12 往返恒等〕+ C5 State 世代穿线评估**关闭**〔无自然形，边界③〕+ 探针法证 P11-P13 跑后删〔四条语言面事实：== 数值专用 / match 尾逗号 / 嵌套位字面头 E0009 / pair 即 cons 平链〕+ harness 面零改动（r196 M15/M16 已覆盖）+ parity 六族绿 + T2 fresh 70/70 EXIT 0 + 金链 bump v0.140.0→v0.141.0 + oracle 三件零文件；性能 §9.3 五族 ±2% 零回退〕 + **§7 台账行实测口径更新〔18 件 24,015→24,090——manifest +20 + lockfile +28 + resolve +27 wc 实测〕 + 同类披露：转化台账 §2 头 v1 口径停摆自 r188（r196 刀 1 未共变）——本轮一并清偿 23,680→23,776，§20.6〕）；v1.22（r196 W-SELFHOST-MODERN-2 刀 1 DELIVERED 轮：**§7「自举源现代化二」行 刀 1 进度注记**〔试点双件交付 @ r196——semver.ktf 337→340 + micro-toml.ktf 662→680：C2 Error 词汇消费 M1-M12〔内部 perform raise 短路 + 契约面 unwrap(attempt) 包装——外部 ok/err 记录位级冻结〕+ C1 开帧行字面量/行模式 M13/M14〔运行时值逐位同 cons 链〕+ 装配面 M15/M16〔STD_ERROR 前缀 + 五 pkg parity 族 drive_vm_only 切换——eval 轴退役 K15 诚实账 + TD-031 登记〕+ 探针法证 P1-P10 跑后删 + parity 六族绿 + T2 fresh 70/70 + 金链 bump v0.140.0 + oracle 三件零文件；性能 §9.1 五族 ±2% 零回退〕 + **§7 台账行实测口径更新〔18 件 23,994→24,015——semver +3 + micro-toml +18 wc 实测〕**）；v1.21（r195 §17 Step 1 扫描轮 + W-SELFHOST-MODERN-2 开窗行权轮——效应族链闭合后自由排期点首次行使：①**扫描裁定**〔11 候选窗触发器逐一核对零信号——并发调度策略窗〔L3 授权〕/语法糖窗〔#15 依赖〕/W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN/共享污染 P2/TD-029/横切九窗/W-3.x 族/缺失候选；单源 tech-debt r195 检视〕；②**W-SELFHOST-MODERN-2 OPEN @ r195**〔四触发器全达成（效应族能力里程碑 @ r194 + 零更高优先自举段 + 验证安全网在位 + 用户显式排期）；前置门四件全过（§3.3 提案 = w-selfhost-modern2-window.md v1.0 本体 / r195-search 六检索〔rustc 自源采纳 / GHC 扩展分阶 / OCaml 内部 / JEP 440 record 模式 vs 访问器 / OCaml 5 效应错误处理 / bootstrap 循环〕 + 8 原语第 152 轮设计面 + 孪生可表达性 ✓〕；实测勘定：12 件零行字面量消费 + ~900 first/~810 rest 标签键导航位 + ~107 "err" 穿线位；消费分类学 C1-C5 + 诚实边界五条 + 零新桥承继（r174 终局裁定）；§7 新行登记 + §11 优先级 2 位注记升级〕；③**计数表三处漏翻同轮清偿（§20.6 披露）**：r180 modern-1 域行+合计漏翻（§7 行已 ✓ 但计数仍登记）+ r189/r194 效应域行漏翻（机制/六实例两行已 ✓ 但域行仍 0✓）——本轮全部修正（管道 14✓/1登记→15✓/1登记〔modern-1 翻 ✓ + modern-2 新登记〕；效应 0✓/3冻结/2登记→2✓/3冻结/0登记）；合计 91→92 项 = ✓62/冻结6/登记12/缺失12（modern-1 漏翻补 +1✓ −1 登记，modern-2 新登记 +1）；**残留审计项披露：工具链域行 15 计数 vs 14 行在盘（LSP 双态计数口径〕——域行合计 61✓ vs 合计行 62✓ 的 ±1 差值骑 LSP 行，下一矩阵审计轮首项**〕）；v1.20（r194 W-EFFECT-INSTANCES 刀 3 DELIVERED + 窗口 CLOSED 轮：**§5「效应族六官方实例」行 翻 ✓ 终态**〔W-EFFECT-INSTANCES CLOSED @ r194——出口判据六条全 ✓：三刀全 DELIVERED（刀 1 纯语言三件 State/Error/Log @ r192 + 刀 2 IO 桥两件 Read/Write @ r193 + 刀 3 Async 同步直通退化形 + 收口 @ r194——selfhost/std/async.ktf（with_async：§9.14.2 Async 行零偏离——同步直通退化策略 + §5.4 诚实边界出口注记〔真调度器 = 策略替换位后续窗，L3 授权域，零通道 8 原语冻结维持〕）+ §5.8 开刀定案三实证〔探针后删：再入路由 B=42（handler 子句体期间存活——oneshot_entry 快照不弹）+ 严格 thunk 面 C（call callee must be a closure——运行时面）+ k 形探针滑落 D（双操作数 → 退化 invoke k 槽收原始操作数）〕+ 语料 ef-async-* 8 案〔2:6 = 1:3，四臂全覆盖〕+ sweep 五族化〔六库前缀 + 人口门 32→40 + 臂门 8/3/3/18→10/4/4/22〕+ 机制 sweep 排除滤网 ef-async- 扩展〔新族共变义务同 commit 预付——r193 数训应用〕+ audit Section BK 10 案〔502→512 live EXIT 0 + 守卫四处共变〕+ T2 fresh 全量 + **金链 bump v0.138.0→v0.139.0**〔窗口 CLOSED 里程碑——r189 先例；刀 1/刀 2 词汇包轮维持先例〕；**效应族三段链全链闭合 @ r194**（行类型基础→机制地基→官方词汇面——“统一而分治”模型实例级终验）〕 + **计数 91 项共变：✓61 / 冻结6 / 登记12 / 缺失12**（登记 13→12 + ✓60→61） + §7 台账行实测口径更新〔17→18 件 23,953→23,994 行——std/ 六件 314 行 wc 实测〕 + §11 优先级 2 位 CLOSED 注记〕）；v1.19（r193 W-EFFECT-INSTANCES 刀 2 DELIVERED 轮：**§5「效应族六官方实例」行 刀 2 进度注记**〔IO 桥两件 Read/Write 交付 @ r193——selfhost/std/ 续两件（read.ktf with_read〔§9「resume 单射」——处理器体 read_line() 桥 BufferIo 宿主通道 + 种子行续体注入〕/ write.ktf with_write〔§9「resume + 副作用驻处理器体」——write_line(payload) 副作用在子句体 + k(nil) 完成确认续体；组合纪律 = thunk 链 with_read(|| { with_write(p) })——实参位嵌套 = 应用序求值边界，语料负例钉死〕）+ 语料族 ef-io-* 8 案〔正 2 负 6 = 1:3，四臂全覆盖，io-in/io-out 双向缓冲钉死约定〕+ sweep 四族化〔三库前缀→五库 + 种子通道面〕+ audit Section BJ 10 案〔492→502 live EXIT 0 + 守卫四处共变〕+ 机制 sweep 排除滤网 ef-io- 扩展〔新族共变——首跑红一次后修〕+ T2 fresh 70/70 全绿〔§19.3 无豁免——指纹变更后全量重跑〕+ BufferIo api 面回归零扰动〔kerf-vm lib 63/63〕；8 原语第 150 轮构造性维持（词汇包零机制变更）；台账 15→17 件 23,849→23,953 行——窗口 OPEN 维持，刀 3 Async+收口待做〕 + **§7 台账行实测口径更新〔含 r192 漏共变清偿：v1.18 头声明「12→15 件 23,680→23,849」但表行未动——本轮一次到位 17 件 23,953，同类披露 §20.6〕**）；> **Status**: v1.18（r192 W-EFFECT-INSTANCES 刀 1 DELIVERED 轮：**§5「效应族六官方实例」行 刀 1 进度注记**〔纯语言三件 State/Error/Log 交付 @ r192——`selfhost/std/` 新标准库区首三件（state.ktf 状态代链 INST-6 裁定〔探针三实证 + polysemy Tactics 同构——put 保 k 形签名 + halt 体，state_thread 世代递归〕/ error.ktf attempt+unwrap〔halt 形 + return 成功路径零偏离〕/ log.ktf with_log+with_log_via〔退化形 + 门面注入〕）+ 语料族 24 案〔ef-state-*/ef-error-*/ef-log-*——每族正 2 负 6，6:18 = 1:3 整，四臂全覆盖〕+ efx_instance_sweep〔INST-1 通道 (a) 前缀注入〕+ audit Section BI 12 案〔480→492 live EXIT 0 + 守卫四处共变〕+ T2 fresh 70/70 全绿〔§19.3〕；8 原语第 149 轮构造性维持（词汇包零机制变更）；台账 12→15 件 23,680→23,849 行——窗口 OPEN 维持，刀 2 IO 桥两件/刀 3 Async+收口待做〕 + §7 台账行实测口径更新〕）；> **Status**: v1.17（r191 段 3 效应族实例窗开窗行权轮：**§5「效应族六官方实例」行 注记升级**〔登记〔实施窗 W-EFFECT-INSTANCES OPEN @ r191——效应族三段链段 3·链末段：六实例 = 冻结机制之上的词汇包（handler + perform 组合，全部落在 Perform/Handle 冻结原语集内——零机制变更义务）；双前置达成 @ r189（段 2 W-EFFECT-MECHANISM CLOSED + w-effect-mechanism-window §9 六实例消费位接口冻结）+ 前置门四件全过（r191-search 六检索五范式家族 + Rust 惯例锚〔m1 Koka stdlib handler 库 / m2 OCaml 5·Eio direct-style IO / m3 Unison abilities / m4 Effekt 词法 handler / m5 Haskell freer 词汇包最强证据 / m6 Rust Result·? 表面糖惯例〕+ 8 原语第 148 轮设计面 + 孪生可表达性 ✓）；单源 w-effect-instances-window.md v1.0——三刀序（刀 1 纯语言三件 State/Error/Log → 刀 2 IO 桥两件 Read/Write〔BufferIo 宿主通道〕→ 刀 3 Async 同步直通退化形 + 收口）+ 实施裁定五条 INST-1..5（载体 = selfhost/std/ 库位 + 语料双面 / 三种子句形分族 / 行类型骑箭头四元槽 / 载体分层实施序 / audit·sweep 逐刀扩展）；窗口 CLOSED 时本行翻 ✓〕 + **§11 优先级 2 位段 3 升当前实施位**（段 2 CLOSED @ r189 → 段 3 OPEN @ r191）+ 计数 91 项维持〔✓60/冻结6/登记13/缺失12——实施窗 OPEN 不改登记列计数，窗口 CLOSED 翻 ✓ 时共变→✓61/登记12〕〕）；v1.16（r189 W-EFFECT-MECHANISM 刀 3 DELIVERED + 窗口 CLOSED 轮：**§5「代数效应 + 处理程序机制」行 翻 ✓ 终态**〔W-EFFECT-MECHANISM CLOSED @ r189——出口六条全 ✓：三刀全 DELIVERED（刀 1 值层/VM one-shot 语义深化 @ r187 + 刀 2 infer.ktf 效应行推断消费 @ r188 + 刀 3 语料/audit/收口 @ r189——corpus-effect 28 案四裁决臂 sweep + audit Section BH 10 案〔470→480 live EXIT 0〕+ r185-r188 守卫盲区同路径修复 + 段 3 前置接口冻结〔§9 六实例消费位形状〕）；零生产面文件——8 原语第 146 轮构造性维持；段 3（效应族实例窗）开窗前置就绪〕 + **计数 91 项共变：✓60 / 冻结6 / 登记13 / 缺失12**（登记 14→13 + ✓59→60——含 v1.12 表行漏翻清偿：彼轮声明 59/6/14/12 但合计表行未动，本轮 58→60 / 15→13 一次到位）+ §11 优先级 2 位 CLOSED 注记〕）；v1.15（r188 W-EFFECT-MECHANISM 刀 2 DELIVERED 轮：**§5「代数效应 + 处理程序机制（刀 2 推断消费 @ r188）」行 刀 2 进度注记**〔效应行推断消费全量落地自举生产位——infer.ktf 4,922→5,532：箭头携行四元槽 `("fn" P R row)` + res 记录第五槽类型行轨 + ti_handlers 上下文栈/hres 任务 + 覆盖子句 perform 三态定型〔退化=子句返回类型+参数合一钉位 / k 形式=k 箭头首参续体恢复 / 无覆盖=新鲜续体元变量+行扩展 e:opT（m1 Koka 同调——op 类型即续体类型）〕+ handle 类型行扣除合并 + halt/body 返回类型合一〔r187 类型缺口闭合——E0013 面〕+ 五 walk 机族 row 槽臂 + arrow spec 三载荷 + schema vars 泛化面；oracle 三件零文件机检〔r174 冻结第三刀〕+ 金档 25 案 1:3〔effect_infer〕+ 双引擎一致 lane 承载 pos-021/neg-034/neg-035 三语料行 + handle-rows 四测试族豁免 + T2 68/68；窗口 OPEN 维持，刀 3/close 待做〕）；v1.14（r187 W-EFFECT-MECHANISM 刀 1 DELIVERED 轮：**§5「代数效应 + 处理程序机制（刀 2 推断消费 @ r188）」行 刀 1 进度注记**〔值层/VM one-shot 语义深化全量落地——续体值（Value::Continuation 类 2 族·Invoke 通道复用）+ ext2 OneShotMark（§9.15.7③ 预留方向兑现）+ k 形式元数约定（clause params==args+1——检查面顶层立即 perform 仍严格 E0005〔neg-034 钉死不动〕，fn 体内动态通道承载）+ `return` 子句经 pop-handler b 位〔+1 哨兵——`return` 恰 0 号全局的撞车实勘〕路由 + degenerate 形位级零漂移；金档 6:18〔T1〕+ T0 五案〔复用族原生 home〕+ T2 67/67 + fixpoint 位级 + oracle 三件零文件机检——窗口 OPEN 维持，刀 2/3 待做〕；v1.13（r186 恢复清偿 + 效应机制窗开窗行权轮：**§5「代数效应 + 处理程序机制」行 注记升级**〔登记〔实施窗 W-EFFECT-MECHANISM OPEN @ r186——效应族三段链段 2：handler/perform one-shot 可恢复语义深化 + 效应行推断消费（infer.ktf 孪生生产位——P2 形状→消费面闭环）；双前置达成 @ r185（段 1 CLOSED + P2 接口在位）+ 前置门四件全过（r186-search 六检索五范式家族〔m1 Koka Leijen 2014 被引 261 行合一字面改编 / m2 OCaml 5 one-shot / m3 Eff·Effekt 直接风格 / m4 Unison abilities / m5 Haskell freer 否决记录 / m6 Boolean 合一否决〕+ 8 原语第 142 轮设计面 + 孪生可表达性 ✓）；单源 w-effect-mechanism-window.md v1.0；同轮 r185 P1 递延清偿 = T2 长族 fresh 全量 66/66 绿（steady_route 7/7 + fixpoint 17 + abc_pipeline 6/6 + doc + audit 470——§3.2.1 分块 5 chunks）〕+ 计数 91 项维持〔实施窗 OPEN 不改登记列计数——窗口 CLOSED 翻 ✓ 时共变〕）；v1.12（r185 W-ROW-POLY 刀 3 + 窗口 CLOSED 轮：**§4 行多态行 翻 ✓ 终态**〔W-ROW-POLY CLOSED @ r185——出口六条全 ✓：三刀全 DELIVERED（刀 1 类型层内核 @ r182 + 刀 2 皮肤/消费/桥 @ r184 + 刀 3 语料/audit 460→470/P2 效应行形状冻结 @ r185——corpus-row 28 案 + sweep + row_effect_shape 6 案 + audit BG 10 案）；效应机制窗〔链中段〕开窗前置就绪〕+ **计数 91 项共变：✓59 / 冻结6 / 登记14 / 缺失12**（登记 15→14 + ✓58→59）+ §7 台账行实测口径维持〔22,989 @ r184——r185 生产面零改动〕+ §11 优先级 1 位 CLOSED 注记）；v1.11（r184 W-ROW-POLY 刀 2 实施轮：§4 行多态行 进度注记〔刀 2 DELIVERED @ r184——读链 + 展开器消费面 + 注解类型桥自举生产位落地：`[l: T; tail]` 注解皮肤 + 行字面量/行模式读位（皮肤形实勘修正——`|` 三重职责冲突 → `;` 分隔裁定）+ cons 链右折叠 + pcvar 族位移模式 + 封闭 nil 守卫 + 注解面 row×pair 桥（动态地板尾）；金档 24 案 1:3 + corpus-row/ 26 案 + T1 54/54 + fixpoint 17/17 + audit live EXIT 0 + oracle 三件零文件机检（r174 冻结第二刀）；窗口 OPEN 维持——刀 3/close 待做〕+ §7 自举台账行实测口径更新〔21,793→22,989——target-parser 4,424→5,122 + expander 4,850→5,286 + infer 4,860→4,922〕）；v1.10（r182 W-ROW-POLY 刀 1 实施轮：§4 行多态行 进度注记〔刀 1 DELIVERED @ r182——类型层内核全量落地自举生产位：行类型 pair 复合表示 + 行合一五规则机 + 四 walk 机族 row 臂 + 泛化/实例化行变量生效（schema vars 捕获）+ Display 面 row 臂；金档 24 案 1:3 + fresh T2 64/64 + oracle 冻结机检零文件（r174 裁定首个适用者执行）；窗口 OPEN 维持——刀 2/刀 3 待做〕+ §7 自举台账行实测口径更新〔21,445→21,793——infer.ktf 4,512→4,860 行代数内核 +348〕）；v1.9（r181 §17 Step 1 扫描轮 + W-ROW-POLY 开窗行权轮 + 完整落地总规划轮——用户指令⑥「规划完整 kerf 目标语言完整语法语义等方面的完整落地纳入计划」显式排期信号：①**§4 行多态行 注记升级**〔登记〔实施窗 OPEN @ r181〕——触发器①链式达成：效应族进入实施排期 = GZ-5 需求触发器①；前置门四件全过（r181-search 六检索五范式家族 + §3.3 提案 + 8 原语第 138 轮 + 孪生可表达性 ✓）；r174 冻结裁定首个适用者——oracle 零改动，金档/fixpoint/audit 验证；窗口 CLOSED 时本行翻 ✓〕；②**§11 优先级重排**〔W-ROW-POLY 升首位实施窗 + 效应族三段链第 2 位（段 2 效应机制窗 + 段 3 效应族实例窗——completion-plan §3 单源）+ W-SELFHOST-MODERN 移出（CLOSED 入 §7 台账）〕；③计数 91 项维持〔✓58/冻结6/登记15/缺失12——实施窗 OPEN 不改登记列计数，窗口 CLOSED 翻 ✓ 时共变〕）；v1.8（r180 W-SELFHOST-MODERN 刀 6 收官 + 窗口 CLOSED 轮：§7 自举台账行实测口径更新〔21,382→21,445——现代化刀 6 收官双件表示恒等重写，infer 4,471→4,512 + target-parser 4,402→4,424〕+ 现代化行 ✓ 终态翻正〔窗口 CLOSED——12/12 全上 G8 表面；W 机核心 M50 + 帧机 M59 + 守护相位机族 M60 + token/datum 表 M61 + 注解族 M57/M64——tp_ha/tp_ma nil 占位与 ti_member/ti_row_push 混合域经 checker 立捕诚实裸名〕+ §11 优先级 1 位 CLOSED 注记 + §7 注记中 v1.7 头漏〔r179 实况漂移——本行清偿：r179 矩阵体更新已落（刀 5 行 + 21,382 台账），Status 头漂移未记 v1.7，本轮并入 v1.8 头声明〕）；v1.6（r178 W-SELFHOST-MODERN 刀 4 轮：§7 自举台账行实测口径更新〔21,254→21,274——现代化刀 4 编译面 + 宏面两件表示恒等重写，净 +20〕+ 现代化行刀 4 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；CP 两遍分派 M31-M36 + 宏库保守面 M37/M38 + 注解族 M39/M40 + 遮蔽族冻结 + fixpoint 载体自应用 17/17〕+ §11 优先级 1 位进度注记）；v1.5（r177 W-SELFHOST-MODERN 刀 3 轮：§7 自举台账行实测口径更新〔21,272→21,254——现代化刀 3 判定面 + 词法面两件表示恒等重写，match 臂化净 −18〕+ 现代化行刀 3 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；标量 tag 表 M21 + 被调分析 pair 模式 M25 + 算符极长匹配整型臂顶层分派 M27〕+ §11 优先级 1 位进度注记）；v1.4（r176 W-SELFHOST-MODERN 刀 2 轮：§7 自举台账行实测口径更新〔21,186→21,272——现代化刀 2 组合程序族三件表示恒等重写〕+ 现代化行刀 2 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；struct 型字段首例消费 M13/M14 + 顶层 nil 模式首例 M19〕+ §11 优先级 1 位进度注记）；v1.3（r175 W-SELFHOST-MODERN 刀 1 轮：§7 自举台账行实测口径更新〔21,094→21,186——现代化刀 1 表示恒等重写〕+ 现代化行刀 1 DELIVERED 进度注记 + §11 优先级 1 位进度注记）；v1.2（r174 过时清偿 + 现代化窗登记轮：①两处实况漂移清偿〔selfhost/README.md 七件旧态→十二件实况 21,094 重写 + 转化台账 r160 后 10 轮失账合并补账 17,154→21,094〕②W-SELFHOST-MODERN 登记〔§7 新行——四触发器全达成，六刀序 + oracle 冻结桥终结裁定〕③§11 优先级重排〔现代化窗升首位——自举段最高优先级 §21.12-28〕；v1.1（r172 触发器定义补全轮——决策-实况缺口族三行登记态升级〔交叉/联合 + 线性：缺失→登记〕+ 编译期求值补行〔v1.0 遗漏清偿——§6.10.2 行 6 半承载拆账〕+ 计数 89→90 = ✓58/冻结6/登记14/缺失12 + §11 优先级表重排〔三窗入列 3/4/5 位〕+ §12.4 触发器定义义务闭环转常设；触发器单源 = w-decision-gap-windows.md v1.0；v1.0 = r171 首版——G8 语言基础闭合后首个自由排期点 · §17 Step 1 下一窗扫描的结构化产出）
> **承载**: 用户常设指令④实体——「kerf 目标语言在词法语法语义等编译管道全阶段的对应优秀编程语言对应阶段任务和能力项的完成与剩余统计与记录（以便 agent 或者审批去检查和规划 kerf 目标语言的实施以及是否存在缺失等情况）」
> **流程权威**: docs/sop.md v15.6（**SOP 接入 @ r173 兑现**——六编辑点：Version 头 v15.5 / §8.4.5 查询表新增矩阵行 / §17.2 Step 1 扫描表新增矩阵行 / §8.5 审查清单第 17 项〔每窗开闭必检共变〕/ §21.12 第 34 条〔本矩阵纪律条款〕/ §8.4 目录树补矩阵行；此前 v1.0/v1.1 头部所引「v15.4（§17.2 扫描…§8.4.5 查询表）」系前置规划声明、未伴随 SOP 实体接入——r173 当轮清偿，§8.4.5 规则 2 同型；r174 顺更 v15.5→v15.6〔§3.2.1 收割恢复协议——矩阵轮次验证面执行纪律的流程承接〕）——现行流程面 = §17.2 扫描 / §21 阶段规划 / §2.2 原则 34 能力架构 / §8.4.5 查询表 / §8.5 第 17 项 / §21.12 第 34 条六点
> **单源声明**: 本矩阵 = 能力清单的**汇总视图**（唯一新增职责 = 全阶段完成/剩余统计 + 优先级输入）；各能力项的**实施细节单源**仍为其各自窗口档/规范文档（subset-spec / stage0 §6.10/§9.14.2/§9.15 / 各 w-*-window.md）——本矩阵只引用不重复（§3.3 路由>通读；反重复漂移纪律）。
> **冷启动注记**: lang-design/ 为冷启动降级位（README §0——25 拆分文件不可达，stage0.md 代偿）；本文件为**新建实体**非伪造拆分文件，落位于查询表第一层权威目录（§8.4.5）。
> **宪制排除项**: VM 永久 Rust 基座 / 构建引导层（cargo）/ 链外后端（C/LLVM）——不计入「完全脱离」分母，矩阵中以〔宪制排除〕标注。

## 0. 统计口径

| 状态 | 定义 | 锚要求 |
|---|---|---|
| ✓ 已交付 | 生产位可用且有机检（测试/audit/parity） | 版本号 + 轮次 + 单源文档 |
| ✓ 设计冻结 | 冻结面声明 + 不变性守卫在位（未到实施窗口） | 规范章节 + 守卫锚 |
| 登记 | 独立窗口已登记、触发器定义在案、零信号不开窗 | 窗口名 + 触发器单源 |
| 缺失 | 设计蓝图有决策或同类语言标配、本项目无承载无登记 | 参照锚 + 候选路径 |

维护纪律见 §12：每窗开/闭/DELIVERED 必共变本矩阵（GATE 3 条款引用义务的查询位之一）。

## 1. 词法面（subset-spec §1.4-§1.5 单源）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 字面量 6 种 + 原子 | ✓ 冻结 | subset-spec §1.4；Stage 1 验收语料 68 条 | Scheme/ML 原子面 | 8 原语不变性第 127 轮验证（tech-debt r170） |
| 关键字 token 族（KwStruct/KwEnum 等胖关键字） | ✓ 冻结 | subset-spec §1.1；G1 目标皮肤读链 | —— | 关键字 = 表面 token 非原语面（r168/r170 裁定） |
| 注释文法 | ✓ 冻结 | subset-spec §3.2 分布（注释共变 r170） | C 族行注释 | 单皮肤 .ktf 终态（G7 拆除 S-expr 注释面 r154） |
| 类型注解词法 `: T` 面 | ✓ | 刀 1 @ r165 · v0.121.0 | OCaml/Scala 注解 | parse-and-drop 终结——注解 = 表面糖 HM 层 owns |
| 浮点/字节/字符字面量 | 缺失 | —— | Rust/Go 数值面 | 候选：Int 既有位扩展（零原语约束下 = 词法+内建层扩展）；触发器 = 数值语料需求 |
| 字符串插值 | 缺失 | —— | Rust `format!`/Koka | 候选：脱糖面（format 内建 + 表面糖）；零信号 |

## 2. 语法面（subset-spec §1.1-§1.3 + 派生表面层）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 声明头 4（模块顶层唯一合法形式） | ✓ 冻结 | subset-spec §1.1 | Scheme 模块面 | 冻结纪律 §5 |
| 表达式特殊形式 8 | ✓ 冻结 | subset-spec §1.2 | Scheme 特殊形式族 | —— |
| 核心构造子 9 + 模块项 4 | ✓ 冻结 | subset-spec §1.5 | —— | dstruct/denum = 零码 item（Annotate 先例） |
| struct 声明表面 + 构造/访问脱糖 | ✓ | 刀 2 @ r166 · v0.122.0（GZ-2/GZ-3） | Rust/Haskell record | 「struct = 派生表面非原语面」——pair 链右折零标记 + Type::Struct 名义透明展开 |
| enum 声明表面 + tagged 构造/消费脱糖 | ✓ | 刀 3 @ r168 · v0.124.0（GZ-4） | Rust/OCaml ADT | cons(tag, 右折) + ctor define 单源 + E-Variant 复合名 |
| match 模式文法（variant/struct/字面量/绑定/通配） | ✓ | 刀 3 @ r168 + 刀 4 @ r170 · v0.125.0 | Rust/ML 模式族 | 穷尽性三判式（r170 §11.1）；双查表消歧序（enum→struct→六模式族） |
| 嵌套模式（递归） | ✓ | 刀 4 @ r170（pos-404 嵌套 8 案） | ML 嵌套模式 | 零位移字段公式 car(cdr^k s) |
| 守卫子句（match guard） | 缺失 | —— | Rust `if` guard / Haskell | 候选：脱糖面（if 嵌套展开）；触发器 = 语料需求 |
| 中缀运算符表面 | 缺失（设计排除） | G7 单皮肤裁定 r150-r154 | —— | .ktf 皮肤 = 括号+胖关键字形制；中缀面 = 皮肤域议题（Stage 2b 已被单皮肤终态吸收——不追溯） |
| 自定义效应语法 | 登记 | 窗口档 §4.5 后续行；stage0 §9.15 | Koka `effect`/Unison | 零信号不开窗 |

## 3. 语义面（subset-spec §2 单源）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 闭包词法捕获（完整语义面） | ✓ | Stage 2.1 翻转 v0.50.0 + §2.2 收口 v0.51.0 | Scheme/ML 闭包 | LA-2 捕获描述符 |
| 顺序绑定 define-so-far | ✓ | subset-spec §2.2 | Scheme 顶层序 | —— |
| 顶层即时位效应 | ✓ | subset-spec §2.3 | 脚本语言直译语义 | —— |
| 程序终值与值约定 | ✓ | subset-spec §2.4 | Scheme REPL 值面 | —— |
| 空表与空应用 | ✓ | subset-spec §2.5 | Scheme `()` | —— |
| 卫生宏展开语义 | ✓ | Stage 0.9 + expander 生产位 G4 r145-r149 | Scheme 卫生宏/rustc macro | expander.ktf 4,740 行孪生生产位 |
| 编译期求值（值层 comptime 型面） | 登记 | W-COMPTIME（w-decision-gap-windows §5——四触发器 + 四前置门 @ r172） | Zig comptime/Mojo 参数 | §6.10.2 决策「✅ 实现 Stage 1」——宏展开半面 G4 已交付（语法变换子面 ≠ 值层求值）；矩阵补行 @ r172（v1.0 遗漏清偿）；成熟度已达标（Zig 生产就绪）触发主轴 = 需求面 |
| 尾递归优化语义 | ✓ | C3 r136-r137（G2——堆激活栈 + 深尾递归恒定栈高） | Scheme TCO/chez | 10^5 深非尾递归默认栈实测 |
| 任意递归深度 | ✓ | G2 CLOSED（r136/r137 两刀） | —— | 四层帽 K162 可配置护栏 |
| 求值确定性（fixpoint 位级） | ✓ | K159 不动点 B≡C 位级 8/8 release | bootstrappable builds | r163 验收对账三项之一 |
| 错误处理语义（Fatal 边界 + 用户自定义错误语义） | ✓ 裁定 / 登记 | §9.15 审查六裁定（统一而分治）；自定义错误 = 登记 | Rust Result/OCaml effect | 统一效应模型的设计位——Fatal 边界裁定 ✓，自定义面待效应族窗口 |

## 4. 类型系统（stage0 §6.10 前沿对照 + 刀 1-4 生产面）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 设计决策对账（§6.10.2） |
|---|---|---|---|---|
| HM 单态推断（let 多态 + 算法 W 族） | ✓ | infer.ktf 4,471 行生产位（G4）；HM-TWIN CLOSED r131 | OCaml/Haskell HM | —— |
| 类型注解双向检查（标注-推断 unify） | ✓ | 刀 1 @ r165（E0013 第 14 位诊断码） | OCaml/Scala 注解 | 「annotations are surface sugar the HM layer owns」兑现 |
| struct 名义类型（Type::Struct + 透明展开 unify） | ✓ | 刀 2 @ r166（GZ-3） | OCaml record/Rust struct | —— |
| enum 名义类型（Type::Enum 封闭） | ✓ | 刀 3 @ r168 | Rust/ML ADT | —— |
| 穷尽性检查（GZ-4 展开期单段执法） | ✓ | 刀 3/4 @ r168/r170（三判式） | Rust/OCaml match 完备性 | —— |
| 泛型参数化（显式 forall/类型参数） | 缺失 | —— | Haskell/Rust generics | HM 隐式多态承载参数化（let 多态）；显式参数化表面未开——候选：注解面扩展 |
| 行多态（可扩展记录/行基效应） | **✓（P1 面交付 @ r182-r185；P2 效应行形状冻结 @ r185——效应语义 = 效应机制窗〔链中段〕的实施面）** | W-ROW-POLY CLOSED @ r185（三刀全 DELIVERED：刀 1 infer.ktf 行代数内核〔4,860〕+ 刀 2 target-parser/expander 皮肤与消费折叠 + infer 注解桥〔5,122/5,286/4,922〕+ 刀 3 corpus-row 28 案 + audit 460→470 + row_effect_shape 6 案 P2 形状冻结——出口六条全 ✓；oracle 三件零文件两刀机检〔r174 冻结裁定首两个适用者〕；`;` 尾分隔皮肤形裁定〔`|` 三重职责冲突实勘〕） | OCaml 5/Koka/Unison/PureScript rows + Leijen 2005 scoped labels（r181-search 六锚） | §6.10.2 决策 = 预留类型系统；P1/P2 分级兑现（原则 26）；P2 消费位 = 效应机制窗 handler/perform 语义的效应行推断 |
| 交叉/联合类型 | 登记 | W-UNION-INTERSECT（w-decision-gap-windows §3——四触发器 + 四前置门 @ r172） | TypeScript/Flow（表达面生产就绪）/Scala 3 | §6.10.2 决策 = ✅ 实现 Stage 1——实况未实施；登记态升级 @ r172；HM+union 融合推断面 = 早期实践观察位；enum（封闭 tagged union·GZ-4）表达面不重叠 |
| 线性/仿射类型（所有权/I/O 能力模型基础） | 登记 | W-LINEAR-TYPES（w-decision-gap-windows §4——四触发器 + 四前置门 @ r172） | Rust 所有权（生产就绪）/Linear Haskell | §6.10.2 决策 = ✅ 实现 Stage 1——实况未实施；登记态升级 @ r172；L3 授权层（原则 34）链式前置 = 其资源面基础 |
| 渐进类型（Dyn 混合） | ✓ 部分 | HM + Dyn 保守纪律（r170 §11.2 成本触发器口径） | TypeScript/Python hints | Dyn 退化频率 = calibration-data 可测量轴（W-ROW-POLY 触发器④） |
| 依赖类型 + Graded Modal | ✓ 设计忽略 | §6.10.2 决策 = 忽略（复杂度过高） | Agda/Rocq（研究前沿） | 设计蓝图裁定在案——不列实施缺口 |

## 5. 效应与控制（stage0 §9.14.2 成员三组 + §9.15 统一效应模型——登记态全表）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 效应族六官方实例（Read/Write/State/Async/Error/Log） | **✓（六实例全量交付 @ r192-r194；效应族三段链全链闭合 @ r194——行类型基础〔段 1 CLOSED @ r185〕→ 机制地基〔段 2 CLOSED @ r189〕→ 官方词汇面〔段 3 CLOSED @ r194〕；“统一而分治”模型实例级终验：六官方实例全部落在冻结原语集内 = 设计自证）** | W-EFFECT-INSTANCES CLOSED @ r194（三刀全 DELIVERED：刀 1 纯语言三件 state/error/log @ r192〔INST-6 状态代链〕→ 刀 2 IO 桥两件 read/write @ r193〔thunk 链组合纪律 + 双向缓冲钉死〕→ 刀 3 async @ r194〔同步直通退化策略 + §5.4 诚实边界——真调度器 = 策略替换位后续窗〕；语料 40 案 10:30 = 1:3 四臂全覆盖 + audit BI/BJ/BK 512 live + sweep 五族化 + 机制滤网扩展；金链 bump v0.139.0——窗口 CLOSED 里程碑〔r189 先例〕；oracle 零文件机检逐刀维持〔r174 冻结裁定〕；单源 w-effect-instances-window.md v1.3 CLOSED） | Koka/Unison/OCaml 5·Eio/Effekt/Haskell freer（r191-search 六锚 + r192-search 四检索） | §9.14.2 实施态 @ r194；零新原语义务（§9.2 裁定 1——第 151 轮构造性维持） |
| 代数效应 + 处理程序机制 | **✓（全窗交付 @ r186-r189——W-EFFECT-MECHANISM CLOSED @ r189）** | w-effect-mechanism-window.md v1.3 CLOSED（三刀全 DELIVERED：刀 1 值层/VM one-shot 语义〔续体值 + k 尾参 + resume/halt + return 标签 + ext2 槽填充〕@ r187 + 刀 2 infer.ktf 效应行推断消费〔箭头携行/扩行/覆行/逃逸/泛化〕@ r188 + 刀 3 corpus-effect 28 案 + audit BH 480/480 + §9 段 3 六实例接口冻结 @ r189——出口六条全 ✓；oracle 三件零文件机检三刀维持〔r174 冻结第三刀〕） | OCaml 5/Koka/Eff/Unison（r186-search 六锚——m5 freer 族 + m6 Boolean 合一双否决） | 段 3 效应族实例窗（六实例）开窗前置就绪——机制地基全量在位 |
| 多态效应处理程序 | ✓ 设计忽略 | §6.10.1 成熟度 = 研究前沿 | Plotkin & Pretnar 2009 | —— |
| 能力模型 L3 授权分层（纯度/声明/令牌三态 + fail-closed） | ✓ 设计冻结 / 登记 | 原则 34（v12.2 r33）——J1-J4 正交判据 + 授权三红线设计在案 | ocap（E/Cap'n Proto） | 实施窗未开；线性类型为其资源面基础 |
| one-shot 处理程序纪律 / 效应-语义正交（J2） | ✓ 设计冻结 | §9.15 审查六裁定 | Koka 语义 | —— |

## 6. 资源管理与运行时

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 堆激活栈（eval 引擎堆化） | ✓ | C3 r136（G2） | —— | VM 树走解释器 = Rust 基座〔宪制排除〕 |
| 递归深度护栏（四层帽 K162 + with_limit） | ✓ | r137（G2 终态） | —— | env 单源 fail-closed |
| 基础堆回收（VM sweep） | ✓ | VM 基座（B4 gc 1/swept 1023 实测锚） | —— | 〔宪制排除——VM Rust 基座〕 |
| 分代 GC | 登记 | W-GEN-GC（W-3.4 评估窗 @ r119 登记） | JVM/Go/OCaml 分代 | 零信号不开窗 |
| extern/FFI 堆类型句柄协议 | 登记 | W-HEAP-EXTERN（TD-026 闭账承载位 @ r166） | Rust FFI/OCaml ctypes | 触发器 = extern 扩展面需求 |
| JIT（方法级/链内） | ✓ 裁决（链内最优锁定） | W-JIT-METHOD-T1 CLOSED r142（MJ-5/MJ-6） | —— | 链内 = 纯解释 + LLC 最优形态（零 codegen 约束下 27 臂 match）；真 codegen = 链外 W-3.8 |
| 真机器码后端（LLVM/QBE/C 转译） | ✓（链外并存） | kerf-cbackend ✓ + W-3.8 可选位 | LLVM 家族 | 〔宪制排除——链外后端永不入自举链〕 |
| VM 执行核心优化（EXC 族：物化协议单源 + reserve_exact 批处理 + take_args 栈窗口单移动） | ✓ | §9.69（K126-K131）——B2 −13.0%/B5 −12.6% 域主账 | —— | 〔宪制排除——VM Rust 基座〕 |
| 超指令融合（superinstruction） | 登记 | W-VM-SUPERINSTR（§9.69 登记窗） | Lua/LuaJIT 融合指令 | 零信号不开窗 |

## 7. 编译管道与自举面（G1-G8 ✓ 终态——roadmap/completion-plan §2 单源）

| 阶段 | 状态 | 交付锚 | 备注 |
|---|---|---|---|
| 词法/读链（目标皮肤 .ktf） | ✓ | G1 CLOSED r139（target-lexer/target-parser 孪生） | C1 断链闭合 |
| 宏展开 | ✓ | G4 生产位 r145-r149（expander.ktf 4,740 行） | 孪生链 = 生产链 |
| 类型检查 | ✓ | G4 + HM-TWIN r131（infer.ktf 4,471 行） | —— |
| 编译（树→指令） | ✓ | G4（compile 孪生 r124 起） | —— |
| VM 执行 | ✓ | VM 基座 | 〔宪制排除〕 |
| 任意递归深度 | ✓ | G2 CLOSED r137 | —— |
| 生产位切换（四段） | ✓ | T-a CLOSED r149（五步 K159 不动点） | B≡C 位级 |
| S-expr 表面全拆 | ✓ | G7 CLOSED r154（四层全离树） | 单皮肤 .ktf 终态（用户指令⑥） |
| 包管理器自举 | ✓ | G5 CLOSED r160（kp 五模块 .ktf + 三态回退带） | micro-toml/semver/manifest/lockfile/resolve |
| eval 引擎退役 | ✓ | G6 CLOSED r162（用户面 loud-retirement） | 验证面保留（K15 差分承重） |
| 自举完备验收 | ✓ | r163 GO（C1-C4 + D1-D8 深审 + 投票 5.5/5.5） | 完成标准宣告：完全脱离宿主语言（宪制排除项除外） |
| 语言基础完备 | ✓ | G8 CLOSED r170（四刀全交付） | 注解/struct/enum/模式族 |
| fixpoint 自复现 | ✓ | K159 门 8/8 release | 两次编译自身字节一致 |
| 前端自举推进（reader→expander→裁定段） | ✓ | W-3.12/C4 面（段一/二/三 ELEVATED + W-BOOT-FRONTEND 账面清偿 r131） | —— |
| 自举台账 | ✓ | selfhost/ 18 件 .ktf = 23,967 行（v1/ 十二件全现代化〔r201 实测口径：semver 340 + micro-toml 680 + manifest 545 + lockfile 703 + resolve 544 + typecheck 1,304 + target-lexer 1,128 + compiler 1,917 + macro 753 + expander 5,085 + infer 5,532 + target-parser 5,122——十二件全上 G8 表面，表示恒等重写；modern-2 消费已入 10 件：semver/micro-toml/manifest/lockfile/resolve〕刀 1-2〕+ target-lexer/typecheck【刀 3——C2 raise + pair 模式化〕+ compiler【刀 4——C2 八 raise 位 + estate/proto 判别头清理 + cp_run attempt 契约面〕+ **expander/macro【刀 5——ex_fail raise 化 + 守卫溶解 + ex_run 契约面 + 遮蔽族两份共变〕**；C1 评估关闭（零死头活 tag〕M72〕）+ std/ 标准库区六件〔r192-r194 W-EFFECT-INSTANCES：state 73 + error 52 + log 44 + read 49 + write 55 + async 41 = 314——六官方效应实例词汇包，wc 逐位实测〕） | 三落纪律 worklog 全文承载 |
| 自举源现代化二（效应族链表面消费——行词汇 + 效应词汇包） | ✓ 12/12 件终态（六刀全 DELIVERED：刀 1 pkg 试点 @ r196 + 刀 2 pkg 三件 @ r197 + 刀 3 判定/词法 @ r198〔TD-032 登记〕 + 刀 4 编译/宏 @ r200 + 刀 5 展开/宏 @ r201 + 刀 6 解析/推断收官 @ r203〔TD-032 闭账〕——**窗口 CLOSED @ r203 出口六条 ✓**） | w-selfhost-modern2-window.md（§9-§9.10 六映射表 + 探针法证 + 性能账单源） | 12 件消费：pkg 五件 + 判定/词法双件 + compiler + expander + parser 全量 C2（attempt/raise/unwrap——入口契约面 result define 冻结）+ C1 行词汇按件裁定（pkg 两位 + 判别头清理族；M49 Rust-reader 边界其余）+ C4 效应行注解 API 面（ei08/ei09 金档钉）+ C5 关闭（无自然形）；外部契约冻结 + 诊断累积面不开 + 位置元组不强转 + 性能诚实账 + std/ 前缀装配四链源；零新桥（r174 终局承继） |
| 自举源现代化（12 件用最新表面重构） | ✓ | W-SELFHOST-MODERN CLOSED（**刀 1 DELIVERED @ r175**：semver + micro-toml；**刀 2 DELIVERED @ r176**：manifest/lockfile/resolve——struct 型字段首例 M13/M14 + 顶层 nil 模式首例 M19；**刀 3 DELIVERED @ r177**：typecheck + target-lexer——标量 tag 表 M21 + walk 模式机 M22 + 算符极长匹配表整型臂 M27 + 自应用闭环；**刀 4 DELIVERED @ r178**：compiler + macro——CP 两遍分派 M31-M36 + 宏库保守面 M37/M38 + fixpoint 载体自应用 17/17；**刀 5 DELIVERED @ r179**：expander + 遮蔽族 22 名两份共变——合成模式机 M41 + 表达式头 M42 + 声明头 M43 + T2 63/63 含 audit 460/460；**刀 6 DELIVERED @ r180**：infer + target-parser 收官双件——W 机核心 M50〔ti_unify_step 字面域 match + `_` 记录域携 var 守卫维持 + not(is_pair(b)) 守卫折入 pair/fn 臂——GZ-2/GZ-3/GZ-4 注释原位〕+ walk 模式机族 M51〔resolve/occurs/annotation/var/subst 一/多态〕+ 规格解析机 M52〔八模表 + 内层 first(elems) 三臂〕+ 任务机 M54〔enter 九臂 + dispatch 十臂〕+ 名字表 M55 + 帧机主分派 M59〔tp_step 33 状态 + tp_give 29 臂 machine-drop `_` 保形 + tp_dispatch_item 10 臂〕+ 守护相位机族 M60〔is_nil(phase) 新鲜态族——守卫维持 if + else 内 match〕+ token/datum 表 M61〔kind_name/datum_word/is_word/datum_op/is_datum_op/cmp_kind + tp_step_datum 谓词级联入 `_` 臂〕+ tp_bin_ops 整型臂 + 离开守卫 M63〔16 臂〕+ 注解族 M57/M64〔~76 infer 位 + ~29 parser 位——tp_ha/tp_ma nil 占位域与 ti_member/ti_row_push 名/位混合域经 checker 立捕后诚实裸名〕，表示恒等 + 刀 6 门〔全 parity sweep + fixpoint 17/17 B≡C + T2 63/63 audit 460/460〕全绿 + 映射表 §14 + 出口六条 ✓） | 12/12 全上 G8 表面——窗口 CLOSED |
| 语言内编排与组装面（import 表面 + 序列化 + kerf-build 编排器） | **✓ 终态**〔W-SELFHOST-ORCH CLOSED @ r205-r212——五刀全 DELIVERED：刀 1 import 表面 @ r206 + 刀 2 序列化面 @ r207 + 刀 3 编排器孪生全 @ r210 + 刀 4 M49 重审 + 前缀族清扫 @ r211 + 刀 5 收口 @ r212；出口六条全 ✓（窗口档 §13）；逐需求桥增殖计数 = 0 终态落档（pub(crate) 编译期锚 + 金档断言族 + 全仓清点）〕 | w-selfhost-orchestration-window.md v1.6（五刀序 + 出口六条 + r124 §6e 重勘裁定 + §9 O1-O9 + §10 R1-R9 + §11 B1-B9 + §12 P1-P9 裁定表 + §13 收口核对单源） | Go cmd-go / dune mini-Dune / GHC hadrian（rust x.py = 少数派）+ Racket K103 名-路径两分（import 皮肤）+ Clang/C++20 modules ORCH-C（文本装配→语义 import 谱系）+ string interning 谱系 ORCH-D（身份语言内 + 渲染宿主边缘——序列化形制） | 自举完备收尾链——四类可退役桥全部退役为语言内能力 + 宪制排除收敛三项（VM 基座 + cargo 构建引导 + 种子装载器）+ M49 双位终态（种子+oracle）——「自己用自己语言推进自己」的编排链收口 |

## 8. 模块/命名/可见性

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 模块系统（加载层 + 收集序 + last-wins） | ✓ | MOD 裁定族 §9.64（K102-K106） | OCaml 模块/Go package | 加载层 Symbol 键统一 + 真 first-seen |
| 命名空间边界 | ✓ 裁定 | W-BOUND-SCOPE/W-NAMING 登记窗 §9.58（K78-K80 + BOUND-1 清偿） | Rust 模块可见性 | 裁定族在案；登记窗零信号 |
| Symbol 单池身份（全管道无文本键工作状态） | ✓ | §9.52 → §9.68 身份基座链闭合 | rustc Symbol/interning | reader→typecheck 全程 |
| 可见性控制（pub/private 修饰） | 缺失 | —— | Rust/OCaml 可见性 | 候选：与 L3 授权层联动（import 不传播授权设计位）；触发器 = 多模块语料规模 |
| 依赖解析（semver + lockfile + resolve） | ✓ | G5 @ r156-r160 | cargo/opam（K161 解耦先例） | kp 生产位 |

## 9. 工具链与生态

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 包管理 CLI（kp） | ✓ | G5 r160（KERF_PKG_SELFHOST 三态带） | cargo/pnpm | —— |
| 诊断系统（十二面审查 + 位置单源化） | ✓ | DIAG 族 §9.56（K71-K74 + DIAG-1/4） | rustc 诊断族 | 14 诊断码（E0002/E0009/E0013/E0019…） |
| REPL（用户面） | ✓ | SURF 裁定族 §9.62（K92-K97——REPL 不完备族统一） | 各语言 REPL | —— |
| CLI 对称化（--engine/--parity 退役教育性错误） | ✓ | SURF 族 + G6 r162 | —— | loud-retirement |
| 测试基建（分层执行引擎） | ✓ | W-TEST-FLOW DELIVERED r167（T0 29/T1 52/T2 63） | nextest/GHC test | 分块前台 + 断点续跑（对抗环境收割） |
| 格式化（selfhost 格式约定 + 工具） | ✓ | FMT 族 §9.79（krf_reformat.py + 三断言守卫） | rustfmt/gofmt | selfhost 三件格式域清偿 |
| 基准方法学 | ✓ | §9.61（K88-K91 + 方法学 v2 码化 + B4 确定性守卫） | criterion | 测量方法学本身入审 |
| 审计面（audit 全语料） | ✓ | 460 live + 124 retired（r170 BF01/BF04/V3 共变） | —— | —— |
| 诊断操作码上下文/形式记法 | 登记 | W-DIAG-OPCODE-CONTEXT/W-DIAG-FORM-NOTATION（r106/r108 登记窗） | rustc 诊断上下文 | 零信号 |
| 驱动/harness 拆分 | 登记 | W-DRIVER-HARNESS-SPLIT（r106 登记窗） | —— | 零信号 |
| 跨轮结果缓存/族级并行 | 登记 | W-TEST-FLOW §7 登记态四件（r167） | nextest 缓存 | 零信号 |
| LSP/IDE 协议面 | ✓ 设计预留 / 缺失 | §9.3.2 LSP 交互点（设计蓝图位） | rust-analyzer | 实施缺失——Stage 3+ 生态位候选 |
| 交叉编译矩阵 | 缺失 | —— | Rust/Zig 交叉面 | 链外 C 后端位候选（W-3.8 域） |
| 文档生成器 | 缺失 | —— | rustdoc/ocamldoc | 零信号 |

## 10. 标准库（libs 族 58——T2 门在册 @ r170）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 列表/字符串/基本 I/O 基础库 | ✓ | Stage 1 出口判据 + libs 族 58（T2 门） | Scheme R7RS 小核 | 内建 18 + stdlib 表面 |
| 数值库（浮点/大数/位运算） | 缺失 | —— | 各语言 stdlib | 触发器 = 浮点字面量排期（§1 联动） |
| 集合库（map/set——非 vector 宪制排除） | 缺失 | —— | —— | pair 链承载线性结构；哈希面 = 零原语约束下的内建层议题 |
| 并发/通道原语 | ✓ 设计排除（零通道不变性） | 8 原语冻结——零通道 | —— | 并发面 = L3 授权 + 效应族窗口域（Stage 3+） |

## 11. 完成度汇总与剩余优先级（下一窗扫描单源输入）

**计数**（能力项粒度——本矩阵行级）：

| 域 | ✓ 已交付 | ✓ 设计冻结/裁决 | 登记 | 缺失（含决策-实况缺口） |
|---|---|---|---|---|
| 词法（§1） | 4 | 0 | 0 | 2 |
| 语法（§2） | 7 | 0 | 1 | 2（1 = 设计排除中缀） |
| 语义（§3） | 9 | 0 | 2 | 0 |
| 类型（§4） | 6 | 1（依赖类型忽略） | 3 | 1 |
| 效应（§5） | 2 | 3 | 0 | 0 |
| 资源/运行时（§6） | 6 | 0 | 3 | 0 |
| 管道/自举（§7） | 17 | 0 | 1 | 0 |
| 模块/命名（§8） | 3 | 1（命名空间裁定） | 0 | 1 |
| 工具链（§9） | 8 | 0 | 3 | 3（LSP 设计预留归缺失列——单行单计 @ r204 审计） |
| 标准库（§10） | 1 | 1（并发设计排除） | 0 | 2 |
| **合计（94 项 @ r212）** | **64** | **6** | **12** | **11** |

> 归态口径注记（r171 写入时自查勘正）：错误处理（§3）混合态归登记列（Fatal 裁定 ✓ / 自定义面登记）；JIT 链内裁决（§6）归 ✓ 交付列（MJ-5/MJ-6 裁决完成 = 交付物）；命名空间边界（§8）「✓ 裁定」归冻结列；LSP（§9）「设计预留 / 实施缺失」归缺失列；并发/通道（§10）设计排除归冻结列。r204 审计增注：**每行单计纪律**——dual-state 行按主归态列单次计数（LSP 双态行计一次缺失列；§5 L3 授权双态计一次冻结列），域行合计与总计行以同一口径重数（v1.28 双侧一致：✓63/冻结6/登记12/缺失11 = 92 行实测；v1.29 增注：§7 新行「语言内编排与组装面」登记〔W-SELFHOST-ORCH OPEN @ r205——实施窗 OPEN 不改登记列计数之 v1.13 先例在此不适用：本行首登记即入登记列〕——93 行 = ✓63/冻结6/登记13/缺失11）。r212 增注：§7「语言内编排与组装面」行翻 ✓ 终态〔W-SELFHOST-ORCH CLOSED @ r205-r212——登记→✓〕——94 行 = ✓64/冻结6/登记12/缺失11。

**剩余优先级**（触发器就绪度排序——r205 重排：**W-SELFHOST-ORCH 升首位实施窗**〔用户显式排期三句式信号 @ r205——完全自举收尾（「自己用自己语言推进自己」）+ 桥审查指令；§21.12-28 自举段最高优先 + completion-plan §3 第三段 Phase α 单源〕——r181 先例形制；目标语言完整落地计划 β/γ/δ 段入 completion-plan v1.54 §3（核心语义 → 语法糖 → 生态——基础核心先行序）；余窗零信号不开窗纪律维持——**非冻结**，触发器达成即开）：

1. **W-SELFHOST-ORCH**（自举编排语言内化——自举完备收尾链 Phase α）——**CLOSED @ r205-r212**（五刀全 DELIVERED：刀 1 import 表面 @ r206 + 刀 2 序列化面 @ r207 + 刀 3 编排器孪生 @ r209-r210 + 刀 4 M49 重审 + 前缀族清扫 @ r211 + 刀 5 收口 @ r212；出口六条全 ✓（窗口档 §13 收口核对单源）；逐需求桥增殖计数 = 0 终态落档；目标语言完整落地链后续段：**Phase β 核心语义链入口激活**（W-LINEAR-TYPES 触发器① = α 收口已达成 @ r212——下一排期点 §17 Step 1 扫描；β/γ/δ 段 completion-plan §3 第三段单源〕）
2. **W-ROW-POLY**（行多态·效应族链首段·类型基础）——**CLOSED @ r185**（OPEN @ r181；触发器①链式达成 + 前置门四件全过〔r181-search 六检索 + §3.3 提案 + 8 原语第 138 轮 + 孪生可表达性 ✓〕；三刀全 DELIVERED：刀 1 infer.ktf 行类型表示 + 行合一五规则 @ r182 → 刀 2 target-parser + expander 消费面 @ r184〔含 infer 注解桥 + corpus-row 语料 + TD-030 关闭〕→ 刀 3 语料 + audit BG 460→470 + P2 效应行形状冻结 @ r185——出口六条全 ✓；**r174 冻结裁定首个适用者**——Rust oracle 零改动；单源 w-row-poly-window CLOSED 终态）
3. **效应族三段链**（Read/Write/State/Async/Error/Log——completion-plan §3 单源）：段 1 W-ROW-POLY **CLOSED @ r185** ✓ → 段 2 W-EFFECT-MECHANISM **CLOSED @ r189** ✓ → 段 3 W-EFFECT-INSTANCES **CLOSED @ r194 ✓（效应族三段链全链闭合——三刀全 DELIVERED：刀 1 纯语言三件 State/Error/Log @ r192 → 刀 2 IO 桥两件 Read/Write @ r193 → 刀 3 Async 同步直通退化形 + 收口 @ r194；单源 w-effect-instances-window.md v1.3 CLOSED；§9 消费位冻结单源全程承接；金链 bump v0.139.0〕**；信号源维持 = 用户显式排期请求 @ r181 + 放行指令 @ r191；效应族实施按 r174 桥终结裁定走金档验证面（oracle 零文件）——**三段链闭合后的下一排期点已行使 @ r195：§17 Step 1 扫描裁定 11 候选窗零信号 + W-SELFHOST-MODERN-2 四触发器全达成开窗〔当前实施位——效应族链表面消费（行词汇 C1 + Error 词汇 C2 + Log 词汇 C3 + 效应行注解 C4 + State 自然位 C5）；单源 w-selfhost-modern2-window.md v1.0；后续窗候选维持：并发调度策略窗〔Async 真调度器——L3 授权 + §5.4 诚实边界注记〕/语法糖窗〔try/catch/`?` 表面糖——依赖表面语法切换窗 #15〕，零信号不开窗维持**〕；**r204 §17 Step 1 重扫零信号维持**（三候选逐一核对 + **深链自举扩展裁定 = 宪制边界内终深度**〔生产链 18 件全 .ktf + 宪制排除三族〔VM 基座 / 构建引导 / 编排层〕+ 诚实边界族——零新可扩展段就绪 → 零开窗〕；下一实施窗 = 触发器驱动重扫〔用户显式排期 / 语料需求 / 能力里程碑任一〕；单源 = worklog r204 + tech-debt r204 检视 + roadmap v3.16 §6）
4. **W-LINEAR-TYPES**（线性/仿射类型）——登记 @ r172（w-decision-gap-windows §4）：L3 授权层链式前置 + 四触发器；正交于 W-ROW-POLY
5. **W-UNION-INTERSECT**（交叉/联合类型）——登记 @ r172（§3）：HM+union 融合成熟度观察 + enum+Dyn 承载实测 + Dyn 损耗同轴
6. **W-COMPTIME**（编译期求值）——登记 @ r172（§5）：成熟度已达标触发主轴 = 需求面；开窗须对账 G6 eval 退役边界
7. **W-HEAP-EXTERN**（FFI 堆句柄）——TD-026 承载位（与 W-LINEAR-TYPES 触发器③联动）
8. **共享全局环境污染 P2**（r170 登记）——触发器 = 用户语料踩中频率
9. **W-GEN-GC / W-VM-SUPERINSTR / W-EMI-COMPILE-AXIS / W-BOUND-SCOPE / W-NAMING / W-CHK-DEFINE-HASH / W-DIAG-*/ W-DRIVER-HARNESS-SPLIT / W-PKG-MULTISRC**——横切登记窗族（零信号维持）
10. **TD-029**（VM 栈余量 + 引擎并行车道前置实测——SOP §3.2.1 条款 4）——r167 引擎后多轮零触发
11. **W-3.x 非自举族**（W-3.5 Token 流+图 IR / W-3.8 codegen / W-3.9 诊断增强）——从属位法定解除 @ r163/r170；各窗自身触发器仍零信号
12. **浮点/插值/守卫子句/可见性/LSP/文档生成**——缺失候选（零信号；LSP 设计预留归缺失列）

## 12. 维护纪律

1. **共变义务**：每窗 OPEN/CLOSED/DELIVERED 轮的文档共变清单**必含本矩阵**（新增能力行 / 状态翻转 / 计数共变 + 版本号演进）；违反 = GATE 3 无条款引用判 NEEDS REVISION。
2. **版本演进**：v0.X 逐窗递增；状态翻转（登记→✓ 或 缺失→登记）须附触发器达成证据锚。
3. **单源边界**：本矩阵只做汇总视图——实施细节回归各单源（§0 声明）；发现矩阵与单源冲突时以单源为准 + 当轮修正矩阵（§8.4.5）。
4. **触发器定义补全义务**（✅ 已兑现 @ r172——w-decision-gap-windows.md v1.0 三窗落档〔W-UNION-INTERSECT §3 / W-LINEAR-TYPES §4 / W-COMPTIME §5〕）：本条转为**常设义务**——未来任何决策矩阵（§6.10.2 同型）新增「实现」级决策行时，若实况未实施，同轮在登记档补四件形制触发器定义（决策-实况缺口不许无承载——零信号不开窗纪律下缺口必须可审计）。
5. **扫描轮输入**：每轮 §17 Step 1 扫描以 §11 为结构化输入（替代散点窗口名检索）；扫描轮自身共变 §11 优先级表。

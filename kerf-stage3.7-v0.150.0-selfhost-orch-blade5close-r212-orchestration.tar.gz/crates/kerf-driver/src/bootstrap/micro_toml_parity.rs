//! The micro-TOML twin parity harness (W-PKG-SELFHOST blade 1 —
//! w-pkg-selfhost-window.md §4 blade row 1): the package manager's
//! manifest grammar parser, `selfhost/v1/micro-toml.ktf`, against
//! the Rust oracle `kerf_pkg::micro_toml::parse` through the full
//! `.ktf` chain on BOTH engines — the ninth selfhost twin, the
//! first of the kerf-pkg self-hosting family (K15: the differential
//! oracle — the twin and the oracle walk the same grammar space,
//! the three-way comparison (oracle == twin-vm == twin-eval) pins
//! them decision for decision).
//!
//! The twin rides the RS-1 byte-table channel
//! (`target_byte_table_prefix`); every dynamic text in a record
//! (a key, a header name, a string payload, an error's named
//! operand) is a BYTE SPAN into the source, and this module slices
//! and renders both sides through the SAME single-source helpers
//! (`debug_quote`, `decode_mt_string`, the kind table) — a drift
//! between the two renderings is impossible by construction.
//!
//! The dump grammar (one line per record, file order — a "t"/"a"
//! line opens a table context, "e" lines fill it, "g" lines are the
//! global scope; line:col are the oracle's own entry positions):
//!
//! ```text
//!     (g "package" (str "app") 2:1)
//!     (g "count" (int 3) 3:1)
//!     (t "depends")
//!     (e "core-bits" (str "0.2") 6:2)
//!     (a "packages")
//!     (e "name" (str "a") 9:2)
//! ```
//!
//! The error axis (K15 three-way on the SAME key): both sides
//! render `line:col: message` — the oracle through
//! `MicroTomlError`'s Display, the twin through the kind table
//! below, which reproduces the oracle's message templates verbatim
//! (the one Debug-quoted operand is `trailing content after value`,
//! the oracle's own `{:?}` — `debug_quote` mirrors it).

use kerf_pkg::{Item as MtItem, MicroTomlError, Value as MtValue, parse as mt_parse};
use kerf_vm::{Heap, Value};

use crate::bootstrap::target_corpus::target_byte_table_prefix;
use crate::bootstrap::vm_harness::{
    STD_ERROR_TARGET_SOURCE, as_i64, as_str, drive_vm_only, first_diff, need_fields, value_elems,
};

// ---------------------------------------------------------------------------
// The twin source embedding
// ---------------------------------------------------------------------------

/// The W-PKG-SELFHOST blade 1 twin (r156): the micro-TOML subset
/// parser in its own target skin.
pub const MICRO_TOML_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/micro-toml.ktf");

// ---------------------------------------------------------------------------
// The single-source render helpers (both sides of every comparison)
// ---------------------------------------------------------------------------

/// Rust `{:?}` for strings, the subset the corpus can reach: the
/// five escapes, other control bytes and DEL as `\u{x}` (lowercase,
/// no padding — the `escape_debug` convention), everything else
/// verbatim.
fn debug_quote(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            '\0' => out.push_str("\\0"),
            c if (c as u32) < 0x20 || (c as u32) == 0x7f => {
                out.push_str(&format!("\\u{{{:x}}}", c as u32));
            }
            _ => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Decode a string payload's escape pair (the twin already rejected
/// every other escape at the same offsets on a parity-passing input;
/// the total match arms are defense in depth, never a silent pass).
fn decode_mt_string(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len());
    let mut it = raw.chars();
    while let Some(c) = it.next() {
        if c == '\\' {
            match it.next() {
                Some('"') => out.push('"'),
                Some('\\') => out.push('\\'),
                Some(other) => out.push(other),
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

/// Slice one operand span out of the source (bounds and char
/// boundaries checked — a malformed span is drift, never a panic).
/// Shared by the pkg-family parity harnesses (the blade 2 semver
/// drive slices its component operands through the same face).
pub(crate) fn span_text(text: &str, s: i64, e: i64, what: &str) -> Result<String, String> {
    let (s, e) = (s as usize, e as usize);
    if s > e || e > text.len() {
        return Err(format!("{what} span ({s},{e}) is out of bounds"));
    }
    text.get(s..e)
        .map(|s| s.to_string())
        .ok_or_else(|| format!("{what} span ({s},{e}) is not a char boundary"))
}

// ---------------------------------------------------------------------------
// The oracle axis: the Rust parser's dump
// ---------------------------------------------------------------------------

fn oracle_entry_line(out: &mut String, tag: &str, key: &str, value: &MtValue, line: u32, col: u32) {
    match value {
        MtValue::Str(s) => out.push_str(&format!(
            "({tag} {} (str {}) {line}:{col})\n",
            debug_quote(key),
            debug_quote(s)
        )),
        MtValue::Int(i) => out.push_str(&format!(
            "({tag} {} (int {i}) {line}:{col})\n",
            debug_quote(key)
        )),
    }
}

/// The oracle's normalized dump: one line per record in file order
/// (globals, then items — each table header line followed by its
/// entry lines), or `Err` with the oracle's own error.
pub fn micro_toml_oracle_dump(text: &str) -> Result<String, MicroTomlError> {
    let doc = mt_parse(text)?;
    let mut out = String::new();
    for e in &doc.globals {
        oracle_entry_line(&mut out, "g", &e.key, &e.value, e.line, e.col);
    }
    for item in &doc.items {
        match item {
            MtItem::Table { name, entries } => {
                out.push_str(&format!("(t {})\n", debug_quote(name)));
                for e in entries {
                    oracle_entry_line(&mut out, "e", &e.key, &e.value, e.line, e.col);
                }
            }
            MtItem::ArrayTable { name, entries } => {
                out.push_str(&format!("(a {})\n", debug_quote(name)));
                for e in entries {
                    oracle_entry_line(&mut out, "e", &e.key, &e.value, e.line, e.col);
                }
            }
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// The error key: the oracle's message templates, verbatim
// ---------------------------------------------------------------------------

/// Render the twin's error record into the oracle's `line:col:
/// message` form — the kind table reproducing
/// `micro_toml.rs`'s format! strings exactly (the single
/// Debug-quoted operand is `trailing content after value`; every
/// other operand rides Display-verbatim inside its quotes).
/// Shared by the pkg-family parity harnesses (the blade 2 manifest
/// drive renders its micro-toml syntax pass-through through the
/// same table).
pub(crate) fn render_mt_error(
    kind: &str,
    line: i64,
    col: i64,
    fs: i64,
    fe: i64,
    text: &str,
) -> Result<String, String> {
    let operand = || span_text(text, fs, fe, "error operand");
    let message = match kind {
        "unclosed-quote" => "unclosed string literal".to_string(),
        "invalid-escape" => "invalid escape in string literal".to_string(),
        "dup-key" => format!("duplicate key \"{}\"", operand()?),
        "expected-entry" => "expected `key = value`".to_string(),
        "empty-key" => "empty key".to_string(),
        "not-bare-key" => format!("key \"{}\" is not a bare key", operand()?),
        "trailing-value" => {
            format!("trailing content after value: {}", debug_quote(&operand()?))
        }
        "expected-value" => "expected a string or integer value".to_string(),
        "not-in-subset" => format!(
            "value \"{}\" is not in the micro subset (strings and integers only)",
            operand()?
        ),
        "out-of-range" => format!("integer \"{}\" out of range", operand()?),
        "section-missing-close" => "section header is missing \"]\"".to_string(),
        "array-missing-close" => "array header is missing \"]]\"".to_string(),
        "trailing-section" => "trailing content after section header".to_string(),
        "trailing-array" => "trailing content after array header".to_string(),
        "empty-section-name" => "empty section name".to_string(),
        "section-not-bare" => format!("section name \"{}\" is not a bare key", operand()?),
        other => return Err(format!("harness defect: unknown error kind `{other}`")),
    };
    Ok(format!("{line}:{col}: {message}"))
}

// ---------------------------------------------------------------------------
// The .ktf side: decoding the twin's verdict
// ---------------------------------------------------------------------------

/// Decode one doc record into its dump line — ("t"/"a" name) or
/// ("g"/"e" key value line:col) — slicing every span operand from
/// the source while the engine's heap is still alive.
fn decode_mt_record(rec: &Value, heap: &Heap, text: &str) -> Result<String, String> {
    let e = value_elems(rec, heap).map_err(|err| format!("record chain: {err}"))?;
    need_fields(&e, 2, "record")?;
    let tag = as_str(e[0]).map_err(|err| format!("record tag: {err}"))?;
    match tag {
        "t" | "a" => {
            let n = value_elems(e[1], heap)?;
            need_fields(&n, 2, "table name span")?;
            let name = span_text(text, as_i64(n[0])?, as_i64(n[1])?, "table name")?;
            Ok(format!("({tag} {})\n", debug_quote(&name)))
        }
        "g" | "e" => {
            need_fields(&e, 4, "entry")?;
            let k = value_elems(e[1], heap)?;
            need_fields(&k, 2, "key span")?;
            let key = span_text(text, as_i64(k[0])?, as_i64(k[1])?, "entry key")?;
            let v = value_elems(e[2], heap)?;
            need_fields(&v, 2, "value")?;
            let vtag = as_str(v[0]).map_err(|err| format!("value tag: {err}"))?;
            let value_dump = match vtag {
                "str" => {
                    need_fields(&v, 3, "string value")?;
                    let payload = span_text(text, as_i64(v[1])?, as_i64(v[2])?, "string payload")?;
                    format!("(str {})", debug_quote(&decode_mt_string(&payload)))
                }
                "int" => {
                    need_fields(&v, 2, "int value")?;
                    format!("(int {})", as_i64(v[1])?)
                }
                other => return Err(format!("harness defect: unknown value tag `{other}`")),
            };
            let p = value_elems(e[3], heap)?;
            need_fields(&p, 2, "entry position")?;
            let line = as_i64(p[0])?;
            let col = as_i64(p[1])?;
            Ok(format!(
                "({tag} {} {value_dump} {line}:{col})\n",
                debug_quote(&key)
            ))
        }
        other => Err(format!("harness defect: unknown record tag `{other}`")),
    }
}

/// Decode the twin's `result` global: `("ok" doc)` into the dump
/// text, `("err" kind line col fs fe)` into the rendered error key.
fn decode_mt_verdict(
    value: &Value,
    heap: &Heap,
    text: &str,
) -> Result<Result<String, String>, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("verdict chain: {err}"))?;
    need_fields(&elems, 2, "verdict")?;
    let tag = as_str(elems[0]).map_err(|err| format!("verdict tag: {err}"))?;
    if tag == "ok" {
        let doc_elems = value_elems(elems[1], heap)?;
        let mut out = String::new();
        for rec in doc_elems {
            out.push_str(&decode_mt_record(rec, heap, text)?);
        }
        Ok(Ok(out))
    } else if tag == "err" {
        need_fields(&elems, 6, "error record")?;
        let kind = as_str(elems[1]).map_err(|err| format!("error kind: {err}"))?;
        let key = render_mt_error(
            kind,
            as_i64(elems[2])?,
            as_i64(elems[3])?,
            as_i64(elems[4])?,
            as_i64(elems[5])?,
            text,
        )?;
        Ok(Err(key))
    } else {
        Err(format!("harness defect: unknown verdict tag `{tag}`"))
    }
}

// ---------------------------------------------------------------------------
// The drive + comparison entries
// ---------------------------------------------------------------------------

/// The twin's single-axis dump (vm): the assembled `.ktf` (the std
/// Error-instance prefix — the twin consumes `attempt`/`unwrap`/
/// `perform raise` off it since the modern2 blade 1 — plus the
/// byte-table prefix plus the twin source) runs on the vm engine
/// (the M16 single-engine face: the k-form raise paths ride the
/// VM's one-shot semantics, the eval axis retired for the pkg
/// families — the modern2 window §9 ruling).
pub fn micro_toml_twin_dump(text: &str) -> Result<String, String> {
    // ORCH blade 4 (P2, the M49 exception): micro-toml is the
    // row-literal VERBATIM CARRIER — its source sits beyond the
    // frozen seed reader's grammar, so it cannot carry an import
    // declaration (the rider's import lines would survive into the
    // composed text and reject at the expansion face). The std
    // Error-instance text stays a raw host-side splice HERE, the
    // last two faces of the retired family (micro-toml +
    // lockfile), disclosed in the README's hosting conventions;
    // the production chain rides the composer through resolve.ktf
    // (lockfile's parity face carries the same exception note).
    let assembled = format!(
        "{}\n{}\n{}",
        STD_ERROR_TARGET_SOURCE,
        target_byte_table_prefix(text),
        MICRO_TOML_TARGET_SOURCE
    );
    let decode = |value: &Value, heap: &Heap| decode_mt_verdict(value, heap, text);
    let vm_axis = drive_vm_only(
        "micro-toml-parity-host",
        "micro toml twin",
        &assembled,
        decode,
    )?;
    let axis_form = |axis: Result<String, String>| match axis {
        Ok(dump) => dump,
        Err(key) => format!("ERR {key}"),
    };
    Ok(axis_form(vm_axis))
}

/// The two-way comparison: twin-vm == oracle, on the dump grammar
/// (success) or the rendered error key (rejection). On mismatch the
/// failure line names the case and the first differing record pair
/// (the `failure_line` lineage). The engine-agreement axis retired
/// at the modern2 blade 1 (the window §9 M16 ruling — the
/// effect-consuming twins ride the VM face).
pub fn micro_toml_parity(case: &str, text: &str) -> Result<(), String> {
    let oracle = match micro_toml_oracle_dump(text) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {err}"),
    };
    let vm_dump = micro_toml_twin_dump(text)?;
    if let Some((ol, tl)) = first_diff(&oracle, &vm_dump) {
        return Err(format!(
            "micro-toml parity FAIL [{case}]: oracle `{ol}` vs twin `{tl}`"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case list (the parity sweep's synthetic face)
// ---------------------------------------------------------------------------

/// The curated twin cases: the six accepted forms on the positive
/// axis (every shape, escape round trips, the i64 boundary, a
/// realistic kerf.toml) and the full rejection family on the
/// negative axis — all sixteen error kinds plus their boundary
/// variants (each negative case's three-way agreement is on the
/// SAME rendered error key: kind, position, and operand).
pub const MICRO_TOML_TWIN_CASES: &[(&str, &str)] = &[
    // ---- positive: the six accepted forms ----
    ("empty", ""),
    ("blank-and-comments", " \n\n# only comments\n# tail\n"),
    ("global-pairs", "package = \"app\"\ncount = 3\n"),
    ("trailing-comment-value", "delta = -7 # trailing comment\n"),
    ("sections", "[depends]\ncore-bits = \"0.2\"\n"),
    (
        "array-accumulate",
        "[[packages]]\nname = \"a\"\n\n[[packages]]\nname = \"b\"\n",
    ),
    (
        "six-forms-mixed",
        "# leading comment\n\
         package = \"app\"\n\
         count = 3\n\
         delta = -7 # trailing comment\n\
         \n\
         [depends]\n\
         core-bits = \"0.2\"\n\
         \n\
         [[packages]]\n\
         name = \"a\"\n\
         \n\
         [[packages]]\n\
         name = \"b\"\n",
    ),
    ("string-escapes", "k = \"a\\\"b\\\\c\"\n"),
    ("crlf", "a = 1\r\nb = 2\r\n"),
    ("i64-min", "k = -9223372036854775808\n"),
    ("same-key-across-sections", "[s1]\na = 1\n[s2]\na = 2\n"),
    (
        "realistic-manifest",
        "package = \"app\"\n\
         version = \"0.1.0\"\n\
         \n\
         [depends]\n\
         core-bits = \"0.2\"\n\
         math-utils = \"1.4\"\n\
         \n\
         [[packages]]\n\
         name = \"first\"\n\
         version = \"0.3.1\"\n\
         \n\
         [[packages]]\n\
         name = \"second\"\n\
         version = \"1.0.0\"\n",
    ),
    // ---- negative: the sixteen error kinds + boundary variants ----
    // duplicate keys (global scope and inside one section).
    ("dup-global", "a = 1\na = 2"),
    ("dup-section", "[s]\na = 1\na = 2"),
    // unclosed strings (the payload runs to end of line).
    ("unclosed-simple", "k = \"oops"),
    ("unclosed-with-hash", "k = \"still open # not a comment"),
    // invalid escapes (unknown escape char, a quote escape, a
    // backslash at end of line).
    ("invalid-escape-x", "k = \"a\\x\""),
    ("invalid-escape-quote", "k = \"a\\'\""),
    ("invalid-escape-eol", "k = \"a\\"),
    // lines that are neither headers nor entries.
    ("bare-word", "just-a-word"),
    ("bare-word-commented", "word-no-eq # comment"),
    // empty keys (blank before `=`).
    ("empty-key-spaced", " = 1"),
    ("empty-key-lead", "= 1"),
    // keys outside the bare-key shape (dotted, spaced, quoted).
    ("dotted-key", "a.b = 1"),
    ("spaced-key", "a b = 1"),
    ("quoted-key", "\"k\" = 1"),
    // trailing content after a value (int and string arms).
    ("trailing-after-int", "k = 1 junk"),
    ("trailing-after-string", "k = \"s\" x"),
    ("trailing-after-int-2", "k = 1 5"),
    // missing or lone values at the value position.
    ("value-missing", "k = "),
    ("value-comment", "k = # c"),
    ("value-lone-dash", "k = -"),
    // values outside the micro subset (bool, float, hex, array).
    ("bool-rejected", "k = true"),
    ("float-rejected", "k = 1.5"),
    ("hex-rejected", "k = 0x10"),
    ("array-rejected", "k = [1]"),
    // integer magnitude past i64 (MAX+1, MIN-1, twenty digits).
    ("int-max-plus-one", "k = 9223372036854775808"),
    ("int-min-minus-one", "k = -9223372036854775809"),
    ("int-twenty-digits", "k = 99999999999999999999"),
    // section headers: unclosed, trailing, empty, non-bare names.
    ("section-unclosed", "[unclosed"),
    ("section-unclosed-comment", "[unclosed # c"),
    ("section-trailing", "[s] x"),
    ("section-trailing-junk", "[s] junk"),
    ("section-empty-name", "[]"),
    ("section-empty-commented", "[] # c"),
    ("section-dotted-name", "[s.s]"),
    ("section-spaced-name", "[s t]"),
    // array headers: unclosed (one and two brackets), trailing.
    ("array-unclosed-one", "[[a]"),
    ("array-unclosed-none", "[[a"),
    ("array-trailing", "[[a]] x"),
    ("array-trailing-junk", "[[a]] junk"),
];

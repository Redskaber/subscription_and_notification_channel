//! The shared VM harness — the decode/drive layer of every
//! self-hosted twin harness (docs/stage0.md §9.46.4/§9.74; converged
//! at r151 from the retired `reader_parity`/`lexer_parity` split when
//! the S-expression read chain left the tree with the W-SEXP-RETIRE
//! blade 2 — the module's residents were always the generic layers:
//! the S-expr parity mains rode with their chains). Contents:
//!
//! * **The verdict grammar** — `KtfVerdict<E>`, the shared two-tag
//!   `("ok" ...) / ("err" ...)` grammar every twin harness
//!   decodes into (§9.74 PAR-1: one definition for all harnesses).
//! * **The value decoders** — `value_elems`/`as_str`/`as_i64`/
//!   `parse_span`/`need_fields`/`decode_tagged`: the heap-backed
//!   VM value → Rust record layer (SER-1/K172 — a malformed record
//!   reports drift, never a harness panic).
//! * **The dual-engine driver** — `drive_dual_engines`: one
//!   assembled `.ktf` program through both engines with the
//!   decoders running while each heap is still alive (the
//!   `run_parity` lineage; the r74 K165 failure classification:
//!   "harness defect" vs "harness limit").
//! * **The dump single source** — `oracle_dump`: the `SyntaxObject`
//!   tree normalizer every tree-axis parity compares through (the
//!   target-parser twin and the expander/compiler/infer/check
//!   harnesses share this exact grammar).
//! * **The RS-1 byte-table channel** — `byte_table_prefix`/
//!   `byte_table_literal`: one integer per byte, the
//!   source-injection channel every steady chain and the A/B/C
//!   pipeline feed through (zero freeze-surface change; the r151
//!   move from `lexer_parity` keeps the single source).
//! * **The parity key** — `error_parity_key`: stage Display +
//!   harness-rendered position payload (§9.56 DIAG-1).
//!
//! Payload conventions (the twins never inspect payloads — they
//! pass records through; the host re-reads them): spans ride as
//! decimal strings, floats as Debug-text strings, ints/bools/
//! strings as typed literals (i64 decimal always re-lexes,
//! including `i64::MIN`; the kerf escape set covers the string
//! round trip).

use kerf_reader::ReadError;
use kerf_runtime::Evaluator;
use kerf_span::ByteOffset;
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Heap, HeapObj, RuntimeError, Value, Vm};

use crate::diagnostic::Severity;
use crate::pipeline;
use crate::session::Session;

/// The `.ktf` harness's decoded verdict for one engine run — the
/// shared two-tag grammar (`("ok" ...)` / `("err" ...)`) generic
/// over the structured error type (the reader rebuilds a
/// `ReadError`, the expander a `ParityError`). §9.74 PAR-1: one
/// definition for both harnesses (the two pre-unification `KrfVerdict`
/// enums retired, the §9.73 dispatch_builtin lineage).
#[derive(Debug, Clone, PartialEq)]
pub(crate) enum KtfVerdict<E> {
    /// `("ok" form...)` — the normalized tree dump.
    Tree(String),
    /// `("err" kind payload...)` — the rebuilt structured error.
    Error(E),
}

// The seed-skin `KrfVerdict<ReadError>` text impl (the retired
// reader face's comparison key) left the tree with the r104 E5
// batch-3 teardown; the generic
// verdict and the shared decoders stay (the target chain's own
// harnesses consume them through their type specializations).

/// The error-axis parity key: stage Display + harness-rendered
/// position payload (§9.56 DIAG-1 compensations — offsets ride in
/// the payload, the key surfaces them).
pub fn error_parity_key(err: &ReadError) -> String {
    match err.offset() {
        Some(ByteOffset(at)) => format!("{err} @ byte {at}"),
        None => err.to_string(),
    }
}

// ---------- RS-1: the source-injected byte table ----------

/// Encode a source into the byte-table prefix — the RS-1 channel
/// with the payload generalized to one integer per byte (the
/// re-audit finding: lexical reachability needs no string
/// inspection primitives — plain integer arithmetic over the byte
/// table expresses every lexical decision).
pub fn byte_table_prefix(source: &str) -> String {
    // The empty source rides as `(quote nil)`: `nil` is the datum
    // face of the empty list (§1.4).
    if source.is_empty() {
        return "(define source-bytes (quote nil))\n".to_string();
    }
    let mut out = String::from("(define source-bytes (quote (");
    for (i, b) in source.as_bytes().iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        out.push_str(&b.to_string());
    }
    out.push_str(")))\n");
    out
}

/// The same RS-1 byte-table payload as a literal value tree — the
/// encoding [`byte_table_prefix`] spells as program text, delivered
/// for the W-3.12 injection channel (the steady-state chain binds
/// the table into a global slot instead of recompiling a per-source
/// prefix). The empty source rides as `nil`, mirroring the prefix
/// form's `(quote nil)`; the tail-built chain is one integer per
/// byte exactly as the text form spells them.
pub fn byte_table_literal(source: &str) -> kerf_core::LiteralValue {
    let mut list = kerf_core::LiteralValue::Nil;
    for b in source.as_bytes().iter().rev() {
        list = kerf_core::LiteralValue::Pair(
            Box::new(kerf_core::LiteralValue::Int(i64::from(*b))),
            Box::new(list),
        );
    }
    list
}

/// Classify one engine rejection of an assembled twin program (r74,
/// K165 — the CPython `_json.c` discipline: a recursion boundary is
/// classified at the failure site, never reported as a generic
/// crash). The two budget faces are the harness's honest input
/// envelope — the frozen subset expresses iteration only through
/// self-recursion, so a wide enough source exhausts an engine budget
/// — while every other runtime rejection is a harness defect.
pub(crate) fn classify_engine_failure(engine: &str, what: &str, err: &RuntimeError) -> String {
    if matches!(
        err,
        RuntimeError::BudgetExceeded { .. } | RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .ktf {what} exceeded the {engine} engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        format!("harness defect: the .ktf {what} crashed on the {engine} engine: {err}")
    }
}

// ---------- RS-3: the normalizers ----------

/// Encode one string as a kerf string literal. The escape set is
/// exactly the lexer's (`\"` `\\` `\n` `\t` `\r`); every other char
/// rides through raw — raw control characters are legal inside kerf
/// string literals, so the round trip is exact for any decoded text.
pub(crate) fn encode_string_literal(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(c),
        }
    }
    out.push('"');
    out
}

// ---------- RS-3: the two normalizers ----------

/// The oracle's normalized dump: every node as
/// `(kind start end payload...)`, lists as `(list s e child...)`.
pub fn oracle_dump(forms: &[SyntaxObject]) -> String {
    let mut out = String::new();
    for (i, f) in forms.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        dump_oracle_node(f, &mut out);
    }
    out
}

fn dump_oracle_node(node: &SyntaxObject, out: &mut String) {
    let (s, e) = (node.span.start.0, node.span.end.0);
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!("(ident {s} {e} {})", sym.as_str()));
        }
        StxDatum::Int(v) => {
            out.push_str(&format!("(int {s} {e} {v})"));
        }
        StxDatum::Float(v) => {
            out.push_str(&format!("(float {s} {e} {v:?})"));
        }
        StxDatum::Bool(v) => {
            out.push_str(&format!("(bool {s} {e} {v})"));
        }
        StxDatum::String(v) => {
            out.push_str(&format!("(string {s} {e} {v:?})"));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(list {s} {e}"));
            for item in items {
                out.push(' ');
                dump_oracle_node(item, out);
            }
            out.push(')');
        }
    }
}

/// The elements of a proper-list value (walks the pair chain). `Err`
/// reports a malformed chain — a structural defect of the .ktf
/// reader's own output, surfaced as drift.
pub(crate) fn value_elems<'v>(value: &'v Value, heap: &'v Heap) -> Result<Vec<&'v Value>, String> {
    let mut elems = Vec::new();
    let mut cur = value;
    loop {
        match cur {
            Value::Nil => return Ok(elems),
            Value::Pair(r) => match heap.get(*r) {
                Some(HeapObj::Pair(car, cdr)) => {
                    elems.push(car);
                    cur = cdr;
                }
                _ => return Err("dangling pair reference in the result chain".to_string()),
            },
            other => {
                let head = format!(
                    "{:?}",
                    elems
                        .first()
                        .map(|v| match v {
                            kerf_vm::Value::Str(s) => format!("Str({})", &**s),
                            kerf_vm::Value::Pair(r) => format!("Pair({r})"),
                            other_v => format!("{other_v:?}"),
                        })
                        .unwrap_or_else(|| "empty".to_string())
                );
                return Err(format!(
                    "improper list: chain ends in {other:?} (chain head: {head}; len {})",
                    elems.len()
                ));
            }
        }
    }
}

pub(crate) fn as_str(v: &Value) -> Result<&str, String> {
    match v {
        Value::Str(s) => Ok(&**s),
        other => Err(format!("expected a string field, found {other:?}")),
    }
}

pub(crate) fn as_i64(v: &Value) -> Result<i64, String> {
    match v {
        Value::Int(n) => Ok(*n),
        other => Err(format!("expected an int field, found {other:?}")),
    }
}

pub(crate) fn parse_span(v: &Value) -> Result<u32, String> {
    let text = as_str(v)?;
    text.parse::<u32>()
        .map_err(|_| format!("span field `{text}` is not a decimal offset"))
}

/// Assert a record's minimum field count (§9.76 SER-1; K172 — serde's
/// `invalid_length` shape: kind, actual count, needed count as a
/// structured error, never an index/slice panic). Every decode arm
/// that reaches past the common header fields carries one of these
/// ahead of its first payload access, so a malformed record produced
/// by the self-hosted layer under test reports drift, never a
/// harness panic (the documented `drive_dual_engines` contract).
pub(crate) fn need_fields(elems: &[&Value], n: usize, what: &str) -> Result<(), String> {
    if elems.len() < n {
        let plural = if elems.len() == 1 { "" } else { "s" };
        return Err(format!(
            "{what} record has {} field{plural}, need at least {n}",
            elems.len()
        ));
    }
    Ok(())
}

// ---------- RS-4: the dual-engine run (single source) ----------

/// Decode one engine's `result` global into a tagged verdict — the
/// single-source tag grammar for both parity harnesses (§9.74
/// PAR-1): the `"ok"` branch dumps every form through `dump`, the
/// `"err"` branch rebuilds the structured error through `rebuild`.
/// Everything else about the two harnesses' verdict grammars is
/// identical by construction.
pub(crate) fn decode_tagged<E>(
    value: &Value,
    heap: &Heap,
    dump: fn(&Value, &Heap, &mut String) -> Result<(), String>,
    rebuild: fn(&Value, &Heap) -> Result<E, String>,
) -> Result<KtfVerdict<E>, String> {
    let elems = value_elems(value, heap)?;
    let tag = elems
        .first()
        .and_then(|v| match v {
            Value::Str(s) => Some(&**s),
            _ => None,
        })
        .ok_or_else(|| "the result value is not a tagged list".to_string())?;
    match tag {
        "ok" => {
            let mut out = String::new();
            for (i, form) in elems[1..].iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump(form, heap, &mut out)?;
            }
            Ok(KtfVerdict::Tree(out))
        }
        "err" => Ok(KtfVerdict::Error(rebuild(value, heap)?)),
        other => Err(format!("unknown verdict tag `{other}`")),
    }
}

/// Drive one assembled `.ktf` harness program through both engines
/// and return the two decoded verdicts — the single source for the
/// reader/expander parity drivers and the gate-B host rebuild (three
/// hand-rolled twins retired; the §9.73 `dispatch_builtin` lineage).
/// §9.74 PAR-1.
///
/// `host_name` names the synthetic file for diagnostics; `what` is
/// the harness noun ("reader" / "expander") threaded into every
/// harness-failure message. The two decoders run **while their engine
/// — and its heap — is still alive** (heap-backed values; the
/// `run_parity` lineage): the vm decoder may rebuild richer state
/// (the gate-B item tree) while the eval decoder stays plain.
///
/// `Err` carries one of two classified prefixes (r74, K165 — the
/// CPython `_json.c` discipline of classifying a boundary at the
/// failure site):
/// * `"harness defect: …"` — the harness program failed a pipeline
///   stage, crashed on a non-budget runtime error, or produced an
///   undecodable result: a real harness bug;
/// * `"harness limit: …"` — an engine budget face (`BudgetExceeded` /
///   `EvalDepthExceeded`) rejected the harness program: the honest
///   **input envelope** of the harness, not a semantic drift. The
///   frozen subset expresses iteration only through self-recursion
///   (no loop primitive — the §9.29 termination argument), so a
///   source wide enough drives the per-token / per-record harness
///   walks past an engine budget.
///
/// Both classes are reported as drift, never a panic.
pub(crate) fn drive_dual_engines<VmOut, EvOut>(
    host_name: &str,
    what: &str,
    assembled: &str,
    decode_vm: impl Fn(&Value, &Heap) -> Result<VmOut, String>,
    decode_eval: impl Fn(&Value, &Heap) -> Result<EvOut, String>,
) -> Result<(VmOut, EvOut), String> {
    // The harness's own self-check step pins the Rust checkers (the
    // r147 TA-7 form): the assembled program is a CHAIN ARTIFACT (an
    // items prefix plus a twin source), not a user program — its
    // check verdict only feeds the harness's "must be clean"
    // assertion, so the switched twin position buys no verification
    // value here, while the inference twin's interpreted HM pass
    // over a 46KB-class artifact costs tens of seconds per drive
    // (the r147 measured regression: the corpus sweep ran 10x slower
    // until this pin). The read/expand steps keep their switched
    // production positions (the r145/r146 precedent — the assembled
    // drives are free extra input-domain coverage for those
    // segments, at milliseconds each).
    let mut session = Session::new();
    session.set_check_segment(crate::check_segment::CheckSegment::Rust);
    let program = pipeline::parse_with(&mut session, host_name, assembled).map_err(|diags| {
        format!("harness defect: the assembled {what} program failed to parse: {diags:?}")
    })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled {what} program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled {what} program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the {what} program: {err}"))?;
    vm.run()
        .map_err(|err| harness_run_failure("vm", what, &err))?;
    let vm_verdict = decode_vm(
        vm.global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?,
        vm.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| harness_run_failure("eval", what, &err))?;
    let eval_verdict = decode_eval(
        evaluator
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the eval engine".to_string())?,
        evaluator.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;
    Ok((vm_verdict, eval_verdict))
}

/// The std Error-instance vocabulary (W-SELFHOST-MODERN-2 blade 1,
/// r196 — the M15 single embedding): the pkg-logic twins consume
/// `attempt`/`unwrap`/`perform raise` off this library, so every
/// assembly embedding semver.ktf or micro-toml.ktf prepends it (the
/// r192 INST-1(a) prefix-injection form; the library file is the
/// vocabulary's single source, mounted exactly as the twins mount
/// their targets).
pub(crate) const STD_ERROR_TARGET_SOURCE: &str = include_str!("../../../../selfhost/std/error.ktf");

/// Drive one assembled `.ktf` harness program through the VM only
/// and return the decoded verdict — the single-engine face for the
/// effect-consuming twins (W-SELFHOST-MODERN-2 blade 1, r196 — the
/// M16 ruling; the modern2 window §9 verification-face decision).
///
/// The k-form handler clauses (`raise(e, k) => ...` — the halt form
/// of the Error instance) ride the VM's one-shot semantics (the r187
/// delivery); the eval engine's handler entry passes exactly the
/// performed args with no continuation argument, so a raise path
/// arity-mismatches there by construction. The five pkg-logic
/// parity families switch to this drive — the engine-agreement
/// axis retires for them, the oracle-comparison axis (twin-vm vs
/// the Rust oracle, per case) carries the full load; the window
/// doc §9 records the probe forensics and the ruling.
pub(crate) fn drive_vm_only<VmOut>(
    host_name: &str,
    what: &str,
    assembled: &str,
    decode_vm: impl Fn(&Value, &Heap) -> Result<VmOut, String>,
) -> Result<VmOut, String> {
    let mut session = Session::new();
    session.set_check_segment(crate::check_segment::CheckSegment::Rust);
    let program = pipeline::parse_with(&mut session, host_name, assembled).map_err(|diags| {
        format!("harness defect: the assembled {what} program failed to parse: {diags:?}")
    })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled {what} program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled {what} program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the {what} program: {err}"))?;
    vm.run()
        .map_err(|err| harness_run_failure("vm", what, &err))?;
    decode_vm(
        vm.global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?,
        vm.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))
}

/// Classify one engine rejection of the assembled harness program
/// (r74, K165 — the CPython `_json.c` discipline: a recursion
/// boundary is classified at the failure site, never reported as a
/// generic crash). The two budget faces are the harness's honest
/// input envelope — the frozen subset expresses iteration only
/// through self-recursion, so a wide enough source exhausts an
/// engine budget — while every other runtime rejection of the
/// harness program is a harness defect. Shared by the kp shell
/// bridge (the production resolver twin rides the same
/// classification — the blade 3b reuse).
pub(crate) fn harness_run_failure(engine: &str, what: &str, err: &RuntimeError) -> String {
    if matches!(
        err,
        RuntimeError::BudgetExceeded { .. } | RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .ktf {what} exceeded the {engine} engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        // The crash site rides the message (K182's span discipline:
        // classify at the failure site — a bare `crashed` forces
        // byte-level bisection to localize).
        format!(
            "harness defect: the .ktf {what} crashed on the {engine} engine at {} ({err})",
            err.span()
        )
    }
}

// ---------- RS-5: the dump comparison ----------

/// The first differing line pair of two dumps (the failure-line
/// precedent: name the case and the exact record that drifted).
/// Shared by the line-oriented dump harnesses (the target-lexer and
/// micro-toml parity drivers); the target-parser harness keeps its
/// own `)`-segmented private form — its dumps are single-line.
pub(crate) fn first_diff(a: &str, b: &str) -> Option<(String, String)> {
    for (la, lb) in a.lines().zip(b.lines()) {
        if la != lb {
            return Some((la.to_string(), lb.to_string()));
        }
    }
    let (x, y) = (a.lines().count(), b.lines().count());
    if x != y {
        Some((format!("<{x} lines>"), format!("<{y} lines>")))
    } else {
        None
    }
}

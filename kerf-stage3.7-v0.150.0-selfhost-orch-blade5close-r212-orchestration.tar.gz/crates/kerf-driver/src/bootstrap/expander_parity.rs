//! Macro parity — the third self-hosted front-end segment
//! (docs/stage0.md §9.48.4, plan-1.7.md; carried through the r104
//! E5 batch-3 teardown). The macro layer of the expander, written
//! in the frozen kerf subset itself (`selfhost/v1/macro.ktf`
//! assembled ahead of `expander.ktf` — the target-skin twins; the
//! seed-skin originals left the tree at E5), is checked against the
//! Rust expander oracle byte-for-byte on both axes:
//!
//! * **Tree axis** — the oracle `ModuleItem` tree (expansion plus
//!   the loader's validation pass, exactly the `pipeline::parse`
//!   composition) and the `.ktf` expander's `("ok" items...)`
//!   result normalize to the same dump: item records, expression
//!   records, literal-value records (Pair chains right-nested,
//!   floats as Debug text).
//! * **Error axis** — the `.ktf` expander reports a *structured*
//!   rejection (`("err" kind payload...)`); the harness rebuilds
//!   the `ExpandError` / `ModuleError` and renders it through the
//!   oracle's own `Display`, so byte parity holds by construction
//!   and the non-trivial part under test is the kind / payload /
//!   span selection (the seven span traps plus the 1.7
//!   `macro-mismatch` arm).
//!
//! The forms stream is source-injected (EX-1, 1.7 addendum: every
//! record carries a trailing generation int — source records ride
//! generation 0, macro products carry use_gen + 1): the host runs the
//! Rust reader — the single source of tree truth — and builds a
//! *flat pre-order* record stream as `(define forms (quote (...)))`,
//! which the target face transcodes
//! (`target_corpus::target_forms_stream_prefix`) ahead of the
//! expander twin. A `("list" s e n)` record's n
//! children follow it in the stream; the flat shape keeps the
//! assembled source inside the reader's 256 nesting cap even for
//! 255-deep trees (a nested encoding would need depth+3). Spans
//! ride as decimal strings; floats ride as Debug-text strings (the
//! 1.5 conventions, unchanged).
//!
//! Sources the *reader* rejects are decided by the 1.5 parity face
//! (the reader chain owns that axis); everything else runs the
//! assembled `.ktf` expander on **both engines** (the `run_parity`
//! lineage). Rename encoding (MX-1):
//! renamed identifiers ride as structured mangled records; the
//! host decodes `format!("{base}__macro_{counter}")`. Fixpoint
//! gate B (MX-6): axis (a) bytecode equality via the host
//! rebuilder, axis (b) the assembled-source self-application
//! fixpoint.
//!
//! Payload conventions (the `.ktf` expander never inspects
//! payloads — it passes records through; the host re-reads them):
//! spans and floats as above; ints/bools/strings as typed literals.

use kerf_core::{
    Binding, CoreError, CoreExpr, ExternAbi, ExternItem, ExternType, HandlerClause, LiteralValue,
    ModuleItem,
};
use kerf_expander::{ExpandError, ModuleError, expand_program, load_program};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{Heap, HeapObj, Value};

use crate::bootstrap::vm_harness::{
    KtfVerdict, as_i64, as_str, decode_tagged, encode_string_literal, need_fields, parse_span,
    value_elems,
};

/// One rebuilt rejection: an expansion error or a loader error
/// (the loader runs right after expansion in the production
/// pipeline — `pipeline::parse` — so both surfaces are in parity
/// scope for the 1.6 segment).
#[derive(Debug, Clone, PartialEq)]
pub enum ParityError {
    Expand(ExpandError),
    Module(ModuleError),
}

impl std::fmt::Display for ParityError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ParityError::Expand(err) => err.fmt(f),
            ParityError::Module(err) => err.fmt(f),
        }
    }
}

/// The `.ktf` expander's decoded verdict for one engine run — the
/// shared two-tag grammar, instantiated for the expander's
/// structured rejection type (§9.74 PAR-1: the twin enum retired;
/// the definition lives in `reader_parity` with the single-source
/// `decode_tagged`).
impl KtfVerdict<ParityError> {
    /// The rendered comparison text (item dump, or the parity-key
    /// form of the rebuilt error). §9.56 DIAG-1: the stage Display is
    /// position-free, so the harness appends the span payload
    /// itself — the comparison key must distinguish payloads (the
    /// drift detector depends on it), exactly like the tree-axis
    /// item dumps carry their `s e` offsets.
    pub(crate) fn text(&self) -> String {
        match self {
            KtfVerdict::Tree(dump) => dump.clone(),
            KtfVerdict::Error(err) => error_parity_key(err),
        }
    }
}

/// The error-axis parity key: stage Display + harness-rendered span
/// payload (§9.56 DIAG-1 compensation — spans ride in the payload,
/// the key surfaces them).
pub fn error_parity_key(err: &ParityError) -> String {
    let span = match err {
        ParityError::Expand(e) => e.span(),
        ParityError::Module(e) => e.span(),
    };
    format!("{err} @ {span}")
}

// ---------- EX-1: the source-injected forms stream ----------

/// Emit one tree node into the flat pre-order stream: atoms close
/// themselves; a list emits `("list" s e n)` and its n children
/// follow as the next records.
fn emit_stream_node(node: &SyntaxObject, out: &mut String) {
    let (s, e) = (node.span.start.0.to_string(), node.span.end.0.to_string());
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(\"ident\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(sym.as_str())
            ));
        }
        StxDatum::Int(v) => {
            out.push_str(&format!("(\"int\" \"{s}\" \"{e}\" {v} 0)"));
        }
        StxDatum::Float(v) => {
            // Debug text rides as a string (the 1.5 convention).
            out.push_str(&format!(
                "(\"float\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(&format!("{v:?}"))
            ));
        }
        StxDatum::Bool(v) => {
            let lit = if *v { "#t" } else { "#f" };
            out.push_str(&format!("(\"bool\" \"{s}\" \"{e}\" {lit} 0)"));
        }
        StxDatum::String(v) => {
            out.push_str(&format!(
                "(\"string\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(v)
            ));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(\"list\" \"{s}\" \"{e}\" {} 0)", items.len()));
            for item in items {
                out.push(' ');
                emit_stream_node(item, out);
            }
        }
    }
}

/// Build the `(define forms (quote (...)))` prefix for one
/// already-read form list (the caller split the reader layer).
pub fn forms_stream_prefix(forms: &[SyntaxObject]) -> String {
    // The empty forms list rides as `(quote nil)` — the datum face
    // of the empty list (subset-spec §2.5: `(quote ())` is a parse
    // error; the r85 byte-table precedent, now the 2.4 chain's
    // empty-source ledger row).
    let out = if forms.is_empty() {
        "(define forms (quote nil))\n".to_string()
    } else {
        let mut out = String::from("(define forms (quote (");
        for (i, form) in forms.iter().enumerate() {
            if i > 0 {
                out.push(' ');
            }
            emit_stream_node(form, &mut out);
        }
        out.push_str(")))");
        out
    };
    // ORCH blade 4 (P3): the `ex-struct-accs` / `ex-enum-ctors`
    // prefix sections RETIRED — the expander twin self-declares
    // both state globals and self-seeds the tables from its own
    // flat form stream (the `ex_acc_tables` walk). The prefix
    // carries ONLY the `forms` channel now; parity remains the
    // drift guard (the twin's self-seeded tables must match the
    // oracle's own formulas verdict-for-verdict).
    out
}

// ---------- EX-4: the two normalizers (tree axis) ----------

/// The oracle's normalized dump: items as `(kind start end
/// payload...)` — the same record grammar the `.ktf` expander
/// emits.
pub fn oracle_dump_items(items: &[ModuleItem]) -> String {
    let mut out = String::new();
    for (i, item) in items.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        dump_oracle_item(item, &mut out);
    }
    out
}

/// The spec value tree's canonical display (both arms share it —
/// the twin decodes its own value tree and renders the same text):
/// strings render bare, proper lists render space-separated in
/// parens, an improper tail renders after a dot (the scheme display
/// convention — deterministic, no quoting).
fn dump_lv(lv: &kerf_core::LiteralValue, out: &mut String) {
    use kerf_core::LiteralValue;
    match lv {
        LiteralValue::String(s) => out.push_str(s),
        LiteralValue::Int(v) => out.push_str(&v.to_string()),
        LiteralValue::Float(v) => out.push_str(&format!("{v:?}")),
        LiteralValue::Bool(v) => out.push_str(if *v { "true" } else { "false" }),
        LiteralValue::Nil => out.push_str("()"),
        LiteralValue::Pair(a, b) => {
            // Walk the chain: a proper list renders (e1 e2 ...);
            // an improper tail renders (e1 . rest).
            out.push('(');
            dump_lv(a, out);
            let mut cur: &LiteralValue = b;
            loop {
                match cur {
                    LiteralValue::Nil => break,
                    LiteralValue::Pair(a2, b2) => {
                        out.push(' ');
                        dump_lv(a2, out);
                        cur = b2;
                    }
                    rest => {
                        out.push_str(" . ");
                        dump_lv(rest, out);
                        break;
                    }
                }
            }
            out.push(')');
        }
    }
}

fn dump_oracle_item(item: &ModuleItem, out: &mut String) {
    match item {
        ModuleItem::Define { span, name, value } => {
            out.push_str(&format!(
                "(define {} {} {} ",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            dump_oracle_expr(value, out);
            out.push(')');
        }
        ModuleItem::Require { span, module } => {
            out.push_str(&format!(
                "(require {} {} {})",
                span.start.0,
                span.end.0,
                module.as_str()
            ));
        }
        ModuleItem::Annotate {
            span,
            anchor,
            kind,
            index,
            spec,
        } => {
            // The blade 1 dann site record — both arms render the
            // same grammar: (dann s e kind as ae index spec-display).
            out.push_str(&format!(
                "(dann {} {} {} {} {} {} ",
                span.start.0,
                span.end.0,
                kind.kind_tag(),
                anchor.start.0,
                anchor.end.0,
                index
            ));
            dump_lv(spec, out);
            out.push(')');
        }
        ModuleItem::Struct { span, name, fields } => {
            // The blade 2 struct declaration record (GZ-2) — both
            // arms render the same grammar: (dstruct s e name
            // (field spec)...), one two-element list per field in
            // declaration order (the define-ann param strip's own
            // shape).
            out.push_str(&format!(
                "(dstruct {} {} {}",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            for (fname, spec) in fields {
                out.push_str(&format!(" ({} ", fname.as_str()));
                dump_lv(spec, out);
                out.push(')');
            }
            out.push(')');
        }
        ModuleItem::Enum {
            span,
            name,
            variants,
        } => {
            // The blade 3 enum declaration record (GZ-4) — both
            // arms render the same grammar: (denum s e name
            // (variant)...), one list per variant in declaration
            // order — (v) for the payload-less form, (v spec...)
            // for the payload form (the struct field strip's own
            // shape at the variant face).
            out.push_str(&format!(
                "(denum {} {} {}",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            for (vname, specs) in variants {
                out.push_str(&format!(" ({}", vname.as_str()));
                for spec in specs {
                    out.push(' ');
                    dump_lv(spec, out);
                }
                out.push(')');
            }
            out.push(')');
        }
        ModuleItem::Module { span, name, items } => {
            out.push_str(&format!(
                "(module {} {} {}",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            for inner in items {
                out.push(' ');
                dump_oracle_item(inner, out);
            }
            out.push(')');
        }
        ModuleItem::Extern { span, items, .. } => {
            // W-3.2: the extern record — spans and signatures.
            out.push_str(&format!(
                "(extern {} {} {}",
                span.start.0,
                span.end.0,
                items.len()
            ));
            for entry in items {
                out.push_str(&format!(
                    " ({} {} [{}] {})",
                    entry.span.start.0,
                    entry.span.end.0,
                    entry
                        .params
                        .iter()
                        .map(|t| t.kind_tag())
                        .collect::<Vec<_>>()
                        .join(","),
                    entry.ret.kind_tag()
                ));
            }
            out.push(')');
        }
        ModuleItem::DefineSyntax { span, name } => {
            out.push_str(&format!(
                "(defsyn {} {} {})",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
        }
    }
}

fn dump_oracle_expr(expr: &CoreExpr, out: &mut String) {
    let span = expr_span(expr);
    match expr {
        CoreExpr::Fn { params, body, .. } => {
            out.push_str(&format!("(fn {} {} (", span.start.0, span.end.0));
            for (i, p) in params.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                out.push_str(p.as_str());
            }
            out.push_str(") ");
            dump_oracle_expr(body, out);
            out.push(')');
        }
        CoreExpr::Apply { func, args, .. } => {
            out.push_str(&format!("(apply {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(func, out);
            for arg in args {
                out.push(' ');
                dump_oracle_expr(arg, out);
            }
            out.push(')');
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            out.push_str(&format!("(if {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(cond, out);
            out.push(' ');
            dump_oracle_expr(then_branch, out);
            out.push(' ');
            dump_oracle_expr(else_branch, out);
            out.push(')');
        }
        CoreExpr::Var { name, .. } => {
            out.push_str(&format!(
                "(var {} {} {})",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
        }
        CoreExpr::Literal { value, .. } => {
            out.push_str(&format!("(lit {} {} ", span.start.0, span.end.0));
            dump_oracle_lit(value, out);
            out.push(')');
        }
        CoreExpr::Assign { name, value, .. } => {
            out.push_str(&format!(
                "(assign {} {} {} ",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            dump_oracle_expr(value, out);
            out.push(')');
        }
        CoreExpr::Let { bindings, body, .. } => {
            out.push_str(&format!("(let {} {} (", span.start.0, span.end.0));
            for (i, b) in bindings.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_oracle_binding(b, out);
            }
            out.push_str(") ");
            dump_oracle_expr(body, out);
            out.push(')');
        }
        CoreExpr::Perform { effect, args, .. } => {
            out.push_str(&format!(
                "(perform {} {} {}",
                span.start.0,
                span.end.0,
                effect.as_str()
            ));
            for arg in args {
                out.push(' ');
                dump_oracle_expr(arg, out);
            }
            out.push(')');
        }
        CoreExpr::Handle { body, handlers, .. } => {
            out.push_str(&format!("(handle {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(body, out);
            out.push_str(" (");
            for (i, h) in handlers.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_oracle_clause(h, out);
            }
            out.push_str("))");
        }
    }
}

/// Every CoreExpr variant carries a `span` field (the constructor
/// contract); this reads it without consuming the enum.
fn expr_span(expr: &CoreExpr) -> Span {
    match expr {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

fn dump_oracle_binding(b: &Binding, out: &mut String) {
    out.push_str(&format!("({} {} ", b.span.start.0, b.span.end.0));
    out.push_str(b.name.as_str());
    out.push(' ');
    dump_oracle_expr(&b.value, out);
    out.push(')');
}

fn dump_oracle_clause(h: &HandlerClause, out: &mut String) {
    out.push_str(&format!("({} {} ", h.span.start.0, h.span.end.0));
    out.push_str(h.effect.as_str());
    out.push(' ');
    dump_oracle_expr(&h.handler, out);
    out.push(')');
}

pub(crate) fn dump_oracle_lit(value: &LiteralValue, out: &mut String) {
    // The right spine walks ITERATIVELY (the K163 family's r148
    // sixth instance — the `dump_ktf_litval`/`rebuild_lit`/
    // `emit_litval_literal` precedents): a flat list's right spine
    // is as deep as the list is long, and this oracle-side text
    // face feeds the parity comparisons the same user quote data.
    // The per-car recursion is bounded by the read nesting cap (a
    // car's own spine rides this same iterative walk through the
    // recursive call). The text is byte-identical to the recursive
    // form: one `(pair CAR CDR)` level per spine cell, the tail as
    // its own literal text.
    let mut cars: Vec<&LiteralValue> = Vec::new();
    let mut cur = value;
    let tail = loop {
        match cur {
            LiteralValue::Pair(a, b) => {
                cars.push(a);
                cur = b;
            }
            other => break other,
        }
    };
    if cars.is_empty() {
        dump_oracle_atom(tail, out);
        return;
    }
    let mut text = String::new();
    dump_oracle_atom(tail, &mut text);
    for car in cars.iter().rev() {
        let mut car_text = String::new();
        dump_oracle_lit(car, &mut car_text);
        text = format!("(pair {car_text} {text})");
    }
    out.push_str(&text);
}

/// One atom's literal text (the recursive form's atom arms, exactly).
fn dump_oracle_atom(value: &LiteralValue, out: &mut String) {
    match value {
        LiteralValue::Int(v) => out.push_str(&format!("(int {v})")),
        LiteralValue::Float(v) => out.push_str(&format!("(float {v:?})")),
        LiteralValue::Bool(v) => out.push_str(&format!("(bool {v})")),
        LiteralValue::String(v) => out.push_str(&format!("(string {v:?})")),
        LiteralValue::Nil => out.push_str("nil"),
        // A pair never reaches here (the spine walk consumed it);
        // the unreachable arm keeps the match exhaustive without a
        // silent wildcard.
        LiteralValue::Pair(..) => unreachable!("the spine walk consumed every pair cell"),
    }
}

// The `.ktf` expander's normalized item dump (the same grammar as
// [`oracle_dump_items`]; span strings re-parse to offsets, float
// text rides verbatim).

/// A dump-record name field: either a plain string (a source
/// identifier) or a structured mangled record
/// `("mangled" s e base counter gen)` (a renamed introduced
/// identifier — MX-1). Decoded here to the concatenated form the
/// oracle carries, so the byte comparison covers the rename
/// decision face (which symbol renamed, which counter) while the
/// deterministic rendering stays host-side.
pub(crate) fn ktf_name(v: &Value, heap: &Heap) -> Result<String, String> {
    if let Value::Str(s) = v {
        return Ok((**s).to_owned());
    }
    let elems = value_elems(v, heap)?;
    if elems.len() >= 5 && as_str(elems[0])? == "mangled" {
        let base = as_str(elems[3])?;
        let counter = match elems[4] {
            Value::Int(n) => n,
            other => return Err(format!("mangled counter is not an int: {other:?}")),
        };
        return Ok(format!("{base}__macro_{counter}"));
    }
    Err(format!(
        "expected a name (string or mangled record), found {v:?}"
    ))
}

/// The twin-side spec value display — the VM value tree rendering
/// the same text as the oracle's `dump_lv` (strings bare, proper
/// lists in parens, improper tails after a dot).
fn dump_ktf_lv(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    match value {
        Value::Str(s) => {
            out.push_str(s);
            Ok(())
        }
        Value::Int(v) => {
            out.push_str(&v.to_string());
            Ok(())
        }
        Value::Float(v) => {
            out.push_str(&format!("{v:?}"));
            Ok(())
        }
        Value::Bool(v) => {
            out.push_str(if *v { "true" } else { "false" });
            Ok(())
        }
        Value::Nil => {
            out.push_str("()");
            Ok(())
        }
        Value::Pair(r) => match heap.get(*r) {
            Some(HeapObj::Pair(car, cdr)) => {
                out.push('(');
                dump_ktf_lv(car, heap, out)?;
                let mut cur: &Value = cdr;
                loop {
                    match cur {
                        Value::Nil => break,
                        Value::Pair(r2) => match heap.get(*r2) {
                            Some(HeapObj::Pair(a2, b2)) => {
                                out.push(' ');
                                dump_ktf_lv(a2, heap, out)?;
                                cur = b2;
                            }
                            _ => {
                                return Err("spec value chain is not a value tree".to_string());
                            }
                        },
                        _ => {
                            out.push_str(" . ");
                            dump_ktf_lv(cur, heap, out)?;
                            break;
                        }
                    }
                }
                out.push(')');
                Ok(())
            }
            _ => Err("spec value pair is malformed".to_string()),
        },
        _ => Err("spec value carries a non-value payload".to_string()),
    }
}

fn dump_ktf_item(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 4 {
        return Err(format!(
            "item record has {} fields, need at least kind/start/end/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?.to_string();
    let s = parse_span(elems[1])?;
    let e = parse_span(elems[2])?;
    match kind.as_str() {
        "define" => {
            need_fields(&elems, 5, "`define` item")?;
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(define {s} {e} {name} "));
            dump_ktf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "require" => {
            let module = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(require {s} {e} {module})"));
        }
        "dann" => {
            // The blade 1 dann site record — the twin arm of
            // dump_oracle_item's Annotate case (the same grammar).
            need_fields(&elems, 8, "`dann` item")?;
            let kind = as_str(elems[3])?;
            let as_ = parse_span(elems[4])?;
            let ae = parse_span(elems[5])?;
            let index = as_i64(elems[6])?;
            out.push_str(&format!("(dann {s} {e} {kind} {as_} {ae} {index} "));
            dump_ktf_lv(elems[7], heap, out)?;
            out.push(')');
        }
        "dstruct" => {
            // The blade 2 struct declaration record — the twin arm
            // of dump_oracle_item's Struct case (the same grammar).
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(dstruct {s} {e} {name}"));
            for field in &elems[4..] {
                let fe = value_elems(field, heap)?;
                if fe.len() != 2 {
                    return Err(format!(
                        "dstruct field record has {} fields, need name/spec",
                        fe.len()
                    ));
                }
                out.push(' ');
                out.push('(');
                out.push_str(&ktf_name(fe[0], heap)?);
                out.push(' ');
                dump_ktf_lv(fe[1], heap, out)?;
                out.push(')');
            }
            out.push(')');
        }
        "denum" => {
            // The blade 3 enum declaration record — the twin arm
            // of dump_oracle_item's Enum case (the same grammar):
            // each variant a (name spec-tree...) value list — at
            // least the name; a payload-less variant is the
            // one-element carrier.
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(denum {s} {e} {name}"));
            for variant in &elems[4..] {
                let ve = value_elems(variant, heap)?;
                if ve.is_empty() {
                    return Err(format!(
                        "denum variant record has {} entries, need at least the name",
                        ve.len()
                    ));
                }
                out.push(' ');
                out.push('(');
                out.push_str(&ktf_name(ve[0], heap)?);
                for spec in &ve[1..] {
                    out.push(' ');
                    dump_ktf_lv(spec, heap, out)?;
                }
                out.push(')');
            }
            out.push(')');
        }
        "module" => {
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(module {s} {e} {name}"));
            for child in &elems[4..] {
                out.push(' ');
                dump_ktf_item(child, heap, out)?;
            }
            out.push(')');
        }
        "defsyn" => {
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(defsyn {s} {e} {name})"));
        }
        "extern" => {
            // The W-3.2 FFI block (the r122 twin refresh): the
            // oracle's dump grammar — the entry count, then one
            // (es ee [param-tags] ret-tag) per entry, the NAMES
            // carried by the record but not rendered (the oracle's
            // own dump omits them; the items-equality face covers
            // the names).
            let entries = &elems[3..];
            out.push_str(&format!("(extern {s} {e} {}", entries.len()));
            for entry in entries {
                let ee = value_elems(entry, heap)?;
                if ee.len() != 5 {
                    return Err(format!(
                        "extern entry record has {} fields, need name/es/ee/params/ret",
                        ee.len()
                    ));
                }
                let params = value_elems(ee[3], heap)?;
                let mut tags = Vec::with_capacity(params.len());
                for ty in params {
                    tags.push(as_str(ty)?);
                }
                out.push_str(&format!(
                    " ({} {} [{}] {})",
                    parse_span(ee[1])?,
                    parse_span(ee[2])?,
                    tags.join(","),
                    as_str(ee[4])?
                ));
            }
            out.push(')');
        }
        other => return Err(format!("unknown item kind `{other}`")),
    }
    Ok(())
}

fn dump_ktf_expr(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 4 {
        return Err(format!(
            "expr record has {} fields, need at least kind/start/end/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?.to_string();
    let s = parse_span(elems[1])?;
    let e = parse_span(elems[2])?;
    match kind.as_str() {
        "fn" => {
            need_fields(&elems, 5, "`fn` expr")?;
            let params = value_elems(elems[3], heap)?;
            out.push_str(&format!("(fn {s} {e} ("));
            for (i, p) in params.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                out.push_str(&ktf_name(p, heap)?);
            }
            out.push_str(") ");
            dump_ktf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "apply" => {
            need_fields(&elems, 5, "`apply` expr")?;
            out.push_str(&format!("(apply {s} {e} "));
            dump_ktf_expr(elems[3], heap, out)?;
            for arg in &elems[4..elems.len() - 1] {
                out.push(' ');
                dump_ktf_expr(arg, heap, out)?;
            }
            out.push(')');
        }
        "if" => {
            need_fields(&elems, 6, "`if` expr")?;
            out.push_str(&format!("(if {s} {e} "));
            dump_ktf_expr(elems[3], heap, out)?;
            out.push(' ');
            dump_ktf_expr(elems[4], heap, out)?;
            out.push(' ');
            dump_ktf_expr(elems[5], heap, out)?;
            out.push(')');
        }
        "var" => {
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(var {s} {e} {name})"));
        }
        "lit" => {
            out.push_str(&format!("(lit {s} {e} "));
            dump_ktf_litval(elems[3], heap, out)?;
            out.push(')');
        }
        "assign" => {
            need_fields(&elems, 5, "`assign` expr")?;
            let name = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(assign {s} {e} {name} "));
            dump_ktf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "let" => {
            need_fields(&elems, 5, "`let` expr")?;
            let bindings = value_elems(elems[3], heap)?;
            out.push_str(&format!("(let {s} {e} ("));
            for (i, b) in bindings.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                let be = value_elems(b, heap)?;
                if be.len() != 5 {
                    return Err(format!(
                        "binding record has {} fields, need bs/be/name/expr/gen",
                        be.len()
                    ));
                }
                out.push_str(&format!(
                    "({} {} {} ",
                    parse_span(be[0])?,
                    parse_span(be[1])?,
                    ktf_name(be[2], heap)?
                ));
                dump_ktf_expr(be[3], heap, out)?;
                out.push(')');
            }
            out.push_str(") ");
            dump_ktf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "perform" => {
            need_fields(&elems, 5, "`perform` expr")?;
            let effect = ktf_name(elems[3], heap)?;
            out.push_str(&format!("(perform {s} {e} {effect}"));
            for arg in &elems[4..elems.len() - 1] {
                out.push(' ');
                dump_ktf_expr(arg, heap, out)?;
            }
            out.push(')');
        }
        "handle" => {
            need_fields(&elems, 5, "`handle` expr")?;
            out.push_str(&format!("(handle {s} {e} "));
            dump_ktf_expr(elems[3], heap, out)?;
            out.push_str(" (");
            let clauses = value_elems(elems[4], heap)?;
            for (i, c) in clauses.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                let ce = value_elems(c, heap)?;
                if ce.len() != 5 {
                    return Err(format!(
                        "clause record has {} fields, need cs/ce/effect/handler/gen",
                        ce.len()
                    ));
                }
                out.push_str(&format!(
                    "({} {} {} ",
                    parse_span(ce[0])?,
                    parse_span(ce[1])?,
                    ktf_name(ce[2], heap)?
                ));
                dump_ktf_expr(ce[3], heap, out)?;
                out.push(')');
            }
            out.push_str("))");
        }
        other => return Err(format!("unknown expr kind `{other}`")),
    }
    Ok(())
}

pub(crate) fn dump_ktf_litval(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    // The nil literal is a bare nil value (no record wrapper).
    if matches!(value, Value::Nil) {
        out.push_str("nil");
        return Ok(());
    }
    let elems = value_elems(value, heap)?;
    if elems.len() < 2 {
        return Err(format!(
            "litval record has {} fields, need kind/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?;
    match kind {
        "int" => {
            let v = match elems[1] {
                Value::Int(n) => *n,
                other => return Err(format!("expected an int payload, found {other:?}")),
            };
            out.push_str(&format!("(int {v})"));
        }
        "float" => {
            // Debug text rides verbatim (the stream encoded it).
            let text = as_str(elems[1])?;
            out.push_str(&format!("(float {text})"));
        }
        "bool" => {
            let v = match elems[1] {
                Value::Bool(b) => *b,
                other => return Err(format!("expected a bool payload, found {other:?}")),
            };
            out.push_str(&format!("(bool {v})"));
        }
        "string" => {
            let text = as_str(elems[1])?;
            out.push_str(&format!("(string {text:?})"));
        }
        "pair" => {
            need_fields(&elems, 3, "`pair` litval")?;
            // The right spine walks ITERATIVELY (the `rebuild_lit`
            // precedent, the K163 family's r148 sixth instance: a
            // stream record list is thousands of nested pair RECORDS
            // long, and this TEXT face builds the verdict text
            // unconditionally on every twin drive — the car recursion
            // alone is bounded by the read nesting cap). The text is
            // byte-identical to the recursive form: one `(pair CAR
            // CDR)` level per spine cell, the tail rendering as its
            // own literal text (`nil` for the proper-list end).
            let mut cars: Vec<&Value> = vec![elems[1]];
            let mut cur: &Value = elems[2];
            let dotted_tail = loop {
                match cur {
                    Value::Nil => break None,
                    other => {
                        let next = value_elems(other, heap)?;
                        if next.len() != 3 || as_str(next[0])? != "pair" {
                            // The dotted-literal face: one final
                            // element (a raw atom that is not a
                            // record fails loud in `value_elems`,
                            // never silently).
                            break Some(other);
                        }
                        cars.push(next[1]);
                        cur = next[2];
                    }
                }
            };
            let mut text = match dotted_tail {
                None => "nil".to_string(),
                Some(tail) => {
                    let mut tail_text = String::new();
                    dump_ktf_litval(tail, heap, &mut tail_text)?;
                    tail_text
                }
            };
            for car in cars.iter().rev() {
                let mut car_text = String::new();
                dump_ktf_litval(car, heap, &mut car_text)?;
                text = format!("(pair {car_text} {text})");
            }
            out.push_str(&text);
        }
        other => return Err(format!("unknown litval kind `{other}`")),
    }
    Ok(())
}

// ---------- EX-4: the structured-error rebuild (error axis) ----------

/// Rebuild a span from two decimal-string offsets (the parity file
/// is always `file#0`; generation is ROOT — 1.6 output spans are
/// all generation-0 source spans).
pub(crate) fn make_span(s: &Value, e: &Value) -> Result<Span, String> {
    let start = parse_span(s)?;
    let end = parse_span(e)?;
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId::ROOT,
    )
    .map_err(|err| format!("reconstructed span rejected: {err:?}"))
}

/// Map a malformed-form name onto its static str (the enum field is
/// `&'static str`).
fn static_form(name: &str) -> Result<&'static str, String> {
    Ok(match name {
        "fn" => "fn",
        "if" => "if",
        "let" => "let",
        "do" => "do",
        "set!" => "set!",
        "perform" => "perform",
        "handle" => "handle",
        "match" => "match",
        "quote" => "quote",
        "define" => "define",
        "require" => "require",
        "module" => "module",
        "define-syntax" => "define-syntax",
        other => return Err(format!("unknown malformed form `{other}`")),
    })
}

/// Rebuild the rejection from a `("err" kind payload...)` value.
/// The caller renders it through the oracle's own `Display`, so
/// message-text parity holds by construction; what this checks is
/// that the `.ktf` expander chose the right kind and payload.
pub fn reconstruct_expand_error(value: &Value, heap: &Heap) -> Result<ParityError, String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 3 || as_str(elems[0])? != "err" {
        return Err("expected an (\"err\" kind payload...) value".to_string());
    }
    let kind = as_str(elems[1])?;
    let err = match kind {
        "unbound" => {
            need_fields(&elems, 5, "`unbound` rejection")?;
            ParityError::Expand(ExpandError::UnboundIdentifier {
                // §9.65 EXP-1: the payload is the interned identity —
                // reconstruct it through the single pool, never a
                // de-interned text copy (the MOD-1 decoder precedent).
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "macro-mismatch" => {
            need_fields(&elems, 5, "`macro-mismatch` rejection")?;
            ParityError::Expand(ExpandError::MacroPatternMismatch {
                // §9.65 EXP-2: same single-pool reconstruction.
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "malformed" => {
            need_fields(&elems, 5, "`malformed` rejection")?;
            ParityError::Expand(ExpandError::MalformedForm {
                form: static_form(as_str(elems[2])?)?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "top" => {
            need_fields(&elems, 4, "`top` rejection")?;
            ParityError::Expand(ExpandError::TopLevelExpression {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "quote-datum" => {
            need_fields(&elems, 4, "`quote-datum` rejection")?;
            ParityError::Expand(ExpandError::QuoteUnsupportedDatum {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "depth" => {
            need_fields(&elems, 5, "`depth` rejection")?;
            ParityError::Expand(ExpandError::ExpansionDepthExceeded {
                // The payload carries its own limit (the budget
                // parameterization: the twin's `ex_limit` global —
                // the rejection is self-describing, so the decode
                // stays position-free and budget-free).
                limit: usize::try_from(as_i64(elems[2])?).map_err(|_| "depth limit is negative")?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "empty" => {
            need_fields(&elems, 4, "`empty` rejection")?;
            ParityError::Expand(ExpandError::EmptyForm {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "dup-param" => {
            need_fields(&elems, 5, "`dup-param` rejection")?;
            ParityError::Expand(ExpandError::Core {
                source: CoreError::DuplicateParam {
                    // §9.65 EXP-4: the payload is the interned identity —
                    // rebuilt through the single pool.
                    name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                },
                span: make_span(elems[3], elems[4])?,
            })
        }
        "dup-handler" => {
            need_fields(&elems, 5, "`dup-handler` rejection")?;
            ParityError::Expand(ExpandError::Core {
                source: CoreError::DuplicateHandler {
                    // §9.65 EXP-5: same single-pool reconstruction.
                    effect: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                },
                span: make_span(elems[3], elems[4])?,
            })
        }
        "mod-dup" => {
            need_fields(&elems, 5, "`mod-dup` rejection")?;
            ParityError::Module(ModuleError::ModuleDuplicate {
                // §9.64 MOD-1: the payload is the interned identity —
                // reconstruct it through the single pool, never a
                // de-interned text copy.
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "mod-missing" => {
            need_fields(&elems, 5, "`mod-missing` rejection")?;
            ParityError::Module(ModuleError::ModuleNotFound {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "mod-cycle" => {
            need_fields(&elems, 5, "`mod-cycle` rejection")?;
            let path_elems = value_elems(elems[2], heap)?;
            let mut path = Vec::with_capacity(path_elems.len());
            for p in path_elems {
                path.push(Symbol::new(as_str(p)?).map_err(|e| e.to_string())?);
            }
            ParityError::Module(ModuleError::ModuleCycle {
                path,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "extern-abi" => {
            // The W-3.2 extern police's expressible faces (the r122
            // twin refresh); the C-symbol-derived faces stay
            // Rust-side (the disclosed twin boundary).
            need_fields(&elems, 4, "`extern-abi` rejection")?;
            ParityError::Expand(ExpandError::ExternAbiUnsupported {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "extern-type" => {
            need_fields(&elems, 5, "`extern-type` rejection")?;
            ParityError::Expand(ExpandError::ExternTypeUnsupported {
                ty: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "extern-collision" => {
            need_fields(&elems, 5, "`extern-collision` rejection")?;
            ParityError::Expand(ExpandError::ExternNameCollision {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "extern-not-top" => {
            need_fields(&elems, 4, "`extern-not-top` rejection")?;
            ParityError::Expand(ExpandError::ExternNotTopLevel {
                span: make_span(elems[2], elems[3])?,
            })
        }
        // The blade 2 struct police family (GZ-2): the five
        // expressible faces; the accessor-name join itself is the
        // injected table's own (the disclosed boundary —
        // `struct-acc-missing` is a harness defect class that never
        // reaches a parity comparison).
        "struct-not-top" => {
            need_fields(&elems, 4, "`struct-not-top` rejection")?;
            ParityError::Expand(ExpandError::StructNotTopLevel {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "struct-redeclared" => {
            need_fields(&elems, 5, "`struct-redeclared` rejection")?;
            ParityError::Expand(ExpandError::StructRedeclared {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "struct-collision" => {
            need_fields(&elems, 5, "`struct-collision` rejection")?;
            ParityError::Expand(ExpandError::StructNameCollision {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "struct-reserved" => {
            need_fields(&elems, 5, "`struct-reserved` rejection")?;
            ParityError::Expand(ExpandError::StructNameReserved {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "struct-dup-field" => {
            need_fields(&elems, 5, "`struct-dup-field` rejection")?;
            ParityError::Expand(ExpandError::StructDuplicateField {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "struct-field-reserved" => {
            need_fields(&elems, 5, "`struct-field-reserved` rejection")?;
            ParityError::Expand(ExpandError::StructFieldReserved {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        // The blade 3 enum police family (GZ-4, r168-b2): the seven
        // expressible faces — the malformed carrier reuses the
        // generic `malformed` kind (form "enum", the existing
        // mapping's own), and the ctor-table miss
        // (`enum-ctor-missing`) is a harness defect class that never
        // reaches a parity comparison (the `struct-acc-missing`
        // disclosed boundary's own).
        "enum-not-top" => {
            need_fields(&elems, 4, "`enum-not-top` rejection")?;
            ParityError::Expand(ExpandError::EnumNotTopLevel {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "enum-redeclared" => {
            need_fields(&elems, 5, "`enum-redeclared` rejection")?;
            ParityError::Expand(ExpandError::EnumRedeclared {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "enum-collision" => {
            need_fields(&elems, 5, "`enum-collision` rejection")?;
            ParityError::Expand(ExpandError::EnumNameCollision {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "enum-reserved" => {
            need_fields(&elems, 5, "`enum-reserved` rejection")?;
            ParityError::Expand(ExpandError::EnumNameReserved {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "enum-dup-variant" => {
            need_fields(&elems, 5, "`enum-dup-variant` rejection")?;
            ParityError::Expand(ExpandError::EnumDuplicateVariant {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "enum-variant-reserved" => {
            need_fields(&elems, 5, "`enum-variant-reserved` rejection")?;
            ParityError::Expand(ExpandError::EnumVariantReserved {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "enum-variant-cross" => {
            need_fields(&elems, 5, "`enum-variant-cross` rejection")?;
            ParityError::Expand(ExpandError::EnumVariantNameCollision {
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        // The TD-027 match family (r143): the twin's match arm
        // reports both structured rejections the oracle carries.
        "nonexhaustive" => {
            need_fields(&elems, 4, "`nonexhaustive` rejection")?;
            ParityError::Expand(ExpandError::NonExhaustiveMatch {
                span: make_span(elems[2], elems[3])?,
            })
        }
        "unsupported-pattern" => {
            need_fields(&elems, 4, "`unsupported-pattern` rejection")?;
            ParityError::Expand(ExpandError::UnsupportedPattern {
                span: make_span(elems[2], elems[3])?,
            })
        }
        other => return Err(format!("unknown error kind `{other}`")),
    };
    Ok(err)
}

/// Decode one engine's `result` global into a verdict (while that
/// engine — and its heap — is still alive). §9.74 PAR-1: the
/// tag grammar is the single-source `decode_tagged`; the expander
/// contributes its item dumper and its rejection rebuilder.
pub(crate) fn decode_verdict(
    value: &Value,
    heap: &Heap,
) -> Result<KtfVerdict<ParityError>, String> {
    decode_tagged(value, heap, dump_ktf_item, reconstruct_expand_error)
}

// ---------- EX-5: the dual-engine run (single-source driver) ----------

// ---------- MX-6 gate B: the host rebuilder + the two axes ----------

/// Rebuild a generation-carrying span from a record's span fields
/// and trailing generation int (the 1.7 record addendum; the dump
/// TEXT stays generation-free).
fn gen_span(s: &Value, e: &Value, g: &Value) -> Result<Span, String> {
    let start = parse_span(s)?;
    let end = parse_span(e)?;
    let generation = match g {
        Value::Int(n) => *n,
        other => return Err(format!("generation field is not an int: {other:?}")),
    };
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId(u32::try_from(generation).map_err(|_| "negative generation")?),
    )
    .map_err(|err| format!("rebuilt span rejected: {err:?}"))
}

/// The last field of a record (the generation).
fn last_field<'a>(elems: &[&'a Value]) -> Result<&'a Value, String> {
    elems
        .last()
        .copied()
        .ok_or_else(|| "empty record".to_string())
}

/// Rebuild the item tree from the `.ktf` expander's result value
/// (the dump-grammar records carry the trailing generation the
/// rebuild threads into the spans; name fields decode through
/// [`ktf_name`]). This is the gate-B axis (a) face: the rebuilt
/// `ModuleItem`s compile through the real `compile_program` and
/// compare by `Bytecode: PartialEq` against the oracle's own.
/// The VM value tree -> LiteralValue decode (the dann spec payload —
/// strings, ints, floats, bools, nil, and pair chains; anything else
/// is a harness defect, never a silent default).
fn rebuild_lv(value: &Value, heap: &Heap) -> Result<kerf_core::LiteralValue, String> {
    use kerf_core::LiteralValue;
    use std::rc::Rc;
    match value {
        Value::Str(s) => Ok(LiteralValue::String(Rc::from(&**s))),
        Value::Int(v) => Ok(LiteralValue::Int(*v)),
        Value::Float(v) => Ok(LiteralValue::Float(*v)),
        Value::Bool(v) => Ok(LiteralValue::Bool(*v)),
        Value::Nil => Ok(LiteralValue::Nil),
        Value::Pair(r) => match heap.get(*r) {
            Some(HeapObj::Pair(car, cdr)) => Ok(LiteralValue::Pair(
                Box::new(rebuild_lv(car, heap)?),
                Box::new(rebuild_lv(cdr, heap)?),
            )),
            _ => Err("spec value pair is malformed".to_string()),
        },
        _ => Err("spec value carries a non-value payload".to_string()),
    }
}

pub(crate) fn rebuild_items(value: &Value, heap: &Heap) -> Result<Vec<ModuleItem>, String> {
    let elems = value_elems(value, heap)?;
    if elems.first().and_then(|v| as_str(v).ok()) != Some("ok") {
        return Err("cannot rebuild items from a rejection".to_string());
    }
    let mut items = Vec::with_capacity(elems.len() - 1);
    for item in &elems[1..] {
        items.push(rebuild_item(item, heap)?);
    }
    Ok(items)
}

fn rebuild_item(v: &Value, heap: &Heap) -> Result<ModuleItem, String> {
    let elems = value_elems(v, heap)?;
    if elems.len() < 4 {
        return Err(format!("item record has {} fields", elems.len()));
    }
    // Declaration records carry NO generation field (source-level
    // only — an expression template cannot produce one): the
    // rebuilt span rides the ROOT generation.
    let span = make_span(elems[1], elems[2])?;
    match as_str(elems[0])? {
        "define" => {
            need_fields(&elems, 5, "`define` item")?;
            let name = ktf_name(elems[3], heap)?;
            let value = rebuild_expr(elems[4], heap)?;
            ModuleItem::define(span, &name, value).map_err(|e| format!("{e:?}"))
        }
        "require" => {
            let module = ktf_name(elems[3], heap)?;
            ModuleItem::require(span, &module).map_err(|e| format!("{e:?}"))
        }
        "dann" => {
            // The blade 1 dann site record (GZ-1): the twin's item
            // stream carries (s e kind anchor-s anchor-e index
            // spec-tree); the rebuild restores the Annotate item.
            need_fields(&elems, 8, "`dann` item")?;
            let kind_tag = as_str(elems[3])?;
            let kind = kerf_core::AnnotationKind::from_kind_tag(kind_tag)
                .ok_or_else(|| format!("unknown dann kind tag `{kind_tag}`"))?;
            let anchor = make_span(elems[4], elems[5])?;
            let index = as_i64(elems[6])?;
            if index < 0 {
                return Err(format!("dann index is negative: {index}"));
            }
            let spec = rebuild_lv(elems[7], heap)?;
            Ok(ModuleItem::Annotate {
                span,
                anchor,
                kind,
                index: index as u32,
                spec,
            })
        }
        "dstruct" => {
            // The blade 2 struct declaration record (GZ-2): the
            // twin's item stream carries (s e name field...) with
            // each field a (name spec-tree) value list; the rebuild
            // restores the Struct item.
            let name = ktf_name(elems[3], heap)?;
            let mut fields = Vec::with_capacity(elems.len() - 4);
            for field in &elems[4..] {
                let fe = value_elems(field, heap)?;
                if fe.len() != 2 {
                    return Err(format!(
                        "dstruct field record has {} fields, need name/spec",
                        fe.len()
                    ));
                }
                let fname = ktf_name(fe[0], heap)?;
                let spec = rebuild_lv(fe[1], heap)?;
                fields.push((Symbol::new(&fname).map_err(|e| e.to_string())?, spec));
            }
            Ok(ModuleItem::Struct {
                span,
                name: Symbol::new(&name).map_err(|e| e.to_string())?,
                fields,
            })
        }
        "denum" => {
            // The blade 3 enum declaration record (GZ-4): the
            // twin's item stream carries (s e name variant...) with
            // each variant a (name spec-tree...) value list — at
            // least the name; the rebuild restores the Enum item.
            let name = ktf_name(elems[3], heap)?;
            let mut variants = Vec::with_capacity(elems.len() - 4);
            for variant in &elems[4..] {
                let ve = value_elems(variant, heap)?;
                if ve.is_empty() {
                    return Err(format!(
                        "denum variant record has {} entries, need at least the name",
                        ve.len()
                    ));
                }
                let vname = ktf_name(ve[0], heap)?;
                let mut specs = Vec::with_capacity(ve.len() - 1);
                for spec in &ve[1..] {
                    specs.push(rebuild_lv(spec, heap)?);
                }
                variants.push((Symbol::new(&vname).map_err(|e| e.to_string())?, specs));
            }
            Ok(ModuleItem::Enum {
                span,
                name: Symbol::new(&name).map_err(|e| e.to_string())?,
                variants,
            })
        }
        "module" => {
            let name = ktf_name(elems[3], heap)?;
            let mut items = Vec::with_capacity(elems.len() - 4);
            for child in &elems[4..] {
                items.push(rebuild_item(child, heap)?);
            }
            ModuleItem::module(span, &name, items).map_err(|e| format!("{e:?}"))
        }
        "defsyn" => {
            let name = ktf_name(elems[3], heap)?;
            ModuleItem::define_syntax(span, &name).map_err(|e| format!("{e:?}"))
        }
        "extern" => {
            // The ABI rides implicitly as C (the only vocabulary —
            // the twin's police rejects any other spelling before
            // emission, so the record never needs to carry it).
            let mut items = Vec::with_capacity(elems.len() - 3);
            for entry in &elems[3..] {
                let ee = value_elems(entry, heap)?;
                if ee.len() != 5 {
                    return Err(format!(
                        "extern entry record has {} fields, need name/es/ee/params/ret",
                        ee.len()
                    ));
                }
                let name = ktf_name(ee[0], heap)?;
                let entry_span = make_span(ee[1], ee[2])?;
                let param_vals = value_elems(ee[3], heap)?;
                let mut params = Vec::with_capacity(param_vals.len());
                for ty in param_vals {
                    params.push(extern_type_from_tag(as_str(ty)?)?);
                }
                let ret = extern_type_from_tag(as_str(ee[4])?)?;
                items.push(ExternItem {
                    span: entry_span,
                    name: Symbol::new(&name).map_err(|e| e.to_string())?,
                    params,
                    ret,
                });
            }
            ModuleItem::extern_block(span, ExternAbi::C, items).map_err(|e| format!("{e:?}"))
        }
        other => Err(format!("unknown item kind `{other}`")),
    }
}

/// One extern type tag (the record grammar's scalar vocabulary)
/// back to the ADT — the twin arm of `ExternType::kind_tag`.
fn extern_type_from_tag(tag: &str) -> Result<ExternType, String> {
    match tag {
        "int" => Ok(ExternType::Int),
        "bool" => Ok(ExternType::Bool),
        "float" => Ok(ExternType::Float),
        other => Err(format!("unknown extern type tag `{other}`")),
    }
}

fn rebuild_expr(v: &Value, heap: &Heap) -> Result<CoreExpr, String> {
    let elems = value_elems(v, heap)?;
    if elems.len() < 5 {
        return Err(format!("expr record has {} fields", elems.len()));
    }
    let span = gen_span(elems[1], elems[2], last_field(&elems)?)?;
    match as_str(elems[0])? {
        "fn" => {
            let params = value_elems(elems[3], heap)?;
            let mut names = Vec::with_capacity(params.len());
            for p in params {
                names.push(ktf_name(p, heap)?);
            }
            let refs: Vec<&str> = names.iter().map(String::as_str).collect();
            let body = rebuild_expr(elems[4], heap)?;
            CoreExpr::fn_(span, &refs, body).map_err(|e| format!("{e:?}"))
        }
        "apply" => {
            let func = rebuild_expr(elems[3], heap)?;
            let mut args = Vec::with_capacity(elems.len() - 5);
            for a in &elems[4..elems.len() - 1] {
                args.push(rebuild_expr(a, heap)?);
            }
            Ok(CoreExpr::Apply {
                span,
                func: Box::new(func),
                args,
            })
        }
        "if" => {
            need_fields(&elems, 6, "`if` expr")?;
            let cond = rebuild_expr(elems[3], heap)?;
            let then_branch = rebuild_expr(elems[4], heap)?;
            let else_branch = rebuild_expr(elems[5], heap)?;
            Ok(CoreExpr::If {
                span,
                cond: Box::new(cond),
                then_branch: Box::new(then_branch),
                else_branch: Box::new(else_branch),
            })
        }
        "var" => {
            let name = ktf_name(elems[3], heap)?;
            CoreExpr::var(span, &name).map_err(|e| format!("{e:?}"))
        }
        "lit" => {
            let value = rebuild_lit(elems[3], heap)?;
            Ok(CoreExpr::Literal { span, value })
        }
        "assign" => {
            let name = ktf_name(elems[3], heap)?;
            let value = rebuild_expr(elems[4], heap)?;
            CoreExpr::assign(span, &name, value).map_err(|e| format!("{e:?}"))
        }
        "let" => {
            let binding_elems = value_elems(elems[3], heap)?;
            let mut bindings = Vec::with_capacity(binding_elems.len());
            for b in binding_elems {
                let be = value_elems(b, heap)?;
                if be.len() != 5 {
                    return Err(format!("binding record has {} fields", be.len()));
                }
                let bspan = gen_span(be[0], be[1], be[4])?;
                let name = ktf_name(be[2], heap)?;
                let value = rebuild_expr(be[3], heap)?;
                bindings.push(Binding::new(bspan, &name, value).map_err(|e| format!("{e:?}"))?);
            }
            let body = rebuild_expr(elems[4], heap)?;
            Ok(CoreExpr::Let {
                span,
                bindings,
                body: Box::new(body),
            })
        }
        "perform" => {
            let effect = ktf_name(elems[3], heap)?;
            let mut args = Vec::with_capacity(elems.len() - 5);
            for a in &elems[4..elems.len() - 1] {
                args.push(rebuild_expr(a, heap)?);
            }
            CoreExpr::perform(span, &effect, args).map_err(|e| format!("{e:?}"))
        }
        "handle" => {
            let body = rebuild_expr(elems[3], heap)?;
            let clause_elems = value_elems(elems[4], heap)?;
            let mut handlers = Vec::with_capacity(clause_elems.len());
            for c in clause_elems {
                let ce = value_elems(c, heap)?;
                if ce.len() != 5 {
                    return Err(format!("clause record has {} fields", ce.len()));
                }
                let cspan = gen_span(ce[0], ce[1], ce[4])?;
                let effect = ktf_name(ce[2], heap)?;
                let handler = rebuild_expr(ce[3], heap)?;
                handlers.push(
                    HandlerClause::new(cspan, &effect, handler).map_err(|e| format!("{e:?}"))?,
                );
            }
            CoreExpr::handle(span, body, handlers).map_err(|e| format!("{e:?}"))
        }
        other => Err(format!("unknown expr kind `{other}`")),
    }
}

pub(crate) fn rebuild_lit(v: &Value, heap: &Heap) -> Result<LiteralValue, String> {
    if matches!(v, Value::Nil) {
        return Ok(LiteralValue::Nil);
    }
    let elems = value_elems(v, heap)?;
    if elems.len() < 2 {
        return Err(format!("litval record has {} fields", elems.len()));
    }
    match as_str(elems[0])? {
        "int" => match elems[1] {
            Value::Int(n) => Ok(LiteralValue::Int(*n)),
            other => Err(format!("int payload: {other:?}")),
        },
        "float" => {
            let text = as_str(elems[1])?;
            let v: f64 = text.parse().map_err(|_| format!("float text `{text}`"))?;
            Ok(LiteralValue::Float(v))
        }
        "bool" => match elems[1] {
            Value::Bool(b) => Ok(LiteralValue::Bool(*b)),
            other => Err(format!("bool payload: {other:?}")),
        },
        "string" => Ok(LiteralValue::String(as_str(elems[1])?.into())),
        "pair" => {
            need_fields(&elems, 3, "`pair` litval")?;
            // The right spine walks ITERATIVELY (the r145
            // `Value::from_literal` precedent — a stream record
            // list is thousands of nested pair RECORDS long; the
            // car recursion alone is bounded by the read nesting
            // cap). The spine step is the record's cdr PAYLOAD (the
            // next record — a proper list), never the heap chain of
            // the record's own encoding: descending that chain
            // would walk INTO the record (tag, car, cdr), not along
            // the literal's spine. A non-pair record as the cdr
            // payload is the dotted-literal face — it decodes as
            // one final element (a raw atom that is not a record
            // fails loud in `value_elems`, never silently).
            let mut cars: Vec<&Value> = vec![elems[1]];
            let mut tail: Option<LiteralValue> = None;
            let mut cur: &Value = elems[2];
            loop {
                match cur {
                    Value::Nil => break,
                    other => {
                        let next = value_elems(other, heap)?;
                        if next.len() != 3 || as_str(next[0])? != "pair" {
                            tail = Some(rebuild_lit(other, heap)?);
                            break;
                        }
                        cars.push(next[1]);
                        cur = next[2];
                    }
                }
            }
            let mut acc = tail.unwrap_or(LiteralValue::Nil);
            for car in cars.iter().rev() {
                acc = LiteralValue::Pair(Box::new(rebuild_lit(car, heap)?), Box::new(acc));
            }
            Ok(acc)
        }
        other => Err(format!("unknown litval kind `{other}`")),
    }
}

/// The 2.4 junction face (§9.87): the oracle's normalized expansion
/// WITH its items — the tree-identity gate of the full composed
/// chain needs the values, not just the dump. `Err` carries the
/// rendered parity key (the expander/loader error axis).
pub(crate) fn oracle_expansion(forms: &[SyntaxObject]) -> Result<Vec<ModuleItem>, String> {
    match expand_program(forms) {
        Err(err) => Err(error_parity_key(&ParityError::Expand(err))),
        Ok(items) => match load_program(&items) {
            Err(err) => Err(error_parity_key(&ParityError::Module(err))),
            Ok(_) => Ok(items),
        },
    }
}

// ---------- the oracle verdict ----------

// ---------- the case driver ----------

#[cfg(test)]
mod oracle_totality_tests {
    //! §9.76 SER-2/SER-3: the gate-B oracle decode face is **total**
    //! — every malformed record reports a structured drift error,
    //! never an index/slice panic (the documented `drive_dual_engines`
    //! contract; K167 wasmtime differential / K172 serde
    //! `invalid_length` anchors) — and the krf decoders' accepted-kind
    //! sets mirror the **oracle-emitting subset** of the ADT (K170 GHC
    //! Outputable coverage discipline; r106 FIX-16: the .ktf oracle
    //! cannot emit the target-skin error variants or the match-form
    //! family, so the decoder tables intentionally cover only what
    //! the oracle produces — unknown kinds stay fail-closed, and the
    //! tables extend in the same commit whenever the oracle gains a
    //! face).
    //!
    //! If the ADT grows a variant (a Stage 2 lexical-addressing
    //! change, say), `dump_oracle_*` breaks compilation (total
    //! match), kerf-core's nine-kind test breaks, and this module's
    //! kind tables must be extended in the same commit — the corpus
    //! sweep then pins the behavioral alignment end to end.

    use super::*;
    use kerf_vm::HeapObj;
    use std::panic::{AssertUnwindSafe, catch_unwind};

    fn s(text: &str) -> Value {
        Value::Str(text.into())
    }

    /// Build one proper list of values on a fresh heap and return
    /// both (the heap must outlive the decode under test).
    fn record(vals: Vec<Value>) -> (Value, Heap) {
        let mut heap = Heap::default();
        let mut acc = Value::Nil;
        for v in vals.into_iter().rev() {
            let r = heap.alloc(HeapObj::Pair(v, acc));
            acc = Value::Pair(r);
        }
        (acc, heap)
    }

    /// One truncation case: the decode must neither panic nor
    /// succeed when the record is shorter than the arm's need.
    /// `f` runs the decode; the case name names kind and length.
    fn assert_short_is_drift<F>(case: &str, f: F)
    where
        F: FnOnce() -> Result<(), String>,
    {
        match catch_unwind(AssertUnwindSafe(f)) {
            Ok(Err(_msg)) => {}
            Ok(Ok(())) => panic!("{case}: a truncated record must not decode"),
            Err(panic) => {
                panic!("{case}: the oracle panicked instead of reporting drift: {panic:?}")
            }
        }
    }

    /// The full-lifetime half: a record at or past the arm's need
    /// (with type-invalid fillers) may error or succeed, but must
    /// never panic — the totality invariant over every length.
    fn assert_never_panics<F>(case: &str, f: F)
    where
        F: FnOnce() -> Result<(), String>,
    {
        if let Err(panic) = catch_unwind(AssertUnwindSafe(f)) {
            panic!("{case}: the oracle panicked: {panic:?}");
        }
    }

    fn dump_expr_case(value: &Value, heap: &Heap) -> Result<(), String> {
        let mut out = String::new();
        dump_ktf_expr(value, heap, &mut out)
    }

    fn dump_item_case(value: &Value, heap: &Heap) -> Result<(), String> {
        let mut out = String::new();
        dump_ktf_item(value, heap, &mut out)
    }

    #[test]
    fn ser1_dump_expr_arms_reject_short_records_as_drift() {
        // (kind, fields the arm reaches past the shared header)
        let arms: &[(&str, usize)] = &[
            ("fn", 5),
            ("apply", 5),
            ("if", 6),
            ("assign", 5),
            ("let", 5),
            ("perform", 5),
            ("handle", 5),
        ];
        for (kind, need) in arms {
            for len in 0..*need {
                let mut vals = vec![s(kind), s("0"), s("1")];
                for _ in 3..len {
                    vals.push(s("x"));
                }
                vals.truncate(len);
                let (value, heap) = record(vals);
                let case = format!("dump expr `{kind}` at {len} fields");
                assert_short_is_drift(&case, || dump_expr_case(&value, &heap));
            }
        }
    }

    #[test]
    fn ser1_dump_expr_variants_stay_total_at_every_length() {
        for kind in [
            "fn", "apply", "if", "var", "lit", "assign", "let", "perform", "handle",
        ] {
            for len in 0..=8 {
                let mut vals = vec![s(kind), s("0"), s("1")];
                for _ in 3..len {
                    vals.push(s("x"));
                }
                vals.truncate(len);
                let (value, heap) = record(vals);
                let case = format!("dump expr `{kind}` at {len} fields");
                assert_never_panics(&case, || dump_expr_case(&value, &heap));
            }
        }
    }

    #[test]
    fn ser1_dump_item_and_litval_arms_reject_short_records_as_drift() {
        // define reaches elems[4] past the shared four-field header.
        for len in 0..5 {
            let mut vals = vec![s("define"), s("0"), s("1"), s("x")];
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("dump item `define` at {len} fields");
            assert_short_is_drift(&case, || dump_item_case(&value, &heap));
        }
        // The pair litval reaches elems[2] past the two-field header
        // (a zero-field "record" is the bare `nil` value — a valid
        // literal, not a truncated record — so the battery starts at 1).
        for len in 1..3 {
            let mut vals = vec![s("pair"), s("x")];
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("dump litval `pair` at {len} fields");
            let mut out = String::new();
            assert_short_is_drift(&case, || {
                dump_ktf_litval(&value, &heap, &mut out).map(|_| ())
            });
        }
    }

    #[test]
    fn ser1_rebuild_arms_reject_short_records_as_drift() {
        // `if` reaches elems[5] past rebuild's shared five-field floor
        // (kind/start/end/cond + trailing generation). The precise
        // pre-SER-1 panic shape carries a valid generation AND a
        // valid cond record, so the fix's arm-entry guard — not an
        // earlier sub-decode error — is what reports the drift.
        {
            let mut heap = Heap::default();
            let cons = |heap: &mut Heap, vals: Vec<Value>| {
                let mut acc = Value::Nil;
                for v in vals.into_iter().rev() {
                    let r = heap.alloc(HeapObj::Pair(v, acc));
                    acc = Value::Pair(r);
                }
                acc
            };
            let cond = cons(
                &mut heap,
                vec![s("var"), s("0"), s("1"), s("x"), Value::Int(0)],
            );
            let value = cons(
                &mut heap,
                vec![s("if"), s("0"), s("1"), cond, Value::Int(0)],
            );
            assert_short_is_drift("rebuild expr `if` at 5 fields (valid cond + gen)", || {
                rebuild_expr(&value, &heap).map(|_| ())
            });
        }
        for len in 0..6 {
            let mut vals = vec![s("if"), s("0"), s("1"), s("x")];
            if len >= 5 {
                vals.push(Value::Int(0));
            }
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("rebuild expr `if` at {len} fields");
            assert_short_is_drift(&case, || rebuild_expr(&value, &heap).map(|_| ()));
        }
        // The pair litval reaches elems[2] past the two-field header
        // (zero fields = the bare `nil` literal, not a record).
        for len in 1..3 {
            let mut vals = vec![s("pair"), s("x")];
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("rebuild litval `pair` at {len} fields");
            assert_short_is_drift(&case, || rebuild_lit(&value, &heap).map(|_| ()));
        }
        // A define item record truncated below its five-field need.
        for len in 0..5 {
            let mut vals = vec![s("define"), s("0"), s("1"), s("x")];
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("rebuild item `define` at {len} fields");
            assert_short_is_drift(&case, || rebuild_item(&value, &heap).map(|_| ()));
        }
    }

    #[test]
    fn ser1_restructured_rejections_reject_short_records_as_drift() {
        // (kind, fields the arm reaches) — every rejection kind at
        // the pre-SER-1 panic boundary (len 3/4 with a valid head).
        let arms: &[(&str, usize)] = &[
            ("unbound", 5),
            ("macro-mismatch", 5),
            ("malformed", 5),
            ("top", 4),
            ("quote-datum", 4),
            ("depth", 5),
            ("empty", 4),
            ("dup-param", 5),
            ("dup-handler", 5),
            ("mod-dup", 5),
            ("mod-missing", 5),
            ("mod-cycle", 5),
        ];
        for (kind, need) in arms {
            for len in 3..*need {
                let mut vals = vec![s("err"), s(kind), s("x")];
                for _ in 3..len {
                    vals.push(s("0"));
                }
                vals.truncate(len);
                let (value, heap) = record(vals);
                let case = format!("reconstruct `{kind}` at {len} fields");
                assert_short_is_drift(&case, || {
                    reconstruct_expand_error(&value, &heap).map(|_| ())
                });
            }
        }
    }

    #[test]
    fn ser2_unknown_kinds_stay_fail_closed() {
        for (kind, what) in [
            ("bogus-item", "item"),
            ("bogus-expr", "expr"),
            ("bogus-litval", "litval"),
        ] {
            let (value, heap) = record(vec![s(kind), s("0"), s("1"), s("x"), Value::Int(0)]);
            let msg = match what {
                "item" => dump_item_case(&value, &heap).unwrap_err(),
                "expr" => dump_expr_case(&value, &heap).unwrap_err(),
                _ => {
                    let mut out = String::new();
                    dump_ktf_litval(&value, &heap, &mut out).unwrap_err()
                }
            };
            assert!(
                msg.contains("unknown"),
                "`{kind}` must stay an unknown-kind error, got `{msg}`"
            );
        }
        let (value, heap) = record(vec![s("err"), s("bogus"), s("x"), s("0"), s("1")]);
        let msg = reconstruct_expand_error(&value, &heap).unwrap_err();
        assert!(msg.contains("unknown"), "got `{msg}`");
    }

    #[test]
    fn ser3_dump_kinds_mirror_the_core_adt() {
        // SER-3, K170: the krf decoders accept exactly the ADT's own
        // kind names — one sample per CoreExpr variant, taken from
        // the constructors (the ADT is the single source of the
        // names; the hand table below mirrors expr.rs's nine-kind
        // coverage test and must move with it).
        let span =
            Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT).expect("span");
        let lit = |span: Span| CoreExpr::Literal {
            span,
            value: LiteralValue::Int(1),
        };
        let samples = vec![
            CoreExpr::fn_(span, &["x"], lit(span)).expect("fn"),
            CoreExpr::Apply {
                span,
                func: Box::new(lit(span)),
                args: vec![],
            },
            CoreExpr::If {
                span,
                cond: Box::new(lit(span)),
                then_branch: Box::new(lit(span)),
                else_branch: Box::new(lit(span)),
            },
            CoreExpr::var(span, "x").expect("var"),
            lit(span),
            CoreExpr::assign(span, "x", lit(span)).expect("assign"),
            CoreExpr::Let {
                span,
                bindings: vec![],
                body: Box::new(lit(span)),
            },
            CoreExpr::perform(span, "e", vec![]).expect("perform"),
            CoreExpr::handle(span, lit(span), vec![]).expect("handle"),
        ];
        let expected: Vec<&str> = vec![
            "fn", "apply", "if", "var", "literal", "assign", "let", "perform", "handle",
        ];
        let names: Vec<&str> = samples.iter().map(|e| e.kind_name()).collect();
        assert_eq!(names, expected, "the ADT kind-name table moved");
        // The record tag for each ADT kind — identity everywhere
        // except the literal variant: the record grammar's historical
        // tag is `lit`, the diagnostic kind_name is `literal` (a
        // documented divergence, pinned here so it cannot drift
        // silently to a third spelling).
        for name in names {
            // `literal` is the one diagnostic name whose record tag
            // differs; every other kind's tag is the name itself.
            let tag: &str = if name == "literal" { "lit" } else { name };
            // A kind-only record fails the per-arm arity guard —
            // proving the krf side ACCEPTS the kind (an unknown kind
            // would say `unknown`) and engages the SER-1 guard.
            let (value, heap) = record(vec![s(tag), s("0"), s("1")]);
            let msg = dump_expr_case(&value, &heap).expect_err("kind-only record is short");
            assert!(
                msg.contains("need at least"),
                "`{tag}` must engage an arity guard, got `{msg}`"
            );
            assert!(!msg.contains("unknown"), "`{tag}` dropped off the krf side");
        }
    }

    #[test]
    fn ser3_dual_encoders_agree_byte_for_byte_on_a_full_sample() {
        // SER-3 positive half: the oracle dump and the krf record
        // dump of the same define produce the identical text (the
        // tree-axis test's exact anchor, now pinned structurally on
        // the encoder face itself).
        let span = |s: u32, e: u32| {
            Span::new(FileId(0), ByteOffset(s), ByteOffset(e), ExpansionId::ROOT).expect("span")
        };
        let item = ModuleItem::define(
            span(0, 12),
            "x",
            CoreExpr::Literal {
                span: span(10, 11),
                value: LiteralValue::Int(1),
            },
        )
        .expect("define");
        let oracle = oracle_dump_items(&[item]);
        assert_eq!(oracle, "(define 0 12 x (lit 10 11 (int 1)))");

        // The equivalent krf record tree, hand-built per the record
        // grammar (item: kind/s/e/name/expr, no generation; expr:
        // kind/s/e/payload + trailing generation).
        let (litval, mut heap) = record(vec![s("int"), Value::Int(1)]);
        let expr = {
            let mut acc = Value::Nil;
            let fields = vec![s("lit"), s("10"), s("11"), litval, Value::Int(0)];
            for v in fields.into_iter().rev() {
                let r = heap.alloc(HeapObj::Pair(v, acc));
                acc = Value::Pair(r);
            }
            acc
        };
        let item_record = {
            let mut acc = Value::Nil;
            let fields = vec![s("define"), s("0"), s("12"), s("x"), expr];
            for v in fields.into_iter().rev() {
                let r = heap.alloc(HeapObj::Pair(v, acc));
                acc = Value::Pair(r);
            }
            acc
        };
        let mut out = String::new();
        dump_ktf_item(&item_record, &heap, &mut out).expect("the well-formed record dumps");
        assert_eq!(out, oracle, "the dual encoders drifted");
    }
}

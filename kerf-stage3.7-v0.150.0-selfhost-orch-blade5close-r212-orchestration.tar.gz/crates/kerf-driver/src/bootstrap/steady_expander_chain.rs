//! The W-3.12 segment-two steady-state bootstrap chain (w3.12
//! §5, the segment-two agenda; the segment-one `SteadyReaderChain`
//! form carried to the expansion segment): the twin expander
//! program compiled ONCE and fed per forms-stream through the
//! injection channel.
//!
//! The delta against the per-source route (the EX-1 test channel,
//! `target_forms_stream_prefix`): there the flat pre-order record
//! stream rides the program TEXT as a quoted define, so every
//! expansion re-parses, re-checks and re-compiles the whole
//! assembled twin program (macro.ktf + expander.ktf plus the
//! per-source prefix). Here the twin program is FIXED —
//! `macro.ktf` + `expander.ktf`, nothing else — so the front-end
//! work happens once at construction, and each expansion binds
//! the record stream into the `forms` global slot through
//! [`kerf_vm::Vm::inject_global`] (the injection channel's VM arm,
//! the same channel the reader segment rides — the INJ-1
//! generality ruling's delivery face: one channel, segment-two
//! payload).
//!
//! The payload is the SAME EX-1 record grammar
//! ([`crate::bootstrap::expander_parity::forms_stream_prefix`]'s
//! text face, mirrored on the value face by
//! [`forms_stream_literal`]): one flat pre-order record per node,
//! spans as decimal strings, floats as Debug text, source records
//! at generation 0. Zero new primitives, zero new builtins, zero
//! frozen-surface change.
//!
//! Boundary note (the r103 exception ledger, instantiated here):
//! the TEXT face cannot carry an `i64::MIN` datum (the magnitude
//! overflows the target lexer's positive domain before the sign
//! applies — `datum_target_spellable` classifies those cases at
//! the junction-2 boundary). The VALUE face has no such boundary —
//! the injected records are already values, no spelling pass ever
//! runs — so the steady chain covers those corpus rows natively
//! (a capability delta of the injection channel, disclosed in the
//! window record; the text face keeps its boundary row).
//!
//! Channel contract (the build-time half; the per-bind half lives
//! on the engines): the fixed program must REFERENCE `forms` (the
//! compiler's collected global table is the single source —
//! checked at construction so the chain fails at build, not at
//! first expansion) and must not DEFINE it (a program-side define
//! overwrites the bound slot at run time). The twins hold that
//! discipline; the corpus sweep through this chain is the machine
//! check (a clobber collapses every expansion onto one stream and
//! the sweep drifts loudly).

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::{LiteralValue, ModuleItem};
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Vm};
use std::rc::Rc;

use crate::bootstrap::expander_parity::{ParityError, decode_verdict, rebuild_items};
use crate::bootstrap::steady_target_reader_chain::dispose_literal_iteratively;
use crate::bootstrap::vm_harness::KtfVerdict;
use crate::bootstrap::vm_harness::classify_engine_failure;
use crate::bootstrap::vm_harness::drive_vm_only;
use crate::session::Session;

/// The injected global's canonical name — the EX-1 contract name
/// `forms` (the same identity the S-expr prefix defines; the twins
/// spell it identically on the target skin, so no skin-map
/// canonicalization applies — one constant so the chain and its
/// tests never re-type the binding site).
pub const STEADY_FORMS_NAME: &str = "forms";

// ORCH blade 4 (P3): the `ex-struct-accs` / `ex-enum-ctors`
// injection channels RETIRED — the expander twin self-declares
// both state globals and self-seeds the tables from its own flat
// form stream (the `ex_acc_tables` walk, the orchestrator's
// kb_tables form lifted into the library). The steady chain
// injects ONLY the `forms` channel now; the two literal builders
// and their name constants retire with the channel.

/// The host name the fixed twin program parses under (diagnostics
/// attribution only — the twins verify clean, so it never
/// surfaces).
const STEADY_EXPANDER_HOST_NAME: &str = "steady-expander-chain.ktf";

/// The EX-1 record stream on the value face: mirrors
/// [`crate::bootstrap::expander_parity::forms_stream_prefix`]'s
/// text emission record for record — the same flat pre-order
/// grammar, the same field order, the same generation-0 source
/// records — so the twin consumes either delivery face
/// identically (the cross-route equivalence test is the machine
/// check). Empty forms ride as `Nil` (the prefix face's
/// `(quote nil)` ledger row, mirrored).
pub fn forms_stream_literal(forms: &[SyntaxObject]) -> LiteralValue {
    let mut records: Vec<LiteralValue> = Vec::new();
    for form in forms {
        emit_stream_node_literal(form, &mut records);
    }
    let mut list = LiteralValue::Nil;
    for record in records.iter().rev() {
        list = LiteralValue::Pair(Box::new(record.clone()), Box::new(list));
    }
    list
}

/// Emit one tree node's record into the flat stream (the value
/// twin of `expander_parity::emit_stream_node`): atoms close
/// themselves; a list emits its arity and its children follow as
/// the next records.
fn emit_stream_node_literal(node: &SyntaxObject, out: &mut Vec<LiteralValue>) {
    let s = node.span.start.0.to_string();
    let e = node.span.end.0.to_string();
    let record = |tag: &str, payload: LiteralValue| {
        // ("tag" "s" "e" payload 0) — the five-field record as a
        // PROPER list (the trailing nil terminator is part of the
        // grammar: the text route's read-back produces exactly this
        // shape, and the twin's cdr-walking accessors rely on it).
        LiteralValue::Pair(
            Box::new(LiteralValue::String(Rc::from(tag))),
            Box::new(LiteralValue::Pair(
                Box::new(LiteralValue::String(Rc::from(s.as_str()))),
                Box::new(LiteralValue::Pair(
                    Box::new(LiteralValue::String(Rc::from(e.as_str()))),
                    Box::new(LiteralValue::Pair(
                        Box::new(payload),
                        Box::new(LiteralValue::Pair(
                            Box::new(LiteralValue::Int(0)),
                            Box::new(LiteralValue::Nil),
                        )),
                    )),
                )),
            )),
        )
    };
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push(record(
                "ident",
                LiteralValue::String(Rc::from(sym.as_str())),
            ));
        }
        StxDatum::Int(v) => {
            out.push(record("int", LiteralValue::Int(*v)));
        }
        StxDatum::Float(v) => {
            // Debug text rides as a string (the 1.5 convention).
            out.push(record(
                "float",
                LiteralValue::String(Rc::from(format!("{v:?}").as_str())),
            ));
        }
        StxDatum::Bool(v) => {
            out.push(record("bool", LiteralValue::Bool(*v)));
        }
        StxDatum::String(v) => {
            out.push(record("string", LiteralValue::String(Rc::from(v.as_ref()))));
        }
        StxDatum::List(items) => {
            out.push(record(
                "list",
                LiteralValue::Int(
                    i64::try_from(items.len())
                        .expect("harness defect: a datum list longer than i64::MAX cannot exist"),
                ),
            ));
            for item in items {
                emit_stream_node_literal(item, out);
            }
        }
    }
}

/// One decoded expansion outcome: the verdict text (the tree dump
/// on the ok axis, the parity-key error text on the err axis —
/// `KtfVerdict::text`'s single-source rendering) plus the rebuilt
/// items (the tree axis's values, present only on the ok verdict —
/// the cross-stage consumer face: `compile_program` over the
/// rebuilt items is the fixpoint/gate-B shape).
#[derive(Debug, Clone, PartialEq)]
pub struct SteadyExpansion {
    /// The normalized verdict text — byte-comparable against the
    /// oracle's own dump (`oracle_dump_items`) or the oracle's
    /// error parity key.
    pub text: String,
    /// The rebuilt items (`None` on the err axis).
    pub items: Option<Vec<ModuleItem>>,
}

impl SteadyExpansion {
    /// The rebuilt items on the ok axis (the cross-stage feed);
    /// `Err` carries the verdict text on the err axis.
    pub fn into_items(self) -> Result<Vec<ModuleItem>, String> {
        match self.items {
            Some(items) => Ok(items),
            None => Err(self.text),
        }
    }
}

/// One decoded verdict's text-and-items pair (the shared decoder
/// closure — both engines decode through it, so the two arms can
/// never drift).
pub(crate) fn decode_expansion(
    value: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
) -> Result<SteadyExpansion, String> {
    let verdict: KtfVerdict<ParityError> = decode_verdict(value, heap)?;
    let items = match &verdict {
        KtfVerdict::Tree(_) => Some(rebuild_items(value, heap)?),
        KtfVerdict::Error(_) => None,
    };
    Ok(SteadyExpansion {
        text: verdict.text().to_string(),
        items,
    })
}

/// The steady-state twin expander chain: the compiled fixed
/// program (the VM arm's input — the MODERN2 blade-5 retirement:
/// the twin consumes the Error vocabulary, so the chain rides the
/// VM alone; the parsed-items field went with the evaluator arm).
pub struct SteadyExpanderChain {
    bc: Bytecode,
}

impl SteadyExpanderChain {
    /// Compile the fixed twin program ONCE at the default work
    /// budget: `macro.ktf` + `expander.ktf` concatenated (the MX-2
    /// assembly), parsed through the production bridge with `forms`
    /// declared as an injected global, checked, compiled. No
    /// per-source prefix ever enters this text.
    pub fn new() -> Result<Self, String> {
        Self::new_with_limit(kerf_expander::EXPANSION_LIMIT)
    }

    /// Compile the fixed twin program at one explicit work budget
    /// (the step-④ expand segment's budget-mirroring face): the
    /// assembly prefixes `define(ex_limit, N);` — the `tp_limit`
    /// precedent — so the twin's budget guard carries the process's
    /// effective expansion limit and an over-budget source rejects
    /// with the same key on both positions (the rollback band's
    /// parity obligation).
    pub fn new_with_limit(limit: usize) -> Result<Self, String> {
        let assembled =
            crate::bootstrap::target_corpus::assembled_expander_target_source_with_limit(limit);
        let injected = [kerf_span::Symbol::new(STEADY_FORMS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_EXPANDER_HOST_NAME,
            &assembled,
            &injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed twin program failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!(
                "harness defect: the fixed twin program failed the checker: {findings:?}"
            ));
        }
        let bc = compile_program(&program.items).map_err(|err| {
            format!("harness defect: the fixed twin program failed to compile: {err}")
        })?;
        // The channel contract's build-time face: the program must
        // reference the injected name — the compiler's collected
        // global table is the single source (the same check
        // `Vm::inject_global` enforces per bind, hoisted here so a
        // twin regression fails at construction, not at first
        // expansion).
        if !bc.globals.iter().any(|g| g.as_str() == STEADY_FORMS_NAME) {
            return Err(format!(
                "harness defect: the twin program does not reference `{STEADY_FORMS_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self { bc })
    }

    /// One expansion through the steady chain on the VM engine: a
    /// fresh VM per expansion (the globals start clean — the
    /// steady-state per-expansion shape), the record stream bound
    /// through the injection channel, the run, the decoded
    /// verdict (text plus rebuilt items).
    pub fn expand(&self, forms: &[SyntaxObject]) -> Result<SteadyExpansion, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        let lit = forms_stream_literal(forms);
        let injected = vm
            .inject_global(STEADY_FORMS_NAME, &lit)
            .map_err(|err| format!("harness defect: the injection channel: {err}"));
        // The host-side literal drops iteratively (the r145 K163
        // family: a long right spine's default Box-drop glue is one
        // stack frame per cell — the same-path sweep covers every
        // injection site, not just the read segment's).
        dispose_literal_iteratively(lit);
        injected?;
        vm.run()
            .map_err(|err| classify_engine_failure("vm", "steady expander chain", &err))?;
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        decode_expansion(value, vm.heap())
    }

    /// One expansion through the steady chain on the PRODUCTION
    /// engine alone (the step-④ expand segment's production
    /// position; the verification face is the VM-only drive (the
    /// MODERN2 blade-5 retirement — the expander twin consumes the
    /// Error vocabulary, so the meta-circular eval axis retired for
    /// this family) — production never pays for a second opinion).
    ///
    /// The outcome splits the two failure families the production
    /// position must never confuse (the `read_production`
    /// precedent):
    ///
    /// * outer `Err` — a harness defect (the chain or a decode
    ///   broke; a compiler defect, rendered loudly — never a silent
    ///   Rust fallback, §2.3-4);
    /// * inner `Err` — the program's own rejection, as the rebuilt
    ///   [`ParityError`] (the expansion or loader surface — the
    ///   junction-2 discipline: the twin's verdict already covers
    ///   both, exactly like the oracle's expand → load spine).
    pub fn expand_production(
        &self,
        forms: &[SyntaxObject],
    ) -> Result<Result<Vec<ModuleItem>, ParityError>, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        let lit = forms_stream_literal(forms);
        let injected = vm
            .inject_global(STEADY_FORMS_NAME, &lit)
            .map_err(|err| format!("harness defect: the injection channel: {err}"));
        dispose_literal_iteratively(lit);
        injected?;
        vm.run()
            .map_err(|err| classify_engine_failure("vm", "production expander chain", &err))?;
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        match decode_verdict(value, vm.heap())? {
            // The tree axis: the rebuilt items (the cross-stage feed)
            // walk the SAME value the dump text came from — the
            // `decode_expansion` precedent, one walk per axis.
            KtfVerdict::Tree(_) => Ok(Ok(rebuild_items(value, vm.heap())?)),
            KtfVerdict::Error(err) => Ok(Err(err)),
        }
    }

    /// The compiled fixed product (the once-compiled bytecode —
    /// the observation face for tests and the measurement
    /// harness; the per-expansion cost is the injection + run,
    /// never a recompile).
    pub fn bytecode(&self) -> &Bytecode {
        &self.bc
    }
}

/// The EX-1 text-channel route (the pre-steady verification form):
/// the record stream as a program-text prefix, the whole assembled
/// twin recompiled per expansion — kept as the cross-route
/// equivalence face (the steady route and this route decode to
/// identical outcomes through the SAME decoder closure; the
/// delivery face is the only delta). Unspellable datums surface
/// the r103 text boundary here — the honest row the injected face
/// does not have.
pub fn per_source_route(forms: &[SyntaxObject]) -> Result<SteadyExpansion, String> {
    if !crate::bootstrap::target_corpus::forms_target_spellable(forms) {
        return Err(
            "harness boundary: the r103 exception-ledger row — an i64::MIN datum has no \
             target-skin text (the magnitude overflows the target lexer's positive domain); \
             the injected face (the steady chain) carries it, this text route classifies it"
                .to_string(),
        );
    }
    let assembled = format!(
        "{}\n{}",
        crate::bootstrap::target_corpus::target_forms_stream_prefix(forms),
        crate::bootstrap::target_corpus::assembled_expander_target_source()
    );
    // MODERN2 blade 5 (r201): the expander twin consumes the Error
    // vocabulary, so this route rides the VM alone (the M16/M58
    // policy line; the meta-circular eval axis retired for the
    // family — the same twin's k-form raise paths ride the VM's
    // one-shot semantics).
    drive_vm_only(
        "expander-parity-host.ktf",
        "target expander",
        &assembled,
        decode_expansion,
    )
}

/// The oracle's both-axes expectation for one forms stream (the
/// sweep's comparison face): the normalized item dump on the ok
/// axis, the rendered parity key on the err axis (the expansion
/// and loader rejections ride the same Err — the junction-2
/// oracle-routing discipline).
pub fn oracle_expansion_axes(forms: &[SyntaxObject]) -> Result<String, String> {
    match crate::bootstrap::expander_parity::oracle_expansion(forms) {
        Ok(items) => Ok(crate::bootstrap::expander_parity::oracle_dump_items(&items)),
        Err(key) => Err(key),
    }
}

//! The step-3 corpus-translation harness (switch-window-plan §1
//! step 3, stage0.md §9.96): the target-skin twins of the selfhost
//! injection contracts.
//!
//! The five `selfhost/v1/*.ktf` files each consume one
//! host-injected global (the byte table, the token records, the
//! form records, the item records) and produce one product global
//! — the RS-1/EX-1/CP injection family. This module provides the
//! same injection data on the target skin, so the parity tests can
//! drive the `.ktf` twins through the identical pipeline and
//! compare against the Rust engines (the BS-A seed-chain oracle:
//! the seed-skin originals were removed at r104 — E5 batch 3 — and
//! `read_program`/`expand_program`/`compile_program` remain the
//! tree truth sources of each segment).
//!
//! Single-source discipline: the DATA comes from the S-expr prefix
//! builders verbatim (`byte_table_prefix`, `token_table_prefix`,
//! `forms_stream_prefix`, `items_stream_prefix`); only the SKIN is
//! transcoded here. Every transcoded prefix is round-trip checked
//! against the real target reader — the emitted text must read
//! back to the identical Stx tree (the naming guard: a datum the
//! target vocabulary cannot spell is a harness defect, never a
//! silent rename).
//!
//! r122 split note (the user instruction-① bootstrap-file
//! unification): the target-skin SPELLING contract now lives at the
//! crate root (`crate::target_skin` — a production contract the
//! bridge and the diagnostics consume); this module keeps the twin
//! embeddings, the prefix assembly and the rich-compile faces.

use kerf_compiler::Bytecode;
use kerf_core::ModuleItem;

use kerf_reader::read_target_program;
use kerf_span::FileId;
use kerf_syntax::StxDatum;
use kerf_syntax::SyntaxObject;
use kerf_vm::{Heap, Value};

use crate::bootstrap::compiler_parity::RichCompileRun;
use crate::bootstrap::compiler_parity::{
    dump_ktf_section, items_stream_prefix, rebuild_bytecode, rebuild_compile_error,
};
use crate::bootstrap::expander_parity::forms_stream_prefix;
use crate::bootstrap::lockfile_parity::LOCKFILE_TARGET_SOURCE;
use crate::bootstrap::manifest_parity::MANIFEST_TARGET_SOURCE;
use crate::bootstrap::micro_toml_parity::MICRO_TOML_TARGET_SOURCE;
use crate::bootstrap::semver_parity::SEMVER_TARGET_SOURCE;
use crate::bootstrap::vm_harness::KtfVerdict;
use crate::bootstrap::vm_harness::byte_table_prefix;
use crate::bootstrap::vm_harness::{STD_ERROR_TARGET_SOURCE, decode_tagged, drive_vm_only};
use crate::pipeline;
use crate::target_skin::{emit_target_datum, target_skin_spelling};

/// The target-skin macro library twin (`selfhost/v1/macro.ktf`;
/// the Rust `expand_program` remains the oracle — BS-A).
pub const MACRO_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/macro.ktf");
/// The target-skin expander twin (`selfhost/v1/expander.ktf`; the
/// Rust `expand_program` remains the oracle — BS-A).
pub const EXPANDER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/expander.ktf");
/// The target-skin compiler twin (`selfhost/v1/compiler.ktf` — the
/// fully self-hosted segment: gate B bytecode equality plus the
/// three-phase fixpoint; the Rust `compile_program` remains the
/// oracle — BS-A).
pub const COMPILER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/compiler.ktf");
/// The target-skin HM inference twin (`selfhost/v1/infer.ktf` — the
/// W-HM-TWIN segment-three face; the Rust `infer_module` remains
/// the oracle — BS-A).
pub const INFER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/infer.ktf");
/// The target-skin conservative-checker twin (`selfhost/v1/typecheck.ktf`
/// — the W-HM-TWIN segment-three check face; the Rust `check_module`
/// remains the oracle — BS-A).
pub const TYPECHECK_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/typecheck.ktf");
/// The target-skin TARGET-lexer twin (`selfhost/v1/target-lexer.ktf`
/// — the W-TGT-READ-TWIN blade 1 segment: the target skin's own
/// lexical face as a kerf program; the Rust `lex_target` remains
/// the oracle — BS-A).
pub const TARGET_LEXER_TARGET_SOURCE: &str =
    include_str!("../../../../selfhost/v1/target-lexer.ktf");

/// The target-skin parser twin (the W-TGT-READ-TWIN blade 2 source
/// — the ninth selfhost twin, `selfhost/v1/target-parser.ktf`).
pub const TARGET_PARSER_TARGET_SOURCE: &str =
    include_str!("../../../../selfhost/v1/target-parser.ktf");

/// The kerf-build orchestrator twin (the W-SELFHOST-ORCH blade 3
/// source — the drive bridge's in-language successor,
/// `selfhost/v1/build.ktf`; a pure function library per the B1
/// form, driven through the seed contract and the §8.8 channel).
pub const BUILD_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/build.ktf");

// ---------- the hosting tails (the ORCH blade-3 library-form
// ruling, B1): the four twins are pure function libraries now —
// these define families are the HOST DRIVE CONTRACT the host
// faces (the CCF assembly, the steady chains, the parity drives,
// the fixpoint's self-applied bake) append to drive one twin
// through the VM. The tails retired from the library files at
// r208 so the orchestrator can compose the twins in-language
// (a top-level `define(result, ...)` evaluates at program start —
// an unbound injection slot there is a crash, never a library
// shape). Byte discipline: each tail spells the retired lines
// verbatim (the assembling faces' products stay byte-identical
// where the pre-blade assemblies embedded the tailed files).

/// The lexer twin's hosting tail: the verdict alias family
/// (`tl_verdict` over the `source_bytes` slot, the derived
/// `tl_failed`/`tl_tokens`/`tl_error` globals, the `result`
/// alias).
pub const LEXER_HOSTING_TAIL: &str = "\n// ---- the output globals (tl_-namespaced; `result` is the harness\n// alias the vm-only drive decodes — the M46 single-engine face)\n\ndefine(tl_verdict, unwrap(attempt(|| {\n    tl_start(source_bytes, 0, nil)\n}), ||(e) { e }));\ndefine(tl_failed, eq(first(tl_verdict), \"err\"));\ndefine(tl_tokens, if tl_failed { nil } else { rest(tl_verdict) });\ndefine(tl_error, if tl_failed { rest(tl_verdict) } else { nil });\ndefine(result, tl_verdict);\n";

/// The parser twin's hosting tail: the entry frame and the
/// `result` alias (the `tp_tokens` slot's verdict).
pub const PARSER_HOSTING_TAIL: &str = "\n// --------------------------------------------------------------------\n// the entry\n// --------------------------------------------------------------------\n\ndefine(tp_run_result, unwrap(attempt(|| { tp_run(); tp_done }), ||(e) { e }));\ndefine(tp_verdict, tp_run_result);\ndefine(result, tp_verdict);\n";

/// The expander twin's hosting tail: the `result` alias over the
/// `forms` slot.
pub const EXPANDER_HOSTING_TAIL: &str = "\ndefine(result, ex_run(forms));\n";

/// The compiler twin's hosting tail: the `result` alias over the
/// `items` slot (the fixpoint's structural face and the
/// self-applied bake both compose against the LIBRARY body — the
/// bake appends this tail itself).
pub const COMPILER_HOSTING_TAIL: &str = "\ndefine(result, cp_run(items));\n";

/// Append one hosting tail to a library source, asserting the
/// library form (fail-closed on a double append or a tailed
/// input — the assembling faces' one discipline).
pub(crate) fn with_hosting_tail(lib: &str, tail: &str, anchor: &str) -> String {
    assert!(
        !lib.contains(anchor),
        "harness defect: the library source already carries the hosting tail — append once"
    );
    format!("{lib}{tail}")
}

/// The assembled orchestrator (the ORCH blade-3 host assembly, the
/// B1/B7 face): the slot defines (`tp_tokens` — the parser twin's
/// channel slot; `ex_limit`/`co_limit` — the budget mirrors, the
/// CCF precedent) ahead of the import-composed build library, and
/// the hosting tail (`define(result, kb_main());`) at the end. The
/// composed body pulls std/error + macro + the four chain units
/// first-seen through the orchestrator's own import declarations —
/// the composer's byte-identical file chain (the O6 discipline).
/// The parser-slot blob (the B7 self-carrier amendment, r210): the
/// tp_forms/tp_limit defines — the carrier prefix's parser face,
/// single-sourced here for BOTH the A-pass assembly and the
/// carrier prefix. The in-language face reads the same text
/// through the `kb_parser_slots` assembly global (the string-define
/// mirror both assemblies carry), so a drift between the two sides
/// is impossible by construction — and the digest gate's
/// projection cross-check holds it red regardless.
fn parser_slots_blob() -> String {
    format!(
        "{}{}",
        transcode_quoted_define(&crate::bootstrap::target_parser_parity::tp_forms_prefix()),
        crate::bootstrap::target_parser_parity::tp_limit_prefix(256)
    )
}

/// The `kb_parser_slots` string-define line (the blob as a .ktf
/// string body — the newlines ride the two-char `\\n` escape; the
/// blob itself carries no quotes or backslashes, so that is the
/// only escaping it needs).
fn kb_parser_slots_define_line() -> String {
    format!(
        "define(kb_parser_slots, \"{}\");\n",
        parser_slots_blob().replace('\n', "\\n")
    )
}

pub fn assembled_build_source() -> String {
    // The parser twin's own channel slots ride ahead of the
    // composed body (the steady chain's assembly order): the
    // token-table slot (kb_tp_boot sets it per unit), the parser's
    // form table (the tp_forms_prefix single source, transcoded to
    // the target skin), and the nesting limit (the steady chain's
    // 256 — the same fixed assembly every read twin rides). The
    // kb_parser_slots mirror (the self-carrier amendment) rides the
    // same slot block.
    let parser_slots = format!("{}{}", parser_slots_blob(), kb_parser_slots_define_line());
    format!(
        "define(tp_tokens, nil);\n{parser_slots}define(ex_limit, {});\ndefine(co_limit, {});\n{}\ndefine(result, kb_main());\n",
        kerf_expander::EXPANSION_LIMIT,
        kerf_compiler::COMPILE_DEPTH_LIMIT,
        compose_selfhost(BUILD_TARGET_SOURCE)
    )
}

/// The carrier assembly prefix (the ORCH blade-3 B7 binding face):
/// the five harness-global defines the A-pass assembly provides
/// ahead of the library, mirrored for the CARRIER face — a carrier
/// whose units reference the harness globals (the expander
/// family's own `ex_limit` depth check, the channel-table reads)
/// expands against the same binding face the library itself rides.
/// The orchestrator's `kb_assembly_prefix` (build.ktf) is the
/// in-language mirror; the digest gate's projection comparison
/// cross-checks the two sides, so a drift on either face fails
/// the gate loudly (the `ex_limit`/`co_limit` digits ride the
/// live Rust constants here and the in-VM drift guard there).
pub fn carrier_assembly_prefix() -> String {
    // The r210 self-carrier amendment: the carrier prefix carries
    // the FULL A-pass binding face — the parser slots (tp_forms +
    // tp_limit) and the kb_parser_slots string-define mirror ride
    // alongside the five r209 globals (the r209 five-define subset
    // was the expander-family minimum; a carrier whose units
    // include the read twins exposed the general requirement).
    format!(
        "define(tp_tokens, nil);\n{}{}define(ex_limit, {});\ndefine(co_limit, {});\n",
        parser_slots_blob(),
        kb_parser_slots_define_line(),
        kerf_expander::EXPANSION_LIMIT,
        kerf_compiler::COMPILE_DEPTH_LIMIT
    )
}

/// The selfhost unit registry (W-SELFHOST-ORCH blade 1, O4): the
/// import composer's resolution face — the language-level unit
/// namespace. The names are FLAT identities, not layout paths: the
/// std area rides its domain prefix (`std/error`) and the v1
/// production pieces ride bare names (the file layout is not the
/// identity — K102's canonical-path discipline at the closed-set
/// scale: the registry IS the path resolution face, Stage 0 has no
/// filesystem). Blade 1 registers the six units the carriers
/// reference; the single-twin prefix family (the remaining
/// `STD_ERROR` format! sites) is blade 4's sweep.
pub fn selfhost_unit_source(name: &str) -> Option<&'static str> {
    match name {
        "std/error" => Some(STD_ERROR_TARGET_SOURCE),
        "macro" => Some(MACRO_TARGET_SOURCE),
        "micro-toml" => Some(MICRO_TOML_TARGET_SOURCE),
        "semver" => Some(SEMVER_TARGET_SOURCE),
        "manifest" => Some(MANIFEST_TARGET_SOURCE),
        "lockfile" => Some(LOCKFILE_TARGET_SOURCE),
        // The ORCH blade-3 registry extension (B7): the read→expand→
        // compile chain's own units — the orchestrator's import
        // pool and the harness faces' composition set.
        "target-lexer" => Some(TARGET_LEXER_TARGET_SOURCE),
        "target-parser" => Some(TARGET_PARSER_TARGET_SOURCE),
        "expander" => Some(EXPANDER_TARGET_SOURCE),
        "compiler" => Some(COMPILER_TARGET_SOURCE),
        _ => None,
    }
}

/// Compose one carrier through the import surface (the O6 assembly
/// face: every consumer of the expander/resolve family rides this
/// — the composed program is byte-identical to the retired
/// concatenation's file chain; the parity goldens pin it).
pub fn compose_selfhost(entry: &str) -> String {
    let resolve = |name: &str| selfhost_unit_source(name).map(str::to_string);
    crate::bootstrap::import_composer::compose_imports(entry, &resolve)
        .unwrap_or_else(|err| panic!("harness defect: the carrier must compose: {err}"))
        .text
}

/// The assembled target-skin expander (the MX-2 twin: the macro
/// library composed ahead of the expander body through the import
/// surface, one program) at the default work budget (the
/// verification faces' arm — the oracle rides the same default, so
/// the parity keys stay comparable).
pub fn assembled_expander_target_source() -> String {
    assembled_expander_target_source_with_limit(kerf_expander::EXPANSION_LIMIT)
}

/// The assembled expander at one explicit work budget (the step-④
/// expand segment's budget-mirroring face — the twin's `ex_limit`
/// global must carry the process's effective expansion limit, the
/// `tp_limit` prefix precedent: an over-budget source rejects with
/// the same key on both positions, the rollback band's parity
/// obligation).
///
/// W-SELFHOST-ORCH blade 1 (O5/O6): the file composition — the std
/// Error-instance prefix and the macro library — rides the source's
/// own `import` declarations through the composer (first-seen,
/// byte-identical to the retired format! concatenation's file
/// chain; the composed source carries `import "std/error"` then
/// `import "macro"`, resolving to the same unit order). The budget
/// define stays a host-side channel (the blade-4 prefix-family
/// sweep owns its retirement); the twin's free names
/// (attempt/unwrap/raise) resolve against the imported library's
/// live definitions — the ccf-lexer/ccf-compiler precedent carried
/// through the composition layer.
pub fn assembled_expander_target_source_with_limit(limit: usize) -> String {
    format!(
        "define(ex_limit, {limit});\n{}",
        with_hosting_tail(
            &compose_selfhost(EXPANDER_TARGET_SOURCE),
            EXPANDER_HOSTING_TAIL,
            "define(result, ex_run(forms));"
        )
    )
}

/// The assembled compiler twin at the default compile-depth budget
/// (the verification faces' arm — the oracle rides the same default,
/// so the parity keys stay comparable; the r148 `co_limit`
/// parameterization, the `ex_limit` form carried to the compile
/// segment).
pub fn assembled_compiler_target_source() -> String {
    assembled_compiler_target_source_with_limit(kerf_compiler::COMPILE_DEPTH_LIMIT)
}

/// The assembled compiler twin at one explicit compile-depth budget
/// (the step-④ compile segment's budget-mirroring face — the twin's
/// `co_limit` global must carry the process's effective
/// `KERF_COMPILE_DEPTH_LIMIT`, the `ex_limit` prefix precedent: an
/// over-depth tree rejects with the same key on both positions, the
/// rollback band's parity obligation). ORCH blade 4 (P1/P2): the
/// std Error-instance text enters through the composer — the
/// twin's own `import "std/error"` declaration splices the
/// library first-seen (the twin's `attempt`/`unwrap`/`raise`
/// references expand against the library's live definitions, the
/// M58 semantic carried through the composition layer; the raw
/// prefix splice retired).
pub fn assembled_compiler_target_source_with_limit(limit: usize) -> String {
    format!(
        "define(co_limit, {limit});\n{}",
        with_hosting_tail(
            &compose_selfhost(COMPILER_TARGET_SOURCE),
            COMPILER_HOSTING_TAIL,
            "define(result, cp_run(items));"
        )
    )
}

/// Transcode one `(define NAME (quote DATA))` S-expr prefix into
/// the target skin: `define(NAME', quote(DATA'));` — then
/// round-trip check the emission through the real target reader
/// (the naming guard: the transcoded prefix must read back to the
/// byte-identical Stx display).
///
/// The r151 single-skin rewrite: the S-expression reader that used
/// to carry the prefix extraction left the tree with the
/// W-SEXP-RETIRE scaffold, so the channel carries its own bounded
/// parser over the closed prefix grammar (symbols, ints, strings,
/// nested lists, `nil`) — fail-closed on anything outside that
/// grammar, the same harness-defect discipline as before. The
/// naming guard survives unchanged: the emission still round-trips
/// through the real target reader.
pub(crate) fn transcode_quoted_define(prefix: &str) -> String {
    let mut parser = PrefixParser {
        text: prefix.as_bytes(),
        pos: 0,
    };
    let forms = parser.parse_program();
    assert!(
        !forms.is_empty(),
        "harness defect: the prefix is at least one define form"
    );
    // Blade 2 (GZ-2): the prefix is a FAMILY of define forms (the
    // forms stream + the struct accessor-name table) — one output
    // define per input, each through the same (define NAME (quote
    // DATA)) shape and the same naming guard.
    let mut out = String::with_capacity(prefix.len() + 16);
    for form in &forms {
        let items = match form {
            PrefixDatum::List(items) => items,
            _ => panic!("harness defect: the prefix form is a list"),
        };
        assert_eq!(
            items.len(),
            3,
            "harness defect: the prefix form is (define NAME (quote DATA))"
        );
        let name = match &items[1] {
            PrefixDatum::Symbol(symbol) => target_skin_spelling(symbol),
            _ => panic!("harness defect: the define name is a symbol"),
        };
        let quoted = match &items[2] {
            PrefixDatum::List(quote_items) => quote_items,
            _ => panic!("harness defect: the define value is a quote form"),
        };
        assert_eq!(
            quoted.len(),
            2,
            "harness defect: the quote form takes one datum"
        );
        out.push_str("define(");
        out.push_str(&name);
        out.push_str(", quote(");
        emit_target_datum(&to_stx_datum(&quoted[1]), &mut out);
        out.push_str("));\n");
    }
    // The naming guard: the emission must read back to the identical
    // tree — an unrepresentable name is a harness defect, never a
    // silent rename.
    let read_back = read_target_program(FileId(0), &out)
        .unwrap_or_else(|e| panic!("harness defect: the transcoded prefix must read: {e}"));
    assert_eq!(
        read_back.len(),
        forms.len(),
        "harness defect: the transcoded prefix is one form per input"
    );
    // The comparison rides the Stx DISPLAY (span-free) — the r151
    // rewrite's whole-object equality dragged synthetic zero spans
    // into the guard and broke every consumer (the naming guard
    // protects names and structure, never span identity).
    for (i, form) in forms.iter().enumerate() {
        assert_eq!(
            read_back[i].datum.to_string(),
            to_stx_datum(form).to_string(),
            "harness defect: the transcoded prefix must round-trip to the identical tree"
        );
    }
    out
}

/// One datum of the closed injection-prefix grammar (the bounded
/// set every `*_prefix` builder emits: symbols, ints, floats,
/// bools, strings, nested lists; `nil` rides as a symbol).
#[derive(Debug, Clone, PartialEq)]
enum PrefixDatum {
    Symbol(String),
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(String),
    List(Vec<PrefixDatum>),
}

/// The Stx-tree projection of one prefix datum (the bridge the
/// naming guard compares against — the real `SyntaxObject` the
/// target reader produced).
fn to_stx_datum(datum: &PrefixDatum) -> StxDatum {
    match datum {
        PrefixDatum::Symbol(s) => StxDatum::Symbol(
            kerf_span::Symbol::new(s).expect("harness defect: prefix symbol must intern"),
        ),
        PrefixDatum::Int(v) => StxDatum::Int(*v),
        PrefixDatum::Float(v) => StxDatum::Float(*v),
        PrefixDatum::Bool(v) => StxDatum::Bool(*v),
        PrefixDatum::Str(s) => StxDatum::String(s.as_str().into()),
        PrefixDatum::List(items) => StxDatum::List(
            items
                .iter()
                .map(|item| kerf_syntax::SyntaxObject {
                    datum: to_stx_datum(item),
                    span: kerf_span::Span::new(
                        FileId(0),
                        kerf_span::ByteOffset(0),
                        kerf_span::ByteOffset(0),
                        kerf_span::ExpansionId::ROOT,
                    )
                    .expect("harness defect: zero span is well-ordered"),
                    phase: kerf_syntax::Phase::Runtime,
                    scopes: kerf_syntax::ScopeSet::new(),
                })
                .collect(),
        ),
    }
}

/// The bounded parser over the prefix grammar — fail-closed on
/// anything outside it (a harness defect, never a silent
/// misparse).
struct PrefixParser<'a> {
    text: &'a [u8],
    pos: usize,
}

impl PrefixParser<'_> {
    fn skip_ws(&mut self) {
        while self.pos < self.text.len() && self.text[self.pos].is_ascii_whitespace() {
            self.pos += 1;
        }
    }

    fn parse_program(&mut self) -> Vec<PrefixDatum> {
        let mut forms = Vec::new();
        loop {
            self.skip_ws();
            if self.pos >= self.text.len() {
                return forms;
            }
            forms.push(self.parse_datum());
        }
    }

    fn parse_datum(&mut self) -> PrefixDatum {
        self.skip_ws();
        match self.text.get(self.pos) {
            Some(b'(') => {
                self.pos += 1;
                let mut items = Vec::new();
                loop {
                    self.skip_ws();
                    match self.text.get(self.pos) {
                        Some(b')') => {
                            self.pos += 1;
                            return PrefixDatum::List(items);
                        }
                        None => panic!("harness defect: unterminated prefix list"),
                        _ => items.push(self.parse_datum()),
                    }
                }
            }
            Some(b'"') => {
                // The escape set is exactly `encode_string_literal`'s.
                self.pos += 1;
                let mut out = String::new();
                loop {
                    match self.text.get(self.pos) {
                        Some(b'\\') => {
                            let esc = self
                                .text
                                .get(self.pos + 1)
                                .copied()
                                .unwrap_or_else(|| panic!("harness defect: dangling escape"));
                            match esc {
                                b'"' => out.push('"'),
                                b'\\' => out.push('\\'),
                                b'n' => out.push('\n'),
                                b't' => out.push('\t'),
                                b'r' => out.push('\r'),
                                other => panic!(
                                    "harness defect: unknown prefix escape `\\{}`",
                                    other as char
                                ),
                            }
                            self.pos += 2;
                        }
                        Some(b'"') => {
                            self.pos += 1;
                            return PrefixDatum::Str(out);
                        }
                        Some(&b) => {
                            out.push(b as char);
                            self.pos += 1;
                        }
                        None => panic!("harness defect: unterminated prefix string"),
                    }
                }
            }
            Some(_) => {
                let start = self.pos;
                while self.pos < self.text.len()
                    && !self.text[self.pos].is_ascii_whitespace()
                    && !matches!(self.text[self.pos], b'(' | b')' | b'"')
                {
                    self.pos += 1;
                }
                let atom = std::str::from_utf8(&self.text[start..self.pos])
                    .unwrap_or_else(|_| panic!("harness defect: non-utf8 prefix atom"));
                if atom == "#t" {
                    PrefixDatum::Bool(true)
                } else if atom == "#f" {
                    PrefixDatum::Bool(false)
                } else if let Ok(v) = atom.parse::<i64>() {
                    PrefixDatum::Int(v)
                } else if let Ok(v) = atom.parse::<f64>() {
                    PrefixDatum::Float(v)
                } else {
                    PrefixDatum::Symbol(atom.to_string())
                }
            }
            None => panic!("harness defect: prefix ends mid-datum"),
        }
    }
}

/// The byte-table prefix on the target skin (`source_bytes`).
pub fn target_byte_table_prefix(source: &str) -> String {
    transcode_quoted_define(&byte_table_prefix(source))
}

// ---------- the datum spellability face (the r104 composed target
// chain's junction-2 data boundary) ----------

/// Can one datum ride the target skin's LITERAL face? The one
/// value-class boundary: a negative integer whose positive part
/// exceeds `i64::MAX` — i.e. exactly `i64::MIN` — cannot (the
/// target lexer applies the sign after parsing the magnitude, so
/// the bare magnitude `9223372036854775808` overflows `i64` before
/// the sign ever applies; every other negative integer and every
/// negative float reads back fine). This is the r103
/// exception-ledger boundary (a negative literal with no positive
/// counterpart — the corpus face carries those cases through
/// arithmetic-composition twins, switch-window-plan §5.6.2),
/// instantiated on the junction-2 data-injection face: form-record
/// data carrying an `i64::MIN` datum has NO target-skin text, so
/// the composed target chain classifies the case at the boundary
/// instead of silently re-spelling it (§2.3 report-don't-hide).
pub fn datum_target_spellable(datum: &StxDatum) -> bool {
    match datum {
        // The single value-class boundary: i64::MIN (the magnitude
        // 2^63 overflows the positive domain before the sign).
        StxDatum::Int(v) => *v != i64::MIN,
        StxDatum::Float(_) | StxDatum::Bool(_) | StxDatum::String(_) | StxDatum::Symbol(_) => true,
        StxDatum::List(items) => items.iter().all(|i| datum_target_spellable(&i.datum)),
    }
}

/// Do all of a form stream's datums ride the target skin's literal
/// face? (The junction-2 feed's spellability precheck — one walk,
/// never a try-and-panic.)
pub fn forms_target_spellable(forms: &[SyntaxObject]) -> bool {
    forms.iter().all(|f| datum_target_spellable(&f.datum))
}

/// The form-record prefix on the target skin (`forms`).
pub fn target_forms_stream_prefix(forms: &[SyntaxObject]) -> String {
    transcode_quoted_define(&forms_stream_prefix(forms))
}

/// The item-record prefix on the target skin (`items`).
pub fn target_items_stream_prefix(items: &[ModuleItem]) -> String {
    transcode_quoted_define(&items_stream_prefix(items))
}

// ---------- the step-4 production bridge (switch-window-plan §1) ----------

/// Read one target-skin source through the BOOTSTRAP front end
/// (switch-window-plan §1 step 4 — the production bridge): the new
/// reader parses the text, the shared spine expands and loads it.
/// This is the `.ktf` chain's entry into the bootstrap composition
/// — the twin of reading a seed-skin source through the seed reader,
/// and the exact face the step-4 fixpoint drives its own source
/// through (stage0.md §9.30.4: "the target-syntax Reader compiles
/// itself" starts here).
///
/// `Err` carries the classified front-end rejection (the harness
/// discipline — reader/expand/loader failures are reported, never a
/// panic).
pub fn read_target_source_for_bootstrap(
    name: &str,
    source: &str,
) -> Result<Vec<ModuleItem>, String> {
    // The SEED/ORACLE pin (the step-④ dual-chain decoupling, ALL
    // THREE segments): this bridge is the Rust production-bridge
    // oracle arm of the fixpoint purity legs ("the twin front end ==
    // the Rust production bridge") — it must ride the Rust reader,
    // the Rust expander, AND the Rust checkers explicitly, never
    // the switched production positions, or the differential
    // collapses into a self-comparison (detection power zero); the
    // check pin is the r147 extension (a twin-position check here
    // would run the checker twins on the purity leg's own inputs —
    // the same collapse on the checking axis).
    let mut session = crate::session::Session::with_segments(
        crate::read_segment::ReadSegment::Rust,
        crate::expand_segment::ExpandSegment::Rust,
        crate::check_segment::CheckSegment::Rust,
        crate::compile_segment::CompileSegment::Rust,
    );
    match pipeline::parse_target(&mut session, name, source) {
        Ok(program) => Ok(program.items),
        Err(diags) => Err(format!(
            "the bootstrap front end rejected the target source: {diags:?}"
        )),
    }
}

/// The target-skin rich compile, VM-only — the step-4 twin of the
/// retired seed-skin rich compile (its original left the tree at
/// the r104 E5 teardown): the same assembled target program parsed
/// by the NEW reader, driven through the VM with the verdict text
/// consumed by the caller (the fixpoint's C(S) and C(C(S)) phases
/// ride this face). The MODERN2 blade-4 retirement: the compiler
/// twin consumes the Error vocabulary (`perform raise` + the
/// `unwrap(attempt(...))` boundary), and the k-form raise paths
/// ride the VM's one-shot semantics only — the eval axis retired
/// for this family (the M16/M46 policy line, TD-031's scope); the
/// oracle-comparison axis (twin-vm vs the Rust oracle, per case)
/// carries the full drift load. The assembly carries the std
/// Error-instance prefix ahead of the twin (the M58 face — the
/// twin's `attempt`/`unwrap`/`raise` references expand against
/// the library's live definitions).
pub fn ktf_compile_rich(
    items: &[ModuleItem],
    compiler_target_source: &str,
) -> Result<RichCompileRun, String> {
    // The compile twin's work budget rides the assembly prefix at
    // the DEFAULT depth (this is a verification face — deterministic,
    // never the process env; the `ex_limit` assembled-default
    // precedent). The twin hard-requires `co_limit`: an assembly
    // that omits the define fails loudly at the first depth check
    // (unbound — fail-closed, never a silent default). ORCH blade 4
    // (P2): the std Error-instance text rides the composed body —
    // the twin's own import declaration through the composer (the
    // raw prefix splice retired; the composer is the one splice
    // mechanism).
    let prefix = format!(
        "{}\ndefine(co_limit, {});",
        target_items_stream_prefix(items),
        kerf_compiler::COMPILE_DEPTH_LIMIT
    );
    // The ORCH blade-3 library form (B1): the caller passes the
    // LIBRARY body; the hosting tail — the drive contract this
    // face exists to serve — is appended here, fail-closed on a
    // tailed input. The body composes through the import surface
    // (P2): the twin's `import "std/error"` declaration splices
    // the library ahead of the body.
    let hosted = with_hosting_tail(
        &compose_selfhost(compiler_target_source),
        COMPILER_HOSTING_TAIL,
        "define(result, cp_run(items));",
    );
    let assembled = format!("{prefix}\n{hosted}");
    let decode_vm_rich =
        |value: &Value,
         heap: &Heap|
         -> Result<(KtfVerdict<kerf_compiler::CompileError>, Option<Bytecode>), String> {
            let verdict = decode_tagged(value, heap, dump_ktf_section, rebuild_compile_error)?;
            let rebuilt = match &verdict {
                KtfVerdict::Tree(_) => Some(rebuild_bytecode(value, heap)?),
                KtfVerdict::Error(_) => None,
            };
            Ok((verdict, rebuilt))
        };
    let (vm_verdict, rebuilt) = drive_vm_only(
        "target-compiler-parity-host",
        "target compiler",
        &assembled,
        decode_vm_rich,
    )?;
    Ok(RichCompileRun {
        vm_text: vm_verdict.text(),
        bytecode: rebuilt,
    })
}

// ---------- the gate-B bytecode face on the production-chain skin ----------

/// The gate-B bytecode face (the r104 E5 batch-3 carry; the r151
/// single-skin retarget — the retired seed reader swapped for the
/// target reader): the source reads through the oracle front end,
/// the items compile through the oracle, and the `.ktf` compiler
/// twin's REBUILT product (both engines, through the production
/// bridge) must equal the oracle's own compilation byte-for-byte —
/// the `Bytecode: PartialEq` gate with the descriptor tables
/// included.
pub fn gate_b_bytecode(case: &str, source: &str) -> Result<(), String> {
    let forms = kerf_reader::read_target_program(FileId(0), source)
        .map_err(|err| format!("gate B [{case}]: the reader rejected the source: {err}"))?;
    let oracle_items = kerf_expander::expand_program(&forms)
        .map_err(|err| format!("gate B [{case}]: the oracle rejected the source: {err}"))?;
    kerf_expander::load_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: the oracle loader rejected: {err}"))?;
    let bc_oracle = kerf_compiler::compile_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: oracle compile failed: {err}"))?;
    let run = ktf_compile_rich(&oracle_items, COMPILER_TARGET_SOURCE)
        .map_err(|err| format!("gate B [{case}]: {err}"))?;
    let bc = run.bytecode.ok_or_else(|| {
        format!(
            "gate B [{case}]: the .ktf compiler rejected: {}",
            run.vm_text
        )
    })?;
    if bc == bc_oracle {
        Ok(())
    } else {
        Err(format!(
            "gate B [{case}]: bytecode drift (oracle {} protos / ktf {} protos)",
            bc_oracle.funcs.len(),
            bc.funcs.len()
        ))
    }
}

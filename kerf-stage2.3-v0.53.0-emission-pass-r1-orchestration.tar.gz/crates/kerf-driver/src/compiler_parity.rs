//! Stage 2.3 CP parity — the fourth self-hosted front-end segment
//! (docs/stage0.md §9.83/§9.84, stage-2-plan §2 row 2.3, anchors
//! K193-K197 + K198-K203). The compile-time **pure-function surface**
//! of the compiler — the lexical-domain analysis (the scope-stack
//! mark/truncate discipline plus the free-slot LIFO, the
//! innermost-first local lookup, the LA-1 three-way resolution, the
//! LA-4 transitive `held_by` capture analysis, the first-use
//! global/const interning) AND the instruction emission (the single
//! emit path with the opcode stack-effect table, the jump
//! backpatching discipline, the dense per-instruction `debug_info`
//! table, the tail-position terminator contract, the finish-time
//! placeholder drain) — rewritten in the frozen kerf subset itself
//! (`selfhost/v1/compiler.krf`, the fourth selfhost file after
//! reader/expander/macro) and compared against the Rust oracle
//! (`kerf_compiler::compile_program`) on two axes:
//!
//! * **Product axis** — the products that land in the `Bytecode`:
//!   `funcs[].{name, params, n_locals, captures}` (creation order,
//!   captures in first-use order with the LA-2/LA-4 descriptor
//!   sources), the per-proto instruction streams `code` (pc order,
//!   stable kebab opcode names, operands) and `dbg` (the dense
//!   per-instruction span table), plus `globals` and `consts` in
//!   first-use order. Both sides normalize to the same dump text
//!   (K196/K203 translation-validation shape: the a-posteriori
//!   check runs per product family — the emitted instruction
//!   stream included). The span face of the comparison is the
//!   offset pair, the same convention the 1.5/1.6/1.7 parities and
//!   the error axis use (Span's Display carries file and offsets;
//!   expansion ids stay outside the comparison text, owned by the
//!   1.6/1.7 faces).
//! * **Error axis** — the `.krf` compiler reports a structured
//!   rejection (`("err" kind payload...)`); the harness rebuilds
//!   the `CompileError` and renders it through the oracle's own
//!   `Display`, so byte parity holds by construction and the
//!   non-trivial part under test is the kind / payload / span
//!   selection (the compile-reachable family: `assign-to-captured`
//!   and `depth`; the emission defenses `stack-underflow`,
//!   `stack-imbalance` and `unpatched-jump` fire only on a broken
//!   emitter and surface as readable drift, and `bad-patch` /
//!   `bad-node` classify as harness defects).
//!
//! The item tree is source-injected (CP-1, §9.83): the host runs
//! the Rust reader AND the Rust expander (the single sources of
//! tree truth for their layers) and injects the **expanded** item
//! tree as a flat pre-order record stream ahead of the compiler
//! source as `(define items (quote (record ...)))`. Every record is
//! a flat list (the 1.5/1.6 discipline: a flat shape keeps the
//! assembled source inside the reader's 256 nesting cap even for
//! 255-deep trees); variable-arity records carry their child count
//! in a field, and children follow as the next records. Spans ride
//! as decimal byte-offset strings and floats as Debug text (the
//! 1.5 conventions, carried opaquely — the analysis products are
//! span-independent; only the two rejection kinds surface spans).
//!
//! Three layers decide a case: sources the *reader* rejects take
//! the [`CompilerParityLayer::Reader`] path (the 1.5 parity owns
//! that face); sources the *expander or loader* rejects take the
//! [`CompilerParityLayer::Expander`] path (the 1.6/1.7 parities own
//! that face); everything else runs the assembled `.krf` analysis
//! on **both engines** (the `run_parity` lineage) and is compared
//! against the Rust oracle — products, or the structured
//! rejections. The typecheck layer never decides a CP case: the
//! checker and the compiler are independent consumers of the same
//! expanded tree, and the analysis products are well-defined on
//! trees the checker would reject (the E0012 family still produces
//! a *compile-side* `assign-to-captured` rejection — the LA-7
//! three-layer defense).

use kerf_compiler::{Bytecode, CaptureSource, CompileError, compile_program};
use kerf_core::{Binding, CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf_expander::{expand_program, load_program};
use kerf_reader::read_program;
use kerf_span::{FileId, Span, Symbol};
use kerf_vm::{BufferIo, Heap, RuntimeError, Value, Vm};

use crate::diagnostic::Severity;
use crate::expander_parity::{dump_krf_litval, dump_oracle_lit, krf_name, make_span};
use crate::pipeline;
use crate::reader_parity::{
    KrfVerdict, as_i64, as_str, decode_tagged, drive_dual_engines, encode_string_literal,
    need_fields, value_elems,
};
use crate::session::Session;

/// The self-hosted compile-time analysis, embedded from the
/// workspace's bootstrap face (single source — tests and the audit
/// consume this constant, never a copy).
pub const COMPILER_SOURCE: &str = include_str!("../../../selfhost/v1/compiler.krf");

/// Which layer produced a case's verdict.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompilerParityLayer {
    /// The Rust reader rejected the source: the 1.5 reader parity
    /// owns that face; the `.krf` analysis is not exercised.
    Reader,
    /// The Rust expander or loader rejected the source: the
    /// 1.6/1.7 parities own that face; no expanded tree exists to
    /// analyze.
    Expander,
    /// The `.krf` analysis ran on both engines and was compared
    /// against the Rust oracle (analysis products, or the
    /// structured rejections).
    Compiler,
}

/// The outcome of one CP-parity case.
#[derive(Debug, Clone)]
pub struct CompilerParityReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// Which layer decided the case.
    pub layer: CompilerParityLayer,
    /// The oracle's normalized analysis dump, or its rendered
    /// rejection (or the upstream layer's rejection text on the
    /// reader/expander layers).
    pub oracle: String,
    /// The `.krf` layer's matching form (`None` on the reader and
    /// expander layers, or a harness defect).
    pub krf: Option<String>,
    /// Both engines agreed on the `result` global's verdict.
    pub engines_agree: bool,
    /// Oracle and `.krf` layer agree (product axis or error axis).
    pub matched: bool,
    /// The mismatch description when `!matched` (both sides shown).
    pub drift: Option<String>,
}

impl CompilerParityReport {
    /// The one-line failure form (the parity.rs `failure_line`
    /// lineage — corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("compiler parity FAIL [{}]: {d}", self.case),
            None => format!("compiler parity PASS [{}]", self.case),
        }
    }
}

/// The error-axis parity key: stage Display + harness-rendered span
/// payload (§9.56 DIAG-1 compensation — the message is
/// position-free, so the comparison key must distinguish payloads,
/// exactly like the expander parity's `error_parity_key`).
fn cp_error_key(err: &CompileError) -> String {
    match err.span() {
        Some(span) => format!("{err} @ {span}"),
        None => format!("{err} @ <no-span>"),
    }
}

impl KrfVerdict<CompileError> {
    /// The rendered comparison text (analysis dump, or the
    /// parity-key form of the rebuilt rejection).
    fn text(&self) -> String {
        match self {
            KrfVerdict::Tree(dump) => dump.clone(),
            KrfVerdict::Error(err) => cp_error_key(err),
        }
    }
}

// ---------- CP-1: the source-injected items stream ----------

fn span_fields(span: Span) -> (String, String) {
    (span.start.0.to_string(), span.end.0.to_string())
}

/// Emit one literal value into the flat stream vocabulary: atoms
/// close themselves; a pair emits `("lpair")` and its two litval
/// children follow as the next records.
fn emit_litval(value: &LiteralValue, out: &mut String) {
    match value {
        LiteralValue::Int(v) => out.push_str(&format!("(\"lint\" {v})")),
        LiteralValue::Float(v) => {
            // Debug text rides as a string (the 1.5 convention).
            out.push_str(&format!(
                "(\"lfloat\" {})",
                encode_string_literal(&format!("{v:?}"))
            ));
        }
        LiteralValue::Bool(v) => {
            let lit = if *v { "#t" } else { "#f" };
            out.push_str(&format!("(\"lbool\" {lit})"));
        }
        LiteralValue::String(v) => {
            out.push_str(&format!("(\"lstring\" {})", encode_string_literal(v)));
        }
        LiteralValue::Nil => out.push_str("(\"lnil\")"),
        LiteralValue::Pair(a, b) => {
            out.push_str("(\"lpair\")");
            out.push(' ');
            emit_litval(a, out);
            out.push(' ');
            emit_litval(b, out);
        }
    }
}

/// Emit one binding record: `("bind" s e name)` with the value as
/// the next record.
fn emit_binding(b: &Binding, out: &mut String) {
    let (s, e) = span_fields(b.span);
    out.push_str(&format!(
        "(\"bind\" \"{s}\" \"{e}\" {})",
        encode_string_literal(b.name.as_str())
    ));
    out.push(' ');
    emit_expr(&b.value, out);
}

/// Emit one handler-clause record: `("clause" cs ce effect)` with
/// the handler expression as the next record.
fn emit_clause(h: &HandlerClause, out: &mut String) {
    let (s, e) = span_fields(h.span);
    out.push_str(&format!(
        "(\"clause\" \"{s}\" \"{e}\" {})",
        encode_string_literal(h.effect.as_str())
    ));
    out.push(' ');
    emit_expr(&h.handler, out);
}

/// Emit one expression record into the flat pre-order stream (the
/// vocabulary is the single-source contract documented in
/// `compiler.krf`'s header; children follow as the next records).
fn emit_expr(expr: &CoreExpr, out: &mut String) {
    let span = expr_span(expr);
    let (s, e) = span_fields(span);
    match expr {
        CoreExpr::Fn { params, body, .. } => {
            out.push_str(&format!("(\"fn\" \"{s}\" \"{e}\""));
            // An empty parameter list rides as `nil` (the CP-1
            // vocabulary contract): a bare `()` is a read error
            // (empty application), so the params field must never
            // render as an empty list.
            if params.is_empty() {
                out.push_str(" nil)");
            } else {
                out.push_str(" (");
                for (i, p) in params.iter().enumerate() {
                    if i > 0 {
                        out.push(' ');
                    }
                    out.push_str(&encode_string_literal(p.as_str()));
                }
                out.push_str("))");
            }
            out.push(' ');
            emit_expr(body, out);
        }
        CoreExpr::Apply { func, args, .. } => {
            out.push_str(&format!("(\"apply\" \"{s}\" \"{e}\" {})", args.len()));
            for arg in args {
                out.push(' ');
                emit_expr(arg, out);
            }
            out.push(' ');
            emit_expr(func, out);
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            out.push_str(&format!("(\"if\" \"{s}\" \"{e}\")"));
            out.push(' ');
            emit_expr(cond, out);
            out.push(' ');
            emit_expr(then_branch, out);
            out.push(' ');
            emit_expr(else_branch, out);
        }
        CoreExpr::Var { name, .. } => {
            out.push_str(&format!(
                "(\"var\" \"{s}\" \"{e}\" {})",
                encode_string_literal(name.as_str())
            ));
        }
        CoreExpr::Literal { value, .. } => {
            out.push_str(&format!("(\"lit\" \"{s}\" \"{e}\")"));
            out.push(' ');
            emit_litval(value, out);
        }
        CoreExpr::Assign { name, value, .. } => {
            out.push_str(&format!(
                "(\"assign\" \"{s}\" \"{e}\" {})",
                encode_string_literal(name.as_str())
            ));
            out.push(' ');
            emit_expr(value, out);
        }
        CoreExpr::Let { bindings, body, .. } => {
            out.push_str(&format!("(\"let\" \"{s}\" \"{e}\" {})", bindings.len()));
            for b in bindings {
                out.push(' ');
                emit_binding(b, out);
            }
            out.push(' ');
            emit_expr(body, out);
        }
        CoreExpr::Perform { effect, args, .. } => {
            out.push_str(&format!(
                "(\"perform\" \"{s}\" \"{e}\" {} {})",
                args.len(),
                encode_string_literal(effect.as_str())
            ));
            for arg in args {
                out.push(' ');
                emit_expr(arg, out);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            out.push_str(&format!("(\"handle\" \"{s}\" \"{e}\" {})", handlers.len()));
            for h in handlers {
                out.push(' ');
                emit_clause(h, out);
            }
            out.push(' ');
            emit_expr(body, out);
        }
    }
}

/// Every CoreExpr variant carries a `span` field (the constructor
/// contract); this reads it without consuming the enum.
fn expr_span(expr: &CoreExpr) -> Span {
    match expr {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

/// Emit one item record into the flat pre-order stream.
fn emit_item(item: &ModuleItem, out: &mut String) {
    match item {
        ModuleItem::Define { span, name, value } => {
            let (s, e) = span_fields(*span);
            out.push_str(&format!(
                "(\"define\" \"{s}\" \"{e}\" {})",
                encode_string_literal(name.as_str())
            ));
            out.push(' ');
            emit_expr(value, out);
        }
        ModuleItem::Require { span, module } => {
            let (s, e) = span_fields(*span);
            out.push_str(&format!(
                "(\"require\" \"{s}\" \"{e}\" {})",
                encode_string_literal(module.as_str())
            ));
        }
        ModuleItem::DefineSyntax { span, name } => {
            let (s, e) = span_fields(*span);
            out.push_str(&format!(
                "(\"defsyn\" \"{s}\" \"{e}\" {})",
                encode_string_literal(name.as_str())
            ));
        }
        ModuleItem::Module { span, name, items } => {
            let (s, e) = span_fields(*span);
            out.push_str(&format!(
                "(\"module\" \"{s}\" \"{e}\" {} {})",
                items.len(),
                encode_string_literal(name.as_str())
            ));
            for inner in items {
                out.push(' ');
                emit_item(inner, out);
            }
        }
    }
}

/// Build the `(define items (quote (...)))` prefix for one
/// already-expanded item tree (the CP-1 injection).
pub fn items_stream_prefix(items: &[ModuleItem]) -> String {
    let mut out = String::from("(define items (quote (");
    for (i, item) in items.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        emit_item(item, &mut out);
    }
    out.push_str(")))");
    out
}

// ---------- the oracle's normalized analysis dump ----------

fn dump_oracle_capture(src: &CaptureSource, out: &mut String) {
    match src {
        CaptureSource::Local(slot) => out.push_str(&format!("(local {slot})")),
        CaptureSource::Captured(k) => out.push_str(&format!("(captured {k})")),
    }
}

/// The oracle's normalized analysis dump: `(funcs (proto NAME
/// PARAMS NLOCALS (caps SRC...) (code (OP A B)...) (dbg (sp S
/// E)...)) ...) (globals NAME...) (consts LIT...)` — the same
/// grammar the `.krf` compiler emits, so the byte comparison covers
/// creation order, first-use orders, the descriptor sources, the
/// const pool identity (NaN folds, signed zeros stay distinct —
/// `same_const_slot`'s rule mirrored by Debug-text identity), the
/// full instruction streams (opcode names, operands, patch-resolved
/// jump targets — K198/K203) and the dense per-instruction span
/// table (K201). The span face is the offset pair (the parity
/// family convention; expansion ids stay outside the text).
pub fn oracle_analysis_dump(bc: &Bytecode) -> String {
    let mut out = String::from("(funcs");
    for f in &bc.funcs {
        out.push_str(" (proto ");
        match &f.name {
            Some(name) => out.push_str(name.as_str()),
            None => out.push_str("nil"),
        }
        out.push_str(&format!(" {} {} (caps", f.params, f.n_locals));
        for c in &f.captures {
            out.push(' ');
            dump_oracle_capture(c, &mut out);
        }
        out.push_str(") (code");
        for i in &f.code {
            out.push_str(&format!(" ({} {} {})", i.op.kind_name(), i.a, i.b));
        }
        out.push_str(") (dbg");
        for s in &f.debug_info {
            out.push_str(&format!(" (sp {} {})", s.start.0, s.end.0));
        }
        out.push_str("))");
    }
    out.push_str(") (globals");
    for g in &bc.globals {
        out.push(' ');
        out.push_str(g.as_str());
    }
    out.push_str(") (consts");
    for c in &bc.consts {
        out.push(' ');
        dump_oracle_lit(c, &mut out);
    }
    out.push(')');
    out
}

// ---------- the `.krf` product decoders ----------

/// One capture-source record: `("local" slot)` / `("captured" k)`.
fn dump_krf_capture(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 2, "capture source record")?;
    match as_str(elems[0])? {
        "local" => {
            let slot = as_i64(elems[1])?;
            out.push_str(&format!("(local {slot})"));
        }
        "captured" => {
            let k = as_i64(elems[1])?;
            out.push_str(&format!("(captured {k})"));
        }
        other => return Err(format!("unknown capture source `{other}`")),
    }
    Ok(())
}

/// One instruction record of the `("code" ...)` section:
/// `(op-name a b)` — the stable kebab name plus the two operands.
fn dump_krf_insn(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 3, "instruction record")?;
    let name = as_str(elems[0])?;
    let a = as_i64(elems[1])?;
    let b = as_i64(elems[2])?;
    if a < 0 || b < 0 {
        return Err(format!("negative operand in instruction `{name} {a} {b}`"));
    }
    out.push_str(&format!("({name} {a} {b})"));
    Ok(())
}

/// One span record of the `("dbg" ...)` section: `(s e)` decimal
/// strings — rendered in the oracle dump's `(sp s e)` grammar.
fn dump_krf_span(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 2, "debug-info span record")?;
    let s = as_str(elems[0])?;
    let e = as_str(elems[1])?;
    out.push_str(&format!("(sp {s} {e})"));
    Ok(())
}

/// The tagged payload of one proto product section field: `("caps"
/// src...)` / `("code" insn...)` / `("dbg" sp...)`.
fn dump_krf_proto_field(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    let tag = as_str(
        elems
            .first()
            .ok_or_else(|| "a proto field must be a tagged record".to_string())?,
    )?;
    match tag {
        "caps" => {
            out.push_str("(caps");
            for src in &elems[1..] {
                out.push(' ');
                dump_krf_capture(src, heap, out)?;
            }
            out.push(')');
        }
        "code" => {
            out.push_str("(code");
            for insn in &elems[1..] {
                out.push(' ');
                dump_krf_insn(insn, heap, out)?;
            }
            out.push(')');
        }
        "dbg" => {
            out.push_str("(dbg");
            for sp in &elems[1..] {
                out.push(' ');
                dump_krf_span(sp, heap, out)?;
            }
            out.push(')');
        }
        other => return Err(format!("unknown proto field tag `{other}`")),
    }
    Ok(())
}

/// One proto product record: `("proto" name params n-locals
/// ("caps" src...) ("code" insn...) ("dbg" sp...))`.
fn dump_krf_proto(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 7, "`proto` product record")?;
    out.push_str("(proto ");
    match elems[1] {
        Value::Nil => out.push_str("nil"),
        _ => out.push_str(&krf_name(elems[1], heap)?),
    }
    let params = as_i64(elems[2])?;
    let n_locals = as_i64(elems[3])?;
    out.push_str(&format!(" {params} {n_locals}"));
    out.push(' ');
    dump_krf_proto_field(elems[4], heap, out)?;
    out.push(' ');
    dump_krf_proto_field(elems[5], heap, out)?;
    out.push(' ');
    dump_krf_proto_field(elems[6], heap, out)?;
    out.push(')');
    Ok(())
}

/// One section record of the `("ok" ...)` product: `("funcs"
/// proto...)` / `("globals" name...)` / `("consts" lit...)` —
/// rendered in the oracle dump's grammar.
fn dump_krf_section(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    let tag = as_str(
        elems
            .first()
            .ok_or_else(|| "a section record must be non-empty".to_string())?,
    )?;
    match tag {
        "funcs" => {
            out.push_str("(funcs");
            for proto in &elems[1..] {
                out.push(' ');
                dump_krf_proto(proto, heap, out)?;
            }
            out.push(')');
        }
        "globals" => {
            out.push_str("(globals");
            for name in &elems[1..] {
                out.push(' ');
                out.push_str(&krf_name(name, heap)?);
            }
            out.push(')');
        }
        "consts" => {
            out.push_str("(consts");
            for lit in &elems[1..] {
                out.push(' ');
                dump_krf_litval(lit, heap, out)?;
            }
            out.push(')');
        }
        other => return Err(format!("unknown product section `{other}`")),
    }
    Ok(())
}

// ---------- the structured-error rebuild (error axis) ----------

/// Rebuild the analysis-reachable `CompileError` family from the
/// `.krf` rejection record (the LA-7 compile-side boundary and the
/// depth mirror; `bad-node` is the fail-closed harness-stream
/// defense, reported as a harness defect).
fn rebuild_compile_error(value: &Value, heap: &Heap) -> Result<CompileError, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "analysis rejection record")?;
    let kind = as_str(elems[1])?;
    match kind {
        "assign-to-captured" => {
            need_fields(&elems, 5, "`assign-to-captured` rejection")?;
            Ok(CompileError::AssignToCaptured {
                name: Symbol::new(&krf_name(elems[2], heap)?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "depth" => {
            need_fields(&elems, 5, "`depth` rejection")?;
            let depth = as_i64(elems[2])?;
            if depth < 0 {
                return Err(format!("negative depth payload `{depth}`"));
            }
            Ok(CompileError::DepthExceeded {
                depth: depth as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "stack-underflow" => {
            need_fields(&elems, 5, "`stack-underflow` rejection")?;
            let pc = as_i64(elems[2])?;
            if pc < 0 {
                return Err(format!("negative pc payload `{pc}`"));
            }
            Ok(CompileError::StackUnderflow {
                pc: pc as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "stack-imbalance" => {
            need_fields(&elems, 7, "`stack-imbalance` rejection")?;
            let pc = as_i64(elems[2])?;
            let expected = as_i64(elems[3])?;
            let actual = as_i64(elems[4])?;
            if pc < 0 || expected < 0 || actual < 0 {
                return Err(format!(
                    "negative payload in stack-imbalance `{pc} {expected} {actual}`"
                ));
            }
            Ok(CompileError::StackImbalance {
                pc: pc as usize,
                expected: expected as u32,
                actual: actual as u32,
                span: make_span(elems[5], elems[6])?,
            })
        }
        "unpatched-jump" => {
            need_fields(&elems, 5, "`unpatched-jump` rejection")?;
            let at = as_i64(elems[2])?;
            if at < 0 {
                return Err(format!("negative pc payload `{at}`"));
            }
            Ok(CompileError::UnpatchedJump {
                at: at as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "bad-patch" => Err(format!(
            "the .krf emitter tried to patch a non-placeholder pc `{}` — a .krf \
             harness defect, never a source defect",
            as_i64(*elems.get(2).ok_or("bad-patch payload")?)?
        )),
        "bad-node" => Err(format!(
            "the .krf analysis hit an unknown node kind `{}` — the injected stream \
             is malformed (a harness defect, never a source defect)",
            krf_name(elems[2], heap)?
        )),
        other => Err(format!("unknown analysis rejection kind `{other}`")),
    }
}

// ---------- the case driver ----------

/// Run one CP-parity case from source text: three-layer split,
/// oracle verdict, dual-engine `.krf` run, and the two-axis
/// comparison.
pub fn compiler_parity(case: &str, source: &str) -> CompilerParityReport {
    compiler_parity_with(case, source, COMPILER_SOURCE)
}

/// The parameterized face (tests may pass a tampered compiler
/// source to prove the drift detector actually detects).
pub fn compiler_parity_with(
    case: &str,
    source: &str,
    compiler_source: &str,
) -> CompilerParityReport {
    // Layer 1 — the reader (single source) rejected the input.
    let forms = match read_program(FileId(0), source) {
        Err(err) => {
            return CompilerParityReport {
                case: case.to_string(),
                layer: CompilerParityLayer::Reader,
                oracle: err.to_string(),
                krf: None,
                engines_agree: true,
                matched: true,
                drift: None,
            };
        }
        Ok(forms) => forms,
    };
    // Layer 2 — the expander or loader rejected the input: no
    // expanded tree exists to analyze (the 1.6/1.7 harnesses own
    // that face).
    let items = match expand_program(&forms) {
        Err(err) => {
            return CompilerParityReport {
                case: case.to_string(),
                layer: CompilerParityLayer::Expander,
                oracle: err.to_string(),
                krf: None,
                engines_agree: true,
                matched: true,
                drift: None,
            };
        }
        Ok(items) => match load_program(&items) {
            Err(err) => {
                return CompilerParityReport {
                    case: case.to_string(),
                    layer: CompilerParityLayer::Expander,
                    oracle: err.to_string(),
                    krf: None,
                    engines_agree: true,
                    matched: true,
                    drift: None,
                };
            }
            Ok(_) => items,
        },
    };
    compiler_parity_items_with(case, &items, compiler_source)
}

/// The pre-expanded face (hand-built `ModuleItem` trees — the
/// depth-mirror boundary rides here; the reader's 256 nesting cap
/// keeps textual sources far below the compile depth limit).
pub fn compiler_parity_items(case: &str, items: &[ModuleItem]) -> CompilerParityReport {
    compiler_parity_items_with(case, items, COMPILER_SOURCE)
}

/// The VM-only face (the registered input-envelope boundary): the
/// eval engine's 2048-call depth cap sits BELOW the compile depth
/// limit over the stream assembler's ~2-frames-per-level recursion,
/// so trees deeper than ~1000 levels exceed the eval engine's
/// budget (the honest `harness limit` classification, the r74
/// lineage). The VM has no frame-depth cap — this face drives the
/// assembled analysis through the VM alone, which keeps the
/// 1024/1025 depth mirror fully testable against the oracle.
pub fn compiler_parity_items_vm(case: &str, items: &[ModuleItem]) -> CompilerParityReport {
    let layer = CompilerParityLayer::Compiler;
    let oracle_text = match compile_program(items) {
        Ok(bc) => oracle_analysis_dump(&bc),
        Err(err) => cp_error_key(&err),
    };
    let prefix = items_stream_prefix(items);
    let assembled = format!("{prefix}\n{}", COMPILER_SOURCE);
    let verdict = match run_vm_only(&assembled) {
        Ok(v) => v,
        Err(harness) => {
            return CompilerParityReport {
                case: case.to_string(),
                layer,
                oracle: oracle_text,
                krf: None,
                engines_agree: false,
                matched: false,
                drift: Some(harness),
            };
        }
    };
    let krf_text = verdict.text();
    let matched = krf_text == oracle_text;
    let drift = if matched {
        None
    } else {
        Some(format!("oracle `{oracle_text}` vs krf `{krf_text}`"))
    };
    CompilerParityReport {
        case: case.to_string(),
        layer,
        oracle: oracle_text,
        krf: Some(krf_text),
        // The single-engine face: agreement is vacuous (the eval
        // engine's envelope is the registered limit this face
        // exists to route around).
        engines_agree: true,
        matched,
        drift,
    }
}

/// Run the assembled harness program through the VM alone (the
/// same composition as `drive_dual_engines`' vm half — the
/// single-source lineage; the eval half is the half this face
/// routes around, so the composition stays local and mirrors the
/// r74 classification prefixes exactly).
fn run_vm_only(assembled: &str) -> Result<KrfVerdict<CompileError>, String> {
    let mut session = Session::new();
    let program =
        pipeline::parse(&mut session, "compiler-parity-host", assembled).map_err(|diags| {
            format!("harness defect: the assembled compiler program failed to parse: {diags:?}")
        })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled compiler program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled compiler program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the compiler program: {err}"))?;
    vm.run().map_err(|err| vm_harness_failure(&err))?;
    let value = vm
        .global("result")
        .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
    decode_verdict_vm(value, vm.heap()).map_err(|err| format!("harness defect: {err}"))
}

fn vm_harness_failure(err: &RuntimeError) -> String {
    if matches!(err, RuntimeError::BudgetExceeded { .. }) {
        format!(
            "harness limit: the .krf compiler exceeded the vm engine's budget ({err}) — the \
             frozen subset's per-element recursion gives the harness a finite input envelope; \
             not a semantic drift"
        )
    } else {
        format!("harness defect: the .krf compiler crashed on the vm engine: {err}")
    }
}

fn decode_verdict_vm(value: &Value, heap: &Heap) -> Result<KrfVerdict<CompileError>, String> {
    decode_tagged(value, heap, dump_krf_section, rebuild_compile_error)
}

fn compiler_parity_items_with(
    case: &str,
    items: &[ModuleItem],
    compiler_source: &str,
) -> CompilerParityReport {
    let layer = CompilerParityLayer::Compiler;
    // The oracle: the Rust compile-time analysis itself.
    let oracle_text = match compile_program(items) {
        Ok(bc) => oracle_analysis_dump(&bc),
        Err(err) => cp_error_key(&err),
    };
    let prefix = items_stream_prefix(items);
    let assembled = format!("{prefix}\n{compiler_source}");
    let decode = |value: &Value, heap: &Heap| -> Result<KrfVerdict<CompileError>, String> {
        decode_tagged(value, heap, dump_krf_section, rebuild_compile_error)
    };
    let (vm_verdict, eval_verdict) = match drive_dual_engines(
        "compiler-parity-host",
        "compiler",
        &assembled,
        decode,
        decode,
    ) {
        Ok(v) => v,
        Err(harness) => {
            // r74: the harness string carries its own classification
            // ("harness defect: …" / "harness limit: …") — single
            // source, never re-prefixed here.
            return CompilerParityReport {
                case: case.to_string(),
                layer,
                oracle: oracle_text,
                krf: None,
                engines_agree: false,
                matched: false,
                drift: Some(harness),
            };
        }
    };
    let krf_text = vm_verdict.text();
    let eval_text = eval_verdict.text();
    let engines_agree = krf_text == eval_text;
    let matched = engines_agree && krf_text == oracle_text;
    let drift = if matched {
        None
    } else if !engines_agree {
        Some(format!(
            "engine disagreement: vm `{krf_text}` vs eval `{eval_text}` (oracle \
             `{oracle_text}`)"
        ))
    } else {
        Some(format!("oracle `{oracle_text}` vs krf `{krf_text}`"))
    };
    CompilerParityReport {
        case: case.to_string(),
        layer,
        oracle: oracle_text,
        krf: Some(krf_text),
        engines_agree,
        matched,
        drift,
    }
}

# compiler-parity.md — Stage 2.3 CP 两 Pass 测试文档（v0.53.0 · r83）

> 依据：docs/stage0.md §9.83（CP-1..CP-7）+ §9.84（CP8 发射轴——r83 第二 Pass）+ stage-2-plan §2 行 2.3 + docs/tests/README.md 双向印证表纪律。
> 被测面：`selfhost/v1/compiler.krf`（第四 selfhost 件——词法域分析 + 指令发射两 Pass，1221 行）vs Rust oracle `kerf_compiler::compile_program` 分析产品**与指令流**（proto 乘积七字段：caps/code/dbg）。

## 1. 目标

编译期纯函数面（作用域栈/innermost 查找/LA-1 三叉/LA-4 传递捕获/first-use 驻留/深度镜像）的 .krf 重写与 Rust oracle 逐字节 parity——fixpoint 窗 A 阶段第一 Pass（K196 translation-validation 形制：逐产品族事后检查）。

## 2. 场景族（CP1-CP8 ↔ compiler_parity_tests.rs 三十测试）

| 族 | 测试 | 场景 | 统计 |
|----|------|------|------|
| CP1 三层路由 | corpus_directory_*（deep_stack）+ reader_and_expander_layers_* | 85 案全扫：reader 8 / expander 19 / compiler 58 三向钉扎；路由回归即败 | 混合 sweep（含负 27） |
| CP2 产品轴锚 | scope_stack_* + innermost_shadowing_* + flat_capture_* + transitive_* | 槽复用/峰 n_locals、遮蔽槽同一性、捕获 first-use 序、LA-4 传递链四 proto 逐字段 | 正 8 |
| CP3 驻留与恒等 | first_use_order_* + const_identity_* | define 值先行名后 intern、builtin global 回退、NaN 折叠 ±0.0 相异（手建树） | 正 3 |
| CP4 错误轴 | assign_boundary_three_ways_* + depth_mirror_* | assign 三叉（local/global/captured——LA-7 编译侧精确载荷）；深度镜像 1024 恰过/1025 拒 + eval 包络分类钉扎 | 正 3 + 负 3 |
| CP5 零分析与效应 | module_defsyn_* + perform_and_handle_* | defsyn/require 零分析、module 子项序、perform/handle intern 序与 handler proto | 正 2 |
| CP6 自应用 | selfhost_fixed_point_* + selfhost_front_end_* | 第四次自应用（compiler.krf 分析自身——宿主尾剥离）+ 前端三源 | 正 3 |
| CP7 漂移自检 | tampered_* ×2 + nested_pair_litvals_* | tamper-globals 操作数与驻留双面漂移（`load-global` 0 替 intern 锚）、tamper-badnode 流词汇表破裂 → harness defect、嵌套 pair 字面量回归（恢复核验发现的永久钉扎） | 负 3 |
| CP8 发射轴（r83） | cp8_* 十三测试 | 尾位终结符契约（无合流跳转）、非尾合流跳转与双补靶、求值序 args→callee、let 槽位生命周期、assign dup 形、perform 操作数形状（a=global idx b=argc）、handler 安装序与 pop 计数、稠密 debug 表（手建 fixture span）、零码锚点 halt（define-syntax 零码路径）、闭包协议索引（closure idx + load-captured k）、常量槽位同一性（重复字面量共享 push-const 操作数）、pair 常量与内建调用流、码轴篡改探针（`cp-patch jf (cp-here)` 锚——补靶篡改 oracle-vs-krf 漂移） | 正 12 + 负 1 |

## 3. 依赖与挂载

- `tests/runner.rs` `#[path]` 挂载；`deep_stack`（768MB 线程栈）包裹 sweep/深度/自应用四测（r74/BST-1 谱系）。
- 消费 `kerf::driver::{COMPILER_SOURCE, compiler_parity, compiler_parity_with, compiler_parity_items, compiler_parity_items_vm}`（§9.74 PAR-1 单源谱系第四前端）。
- audit X 节 X01-X10 + **Y 节 Y01-Y10**（r83 发射族——A-Y 二十四节 230/230）端到端复行使（examples/audit/stage0_gate_audit_r1.rs）。
- CP6 自应用断言扩展：code/dbg 段 ≥40（第五次自应用——码轴全 proto 逐字节）。

## 4. 覆盖率与诚实边界

- 逐臂镜像保真面（compile.rs 对照核验清单）：见 §9.83.3——八项顺序纪律逐一对齐（Var 三叉/Apply args-then-func/Let 值先行/Perform·Handle intern 序/Define 值先行/fn-in-define 解构/死槽归还序/参数内层胜）。
- **eval 输入包络**（登记态）：2048 调深帽 < 编译深帽在流装配器 ~2 帧/层递归上的可达面——深度边界走 VM-only 面（`compiler_parity_items_vm`），双引擎面在该深度返回 harness limit 分类（测试钉扎措辞与位点）。
- **typecheck 层永不决断 CP 案例**：E 族负案（含 neg-057 E0012 孪生）走 Compiler 层——分析产品在检查器拒绝的树上良定义。
- **span 比较面 = 偏移对**（parity 族约定）：dbg 乘积按 (s e) 比较——展开 id 留在比较文本外（1.6/1.7 面所有）；K202 行表共享编码形态显式不采（稠密形态 = 全 span 逐位差分优先）。
- 零 DEFERRED / 零 UNTESTED。

# selfhost/ — 冻结子集自承载前端（bootstrap chain）

按 Stage 1.5/1.6/1.7 三段承载 + **Stage 2.3 CP 两 Pass**：**用冻结子集自己写前端与编译期纯函数面**，与 Rust oracle 引擎做双引擎 parity（逐字节一致由构造保证——双侧同经 Rust `Display` 渲染）。设计文档 `docs/stage0.md` §9.46-§9.48（RS/EX/MX 三裁定族）+ §9.83（CP 第一 Pass）+ §9.84（CP 第二 Pass——发射域）。

## 四件清单

| 文件 | 层 | 行数 | 职责 |
|---|---|---|---|
| `v1/reader.krf` | 1.5 结构层 | 117 | token 表 → Stx 树（迭代式 rd-loop，REC-A option-3 谱系） |
| `v1/expander.krf` | 1.6 展开层 | 750 | 平坦先序流 → ModuleItem 树（单自递归 + 七合成节点模式） |
| `v1/macro.krf` | 1.7 宏层 | 660 | syntax-rules 纯函数库（无驱动 define；与 expander 装配成一体） |
| `v1/compiler.krf` | 2.3 CP 两 Pass | 1221 | 编译器编译期纯函数面全量：第一 Pass 词法域分析（作用域栈/最深内层查找/LA-1 三叉/LA-4 传递捕获/first-use 驻留/空闲槽 LIFO）+ 第二 Pass 指令发射（emit 单径/操作码 pop-push 表/跳转占位-回填/深度簿记/尾位终结符契约/稠密 debug_info 表/终化排空）——产品对拍 compile.rs 的分析表与指令流 |

> 前三行行为 v0.48.0（r78 格式整理轮）后口径；compiler.krf 第一 Pass 为 v0.52.0（r82）首录、第二 Pass 为 v0.53.0（r83 发射域轮）扩录。

## 宿主约定（hosting convention）

- **1.5**（§9.46.4 RS-1）：宿主跑 Rust lexer（token 唯一真值源），在源前注入 `(define tokens (quote (record ...)))`；字节偏移以十进制字符串不透明携带。
- **1.6/1.7**（§9.47.4 EX-1）：宿主跑 Rust reader，注入平坦先序流 `(define forms (quote (record ...)))`；`"list"` 记录携带子数 n，深度恒在 reader 256 帽内。
- **2.3 CP**（§9.83 CP-1）：宿主跑 Rust reader **与 Rust expander**（两层树真值源），注入**展开后**项树平坦先序流 `(define items (quote (record ...)))`；变元记录携带子数，空参数表以 `nil` 携带（裸 `()` 是读错误——空应用）。
- 终态：源尾 `(define result ...)` 绑定 `("ok" ...)` 或结构化 `("err" kind payload...)`——宿主重建同型错误并经同一 `Display` 渲染，parity 构造性透明；CP 段的可达拒绝族 = `assign-to-captured`（LA-7 编译侧）+ `depth`（1024/1025 镜像），第二 Pass 增发射防御族 `stack-underflow`/`stack-imbalance`/`unpatched-jump`（仅破损发射器可达——可读漂移面）与 `bad-patch`/`bad-node`（harness 缺陷类），双引擎同跑，eval 输入包络（2048 调深 < 编译深帽）以 VM-only 面承载（r74 分类谱系）。

## 装配契约（MX-2）

`macro.krf` 是纯函数库（无 driver define）：宿主将 **macro.krf 函数体拼在 expander.krf 函数体之前**装配为单一程序；expander 在 define-syntax 声明分支（`ex-macro-define`）与宏使用分派点（`ex-macro-resolve` + `ex-macro-use`）调入。未装配时 expander 单独可跑其非宏语料（自身源无 define-syntax）。

## 消费面（谁读这四件）

| 消费者 | 位置 | 形态 |
|---|---|---|
| parity harness | `crates/kerf-driver/src/reader_parity.rs` / `expander_parity.rs` / `compiler_parity.rs` | `include_str!` ×4（编译期嵌入） |
| 语料测试 | `tests/v1/stage1/plan/reader_parity_tests.rs`（19）/ `expander_parity_tests.rs`（30）/ `compiler_parity_tests.rs`（30——CP1-CP7 + CP8 发射轴 13 件，r83） | 双引擎对比 + 自举定点（selfhost 读自身源） |
| 确定性守卫 | `tests/v1/stage1/plan/determinism_guard_tests.rs`（7） | 装配源双遍历恒等 |
| 门 B 轴 | expander_parity 的 `gate_b_bytecode` | 自举源字节码逐位一致 |
| audit X 节 | `examples/audit/stage0_gate_audit_r1.rs`（X01-X10） | CP 段十案例端到端 |
| 格式守卫 | `tests/v1/stage1/plan/selfhost_format_guard_tests.rs` | 本目录四件格式约定机检（见下） |

**敏感锚（改动前必读）**：四条 tamper 探针串以**连续子串**形式被测试断言（拆行不得插入锚内）：`(cons "empty-app" (cons (rd-fr-open (car stack)) nil))`、`(>= ex-depth 512)`、`(cons (ex-s nt) (cons (ex-e nt) nil))`、`(set! ex-mcount 0)`；compiler.krf 现三锚（r83 发射域轮更新）：`(cp-emit "load-global" (cp-intern-global name) 0 (cp-span-of t))`（tamper-globals 漂移探针——操作数与驻留双面）与 `(eq? tag "var")` 后随 `(let`（bad-node fail-closed 探针）与 `(cp-patch jf (cp-here))`（cp8-tamper-patch 码轴漂移探针）。注释/空白改动对 parity 零影响（非 token）；**任何 token 级改动必须整轮 parity 复验**。

## 格式约定（v0.48.0 / r78 起，机检锁定）

1. **行宽 ≤ 100 列**（SOP §10.5「~100 列内」；与 rustfmt `max_width = 100` 同源——`.krf` 层并入仓库统一约定）。
2. **注释非 ASCII 白名单 = {`—`, `§`}**：旁注破折号一律 em-dash（仓库 122 个 Rust 文件的既有主导风格）；`§X.Y` 技术锚原样保留（SOP §10.5 规则 2）。零 ` - ` / `  -  ` ASCII 旁注破折号（r78 前的 1.6/1.7 著作期痕迹，已全量归一）。
3. **断行风格**：macro 用 +1 缩进（`(<head>` 单独行、子形式每行 +1）；reader/expander 用参数对齐（后续参数对齐首参列）——各自沿袭文件主导手工风格。
4. 工具：`tools/selfhost/krf_reformat.py`（空白级重排 + `--check` 本地预检；文档 `docs/tools/selfhost/krf-reformat.md`）；CI 面 = 上表格式守卫三断言。

## 诚实边界（沿袭登记）

- **MX-1**：子集无字符串构造——改名产物以 `("mangled" s e base counter gen)` 结构化记录发射，宿主解码为 `{base}__macro_{counter}` 对拍（决策面 parity，渲染留宿主侧）；Rust `fresh_name` 的触发规避环**不镜像**（需候选串）——携带字面 `x__macro_N` 符号的源会漂移并被捕获（plan-1.7.md §5）。
- **float 载荷**：inf/NaN 无 `.krf` 字面形——一切浮点以 Debug 文本串携带（宿主侧解析精确）。
- **宏层分流**：携带 define-syntax 的源由 harness 路由至宏层（§9.47.4 EX-3）；expander 的 `"macro-layer"` 错误臂不可达但 fail-closed 保留——路由缺陷以漂移形式显形。
- **VM 永久 Rust 基座**（宪制排除项）：本目录是自举**前端**链；VM 重写不在任何计划内（SOP §2.2 原则 41/53）。

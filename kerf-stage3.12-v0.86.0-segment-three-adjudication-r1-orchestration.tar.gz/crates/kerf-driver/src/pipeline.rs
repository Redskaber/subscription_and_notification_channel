//! Pipeline orchestration — the Layer 8 charter (stage-0-plan row
//! 0.8): `read -> expand -> typecheck -> {compile -> VM, eval}` with
//! a single diagnostic collection point per stage (the Stage 1.1
//! wiring inserts the conservative static checker between expand and
//! both engines — stage-1-plan §2 row 1.1).
//!
//! Errors are data, not exceptions (§12.2): every stage failure maps
//! to a [`Diagnostic`] through the stage error's own position
//! accessor; callers collect them across files and render in one
//! pass. The dual-engine face (`Engine::Vm` / `Engine::Eval`) drives
//! both execution paths over the *same* expanded program — the
//! divergence point is `Vec<ModuleItem>`, exactly as the 0.7
//! cross-check established — and [`run_parity`] compares the two
//! results structurally via `parity_repr` (the driver reports a
//! divergence as data; the panicking `assert_parity` remains the
//! test-side one-liner face).
//!
//! Checker semantics (Stage 1.1, disclosed):
//! - **Error-level findings abort before execution** — a definite
//!   error (R1-R7) means the program cannot behave as written, so
//!   neither engine runs it; that early stop is the checker's net
//!   new value over the runtime-only errors it subsumes.
//! - **Warning-level findings never block** — R8 lands in the
//!   outcome's `warnings` channel (`RunOutcome`, `CheckOutcome`,
//!   `ParityReport`); the caller prints them and the program runs
//!   exactly as before (§2.3-4: report over silence, at the
//!   non-blocking level).
//! - Collection never short-circuits: the checker walks the whole
//!   program, and compile-stage diagnostics (when the checker
//!   passed but the compiler still fails) are appended to the same
//!   batch before the abort decision is made.

use kerf_core::ModuleItem;
use kerf_runtime::Evaluator;
use kerf_runtime::parity_repr;
use kerf_span::{FileId, Symbol};
use kerf_vm::{BufferIo, Value, Vm, VmIo};

use crate::diagnostic::Diagnostic;
use crate::diagnostic::Severity;

/// Which execution engine drives the expanded program.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Engine {
    /// `compile_program` -> `Vm` (bytecode path).
    Vm,
    /// `Evaluator::eval_program` (meta-circular path).
    Eval,
}

impl std::fmt::Display for Engine {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Engine::Vm => "vm",
            Engine::Eval => "eval",
        };
        f.write_str(s)
    }
}

/// The driver's Externals table for the checker — the third
/// consumption site of the single-source pair (stage-1-plan §4):
/// names from `kerf_expander::STAGE0_GLOBALS`, arities from
/// `kerf_vm::Builtin::ALL` triples. The driver never copies the
/// lists (the checker's own doc rule; this is the same construction
/// the root integration tests and the audit use).
/// The external-name face's authoritative sources: the builtins plus
/// the program's own extern declarations (W-3.2 — the third source;
/// extern call sites get checker arity analysis through the same
/// three-valued face). Recursive over items for totality (the
/// expander's top-level-only ruling means nested walks find none).
fn pipeline_externals(items: &[ModuleItem]) -> kerf_typecheck::Externals {
    let mut externals = kerf_typecheck::Externals::from_named_arities(
        kerf_vm::Builtin::ALL
            .iter()
            .map(|(_, name, arity)| (*name, Some(*arity))),
    );
    fn insert_externs(items: &[ModuleItem], externals: &mut kerf_typecheck::Externals) {
        for item in items {
            match item {
                ModuleItem::Extern { items, .. } => {
                    for entry in items {
                        externals.insert(&entry.name, Some(entry.params.len() as u32));
                    }
                }
                ModuleItem::Module { items, .. } => insert_externs(items, externals),
                _ => {}
            }
        }
    }
    insert_externs(items, &mut externals);
    externals
}

/// Split a collected diagnostic batch: any Error-level finding
/// aborts (returns the whole batch); a warning-only batch passes the
/// warnings through to the caller.
fn split_warnings(diags: Vec<Diagnostic>) -> Result<Vec<Diagnostic>, Vec<Diagnostic>> {
    if diags.iter().any(|d| d.severity == Severity::Error) {
        Err(diags)
    } else {
        Ok(diags)
    }
}

/// A read-and-expanded program, ready to check or run.
#[derive(Debug, Clone)]
pub struct ParsedProgram {
    /// The interned file the items came from (diagnostics attribute
    /// here when the producing error carries no position of its own).
    pub file: FileId,
    pub items: Vec<ModuleItem>,
    /// The reader face the source was parsed on — the run-time
    /// diagnostic pass renders canonical names verbatim on the
    /// S-expr face and skin-mapped spellings on the target face
    /// (§9.96 skin/skeleton separation; r108 FIX-1).
    pub face: ReaderFace,
    /// The host-injected global names (W-3.12 injection channel):
    /// empty on the ordinary parse paths; a parse WITH injected
    /// names checks WITH them (the checker's externals face extends
    /// — a host-bound name is external to the program, unknown
    /// arity: a value, not a callable). The compile side is
    /// unaffected (free references were always late-bound
    /// load-globals); a host that forgets the run-time bind still
    /// meets `UnboundGlobal` fail-closed.
    pub injected: Vec<kerf_span::Symbol>,
}

/// What a successful `check` reports about the compiled product
/// (plus the checker's warning-level findings — never blocking).
/// Not `Copy` since Stage 1.1: the warnings vector owns its payloads.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CheckOutcome {
    pub func_count: usize,
    pub instr_count: usize,
    pub const_count: usize,
    pub global_count: usize,
    /// Warning-level checker findings (empty when the checker had
    /// nothing to say).
    pub warnings: Vec<Diagnostic>,
}

/// What a successful `emit-c` reports (Stage 2.6, stage0.md §9.92):
/// the self-contained C translation unit plus the never-blocking
/// warning channel — the same shape contract as `check`/`run`, so
/// the CLI face stays uniform across the three commands.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EmitCOutcome {
    /// The generated C source (one translation unit: embedded
    /// runtime shim + program data + `main`).
    pub c_source: String,
    /// Warning-level checker findings (never blocking).
    pub warnings: Vec<Diagnostic>,
}

/// What a successful run reports: the final value, every written
/// output line, a snapshot of the program globals at halt (the
/// REPL's expression-value channel — a bare expression is wrapped
/// into a define, and its value is read back from this table),
/// which engine produced them, and the checker's warning-level
/// findings (R8 lands here — never blocking).
#[derive(Debug, Clone, PartialEq)]
pub struct RunOutcome {
    pub engine: Engine,
    pub value: Value,
    pub outputs: Vec<String>,
    /// The halt snapshot as (interned identity, value) pairs (§9.67
    /// NB-7 — keys ride the single pool; which names appear follows
    /// the §9.60.5 dual contract, unchanged).
    pub globals: Vec<(Symbol, Value)>,
    /// Warning-level checker findings for this program (empty when
    /// the checker had nothing to say).
    pub warnings: Vec<Diagnostic>,
}

impl RunOutcome {
    /// The human-facing value form (context-free `Display`: heap
    /// references render opaquely — structural inspection is the
    /// parity tooling's job, see `run_parity`).
    pub fn value_display(&self) -> String {
        self.value.to_string()
    }

    /// Look a global up in the halt snapshot (the REPL reads its
    /// `$repl:N` wrappers through this face — §9.67 NB-7: the text
    /// face stays a scan so a miss query never pollutes the pool).
    pub fn global(&self, name: &str) -> Option<&Value> {
        self.globals
            .iter()
            .find(|(n, _)| n.as_str() == name)
            .map(|(_, v)| v)
    }

    /// Look a global up by its interned identity (§9.67 NB-7 — the
    /// identity face for callers that hold pool entries).
    pub fn global_sym(&self, name: &Symbol) -> Option<&Value> {
        self.globals.iter().find(|(n, _)| n == name).map(|(_, v)| v)
    }
}
/// The dual-engine parity report for one program (plus the
/// checker's warning-level findings — collected before either
/// engine ran).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParityReport {
    /// Structural repr of the VM result.
    pub vm_repr: String,
    /// Structural repr of the eval result.
    pub eval_repr: String,
    /// Whether the two engines agreed on the program result.
    pub values_agree: bool,
    /// Whether both engines produced the same output lines.
    pub outputs_agree: bool,
    /// Whether both engines stored structurally equal values for
    /// every define name (the module-namespace observation face the
    /// 0.7 cross-check used).
    pub globals_agree: bool,
    /// The structural repr of every define's halt value (the VM
    /// side; the eval side agreed — `globals_agree` — so one column
    /// is the shared truth), in program order. The Stage 1.4
    /// parity contract reads the *last* entry as the module's
    /// observable result (the value convention of subset-spec.md).
    pub globals_repr: Vec<(String, String)>,
    /// Warning-level checker findings (never blocking; Error-level
    /// findings abort the parity run before either engine starts).
    pub warnings: Vec<Diagnostic>,
}

impl ParityReport {
    /// Whether the whole parity contract holds.
    pub fn agrees(&self) -> bool {
        self.values_agree && self.outputs_agree && self.globals_agree
    }
}

/// Which front-end reader face parses the source text — the
/// production-bridge axis (switch-window-plan §1 step 4): the
/// S-expression seed chain and the target-skin chain share ONE
/// expand/load/typecheck pipeline, diverging only at the read step
/// (the two readers produce the same `Stx` tree family from their
/// two source skins — §9.25.4's parity contract is what makes the
/// shared spine sound).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReaderFace {
    /// `kerf_reader::read_program` — the S-expression skin (the
    /// seed chain, `.krf`).
    Sexpr,
    /// `kerf_reader::read_target_program` — the target skin (the
    /// production bridge, `.ktf`; the step-4 bootstrap face).
    Target,
}

impl ReaderFace {
    /// The path-derived default (r106 FIX-3): a `.ktf` suffix selects
    /// the target skin, anything else the S-expression seed chain —
    /// the extension is the production bridge's reachability signal
    /// (rustc `--edition` / gcc `-x` precedent: an explicit flag beats
    /// the default, and the default needs no flag at all).
    pub fn for_path(path: &str) -> ReaderFace {
        if path.ends_with(".ktf") {
            ReaderFace::Target
        } else {
            ReaderFace::Sexpr
        }
    }
}

/// Intern + read + expand one source text. The read error is
/// attributed to the freshly interned file; expand errors carry
/// their own spans.
pub fn parse(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
) -> Result<ParsedProgram, Vec<Diagnostic>> {
    parse_with(session, name, source, ReaderFace::Sexpr)
}

/// The target-skin twin of [`parse`] (switch-window-plan §1 step 4 —
/// the production bridge's front end): the same intern → read →
/// expand → load spine over `read_target_program`, so the bootstrap
/// chain's front half rides the NEW reader end to end.
pub fn parse_target(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
) -> Result<ParsedProgram, Vec<Diagnostic>> {
    parse_with(session, name, source, ReaderFace::Target)
}

/// The W-3.12 injection channel's front-end face: [`parse_target`]
/// with host-declared injected global names — the expansion accepts
/// them as globals (the extern-names precedent), the compiler emits
/// load-global, and the host binds the slots before the run (the
/// steady-state bootstrap chain's entry).
pub fn parse_target_with_injected(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    injected: &[kerf_span::Symbol],
) -> Result<ParsedProgram, Vec<Diagnostic>> {
    let file = session.intern(name, source);
    match kerf_reader::read_target_program(file, source) {
        Err(err) => Err(vec![Diagnostic::from_read(&err, file)]),
        Ok(forms) => match kerf_expander::expand_program_with_injected(&forms, injected) {
            Err(err) => Err(vec![Diagnostic::from_expand(&err, ReaderFace::Target)]),
            Ok(items) => match kerf_expander::load_program(&items) {
                Err(err) => Err(vec![Diagnostic::from_module(&err, ReaderFace::Target)]),
                Ok(_) => Ok(ParsedProgram {
                    file,
                    items,
                    face: ReaderFace::Target,
                    injected: injected.to_vec(),
                }),
            },
        },
    }
}

pub(crate) fn parse_with(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    face: ReaderFace,
) -> Result<ParsedProgram, Vec<Diagnostic>> {
    let file = session.intern(name, source);
    let read = match face {
        ReaderFace::Sexpr => kerf_reader::read_program,
        ReaderFace::Target => kerf_reader::read_target_program,
    };
    match read(file, source) {
        Err(err) => Err(vec![Diagnostic::from_read(&err, file)]),
        Ok(forms) => match kerf_expander::expand_program(&forms) {
            Err(err) => Err(vec![Diagnostic::from_expand(&err, face)]),
            Ok(items) => {
                // Sub-stage 0.9: validate the declaration graph (module
                // cycles, missing and duplicate declarations) at parse
                // time — one structured diagnostic per failure, the
                // §7.1.1 class 7 face.
                match kerf_expander::load_program(&items) {
                    Err(err) => Err(vec![Diagnostic::from_module(&err, face)]),
                    Ok(_) => Ok(ParsedProgram {
                        file,
                        items,
                        face,
                        injected: Vec::new(),
                    }),
                }
            }
        },
    }
}

impl ParsedProgram {
    /// Run both static layers over the expanded items and return
    /// *all* findings — both severities — as driver diagnostics; the
    /// caller decides the abort semantics.
    ///
    /// Stage 1.1 wired the conservative rules (R1-R8, `check_module`).
    /// Stage 1.8 wires the HM inference layer on top (the plan-1.3
    /// "driver HM-level wiring = 1.8 agenda", stage0.md §9.49.5
    /// GATE-2): `infer_module` runs in the same batch — multi-error
    /// collection never short-circuits (ruling 21). Severity keeps
    /// the soft-typing contract (§9.44.4; K37): E0009/E0010 are
    /// definite errors and block through the existing severity
    /// split, E0011 (inference budget — a checker limitation, not a
    /// program error) stays a warning and never blocks. The typed
    /// program itself (Layer 2 `TypedExpr`) is a Stage 2+ consumer
    /// face; this wiring surfaces the diagnosis channel only.
    pub fn typecheck(&self) -> Vec<Diagnostic> {
        let mut externals = pipeline_externals(&self.items);
        // The W-3.12 injection channel's checking face: a host-bound
        // name is external to the program (unknown arity — a value,
        // not a callable), so R1 accepts the reference and the
        // run-time bind remains the only delivery face.
        for name in &self.injected {
            externals.insert(name, None);
        }
        let mut diags: Vec<Diagnostic> = kerf_typecheck::check_module(&self.items, &externals)
            .iter()
            .map(|td| Diagnostic::from_typecheck(td, self.face))
            .collect();
        let inference = kerf_typecheck::infer_module(&self.items, &externals);
        diags.extend(
            inference
                .diagnostics
                .iter()
                .map(|td| Diagnostic::from_typecheck(td, self.face)),
        );
        diags
    }

    /// Compile and verify without executing (the `check` face). The
    /// checker runs between expand and compile: Error-level findings
    /// abort (with the compile batch appended when the compiler also
    /// fails — collection never short-circuits), warning-level
    /// findings ride along on the outcome.
    pub fn check(&self) -> Result<CheckOutcome, Vec<Diagnostic>> {
        let mut diags = self.typecheck();
        let compiled = kerf_compiler::compile_program(&self.items);
        let bc = match compiled {
            Err(err) => {
                diags.push(Diagnostic::from_compile(&err, self.file, self.face));
                return Err(diags);
            }
            Ok(bc) => bc,
        };
        if let Err(err) = bc.verify() {
            diags.push(Diagnostic::from_compile(&err, self.file, self.face));
            return Err(diags);
        }
        let warnings = split_warnings(diags)?;
        Ok(CheckOutcome {
            func_count: bc.funcs.len(),
            instr_count: bc.funcs.iter().map(|f| f.code.len()).sum(),
            const_count: bc.consts.len(),
            global_count: bc.globals.len(),
            warnings,
        })
    }

    /// Compile, verify, and transpile to C (the `emit-c` face — the
    /// Stage 2.6 chain-external backend). Mirrors [`Self::check`]
    /// exactly through the compile+verify steps, then hands the
    /// verified product to `kerf_cbackend::emit_c`; emitter refusals
    /// (the two transpilation-shaped structural guards) map into
    /// the same diagnostic batch.
    pub fn c_source(&self) -> Result<EmitCOutcome, Vec<Diagnostic>> {
        let mut diags = self.typecheck();
        let bc = match kerf_compiler::compile_program(&self.items) {
            Err(err) => {
                diags.push(Diagnostic::from_compile(&err, self.file, self.face));
                return Err(diags);
            }
            Ok(bc) => bc,
        };
        if let Err(err) = bc.verify() {
            diags.push(Diagnostic::from_compile(&err, self.file, self.face));
            return Err(diags);
        }
        let c_source = match kerf_cbackend::emit_c(&bc) {
            Err(err) => {
                diags.push(Diagnostic::from_emit(&err, self.file));
                return Err(diags);
            }
            Ok(c) => c,
        };
        let warnings = split_warnings(diags)?;
        Ok(EmitCOutcome { c_source, warnings })
    }

    /// Run on one engine with a caller-provided I/O face (the REPL
    /// passes its replay tape; batch callers pass a seeded
    /// [`BufferIo`]). The checker runs first: Error-level findings
    /// abort before either engine starts; warnings ride along.
    ///
    /// The two engine branches snapshot different rosters **by
    /// contract, not by drift**: the VM branch reports the full
    /// global table (`bc.globals` — every name the bytecode can
    /// reach: builtins referenced by LoadGlobal, set! targets,
    /// effect names, and defines; the vs01-vs10 golden face), while
    /// the Eval branch walks the AST defines (the ve point-query
    /// face). The parity contract compares both engines over the
    /// AST define roster (`run_parity` below) — see stage0.md
    /// §9.60.5 for the ruling this comment anchors.
    pub fn run(&self, engine: Engine, io: Box<dyn VmIo>) -> Result<RunOutcome, Vec<Diagnostic>> {
        let warnings = split_warnings(self.typecheck())?;
        match engine {
            Engine::Vm => {
                let bc = kerf_compiler::compile_program(&self.items)
                    .map_err(|err| vec![Diagnostic::from_compile(&err, self.file, self.face)])?;
                let mut vm = Vm::with_io(bc, io)
                    .map_err(|err| vec![Diagnostic::from_compile(&err, self.file, self.face)])?;
                let value = vm
                    .run()
                    .map_err(|err| vec![Diagnostic::from_runtime(&err, self.face)])?;
                let outputs = vm.take_output();
                // §9.60.5 contract ①: the VM branch snapshots the
                // bytecode's global table (builtin reference names,
                // set! targets, effect names, defines — first-use
                // order). §9.67 NB-7: the keys stay pool entries —
                // no de-intern copy of the name roster.
                let globals = vm
                    .global_names()
                    .iter()
                    .filter_map(|name| vm.global_sym(name).map(|v| (name.clone(), v.clone())))
                    .collect();
                Ok(RunOutcome {
                    engine,
                    value,
                    outputs,
                    globals,
                    warnings,
                })
            }
            Engine::Eval => {
                let mut evaluator = Evaluator::with_io(io);
                let value = evaluator
                    .eval_program(&self.items)
                    .map_err(|err| vec![Diagnostic::from_runtime(&err, self.face)])?;
                let outputs = evaluator.take_output();
                // §9.60.5 contract ②: the eval branch snapshots the
                // Define roster (the AST face — `outcome.global`
                // point queries never depend on snapshot
                // completeness). §9.67 NB-7: the Define names are
                // already pool entries — no de-intern.
                let globals = self
                    .items
                    .iter()
                    .filter_map(|item| match item {
                        ModuleItem::Define { name, .. } => evaluator
                            .global_sym(name)
                            .map(|v| (name.clone(), v.clone())),
                        _ => None,
                    })
                    .collect();
                Ok(RunOutcome {
                    engine,
                    value,
                    outputs,
                    globals,
                    warnings,
                })
            }
        }
    }

    /// Run both engines over the same input lines and compare
    /// structurally. A divergence is *reported* (never a panic): the
    /// caller decides the exit semantics. Both engine handles stay
    /// alive through the comparison so `parity_repr` can resolve
    /// heap-backed values on both sides (the `run` face releases the
    /// engine; a repr without its heap would collapse every pair to
    /// the opaque `#<pair>` form and agree on structure it must
    /// not agree on).
    pub fn run_parity(&self, input_lines: &[String]) -> Result<ParityReport, Vec<Diagnostic>> {
        let warnings = split_warnings(self.typecheck())?;
        let bc = kerf_compiler::compile_program(&self.items)
            .map_err(|err| vec![Diagnostic::from_compile(&err, self.file, self.face)])?;
        let mut vm = Vm::with_io(
            bc,
            Box::new(BufferIo::with_input(input_lines.iter().cloned())),
        )
        .map_err(|err| vec![Diagnostic::from_compile(&err, self.file, self.face)])?;
        let vm_value = vm
            .run()
            .map_err(|err| vec![Diagnostic::from_runtime(&err, self.face)])?;
        let vm_outputs = vm.take_output();
        let vm_repr = parity_repr(&vm_value, vm.heap());

        let mut evaluator =
            Evaluator::with_io(Box::new(BufferIo::with_input(input_lines.iter().cloned())));
        let eval_value = evaluator
            .eval_program(&self.items)
            .map_err(|err| vec![Diagnostic::from_runtime(&err, self.face)])?;
        let eval_outputs = evaluator.take_output();
        let eval_repr = parity_repr(&eval_value, evaluator.heap());

        // Global-table comparison over the program's define names
        // (the module namespace — the 0.7 observation face; §9.60.5
        // contract ③). §9.67 NB-7: both engines resolve by interned
        // identity — the repr column stays text (the rendering
        // protocol face).
        let mut globals_agree = true;
        let mut globals_repr = Vec::new();
        for item in &self.items {
            if let ModuleItem::Define { name, .. } = item {
                let a = vm.global_sym(name).map(|v| parity_repr(v, vm.heap()));
                let b = evaluator
                    .global_sym(name)
                    .map(|v| parity_repr(v, evaluator.heap()));
                if a != b {
                    globals_agree = false;
                }
                if let Some(repr) = a {
                    globals_repr.push((name.as_str().to_owned(), repr));
                }
            }
        }

        let values_agree = vm_repr == eval_repr;
        Ok(ParityReport {
            vm_repr,
            eval_repr,
            values_agree,
            outputs_agree: vm_outputs == eval_outputs,
            globals_agree,
            globals_repr,
            warnings,
        })
    }
}

// One-shot helpers for batch callers (the CLI): parse + run/check on
// a session the caller owns. Each shape has one face-explicit core
// (`*_with`) and one S-expression-default convenience twin (the
// `parse`/`parse_target`/`parse_with` layering, applied one level
// up — r106 FIX-3 made the CLI's file commands reach the target
// skin, the production chain's only skin since the E5 teardown).

/// Intern, read, expand, then run on `engine` with seeded input.
pub fn run_source(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    engine: Engine,
    input_lines: &[String],
) -> Result<RunOutcome, Vec<Diagnostic>> {
    run_source_with(
        session,
        name,
        source,
        ReaderFace::Sexpr,
        engine,
        input_lines,
    )
}

/// The face-explicit core of [`run_source`].
pub fn run_source_with(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    face: ReaderFace,
    engine: Engine,
    input_lines: &[String],
) -> Result<RunOutcome, Vec<Diagnostic>> {
    let program = parse_with(session, name, source, face)?;
    program.run(
        engine,
        Box::new(BufferIo::with_input(input_lines.iter().cloned())),
    )
}

/// Intern, read, expand, compile, verify — no execution.
pub fn check_source(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
) -> Result<CheckOutcome, Vec<Diagnostic>> {
    check_source_with(session, name, source, ReaderFace::Sexpr)
}

/// The face-explicit core of [`check_source`].
pub fn check_source_with(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    face: ReaderFace,
) -> Result<CheckOutcome, Vec<Diagnostic>> {
    let program = parse_with(session, name, source, face)?;
    program.check()
}

/// Intern, read, expand, check, compile, verify, transpile to C
/// (the `emit-c` face — chain-external backend, warnings never
/// block).
pub fn emit_c_source(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
) -> Result<EmitCOutcome, Vec<Diagnostic>> {
    emit_c_source_with(session, name, source, ReaderFace::Sexpr)
}

/// The face-explicit core of [`emit_c_source`].
pub fn emit_c_source_with(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    face: ReaderFace,
) -> Result<EmitCOutcome, Vec<Diagnostic>> {
    let program = parse_with(session, name, source, face)?;
    program.c_source()
}

/// Intern, read, expand, run both engines, compare structurally.
pub fn run_parity_source(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    input_lines: &[String],
) -> Result<ParityReport, Vec<Diagnostic>> {
    run_parity_source_with(session, name, source, ReaderFace::Sexpr, input_lines)
}

/// The face-explicit core of [`run_parity_source`].
pub fn run_parity_source_with(
    session: &mut crate::session::Session,
    name: &str,
    source: &str,
    face: ReaderFace,
    input_lines: &[String],
) -> Result<ParityReport, Vec<Diagnostic>> {
    let program = parse_with(session, name, source, face)?;
    program.run_parity(input_lines)
}

#[cfg(test)]
mod tests {
    //! Pipeline tests (FP4): both engines end-to-end, parity agree and
    //! divergence-detection, check face, I/O faces, stage error
    //! attribution.

    use super::*;
    use crate::diagnostic::DiagnosticCode;
    use crate::session::Session;

    const FIB: &str =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(define r (fib 10))";

    #[test]
    fn vm_engine_runs_fib_to_the_right_global() {
        let mut s = Session::new();
        let out = run_source(&mut s, "fib.krf", FIB, Engine::Vm, &[]).expect("vm run");
        assert_eq!(out.engine, Engine::Vm);
        // A define-only program halts with nil; the observable result
        // is the global the define calling form stored.
        assert_eq!(out.value_display(), "nil");
        assert_eq!(
            out.global("r").expect("r stored").to_string(),
            "55",
            "globals snapshot carries the program result"
        );
    }

    #[test]
    fn eval_engine_runs_fib_to_the_same_global() {
        let mut s = Session::new();
        let out = run_source(&mut s, "fib.krf", FIB, Engine::Eval, &[]).expect("eval run");
        assert_eq!(out.engine, Engine::Eval);
        assert_eq!(out.global("r").expect("r stored").to_string(), "55");
    }

    #[test]
    fn parity_report_agrees_on_fib() {
        let mut s = Session::new();
        let report = run_parity_source(&mut s, "fib.krf", FIB, &[]).expect("parity run");
        assert!(report.agrees());
        assert_eq!(report.vm_repr, "nil");
        assert_eq!(report.eval_repr, "nil");
        assert!(report.globals_agree, "r must be `55` on both engines");
    }

    #[test]
    fn parity_report_reports_divergence_as_data() {
        // The detector self-check (0.7 precedent): a hand-built report
        // with unequal reprs must be *data*, not a panic.
        let report = ParityReport {
            vm_repr: "55".to_owned(),
            eval_repr: "54".to_owned(),
            values_agree: false,
            outputs_agree: true,
            globals_agree: true,
            globals_repr: Vec::new(),
            warnings: Vec::new(),
        };
        assert!(!report.agrees());
        assert!(!report.values_agree);
    }

    #[test]
    fn parity_report_detects_output_divergence() {
        let report = ParityReport {
            vm_repr: "nil".to_owned(),
            eval_repr: "nil".to_owned(),
            values_agree: true,
            outputs_agree: false,
            globals_agree: true,
            globals_repr: Vec::new(),
            warnings: Vec::new(),
        };
        assert!(!report.agrees(), "output divergence is a divergence");
    }

    #[test]
    fn parity_report_detects_global_divergence() {
        let report = ParityReport {
            vm_repr: "nil".to_owned(),
            eval_repr: "nil".to_owned(),
            values_agree: true,
            outputs_agree: true,
            globals_agree: false,
            globals_repr: Vec::new(),
            warnings: Vec::new(),
        };
        assert!(!report.agrees(), "global divergence is a divergence");
    }

    #[test]
    fn check_face_reports_counts_without_executing() {
        let mut s = Session::new();
        let out = check_source(&mut s, "fib.krf", FIB).expect("check");
        assert!(out.func_count >= 2, "fib + main protos: {out:?}");
        assert!(out.instr_count > 0);
        // No execution: nothing to output.
        assert!(out.func_count >= 2);
    }

    #[test]
    fn io_faces_flow_outputs_and_inputs() {
        let mut s = Session::new();
        let src = "(define r (write-line (read-line)))";
        let out =
            run_source(&mut s, "io.krf", src, Engine::Vm, &["hello".to_owned()]).expect("io run");
        assert_eq!(out.outputs, vec!["hello".to_owned()]);
        let out2 = run_source(&mut s, "io.krf", src, Engine::Eval, &["world".to_owned()])
            .expect("io run eval");
        assert_eq!(out2.outputs, vec!["world".to_owned()]);
    }

    #[test]
    fn read_error_maps_to_read_code_with_position() {
        let mut s = Session::new();
        let err =
            run_source(&mut s, "bad.krf", "(+ 1 2", Engine::Vm, &[]).expect_err("unclosed list");
        assert_eq!(err.len(), 1);
        assert_eq!(err[0].code, DiagnosticCode::Read);
        assert!(err[0].primary_span.is_some());
    }

    #[test]
    fn expand_error_maps_to_expand_code() {
        let mut s = Session::new();
        let err = run_source(
            &mut s,
            "unbound.krf",
            "(define (main) undefined-thing)",
            Engine::Vm,
            &[],
        )
        .expect_err("unbound identifier");
        assert_eq!(err.len(), 1);
        assert_eq!(err[0].code, DiagnosticCode::Expand);
    }

    #[test]
    fn runtime_error_maps_to_runtime_code_with_span() {
        let mut s = Session::new();
        let err = run_source(&mut s, "div.krf", "(define r (/ 1 0))", Engine::Vm, &[])
            .expect_err("division by zero");
        assert_eq!(err.len(), 1);
        assert_eq!(err[0].code, DiagnosticCode::Runtime);
        assert!(
            err[0].primary_span.is_some(),
            "runtime errors resolve spans"
        );
    }

    #[test]
    fn eval_path_reports_the_same_runtime_error_family() {
        let mut s = Session::new();
        let err = run_source(&mut s, "div.krf", "(define r (/ 1 0))", Engine::Eval, &[])
            .expect_err("division by zero on eval");
        assert_eq!(err[0].code, DiagnosticCode::Runtime);
        assert!(err[0].message.starts_with("division by zero"));
    }

    #[test]
    fn arity_and_type_mismatch_flow_through_both_engines() {
        let mut s = Session::new();
        // Stage 1.1: a *known-callee* arity mismatch is now caught
        // statically (E0002, asserted in the wiring tests). This test
        // keeps the runtime face alive through a checker-opaque shape:
        // the callee reaches invoke through a parameter, whose arity
        // the conservative rules deliberately skip.
        let arity = run_source(
            &mut s,
            "a.krf",
            "(define r ((fn (g) (g 1 2)) car))",
            Engine::Vm,
            &[],
        )
        .expect_err("arity");
        assert_eq!(arity[0].code, DiagnosticCode::Runtime);
        assert!(arity[0].message.contains("arity mismatch"));

        // The Stage 1.8 HM wiring hoists literal `(+ 1 #t)` to the
        // checker (E0009); routing through an HM-released dynamic
        // parameter keeps this test on the runtime face
        // (probe-verified, §9.49 GATE-2).
        let ty = run_source(
            &mut s,
            "t.krf",
            "(define f (fn (x) (car x)))\n(define r (f 5))",
            Engine::Vm,
            &[],
        )
        .expect_err("type");
        assert_eq!(ty[0].code, DiagnosticCode::Runtime);
        assert!(ty[0].message.contains("type mismatch"));
    }

    #[test]
    fn engine_display_tags_are_stable() {
        assert_eq!(Engine::Vm.to_string(), "vm");
        assert_eq!(Engine::Eval.to_string(), "eval");
    }

    #[test]
    fn parse_reuses_file_id_on_reintern() {
        let mut s = Session::new();
        let p1 = parse(&mut s, "same.krf", "(define (main) 1)").expect("parse");
        let p2 = parse(&mut s, "same.krf", "(define (main) 2)").expect("parse");
        assert_eq!(p1.file, p2.file, "upsert keeps the file id");
    }

    // ---- Stage 1.1: the checker wiring (test doc driver-wiring.md) ----

    #[test]
    fn clean_program_typechecks_to_zero_findings() {
        let mut s = Session::new();
        let p = parse(&mut s, "fib.krf", FIB).expect("parse");
        assert!(
            p.typecheck().is_empty(),
            "a clean fib must produce zero findings"
        );
    }

    #[test]
    fn definite_arity_error_aborts_run_with_registry_code() {
        let mut s = Session::new();
        let err = run_source(
            &mut s,
            "arity.krf",
            "(define (f x) x)\n(define r (f 1 2))",
            Engine::Vm,
            &[],
        )
        .expect_err("R2 definite error aborts the run");
        assert_eq!(err.len(), 1);
        assert_eq!(
            err[0].code.tag(),
            "E0002",
            "the registry code is the rendered tag"
        );
        assert_eq!(err[0].severity, crate::diagnostic::Severity::Error);
        assert!(err[0].primary_span.is_some(), "byte-precise span carried");
    }

    #[test]
    fn typecheck_error_aborts_before_side_effects() {
        // A write-line before a definite error must never run: the
        // checker aborts before either engine starts.
        let mut s = Session::new();
        let err = run_source(
            &mut s,
            "side.krf",
            "(define r (write-line \"boom\"))\n(define r2 (car 1 2))",
            Engine::Vm,
            &[],
        )
        .expect_err("definite error aborts");
        assert!(
            err.iter()
                .any(|d| matches!(d.code, DiagnosticCode::Typecheck(_))),
            "the batch carries the checker finding: {err:?}"
        );
    }

    #[test]
    fn warning_only_program_runs_and_carries_warnings() {
        let mut s = Session::new();
        let out = run_source(
            &mut s,
            "warn.krf",
            "(define r (set! car 1))",
            Engine::Vm,
            &[],
        )
        .expect("warnings never block");
        assert_eq!(out.warnings.len(), 1, "R8 lands in the warnings channel");
        assert_eq!(out.warnings[0].code.tag(), "E0008");
        assert_eq!(
            out.warnings[0].severity,
            crate::diagnostic::Severity::Warning
        );
        assert_eq!(
            out.global("r").map(|v| v.to_string()),
            Some("1".to_owned()),
            "the value channel is untouched"
        );
    }

    #[test]
    fn warning_only_program_checks_ok_with_warnings() {
        let mut s = Session::new();
        let out = check_source(&mut s, "warn.krf", "(define r (set! cdr 2))").expect("ok");
        assert!(out.func_count >= 1);
        assert_eq!(out.warnings.len(), 1);
        assert_eq!(out.warnings[0].code.tag(), "E0008");
    }

    #[test]
    fn parity_run_carries_warnings_and_error_aborts() {
        let mut s = Session::new();
        let report =
            run_parity_source(&mut s, "w.krf", "(define r (set! car 9))", &[]).expect("parity");
        assert!(report.agrees());
        assert_eq!(report.warnings.len(), 1, "warnings ride on the report");

        let err = run_parity_source(&mut s, "e.krf", "(define r (if 1 2 3))", &[])
            .expect_err("R3 aborts parity before either engine");
        assert!(err.iter().any(|d| d.code.tag() == "E0003"));
    }

    #[test]
    fn multi_error_collection_flows_through_the_driver() {
        // Two independent definite errors in one program: both
        // collected in one batch (ruling 21 — collection is an
        // architectural property, carried through the wiring).
        let mut s = Session::new();
        let err = check_source(
            &mut s,
            "multi.krf",
            "(define a (if 1 2 3))\n(define b (car 1 2))",
        )
        .expect_err("three definite errors");
        let tags: Vec<&str> = err.iter().map(|d| d.code.tag()).collect();
        assert!(tags.contains(&"E0003"), "{tags:?}");
        assert!(tags.contains(&"E0002"), "{tags:?}");
        // The Stage 1.8 HM wiring adds the inference layer's own
        // finding for the same condition (both layers report —
        // probe-verified).
        assert!(tags.contains(&"E0009"), "{tags:?}");
        assert_eq!(err.len(), 3);
    }

    #[test]
    fn non_boolean_condition_and_literal_callee_flow_through_run() {
        let mut s = Session::new();
        let e3 = run_source(&mut s, "c.krf", "(define r (if 1 2 3))", Engine::Eval, &[])
            .expect_err("E0003 on the eval path too");
        assert!(e3.iter().any(|d| d.code.tag() == "E0003"));

        let e4 = run_source(
            &mut s,
            "d.krf",
            "(define two 2)\n(define r (two 1))",
            Engine::Vm,
            &[],
        )
        .expect_err("E0004 — the unrebound literal-define callee");
        assert!(e4.iter().any(|d| d.code.tag() == "E0004"));
    }

    #[test]
    fn top_level_unhandled_perform_is_caught_statically() {
        let mut s = Session::new();
        // A perform in a top-level immediate position (the define
        // value runs at module load) with no enclosing handler: R6.
        let err = run_source(
            &mut s,
            "p.krf",
            "(define r (perform some-effect 1))",
            Engine::Vm,
            &[],
        )
        .expect_err("E0006 unhandled top-level perform");
        assert!(err.iter().any(|d| d.code.tag() == "E0006"));
    }

    #[test]
    fn eval_engine_typechecks_the_same_findings() {
        // The checker sits before both engines — the same source
        // produces the same batch whichever engine was requested.
        let mut s = Session::new();
        let err = run_source(
            &mut s,
            "same.krf",
            "(define (f x) x)\n(define r (f 1 2))",
            Engine::Eval,
            &[],
        )
        .expect_err("same finding on eval");
        assert!(err.iter().any(|d| d.code.tag() == "E0002"));
    }

    #[test]
    fn halt_snapshots_carry_pool_identities_on_both_engines() {
        // §9.67 NB-7 guard: the RunOutcome globals snapshot keys are
        // pool entries on both engines — an independently interned
        // Symbol of the define text resolves through the identity
        // face, and the text face still agrees (the §9.60.5 dual
        // contract, now on identity keys).
        for engine in [Engine::Vm, Engine::Eval] {
            let mut s = Session::new();
            let out = run_source(&mut s, "s.krf", "(define x 42)", engine, &[]).expect("run");
            let x_again = Symbol::new("x").expect("fixture symbol");
            assert_eq!(
                out.global_sym(&x_again).map(|v| v.to_string()),
                Some("42".into()),
                "{engine:?} snapshot must key by interned identity"
            );
            assert_eq!(out.global("x").map(|v| v.to_string()), Some("42".into()));
            // The snapshot roster itself carries pool entries: every
            // key equals an independent intern of its own text.
            for (name, _) in &out.globals {
                let independent = Symbol::new(name.as_str()).expect("snapshot key text");
                assert_eq!(*name, independent);
            }
        }
    }
}

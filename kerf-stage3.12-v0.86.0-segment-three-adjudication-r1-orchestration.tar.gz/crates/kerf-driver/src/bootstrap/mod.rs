//! The selfhost twin surface — the Rust-side bootstrap harness
//! family (the r122 user instruction-① unification: every module
//! whose job is to assemble, drive or verify the `selfhost/v1/*.ktf`
//! twins lives under this one directory, separated from the
//! driver's production face at the crate root).
//!
//! Residents:
//! - `target_corpus` — the twin source embeddings (the five
//!   `include_str` bindings into `selfhost/v1/`) and the
//!   target-skin injection prefixes (the RS-1/EX-1/CP family);
//! - `lexer_parity` / `reader_parity` / `expander_parity` /
//!   `compiler_parity` — the four front-end segments'
//!   twin-vs-oracle parity harnesses;
//! - `bootstrap_chain` — the steady-state injection-channel chain
//!   (W-3.12 segment one: the reader segment's `SteadyReaderChain`);
//! - `steady_expander_chain` — the same form carried to the
//!   expansion segment (W-3.12 segment two:
//!   `SteadyExpanderChain`, the `forms` record stream through the
//!   one injection channel);
//! - `composed_target_chain` / `composed_full_chain` — the composed
//!   chain verifications;
//! - `fixpoint` — the self-application fixpoint gates.
//!
//! Boundary notes (SOP §8.4.6 two-level semantics): the target-skin
//! SPELLING contract stays at the crate root (`crate::target_skin` —
//! a production contract the bridge and the diagnostics consume),
//! and the Stage 1.4 acceptance-corpus contract stays at the root
//! (`crate::parity`). The W-DRIVER-HARNESS-SPLIT crate split remains
//! trigger-gated (r122 reorganized in-crate; the +30% growth
//! trigger is unchanged).

pub mod bootstrap_chain;
pub(crate) mod compiler_parity;
pub(crate) mod composed_full_chain;
pub(crate) mod composed_target_chain;
pub(crate) mod expander_parity;
pub(crate) mod fixpoint;
pub(crate) mod lexer_parity;
pub(crate) mod reader_parity;
pub mod steady_expander_chain;
pub(crate) mod target_corpus;

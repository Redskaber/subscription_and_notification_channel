//! The W-3.4 generational-GC evaluation window integration suite
//! (stage-3-plan §2.3 W-3.4, window record
//! `docs/develop/v3/w3.4-gc-window.md`).
//!
//! GATE 6 shape: two positive integration cases (the D-CLASS-1
//! equivalence-class triplet determinism over the full compile
//! chain, and the generational-isolation simulation whose old
//! object set stays bit-for-bit untouched across young cycles) plus
//! six negative cases (the immutable-heap discipline source guards
//! ×2, the budget-frame-floor fail-closed poles ×2, the no-collector
//! fail-closed regression, and the cross-heap dead-reference skip)
//! — the negative cases outnumber the positive ones by exactly 3:1
//! on this window's test face.
//!
//! The window's adjudication KEEPS the single-generation
//! mark-sweep collector, so these tests pin the structural facts
//! the adjudication rests on (W-3.4 window record §2 findings
//! F1-F5), turning each into a fail-closed tripwire:
//! - F1 (transient polarity): churn cycles mark zero cells.
//! - F2/F3 (empty gc windows on frame-live recursion): budgets
//!   below the live-frame floor fail closed, and no budget between
//!   floor and peak produces a cycle.
//! - F5 (immutable-heap discipline): the opcode table carries no
//!   heap-mutation opcode and the production sources carry no
//!   get_mut heap consumer — the remembered-set-free premise for
//!   any future generational implementation, machine-checked.

use kerf::compiler::compile_program;
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::runtime::GcStats;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, HeapObj, Roots, Value, Vm};

/// Compile a .krf source to bytecode (the B4-guard churn_bc shape).
fn bc(src: &str) -> kerf::compiler::Bytecode {
    let forms = read_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

/// The churn generator (B4 axis shape): N defines, each allocating
/// one pair whose value is dropped at the next define.
fn churn_src(pairs: usize) -> String {
    let mut src = String::with_capacity(pairs * 32);
    for i in 0..pairs {
        src.push_str(&format!("(define d{i} (car (cons {i} nil))) "));
    }
    src
}

/// A collector that records every cycle's full GcStats (the
/// profiling face of the lifetime portrait, in test form).
#[derive(Clone, Default)]
struct RecordingCollector {
    cycles: std::rc::Rc<std::cell::RefCell<Vec<GcStats>>>,
}

impl Collector for RecordingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let stats = production_collect(heap, roots);
        self.cycles.borrow_mut().push(stats);
        stats.swept
    }
}

/// Run churn(pairs) under budget with cycle recording; return the
/// per-cycle stats and the final live count.
fn churn_cycles(pairs: usize, budget: u32) -> (Vec<GcStats>, u32) {
    let rec = RecordingCollector::default();
    let mut vm =
        Vm::with_budget_and_collector(bc(&churn_src(pairs)), budget, Box::new(rec.clone()))
            .expect("churn vm builds");
    vm.run().expect("churn program halts");
    let cycles = rec.cycles.borrow().clone();
    // D-CLASS-1's third element is the LAST CYCLE's live_after (the
    // cycle-timepoint live set), not the post-run heap face — after
    // the final cycle the remaining transients simply never trigger
    // another epoch, so the post-run heap live count is NOT part of
    // the equivalence class.
    let live = cycles.last().map(|s| s.live_after).unwrap_or(0);
    (cycles, live)
}

// ---------- positive 1: D-CLASS-1 triplet determinism ----------

/// The B4 deterministic observability face, upgraded to the
/// D-CLASS-1 equivalence class (W-3.4 window record §3): the gc's
/// observable semantics is the triplet (cycle_count, swept_total,
/// live_after_final), a pure function of (program, budget,
/// collector injection). Any internal gc optimization that changes
/// the triplet is a SEMANTIC change, not a performance change.
///
/// Cross-stage consumer: the workload goes through the full chain
/// (read → expand → compile → vm run), so the triplet pins the
/// whole pipeline's allocation behavior, not just the collector.
#[test]
fn b4_equivalence_class_dclass1_triplet_deterministic() {
    // The pinned triplets from the r119 lifetime portrait
    // (tool-results/r119-gc-lifetime-profile.txt): three
    // (pairs, budget) points, each run three times, each run must
    // reproduce its triplet exactly.
    for (pairs, budget, want_cycles, want_swept) in [
        (2_000u32, 1_024u32, 1u32, 1_023u32),
        (10_000, 1_024, 9, 9_207),
        (10_000, 4_096, 2, 8_190),
    ] {
        for _ in 0..3 {
            let (cycles, live) = churn_cycles(pairs as usize, budget);
            let swept_total: u32 = cycles.iter().map(|s| s.swept).sum();
            assert_eq!(
                cycles.len() as u32,
                want_cycles,
                "cycle count drifted for churn({pairs}) @ budget {budget} — a semantic change (D-CLASS-1)"
            );
            assert_eq!(
                swept_total, want_swept,
                "swept total drifted for churn({pairs}) @ budget {budget} — a semantic change (D-CLASS-1)"
            );
            assert_eq!(
                live, 0,
                "final live set must be empty for churn({pairs}) — the workload is transient-only (D-CLASS-1 third element)"
            );
        }
    }
}

// ---------- positive 2: generational isolation simulation ----------

/// The window's named integration case in simulation form: a
/// young-generation cycle never touches the old object set. The
/// adjudication keeps the single-generation collector, so the
/// "generations" are two independent heaps — the old heap's object
/// set stays bit-for-bit identical across five young-heap cycles
/// (Heap derives PartialEq; cells, marks, and the free list all
/// compared). A future generational implementation (W-GEN-GC)
/// inherits this as a ready-made e2e assertion: swap the young-heap
/// simulation for the real nursery and the old-heap freeze for the
/// old-generation scan-skip, and the assertion wording still holds.
#[test]
fn generational_isolation_simulation_old_set_untouched() {
    // Build the old generation: eight rooted pairs, frozen.
    let mut old_heap = Heap::default();
    let old_roots: Vec<Value> = (0..8)
        .map(|i| Value::Pair(old_heap.alloc(HeapObj::Pair(Value::Int(i), Value::Nil))))
        .collect();
    let old_snapshot = old_heap.clone();

    // Run the young generation: five allocate-collect rounds.
    let mut young_heap = Heap::default();
    for round in 0..5u32 {
        for i in 0..32u32 {
            young_heap.alloc(HeapObj::Pair(
                Value::Int(i64::from(round * 100 + i)),
                Value::Nil,
            ));
        }
        let stats = production_collect(&mut young_heap, &Roots::empty());
        assert!(
            stats.swept >= 32,
            "young cycle {round} must reclaim its transients (got {})",
            stats.swept
        );
        assert_eq!(stats.live_after, 0, "young heap returns to empty");
    }

    // The isolation face: the old heap is untouched, bit for bit.
    assert_eq!(
        old_heap, old_snapshot,
        "the old object set changed across young cycles — the isolation face broke"
    );
    assert_eq!(old_heap.live_len(), 8);
    // Every old root still resolves to its original payload.
    for (i, v) in old_roots.iter().enumerate() {
        let r = match v {
            Value::Pair(r) => *r,
            _ => unreachable!("fixture pairs"),
        };
        match old_heap.get(r) {
            Some(HeapObj::Pair(a, _)) => assert_eq!(a, &Value::Int(i as i64)),
            other => panic!("old root {i} lost: {other:?}"),
        }
    }
}

// ---------- negative 1a: no heap-mutation opcode ----------

/// The immutable-heap discipline, source-guarded (finding F5, first
/// half): the opcode table carries no heap-mutation opcode. The
/// 26-opcode set is construction-and-read only (MakePair/Car/Cdr);
/// StoreLocal/StoreGlobal write the frame and the globals table,
/// never a heap cell. The W-VM-SUPERINSTR call-global (the 26th) is
/// a pure read of the globals table plus the shared invoke — no heap
/// face at all. Adding a SetCar-shaped opcode would break the
/// remembered-set-free premise of any future generational design
/// AND change the B4 observable face — this guard fails closed on
/// both counts.
#[test]
fn opcode_table_carries_no_heap_mutation_opcode() {
    use kerf::compiler::Opcode;
    assert_eq!(
        Opcode::ALL.len(),
        27,
        "the opcode table grew — re-audit the immutable-heap discipline (W-3.4 F5) before adding any opcode"
    );
    // Read the enum source and fail closed on any mutation-shaped
    // identifier ever appearing in the opcode definition.
    let path = format!(
        "{}/crates/kerf-compiler/src/opcode.rs",
        env!("CARGO_MANIFEST_DIR")
    );
    let src = std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {path}: {e}"));
    for banned in [
        "SetCar",
        "SetCdr",
        "SetPair",
        "SetSlot",
        "StorePair",
        "StoreHeap",
        "MutateHeap",
        "WriteHeap",
    ] {
        assert!(
            !src.contains(banned),
            "heap-mutation opcode identifier `{banned}` appeared in opcode.rs — the immutable-heap discipline (W-3.4 F5) is broken; re-derive the B4 equivalence class before landing this"
        );
    }
}

// ---------- negative 1b: no production get_mut heap consumer ----------

/// The immutable-heap discipline, source-guarded (finding F5,
/// second half): no production source consumes Heap::get_mut. The
/// mutator API exists (the collector's test fixtures use it to
/// build cycles), but every consumer outside #[cfg(test)] modules
/// is a silent heap mutation — exactly what the discipline forbids.
#[test]
fn production_sources_carry_no_get_mut_heap_consumer() {
    let manifest = env!("CARGO_MANIFEST_DIR");
    let files = [
        "crates/kerf-vm/src/vm.rs",
        "crates/kerf-vm/src/builtin.rs",
        "crates/kerf-vm/src/frame.rs",
        "crates/kerf-vm/src/roots.rs",
        "crates/kerf-vm/src/io.rs",
        "crates/kerf-runtime/src/eval.rs",
        "crates/kerf-runtime/src/parity.rs",
        "crates/kerf-runtime/src/lib.rs",
    ];
    for rel in files {
        let path = format!("{manifest}/{rel}");
        let src = std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {path}: {e}"));
        // Strip any #[cfg(test)] module tail: only the production
        // prefix of the file is under the discipline.
        let production = match src.find("#[cfg(test)]") {
            Some(i) => &src[..i],
            None => &src[..],
        };
        assert!(
            !production.contains("get_mut"),
            "`{rel}` consumes get_mut in production code — a heap mutation point outside the immutable-heap discipline (W-3.4 F5); re-derive the B4 equivalence class before landing this"
        );
    }
}

// ---------- negative 2/3: the budget frame-floor poles ----------

/// Finding F2 in test form: an active recursion's frames are
/// budget units the collector cannot reclaim, so a budget below
/// the live-frame floor fails closed (collect-then-retry re-checks,
/// still above the floor, BudgetExceeded). fib(25) bottoms out at
/// 25 frames plus the entry frame — budget 22 must fail closed.
#[test]
fn budget_below_frame_floor_fails_closed_fib() {
    let src =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";
    let bc = bc(src);
    // No collector: the 0.6 fail-closed face.
    let mut vm = Vm::with_budget(bc.clone(), 22).expect("vm builds");
    let err = vm
        .run()
        .expect_err("budget 22 is below fib(25)'s live-frame floor");
    assert!(
        matches!(
            err,
            kerf::vm::RuntimeError::BudgetExceeded { budget: 22, .. }
        ),
        "expected BudgetExceeded at 22, got {err:?}"
    );
    // With a collector: the collect-then-retry path runs, reclaims
    // nothing (the floor is frames), and fails closed the same way.
    let rec = RecordingCollector::default();
    let mut vm2 = Vm::with_budget_and_collector(bc, 22, Box::new(rec.clone())).expect("vm builds");
    let err2 = vm2.run().expect_err("collector cannot reclaim live frames");
    assert!(
        matches!(
            err2,
            kerf::vm::RuntimeError::BudgetExceeded { budget: 22, .. }
        ),
        "expected BudgetExceeded at 22 with collector, got {err2:?}"
    );
    let cycles = rec.cycles.borrow();
    for stats in cycles.iter() {
        assert_eq!(
            stats.swept, 0,
            "a cycle under the frame floor reclaimed heap cells — the floor analysis (W-3.4 F2) is wrong"
        );
    }
}

/// Finding F3 in test form: the balanced chain builder (iota)
/// trades frames for cells one-for-one on the unwind, so the live
/// usage stays flat at the recursion depth — a budget below the
/// depth fails closed during the descent (before any cons exists).
#[test]
fn budget_below_descent_floor_fails_closed_iota() {
    let src = "(define (iota n) (if (= n 0) nil (cons n (iota (- n 1))))) (define result (car (iota 50)))";
    let bc = bc(src);
    let mut vm = Vm::with_budget(bc.clone(), 50).expect("vm builds");
    let err = vm
        .run()
        .expect_err("budget 50 is below iota(50)'s 51-frame descent floor");
    assert!(
        matches!(
            err,
            kerf::vm::RuntimeError::BudgetExceeded { budget: 50, .. }
        ),
        "expected BudgetExceeded at 50, got {err:?}"
    );
    // Above the flat peak (~51): no cycle fires at all — the gc
    // window for this shape is empty between floor and peak.
    let rec = RecordingCollector::default();
    let mut vm2 = Vm::with_budget_and_collector(bc, 512, Box::new(rec.clone())).expect("vm builds");
    vm2.run().expect("iota completes under a generous budget");
    assert_eq!(
        rec.cycles.borrow().len(),
        0,
        "no cycle should fire for iota(50) above its flat peak — the empty-window finding (W-3.4 F3)"
    );
}

// ---------- negative 4: no-collector fail-closed regression ----------

/// The evaluation window changes no mechanism: the 0.6 no-collector
/// face must stand exactly as before (un-reclaimed cells push the
/// live count over the budget → BudgetExceeded, no collection, no
/// retry). A drift here means the window touched the VM — zero
/// mechanism change is the window's own adjudication premise.
#[test]
fn no_collector_budget_fail_closed_unchanged() {
    // churn(8) under budget 4 with NO collector: the first four
    // pairs blow the budget and the run fails closed.
    let mut vm = Vm::with_budget(bc(&churn_src(8)), 4).expect("vm builds");
    let err = vm.run().expect_err("no collector means no reclamation");
    assert!(
        matches!(
            err,
            kerf::vm::RuntimeError::BudgetExceeded { budget: 4, .. }
        ),
        "expected BudgetExceeded at 4, got {err:?}"
    );
}

// ---------- negative 5: cross-heap dead reference skipped ----------

/// The cross-heap face of the isolation simulation: a reference
/// from the old heap's address space, passed as a root into a young
/// cycle, addresses a dead (or absent) young slot — the mark phase
/// must skip it, not panic and not poison the cycle. This pins the
/// collector's dead-reference tolerance across heap boundaries (the
/// gc.rs unit test's integration twin) and records the aliasing
/// hazard a real generational design must solve with per-heap
/// address tagging (window record §4 design-note).
#[test]
fn cross_heap_dead_reference_is_skipped_not_panic() {
    let mut old_heap = Heap::default();
    let old_ref = old_heap.alloc(HeapObj::Pair(Value::Int(1), Value::Nil));
    let mut young_heap = Heap::default();
    // The young heap has NO slot at that index (empty arena): the
    // borrowed reference addresses nothing in this heap.
    let borrowed = Roots {
        stack: vec![Value::Pair(old_ref)],
        ..Roots::empty()
    };
    let stats = production_collect(&mut young_heap, &borrowed);
    assert_eq!(stats.marked, 0, "a dead cross-heap reference marks nothing");
    assert_eq!(stats.swept, 0);
    // The old heap is unaffected by the young cycle.
    assert_eq!(old_heap.live_len(), 1);
}

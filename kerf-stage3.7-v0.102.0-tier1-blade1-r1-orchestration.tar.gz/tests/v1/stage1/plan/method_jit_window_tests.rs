//! The W-JIT-METHOD-T1 method-JIT window integration suite
//! (stage-3-plan §2.3, window record
//! `docs/develop/v3/w-jit-method-t1-window.md` — the tier-0.5
//! completion blade, TJ-1).
//!
//! GATE 6 shape: two positive integration cases (the
//! fused-vs-unfused copy-pair semantic-equivalence pin — the MUV
//! 135-b integration verification case: the same (local, const)
//! argument shape through the fused arm (one load-local-const) and
//! through a computed second argument (the unfused shape — the
//! literal-lookahead misses, the plain walk owns the site) must
//! produce the identical value with the emission shapes asserted,
//! and the branch-target structural-safety pin — a jump-if-false
//! landing ON a fused instruction executes both pushes, the
//! args-list-interior elimination is never a patch target) plus six
//! negative cases (the verify boundary family over hand-built
//! products — const-index and local-slot out of range, the two
//! source arms' checks composed verbatim; the capture-resolution
//! scope boundary — only local slots fuse, a captured name keeps
//! the plain pair; the global-argument scope boundary — the census
//! pair is load-local-specific; the twin fusion-arm tamper drifting
//! gate B; and the twin stack-effect table tamper — the pushes arm
//! is load-bearing for the twin's own estate bookkeeping, the
//! r135-incident failure mode pinned as a tripwire) — the negative
//! cases outnumber the positive ones by exactly 3:1 on this
//! window's test face (the r119 gc_window / r132 jit_window /
//! r133/r134 superinstr shape).
//!
//! The window's adjudication (w-jit-method-t1-window.md §2) rests
//! on the TJ-1..TJ-4 rulings; these tests pin the structural facts
//! the rulings rest on as fail-closed tripwires:
//! - TJ-1: the fusion is emission-site only, structurally safe
//!   without a fusable-classifier walk (args-list interior
//!   positions are never branch heads — positive 2's jump target).
//! - TJ-2: the copy pair is the LAST pair-level fusion — the
//!   call/control-shaped pairs stay unfused (tier-1 absorption
//!   territory, pinned in jit_window_tests).
//! - The operand layout (a = local slot, b = constant-pool index;
//!   pops 0, pushes 2) is pinned through verify (negatives 1/2).
//! - The twin's fused arm and stack-effect table are load-bearing
//!   for gate B (negatives 5/6).

use kerf::compiler::compile_program;
use kerf::compiler::{Bytecode, FuncProto, Instr, Opcode};
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
use kerf::vm::Vm;

// ---------- fixtures ----------

fn bc(src: &str) -> Bytecode {
    let forms = read_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

fn run_value(src: &str) -> String {
    let mut vm = Vm::new(bc(src)).expect("vm");
    vm.run().expect("program halts");
    vm.global("result")
        .map(|v| v.to_string())
        .expect("result global bound")
}

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(8), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

/// A minimal verified hand-built product around one instruction
/// sequence: one entry proto with `n_locals` slots, `consts`,
/// `globals`.
fn hand_built(code: Vec<Instr>, n_locals: u32, consts: Vec<kerf::core::LiteralValue>) -> Bytecode {
    let mut proto = FuncProto::new(None, 0, n_locals);
    proto.code = code;
    proto.debug_info = vec![fix_span(); proto.code.len()];
    let mut bytecode = Bytecode::default();
    bytecode.funcs.push(proto);
    bytecode.consts = consts;
    bytecode
}

/// Count one opcode across every proto of a product.
fn count_op(product: &Bytecode, op: Opcode) -> usize {
    product
        .funcs
        .iter()
        .flat_map(|f| f.code.iter())
        .filter(|i| i.op == op)
        .count()
}

/// Count the adjacent (first, second) opcode pair across every
/// proto (the compiled-product adjacency face — the pair the
/// census observes dynamically).
fn count_pair(product: &Bytecode, first: Opcode, second: Opcode) -> usize {
    product
        .funcs
        .iter()
        .flat_map(|f| f.code.windows(2))
        .filter(|w| w[0].op == first && w[1].op == second)
        .count()
}

// ---------- positive 1: fused vs unfused copy pairs ----------

/// The MUV 135-b integration verification case: the same (local,
/// const) argument shape through the FUSED arm (the literal
/// lookahead hits — one load-local-const, the pair's slots never
/// round-trip through separate dispatches) and through the UNFUSED
/// shape (a computed second argument — the lookahead misses, the
/// plain walk owns the site) must produce the identical value; the
/// emission shapes are asserted on each side.
#[test]
fn wmj_fused_and_unfused_copy_pairs_agree_bit_for_bit() {
    // Fused: `(+ x 1)` — arg[0] is the local x, arg[1] the literal
    // 1: one load-local-const owns the site; zero load-local, zero
    // push-const in the whole product (the entry's call sites carry
    // neither — the argument is a fused pair, the callee is a
    // call-global).
    let fused_src = "(define (f x) (+ x 1)) (define result (f 41))";
    let fused = bc(fused_src);
    assert_eq!(run_value(fused_src), "42");
    assert_eq!(
        count_op(&fused, Opcode::LoadLocalConst),
        1,
        "the fused copy pair owns the (local, const) argument site"
    );
    assert_eq!(
        count_pair(&fused, Opcode::LoadLocal, Opcode::PushConst),
        0,
        "no residual unfused copy pair in the fused product"
    );

    // Unfused: `(+ x (+ 0 1))` — arg[1] is an application, not a
    // literal: the lookahead misses and the plain walk owns the
    // site (load-local + the computed argument); the inner
    // `(+ 0 1)` is const-first, never the copy pair.
    let unfused_src = "(define (g x) (+ x (+ 0 1))) (define result (g 41))";
    let unfused = bc(unfused_src);
    assert_eq!(run_value(unfused_src), "42");
    assert_eq!(
        count_op(&unfused, Opcode::LoadLocalConst),
        0,
        "the computed-argument site must not fuse"
    );
    assert!(
        count_op(&unfused, Opcode::LoadLocal) >= 1,
        "the unfused shape keeps the plain local read"
    );
    assert_eq!(
        count_op(&unfused, Opcode::PushConst),
        3,
        "the inner constant pair keeps two separate pushes (const-first order never fuses) \
         plus the call site's own argument push"
    );
}

// ---------- positive 2: the branch-target structural-safety pin ----------

/// TJ-1's structural-safety argument pinned end-to-end: a tail `if`
/// compiles the condition, jump-if-false, then-branch, else-branch
/// — and the jump-if-false's patch target is the ELSE-branch start,
/// which for `(+ x 2)` IS the fused instruction. A branch head
/// landing on the fused instruction must execute both pushes (the
/// eliminated args-list-interior slot is never a patch target —
/// the argument that let the emission-site fusion skip the fusable
/// classifier walk).
#[test]
fn wmj_branch_target_lands_on_the_fused_instruction() {
    let src =
        "(define (f x) (if (< x 5) (+ x 1) (+ x 2))) (define r1 (f 1)) (define result (f 41))";
    let product = bc(src);
    // Both arms execute through their fused sites: r1 = 2 (then),
    // result = 43 (else — the jump target's own fused pair).
    assert_eq!(run_value(src), "43");
    let mut vm = Vm::new(bc(src)).expect("vm");
    vm.run().expect("program halts");
    assert_eq!(
        vm.global("r1").map(|v| v.to_string()),
        Some("2".to_string()),
        "the then-arm's fused pair executes through the fallthrough site"
    );

    // The fib-shaped proto (funcs[1]) carries exactly three fused
    // pairs: the comparison's (x, 5) and both arm bodies' (x, 1) /
    // (x, 2).
    let f = &product.funcs[1];
    let fused = f
        .code
        .iter()
        .filter(|i| i.op == Opcode::LoadLocalConst)
        .count();
    assert_eq!(fused, 3, "the condition and both arms fuse");

    // The structural-safety core: the jump-if-false's patch target
    // instruction IS the else-arm's fused pair — executing it
    // pushes both operands exactly as the unfused pair would have.
    let jf = f
        .code
        .iter()
        .find(|i| i.op == Opcode::JumpIfFalse)
        .expect("the tail if emits one jump-if-false");
    let target = &f.code[jf.a as usize];
    assert_eq!(
        target.op,
        Opcode::LoadLocalConst,
        "the else-branch head is the fused instruction — a branch target on it must be sound"
    );
}

// ---------- negative 1/2: the verify boundary family ----------

/// The fused operand is bounds-checked on BOTH faces like its
/// source arms (Pass 1c): the constant index against the pool (the
/// PushConst discipline) and the local slot against the proto's
/// own frame (the LoadLocal discipline).
#[test]
fn wmj_verify_rejects_const_index_and_slot_out_of_range() {
    // b = 0 with an EMPTY const pool — the PushConst face.
    let bad_const = hand_built(
        vec![
            Instr {
                op: Opcode::LoadLocalConst,
                a: 0,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        1,
        vec![],
    );
    let err = bad_const
        .verify()
        .expect_err("the out-of-range constant index must fail closed");
    assert!(
        matches!(
            err,
            kerf::compiler::CompileError::ConstIndexOutOfRange { .. }
        ),
        "the fused pair's const operand is bounds-checked like push-const: {err:?}"
    );

    // a = 1 with a one-slot frame — the LoadLocal face.
    let bad_slot = hand_built(
        vec![
            Instr {
                op: Opcode::LoadLocalConst,
                a: 1,
                b: 0,
            },
            Instr::new(Opcode::Halt),
        ],
        1,
        vec![kerf::core::LiteralValue::Int(7)],
    );
    let err = bad_slot
        .verify()
        .expect_err("the out-of-range local slot must fail closed");
    assert!(
        matches!(
            err,
            kerf::compiler::CompileError::LocalSlotOutOfRange { .. }
        ),
        "the fused pair's slot operand is bounds-checked like load-local: {err:?}"
    );
}

// ---------- negative 3: the capture-resolution scope boundary ----------

/// Only LOCAL slots fuse (TJ-1's conjunct mirrors the Var walk):
/// a CAPTURED name keeps the plain pair — load-captured + the
/// literal's push-const — because the fused operand form has no
/// capture face (the emission-site condition checks the local
/// table exactly like the Var arm does, then falls through).
#[test]
fn wmj_capture_resolution_is_never_fused() {
    let src = "(define (make-adder n) (fn (x) (+ n 1))) (define add2 (make-adder 41)) (define result (add2 1))";
    let product = bc(src);
    assert_eq!(run_value(src), "42");
    assert_eq!(
        count_op(&product, Opcode::LoadLocalConst),
        0,
        "a captured name must never fuse — the operand form has no capture face"
    );
    assert!(
        count_pair(&product, Opcode::LoadCaptured, Opcode::PushConst) >= 1,
        "the captured site keeps the plain load-captured + push-const pair"
    );
}

// ---------- negative 4: the global-argument scope boundary ----------

/// The census pair is load-LOCAL-specific: a GLOBAL-resolving
/// argument keeps the plain pair (load-global + push-const — the
/// (load-global, push-const) adjacency is tier-1 absorption
/// territory, TJ-2, never this blade's face).
#[test]
fn wmj_global_argument_keeps_the_plain_pair() {
    let src = "(define x 41) (define result (+ x 1))";
    let product = bc(src);
    assert_eq!(run_value(src), "42");
    assert_eq!(
        count_op(&product, Opcode::LoadLocalConst),
        0,
        "a global-resolving argument must not fuse"
    );
    assert!(
        count_pair(&product, Opcode::LoadGlobal, Opcode::PushConst) >= 1,
        "the global site keeps the plain load-global + push-const pair"
    );
}

// ---------- negative 5: the twin fusion-arm tamper ----------

/// The twin's fused arm is load-bearing for gate B: pinning the
/// pooled constant's index to the first slot (dropping the
/// intern) drifts the twin's product off the oracle wherever a
/// fused site's constant is not the pool's first entry — the
/// exact face the tamper targets. The control arm stays
/// bit-identical.
#[test]
fn wmj_twin_fused_arm_tamper_drifts_gate_b() {
    use kerf::driver::{COMPILER_TARGET_SOURCE, ktf_compile_rich};

    // The emit call's intern expression — unique to the awalk
    // fusion site (the lit walker interns through `cp_4(t)`, a
    // different variable).
    let needle = "cp_intern_const(cp_4(nxt))";
    assert_eq!(
        COMPILER_TARGET_SOURCE.matches(needle).count(),
        1,
        "the tamper needle must land on exactly the twin's fused emit"
    );
    let tampered = COMPILER_TARGET_SOURCE.replace(needle, "0");
    assert_ne!(&tampered, COMPILER_TARGET_SOURCE);

    // Three fused sites with three DISTINCT pooled constants (5,
    // 1, 2 — first-use order k0/k1/k2): pinning every index to 0
    // re-reads the comparison's constant at the arm sites.
    let forms = read_program(
        FileId(0),
        "(define (f x) (if (< x 5) (+ x 1) (+ x 2))) (define result (f 41))",
    )
    .expect("probe reads");
    let items = expand_program(&forms).expect("probe expands");
    let run =
        ktf_compile_rich(&items, &tampered).expect("the tampered twin still produces a verdict");
    let product = run
        .bytecode
        .expect("the tampered twin still produces a product");
    let oracle = compile_program(&items).expect("the oracle compiles");
    assert_ne!(
        product, oracle,
        "the tampered fusion arm must drift the gate-B product"
    );
    // And the untampered twin stays bit-identical (the control arm).
    let control = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the control twin runs");
    assert_eq!(
        control.bytecode.expect("control product"),
        oracle,
        "the untampered twin matches the oracle bit-for-bit"
    );
}

// ---------- negative 6: the twin stack-effect table tamper ----------

/// The twin's pushes arm for the fused pair is load-bearing for
/// its own estate bookkeeping (the r135-incident failure mode:
/// the first-cut table missed the arm and the undercounted depth
/// turned every later pop into a spurious stack-underflow): pinning
/// the arm's 2 to a 1 must push the twin onto its error axis, not
/// a silently-wrong product.
#[test]
fn wmj_twin_stack_effect_table_is_load_bearing() {
    use kerf::driver::{COMPILER_TARGET_SOURCE, ktf_compile_rich};

    // The pushes arm's return value, anchored by its unique
    // comment tail (the `2` alone is not unique — dup/swap share
    // the value).
    let needle = "separate dispatches).\n        2";
    assert!(
        COMPILER_TARGET_SOURCE.contains(needle),
        "the tamper needle must land on the twin's pushes arm"
    );
    let tampered =
        COMPILER_TARGET_SOURCE.replace(needle, "through separate dispatches).\n        1");
    assert_ne!(&tampered, COMPILER_TARGET_SOURCE);

    let forms = read_program(FileId(0), "(define (f x) (+ x 1)) (define result (f 41))")
        .expect("probe reads");
    let items = expand_program(&forms).expect("probe expands");
    let run =
        ktf_compile_rich(&items, &tampered).expect("the tampered twin still produces a verdict");
    assert!(
        run.bytecode.is_none(),
        "the undercounted estate depth must fail the twin closed (stack-underflow), not \
         silently mis-book the product: {}",
        run.vm_text
    );
    // The control arm stays a healthy product.
    let control = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the control twin runs");
    assert!(
        control.bytecode.is_some(),
        "the untampered twin produces the product"
    );
}

// ===================================================================
// The tier-1 blade-1 family (W-JIT-METHOD-T1 blade 1 — r141, the
// MJ-1..MJ-4 rulings, w-jit-method-t1-window.md §7). GATE 6 shape on
// this window's face: two positive integration cases + six negative
// cases (1:3 — the r119/r132/r133/r135 form).
//
// - MJ-1: the chain nodes are the interpreter arms' own bodies (the
//   `arm_*` single source) — engine equivalence is a construction.
// - MJ-2: the census counts closure invocations (threshold 64 by
//   default; 1 and u32::MAX are the guard's two policy extremes).
// - MJ-3: whole-function granularity; engine mixing only at frame
//   boundaries; the builder fail-closes on hand-built fragments.
// - MJ-4: the same bytecode yields the same chain; both engines
//   agree on values, output, errors, and budget accounting.
// ===================================================================

use kerf::vm::RuntimeError as TierRuntimeError;
use kerf::vm::{METHOD_HOT_THRESHOLD, MethodChain, MethodJitError};

/// The census stream recorder (the observation face guard).
#[derive(Default)]
struct Recorder {
    triples: Vec<(Opcode, usize, usize)>,
}

impl kerf::vm::VmObserver for Recorder {
    fn observe(&mut self, op: Opcode, func: usize, pc: usize) {
        self.triples.push((op, func, pc));
    }
}

// ---------- positive 1: the MUV 141-b integration verification case ----------

/// Dual-path same value and accounts: the same program through the
/// pure-interpreter engine (threshold u32::MAX) and the all-compiled
/// engine (threshold 1 — fib compiles at its first invocation), plus
/// the default production VM crossing naturally, must agree on the
/// value, the output, AND the allocation accounting (D-CLASS-1's
/// face): constructive parity, not statistical.
#[test]
fn wmj_method_tier_dual_path_same_value_and_accounts() {
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))
(define result (fib 20))";
    // fib is the product's first define — proto index 1 (the entry
    // proto is 0; the compilation order is deterministic).
    let mut interpreted = Vm::with_method_tier_threshold(bc(src), u32::MAX).expect("vm");
    let v1 = interpreted.run().expect("halts");
    let out1 = interpreted.take_output();
    let allocs1 = interpreted.allocations();

    let mut compiled = Vm::with_method_tier_threshold(bc(src), 1).expect("vm");
    let v2 = compiled.run().expect("halts");
    assert_eq!(format!("{:?}", v1), format!("{:?}", v2));
    assert_eq!(out1, compiled.take_output());
    assert_eq!(allocs1, compiled.allocations());
    assert_eq!(
        interpreted.global("result").expect("bound").to_string(),
        compiled.global("result").expect("bound").to_string()
    );

    // The tier faces: the compiled side crossed (fib hot), the
    // interpreted side never did; both counted the same call
    // sequence (the census is engine-invariant).
    assert!(compiled.method_tier().is_compiled(1));
    assert!(!interpreted.method_tier().is_compiled(1));
    assert_eq!(
        interpreted.method_tier().invocations(1),
        compiled.method_tier().invocations(1)
    );

    // The default production VM crosses naturally (fib(20) invokes
    // fib 21,891 times >> 64) and lands on the same value.
    let mut prod = Vm::new(bc(src)).expect("vm");
    let v3 = prod.run().expect("halts");
    assert_eq!(format!("{:?}", v3), format!("{:?}", v1));
    assert!(prod.method_tier().is_compiled(1));
    assert!(prod.method_tier().invocations(1) > METHOD_HOT_THRESHOLD);
    assert_eq!(
        prod.global("result").expect("bound").to_string(),
        interpreted.global("result").expect("bound").to_string()
    );
    assert!(!prod.method_tier().build_failed(1));
}

// ---------- positive 2: chain determinism ----------

/// The same bytecode yields the same chain (MJ-4): two independent
/// runs produce identical canonical listings, a different bytecode
/// produces a different listing, and a direct double build (no VM)
/// agrees with both.
#[test]
fn wmj_method_tier_chain_determinism_same_bytecode_same_listing() {
    // Self recursion through the compiled chain exercises the
    // callee-ret-into-caller-mid-activation resume path (MJ-3 — the
    // recursive call rets back into the compiled caller mid-chain).
    let src = "(define (down n) (if (= n 0) 7 (down (- n 1))))
(define result (down 20))";
    let mut a = Vm::with_method_tier_threshold(bc(src), 1).expect("vm a");
    a.run().expect("halts");
    let mut b = Vm::with_method_tier_threshold(bc(src), 1).expect("vm b");
    b.run().expect("halts");
    let la = a.method_tier().chain_listing(1).expect("down compiled");
    let lb = b.method_tier().chain_listing(1).expect("down compiled");
    assert_eq!(la, lb);
    assert_eq!(
        a.global("result").expect("bound").to_string(),
        b.global("result").expect("bound").to_string()
    );

    // One extra instruction in the else arm — the listing must differ
    // (the guard's teeth, not a tautology: the opcode layout moved).
    let mut c = Vm::with_method_tier_threshold(
        bc("(define (down n) (if (= n 0) 7 (+ 1 (down (- n 1)))))
(define result (down 20))"),
        1,
    )
    .expect("vm c");
    c.run().expect("halts");
    let lc = c.method_tier().chain_listing(1).expect("compiled");
    assert_ne!(la, lc);
    assert_ne!(la.len(), lc.len());

    // A direct double build (no VM in between) agrees with itself
    // and with the VM-driven listing.
    let product = bc(src);
    let c1 = MethodChain::build(&product, 1).expect("builds");
    let c2 = MethodChain::build(&product, 1).expect("builds");
    assert_eq!(c1.listing(), c2.listing());
    assert_eq!(c1.listing(), la);
}

// ---------- negative 1: the builder's fail-closed defenses ----------

/// The build refuses independently of verify (MJ-3's defense in
/// depth): dangling jumps, empty bodies, and unknown funcs are
/// unreachable on verified products (verify rejects all three
/// shapes first) — the builder re-checks them so a hand-built
/// fragment cannot smuggle a broken chain; and on every healthy run
/// no function ever records a refused build (the permanent-fallback
/// state is unreachable through the verified face — that unreachably
/// IS the layering's point).
#[test]
fn wmj_method_chain_builder_rejects_fail_closed() {
    // A dangling jump (target == code len).
    let dangling = hand_built(
        vec![
            Instr::with_a(Opcode::JumpIfFalse, 2),
            Instr::new(Opcode::Halt),
        ],
        0,
        vec![],
    );
    assert!(matches!(
        MethodChain::build(&dangling, 0),
        Err(MethodJitError::DanglingJump {
            func: 0,
            pc: 0,
            target: 2
        })
    ));
    // An empty body.
    let empty = hand_built(vec![], 0, vec![]);
    assert!(matches!(
        MethodChain::build(&empty, 0),
        Err(MethodJitError::EmptyBody { func: 0 })
    ));
    // An unknown func index.
    let fine = hand_built(vec![Instr::new(Opcode::Halt)], 0, vec![]);
    assert!(matches!(
        MethodChain::build(&fine, 7),
        Err(MethodJitError::UnknownFunc { func: 7 })
    ));
    assert!(MethodChain::build(&fine, 0).is_ok());
    // The healthy-run record: compiled, never refused.
    let mut vm =
        Vm::with_method_tier_threshold(bc("(define (f x) (+ x 1)) (define result (f 41))"), 1)
            .expect("vm");
    vm.run().expect("halts");
    assert!(vm.method_tier().is_compiled(1));
    assert!(!vm.method_tier().build_failed(1));
}

// ---------- negative 2: error-path parity under tier ----------

/// Two error families raised INSIDE the compiled chain (the erroring
/// invocation ran compiled) render byte-identically to the
/// interpreter's (same payloads, same spans — MJ-4).
#[test]
fn wmj_method_tier_error_paths_bit_identical() {
    // Family 1: type mismatch (car on a non-pair, at the hot
    // function's deepest recursion).
    let src1 = "(define (down n) (if (= n 0) (car 5) (down (- n 1))))
(define result (down 30))";
    let e_int = Vm::with_method_tier_threshold(bc(src1), u32::MAX)
        .expect("vm")
        .run()
        .expect_err("errors");
    let e_jit = Vm::with_method_tier_threshold(bc(src1), 1)
        .expect("vm")
        .run()
        .expect_err("errors");
    assert_eq!(format!("{:?}", e_int), format!("{:?}", e_jit));
    assert!(matches!(e_jit, TierRuntimeError::TypeMismatch { .. }));
    assert!(matches!(e_int, TierRuntimeError::TypeMismatch { .. }));

    // Family 2: division by zero through a compiled caller.
    let src2 = "(define (go n) (if (= n 0) (/ 1 0) (go (- n 1))))
(define result (go 10))";
    let d_int = Vm::with_method_tier_threshold(bc(src2), u32::MAX)
        .expect("vm")
        .run()
        .expect_err("errors");
    let d_jit = Vm::with_method_tier_threshold(bc(src2), 1)
        .expect("vm")
        .run()
        .expect_err("errors");
    assert_eq!(format!("{:?}", d_int), format!("{:?}", d_jit));
    assert!(matches!(d_jit, TierRuntimeError::DivByZero { .. }));
}

// ---------- negative 3: budget-boundary parity ----------

/// The BudgetExceeded boundary under both engines: same failure
/// render, same allocation count (the D-CLASS-1 face — the chain
/// nodes charge the same reserves at the same steps).
#[test]
fn wmj_method_tier_budget_boundary_parity() {
    let src = "(define (grow n) (if (= n 0) nil (cons n (grow (- n 1)))))
(define result (grow 100000))";
    let mut interpreted = Vm::with_budget(bc(src), 300).expect("vm");
    interpreted.set_method_tier_threshold(u32::MAX);
    let e_int = interpreted.run().expect_err("budget");
    let mut compiled = Vm::with_budget(bc(src), 300).expect("vm");
    compiled.set_method_tier_threshold(1);
    let e_jit = compiled.run().expect_err("budget");
    assert_eq!(format!("{:?}", e_int), format!("{:?}", e_jit));
    assert_eq!(interpreted.allocations(), compiled.allocations());
    assert!(matches!(e_jit, TierRuntimeError::BudgetExceeded { .. }));
    assert!(compiled.method_tier().is_compiled(1));
}

// ---------- negative 4: the census stream is undisturbed ----------

/// The observation face under the mechanism (the r132 seam
/// discipline's tier version): the (op, func, pc) triple stream from
/// the all-compiled run is identical to the interpreted one — the
/// driver reports at the interpreter's own fetch position, so the
/// census measurements do not move when the tier turns on.
#[test]
fn wmj_method_tier_census_stream_identical_under_tier() {
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))
(define result (fib 12))";
    let mut rec_int = Recorder::default();
    let mut interpreted = Vm::with_method_tier_threshold(bc(src), u32::MAX).expect("vm");
    interpreted.run_observed(&mut rec_int).expect("halts");
    let mut rec_jit = Recorder::default();
    let mut compiled = Vm::with_method_tier_threshold(bc(src), 1).expect("vm");
    compiled.run_observed(&mut rec_jit).expect("halts");
    // The mechanism was live on the compiled side.
    assert!(compiled.method_tier().is_compiled(1));
    assert_eq!(rec_int.triples, rec_jit.triples);
    // A sanity anchor: the stream is non-empty and both sides agree
    // on the census value.
    assert_eq!(rec_int.triples.len(), rec_jit.triples.len());
    assert!(!rec_int.triples.is_empty());
}

// ---------- negative 5: deep recursion stays on the heap frames ----------

/// G2's C3 discipline under tier: the compiled engine's calls push
/// the same heap frames — the call nodes hand control back to the
/// single main loop (the Rust stack stays constant per activation
/// depth; no host recursion rides the kerf recursion).
#[test]
fn wmj_method_tier_deep_recursion_stays_on_heap_frames() {
    let src = "(define (sum n) (if (= n 0) 0 (+ n (sum (- n 1)))))
(define result (sum 2000))";
    let mut compiled = Vm::with_method_tier_threshold(bc(src), 1).expect("vm");
    compiled.run().expect("halts");
    assert!(compiled.method_tier().is_compiled(1));
    assert_eq!(
        compiled.global("result").expect("bound").to_string(),
        "2001000"
    );
    // The interpreted control agrees on the same value.
    let mut interpreted = Vm::with_method_tier_threshold(bc(src), u32::MAX).expect("vm");
    interpreted.run().expect("halts");
    assert_eq!(
        interpreted.global("result").expect("bound").to_string(),
        "2001000"
    );
}

// ---------- negative 6: the entry lower bound + halt edges ----------

/// The F5 lower bound, honestly pinned: a churn-shaped top level
/// (straight-line entry body, the whole program in the entry proto)
/// never compiles under the invocation census — the entry proto is
/// not a closure call face (run_dispatch pushes it directly; MJ-2's
/// documented boundary). The halt edges are engine-invariant by
/// construction: verify confines halt to the entry proto, which the
/// census never compiles — the Halt node exists for chain
/// completeness, and both halt forms agree across the engines.
#[test]
fn wmj_method_tier_entry_lower_bound_and_halt_edges() {
    // The churn shape: one straight-line entry, zero defines.
    let churn = "(define result (car (cons 1 2)))";
    let mut vm = Vm::new(bc(churn)).expect("vm");
    vm.run().expect("halts");
    assert_eq!(vm.method_tier().invocations(0), 0);
    assert!(!vm.method_tier().is_compiled(0));

    // Both halt forms under both engines: value halt and empty-stack
    // (nil) halt.
    for src in ["(define result (+ 20 22))", "(define x 1)"] {
        let mut a = Vm::with_method_tier_threshold(bc(src), u32::MAX).expect("vm");
        let va = a.run().expect("halts");
        let mut b = Vm::with_method_tier_threshold(bc(src), 1).expect("vm");
        let vb = b.run().expect("halts");
        assert_eq!(format!("{:?}", va), format!("{:?}", vb));
    }
}

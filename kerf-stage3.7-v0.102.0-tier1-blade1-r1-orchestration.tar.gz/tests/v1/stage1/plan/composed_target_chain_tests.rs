//! The r104 composed target chain (switch-window-plan §5.6.4,
//! stage0.md §9.99): the E5 batch-3 precondition — the `.krf`
//! composed chain's §9.87 formula driven with the five `.ktf`
//! twins through the production bridge, the chain's OWN products
//! feeding forward at every junction.
//!
//! Three layers, per the corpus discipline (the §9.87 test shape
//! carried to the target skin):
//! - **Positive**: the anchor shapes end to end; the selfhost fixed
//!   points — the five `.krf` twin sources through the full `.ktf`
//!   chain (junction 1's twins implement the S-expr read chain, so
//!   the S-expr twin sources ARE the chain's own-source family; the
//!   `.ktf` sources' read-side self-application is carried by the
//!   step-4 fixpoint through the production bridge, and the compile
//!   side rides junction 3 here through the assembled drives); and
//!   the corpus sweep with the drift ledger's routing total.
//! - **Negative**: every routing row's error axis (a reader-layer
//!   rejection at junction 1, expander-layer at junction 2, the
//!   compile error axis at junction 3), the tamper probes at all
//!   three junctions (a chain that cannot fail at every junction is
//!   not a chain), and the honest harness-envelope classification
//!   with the VM bracket re-verification.
//! - **Cross-stage consumption**: the Stage 1.4/2.1 corpus rides as
//!   the input face; the five `.ktf` deliverables (the step-3
//!   twins) are consumed by the chain that replaces their `.krf`
//!   originals; the §9.87.4 layer distribution (8/19/58) is the
//!   ledger's pinned invariant, re-verified on the target skin.

use kerf::driver::{
    COMPILER_TARGET_SOURCE, ComposedLayer, LEXER_TARGET_SOURCE, READER_TARGET_SOURCE,
    assembled_expander_target_source, composed_target_chain_parity, composed_target_chain_probes,
};
use kerf::expander::{expand_program, load_program};
use kerf::reader::read_program;
use kerf::span::FileId;

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family, the selfhost fixed
/// points) recurse through the .ktf analysis and the harness's Rust
/// tree walkers; the demand-allocated stack discipline of the
/// sibling composed-chain tests.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- positive: the anchors, end to end ----------

#[test]
fn positive_anchors_through_the_target_composed_chain() {
    deep_stack(|| {
        let cases = [
            ("target-fn-sugar", "(define (f x) (if x 1 2))"),
            (
                "target-capture-order",
                "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))",
            ),
            (
                "target-transitive",
                "(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))",
            ),
            (
                "target-effects",
                "(define r (handle (perform log 1) (log (fn (v) v))))",
            ),
            (
                "target-let-shadow",
                "(define r (let ((x 1)) (let ((x (+ x 1))) x)))",
            ),
            (
                "target-multi-define-module",
                "(define a 1)\n(define (b x) (+ a x))\n(define c (b 2))",
            ),
            (
                "target-payload-family",
                "(define s \"a\\nb\")\n(define f 3.5)\n(define n -7)\n(define t #f)",
            ),
        ];
        for (name, source) in &cases {
            let report = composed_target_chain_parity(name, source);
            assert!(report.matched, "{}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Compile, "{name}");
            assert!(report.read_matched, "{name}");
            assert_eq!(report.expand_matched, Some(true), "{name}");
            assert_eq!(report.compile_matched, Some(true), "{name}");
        }
    });
}

#[test]
fn empty_and_comment_only_sources_ride_the_compile_row() {
    deep_stack(|| {
        // Zero-form sources: the oracle accepts them (an empty
        // program compiles to the empty product), so they ride the
        // Compile row with the nil-carried stream prefixes.
        for (name, source) in [
            ("target-comment-only", ";; nothing but trivia\n"),
            ("target-empty", ""),
        ] {
            let report = composed_target_chain_parity(name, source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Compile, "{name}");
            assert_eq!(report.compile_matched, Some(true), "{name}");
        }
    });
}

// ---------- the selfhost fixed points ----------
//
// The `.krf`-twin-source fixed points (the reader / lexer /
// assembled expander / compiler / macro sources through the full
// `.ktf` chain — the cross-skin self-application family) retired
// with the r104 E5 batch-3 teardown: the `.krf` originals left the
// tree, and the `.ktf` read-chain twins implement the S-expr read
// chain, so their own-source family IS the `.krf` twin sources
// (the `.ktf` sources' read-side self-application is the step-4
// fixpoint's face through the production bridge, verified in
// `target_fixpoint_tests.rs`; the compile-side carry rides the
// corpus sweep below — every case a full-chain junction-1/2/3
// traversal). The retired family's record rides the audit's
// historical sections.

/// The `.ktf` twins' own-source carry on the read side: junction 1
/// must REJECT a `.ktf` source as its INPUT (the twins implement
/// the S-expr read chain — target-skin text is not S-expr text; the
/// oracle rejects it identically, and the matched error axis is the
/// proof). This pins the boundary the step-4 fixpoint covers from
/// the other side (the `.ktf` sources read through the NEW reader,
/// not through the .ktf read-chain twins).
#[test]
fn a_target_skin_source_is_rejected_by_both_the_twins_and_the_oracle() {
    deep_stack(|| {
        let ktf_sample = "fn main() {\n    let x = 1;\n    x\n}\n";
        let report = composed_target_chain_parity("target-ktf-input-boundary", ktf_sample);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Read);
        // Both engines and the oracle reject with the same key; the
        // downstream junctions are vacuous.
        assert_eq!(report.expand_matched, None);
        assert_eq!(report.compile_matched, None);
    });
}

// ---------- the drift ledger: the corpus routing is total ----------

/// The ledger's pinned distribution (§9.87.4) re-verified on the
/// target skin: every corpus file lands in exactly one row — the 8
/// reader-layer rejections verify on junction 1's error axis, the
/// 19 expander/loader rejections on junction 2's, and the 58
/// compiler-layer files ride the full formula.
#[test]
fn corpus_directory_every_file_lands_in_its_ledger_row_target_skin() {
    deep_stack(corpus_ledger_sweep_body);
}

fn corpus_ledger_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    let mut read_row = 0usize;
    let mut expand_row = 0usize;
    let mut compile_row = 0usize;
    let mut boundary_row = 0usize;
    let mut extern_row = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        // The oracle routing decides the ledger row (the CP1/CP9
        // filter — the same single-source classification).
        let forms = read_program(FileId(0), &source).ok();
        let items = forms.as_ref().and_then(|f| {
            expand_program(f)
                .ok()
                .and_then(|items| load_program(&items).ok().map(|_| items))
        });
        let expected_layer = if forms.is_none() {
            ComposedLayer::Read
        } else if items.is_none() {
            ComposedLayer::Expand
        } else {
            ComposedLayer::Compile
        };
        // W-3.2 + r122 + r123 + r124: the extern family's ledger
        // rows. The expander twin carries the form since the r122
        // refresh (the shape/ABI/type/canonical-collision police
        // plus the extern item records), so the expansion-rejection
        // rows ride the NORMAL path. The r124 junction-3 consumption
        // landed: the emit face carries the names single-quoted
        // (the r122 double-quote family, second member, fixed), the
        // .ktf compiler twin consumes the record (cp_extern_walk),
        // the product tables ride both engines' analysis dumps, and
        // the name-uniqueness police runs twin-side (`eq?` is
        // content comparison for strings). The rows now split:
        // * the oracle-accept rows (pos-037/neg-058) CONVERGE —
        //   products carry the table, parity holds end-to-end, and
        //   they ride the normal Compile row below;
        // * neg-062 (the C-symbol row) stays the ONE disclosed
        //   drift — the derived-symbol character police has no
        //   frozen-subset expression (zero character ops in the 18
        //   builtins), so the twin compiles the row on while the
        //   oracle's compile rejects it; the rebuild face's verify
        //   judge catches the hand-built table through the same
        //   floor (the r123 two-judges contract, §6e ruling).
        let is_extern_row = source.contains("(extern") && forms.is_some() && items.is_some();
        let oracle_compile_rejects = is_extern_row
            && kerf::compiler::compile_program(items.as_ref().expect("the extern row expanded"))
                .is_err();
        let report = composed_target_chain_parity(name, &source);
        if is_extern_row && oracle_compile_rejects {
            extern_row += 1;
            assert!(
                report.drift.is_some(),
                "corpus case {name}: neg-062's row rides its disclosed twin-gap drift \
                 (junction 3 — the derived-symbol character police has no frozen-subset \
                 expression: the twin compiles on, the oracle rejects, the rebuild \
                 face's verify judge catches the hand-built table through the same floor)"
            );
            // The oracle routing must still classify the case — the
            // row change is the twin gap, not an oracle disagreement.
            let oracle_expanded = items.is_some();
            assert_eq!(
                expected_layer,
                if forms.is_none() {
                    ComposedLayer::Read
                } else if !oracle_expanded {
                    ComposedLayer::Expand
                } else {
                    ComposedLayer::Compile
                },
                "corpus case {name}: the oracle routing holds for the extern family"
            );
            continue;
        }
        if let Some(d) = report.drift.as_deref() {
            if d.starts_with("harness limit:") {
                // W-REC-DEPTH blade 2 (r137): the evaluator's depth
                // envelope retired with the blade-1 heap activation
                // stack — a harness-limit classification is now a
                // REGRESSION (the budget face stays honest, but no
                // corpus case may hit it anymore). Hard-fail instead
                // of re-verifying through the retired VM bracket.
                panic!("corpus case {name}: harness-limit classification is retired: {d}");
            } else if d.starts_with("harness boundary:") {
                // The honest data-injection boundary (the r103
                // exception ledger instantiated on junction 2's
                // feed): the `i64::MIN` datum family — no
                // target-skin text exists, the corpus face carries
                // these cases through arithmetic-composition twins.
                // Pinned as the boundary row, never a silent skip.
                boundary_row += 1;
                assert_eq!(
                    expected_layer,
                    ComposedLayer::Compile,
                    "corpus case {name}: the boundary family is oracle-compilable \
                     (the boundary is a data-face fact, not an oracle row change)"
                );
                continue;
            }
        }
        assert!(
            report.matched,
            "corpus case {name} (row {expected_layer:?}): {}",
            report.failure_line()
        );
        assert_eq!(
            report.layer, expected_layer,
            "corpus case {name}: the ledger row must match the oracle routing"
        );
        match expected_layer {
            ComposedLayer::Read => {
                read_row += 1;
                assert!(report.read_matched);
                assert_eq!(report.expand_matched, None);
                assert_eq!(report.compile_matched, None);
            }
            ComposedLayer::Expand => {
                expand_row += 1;
                assert!(report.read_matched);
                assert_eq!(report.expand_matched, Some(true));
                assert_eq!(report.compile_matched, None);
            }
            ComposedLayer::Compile => {
                compile_row += 1;
                assert_eq!(report.compile_matched, Some(true));
            }
        }
    }
    // The pinned ledger on the target skin: the 8/22/58 distribution
    // minus the 2-case boundary family (bnd-002/bnd-003 — the
    // `i64::MIN` literals), disclosed as the boundary row (the
    // corpus face carries them through arithmetic-composition
    // twins, switch-window-plan §5.6.2). r122: the expander twin
    // refresh moved the three extern expansion-rejection rows
    // (neg-059/060/061) from the extern special-case into this row
    // (19 -> 22) — the twin now rejects them with the oracle's own
    // keys at junction 2. r123: neg-062's expansion layer ACCEPTS
    // on both engines (the C-domain re-attribution), so the row
    // joins the junction-3 extern family while its compile-stage
    // rejection rides the corpus contract's new compile-error kind
    // (the expand_row count holds — neg-062 was never in it).
    // r124: the junction-3 consumption converged the two
    // oracle-accept rows (pos-037/neg-058 — products carry the
    // table, parity end-to-end) into the Compile row (56 -> 58).
    assert_eq!(read_row, 8, "the reader-layer row");
    assert_eq!(expand_row, 22, "the expander/loader row");
    assert_eq!(
        compile_row, 58,
        "the compiler-layer row (60 minus the boundary family and the one disclosed \
         extern drift: pos-037/neg-058 converged here, neg-062 stays below)"
    );
    assert_eq!(boundary_row, 2, "the i64::MIN data-boundary family");
    // W-3.2 + r122 + r123 + r124: the extern family's ledger after
    // the junction-3 consumption — the emit fix + cp_extern_walk +
    // the product tables collapsed the drift to the expressibility
    // boundary itself: ONE row (neg-062 — the derived-symbol
    // character police has no frozen-subset expression; the twin
    // compiles on, the oracle rejects, the rebuild face's verify
    // judge catches the hand-built table through the same floor).
    // The three expansion-rejection rows ride the normal Expand row
    // since the r122 refresh.
    assert_eq!(
        extern_row, 1,
        "the extern family's remaining disclosed twin-gap row (neg-062 only)"
    );
    assert_eq!(
        read_row + expand_row + compile_row + boundary_row + extern_row,
        91
    );
    // W-REC-DEPTH blade 2 (r137): the harness-limit bracket count is
    // ZERO by construction — the sweep panics on any harness-limit
    // classification, so reaching this assertion means every corpus
    // case (the deep-nesting family included) rode the dual face.
}

// ---------- negative: every routing row's error axis ----------

#[test]
fn reader_layer_rejections_route_to_junction_one_target() {
    deep_stack(|| {
        for (name, source) in [
            ("target-neg-unclosed", "(define result (+ 1 2)"),
            ("target-neg-unterminated-string", "(define s \"abc"),
        ] {
            let report = composed_target_chain_parity(name, source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Read, "{name}");
            assert_eq!(report.expand_matched, None, "{name}");
            assert_eq!(report.compile_matched, None, "{name}");
        }
    });
}

#[test]
fn expander_layer_rejections_route_to_junction_two_target() {
    deep_stack(|| {
        for (name, file) in [
            ("target-neg-unbound", "neg-013-unbound-reference.krf"),
            ("target-neg-malformed-fn", "neg-011-malformed-fn.krf"),
        ] {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
            let report = composed_target_chain_parity(name, &source);
            assert!(report.matched, "{name}: {}", report.failure_line());
            assert_eq!(report.layer, ComposedLayer::Expand, "{name}");
            assert!(report.read_matched, "{name}: junction 1 must pass");
            assert_eq!(report.expand_matched, Some(true), "{name}");
            assert_eq!(report.compile_matched, None, "{name}");
        }
    });
}

#[test]
fn the_compile_error_axis_rides_junction_three_target() {
    deep_stack(|| {
        // neg-057: the LA-7 assign-to-captured boundary — the oracle
        // pipeline rejects at the compile step, and the target
        // chain's junction 3 must reject identically.
        let source =
            std::fs::read_to_string(format!("{CORPUS_DIR}/neg-057-assign-to-captured.krf"))
                .expect("file");
        let report = composed_target_chain_parity("target-neg-assign-captured", &source);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
        assert_eq!(report.compile_matched, Some(true));
    });
}

// ---------- negative: the tamper probes, junction by junction ----------

#[test]
fn a_tampered_lexer_twin_fails_the_chain_at_junction_one() {
    deep_stack(|| {
        // The letter `n` (byte 110) ADDED to the whitespace table
        // (the r85 tamper's own semantics on the .ktf twin's
        // spelling): every `define` loses its `n` to trivia, the
        // token axis drifts, and the failure must surface AT
        // junction 1 — never fall through to junction 2.
        let tampered = LEXER_TARGET_SOURCE.replace("} else if b == 11 {", "} else if b == 110 {");
        assert_ne!(
            &tampered, LEXER_TARGET_SOURCE,
            "the tamper must land on a real anchor"
        );
        let report = composed_target_chain_probes(
            "target-tamper-lexer",
            "(define x 1)\n(define y (+ x 1))",
            Some(&tampered),
            None,
            None,
        );
        assert!(
            !report.matched,
            "the tampered lexer twin must fail the chain"
        );
        assert_eq!(report.layer, ComposedLayer::Read);
        assert!(!report.read_matched);
        assert_eq!(
            report.expand_matched, None,
            "the chain must stop at junction 1"
        );
    });
}

#[test]
fn a_tampered_expander_twin_fails_the_chain_at_junction_two() {
    deep_stack(|| {
        // The 1.6 depth-guard tamper (CP9-5's precedent, on the
        // .ktf twin's snake-case spelling): junction 1 passes, the
        // tampered expander rejects, and the failure must surface AT
        // junction 2 — never fall through to junction 3.
        let tampered =
            assembled_expander_target_source().replace("ex_depth >= 512", "ex_depth >= 2");
        assert_ne!(
            &tampered,
            &assembled_expander_target_source(),
            "the tamper must land on a real anchor"
        );
        let report = composed_target_chain_probes(
            "target-tamper-expander",
            "(define x (do 1 (do 2 3)))",
            None,
            Some(&tampered),
            None,
        );
        assert!(
            !report.matched,
            "the tampered expander twin must fail the chain"
        );
        assert_eq!(report.layer, ComposedLayer::Expand);
        assert!(report.read_matched, "junction 1 must pass");
        assert_eq!(report.expand_matched, Some(false));
        assert_eq!(
            report.compile_matched, None,
            "the chain must stop at junction 2"
        );
    });
}

#[test]
fn a_tampered_compiler_twin_fails_the_chain_at_junction_three() {
    deep_stack(|| {
        // The CP7 globals tamper on the .ktf twin's own spelling:
        // the var arm's global fallback removed — free names stop
        // interning, and the product axis drifts at junction 3
        // (junctions 1/2 untampered, passing).
        // W-VM-SUPERINSTR note: the probe must reference a global
        // that is NOT the zeroth interned slot. Post-fusion the
        // `+` callee rides the fused call-global arm (untampered),
        // so the tamper's only visible face is the argument's
        // var-arm load — `y` alone (slot 0) would load the correct
        // slot by coincidence; `z` (a later slot) makes the drift
        // structural.
        let tampered = COMPILER_TARGET_SOURCE.replace(
            "cp_emit(\"load-global\", cp_intern_global(name), 0, cp_span_of(t))",
            "cp_emit(\"load-global\", 0, 0, cp_span_of(t))",
        );
        assert_ne!(
            &tampered, COMPILER_TARGET_SOURCE,
            "the tamper must land on a real anchor"
        );
        let report = composed_target_chain_probes(
            "target-tamper-compiler",
            "(define y 1)\n(define z 2)\n(define x (+ y z))",
            None,
            None,
            Some(&tampered),
        );
        assert!(
            !report.matched,
            "the tampered compiler twin must fail the chain"
        );
        assert_eq!(report.layer, ComposedLayer::Compile);
        assert!(report.read_matched, "junction 1 must pass");
        assert_eq!(report.expand_matched, Some(true), "junction 2 must pass");
        assert_eq!(report.compile_matched, Some(false));
    });
}

// ---------- the honest envelope, retired ----------

#[test]
fn the_deep_nesting_family_rides_the_dual_face() {
    deep_stack(|| {
        // bnd-006's 255-deep if chain once rode past the evaluator's
        // per-element envelope (the r74/r85 K165/K166 VM bracket);
        // the W-REC-DEPTH blade-1 heap activation stack retired that
        // envelope (r137) — the family now matches on the DUAL face
        // with both engines agreeing, and the ledger row stays
        // Compile.
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/bnd-006-nesting-255-ok.krf"))
            .expect("file");
        // W-REC-DEPTH blade 2 (r137): the evaluator's depth envelope
        // retired with the blade-1 heap activation stack — the
        // deep-nesting family now rides the DUAL face directly (the
        // VM bracket lineage r74/r85 is retired, not widened).
        let dual = composed_target_chain_parity("target-bracket-dual", &source);
        assert!(
            dual.matched,
            "the deep-nesting family must match on the dual face: {}",
            dual.failure_line()
        );
        assert_eq!(dual.layer, ComposedLayer::Compile);
        assert!(
            dual.engines_agree,
            "both engines must agree on the deep-nesting family"
        );
    });
}

// ---------- the boundary pin: the .ktf twin sources through the
// production bridge are the step-4 face, not this chain's input ----------

#[test]
fn the_reader_twin_source_itself_stays_the_parity_oracle_reference() {
    deep_stack(|| {
        // READER_TARGET_SOURCE is the .ktf twin — the chain PROGRAM,
        // never the chain INPUT. The oracle for every axis of this
        // chain stays the Rust seed reader (`read_program`), pinned
        // by the anchors above; this pin guards the harness's own
        // single-source discipline (a harness that fed the twin
        // source to itself on the read side would be testing the
        // wrong face — the step-4 fixpoint owns that face).
        assert!(
            READER_TARGET_SOURCE.contains("fn rd_loop"),
            "the reader twin's canonical entry is present"
        );
        assert!(
            READER_TARGET_SOURCE.contains("define(result, rd_loop(tokens, nil, nil));"),
            "the reader twin's hosting tail is present (the strip anchor)"
        );
    });
}

// ---------- the i64::MIN data boundary: classified, pinned,
// never hidden ----------

#[test]
fn the_i64_min_datum_boundary_is_classified_not_hidden() {
    deep_stack(|| {
        // bnd-002 (the i64::MIN literal) and bnd-003 (the sub-MIN
        // overflow): the oracle accepts both (Compile-row sources on
        // the .krf chain), but the junction-2 feed's form records
        // carry an `i64::MIN` datum — a value with NO target-skin
        // literal (the magnitude overflows before the sign applies).
        // The chain must CLASSIFY these at the boundary (the honest
        // disclosed row), and the corpus face's carry — the
        // arithmetic-composition twins — is the r103 closeout's own
        // family (switch-window-plan §5.6.2). Junction 1 still
        // passes on both engines (the byte table is skin-less).
        for (name, file) in [
            ("target-boundary-i64-min", "bnd-002-i64-min.krf"),
            ("target-boundary-sub-min", "bnd-003-sub-min-overflow.krf"),
        ] {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
            let report = composed_target_chain_parity(name, &source);
            assert!(
                !report.matched,
                "{name}: the boundary family must not claim a match"
            );
            let drift = report
                .drift
                .as_deref()
                .expect("the boundary drift is present");
            assert!(
                drift.starts_with("harness boundary:"),
                "{name}: the drift must be the boundary classification: {drift}"
            );
            assert!(
                report.read_matched,
                "{name}: junction 1 still passes (the byte table is skin-less)"
            );
        }
        // The negative-literal family BELOW the boundary rides
        // fine: -7 and -3.5 datums read back through the target
        // lexer (the magnitude is in range, the sign applies) — the
        // anchors' payload family already proves it end to end.
        let report = composed_target_chain_parity("target-boundary-minus-seven", "(define n -7)");
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.layer, ComposedLayer::Compile);
    });
}

// ---------- the W-3.12-a measurement face (Stage 3.1) ----------
//
// An `#[ignore]`d measurement (the `b_face_measurement_c_vs_vm`
// lineage): it prices the junction-1 upgrade question — what
// switching the production read step to the self-hosted reader
// chain (lexer.ktf + reader.ktf on the VM) would cost per read,
// against the Rust oracle it would replace. The numbers land in
// `docs/develop/v3/w3.12-frontend-window.md` (MUV 3.12-a); the
// face is manual (`--ignored --nocapture`), never a regression
// gate. Three sizes ride the same anchor family the B series uses
// (fib) plus the corpus's boundary shapes, so the per-read cost's
// source-size dependence is visible alongside the fixed twin cost.
#[test]
#[ignore = "W-3.12-a measurement face: run with --ignored --nocapture"]
fn w312a_selfhost_read_face_vs_rust_oracle() {
    use std::hint::black_box;
    use std::time::Instant;

    use kerf::compiler::compile_program;
    use kerf::driver::Session;
    use kerf::driver::{
        LEXER_TARGET_SOURCE, READER_TARGET_SOURCE, SteadyReaderChain, target_byte_table_prefix,
    };
    use kerf::driver::{Severity, parse_target};
    use kerf::span::FileId;
    use kerf::vm::{BufferIo, Vm};

    use kerf::reader::read_program;

    const ITERS: usize = 30;
    let sources: &[(&str, &str)] = &[
        (
            "fib-anchor",
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))",
        ),
        (
            "nesting-255-ok",
            include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/tests/v1/stage1/corpus/bnd-006-nesting-255-ok.krf"
            )),
        ),
    ];
    for (name, source) in sources {
        let assembled = format!(
            "{}\n{}\n{}",
            target_byte_table_prefix(black_box(source)),
            LEXER_TARGET_SOURCE,
            READER_TARGET_SOURCE
        );
        // Warmup + correctness: the chain must read the source (the
        // result global is set by reader.ktf's final define).
        let build = || {
            let mut session = Session::new();
            let program = parse_target(&mut session, "w312a-host.ktf", &assembled)
                .expect("assembled twin program parses");
            let findings = program.typecheck();
            assert!(
                !findings.iter().any(|d| d.severity == Severity::Error),
                "assembled twin program typechecks"
            );
            compile_program(&program.items).expect("assembled twin program compiles")
        };
        let run = |bc: kerf::compiler::Bytecode| {
            let mut vm = Vm::with_io(bc, Box::new(BufferIo::default())).expect("vm accepts");
            vm.run().expect("the twin chain halts");
            vm
        };
        for _ in 0..3 {
            run(build());
        }
        // Compile share (today's injection form: the byte table rides
        // the program text, so this recompiles per source — the
        // harness upper bound, disclosed as such in the evaluation).
        let mut compile_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            build();
            compile_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        // VM share (steady-state: the twins executing, the source
        // arriving as the injected byte table).
        let bc = build();
        let mut vm_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            run(bc.clone());
            vm_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        // The PRODUCTIONIZED steady state (r121): the real
        // SteadyReaderChain — the once-compiled fixed twin program,
        // every read a fresh VM + the injection-channel bind + the
        // run + the decode. This is the number the window record's
        // implementation table carries.
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let mut steady_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            chain.read(source).expect("the steady read halts");
            steady_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        // The Rust oracle share (the seed-chain reader the twins
        // would replace in production).
        let mut rust_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            let _ = read_program(FileId(0), black_box(source));
            rust_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        let median = |v: &[f64]| {
            let mut s = v.to_vec();
            s.sort_by(|a, b| a.partial_cmp(b).expect("finite"));
            s[s.len() / 2]
        };
        println!(
            "W-3.12-a [{name} | {}B]: assembled-compile median {:.1}µs, twins-on-vm median {:.3}ms, steady-chain-read median {:.3}ms (r121 productionized), rust-read median {:.2}µs — vm/rust {:.0}x, steady/rust {:.0}x",
            source.len(),
            median(&compile_ns) / 1e3,
            median(&vm_ns) / 1e6,
            median(&steady_ns) / 1e6,
            median(&rust_ns) / 1e3,
            median(&vm_ns) / median(&rust_ns),
            median(&steady_ns) / median(&rust_ns),
        );
    }
}

/// The W-3.12 segment-two measurement face (r122, the w312a
/// lineage): the steady expander chain's per-expansion cost vs the
/// Rust expansion oracle — the same two-size anchor family (a
/// fib-anchor program and the corpus's nesting-255-ok boundary
/// row), medians over 30 runs, warmup ×3, `black_box` fences
/// (§9.61 PERF-2). Manual face (never in the regression gate); the
/// numbers land in the window record's segment-two table (§1b) as
/// the single source.
#[test]
#[ignore = "the manual measurement face — run explicitly, numbers land in the window record"]
fn w312b_steady_expander_face_vs_rust_oracle() {
    use std::hint::black_box;
    use std::time::Instant;

    use kerf::driver::SteadyExpanderChain;
    use kerf::expander::expand_program;
    use kerf::reader::read_program;
    use kerf::span::FileId;

    const ITERS: usize = 30;
    let sources: &[(&str, &str)] = &[
        (
            "fib-anchor",
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))",
        ),
        (
            "nesting-255-ok",
            include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/tests/v1/stage1/corpus/bnd-006-nesting-255-ok.krf"
            )),
        ),
    ];
    for (name, source) in sources {
        let forms = read_program(FileId(0), source).expect("the source reads");
        // Warmup + correctness: the chain must expand the stream and
        // match the oracle's own expansion text.
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let oracle = kerf::driver::oracle_expansion_axes(black_box(&forms));
        for _ in 0..3 {
            let outcome = chain
                .expand(black_box(&forms))
                .expect("the steady expansion halts");
            assert_eq!(
                outcome.text,
                match &oracle {
                    Ok(dump) => dump.clone(),
                    Err(key) => key.clone(),
                },
                "the steady expansion matches the oracle (warmup correctness)"
            );
        }
        // The steady chain share (per expansion: fresh VM + the
        // injection bind + the run + the decode — the once-compiled
        // product never recompiles).
        let mut steady_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            chain
                .expand(black_box(&forms))
                .expect("the steady expansion halts");
            steady_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        // The Rust oracle share (the seed-chain expander the twins
        // would replace in production).
        let mut rust_ns = Vec::with_capacity(ITERS);
        for _ in 0..ITERS {
            let t = Instant::now();
            let _ = expand_program(black_box(&forms));
            rust_ns.push(t.elapsed().as_secs_f64() * 1e9);
        }
        let median = |v: &[f64]| {
            let mut s = v.to_vec();
            s.sort_by(|a, b| a.partial_cmp(b).expect("finite"));
            s[s.len() / 2]
        };
        println!(
            "W-3.12-b [{name} | {}B]: steady-expander median {:.3}ms, rust-expand median {:.2}µs — steady/rust {:.0}x",
            source.len(),
            median(&steady_ns) / 1e6,
            median(&rust_ns) / 1e3,
            median(&steady_ns) / median(&rust_ns),
        );
    }
}

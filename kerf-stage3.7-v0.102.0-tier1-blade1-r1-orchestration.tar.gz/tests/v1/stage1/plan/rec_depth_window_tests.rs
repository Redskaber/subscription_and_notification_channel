//! The W-REC-DEPTH blade 2 window tests (r137, bootstrap-completion-
//! plan.md §4.1; the K162 ruling's engineering face): the four
//! conservative depth guardrails (reader 256 / expander 512 /
//! compiler 1024 / pkg-resolve 512) stay the DEFAULTS — behavior
//! byte-for-byte — while every layer gains an explicit `with_limit`
//! face for deep synthesized sources, and the driver CLI reads the
//! environment overrides through one fail-closed consumer
//! (`DepthLimits::from_env` at `Session::with_limits`).
//!
//! The fixpoint's r74/r85 VM-only brackets are RETIRED by the same
//! blade (the composed-chain and fixpoint tests assert the DUAL face
//! directly — those live in their own files; this file owns the
//! guardrail parameterization face).

use kerf::compiler::{COMPILE_DEPTH_LIMIT, compile_with_limit};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{DepthLimits, Session};
use kerf::expander::{EXPANSION_LIMIT, expand_program_with_limit};
use kerf::pkg::{PkgError, resolve_with_limit};
use kerf::reader::{
    NESTING_LIMIT, ReadError, read_program, read_program_with_limit, read_target_program_with_limit,
};
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

fn span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("the audit span is well-formed by construction")
}

/// `n` nested lists around a `1` atom — the reader's deep-nesting
/// probe shape (the parser.rs inline-test form, lifted to the
/// window's own face).
fn deep_lists(n: usize) -> String {
    let mut src = String::new();
    for _ in 0..n {
        src.push('(');
    }
    src.push('1');
    for _ in 0..n {
        src.push(')');
    }
    src
}

/// `n` nested `if` forms around a `1` atom — the expander's deep
/// work-budget probe (each nesting level costs one `enter`).
fn deep_ifs(n: usize) -> String {
    let mut src = String::new();
    for _ in 0..n {
        src.push_str("(if 1 ");
    }
    src.push('1');
    for _ in 0..n {
        src.push_str(" 1)");
    }
    src
}

/// `n` nested applications of `f` around a literal — the compiler's
/// deep-recursion probe (the compile.rs inline-test form).
fn deep_apply(n: usize) -> CoreExpr {
    let mut e = CoreExpr::Literal {
        span: span(),
        value: LiteralValue::Int(42),
    };
    for _ in 0..n {
        e = CoreExpr::Apply {
            span: span(),
            func: Box::new(CoreExpr::Var {
                span: span(),
                name: kerf::span::Symbol::new("f").expect("probe symbol is valid"),
            }),
            args: vec![e],
        };
    }
    e
}

fn read_and_expand(source: &str) -> Vec<ModuleItem> {
    let forms = read_program(FileId(0), source).expect("the probe reads at the default cap");
    kerf::expander::expand_program(&forms).expect("the probe expands at the default cap")
}

/// Run one body on a thread with a large stack: the deep probes
/// below build and DROP trees hundreds of levels deep (the demand-
/// allocated stack discipline of the sibling window tests).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- positive: the with_limit faces carry deep sources ----------

#[test]
fn reader_with_limit_reads_nesting_beyond_the_default() {
    deep_stack(|| {
        // 600 lists past the 256 default: the raised cap reads it,
        // and the measured depth is exact (root + 600 nested).
        let forms = read_program_with_limit(FileId(0), &deep_lists(600), NESTING_LIMIT * 2 + 88)
            .expect("600-deep nesting reads under a raised cap");
        let mut depth = 1usize;
        let mut walk = &forms[0];
        loop {
            match &walk.datum {
                kerf::syntax::StxDatum::List(items) if !items.is_empty() => {
                    depth += 1;
                    walk = &items[0];
                }
                _ => break,
            }
        }
        assert_eq!(depth, 601, "root + 600 nested lists");
    });
}

#[test]
fn target_reader_with_limit_reads_nesting_beyond_the_default() {
    deep_stack(|| {
        // The target-skin twin of the reader face: the same paren
        // probe wrapped in a `define` statement (the target item
        // grammar — a bare paren run is not an item), read through
        // `read_target_program_with_limit` under a raised cap; the
        // DEFAULT cap rejects the same source with the structured
        // nesting error.
        let source = format!("define(r, {});", deep_lists(600));
        let forms = read_target_program_with_limit(FileId(0), &source, 1024)
            .expect("600-deep target nesting reads under a raised cap");
        assert_eq!(forms.len(), 1, "the deep probe produced its define");
        let err = read_target_program_with_limit(FileId(0), &source, NESTING_LIMIT)
            .expect_err("the default cap still rejects the deep target source");
        assert!(
            matches!(err, ReadError::NestingDepthExceeded { .. }),
            "the default rejection is the nesting cap: {err:?}"
        );
    });
}

#[test]
fn expander_with_limit_expands_nesting_beyond_the_default() {
    deep_stack(|| {
        // 700 nested ifs past the 512 default: reading needs the
        // raised reader cap too, then the raised expansion budget
        // carries the walk (each nesting level costs one `enter`).
        let source = format!("(define probe {})", deep_ifs(700));
        let forms = read_program_with_limit(FileId(0), &source, 1024)
            .expect("the 700-deep if chain reads under a raised reader cap");
        let items = expand_program_with_limit(&forms, 2048)
            .expect("the 700-deep if chain expands under a raised budget");
        assert_eq!(items.len(), 1, "one define");
    });
}

#[test]
fn compiler_with_limit_compiles_depth_beyond_the_default() {
    deep_stack(|| {
        // 2000 nested applications past the 1024 default: the
        // raised cap compiles it; the default cap still rejects the
        // SAME tree with the structured error (the golden behavior,
        // unchanged).
        let ok = compile_with_limit(&deep_apply(2000), 4096)
            .expect("2000-deep application compiles under a raised cap");
        assert!(!ok.funcs.is_empty(), "the product carries its protos");
        let err = compile_with_limit(&deep_apply(2000), COMPILE_DEPTH_LIMIT)
            .expect_err("the default cap still rejects the deep tree");
        assert!(
            matches!(err, kerf::compiler::CompileError::DepthExceeded { depth, .. } if depth == COMPILE_DEPTH_LIMIT + 1),
            "the structured depth error carries the default cap: {err:?}"
        );
    });
}

#[test]
fn pkg_resolve_with_limit_carries_a_deep_chain_beyond_the_default() {
    // A 3-deep dependency chain under a tight cap of 2: the walk
    // fails closed with the structured depth error naming the cap;
    // under a raised cap the same graph resolves. The default (512)
    // stays untouched — its face is the golden rejection, pinned in
    // the crate's own inline tests.
    let tag = format!("recdepth-deep-{}", std::process::id());
    let dir = std::env::temp_dir().join(&tag);
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("fixture dir creates");
    let manifest = |name: &str, dep: Option<&str>| match dep {
        Some(dep) => {
            format!("package = \"{name}\"\nversion = \"0.1.0\"\n\n[depends]\n{dep} = \"0.1\"\n")
        }
        None => format!("package = \"{name}\"\nversion = \"0.1.0\"\n"),
    };
    std::fs::write(dir.join("kerf.toml"), manifest("root", Some("d0"))).expect("root writes");
    let mut parent = dir.clone();
    for i in 0..3 {
        let lib = parent.join("libs").join(format!("d{i}"));
        std::fs::create_dir_all(&lib).expect("lib dir creates");
        let dep = if i + 1 < 3 {
            Some(format!("d{}", i + 1))
        } else {
            None
        };
        std::fs::write(
            lib.join("kerf.toml"),
            manifest(&format!("d{i}"), dep.as_deref()),
        )
        .expect("lib manifest writes");
        parent = lib;
    }
    match resolve_with_limit(&dir, 2) {
        Err(PkgError::DepthLimitExceeded { limit, package }) => {
            assert_eq!(limit, 2, "the structured error names the configured cap");
            assert_eq!(package, "d2", "the over-depth package is named");
        }
        other => panic!("expected the tight-cap rejection, got {other:?}"),
    }
    let full = resolve_with_limit(&dir, 512).expect("the same chain resolves under the raised cap");
    assert_eq!(full.order.len(), 4, "root + three libs");
    let _ = std::fs::remove_dir_all(&dir);
}

// ---------- negative: the defaults are golden, the overrides fail closed ----------

#[test]
fn reader_default_cap_rejects_257_deep_nesting_unchanged() {
    // The golden boundary: 256-deep reads, 257-deep rejects with the
    // structured error naming the DEFAULT cap — the with_limit work
    // changed nothing about the default path.
    read_program(FileId(0), &deep_lists(NESTING_LIMIT))
        .expect("256-deep nesting stays legal at the default");
    let err = read_program(FileId(0), &deep_lists(NESTING_LIMIT + 1))
        .expect_err("257-deep nesting still rejects at the default");
    assert!(
        matches!(&err, ReadError::NestingDepthExceeded { depth, limit }
            if *depth == NESTING_LIMIT + 1 && *limit == NESTING_LIMIT),
        "the default rejection carries the default cap: {err:?}"
    );
}

#[test]
fn reader_with_limit_zero_rejects_the_first_list() {
    // The degenerate override: a cap of 0 rejects the very first
    // list (depth 1 > 0) — fail-closed, never a panic.
    let err = read_program_with_limit(FileId(0), "(define r 1)", 0)
        .expect_err("the zero cap rejects the first list");
    assert!(
        matches!(&err, ReadError::NestingDepthExceeded { depth, limit } if *depth == 1 && *limit == 0),
        "the zero cap is the structured rejection, not a panic: {err:?}"
    );
}

#[test]
fn expander_with_limit_tight_rejects_nested_forms() {
    // A budget of 2 admits exactly two nested levels of expansion
    // work and rejects the third — the boundary is exact, not fuzzy.
    let source = format!("(define probe {})", deep_ifs(3));
    let forms = read_program_with_limit(FileId(0), &source, 64).expect("the 3-deep probe reads");
    let err = expand_program_with_limit(&forms, 2)
        .expect_err("the tight budget rejects the third nesting level");
    assert!(
        matches!(err, kerf::expander::ExpandError::ExpansionDepthExceeded { limit, .. } if limit == 2),
        "the structured error names the configured budget: {err:?}"
    );
}

#[test]
fn compiler_with_limit_tight_rejects_deep_apply() {
    // A recursion cap of 10 rejects an 11-deep application with the
    // configured cap in the structured error.
    let err = compile_with_limit(&deep_apply(11), 10)
        .expect_err("the tight cap rejects the deep application");
    assert!(
        matches!(err, kerf::compiler::CompileError::DepthExceeded { depth, .. } if depth == 11),
        "the structured error carries depth 11 (cap + 1): {err:?}"
    );
}

#[test]
fn depth_limits_default_pins_the_conservative_constants() {
    // The driver face: `DepthLimits::default()` IS the three crate
    // constants — and a fresh `Session` carries exactly those (the
    // library face never reads the environment implicitly).
    let defaults = DepthLimits::default();
    assert_eq!(defaults.reader_nesting, NESTING_LIMIT);
    assert_eq!(defaults.expansion, EXPANSION_LIMIT);
    assert_eq!(defaults.compile_depth, COMPILE_DEPTH_LIMIT);
    let session = Session::new();
    assert_eq!(*session.limits(), defaults);
    assert_eq!(*Session::with_limits(defaults).limits(), defaults);
}

#[test]
fn depth_limit_env_parsing_validates_and_fails_closed() {
    // The pure core of `DepthLimits::from_env` (the parse function
    // is private; from_env is exercised through the same validator):
    // a clean environment (no KERF_* variables set) yields exactly
    // the defaults, and the message shape is the fail-closed English
    // form (R8 — lowercase, no trailing period).
    let limits = DepthLimits::from_env().expect("a clean environment parses");
    assert_eq!(limits, DepthLimits::default());
}

// ---------- integration: the raised caps flow through the pipeline ----------

#[test]
fn session_with_limits_carries_deep_sources_through_parse() {
    deep_stack(|| {
        // The end-to-end integration face (the MUV's verification
        // case): a deep synthesized program (600-deep if chain inside
        // a define) — far past the reader's 256 default — reads and
        // expands through a session carrying raised guardrails,
        // while the default session rejects the same source at the
        // reader boundary. (The typecheck leg rides a shallow probe:
        // HM inference over a 600-deep if chain is a checker-budget
        // concern, not a guardrail concern.)
        let source = format!("(define probe {})", deep_ifs(600));
        let mut raised = Session::with_limits(DepthLimits {
            reader_nesting: 1024,
            expansion: 2048,
            compile_depth: 4096,
        });
        let program = kerf::driver::parse(&mut raised, "deep-probe.krf", &source)
            .expect("the deep program parses under the raised guardrails");
        assert_eq!(program.items.len(), 1, "the define survives the walk");
        let mut default_session = Session::new();
        let err = kerf::driver::parse(&mut default_session, "deep-probe.krf", &source)
            .expect_err("the default guardrails reject the deep program");
        assert!(
            err.iter().any(|d| d.message.contains("nesting")),
            "the rejection is the reader's nesting cap: {err:?}"
        );
        // The full check pipeline on a shallow probe through the
        // raised session: findings stay warning-free at the error
        // level (the guardrails never leak into the verdicts).
        let shallow = kerf::driver::parse(&mut raised, "shallow-probe.krf", "(define q (+ 1 2))")
            .expect("the shallow probe parses");
        let findings = shallow.typecheck();
        assert!(
            !findings
                .iter()
                .any(|d| d.severity == kerf::driver::Severity::Error),
            "the shallow program checks without error findings: {findings:?}"
        );
    });
}

#[test]
fn read_and_expand_helper_stays_within_defaults() {
    // A sanity pin for this file's own helper: the shallow probes
    // the negative cases use read and expand under the DEFAULT caps
    // (the helper itself is not limit-dependent).
    let items = read_and_expand("(define shallow (+ 1 2))");
    assert_eq!(items.len(), 1);
}

# kerf v0.102.0 — W-JIT-METHOD-T1 tier-1 刀 1：方法编译基础设施（r141）

第一百四十一轮（r141 · Task 141）· SOP v15.3 §21.12-28 自举完备优先 · W-JIT-METHOD-T1 窗内刀 1（G3 性能前置——tier-1 两刀之一）· L3 常规轮（VM 执行核心域 + 测试面 + 审计面全链）。

## 本轮交付

- **tier-1 刀级四裁定 MJ-1..MJ-4（w-jit-method-t1-window.md v1.1 §7——K158 菜单的操作化）**：MJ-1 执行形 = closure chain（链接闭包链——每节点恰一条指令的语义，1:1 镜像解释器臂：节点体调用与臂相同的 arm_* 辅助函数同序同载荷——**语义等价是构造性的非统计性的**〔r134 F1 先例形制〕；诚实注记 = Rc 直链在安全 Rust 前向引用下须内部可变性，其每步成本超过它要替代的索引——后继链接走 pc 索引表，刀 2 B 轴实测裁决）；MJ-2 census = per-function 闭包调用计数（invoke 闭包臂每调用 +1 非每指令 +1；METHOD_HOT_THRESHOLD = 64 两端论证〔fib-25 242,785 ≫ 64 摊销 / 一次性程序 1 ≪ 64 冷函数永不编译——F5 机制化〕；触达当次调用走编译链；失败永久回退无重试）；MJ-3 编译边界 = 整函数粒度 + 帧边界引擎选择（绝不混链；mid-method 重入经 pc 索引表；pc 纪律 = 驱动器单源 fetch 等价推进）；MJ-4 确定性 = 同 Bytecode 恒同链（canonical listing 可序列化比对）+ 双路同值（值/输出/错误/预算账逐位）。
- **实施全链（kerf-vm + 跨 crate 测试/审计）**：`crates/kerf-vm/src/methodjit.rs` 新模块（MethodChain 纯函数构建 + 悬挂跳转/空体/未知函数 fail-closed 纵深防御 + canonical listing + MethodJit census 状态机〔Cold/Hot/Failed〕）；vm.rs 臂提取重构（15 个 arm_* pub(crate) 单源镜像面 + 4 个 shim——两引擎共用同函数；解释器臂成为 arm_* 调用者）；run_dispatch loop-top 引擎选择（一次 Option 探测/迭代——刀 2 B 轴实测）+ run_compiled_frame 驱动器（const 泛型 OBSERVE 单化——观察三元组由驱动器上报，census 测量面零扰动）；invoke 闭包臂 note_invoke 计数钩子；Vm 构造器/策略面（with_method_tier_threshold + set_method_tier_threshold + method_tier() 观察面）。
- **构造性 parity 实证（刀 1 验收三腿全绿）**：双路同值（同程序阈值 u32::MAX 纯解释 vs 阈值 1 全编译 vs 默认 64 自然穿越——值/输出/allocations 逐位一致）；回退触发实测（构建器三拒绝面直调 + 健康运行零 Failed 记录——Verified 面上结构性不可达 = 纵深防御分层本身）；确定性（两次构建 listing 逐位相等 + 形变移动 listing）。
- **测试面（GATE 6 正负 1:3）**：method_jit_window_tests 新族 8 件（正 2/负 6：双路同值与账目 [MUV 141-b 集成验证用例] + 链确定性 | 构建器 fail-closed + 错误路径位级一致 [TypeMismatch/DivByZero 双族] + 预算边界 parity [BudgetExceeded 同位同账] + census 流零扰动 [观察三元组逐位] + 深递归堆帧纪律 [sum 2000] + entry 下界与 halt 边）；audit **AW 族 10 案**（380→390 live · 47→48 节：AW01-AW10 对应族面 + 默认 64 阈值边界〔63 次不编译/64 次编译〕）；TEST-3 守卫共变（494 总 = 390 live + 104 retired + 头行字面量）。
- **基线迁移**：test --release **1599:0:4 → 1607:0:4**（+8 新族——tier 机制默认激活下全树绿 = 构造性 parity 的全树实证〔fixpoint/gate B/parity/census 锚/gc/rec-depth 10^5 全部在 tier 开启态运行通过〕）；audit 390/390 · 48 节；六命令 clean 冷跑全绿（build 0e0w 18s / check 0/0 / fmt 零 diff / clippy -D warnings 零 / doc 唯一 cargo#6313）；R8 编码面扫描清零（新代码面全英文）。
- **零编译面变更**：操作码面 27 维持、零新原语、零 .ktf 孪生变更（tier = 运行期机制非编译期）——S-expr 转化台账维持九件 14,243 行（零新转化面）；快照黄金族零再生成（指令流不变）。
- **B 轴对照与守卫族再生成 = 刀 2 排期**（w-jit-method-t1-window.md §3 切轮表 + §7 交付范围声明——MUV 边界不降级）：tier-0.5 LLC 协作精化 + B 轴对照 tier-0.5 收尾基线三跑 + 三触发器复画像 + 守卫族再生成。

## 验收

- 六命令（cargo clean 冷跑，OBS 口径）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1607:0:4**（+8） / doc 唯一 cargo#6313；audit **390/390 live + 104 retired · 48 节**（AW 族 10 案——实施窗增节形制沿 r124-r139 先例）。
- 8 原语不变性第一百零三轮验证：零新原语/零新内建/零语法增改/零操作码面变更（tier = VM 执行层机制；VM 永久 Rust 基座宪制排除项维持——本刀为基座内优化非重写）。
- S-expr 转化记录：零新转化面（tier = Rust 侧执行层——零 .ktf 孪生变更；台账维持九件 14,243 行）。
- 自举矩阵实态：G1 ✓ + G2 ✓ + **G3 在窗（tier-1 刀 1 ✓——下一刀 = 刀 2 tier 分派集成/守卫/audit/B 轴）** + G4-G6 后置 + G7/G8 在册；C1 ✓ / C3 ✓ / C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 在窗）/ C4 ✗。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 2**（tier 分派集成 + LLC 协作精化 + 守卫族再生成 + audit AX + B 轴对照三跑 + 三触发器复画像——窗口出口条件 §4）∥ TD-027（T-a 前置门在册）。

---
# kerf v0.101.0 — 自举完备总规划 v1.5：语言基础时点裁定 + S-expr 拆除窗入序 + 转化台账（r140）

第一百四十轮（r140 · Task 140）· SOP v15.3 §21.12-28 自举完备优先 · 规划刷新轮（bootstrap-completion-plan.md v1.4→v1.5——G1 ✓ / G2 ✓ 闭合后的窗口序列重整 + 用户 15 条指令族承载）· 单轮规划域（零代码变更——六命令基线维持验证）。

## 本轮交付

- **两新窗入序（§3 序 4/序 7 + §4.4/§4.5 细粒度 MUV）**：**W-SEXP-RETIRE**（G7——S-expr 脚手架拆除窗：语料单皮肤迁移 → S-expr 读链退役 → 面清零扫描守卫化三刀；前置 = T-a step ④ read 段生产位 + TD-027；R5 拆除判据双臂满足——target 读链全语料覆盖 + 类型注解语法/胖关键字额外能力；先于 W-EVAL-RETIRE 的技术理由 = 最大表面迁移需双引擎 parity 安全网在场）+ **W-LANG-FOUNDATION**（G8——语言基础完备窗：类型注解消费面 → struct 脱糖 → enum 脱糖 + 穷尽性 → 模式匹配扩展 + 行多态评估窗四刀；前置 = 自举完备验收 C1-C4 + 单皮肤终态——§21.12-28① 从属位法定解除对象；工作流 = 自托管[编辑 .ktf → kerf 编译 → 测试经 VM]——C4 面首个生产消费）。
- **G7/G8 缺口行补全（§2 现状地图）**：S-expr 表面存续（双皮肤态——用户指令⑥「完全自举后完全使用目标语言词法语法语义」未兑现 = 自举终态组成缺口）+ 语言基础面未完备（struct/enum/注解消费 = Stage 2+ 登记态——stage0 §9.14.2 R4 实况对账）入账；G2 行刷新为已闭合（r136/r137——C3 终态）。
- **enum/struct 时点裁定（§9——用户审查问题正面回答）**：**时机未到（非遗忘）**——设计登记在位（stage0 §9.14.2 类型系统成员 + §7.4 内部语法 ADT 设计）+ 语法桥生产在位（target parser parse_type_drop:1602——注解全族解析后 drop）+ 实现窗法定 C2 后；三层结构性理由（冻结子集 = 自举目标面 / 串行自举硬规则 / 生产位切换后语言经自身推进——K140-K142 先例族投影）；与 8 原语不变性零冲突（struct/enum = 派生表面语法糖非原语面）；「当前这样好」的边界 = C1-C4 前是（纪律正确）、作为终态否（G8 入账 + 窗入序 = 不可无限推迟）。
- **S-expr→目标语言完全转化统一记录新建**（docs/develop/v3/s-expr-conversion-record.md v1.0——用户指令⑫落位）：九件 14,243 行逐件台账（lexer 671/reader 141/macro 686/expander 1,671/compiler 1,804/infer 3,690/typecheck 1,234/target-lexer 1,065/target-parser 3,281）+ 刀级谱系（r100 首波五件 → r121-r124 段族 → r126-r131 HM 刀族 → r133-r135 融合共变 → r136/r138 目标孪生 → r139 C1 闭合）+ 未转化面清点（G7 拆除对象）+ 三处单源登记义务 + 审计口径（wc -l 与台账累计行互证）。
- **roadmap §6 当前位置行 r140 刷新**（r120 滞留 19 轮的文档同步缺口清偿——§8.4.5 文档与代码冲突以代码为准 + 提交修正文档）：G1/G2/G3/G4 实态 + 窗口序列单源指针（bootstrap-completion-plan v1.5 §3 序 1-7）。
- **冻结问题重审对账（用户指令③——tech-debt r140 检视节承载）**：r135 W-PKG-SELFHOST 反冻结改写维持；subset-spec「Frozen」= 实现面诚实快照非政策性冻结（语义翻转经 MUV 合法行使三次先例）；§3.2 内核冻结 = 设计宪法锚与数据类型表面化正交——零「因冻结导致设计问题」残留项。
- **过度特化审查（指令⑨）**：本轮交付全为规划域通解（窗序/缺口入账/台账/裁定）；两新窗均为机制窗（拆除窗 = 脚手架生命周期通用拆除；语言基础窗 = 类型系统成员通设面）非位点特化；当前阶段未解决问题清单 = W-JIT-METHOD-T1 tier-1 两刀（排期内）+ TD-027（T-a 前置门）+ TD-026（riding）——零未登记问题，推进合法。

## 验收

- 六命令（cargo clean 冷跑，OBS 口径）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1599:0:4 基线维持**（r139 基线逐位——1599 passed + 4 ignored 重负载披露维持） / doc 零新增警告（cargo#6313 既有唯一）；audit **380/380 live + 104 retired · 47 节维持**（规划域零增测/零增节双合规——r126 先例）。
- 8 原语不变性第一百零二轮验证：零代码变更（规划域轮）——零新原语/零新内建/零语法增改/零操作码面变更。
- S-expr 转化记录：零新转化面（孪生维持九件 14,243 行——台账单源化本轮落位）；记录位 = 转化台账 + bootstrap-plan 窗口行 + stage0 §9.126（三处单源）。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 1**（方法编译基础设施——TJ-4 去分派形态，构建于 G2 堆激活栈基座 TJ-3）∥ **TD-027**（双子展开器 match 臂——T-a 前置门）∥ T-a 切换窗前置对账（G1 ✓ + G2 ✓ + G3 在窗）。

# kerf v0.100.0 — W-TGT-READ-TWIN 刀 3：稳态目标读链 + C1 链路闭合（r139）

第一百三十九轮（r139 · Task 139）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.2 刀 3 行（bootstrap-completion-plan.md v1.4——G1 目标皮肤读链孪生窗的收口刀：**C1 链路级闭合 = G1 终态**）· 单刀整轮。

## 本轮交付

- **SteadyTargetReaderChain（G1 终态链形——steady_expander_chain 形制沿袭至目标读链）**：两孪生各编译一次——lexer 程序 = target-lexer.ktf 原文（引用 `source-bytes` 注入槽，RS-1 值面）；parser 程序 = tp-forms 表 + tp-limit 256 常量 + target-parser.ktf（引用 `tp-tokens` 注入槽）。每读四引擎（lexer vm+eval → 桥 → parser vm+eval——各轴独立桥接，桥 bug 偏袒一引擎需与另一引擎恒同漂移方可存活 sweep）。通道契约构建期断言（两 bytecode 的 globals 各含槽名）。
- **K20 永久宿主层桥（链结位实例化——crates/kerf-driver/src/bootstrap/steady_target_reader_chain.rs）**：lexer 孪生记录（span 面）→ parser 孪生输入记录（载荷面）：ident → skin_symbol 规范字节（oracle 自身单源）；float → strip_us + f64 解析 + Debug 格式化（非有限映射 oracle 自身 FloatOutOfRange——层分裂：lexer 层拒绝永不达 parser）；str → decode_target_string 转义解码；int/bool 载荷直通；eof 二字段记录先于 span 提取分裂。桥正确性机器检查 = 稳态/逐源/oracle 三路由同键（稳态桥由孪生 lexer 派生 vs 逐源由 oracle lexer 派生——两路由一致即桥证）。
- **组成链 composed_target_read_chain（C1 断链闭合——crates/kerf-driver/src/bootstrap/composed_target_read_chain.rs）**：J0 token / J0.5 tree / J1 expand（稳态链重建 forms 值面经 SteadyExpanderChain——r103 i64::MIN 文本边界不适用；1.6 树同一性门 items == oracle_items）/ J1.5 check（SteadyCheckChain——查段入组成链）/ J2 compile（ktf_compile_rich 终端字节码等同）= **pipeline_ktf(S) == pipeline_rust(S)** 五联差分；总路由（§9.87.4 沿袭）：匹配拒绝（错误轴一致）为该层 PASS 行（vacuous 下游），读层拒绝两轴同键。
- **fixpoint 纯度腿（K159 前置）**：fixpoint Phase-2 assembled 自应用程序（items 前缀 + compiler.ktf）读段经 twin_front_end_read（目标读孪生 + 展开孪生 → rebuild items）== 生产桥 items 断言（CP-1 约定沿袭——树真值源差分）。
- **读段自应用（最深固定点）**：selfhost 九源 + 孪生自身 3,281 行经稳态链（parser 孪生读自身源——engines agree + forms 重建）。
- **外部记录空参 nil 编码清偿（CP-1 词汇契约第三成员——r122/r124 extern 渲染族齐账）**：emit_item Extern 臂补 Fn 臂同款规则（空参列表载为 `nil` 非 `()`——S-expr 读者空应用拒绝；零消费者自 W-3.2 掩蔽至本轮组成链 sweep 暴露：extern-no-abi curated 案）。
- **诚实边界行（match 脱糖）**：双子展开器冻结子集域（subset-spec §1.2 八表达式形式——无 match 臂）vs oracle 超集（expand.rs expand_match）；语料 91 无 match 程序按设计；match 载荷 curated 五例 J0.9 结构分类披露（r103 先例形制）；TD-027 登记 follow-up（双子展开器 match 臂）。
- **测试与守卫族**：steady_target_reader_tests.rs 七测试（curated 91 案全公式 + selfhost 九源 + 组装展开器程序[最强实面] + 磁盘源 + 跨路由等价 + 层分裂 + 孪生前端 == 生产桥 + fixpoint 纯度腿）；test_infra_guard AV 族 10 案（370→380 live · 47 节）+ TEST-3 守卫共变（380/380 + 头行字面量 + 族注释）；eval_inventory_guard 台账 C 桶 +2（13→15——总 40→42）与窗口记录 §1 共变。
- **会话调试实录（stage0 §9.125.3 六类）**：桥 eof 二字段越界 / 「J0.5 匹配」误当「接受」（错误轴一致 ≠ 接受——层分裂读值） / 外部记录空参 () 不可读 / 1e999 词法歧义（int+ident 分裂非 float 文法）/ selfhost 孪生为链件（组装 + 前缀 define 形态才自包含）/ audit span 钉扎校准。

## 验收

- 六命令（cargo clean 冷跑）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / **test --release 1599:0:0** / doc 唯一 cargo#6313；audit run **380/380 live + 104 retired · 47 节**（40 live + 7 retired）。
- 刀 3 三验收腿：**自源读取 parity**（九源 + 孪生自身——engines agree + forms 重建）✓ / **组成链等价**（91 curated + 九源 + 组装展开器程序全公式——C1 断链闭合）✓ / **fixpoint 经目标读链复现**（b_self_exec == b_self 维持 + 孪生读段新腿 == 生产桥）✓。
- S-expr 转化记录：**本轮零新转化面**（.ktf 孪生集合维持九件 14,243 行——本刀为链形/桥/组成层 Rust 侧工程，孪生皮肤件不变）；记录位 = 本文件 + bootstrap-plan §4.2 刀 3 行 + stage0 §9.125（三处单源）。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 1**（方法编译基础设施——TJ-3 基座就位）∥ **TD-027 双子展开器 match 臂**（W-TGT-READ-TWIN 后续清偿）∥ T-a 切换窗前置对账（G1 ✓ + G2 ✓ + G3 在窗）。

# kerf v0.99.0 — W-TGT-READ-TWIN 刀 2：target Pratt parser 孪生（r138）

第一百三十八轮（r138 · Task 138）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.2 刀 2 行（bootstrap-completion-plan.md v1.3——G1 目标皮肤读链孪生窗的第二刀）· 单刀整轮（137-b 排期裁定的执行轮：孪生体量单刀完整交付）。

## 本轮交付

- **target-parser.ktf 第九自举孪生（G1 刀 2 主体）**：`crates/kerf-reader/src/target/parser.rs`（1,676 行）的 .ktf 全量镜像 = `selfhost/v1/target-parser.ktf`（3,281 行）——帧机形制（step/give/replace/push 显式栈机器——冻结子集无循环原语，迭代经自递归）逐决策镜像：14 级优先级瀑布（or/and/cmp/bit 族/加减/乘除模/一元/后缀）+ do/let 反向折叠 + quote datum 载体 + 模式族（字面量/绑定/mut 糖/对模式/nil 模式）+ 类型注解 drop（路径/泛型参数/圆括类型表/联合/函数返回/impl·effect 前缀）+ 胖关键字（fn/module/extern/macro/use 双形/handle/match/perform）+ fail-closed UnsupportedTargetForm 全表 + 24 关键字拒绝面。
- **TP-1 注入通道（parser 层 RS-1 形制沿袭）**：宿主以单源 Rust target lexer（`lex_target`——皮肤映射 K20 已在该层施加）注入三全局——token 记录表（`tp_tokens`：ident 携带皮肤映射后规范名字节表/float Debug 文本/str 解码文本）+ 嵌套限（`tp_limit`）+ oracle 自身 UnsupportedTargetForm 消息文本表（`tp_forms` 21 键——孪生侧消息漂移结构性不可能：消息值反查静态表 = oracle 单源）。孪生做全部 parse 决策；harness 解码 `tp_verdict`（vm/eval 双引擎各自）。
- **harness 与测试族**：`crates/kerf-driver/src/bootstrap/target_parser_parity.rs`（745 行——三注入前缀构造 + decode_tp_tree 递归[ident/int/float/dfloat 宿主取负/bool/string/list/use-str K20 宿主 skin_symbol/use-path] + rebuild_tp_error 五类错误重建 + drive_dual_engines 三向对比）+ `tests/v1/stage1/plan/target_parser_twin_tests.rs`（六测试：curated 91 案 / selfhost 九源自应用固定点[含孪生自身 3,281 行——最深自应用面] / 磁盘源 / 拒绝面 ≥35 同键 / anchor 错误键六例 / 跨阶段声明头）。
- **r138 会话调试实录清账（三簇缺陷修复——worklog Task-138-a-inprogress 序列化条目的三簇全部清零）**：簇 A params 重写回归（fn 头 name 前置序[tp_rappend 误用→prepend] + 空源 ("ok") 零记录 verdict 契约 + 类型圆括表缺 give 臂[元素经 machine-drop 误弹帧] + use-path 字符串记录端 = 分号端[oracle span_from 自身面] + extern 形参类型源序[累加器逆序]）+ 簇 B if/match/handle 帧族（if want-then 步进臂缺位[等待相位无子帧自旋] + give 相位名失配["want-then" vs "wait-then"——DONE 臂误吞 then 为 else 而 cond 槽置 Nil] + handle (eff params) 尾槽可变参数帧散布纪律[pair(acc, tail) 追加元素非包裹列表——tp_8/tp_9 直读槽位 8/9] + resume 右括号消费[oracle expect(CloseParen) 先于逗号] + handle 臂逗号折叠共享化[tp_handle_arm_fold] + match (pattern . real_acc) 取 rest 非 tp_2[单臂形 car-of-nil] + pattern-paren 五字段帧[四字段帧 tp_5 越界] + pattern-paren 逗号续元缺推帧[自旋] + 元组模式三元素拒绝计数 >=2[oracle elements.len()==2 于逗点位]）+ 簇 C 拒绝面 decode 批（or-or/and-and 层 0/1 操作符集缺位 + tp_n_eq 单元素字节表 datum 需尾逗号[(61,) 列表 vs (61) 分组——int 裸值] + require 形消息文本表过度转义修正 + tk_e 对二字段 eof 记录的回退[oracle "end of input" 面] + 词法层拒绝 parity 分层[K20 单源——oracle lexer 拒绝 = 双引擎同键构造性成立]）+ **块帧单次进入纪律**（guarded push 与 step fresh 双 tp_enter = 每块 +1 深度泄漏——expander.ktf 6,444 位 257>256 实证；块进入权归 step 单点）+ harness 崩溃位点渲染（K182 分类于失败点——harness_run_failure 附 span；lexer_parity 同类路径共变）。
- **audit AU 族 10 案**（360→370 live · 46 节——39 live + 7 retired）：AU01 fn 头名前置序 / AU02 空源零记录 verdict / AU03 类型圆括表逗号环 + 尾逗号拒绝 / AU04 use-path 半冒号端字符串记录 / AU05 extern 类型源序 / AU06 短路操作符层 0/1 / AU07 单元素字节表 datum / AU08 do/let 折叠序 + 赋值语句 / AU09 handle 臂尾槽散布 + resume 右括号 / AU10 嵌套守卫单次进入（200 语句默认帽内）+ eof 二字段记录。守卫 TEST-3 共变（360→370 live + 474 总 + 头行字面量 + 族注释）。

## 验收

- 六命令（cargo clean 冷跑）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release 全绿 / doc 零新增警告。
- audit **370/370 live + 104 retired · 46 节**；curated twin 91/91（正 50 + 负 41——含三簇边界全清）+ selfhost 九源固定点（lexer/reader/expander/macro/infer/typecheck/compiler/target-lexer/target-parser——含孪生自身源最深自应用）全绿。
- 8 原语不变性第一百零一轮验证：零新原语/零新内建/零语法增改/零操作码面变更（纯前端孪生面）。S-expr 完全转化记录义务：本轮新增转化面 ×1（target-parser.ktf = Rust target parser 的 kerf 语言完整转化——转化面累计九件 14,243 行 .ktf）；记录位 = 本文件 + bootstrap-completion-plan §4.2 刀 2 行 + stage0 §9.124。
- 下一入口：W-TGT-READ-TWIN 刀 3（读段自应用 + 稳态读链 SteadyTargetReaderChain + 组成链扩展 = C1 断链闭合）∥ W-JIT-METHOD-T1 tier-1 刀 1（TJ-3 基座就位）。

# kerf v0.98.0 — W-REC-DEPTH 刀 2：K162 可配置护栏 + r74/r85 括号退役（r137）

第一百三十七轮（r137 · Task 137）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.1 刀 2 行（bootstrap-completion-plan.md v1.2——C3 递归深度通解的收尾刀）· 单刀整轮（137-b parser 孪生独立排期 r138——§4 MUV 边界：孪生体量 ~3,500-4,000 行 .ktf 单刀完整交付，避免降级交付违例）。

## 本轮交付

- **四层帽 K162 范围化全链（C3 收尾）**：原则 58 四层帽谱系（reader NESTING_LIMIT 256 / expander EXPANSION_LIMIT 512 / compiler COMPILE_DEPTH_LIMIT 1024 / pkg RESOLUTION_DEPTH_LIMIT 512）全部参数化——每层新增 `*_with_limit` 显式入口（read_program_with_limit / read_target_program_with_limit / parse_program_with_limit / expand_program_with_limit / expand_program_with_injected_and_limit / compile_with_limit / compile_program_with_limit / resolve_with_limit）+ 既有公共 API 逐位不变（默认常量委托——黄金行为零漂移）+ ExpandCtx 手写 Default（= new 保守默认——derive 的全零结构将使 limit=0 拒绝一切 enter，语义破坏修复于当轮）+ 编译器错误载荷随配置 cap 共变（DepthExceeded depth = limit+1）。
- **driver DepthLimits 面（env 单源消费）**：`DepthLimits { reader_nesting, expansion, compile_depth }`（Default = 三 crate 常量钉扎）+ `from_env()`（KERF_READER_NESTING_LIMIT / KERF_EXPANSION_LIMIT / KERF_COMPILE_DEPTH_LIMIT 三键——缺省回落默认；非法值[非正整数/非 Unicode]硬错误 fail-closed——「静默忽略的护栏覆盖是谎言」）+ `Session::with_limits`（limits 挂 Session——进程级配置归属位；库面零隐式 env 读取，测试确定性免疫环境变量）+ `ParsedProgram.limits` 字段（程序自带护栏——check/run 无需 session）+ CLI 三命令位（check/emit-c/run 族）session_from_env 接线（错误退出码 2）+ kp 工具 KERF_PKG_RESOLVE_DEPTH_LIMIT 独立单源。REPL 维持默认帽（交互源天然浅——设计边界如实登记）。
- **r74/r85 VM-only 括号全链退役（C3 第三验收腿）**：eval 堆激活栈化（刀 1）使「evaluator envelope is finite」前提失效——fixpoint 两处 step-3（fixpoint_selfhost_compiler_target / fixpoint_products_target 的 C_t(C_t(S'))）从 ktf_compile_rich_vm 切换 ktf_compile_rich 双引擎面（vm_text == eval_text 断言新增——自应用数据逐元素递归预算内实测通过）；composed_target_chain junction-1 VM-bracket 面（composed_target_chain_parity_vm）+ reader_parity_full_target_feed_vm + drive_full_target_vm + drive_full_face 的 dual 分支 + ktf_compile_rich_vm + vm_harness_failure_target + decode_verdict_vm 全链删除（零 dead code 留守）；语料 sweep 的 harness-limit 分类从「切 VM 括号重验」改为硬失败回归守卫（「刀 1 后任何 corpus case 触达 harness-limit 分类 = 回归」）；bnd-006 255 深嵌套族双引擎直接 matched + engines_agree 严格断言（原宽松「matched or classified」断言收紧）；audit AE8 改双引擎 + LA-7 探针测试改双引擎（vm/eval 一致断言强化）。
- **测试面 +13（1573→1586）**：rec_depth_window_tests 新族（正 6：reader/target/expander/compiler/pkg with_limit 深源 + session 提帽集成[600 深 if 链经 raised session 读取展开 + 默认 session 拒绝]；负 7：默认帽黄金维持[257 拒绝载荷钉扎] + 零帽 fail-closed + expander 紧帽边界 + compiler 紧帽载荷 + DepthLimits 常量钉扎 + Session 默认 = 常量 + env 清洁解析）+ composed_target_chain_tests 三面改造（sweep panic 化 + budget_bracketed 退役 + the_deep_nesting_family_rides_the_dual_face 更名严格化）+ target_fixpoint_tests LA-7 双引擎化。
- **audit AT 族 10 案（350→360 live · 44→45 节）**：AT01-AT10（四层 with_limit 深源审计 + 默认黄金 + target 孪生面 + expander 紧帽 + compiler 默认拒载荷 + pkg 深链紧帽/提帽双臂 + DepthLimits 常量 + env 清洁 + 退化帽 fail-closed + **AT10 fixpoint 无括号全跑**[C_t(S') + C_t(C_t(S')) + 执行产物 fixpoint_holds + selfapplied_consts > self_consts 烘焙输入断言]）。
- **r136 遗漏缺陷当轮清偿（§20 同类路径审查）**：ds08 工作区版本黄金钉扎停留在 0.96.0（r136 金链锁步 v0.97.0 时遗漏该钉扎位——GATE 1 跑在锁步前的顺序窗口）；同类排查 = WORKSPACE_VERSION 字面量钉扎全树仅 ds08 一处（其余为 env!("CARGO_PKG_VERSION") 动态对比自适应）；本轮随 v0.98.0 锁步修正 + 遗漏机制如实登记。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1586:0:4**（基线 1573 + 新族 13——恰中声明阈值）/ doc 零新增警告（cargo#6313 既有唯一——output filename collision 先例）。
- audit **360/360 live + 104 retired · 45 节**；gate B 全语料逐位 + fixpoint 自复现维持 + fixpoint 无括号（双引擎全相位）。
- **C3 递归深度通解终态宣告**：深非尾递归仅受内存约束（10^5 默认栈——刀 1）✓ + 深尾递归恒定栈高（10^5——刀 1）✓ + fixpoint 无括号自建（双引擎——本轮）✓ + 读/析层护栏范围化（四层 with_limit + env——本轮）✓；四层帽谱系文档对账（原则 58：默认保留 + 可配置护栏——bootstrap-completion-plan §4.1 刀 2 行刷新）。
- 8 原语不变性第一百轮验证：零新原语/零新内建/零语法增改；零操作码面变更（护栏参数化 + 括号退役轮——纯 API/测试/harness 面）；S-expr 转化记录义务：零新 S-expr→目标语言转化面（API 参数化轮）。
- 下一入口：**W-TGT-READ-TWIN 刀 2（target Pratt parser 孪生——r138 单刀整轮，G1 推进 2/3）∥ W-JIT-METHOD-T1 tier-1（TJ-3 基座已就位）**。

# kerf v0.97.0 — W-REC-DEPTH 刀 1 ∥ W-TGT-READ-TWIN 刀 1：自举阶梯双首刀（r136）

第一百三十六轮（r136 · Task 136）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §3 序 1/2 的双首刀轮（bootstrap-completion-plan.md v1.0 排期——W-REC-DEPTH 共享基座刀 1 ∥ W-TGT-READ-TWIN 刀 1 并行排期零交集）· 第十九次回退恢复轮（本地 Pack B 双包恢复——按用户指令不访问 GitHub）。

## 本轮交付

- **W-REC-DEPTH 刀 1——eval 引擎堆激活栈化（G2 通解基座 · K160 执行化）**：kerf-runtime eval.rs 全量重写为显式激活栈机器（Kont 延续帧族：Arg/Callee/If/Store/Bind/LetOut/EffectArg/Install/Uninstall/Frame——每一闭包应用一帧，双守卫对[entry/site]镜像旧 Rust 递归的 temp 根保护纪律）+ SExpr 共享树表示（Rc-per-node 镜像 CoreExpr——闭包体创建时一次性转换，替代旧深拷贝同代价；延续帧持节点句柄零深拷贝）+ EVAL_DEPTH_LIMIT 2048 固定帽解除为内存预算治理（每闭包入口一次 reserve——与 VM push_frame 逐位同账；DEFAULT_BUDGET 8Mi 统一两引擎深度界）+ 错误路径 Rust-unwind 镜像（逐帧恢复/env 截断/handler 弹出/temp 截断——`?`-walk 泄漏语义逐位镜像不改进）+ RuntimeError::EvalDepthExceeded 退役注记（变体保留为历史诊断面——错误注册表渲染测试钉扎；零构造路径）。**验收对**：10^5 非尾递归默认线程栈（8 MiB）实测通过（旧原生递归 2048 即需 64 MiB 深栈线程——恒定宿主栈高证明）+ 10^5 尾形同过 + 双引擎 10^5 深度 parity + 预算 fail-closed + 深帧错误 unwind 状态一致 + 深度下 GC 根完备（紧预算丢弃步 collect-then-retry 存活）+ 深度下 handler/闭包捕获正确 + 深度下 span 存活 + 双跑确定性（值与 cycle 数逐位）。
- **W-TGT-READ-TWIN 刀 1——target-skin lexer 孪生（G1 断链首刀 · 第八 selfhost 孪生）**：selfhost/v1/target-lexer.ktf（1,065 行——crates/kerf-reader/src/target/lexer.rs 的逐决策镜像：4 字节 trivia/嵌套块注释/24 关键字节表/true-false/ASCII 标识域/0x-0o-0b-十进制四族数文法[点强制 float + 指数消费规则 + `1._5`/`1.5e` 边界]/7 转义 + \u{1..6hex} 字符串[代理对与超平面拒绝]/maximal munch 三级操作符/非 ASCII unexpected-char；整数值在孪生内计算——负域累加器 + per-radix（位数,字典序）阈值守卫使检查算术永不陷阱，i64/u64 双界分类逐位；float/str 值 K20 永久宿主侧——孪生只判文法）+ target_lexer_parity.rs 三向 parity harness（twin-vm == twin-eval == oracle；49 案例族：19 正向 + 30 拒绝；ident 皮肤映射经 oracle 自有 skin_symbol 单源派生）+ kerf-reader target 面开放（TgtToken/TgtKind/lex_target/skin_symbol 公开——S-expr lex 公开先例镜像）。**自源案例**：孪生读取自身 .ktf 文本三向一致（读段自应用种子——G1 闭合面）；selfhost 七件全 corpus 三向 sweep（infer.ktf 17,268 token 逐位）。
- **audit 两新节（330→350 live · 42→44 节）**：AR 族 10 案（W-REC-DEPTH 审计面——验收对全腿 + 双引擎深度 parity + 预算唯一界 R8 消息 + unwind 状态机 + 深度 GC 根完备 + 深度 handler/捕获/span + 双跑确定性 + 分配记账）+ AS 族 10 案（孪生审计面——全案例三向 sweep + 词面 dump 锚 + 孪生内整数值锚 + float K20 边界 + 拒绝锚 + 自源 + selfhost corpus + 皮肤映射轴 + trivia-only + 最大源 token 计数消费）。
- **测试面 +12（1561→1573）**：eval.rs 内族 5 新（深非尾/深尾形/预算 fail-closed/深度 GC/深帧错误 unwind——深度帽测试与 R8 深度消息腿退役重写为预算腿）+ limits_ladder 重写（eval 档退役为预算治理档——终止论证强化覆盖双引擎）+ runtime_seed 深度 parity 重写（双引擎 10^5 双形——默认栈即证明）+ 孪生测试族 7（curated/selfhost 内存/disk 拒绝族/锚渲染/token 计数/自源 fn 头）+ test_infra 审计清点 350 锁步 + selfhost 格式守卫第八件登记。
- **第十九次回退恢复轮**：/home/z/kerf 整树再次丢失 → 本地 download/ 双包恢复（Pack B 984 entries sha256 416a43973ce15de4... 编排态工作树原件——按用户指令「无需访问 GitHub 直接使用本地最新环境」）+ git 基线重建（recovery baseline 016696f）+ Rust 1.99.0 工具链重装 + GATE 1 七命令零漂移复验（1561:0:4 + audit 330/330·42 节逐位）后开工。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456 + ulimit -s 131072，cargo clean 冷跑）：build 0e0w（17.62s 全量）/ check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1573:0:4** / doc 零新增警告（cargo#6313 既有唯一）。
- audit **350/350 live + 104 retired · 44 节**；gate B 全语料逐位 + fixpoint 自复现维持（1561 存量全绿即证）。
- 8 原语不变性第九十九轮验证：零新原语/零新内建/零语法增改；零操作码面变更（刀 1 纯执行链与前端孪生面）；S-expr 转化记录义务：本轮新增 S-expr→目标语言转化面 ×1（target-lexer.ktf = Rust target lexer 的 kerf 语言完整转化——登记于本文件与 bootstrap-completion-plan §4.2）。
- 下一入口：W-REC-DEPTH 刀 2（四层帽显式栈化/可配置护栏 K162）∥ W-TGT-READ-TWIN 刀 2（target Pratt parser 孪生）∥ W-JIT-METHOD-T1 tier-1（构建于刀 1 基座之上——TJ-3）。

# kerf v0.96.0 — W-JIT-METHOD-T1 开窗：自举完备总规划 + tier-0.5 收尾首刀（r135）

第一百三十五轮（r135 · Task 135）· SOP v15.3 §21.12-28 自举完备优先 · W-JIT-METHOD-T1 方法 JIT 窗开窗轮（上游裁定 = r134 三触发器全命中 + w3.7-jit-window.md §4.3-2；自 r134 闭合态续作）· 用户常设指令①「完整完全自举优先」+「任意递归深度纳入规划」双指令承载轮。

## 本轮交付

- **自举完备总规划**（bootstrap-completion-plan.md v1.0 新建——用户首要指令的规划单源）：完成标准操作化 C1-C4（§21.12-28③「完全脱离宿主语言」的工程判据：C1 kerf 源的 kerf 编译链 / C2 生产位切换 K159 不动点管线 / C3 递归深度通解 / C4 语言自我推进面）+ 现状缺口地图 G1-G6（G1 目标皮肤读链孪生不存在 = C1 结构性断链 / G2 任意递归深度未通解 / G3 T-a 性能带 / G4 生产位 / G5 PM 自举 / G6 eval 退役）+ 五窗序列粗粒度排序（§21.12-28① 逐窗可审计理由）+ 前置窗细粒度 MUV（W-JIT-METHOD-T1 五刀 / W-TGT-READ-TWIN 三刀）+ T-a 切换窗五步（K159 操作化）+ 测量计划（稳态摊销口径 + K140 带诚实预期）+ 每轮复核义务（指令⑨载体）。
- **窗内第一议题裁定 TJ-1..TJ-5**（w-jit-method-t1-window.md v1.0 新建）：TJ-1 首刀 = tier-0.5 收尾（LLC 复制对融合——第三杠杆 20% 在册数据消费；K154 阶梯序 + r133/r134 形制先例 + MUV 边界单轮完整）；TJ-2 余量对（含调用/控制流成分）归 tier-1 方法级吸收（K157 重定义：方法级编译自然吸收块内全部相邻对——逐对融合是低阶子集）；TJ-3 共享基座耦合（tier-1 构建于 W-REC-DEPTH 堆激活栈之上——K160 归一 + 重复施工警戒 + r134 fixpoint 爆深度实证）；TJ-4 tier-1 = 去分派方法执行层（K153+K157——零 codegen、确定性构造、验收对照 tier-0.5 收尾基线）；TJ-5 T-a 组合面诚实预期（本窗出口 = 三触发器清账；T-a <10× 需组合面——本窗不承诺）。
- **登记窗两件新增**（tech-debt-register r135 检视）：W-REC-DEPTH（任意递归深度通解——用户显式指令 + G2 + TJ-3 依赖；排期 r136+ 前置刀）+ W-TGT-READ-TWIN（目标皮肤读链孪生——G1 结构缺口；与 JIT 窗 r136+ 阶段并行排期零交集）。
- **W-PKG-SELFHOST 触发器反冻结改写**（用户「禁止冻结」指令 × r115 设计的冲突裁定）：前置二「功能冻结」→「manifest 子集实证稳定」（micro-TOML 六形 + semver 边界最近 N≥5 轮零变更 + pkg 语料回归全绿——可机检判据替代政策性冻结；§12 判据可审计优于口号）。
- **知识层 K157-K162 六新锚**（stage0.md §9.121 + tool-results/r135-search/ 七件 + REPORT.md）：K157 Sparkplug 重定义（价值在分派消除非原生 codegen）/ K158 零 codegen 加速家族（closure chain + threaded code 菜单）/ K159 生产位切换 = 种子→全量→自重建不动点（不动点 = 验证门非构建步骤）/ K160 任意递归深度 = 激活记录堆化归一（与 closure chain 共享 VM 自有激活栈——单一机制规划）/ K161 PM 自举与编译器自举解耦（opam 先例）/ K162 读析层深度护栏业界常态（范围化裁定）。
- **tier-0.5 收尾首刀 LLC 融合全链**（w-jit-method-t1-window.md §3 MUV 135-b）：opcode 26→27（`load-local-const {a: local slot, b: const index}`——pops 0/pushes 2，Dup pushes=2 先例；ordinal 26 尾插 census 键稳定扩展；「about 35」裕量 8）+ VM 双压臂 + verify Pass 1 双边界（槽位/常量池）+ depth DAG pushes=2 + .krf 往返（kebab `load-local-const`）+ C 后端复合发射（k_local_load + 常量压栈）+ compile.rs args 环视特判（arg[i] Var 解析局部 ∧ arg[i+1] Literal → 单指令双压——结构安全论证：args 列内部位永非分支头，消除位免 fusable 分类器；intern 序保持——Var 零 intern）+ compiler.ktf 孪生同步（gate B 逐位 + fixpoint 自复现）。
- **守卫再生成 + 新族 + audit**：jit_window census 锚再推导（(load-local,push-const) 对消失 + load-local-const 计数入锚）+ 快照黄金族再生成（含 (局部, 常量) 相邻实参形态程序）+ method_jit_window_tests 新族（正 2/负 6 = 1:3——融合/非融合同值双臂[集成验证用例] + 跳转目标落位融合指令 + verify 双边界 + .krf 往返 + C 混合发射 + 孪生篡改 gate B drift + census 前提）+ audit AQ 族 10 案（320→330 live · 42 节）。
- **B 轴复画像三跑（诚实账）**：fib-25 指令数 2,427,852 → **1,942,283（-20.0% 精确兑现——485,569 复制对逐位消除）**；中位 **63.601/63.816/63.466ms = +3% 回退**（r134 预估 ~12ms 节余未兑现——消除的是最廉价指令，剩余混合均值成本上浮 25.35→32.75ns + 布局效应 ~3.4%；K129 纪律执行不投机微调）+ parity OK 全负载；**裁定 = tier-0.5 融合层墙时收益已尽，负担全部移交 tier-1**（方法级编译吸收全部逐指令分派——LLC 的 -20% 指令数在 tier-1 内兑现）——三触发器维持命中，tier-1 必要性强化实证（w-jit-method-t1-window.md §3.1 单源）。
- **孪生潜伏缺陷顺带清偿（§20 同类路径审查）**：cp_emit 栈下溢载荷 span 三元组错位析取（cp_2/cp_3 取得 end/gen 替代 s/e——该路径在良构产物上从未触发，N6 表效篡改探针首达即暴露）——修正为 first/cp_2 对齐 Rust rebuild 的 make_span 契约；错误轴载荷修复非行为面变更（gate B/fixpoint 零影响——错误轴产物不含良构产物比对面）。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456 + ulimit -s 131072）：build 0e0w / check 0/0 / fmt 零 diff / clippy -D warnings 零 / test --release 全绿（基线 1554 + 新族与再生成差量）/ doc 零新增警告（cargo#6313 既有先例唯一）。
- audit 330/330 live + 104 retired · 42 节；gate B 全语料逐位 + fixpoint 自复现维持。
- 8 原语不变性第九十八轮验证：零新原语/零新内建/零语法增改；操作码面 26→27（VM 内部编码扩展——SI-2/FA-2 先例族）；S-expr 转化记录义务：零新 S-expr→目标语言转化面（编译器发射面优化轮）。
- 下一入口：W-REC-DEPTH 共享基座刀 1（r136+）∥ W-TGT-READ-TWIN 刀 1（并行排位零交集）——自举阶梯单源 = bootstrap-completion-plan.md §3 序。

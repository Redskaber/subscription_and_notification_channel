//! CP parity — the fourth self-hosted front-end segment
//! (Stage 2.3 — docs/stage0.md §9.83/§9.84, stage-2-plan §2 row 2.3,
//! anchors K193-K197 + K198-K203; carried through the r104 E5
//! batch-3 teardown). The compile-time **pure-function surface**
//! of the compiler — the lexical-domain analysis (the scope-stack
//! mark/truncate discipline plus the free-slot LIFO, the
//! innermost-first local lookup, the LA-1 three-way resolution, the
//! LA-4 transitive `held_by` capture analysis, the first-use
//! global/const interning) AND the instruction emission (the single
//! emit path with the opcode stack-effect table, the jump
//! backpatching discipline, the dense per-instruction `debug_info`
//! table, the tail-position terminator contract, the finish-time
//! placeholder drain) — written in the frozen kerf subset itself
//! (`selfhost/v1/compiler.ktf`, the fourth selfhost twin after
//! reader/expander/macro — target-skin; the seed-skin original
//! left the tree at E5) and compared against the Rust oracle
//! (`kerf_compiler::compile_program`) on two axes:
//!
//! * **Product axis** — the products that land in the `Bytecode`:
//!   `funcs[].{name, params, n_locals, captures}` (creation order,
//!   captures in first-use order with the LA-2/LA-4 descriptor
//!   sources), the per-proto instruction streams `code` (pc order,
//!   stable kebab opcode names, operands) and `dbg` (the dense
//!   per-instruction span table), plus `globals` and `consts` in
//!   first-use order. Both sides normalize to the same dump text
//!   (K196/K203 translation-validation shape: the a-posteriori
//!   check runs per product family — the emitted instruction
//!   stream included). The span face of the comparison is the
//!   offset pair, the same convention the 1.5/1.6/1.7 parities and
//!   the error axis use (Span's Display carries file and offsets;
//!   expansion ids stay outside the comparison text, owned by the
//!   1.6/1.7 faces).
//! * **Error axis** — the `.ktf` compiler reports a structured
//!   rejection (`("err" kind payload...)`); the harness rebuilds
//!   the `CompileError` and renders it through the oracle's own
//!   `Display`, so byte parity holds by construction and the
//!   non-trivial part under test is the kind / payload / span
//!   selection (the compile-reachable family: `assign-to-captured`
//!   and `depth`; the emission defenses `stack-underflow`,
//!   `stack-imbalance` and `unpatched-jump` fire only on a broken
//!   emitter and surface as readable drift, and `bad-patch` /
//!   `bad-node` classify as harness defects).
//!
//! The item tree is source-injected (CP-1, §9.83): the host runs
//! the Rust reader AND the Rust expander (the single sources of
//! tree truth for their layers) and injects the **expanded** item
//! tree as a flat pre-order record stream ahead of the compiler
//! twin as `(define items (quote (record ...)))` (the S-expr prefix
//! text is the internal intermediate, which the target face
//! transcodes — `target_corpus::target_items_stream_prefix`). Every record is
//! a flat list (the 1.5/1.6 discipline: a flat shape keeps the
//! assembled source inside the reader's 256 nesting cap even for
//! 255-deep trees); variable-arity records carry their child count
//! in a field, and children follow as the next records. Spans ride
//! as decimal byte-offset strings and floats as Debug text (the
//! 1.5 conventions, carried opaquely — the analysis products are
//! span-independent; only the two rejection kinds surface spans).
//!
//! Three layers decide a case: sources the *reader* rejects are
//! decided by the 1.5 parity face; sources the *expander or loader*
//! rejects are decided by the 1.6/1.7 parity faces; everything else
//! runs the assembled `.ktf` analysis
//! on **both engines** (the `run_parity` lineage) and is compared
//! against the Rust oracle — products, or the structured
//! rejections. The typecheck layer never decides a CP case: the
//! checker and the compiler are independent consumers of the same
//! expanded tree, and the analysis products are well-defined on
//! trees the checker would reject (the E0012 family still produces
//! a *compile-side* `assign-to-captured` rejection — the LA-7
//! three-layer defense).

use kerf_compiler::{Bytecode, CaptureSource, CompileError, ExternEntry, FuncProto, Instr, Opcode};
use kerf_core::{Binding, CoreExpr, ExternType, HandlerClause, LiteralValue, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_vm::{Heap, Value};

use crate::bootstrap::expander_parity::{
    dump_ktf_litval, dump_oracle_lit, ktf_name, make_span, rebuild_lit,
};
use crate::bootstrap::reader_parity::{
    KtfVerdict, as_i64, as_str, encode_string_literal, need_fields, value_elems,
};

/// The error-axis parity key: stage Display + harness-rendered span
/// payload (§9.56 DIAG-1 compensation — the message is
/// position-free, so the comparison key must distinguish payloads,
/// exactly like the expander parity's `error_parity_key`).
///
/// `pub(crate)` since the 2.4 composed chain (§9.87): the full
/// chain's final face renders the oracle full-pipeline compile
/// through the same key — one rendering, never a second.
pub fn cp_error_key(err: &CompileError) -> String {
    match err.span() {
        Some(span) => format!("{err} @ {span}"),
        None => format!("{err} @ <no-span>"),
    }
}

impl KtfVerdict<CompileError> {
    /// The rendered comparison text (analysis dump, or the
    /// parity-key form of the rebuilt rejection).
    pub(crate) fn text(&self) -> String {
        match self {
            KtfVerdict::Tree(dump) => dump.clone(),
            KtfVerdict::Error(err) => cp_error_key(err),
        }
    }
}

// ---------- CP-1: the source-injected items stream ----------

fn span_fields(span: Span) -> (String, String, String) {
    (
        span.start.0.to_string(),
        span.end.0.to_string(),
        span.expansion_id.0.to_string(),
    )
}

/// Emit one literal value into the flat stream vocabulary: atoms
/// close themselves; a pair emits `("lpair")` and its two litval
/// children follow as the next records.
fn emit_litval(value: &LiteralValue, out: &mut String) {
    match value {
        LiteralValue::Int(v) => out.push_str(&format!("(\"lint\" {v})")),
        LiteralValue::Float(v) => {
            // Debug text rides as a string (the 1.5 convention).
            out.push_str(&format!(
                "(\"lfloat\" {})",
                encode_string_literal(&format!("{v:?}"))
            ));
        }
        LiteralValue::Bool(v) => {
            let lit = if *v { "#t" } else { "#f" };
            out.push_str(&format!("(\"lbool\" {lit})"));
        }
        LiteralValue::String(v) => {
            out.push_str(&format!("(\"lstring\" {})", encode_string_literal(v)));
        }
        LiteralValue::Nil => out.push_str("(\"lnil\")"),
        LiteralValue::Pair(a, b) => {
            out.push_str("(\"lpair\")");
            out.push(' ');
            emit_litval(a, out);
            out.push(' ');
            emit_litval(b, out);
        }
    }
}

/// Emit one binding record: `("bind" s e name gen)` with the value
/// as the next record (the trailing generation int is the 2.5
/// addendum — the 1.7 record lineage: source records ride 0, macro
/// products carry use_gen + 1).
fn emit_binding(b: &Binding, out: &mut String) {
    let (s, e, g) = span_fields(b.span);
    out.push_str(&format!(
        "(\"bind\" \"{s}\" \"{e}\" {} {g})",
        encode_string_literal(b.name.as_str())
    ));
    out.push(' ');
    emit_expr(&b.value, out);
}

/// Emit one handler-clause record: `("clause" cs ce effect gen)`
/// with the handler expression as the next record.
fn emit_clause(h: &HandlerClause, out: &mut String) {
    let (s, e, g) = span_fields(h.span);
    out.push_str(&format!(
        "(\"clause\" \"{s}\" \"{e}\" {} {g})",
        encode_string_literal(h.effect.as_str())
    ));
    out.push(' ');
    emit_expr(&h.handler, out);
}

/// Emit one expression record into the flat pre-order stream (the
/// vocabulary is the single-source contract documented in
/// `compiler.ktf`'s header; children follow as the next records).
fn emit_expr(expr: &CoreExpr, out: &mut String) {
    let span = expr_span(expr);
    let (s, e, g) = span_fields(span);
    match expr {
        CoreExpr::Fn { params, body, .. } => {
            out.push_str(&format!("(\"fn\" \"{s}\" \"{e}\""));
            // An empty parameter list rides as `nil` (the CP-1
            // vocabulary contract): a bare `()` is a read error
            // (empty application), so the params field must never
            // render as an empty list.
            if params.is_empty() {
                out.push_str(&format!(" nil {g})"));
            } else {
                out.push_str(" (");
                for (i, p) in params.iter().enumerate() {
                    if i > 0 {
                        out.push(' ');
                    }
                    out.push_str(&encode_string_literal(p.as_str()));
                }
                out.push_str(&format!(") {g})"));
            }
            out.push(' ');
            emit_expr(body, out);
        }
        CoreExpr::Apply { func, args, .. } => {
            out.push_str(&format!("(\"apply\" \"{s}\" \"{e}\" {} {g})", args.len()));
            for arg in args {
                out.push(' ');
                emit_expr(arg, out);
            }
            out.push(' ');
            emit_expr(func, out);
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            out.push_str(&format!("(\"if\" \"{s}\" \"{e}\" {g})"));
            out.push(' ');
            emit_expr(cond, out);
            out.push(' ');
            emit_expr(then_branch, out);
            out.push(' ');
            emit_expr(else_branch, out);
        }
        CoreExpr::Var { name, .. } => {
            out.push_str(&format!(
                "(\"var\" \"{s}\" \"{e}\" {} {g})",
                encode_string_literal(name.as_str())
            ));
        }
        CoreExpr::Literal { value, .. } => {
            out.push_str(&format!("(\"lit\" \"{s}\" \"{e}\" {g})"));
            out.push(' ');
            emit_litval(value, out);
        }
        CoreExpr::Assign { name, value, .. } => {
            out.push_str(&format!(
                "(\"assign\" \"{s}\" \"{e}\" {} {g})",
                encode_string_literal(name.as_str())
            ));
            out.push(' ');
            emit_expr(value, out);
        }
        CoreExpr::Let { bindings, body, .. } => {
            out.push_str(&format!("(\"let\" \"{s}\" \"{e}\" {} {g})", bindings.len()));
            for b in bindings {
                out.push(' ');
                emit_binding(b, out);
            }
            out.push(' ');
            emit_expr(body, out);
        }
        CoreExpr::Perform { effect, args, .. } => {
            out.push_str(&format!(
                "(\"perform\" \"{s}\" \"{e}\" {} {} {g})",
                args.len(),
                encode_string_literal(effect.as_str())
            ));
            for arg in args {
                out.push(' ');
                emit_expr(arg, out);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            out.push_str(&format!(
                "(\"handle\" \"{s}\" \"{e}\" {} {g})",
                handlers.len()
            ));
            for h in handlers {
                out.push(' ');
                emit_clause(h, out);
            }
            out.push(' ');
            emit_expr(body, out);
        }
    }
}

/// Every CoreExpr variant carries a `span` field (the constructor
/// contract); this reads it without consuming the enum.
fn expr_span(expr: &CoreExpr) -> Span {
    match expr {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

/// Emit one item record into the flat pre-order stream.
fn emit_item(item: &ModuleItem, out: &mut String) {
    match item {
        ModuleItem::Define { span, name, value } => {
            let (s, e, g) = span_fields(*span);
            out.push_str(&format!(
                "(\"define\" \"{s}\" \"{e}\" {} {g})",
                encode_string_literal(name.as_str())
            ));
            out.push(' ');
            emit_expr(value, out);
        }
        ModuleItem::Require { span, module } => {
            let (s, e, g) = span_fields(*span);
            out.push_str(&format!(
                "(\"require\" \"{s}\" \"{e}\" {} {g})",
                encode_string_literal(module.as_str())
            ));
        }
        ModuleItem::DefineSyntax { span, name } => {
            let (s, e, g) = span_fields(*span);
            out.push_str(&format!(
                "(\"defsyn\" \"{s}\" \"{e}\" {} {g})",
                encode_string_literal(name.as_str())
            ));
        }
        ModuleItem::Module { span, name, items } => {
            let (s, e, g) = span_fields(*span);
            out.push_str(&format!(
                "(\"module\" \"{s}\" \"{e}\" {} {} {g})",
                items.len(),
                encode_string_literal(name.as_str())
            ));
            for inner in items {
                out.push(' ');
                emit_item(inner, out);
            }
        }
        ModuleItem::Extern { span, items, .. } => {
            // W-3.2: the extern record — one entry per declared
            // function, signature carried as the type tag sequence.
            // r122 fix (exposed by the expander twin refresh, §20):
            // the params and ret ride as QUOTED STRINGS — the old
            // bare-text `int,int` form split under the target
            // reader's comma separator and never survived the
            // round-trip guard (a latent defect the junction-3 twin
            // gap had masked since W-3.2; no consumer existed to
            // exercise it).
            // r124 fix (the same family, second member): the NAME
            // field rode DOUBLE-QUOTED (`"{}"` wrapping an
            // already-quoted `encode_string_literal` product) — the
            // target lexer splits `""add""` into three tokens
            // (`""` `add` `""`), the bare `add` symbol datum has
            // no Stage 0 value model, and the assembled source fails
            // to parse. Same masking path (zero consumers since
            // W-3.2); surfaced by the r124 junction-3 probe.
            let (s, e, g) = span_fields(*span);
            out.push_str(&format!("(\"extern\" \"{s}\" \"{e}\" {} {g}", items.len()));
            for entry in items {
                // The CP-1 vocabulary contract (the `Fn` arm's own
                // rule, applied here): an empty parameter list rides
                // as `nil` — a bare `()` is a read error (empty
                // application). The extern record's params field is
                // the same family's third member (the r122/r124
                // extern-rendering lineage): zero consumers had
                // exercised an empty-params extern since W-3.2;
                // surfaced by the blade-3 composed chain's sweep
                // (the extern-no-abi curated case).
                let params_field = if entry.params.is_empty() {
                    "nil".to_string()
                } else {
                    format!(
                        "({})",
                        entry
                            .params
                            .iter()
                            .map(|t| format!("\"{}\"", t.kind_tag()))
                            .collect::<Vec<_>>()
                            .join(" ")
                    )
                };
                out.push_str(&format!(
                    " ({} {} \"{}\")",
                    encode_string_literal(entry.name.as_str()),
                    params_field,
                    entry.ret.kind_tag()
                ));
            }
            out.push(')');
        }
    }
}

/// Build the `(define items (quote (...)))` prefix for one
/// already-expanded item tree (the CP-1 injection).
pub fn items_stream_prefix(items: &[ModuleItem]) -> String {
    // The empty items list rides as `(quote nil)` — the datum face
    // of the empty list (subset-spec §2.5; the forms-prefix and
    // byte-table precedents — the 2.4 chain's empty-product ledger
    // row rides here).
    if items.is_empty() {
        return "(define items (quote nil))\n".to_string();
    }
    let mut out = String::from("(define items (quote (");
    for (i, item) in items.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        emit_item(item, &mut out);
    }
    out.push_str(")))");
    out
}

// ---------- the oracle's normalized analysis dump ----------

fn dump_oracle_capture(src: &CaptureSource, out: &mut String) {
    match src {
        CaptureSource::Local(slot) => out.push_str(&format!("(local {slot})")),
        CaptureSource::Captured(k) => out.push_str(&format!("(captured {k})")),
    }
}

/// The oracle's normalized analysis dump: `(funcs (proto NAME
/// PARAMS NLOCALS (caps SRC...) (code (OP A B)...) (dbg (sp S
/// E)...)) ...) (globals NAME...) (consts LIT...)` — the same
/// grammar the `.ktf` compiler emits, so the byte comparison covers
/// creation order, first-use orders, the descriptor sources, the
/// const pool identity (NaN folds, signed zeros stay distinct —
/// `same_const_slot`'s rule mirrored by Debug-text identity), the
/// full instruction streams (opcode names, operands, patch-resolved
/// jump targets — K198/K203) and the dense per-instruction span
/// table (K201). The span face is the offset pair (the parity
/// family convention; expansion ids stay outside the text).
pub fn oracle_analysis_dump(bc: &Bytecode) -> String {
    let mut out = String::from("(funcs");
    for f in &bc.funcs {
        out.push_str(" (proto ");
        match &f.name {
            Some(name) => out.push_str(name.as_str()),
            None => out.push_str("nil"),
        }
        out.push_str(&format!(" {} {} (caps", f.params, f.n_locals));
        for c in &f.captures {
            out.push(' ');
            dump_oracle_capture(c, &mut out);
        }
        out.push_str(") (code");
        for i in &f.code {
            out.push_str(&format!(" ({} {} {})", i.op.kind_name(), i.a, i.b));
        }
        out.push_str(") (dbg");
        for s in &f.debug_info {
            out.push_str(&format!(" (sp {} {})", s.start.0, s.end.0));
        }
        out.push_str("))");
    }
    out.push_str(") (globals");
    for g in &bc.globals {
        out.push(' ');
        out.push_str(g.as_str());
    }
    out.push_str(") (consts");
    for c in &bc.consts {
        out.push(' ');
        dump_oracle_lit(c, &mut out);
    }
    out.push_str(") (externs");
    // The r124 junction-3 parity extension: the extern contract
    // table rides the analysis dump (same grammar family as
    // `globals` — one entry per declaration: the name, the param
    // tags, then the ret tag). The compile products already carry
    // it (`Bytecode::externs`, the gate-B PartialEq absorbs it
    // structurally); the analysis face now does too, so the
    // junction-3 twin-gap drift narrows to the expressibility
    // boundary itself (the derived-symbol character police).
    for e in &bc.externs {
        out.push_str(&format!(" ({}", e.name.as_str()));
        for t in &e.params {
            out.push(' ');
            out.push_str(t.kind_tag());
        }
        out.push(' ');
        out.push_str(e.ret.kind_tag());
        out.push(')');
    }
    out.push(')');
    out
}

/// The full-pipeline analysis dump — the compile product with the
/// HM type judgment at the tail (w-hm-twin-window §3 TWIN-4 face A,
/// the 127-c extension): [`oracle_analysis_dump`] verbatim plus the
/// `types` segment (the tdef family in the compact grammar — the
/// same records the inference sweep's verdict text carries, rendered
/// by the same single-source pair). The compile dump stays the
/// compile-only face (the witness and the composed chain's compile
/// junction keep it); THIS face is the composed junction's
/// full-pipeline comparison point — the `.ktf` chain's compiler
/// dump plus the inference twin's types section against the oracle's
/// compile product plus `infer_module`'s judgment, one text.
pub fn oracle_analysis_dump_typed(bc: &Bytecode, items: &[ModuleItem]) -> String {
    format!(
        "{} {}",
        oracle_analysis_dump(bc),
        crate::bootstrap::infer_parity::oracle_types_segment(items)
    )
}

// ---------- the `.ktf` product decoders ----------

/// One capture-source record: `("local" slot)` / `("captured" k)`.
fn dump_ktf_capture(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 2, "capture source record")?;
    match as_str(elems[0])? {
        "local" => {
            let slot = as_i64(elems[1])?;
            out.push_str(&format!("(local {slot})"));
        }
        "captured" => {
            let k = as_i64(elems[1])?;
            out.push_str(&format!("(captured {k})"));
        }
        other => return Err(format!("unknown capture source `{other}`")),
    }
    Ok(())
}

/// One instruction record of the `("code" ...)` section:
/// `(op-name a b)` — the stable kebab name plus the two operands.
fn dump_ktf_insn(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 3, "instruction record")?;
    let name = as_str(elems[0])?;
    let a = as_i64(elems[1])?;
    let b = as_i64(elems[2])?;
    if a < 0 || b < 0 {
        return Err(format!("negative operand in instruction `{name} {a} {b}`"));
    }
    out.push_str(&format!("({name} {a} {b})"));
    Ok(())
}

/// One span record of the `("dbg" ...)` section: `(s e gen)` — the
/// offset strings plus the trailing generation int (the 2.5
/// addendum), rendered in the oracle dump's `(sp s e)` grammar. The
/// generation rides OUTSIDE the dump text (the parity family
/// convention — expansion ids stay outside the text); the rebuild
/// face (`rebuild_bytecode`) is the consumer that needs it.
fn dump_ktf_span(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 3, "debug-info span record")?;
    let s = as_str(elems[0])?;
    let e = as_str(elems[1])?;
    // Fail-closed on the generation int: a malformed trailing field
    // is a harness defect, never a silent drop.
    as_i64(elems[2])?;
    out.push_str(&format!("(sp {s} {e})"));
    Ok(())
}

/// The tagged payload of one proto product section field: `("caps"
/// src...)` / `("code" insn...)` / `("dbg" sp...)`.
fn dump_ktf_proto_field(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    let tag = as_str(
        elems
            .first()
            .ok_or_else(|| "a proto field must be a tagged record".to_string())?,
    )?;
    match tag {
        "caps" => {
            out.push_str("(caps");
            for src in &elems[1..] {
                out.push(' ');
                dump_ktf_capture(src, heap, out)?;
            }
            out.push(')');
        }
        "code" => {
            out.push_str("(code");
            for insn in &elems[1..] {
                out.push(' ');
                dump_ktf_insn(insn, heap, out)?;
            }
            out.push(')');
        }
        "dbg" => {
            out.push_str("(dbg");
            for sp in &elems[1..] {
                out.push(' ');
                dump_ktf_span(sp, heap, out)?;
            }
            out.push(')');
        }
        other => return Err(format!("unknown proto field tag `{other}`")),
    }
    Ok(())
}

/// One proto product record: `("proto" name params n-locals
/// ("caps" src...) ("code" insn...) ("dbg" sp...))`.
fn dump_ktf_proto(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 7, "`proto` product record")?;
    out.push_str("(proto ");
    match elems[1] {
        Value::Nil => out.push_str("nil"),
        _ => out.push_str(&ktf_name(elems[1], heap)?),
    }
    let params = as_i64(elems[2])?;
    let n_locals = as_i64(elems[3])?;
    out.push_str(&format!(" {params} {n_locals}"));
    out.push(' ');
    dump_ktf_proto_field(elems[4], heap, out)?;
    out.push(' ');
    dump_ktf_proto_field(elems[5], heap, out)?;
    out.push(' ');
    dump_ktf_proto_field(elems[6], heap, out)?;
    out.push(')');
    Ok(())
}

/// The analysis-dump renderer for one compiler product (the CP9
/// section grammar): one section record of the `("ok" ...)`
/// product — `("funcs" proto...)` / `("globals" name...)` /
/// `("consts" lit...)`. `pub(crate)` since the step-4 production
/// bridge (switch-window-plan §1): the target-skin compile driver
/// renders through the same single source.
pub(crate) fn dump_ktf_section(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    let tag = as_str(
        elems
            .first()
            .ok_or_else(|| "a section record must be non-empty".to_string())?,
    )?;
    match tag {
        "funcs" => {
            out.push_str("(funcs");
            for proto in &elems[1..] {
                out.push(' ');
                dump_ktf_proto(proto, heap, out)?;
            }
            out.push(')');
        }
        "globals" => {
            out.push_str("(globals");
            for name in &elems[1..] {
                out.push(' ');
                out.push_str(&ktf_name(name, heap)?);
            }
            out.push(')');
        }
        "consts" => {
            out.push_str("(consts");
            for lit in &elems[1..] {
                out.push(' ');
                dump_ktf_litval(lit, heap, out)?;
            }
            out.push(')');
        }
        // The r124 junction-3 parity extension: the externs section
        // in the twins' own product grammar — one entry per
        // declaration, `(name param-tag... ret-tag)`, the same
        // compact style the analysis dump carries on the oracle
        // side. The rebuild faces (below) turn it back into
        // `ExternEntry` rows.
        "externs" => {
            out.push_str("(externs");
            for entry in &elems[1..] {
                out.push(' ');
                dump_ktf_extern_entry(entry, heap, out)?;
            }
            out.push(')');
        }
        // The 127-c segment-three parity extension (TWIN-4 face B):
        // the types section in the twins' own product grammar —
        // `("types" tdef-record...)`, rendered through the SAME
        // single-source tdef decoder the inference sweep's verdict
        // face uses (infer_parity::twin_tdef). The HM twins' ok
        // products carry this section natively; the compiler twin
        // never emits it (the compile face has no type judgment) —
        // this arm is the shared renderer that lets the types
        // section ride the one dump-grammar family next to
        // funcs/globals/consts/externs, the composed analysis's
        // twin side.
        "types" => {
            out.push_str("(types");
            let records = value_elems(
                elems
                    .get(1)
                    .ok_or_else(|| "the types section carries its record list".to_string())?,
                heap,
            )?;
            for tdef in &records {
                out.push(' ');
                out.push_str(&crate::bootstrap::infer_parity::twin_tdef(tdef, heap)?);
            }
            out.push(')');
        }
        other => return Err(format!("unknown product section `{other}`")),
    }
    Ok(())
}

/// Dump one extern entry record `("name" ("param" ...) "ret")` as
/// `(name param... ret)` — the compact parity style (§9.56 DIAG-1
/// sibling: the payload rides the comparison text; the quotes are
/// the datum face's own, dropped here).
fn dump_ktf_extern_entry(v: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let entry = value_elems(v, heap)?;
    need_fields(&entry, 3, "extern entry product record")?;
    out.push('(');
    out.push_str(&ktf_name(entry[0], heap)?);
    let params = value_elems(entry[1], heap)?;
    for p in params {
        out.push(' ');
        out.push_str(&ktf_name(p, heap)?);
    }
    out.push(' ');
    out.push_str(&ktf_name(entry[2], heap)?);
    out.push(')');
    Ok(())
}

// ---------- the 2.5 rebuild face (stage-2-plan §2 row 2.5, MUV ①) ----------

/// Rebuild one capture-source record: `("local" slot)` /
/// `("captured" k)` — the LA-2/LA-4 descriptor face.
fn rebuild_capture(v: &Value, heap: &Heap) -> Result<CaptureSource, String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 2, "capture source record")?;
    let idx = |val: &Value| -> Result<u32, String> {
        u32::try_from(as_i64(val)?).map_err(|_| "capture index out of range".to_string())
    };
    match as_str(elems[0])? {
        "local" => Ok(CaptureSource::Local(idx(elems[1])?)),
        "captured" => Ok(CaptureSource::Captured(idx(elems[1])?)),
        other => Err(format!("unknown capture source `{other}`")),
    }
}

/// Rebuild one instruction record `("op-name" a b)` — the kebab
/// name reversed through the single-source pair
/// (`Opcode::from_kind_name`), the operands range-checked into
/// their `u32` slots.
fn rebuild_insn(v: &Value, heap: &Heap) -> Result<Instr, String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 3, "instruction record")?;
    let name = as_str(elems[0])?;
    let op = Opcode::from_kind_name(name).ok_or_else(|| format!("unknown opcode name `{name}`"))?;
    let a = u32::try_from(as_i64(elems[1])?)
        .map_err(|_| format!("negative or huge `a` operand in `{name}`"))?;
    let b = u32::try_from(as_i64(elems[2])?)
        .map_err(|_| format!("negative or huge `b` operand in `{name}`"))?;
    Ok(Instr { op, a, b })
}

/// Rebuild one debug span record `(s e gen)` — the offsets parsed
/// from their decimal strings, the generation int carried into the
/// `ExpansionId` (the field the dump text leaves outside; the
/// rebuild is where it lands — 2.5 MUV ①'s field-completeness
/// point: macro-introduced instructions carry their generations).
fn rebuild_span(v: &Value, heap: &Heap) -> Result<Span, String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 3, "debug-info span record")?;
    let start = as_str(elems[0])?;
    let s: u32 = start
        .parse()
        .map_err(|_| format!("bad span start `{start}`"))?;
    let end = as_str(elems[1])?;
    let e: u32 = end.parse().map_err(|_| format!("bad span end `{end}`"))?;
    let g = u32::try_from(as_i64(elems[2])?).map_err(|_| "negative generation".to_string())?;
    Span::new(FileId(0), ByteOffset(s), ByteOffset(e), ExpansionId(g))
        .map_err(|err| format!("rebuilt span rejected: {err:?}"))
}

/// Rebuild one proto record `("proto" name params n-locals ("caps"
/// src...) ("code" insn...) ("dbg" sp...))` into a `FuncProto`.
fn rebuild_proto(v: &Value, heap: &Heap) -> Result<FuncProto, String> {
    let elems = value_elems(v, heap)?;
    need_fields(&elems, 7, "`proto` product record")?;
    let name = match elems[1] {
        Value::Nil => None,
        _ => Some(Symbol::new(&ktf_name(elems[1], heap)?).map_err(|e| e.to_string())?),
    };
    let params =
        u32::try_from(as_i64(elems[2])?).map_err(|_| "proto params out of range".to_string())?;
    let n_locals =
        u32::try_from(as_i64(elems[3])?).map_err(|_| "proto n_locals out of range".to_string())?;
    fn section<'a>(
        v: &'a Value,
        tag: &'static str,
        heap: &'a Heap,
    ) -> Result<Vec<&'a Value>, String> {
        let fields = value_elems(v, heap)?;
        if as_str(fields.first().ok_or("empty proto field")?)? != tag {
            return Err(format!(
                "proto field order: expected `{tag}`, found `{}`",
                as_str(fields[0])?
            ));
        }
        Ok(fields[1..].to_vec())
    }
    let caps = section(elems[4], "caps", heap)?;
    let code = section(elems[5], "code", heap)?;
    let dbg = section(elems[6], "dbg", heap)?;
    let mut proto = FuncProto::new(name, params, n_locals);
    for src in caps {
        proto.captures.push(rebuild_capture(src, heap)?);
    }
    for insn in code {
        proto.code.push(rebuild_insn(insn, heap)?);
    }
    for sp in dbg {
        proto.debug_info.push(rebuild_span(sp, heap)?);
    }
    Ok(proto)
}

/// Rebuild the `.ktf` compiler's `("ok" ...)` product into a real
/// [`Bytecode`] — the 2.5 MUV ① face. Every product section lands
/// field-for-field: protos (names through the mangled-name decoder,
/// captures, instruction streams through the opcode reverse table,
/// debug spans with their generations), the interned globals, and
/// the constant pool through the literal decoder. `Bytecode::verify`
/// runs before the product returns: a rebuilt product is a loadable
/// program or it is an error — never a half image (the fail-closed
/// contract; the witness lineage of §9.87.5 now lands on the
/// structural face).
pub fn rebuild_bytecode(value: &Value, heap: &Heap) -> Result<Bytecode, String> {
    let elems = value_elems(value, heap)?;
    let tag = as_str(
        elems
            .first()
            .ok_or_else(|| "the product value is not a tagged list".to_string())?,
    )?;
    if tag != "ok" {
        return Err(format!(
            "rebuild_bytecode needs the ok product, found `{tag}` (the error axis \
             is owned by the parity faces)"
        ));
    }
    let mut bc = Bytecode::default();
    for section in &elems[1..] {
        let fields = value_elems(section, heap)?;
        let tag = as_str(
            fields
                .first()
                .ok_or_else(|| "a section record must be non-empty".to_string())?,
        )?;
        match tag {
            "funcs" => {
                for proto in &fields[1..] {
                    bc.funcs.push(rebuild_proto(proto, heap)?);
                }
            }
            "globals" => {
                for name in &fields[1..] {
                    bc.globals
                        .push(Symbol::new(&ktf_name(name, heap)?).map_err(|e| e.to_string())?);
                }
            }
            "consts" => {
                for lit in &fields[1..] {
                    bc.consts.push(rebuild_lit(lit, heap)?);
                }
            }
            // The r124 junction-3 parity extension: the externs
            // section rebuilds into `Bytecode::externs` — the gate-B
            // `Bytecode: PartialEq` then covers the table
            // structurally, and `bc.verify()` (below) judges it
            // through the same single floor as every hand-built
            // product (`extern_table_floor`, the r123 two-judges
            // contract).
            "externs" => {
                for entry in &fields[1..] {
                    bc.externs.push(rebuild_extern_entry(entry, heap)?);
                }
            }
            other => return Err(format!("unknown product section `{other}`")),
        }
    }
    bc.verify()
        .map_err(|err| format!("rebuilt product rejected by verify: {err}"))?;
    Ok(bc)
}

/// Rebuild one extern entry record `("name" ("param" ...) "ret")`
/// into an `ExternEntry` (name symbolized, params and ret reversed
/// through the single-source kind-tag table).
fn rebuild_extern_entry(v: &Value, heap: &Heap) -> Result<ExternEntry, String> {
    let entry = value_elems(v, heap)?;
    need_fields(&entry, 3, "extern entry product record")?;
    let name = Symbol::new(&ktf_name(entry[0], heap)?).map_err(|e| e.to_string())?;
    let params = value_elems(entry[1], heap)?;
    let mut param_types = Vec::with_capacity(params.len());
    for p in params {
        param_types.push(extern_type_from_kind_tag(&ktf_name(p, heap)?)?);
    }
    let ret = extern_type_from_kind_tag(&ktf_name(entry[2], heap)?)?;
    Ok(ExternEntry {
        name,
        params: param_types,
        ret,
    })
}

/// Reverse one extern kind tag through the single-source table
/// (`ExternType::kind_tag` — the same three-word closed set).
fn extern_type_from_kind_tag(tag: &str) -> Result<ExternType, String> {
    match tag {
        "int" => Ok(ExternType::Int),
        "bool" => Ok(ExternType::Bool),
        "float" => Ok(ExternType::Float),
        other => Err(format!("unknown extern type tag `{other}`")),
    }
}

// ---------- the structured-error rebuild (error axis) ----------

/// Rebuild the analysis-reachable `CompileError` family from the
/// `.ktf` rejection record (the LA-7 compile-side boundary and the
/// depth mirror; `bad-node` is the fail-closed harness-stream
/// defense, reported as a harness defect).
pub(crate) fn rebuild_compile_error(value: &Value, heap: &Heap) -> Result<CompileError, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "analysis rejection record")?;
    let kind = as_str(elems[1])?;
    match kind {
        "assign-to-captured" => {
            need_fields(&elems, 5, "`assign-to-captured` rejection")?;
            Ok(CompileError::AssignToCaptured {
                name: Symbol::new(&ktf_name(elems[2], heap)?).map_err(|e| e.to_string())?,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "depth" => {
            need_fields(&elems, 5, "`depth` rejection")?;
            let depth = as_i64(elems[2])?;
            if depth < 0 {
                return Err(format!("negative depth payload `{depth}`"));
            }
            Ok(CompileError::DepthExceeded {
                depth: depth as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        // The r124 junction-3 consumption: the twins' own
        // name-uniqueness rejection (the only C-domain face the
        // frozen subset can express — `eq?` is content comparison
        // for strings). The derived-symbol character police stays
        // the disclosed blind face (§6e): zero character ops in
        // the 18 builtins, so the twins compile those rows on.
        "extern-name-duplicate" => {
            need_fields(&elems, 4, "`extern-name-duplicate` rejection")?;
            let index = as_i64(elems[2])?;
            if index < 0 {
                return Err(format!("negative entry index payload `{index}`"));
            }
            Ok(CompileError::ExternNameDuplicate {
                index: index as usize,
                name: Symbol::new(&ktf_name(elems[3], heap)?).map_err(|e| e.to_string())?,
            })
        }
        "stack-underflow" => {
            need_fields(&elems, 5, "`stack-underflow` rejection")?;
            let pc = as_i64(elems[2])?;
            if pc < 0 {
                return Err(format!("negative pc payload `{pc}`"));
            }
            Ok(CompileError::StackUnderflow {
                pc: pc as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "stack-imbalance" => {
            need_fields(&elems, 7, "`stack-imbalance` rejection")?;
            let pc = as_i64(elems[2])?;
            let expected = as_i64(elems[3])?;
            let actual = as_i64(elems[4])?;
            if pc < 0 || expected < 0 || actual < 0 {
                return Err(format!(
                    "negative payload in stack-imbalance `{pc} {expected} {actual}`"
                ));
            }
            Ok(CompileError::StackImbalance {
                pc: pc as usize,
                expected: expected as u32,
                actual: actual as u32,
                span: make_span(elems[5], elems[6])?,
            })
        }
        "unpatched-jump" => {
            need_fields(&elems, 5, "`unpatched-jump` rejection")?;
            let at = as_i64(elems[2])?;
            if at < 0 {
                return Err(format!("negative pc payload `{at}`"));
            }
            Ok(CompileError::UnpatchedJump {
                at: at as usize,
                span: make_span(elems[3], elems[4])?,
            })
        }
        "bad-patch" => Err(format!(
            "the .ktf emitter tried to patch a non-placeholder pc `{}` — a .ktf \
             harness defect, never a source defect",
            as_i64(*elems.get(2).ok_or("bad-patch payload")?)?
        )),
        "bad-node" => Err(format!(
            "the .ktf analysis hit an unknown node kind `{}` — the injected stream \
             is malformed (a harness defect, never a source defect)",
            ktf_name(elems[2], heap)?
        )),
        other => Err(format!("unknown analysis rejection kind `{other}`")),
    }
}

// ---------- the case driver ----------

/// The rich drive's outcome: both engines' rendered verdict texts
/// plus the vm-side product rebuilt as a real [`Bytecode`] (the ok
/// axis). The verdict values stay crate-side; the texts are the
/// comparison face external consumers need.
pub struct RichCompileRun {
    pub vm_text: String,
    pub eval_text: String,
    pub bytecode: Option<Bytecode>,
}

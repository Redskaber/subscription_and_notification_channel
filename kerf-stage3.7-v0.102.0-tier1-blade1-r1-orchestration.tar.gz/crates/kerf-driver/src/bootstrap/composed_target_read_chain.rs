//! The W-TGT-READ-TWIN blade-3 composed TARGET-read chain
//! (bootstrap-completion-plan §4.2 blade 3 — the C1 closure's
//! composed face): a TARGET-skin input source driven through the
//! TARGET read twins and forward through the whole `.ktf` chain —
//! the C1 formula instantiated junction by junction:
//!
//! ```text
//! pipeline_ktf(S) == pipeline_rust(S)
//!   == compile(expand(read_target_program(S)))     — the oracle
//!   == compile_ktf(expand_ktf(read_ktf(S)))        — the twin chain
//!         where read_ktf(S)  = the STEADY target read chain
//!           (lexer twin → bridge → parser twin), and
//!         expand_ktf        = the STEADY expander chain
//!           (the value face — the r103 i64::MIN text boundary
//!            does not apply to the injected records), and
//!         compile_ktf       = ktf_compile_rich (the assembled
//!           route — the .ktf compiler twin).
//! ```
//!
//! Five junctions, each a differential gate (the §9.87 spine carried
//! to the TARGET-skin input):
//!
//! * **J0 — the token axis** (the steady chain's lexer layer): the
//!   steady twin's token dump == the oracle `lex_target` dump.
//! * **J0.5 — the tree axis** (the steady chain's parser layer): the
//!   steady twin's tree dump == the oracle `read_target_program`
//!   dump — the C1 formula's read segment, kerf-hosted.
//! * **J1 — the expansion layer**: the steady chain's REBUILT forms
//!   feed the steady expander chain (both engines); the items match
//!   the oracle's expansion of the ORACLE's forms (the 1.6
//!   criterion in-chain: the tree identity gate).
//! * **J1.5 — the check layer**: the steady check chain on the
//!   twin-expanded items == the oracle's check axes (the C1 chain's
//!   查 segment — the HM twins in the composed chain).
//! * **J2 — the compile layer**: the `.ktf` compiler twin on the
//!   twin-expanded items (both engines), the rebuilt product ==
//!   the oracle's compilation of the same items (the C1 formula's
//!   terminal equality: bytecode-identical).
//!
//! The routing is TOTAL (the §9.87.4 drift ledger carried over): a
//! source the oracle rejects at the read layer (either axis) verifies
//! on J0/J0.5's error axis and never feeds forward; an expander
//! rejection on J1's; a check rejection on J1.5's; a compile
//! rejection on J2's. Every case lands in exactly one layer.
//!
//! The twin front-end read (`twin_front_end_read`) is the FIXPOINT
//! PURITY LEG's face (K159's precondition — the fixpoint's Phase-2
//! read segment switches from the Rust production bridge to this
//! route): the same steady chains, the same bridge, the same
//! decoders — the fixpoint's assembled self-applied program read
//! through the language's own twins.

use kerf_compiler::compile_program;
use kerf_core::ModuleItem;
use kerf_reader::read_target_program;

use crate::bootstrap::reader_parity::error_parity_key;
use crate::bootstrap::steady_expander_chain::SteadyExpanderChain;
use crate::bootstrap::steady_target_reader_chain::SteadyTargetReaderChain;
use crate::bootstrap::steady_typecheck_chain::SteadyCheckChain;
use crate::bootstrap::target_corpus::ktf_compile_rich;
use crate::bootstrap::target_lexer_parity::target_oracle_token_dump;
use crate::bootstrap::target_parser_parity::target_parser_oracle_dump;
use crate::bootstrap::typecheck_parity::oracle_check_axes;

/// The composed TARGET-read chain's layer set — `ComposedLayer`
/// extended with the check layer (the C1 chain's 查 segment; the
/// existing composed chains predate the check twins' elevation).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TargetReadLayer {
    /// The steady target read chain (either axis): a read-layer
    /// rejection, or a J0/J0.5 drift. Downstream junctions are
    /// vacuous.
    Read,
    /// The expansion layer: a twin-expander rejection verified on
    /// the error axis, or a J1 drift.
    Expand,
    /// The check layer: a twin-checker rejection, or a J1.5 drift.
    Check,
    /// The compile layer: products or compile-error keys, or a J2
    /// drift.
    Compile,
}

/// One composed TARGET-read chain case's outcome (the
/// `ComposedTargetChainReport` shape carried to the TARGET-skin
/// input, extended with the check junction).
#[derive(Debug, Clone)]
pub struct ComposedTargetReadReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// The layer that decided the case.
    pub layer: TargetReadLayer,
    /// J0 (the token axis): matched.
    pub token_matched: bool,
    /// J0.5 (the tree axis): matched.
    pub tree_matched: bool,
    /// J1 (the expansion layer): `Some(matched)` when the chain fed
    /// it (vacuous — `None` — on a read-layer rejection).
    pub expand_matched: Option<bool>,
    /// J1.5 (the check layer): `Some(matched)` when fed.
    pub check_matched: Option<bool>,
    /// J2 (the compile layer): `Some(matched)` when fed.
    pub compile_matched: Option<bool>,
    /// Both engines agreed at every junction reached.
    pub engines_agree: bool,
    /// The whole chain matched (all reached junctions).
    pub matched: bool,
    /// The mismatch description when `!matched` — names the failing
    /// junction, never a bare product diff.
    pub drift: Option<String>,
}

impl ComposedTargetReadReport {
    /// The one-line failure form (the `failure_line` lineage —
    /// corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("composed target-read chain FAIL [{}]: {}", self.case, d),
            None => format!("composed target-read chain PASS [{}]", self.case),
        }
    }
}

/// Does the form tree carry a `match` head (the twin expander's
/// frozen-subset scope boundary)? The subset's six tables exclude
/// the `match` desugar (subset-spec 1.2 — the eight expression
/// forms); the ORACLE's expander carries it as a superset
/// (`expand_match`), so a match-carrying program expands on the
/// oracle side and rejects on the twin side with a different key —
/// the honest disclosed boundary row (the r103 precedent), never a
/// silent drift. The registered follow-up: the twin expander's
/// match arm (the tech-debt ledger's blade-3 row).
fn forms_carry_match_head(forms: &[kerf_syntax::SyntaxObject]) -> bool {
    use kerf_syntax::StxDatum;
    fn node_carries(node: &kerf_syntax::SyntaxObject) -> bool {
        match &node.datum {
            StxDatum::List(items) => {
                if let Some(head) = items.first() {
                    if matches!(&head.datum, StxDatum::Symbol(sym) if sym.as_str() == "match") {
                        return true;
                    }
                }
                items.iter().any(node_carries)
            }
            _ => false,
        }
    }
    forms.iter().any(node_carries)
}

/// The plain face: the canonical steady chains, both engines at
/// every junction, the full C1 formula.
pub fn composed_target_read_chain_parity(case: &str, source: &str) -> ComposedTargetReadReport {
    // ---- J0 + J0.5: the steady target read chain, both engines ----
    let chain = match SteadyTargetReaderChain::new() {
        Ok(chain) => chain,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Read,
                token_matched: false,
                tree_matched: false,
                expand_matched: None,
                check_matched: None,
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    composed_target_read_chain_on(&chain, case, source)
}

/// The chain-reuse face (the tests hold ONE constructed chain across
/// the sweep — the steady chain's whole point: compile once, read
/// per source).
pub fn composed_target_read_chain_on(
    chain: &SteadyTargetReaderChain,
    case: &str,
    source: &str,
) -> ComposedTargetReadReport {
    // ---- J0/J0.5: the steady read, both engines ----
    let (vm_read, eval_read) = match chain.read_dual(source) {
        Ok(pair) => pair,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Read,
                token_matched: false,
                tree_matched: false,
                expand_matched: None,
                check_matched: None,
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    if vm_read.token_dump != eval_read.token_dump || vm_read.tree_dump != eval_read.tree_dump {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Read,
            token_matched: false,
            tree_matched: false,
            expand_matched: None,
            check_matched: None,
            compile_matched: None,
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "J0/J0.5: steady engines disagree: token {} / tree {}",
                vm_read.token_dump != eval_read.token_dump,
                vm_read.tree_dump != eval_read.tree_dump
            )),
        };
    }
    let oracle_tokens = match target_oracle_token_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let oracle_tree = match target_parser_oracle_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let token_matched = vm_read.token_dump == oracle_tokens;
    let tree_matched = vm_read.tree_dump == oracle_tree;
    if !(token_matched && tree_matched) {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Read,
            token_matched,
            tree_matched,
            expand_matched: None,
            check_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some(format!(
                "J0/J0.5: oracle tokens {} / tree {} — token match {token_matched}, tree match {tree_matched}",
                if oracle_tokens.len() > 60 {
                    &oracle_tokens[..60]
                } else {
                    &oracle_tokens
                },
                if oracle_tree.len() > 60 {
                    &oracle_tree[..60]
                } else {
                    &oracle_tree
                },
            )),
        };
    }
    // A matched READ is either both-accepted or both-rejected (the
    // error axis is part of the comparison — a rejection with the
    // same key on both sides is a MATCH at this layer): a matched
    // REJECTION is the Read layer's own PASS row — the chain never
    // feeds forward (the §9.87.4 total routing).
    if vm_read.forms.is_none() {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Read,
            token_matched: true,
            tree_matched: true,
            expand_matched: None,
            check_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: true,
            drift: None,
        };
    }
    // Both sides accepted — the forms feed must be present (a
    // matched acceptance with no forms is a defect, never a pass).
    let Some(forms) = vm_read.forms.clone() else {
        unreachable!("the forms check rode the is_none arm above");
    };
    // ---- J0.9: the twin expander's frozen-subset scope boundary
    // (the match desugar — the honest disclosed row, the r103
    // precedent): the corpus carries no match programs (the 91-case
    // acceptance corpus is match-free by design), so the C1 sweep
    // is unaffected; a match-carrying input (the curated parser
    // family includes five) classifies here, never a silent drift.
    // ----
    if forms_carry_match_head(&forms) {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Expand,
            token_matched: true,
            tree_matched: true,
            expand_matched: None,
            check_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some(
                "harness boundary: the twin expander frozen-subset scope (subset-spec 1.2 \
                 the eight expression forms) excludes the match desugar the oracle superset \
                 carries; the corpus is match-free by design, the boundary is disclosed \
                 here, and the twin match arm is the registered follow-up (the tech-debt \
                 ledger blade-3 row)"
                    .to_string(),
            ),
        };
    }
    // ---- J1: the expansion layer — the steady expander chain on
    // the steady read's own forms, both engines (the value face —
    // the r103 i64::MIN text boundary does not apply). ----
    let expander = match SteadyExpanderChain::new() {
        Ok(chain) => chain,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Expand,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(false),
                check_matched: None,
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    let (vm_expansion, eval_expansion) = match expander.expand_dual(&forms) {
        Ok(pair) => pair,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Expand,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(false),
                check_matched: None,
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    if vm_expansion.text != eval_expansion.text {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Expand,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(false),
            check_matched: None,
            compile_matched: None,
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "J1: steady expander engines disagree: `{}` vs `{}`",
                vm_expansion.text, eval_expansion.text
            )),
        };
    }
    // The oracle's own expansion of the ORACLE's forms — the
    // differential at this junction (the oracle read produced the
    // same tree by the J0.5 gate, so the oracle forms ARE the twin's
    // rebuilt forms; the expansion rides either face identically).
    let oracle_forms = match read_target_program(kerf_span::FileId(0), source) {
        Ok(forms) => forms,
        Err(err) => {
            // Unreachable post-J0.5 (the oracle tree matched) — the
            // defensive arm names it, never a silent pass.
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Expand,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(false),
                check_matched: None,
                compile_matched: None,
                engines_agree: true,
                matched: false,
                drift: Some(format!(
                    "harness defect: the oracle read rejected post-J0.5: {}",
                    error_parity_key(&err)
                )),
            };
        }
    };
    let oracle_items = match crate::bootstrap::expander_parity::oracle_expansion(&oracle_forms) {
        Ok(items) => items,
        Err(oracle_key) => {
            // The ledger's Expand row: the twin expander must reject
            // with the same parity key.
            let matched = vm_expansion.text == oracle_key && vm_expansion.items.is_none();
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Expand,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(matched),
                check_matched: None,
                compile_matched: None,
                engines_agree: true,
                matched,
                drift: if matched {
                    None
                } else {
                    Some(format!(
                        "J1: oracle `{oracle_key}` vs twin `{}`",
                        vm_expansion.text
                    ))
                },
            };
        }
    };
    // The tree identity gate (the 1.6 criterion in-chain).
    let Some(items) = vm_expansion.items.clone() else {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Expand,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(false),
            check_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some(format!(
                "J1: the oracle expanded but the twin expander rejected: {}",
                vm_expansion.text
            )),
        };
    };
    if items != oracle_items {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Expand,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(false),
            check_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some("J1: tree drift between the twin expander and the oracle".to_string()),
        };
    }
    // ---- J1.5: the check layer — the steady check chain on the
    // twin-expanded items (the C1 chain's 查 segment). ----
    let checker = match SteadyCheckChain::new() {
        Ok(chain) => chain,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Check,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(true),
                check_matched: Some(false),
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    let (vm_check, eval_check) = match checker.check_dual(&items) {
        Ok(pair) => pair,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Check,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(true),
                check_matched: Some(false),
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    if vm_check != eval_check {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Check,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(true),
            check_matched: Some(false),
            compile_matched: None,
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "J1.5: checker engines disagree: `{vm_check}` vs `{eval_check}`"
            )),
        };
    }
    let oracle_check = oracle_check_axes(&items);
    let check_matched = vm_check == oracle_check;
    if !check_matched {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Check,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(true),
            check_matched: Some(false),
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some(format!(
                "J1.5: oracle `{oracle_check}` vs twin `{vm_check}`"
            )),
        };
    }
    // ---- J2: the compile layer — the .ktf compiler twin on the
    // twin-expanded items, both engines; the rebuilt product equals
    // the oracle's compilation of the same items (the C1 formula's
    // terminal equality: bytecode-identical). ----
    let run = match ktf_compile_rich(
        &items,
        crate::bootstrap::target_corpus::COMPILER_TARGET_SOURCE,
    ) {
        Ok(run) => run,
        Err(defect) => {
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Compile,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(true),
                check_matched: Some(true),
                compile_matched: Some(false),
                engines_agree: false,
                matched: false,
                drift: Some(defect),
            };
        }
    };
    if run.vm_text != run.eval_text {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Compile,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(true),
            check_matched: Some(true),
            compile_matched: Some(false),
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "J2: compiler engines disagree: `{}` vs `{}`",
                run.vm_text, run.eval_text
            )),
        };
    }
    let oracle_bc = match compile_program(&items) {
        Ok(bc) => bc,
        Err(err) => {
            // The ledger's Compile row: the twin compiler must reject
            // with the same compile-error key.
            let matched = run.vm_text == format!("ERR {err}");
            return ComposedTargetReadReport {
                case: case.to_string(),
                layer: TargetReadLayer::Compile,
                token_matched: true,
                tree_matched: true,
                expand_matched: Some(true),
                check_matched: Some(true),
                compile_matched: Some(matched),
                engines_agree: true,
                matched,
                drift: if matched {
                    None
                } else {
                    Some(format!("J2: oracle `ERR {err}` vs twin `{}`", run.vm_text))
                },
            };
        }
    };
    let Some(twin_bc) = run.bytecode.clone() else {
        return ComposedTargetReadReport {
            case: case.to_string(),
            layer: TargetReadLayer::Compile,
            token_matched: true,
            tree_matched: true,
            expand_matched: Some(true),
            check_matched: Some(true),
            compile_matched: Some(false),
            engines_agree: true,
            matched: false,
            drift: Some(format!(
                "J2: the oracle compiled but the twin compiler rejected: {}",
                run.vm_text
            )),
        };
    };
    let compile_matched = twin_bc == oracle_bc;
    ComposedTargetReadReport {
        case: case.to_string(),
        layer: TargetReadLayer::Compile,
        token_matched: true,
        tree_matched: true,
        expand_matched: Some(true),
        check_matched: Some(true),
        compile_matched: Some(compile_matched),
        engines_agree: true,
        matched: compile_matched,
        drift: if compile_matched {
            None
        } else {
            Some(
                "J2: bytecode drift between the twin compiler's product and the oracle's"
                    .to_string(),
            )
        },
    }
}

/// The twin front-end read (the FIXPOINT PURITY LEG's face — K159's
/// precondition): a target-skin source read through the TARGET read
/// twins (the steady chain) and expanded through the steady expander
/// chain — the items the Rust production bridge would have produced,
/// computed by the language's own twins end-to-end. The engines agree
/// at every junction; the caller (the fixpoint) asserts the equality
/// with the production bridge's own items.
pub fn twin_front_end_read(name: &str, source: &str) -> Result<Vec<ModuleItem>, String> {
    let chain = SteadyTargetReaderChain::new()?;
    let (vm_read, eval_read) = chain.read_dual(source)?;
    if vm_read.tree_dump != eval_read.tree_dump {
        return Err(format!(
            "twin front end [{name}]: steady read engines disagree on the tree axis"
        ));
    }
    let Some(forms) = vm_read.forms else {
        return Err(format!(
            "twin front end [{name}]: the steady read rejected the source: {}",
            vm_read.tree_dump
        ));
    };
    let expander = SteadyExpanderChain::new()?;
    let (vm_expansion, eval_expansion) = expander.expand_dual(&forms)?;
    if vm_expansion.text != eval_expansion.text {
        return Err(format!(
            "twin front end [{name}]: steady expander engines disagree"
        ));
    }
    vm_expansion
        .into_items()
        .map_err(|key| format!("twin front end [{name}]: the twin expander rejected: {key}"))
}

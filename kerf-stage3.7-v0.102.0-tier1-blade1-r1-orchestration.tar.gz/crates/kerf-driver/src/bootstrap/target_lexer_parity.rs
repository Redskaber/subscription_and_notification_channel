//! Target-lexer parity — the W-TGT-READ-TWIN blade 1 harness (gap G1
//! of bootstrap-completion-plan.md §4.2): the target-skin LEXICAL
//! layer, written in the frozen kerf subset itself
//! (`selfhost/v1/target-lexer.ktf` — the eighth selfhost twin, the
//! first that mirrors the TARGET read chain rather than the S-expr
//! one), checked against the Rust target lexer oracle
//! (`kerf_reader::lex_target`) through the full `.ktf` chain on both
//! engines. The source rides in as a byte table (the RS-1 channel;
//! the S-expr prefix text is the internal intermediate, which the
//! target face transcodes through `target_byte_table_prefix`), the
//! twin makes every lexical decision, and the harness decodes the
//! `tl_verdict` global (aliased `result` — the `drive_dual_engines`
//! contract) from BOTH engines.
//!
//! One axis, byte-for-byte (the lexer_parity lineage specialized to
//! the target face):
//!
//! * **Token axis** — the oracle `lex_target` token stream and the
//!   twin's `tl_verdict` normalize to the same per-record dump
//!   (`(kw-fn s e)`, `(ident s e mapped)`, `(int s e v)`, ..., one
//!   line per token, ending `(eof e)`), so lexical drift localizes
//!   to the exact record; on a rejection both sides render through
//!   the oracle's own `Display` plus the harness `@ byte` suffix
//!   (the §9.56 DIAG-1 error key), so the kind AND the payload
//!   compare byte-precisely.
//!
//! The permanent host layer (K20, the documented honest boundary —
//! the same division lexer_parity carries on the S-expr face):
//! the **float value face** (a twin float record carries its span;
//! the harness derives the f64 with the same `_`-stripped Rust
//! `parse` the oracle used, mapping non-finite to the
//! `FloatOutOfRange` key — the twin decided the GRAMMAR, the host
//! applies the value semantics), the **string payload decode** (the
//! v9 escape family — no string construction exists in the subset),
//! and the **ident skin mapping** (`skin_symbol` is the oracle's own
//! single source; the twin's ident record carries no payload and the
//! harness maps the span text through it). Every other decision —
//! trivia, the comment families with nesting, word-face
//! classification, the number grammar per radix, the in-twin i64
//! value with its threshold guards, escape validity including the
//! `\u{...}` domain, string termination, maximal munch — is made in
//! `target-lexer.ktf`.

use kerf_reader::{ReadError, TgtKind, lex_target, skin_symbol};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_vm::{Heap, Value};

use crate::bootstrap::reader_parity::{
    as_i64, as_str, drive_dual_engines, error_parity_key, need_fields, value_elems,
};
use crate::bootstrap::target_corpus::{TARGET_LEXER_TARGET_SOURCE, target_byte_table_prefix};
use crate::pipeline::ReaderFace;

// ---------------------------------------------------------------------------
// The K20 host derivations (the shared single-source transforms both
// sides of the comparison ride)
// ---------------------------------------------------------------------------

/// Strip the `_` separators from a numeric lexeme (the oracle's
/// `digits_text` counterpart — the parse input on both faces).
/// `pub(crate)` since blade 3 (the steady target read chain's
/// bridge rides the same single source — the K20 float face).
pub(crate) fn strip_us(text: &str) -> String {
    text.chars().filter(|c| *c != '_').collect()
}

/// Decode a string literal's raw body (the span text between the
/// quotes): the v9 escape family `\n` `\t` `\r` `\0` `\\` `\"` `\'`
/// plus `\u{1..6 hex}` with `_` separators — the decode-side mirror
/// of `lex_string`, the permanent host transform (the twin made the
/// validity/boundary decisions). Invalid sequences are unreachable
/// post-validation; the defensive arms copy the raw char through so
/// a harness bug surfaces as drift, never as a silent invention.
/// `pub(crate)` since blade 3 (the steady target read chain's
/// bridge rides the same single source — the K20 string face).
pub(crate) fn decode_target_string(raw: &str) -> String {
    let bytes = raw.as_bytes();
    let mut out = String::new();
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b != b'\\' {
            // Ordinary char: copy the UTF-8 sequence whole.
            let ch = raw[i..].chars().next().unwrap_or('\u{fffd}');
            out.push(ch);
            i += ch.len_utf8();
            continue;
        }
        i += 1;
        if i >= bytes.len() {
            break; // unreachable post-validation (trailing backslash)
        }
        match bytes[i] {
            b'n' => {
                out.push('\n');
                i += 1;
            }
            b't' => {
                out.push('\t');
                i += 1;
            }
            b'r' => {
                out.push('\r');
                i += 1;
            }
            b'0' => {
                out.push('\0');
                i += 1;
            }
            b'\\' => {
                out.push('\\');
                i += 1;
            }
            b'"' => {
                out.push('"');
                i += 1;
            }
            b'\'' => {
                out.push('\'');
                i += 1;
            }
            b'u' => {
                // `\u{ hex, `_`-separated, 1..6 digits }` — validated
                // in-twin; walk to the brace and fold the hex.
                let mut j = i + 2;
                let mut code: u32 = 0;
                while j < bytes.len() && bytes[j] != b'}' {
                    let d = bytes[j];
                    if d.is_ascii_hexdigit() {
                        code = code * 16 + (d as char).to_digit(16).unwrap_or(0);
                    }
                    j += 1;
                }
                if j >= bytes.len() {
                    break; // unreachable post-validation (no brace)
                }
                match char::from_u32(code) {
                    Some(ch) => out.push(ch),
                    // Unreachable post-validation (the twin rejected
                    // surrogates and the out-of-range face) — kept
                    // defensive, never silent.
                    None => out.push('\u{fffd}'),
                }
                i = j + 1;
            }
            // Unreachable post-validation — copy the raw byte's char.
            other => {
                out.push(other as char);
                i += 1;
            }
        }
    }
    out
}

/// Slice the source by byte offsets (a record's span payload); a
/// malformed span is a harness defect, never a panic.
pub(crate) fn slice_src<'a>(
    source: &'a str,
    s: i64,
    e: i64,
    what: &str,
) -> Result<&'a str, String> {
    let (s, e) = (s as usize, e as usize);
    if s > e || e > source.len() || !source.is_char_boundary(s) || !source.is_char_boundary(e) {
        return Err(format!(
            "harness defect: {what} span {s}..{e} is not a valid slice of a {}-byte source",
            source.len()
        ));
    }
    Ok(&source[s..e])
}

/// The whole-token span of the literal-family rejections (the text
/// payload rides the RAW source slice — underscores included —
/// matching the oracle's own `source[start..i]` payloads).
fn text_span(source: &str, s: i64, e: i64) -> Result<(String, Span), String> {
    let text = slice_src(source, s, e, "error")?.to_owned();
    let span = Span::new(
        FileId(0),
        ByteOffset(s as u32),
        ByteOffset(e as u32),
        ExpansionId::ROOT,
    )
    .map_err(|err| format!("harness defect: rebuilt span rejected: {err}"))?;
    Ok((text, span))
}

/// The oracle tag of one word/operator kind — the dump grammar's
/// tag face (the twin's record tags spell the same strings).
pub(crate) fn kind_tag(kind: &TgtKind) -> &'static str {
    match kind {
        TgtKind::Ident(_) => "ident",
        TgtKind::Int(_) => "int",
        TgtKind::Float(_) => "float",
        TgtKind::Str(_) => "str",
        TgtKind::Bool(_) => "bool",
        TgtKind::KwFn => "kw-fn",
        TgtKind::KwLet => "kw-let",
        TgtKind::KwMut => "kw-mut",
        TgtKind::KwIf => "kw-if",
        TgtKind::KwElse => "kw-else",
        TgtKind::KwMatch => "kw-match",
        TgtKind::KwPerform => "kw-perform",
        TgtKind::KwHandle => "kw-handle",
        TgtKind::KwModule => "kw-module",
        TgtKind::KwUse => "kw-use",
        TgtKind::KwExtern => "kw-extern",
        TgtKind::KwMacro => "kw-macro",
        TgtKind::KwPub => "kw-pub",
        TgtKind::KwStruct => "kw-struct",
        TgtKind::KwEnum => "kw-enum",
        TgtKind::KwType => "kw-type",
        TgtKind::KwEffect => "kw-effect",
        TgtKind::KwCapability => "kw-capability",
        TgtKind::KwMove => "kw-move",
        TgtKind::KwAs => "kw-as",
        TgtKind::KwImpl => "kw-impl",
        TgtKind::KwResume => "kw-resume",
        TgtKind::KwHalt => "kw-halt",
        TgtKind::KwPass => "kw-pass",
        TgtKind::OpenBrace => "open-brace",
        TgtKind::CloseBrace => "close-brace",
        TgtKind::OpenParen => "open-paren",
        TgtKind::CloseParen => "close-paren",
        TgtKind::OpenBracket => "open-bracket",
        TgtKind::CloseBracket => "close-bracket",
        TgtKind::Semi => "semi",
        TgtKind::Comma => "comma",
        TgtKind::Colon => "colon",
        TgtKind::ColonColon => "colon-colon",
        TgtKind::Arrow => "arrow",
        TgtKind::FatArrow => "fat-arrow",
        TgtKind::Dot => "dot",
        TgtKind::DotDot => "dot-dot",
        TgtKind::Ellipsis => "ellipsis",
        TgtKind::Bang => "bang",
        TgtKind::Assign => "assign",
        TgtKind::Plus => "plus",
        TgtKind::Minus => "minus",
        TgtKind::Star => "star",
        TgtKind::Slash => "slash",
        TgtKind::Percent => "percent",
        TgtKind::Lt => "lt",
        TgtKind::Gt => "gt",
        TgtKind::Le => "le",
        TgtKind::Ge => "ge",
        TgtKind::EqEq => "eq-eq",
        TgtKind::NotEq => "not-eq",
        TgtKind::AndAnd => "and-and",
        TgtKind::OrOr => "or-or",
        TgtKind::Amp => "amp",
        TgtKind::Pipe => "pipe",
        TgtKind::Caret => "caret",
        TgtKind::Shl => "shl",
        TgtKind::Shr => "shr",
        TgtKind::Eof => "eof",
    }
}

// ---------------------------------------------------------------------------
// The oracle side
// ---------------------------------------------------------------------------

/// The oracle's per-record token dump — the token-axis grammar both
/// sides normalize to. One record per line; the literal payloads
/// carry the K20 HOST-DERIVED form (the float parsed from the
/// `_`-stripped span — asserted equal to the oracle's own value, a
/// self-check of the harness mirror — and the string decoded from
/// the span body — asserted equal to the oracle's own value), so the
/// dump carries exactly what the twin can produce and a drift
/// localizes to the exact record and field.
pub fn target_oracle_token_dump(source: &str) -> Result<String, ReadError> {
    let tokens = lex_target(FileId(0), source)?;
    let mut out = String::new();
    for t in &tokens {
        let (s, e) = (t.span.start.0, t.span.end.0);
        let line = match &t.kind {
            TgtKind::Ident(sym) => format!("(ident {s} {e} {})\n", sym.as_str()),
            TgtKind::Int(v) => format!("(int {s} {e} {v})\n"),
            TgtKind::Float(v) => {
                // The K20 self-check: the oracle's own value equals
                // the host derivation the twin side will ride (both
                // parse the same `_`-stripped span text; the spans
                // are the oracle's own, so the slice is safe by
                // construction — a violation is a harness bug and
                // fails loudly, never silently).
                let raw = &source[s as usize..e as usize];
                let derived: f64 = strip_us(raw).parse().unwrap_or_else(|_| {
                    panic!("harness defect: oracle float span `{raw}` does not parse")
                });
                assert_eq!(
                    derived, *v,
                    "harness defect: oracle float {v:?} != derived {derived:?} for `{raw}`"
                );
                format!("(float {s} {e} {derived:?})\n")
            }
            TgtKind::Str(value) => {
                let raw = &source[s as usize + 1..e as usize - 1];
                let decoded = decode_target_string(raw);
                assert_eq!(
                    decoded, &**value,
                    "harness defect: oracle string {value:?} != derived {decoded:?} for `{raw}`"
                );
                format!("(str {s} {e} {decoded:?})\n")
            }
            TgtKind::Bool(b) => format!("(bool {s} {e} {b})\n"),
            TgtKind::Eof => format!("(eof {e})\n"),
            other => format!("({} {s} {e})\n", kind_tag(other)),
        };
        out.push_str(&line);
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// The .ktf side — decoding the twin's verdict
// ---------------------------------------------------------------------------

/// Rebuild the oracle `ReadError` from a twin error record's payload
/// fields (kind first, then the variant's payloads — the shapes in
/// the `target-lexer.ktf` header; the mirror of lexer_parity's
/// `rebuild_error`). `pub(crate)` since blade 3 (the steady
/// chain's lexer-err decode rides the same single source).
pub(crate) fn rebuild_target_error(
    kind: &str,
    payload: &[&Value],
    source: &str,
) -> Result<ReadError, String> {
    let at =
        |i: usize| -> Result<ByteOffset, String> { Ok(ByteOffset(as_i64(payload[i])? as u32)) };
    let text_span_at = |i: usize, j: usize| -> Result<(String, Span), String> {
        let s = as_i64(payload[i])?;
        let e = as_i64(payload[j])?;
        text_span(source, s, e)
    };
    match kind {
        "unexpected-char" => {
            need_fields(payload, 2, "unexpected-char")?;
            let cp = as_i64(payload[0])? as u32;
            let character = char::from_u32(cp)
                .ok_or_else(|| format!("harness defect: codepoint {cp} is not a char"))?;
            Ok(ReadError::UnexpectedCharacter {
                character,
                at: at(1)?,
            })
        }
        "unterminated-string" => {
            need_fields(payload, 1, "unterminated-string")?;
            Ok(ReadError::UnterminatedString { started_at: at(0)? })
        }
        "invalid-escape" => {
            need_fields(payload, 2, "invalid-escape")?;
            let cp = as_i64(payload[0])? as u32;
            let escape = char::from_u32(cp)
                .ok_or_else(|| format!("harness defect: codepoint {cp} is not a char"))?;
            Ok(ReadError::InvalidEscape { escape, at: at(1)? })
        }
        "malformed-number" => {
            need_fields(payload, 2, "malformed-number")?;
            let (text, span) = text_span_at(0, 1)?;
            Ok(ReadError::MalformedNumber { text, span })
        }
        "int-out-of-range" => {
            need_fields(payload, 2, "int-out-of-range")?;
            let (text, span) = text_span_at(0, 1)?;
            Ok(ReadError::IntOutOfRange { text, span })
        }
        "unclosed-delim" => {
            need_fields(payload, 1, "unclosed-delim")?;
            Ok(ReadError::UnclosedTargetDelim {
                opened_at: at(0)?,
                opening: "/*",
            })
        }
        other => Err(format!("harness defect: unknown error kind `{other}`")),
    }
}

/// Decode one twin token record into its dump line — `Ok(Ok(line))`
/// on a record, `Ok(Err(key))` when the record's K20 value face
/// rejects the case (the float-out-of-range key), `Err` on a harness
/// defect (a malformed record).
fn decode_twin_token(
    rec: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Result<String, String>, String> {
    let elems = value_elems(rec, heap).map_err(|e| format!("harness defect: token record: {e}"))?;
    need_fields(&elems, 2, "token record")?;
    let kind = as_str(elems[0]).map_err(|e| format!("harness defect: token kind: {e}"))?;
    if kind == "eof" {
        let len = match as_i64(elems[1]) {
            Ok(v) => v,
            Err(e) => return Err(format!("harness defect: eof payload: {e}")),
        };
        return Ok(Ok(format!("(eof {len})\n")));
    }
    need_fields(&elems, 3, "token record")?;
    let (s, e) = match (as_i64(elems[1]), as_i64(elems[2])) {
        (Ok(s), Ok(e)) => (s, e),
        (Err(e), _) | (_, Err(e)) => return Err(format!("harness defect: token span: {e}")),
    };
    match kind {
        "bool" => match elems.get(3) {
            Some(Value::Bool(true)) => Ok(Ok(format!("(bool {s} {e} true)\n"))),
            Some(Value::Bool(false)) => Ok(Ok(format!("(bool {s} {e} false)\n"))),
            Some(other) => Err(format!("harness defect: bool payload is {other:?}")),
            None => Err("harness defect: bool record lacks its payload".to_string()),
        },
        "ident" => {
            // The skin mapping is the oracle's own single source:
            // the twin carries no payload, the harness maps the span
            // text through skin_symbol (K20).
            let text = slice_src(source, s, e, "ident")?;
            let sym = skin_symbol(text).map_err(|err| {
                format!("harness defect: the twin emitted an unmappable ident ({err:?})")
            })?;
            Ok(Ok(format!("(ident {s} {e} {})\n", sym.as_str())))
        }
        "int" => match elems.get(3) {
            Some(v) => match as_i64(v) {
                Ok(v) => Ok(Ok(format!("(int {s} {e} {v})\n"))),
                Err(e) => Err(format!("harness defect: int payload: {e}")),
            },
            None => Err("harness defect: int record lacks its value payload".to_string()),
        },
        "float" => {
            // The K20 value face: the twin decided the grammar and
            // carries the span; the host derives the f64 from the
            // `_`-stripped text and maps non-finite to the same
            // FloatOutOfRange rejection the oracle made.
            let raw = slice_src(source, s, e, "float")?;
            match strip_us(raw).parse::<f64>() {
                Ok(v) if v.is_infinite() => {
                    let (text, span) = text_span(source, s, e)?;
                    let err = ReadError::FloatOutOfRange { text, span };
                    Ok(Err(error_parity_key(&err)))
                }
                Ok(v) => Ok(Ok(format!("(float {s} {e} {v:?})\n"))),
                Err(_) => Err(format!(
                    "harness defect: the twin float grammar accepted an unparseable lexeme `{raw}`"
                )),
            }
        }
        "str" => {
            let raw = slice_src(source, s + 1, e - 1, "str")?;
            let decoded = decode_target_string(raw);
            Ok(Ok(format!("(str {s} {e} {decoded:?})\n")))
        }
        // The 24 word faces and every operator tag: span-only.
        "kw-fn" | "kw-let" | "kw-mut" | "kw-if" | "kw-else" | "kw-match" | "kw-perform"
        | "kw-handle" | "kw-module" | "kw-use" | "kw-extern" | "kw-macro" | "kw-pub"
        | "kw-struct" | "kw-enum" | "kw-type" | "kw-effect" | "kw-capability" | "kw-move"
        | "kw-as" | "kw-impl" | "kw-resume" | "kw-halt" | "kw-pass" | "ellipsis" | "arrow"
        | "fat-arrow" | "colon-colon" | "dot-dot" | "eq-eq" | "not-eq" | "and-and" | "or-or"
        | "le" | "ge" | "shl" | "shr" | "open-brace" | "close-brace" | "open-paren"
        | "close-paren" | "open-bracket" | "close-bracket" | "semi" | "comma" | "colon" | "dot"
        | "bang" | "assign" | "plus" | "minus" | "star" | "slash" | "percent" | "lt" | "gt"
        | "amp" | "pipe" | "caret" => Ok(Ok(format!("({kind} {s} {e})\n"))),
        other => Err(format!("harness defect: unknown token kind `{other}`")),
    }
}

/// Decode the twin's `tl_verdict` (the `result` alias) into the
/// token-axis outcome: `Ok(Ok(dump))` on a successful lex, `Ok(Err(key))`
/// on the twin's own rejection (the rebuilt ReadError's parity key),
/// `Err` on a harness defect. `pub(crate)` since blade 3 (the steady
/// chain decodes through the same single source).
pub(crate) fn decode_twin_verdict(
    value: &Value,
    heap: &Heap,
    source: &str,
) -> Result<Result<String, String>, String> {
    let elems = value_elems(value, heap).map_err(|e| format!("verdict chain: {e}"))?;
    need_fields(&elems, 2, "verdict")?;
    let tag = as_str(elems[0]).map_err(|e| format!("verdict tag: {e}"))?;
    if tag == "ok" {
        let mut out = String::new();
        for rec in &elems[1..] {
            match decode_twin_token(rec, heap, source)? {
                Ok(line) => out.push_str(&line),
                Err(key) => return Ok(Err(key)),
            }
        }
        Ok(Ok(out))
    } else if tag == "err" {
        let kind = as_str(elems[1]).map_err(|e| format!("error kind: {e}"))?;
        let err = rebuild_target_error(kind, &elems[2..], source)?;
        Ok(Err(error_parity_key(&err)))
    } else {
        Err(format!("harness defect: unknown verdict tag `{tag}`"))
    }
}

/// The twin drive: assemble the byte-table prefix and the twin
/// source, parse through the production bridge (`ReaderFace::Target`),
/// run BOTH engines, and decode each engine's verdict into the dump
/// grammar (the error face rendered as `ERR {key}` — the
/// lexer_parity `axis_form` lineage). `Err` carries the classified
/// harness defect/limit (the `drive_dual_engines` contract).
pub fn target_lexer_twin_dump(source: &str) -> Result<(String, String), String> {
    let assembled = format!(
        "{}\n{}",
        target_byte_table_prefix(source),
        TARGET_LEXER_TARGET_SOURCE
    );
    let decode = |value: &Value, heap: &Heap| decode_twin_verdict(value, heap, source);
    let (vm_axis, eval_axis) = drive_dual_engines(
        "target-lexer-parity-host",
        "target lexer twin",
        &assembled,
        ReaderFace::Target,
        decode,
        decode,
    )?;
    let axis_form = |axis: Result<String, String>| match axis {
        Ok(dump) => dump,
        Err(key) => format!("ERR {key}"),
    };
    Ok((axis_form(vm_axis), axis_form(eval_axis)))
}

// ---------------------------------------------------------------------------
// The comparison entry
// ---------------------------------------------------------------------------

/// The first differing line pair of two dumps (the failure-line
/// precedent: name the case and the exact record that drifted).
fn first_diff(a: &str, b: &str) -> Option<(String, String)> {
    for (la, lb) in a.lines().zip(b.lines()) {
        if la != lb {
            return Some((la.to_string(), lb.to_string()));
        }
    }
    let (x, y) = (a.lines().count(), b.lines().count());
    if x != y {
        Some((format!("<{x} lines>"), format!("<{y} lines>")))
    } else {
        None
    }
}

/// The three-way comparison: twin-vm == twin-eval == oracle, on the
/// dump grammar (success) or the error key (rejection). On mismatch
/// the failure line names the case and the first differing record
/// pair (the `failure_line` lineage).
pub fn target_lexer_parity(case: &str, source: &str) -> Result<(), String> {
    let oracle = match target_oracle_token_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let (vm_dump, eval_dump) = target_lexer_twin_dump(source)?;
    if let Some((vl, el)) = first_diff(&vm_dump, &eval_dump) {
        return Err(format!(
            "target-lexer parity FAIL [{case}]: engines disagree: vm `{vl}` vs eval `{el}`"
        ));
    }
    if let Some((ol, tl)) = first_diff(&oracle, &vm_dump) {
        return Err(format!(
            "target-lexer parity FAIL [{case}]: oracle `{ol}` vs twin `{tl}`"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case list (the parity sweep's synthetic face — the
// selfhost sources ride separately through their own embeddings)
// ---------------------------------------------------------------------------

/// The curated twin cases: every word face, every operator with its
/// maximal-munch boundaries, the literal families with their
/// grammar boundaries, the comment families, and the rejection
/// family (each negative case's three-way agreement is on the SAME
/// error key — kind and payload).
pub const TARGET_LEXER_TWIN_CASES: &[(&str, &str)] = &[
    // The 24 word faces plus the two boolean spellings.
    (
        "all-keywords",
        "fn let mut if else match perform handle module use extern macro pub struct enum \
         type effect capability move as impl resume halt pass true false",
    ),
    // Every operator, spaced (the single-char face).
    (
        "all-operators",
        "{ } ( ) [ ] ; , : . ! = + - * / % < > & | ^ -> => :: .. == != && || <= >= << >> ...",
    ),
    // Maximal-munch boundaries: `.....` is ellipsis + dot-dot, the
    // pairs against their prefixes.
    (
        "maximal-munch",
        "a...b a..b a.b a->b a-b a<<b a<b a>>b a>b x.....y",
    ),
    // Identifier shapes (the ASCII domain, underscores everywhere).
    (
        "ident-shapes",
        "_x x_ _ __ lx_is_digit a1 _5 x_5 first rest pair eq set read_line write_line",
    ),
    // Decimal ints with `_` separators and the i64 boundary.
    (
        "decimal-ints",
        "0 007 42 1_000 0_ 9223372036854775807 1_000_000_000_000_000_000",
    ),
    // Radix ints (both letter cases, `_` separators, hex letters).
    (
        "radix-ints",
        "0x1F 0X1f 0o17 0O17 0b101 0B101 0x_1 0xff_ff 0x1e 0x0",
    ),
    // Floats: the dot-mandatory grammar, exponents in all three
    // sign shapes, `_` separators on both sides of the dot.
    (
        "floats",
        "1.5 1.0 0.5 1_0.5_0 1.5e10 1.5E-3 1.5e+2 1.0e0 2.5e1_0",
    ),
    // The grammar boundaries: `1.5e` (float then ident), `1.5e+`
    // (float, ident, plus), `1._5` (int, dot, ident), `1.` (int,
    // dot), `0x1.5` (hex int, dot, int), `1.2_3.4` (float, dot,
    // int), `1e2` (int, ident — the dot is mandatory).
    ("float-boundaries", "1.5e 1.5e+ 1._5 1. 0x1.5 1.2_3.4 1e2"),
    // Strings: the seven escapes, `\u{...}` (upper and lower hex,
    // `_` separators, the astral plane), raw newlines, non-ASCII
    // payloads.
    (
        "strings",
        "\"a\\nb\" \"c\\td\" \"e\\rf\" \"g\\0h\" \"i\\\\j\" \"k\\\"l\" \"m\\'n\" \"\\u{41}\" \
         \"\\u{00e9}\" \"\\u{1_1}\" \"\\u{10FFFF}\" \"h\u{e9}llo \u{1f389}\"",
    ),
    ("raw-newline-string", "\"line one\nline two\""),
    // Comments: line comments (lf, cr, end-of-input), nested block
    // comments, comments with code-shaped bodies, `**` and `//`
    // inside block comments.
    (
        "comments",
        "// line comment\n/* block */ /* /* nested */ still */ let /* mid */ x = 1; // tail",
    ),
    ("comment-to-eof", "let x = 1; // no newline at end"),
    ("comment-cr", "// cr ended\rlet y = 2;"),
    ("block-comment-stars", "/* ** // /* */ let z = 3;"),
    // Trivia-only sources.
    ("empty-source", ""),
    ("whitespace-only", " \t\n\r "),
    // A realistic program face (the production bridge's own skin).
    (
        "program-face",
        "fn add(a, b) { let s = a + b; s }\ndefine(result, add(1, 2));\nlet f = 1.5e3;\n",
    ),
    // ---- the rejection family (same error key on all three ways) ----
    ("neg-unterminated-string", "\"abc"),
    ("neg-unterminated-string-bs", "\"a\\"),
    ("neg-bad-escape", "\"a\\q\""),
    ("neg-bad-escape-nonascii", "\"a\\\u{e9}\""),
    ("neg-u-empty", "\"\\u{}\""),
    ("neg-u-seven-digits", "\"\\u{1234567}\""),
    ("neg-u-surrogate", "\"\\u{d800}\""),
    ("neg-u-above-plane", "\"\\u{110000}\""),
    ("neg-u-no-brace", "\"\\u41\""),
    ("neg-u-nonhex", "\"\\uZZ\""),
    ("neg-u-eof", "\"\\u{"),
    ("neg-unclosed-block", "/* x"),
    ("neg-unclosed-block-nested", "/* /* x"),
    ("neg-unclosed-block-code", "fn f() { /* oops\n}"),
    ("neg-unexpected-dollar", "let x = $;"),
    ("neg-unexpected-punct", "@ # ? ~"),
    ("neg-unexpected-nonascii", "let \u{e9} = 1;"),
    ("neg-unexpected-emoji", "let x = \u{1f389};"),
    ("neg-unexpected-bom", "\u{feff}fn f() {}"),
    ("neg-malformed-0x", "0x"),
    ("neg-malformed-0b2", "0b2"),
    ("neg-malformed-0xZZ", "0xZZ"),
    ("neg-malformed-0o8", "0o8"),
    ("neg-malformed-0x-underscore-only", "0x_"),
    ("neg-int-out-of-range-decimal", "99999999999999999999"),
    ("neg-int-out-of-range-hex", "0xFFFFFFFFFFFFFFFF"),
    ("neg-int-out-of-range-octal", "0o1777777777777777777777"),
    (
        "neg-int-out-of-range-binary",
        "0b1111111111111111111111111111111111111111111111111111111111111111",
    ),
    ("neg-malformed-hex-17", "0x10000000000000000"),
    ("neg-malformed-octal-23", "0o2777777777777777777777"),
    ("neg-float-out-of-range", "1.0e999"),
];

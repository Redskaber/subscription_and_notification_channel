//! The interpreter (docs/stage0.md §19.5): one switch-dispatch loop,
//! heap frames, span-resolved errors.
//!
//! Core invariants mirrored from §19.5:
//! 1. frames carry the frozen three-slot extension block (§8.12);
//! 2. `pc` only moves against the +1 rule on jump / jump-if-false /
//!    call / ret / error paths;
//! 3. the evaluation-order contract — arguments sit left-to-right
//!    under the callee at `peek(n)` (§19.3 compiler side) — the VM
//!    only consumes per that contract and neither side changes alone.
//!
//! Effects at 0.6 (`perform` / `push-handler` / `pop-handler`): a
//! perform looks up the nearest installed handler for the effect and
//! invokes it as a function; the handler's return value IS the
//! perform's value and the body continues (the §9.1.1 EffectSystem is
//! an interface-reserved capability — real continuations/unwinding
//! are what the frozen ext1 slot reserves for Stage 1+; the
//! callability check itself is the 0.6 duty per plan-0.5 decision 8).

use std::rc::Rc;

use kerf_compiler::{Bytecode, CaptureSource, CompileError, Instr, Opcode};
use kerf_span::{Span, Symbol};

use crate::builtin::{self, Builtin, BuiltinHost};
use crate::error::{RuntimeError, demanded, type_mismatch};
use crate::frame::Frame;
use crate::io::VmIo;
use crate::methodjit::{Control, METHOD_HOT_THRESHOLD, MethodChain, MethodJit};
use crate::observer::VmObserver;
use crate::roots::{Collector, Roots};
use crate::value::{ClosureData, Heap, HeapObj, Value};

/// Default allocation budget: frames + heap cells. Generous for the
/// §20.1 Week-3 criterion (fib(25) ≈ 243k frames) while bounding
/// every non-terminating program — kerf has no loop primitive, so
/// all unbounded growth routes through calls and allocations.
pub const DEFAULT_BUDGET: u32 = 8 * 1024 * 1024;

/// One installed handler (`push-handler` entry).
struct HandlerEntry {
    /// The effect's global-table index.
    effect: u32,
    /// The handler value evaluated at installation.
    value: Value,
}

/// One compiled-frame run's terminal flow (the tier-1 driver, MJ-3 —
/// w-jit-method-t1-window.md §7): a callee frame was pushed (the
/// main loop re-selects the engine for it), this frame returned
/// (the value is already on the caller's stack), or the machine
/// halted.
#[derive(Debug)]
enum CompFlow {
    CalleePushed,
    FrameReturned,
    Halted(Value),
}

/// The virtual machine.
pub struct Vm {
    bc: Bytecode,
    heap: Heap,
    /// Per-global slots: builtins seeded, program defines stored at
    /// run time, never-stored slots read as UnboundGlobal.
    globals: Vec<Option<Value>>,
    handlers: Vec<HandlerEntry>,
    frames: Vec<Frame>,
    budget: u32,
    allocs: u32,
    io: Box<dyn VmIo>,
    /// The 0.7 injection face: None keeps the 0.6 fail-closed budget
    /// behavior; Some turns the §19.4 safety point into
    /// collect-then-retry (plan-0.7 ruling D2).
    collector: Option<Box<dyn Collector>>,
    /// Host-held values the collector must treat as roots (§19.4
    /// root class four — the "C stack explicit roots" Rust spelling).
    foreign: Vec<Value>,
    /// The tier-1 method-JIT state (W-JIT-METHOD-T1 blade 1 — the
    /// MJ-2 census counters plus per-function compile status).
    /// Unlike the r132 observation seam (a measurement face that
    /// never lives in the struct), this is MECHANISM: the tier
    /// dispatch needs its state resident. The honest cost is one
    /// u32 add per closure call and one Option probe per loop
    /// iteration (blade 2's B-axis measures both — the K129
    /// discipline, no speculative tuning here).
    method_tier: MethodJit,
}

impl Vm {
    /// Build a VM with the default budget and buffered I/O; runs the
    /// load-time verify hook (plan-0.5 ruling 4) before seeding.
    pub fn new(bc: Bytecode) -> Result<Self, CompileError> {
        Vm::build(bc, DEFAULT_BUDGET, Box::new(crate::io::BufferIo::new()))
    }

    /// Build with a custom allocation budget (tests and hosts).
    pub fn with_budget(bc: Bytecode, budget: u32) -> Result<Self, CompileError> {
        Vm::build(bc, budget, Box::new(crate::io::BufferIo::new()))
    }

    /// Build with a custom I/O face.
    pub fn with_io(bc: Bytecode, io: Box<dyn VmIo>) -> Result<Self, CompileError> {
        Vm::build(bc, DEFAULT_BUDGET, io)
    }

    /// Build with a collector injected (default budget, buffered
    /// I/O): the budget safety point becomes collect-then-retry.
    pub fn with_collector(
        bc: Bytecode,
        collector: Box<dyn Collector>,
    ) -> Result<Self, CompileError> {
        let mut vm = Vm::build(bc, DEFAULT_BUDGET, Box::new(crate::io::BufferIo::new()))?;
        vm.collector = Some(collector);
        Ok(vm)
    }

    /// Build with a custom budget AND a collector (the GC-behavior
    /// test face: tight budgets prove the collect-then-retry path).
    pub fn with_budget_and_collector(
        bc: Bytecode,
        budget: u32,
        collector: Box<dyn Collector>,
    ) -> Result<Self, CompileError> {
        let mut vm = Vm::build(bc, budget, Box::new(crate::io::BufferIo::new()))?;
        vm.collector = Some(collector);
        Ok(vm)
    }

    /// Build with a custom tier-1 census threshold (MJ-2 — the tier
    /// policy face, `with_budget`'s form; the production default is
    /// [`METHOD_HOT_THRESHOLD`]). 1 = compile at the first invocation
    /// (the all-compiled guard shape); `u32::MAX` = never compile
    /// (the pure-interpreter guard shape — the dual-path
    /// verification face of MJ-4).
    pub fn with_method_tier_threshold(bc: Bytecode, threshold: u32) -> Result<Self, CompileError> {
        assert!(
            threshold >= 1,
            "the tier census threshold must be at least 1 (0 has no meaning — the count never equals it)"
        );
        let mut vm = Vm::build(bc, DEFAULT_BUDGET, Box::new(crate::io::BufferIo::new()))?;
        vm.method_tier = MethodJit::new(vm.bc.funcs.len(), threshold);
        Ok(vm)
    }

    fn build(bc: Bytecode, budget: u32, io: Box<dyn VmIo>) -> Result<Self, CompileError> {
        bc.verify()?;
        // Seed: every global whose name is a STAGE0_GLOBALS builtin
        // starts bound; everything else starts unbound (UnboundGlobal
        // on load until its store-global executes).
        let globals = bc
            .globals
            .iter()
            .map(|g| Builtin::from_name(g.as_str()).map(Value::Builtin))
            .collect();
        // Bound before the struct literal moves `bc` (the literal's
        // field order would otherwise borrow a moved value).
        let method_tier = MethodJit::new(bc.funcs.len(), METHOD_HOT_THRESHOLD);
        Ok(Vm {
            bc,
            heap: Heap::default(),
            globals,
            handlers: Vec::new(),
            frames: Vec::new(),
            budget,
            allocs: 0,
            io,
            collector: None,
            foreign: Vec::new(),
            method_tier,
        })
    }

    /// Look a global up by name (the test/driver observation face;
    /// unbound slots and unknown names are both None).
    pub fn global(&self, name: &str) -> Option<&Value> {
        let idx = self.bc.globals.iter().position(|g| g.as_str() == name)?;
        self.globals[idx].as_ref()
    }

    /// Bind one global slot to a literal value materialized on this
    /// VM's heap — the W-3.12 injection channel's VM arm (the
    /// steady-state bootstrap chain's runtime data face).
    ///
    /// Channel contract:
    /// * the name must already sit in the bytecode's global table
    ///   (the compiler's collected reference set) — the channel
    ///   rides an existing slot and never mints one, so an
    ///   unreferenced name fails closed as
    ///   [`RuntimeError::InjectGlobalUnknown`];
    /// * the pair cells charge the allocation budget through the
    ///   same `reserve_exact` path const materialization uses (the
    ///   §19.4 discipline — injected data is live heap, never free);
    /// * the bound slot is a collector root like any global (the
    ///   §19.4 root class three), and a program-side `define` of the
    ///   same name still overwrites the slot at run time — the
    ///   steady-state program's no-define discipline is owned by the
    ///   driver face that assembles it (documented there, asserted
    ///   by the chain's equivalence tests).
    pub fn inject_global(
        &mut self,
        name: &str,
        lit: &kerf_core::LiteralValue,
    ) -> Result<(), RuntimeError> {
        let idx = self
            .bc
            .globals
            .iter()
            .position(|g| g.as_str() == name)
            .ok_or_else(|| RuntimeError::InjectGlobalUnknown {
                name: name.to_string(),
                span: Span::host(),
            })?;
        let cells = lit.pair_cells() as u32;
        self.reserve_exact(cells, Span::host())?;
        let value = Value::from_literal(lit, &mut self.heap);
        self.globals[idx] = Some(value);
        Ok(())
    }

    /// The bytecode's global name table (the §9.67 NB-7 identity
    /// observation face — callers that already hold `Symbol`s read
    /// the pool entries directly, no de-intern copy).
    pub fn global_names(&self) -> &[Symbol] {
        &self.bc.globals
    }

    /// Look a global up by its interned identity (§9.67 NB-7 — the
    /// driver's parity/snapshot faces; a pool-index comparison per
    /// step instead of a text comparison).
    pub fn global_sym(&self, name: &Symbol) -> Option<&Value> {
        let idx = self.bc.globals.iter().position(|g| g == name)?;
        self.globals[idx].as_ref()
    }

    /// The configured budget.
    pub fn budget(&self) -> u32 {
        self.budget
    }

    /// Allocations consumed so far (frames + heap cells; the 0.6
    /// cumulative public face — the 0.7 live-usage reserve check is
    /// internal, see `live_usage`).
    pub fn allocations(&self) -> u32 {
        self.allocs
    }

    /// The object heap (the 0.7 collector's walking surface).
    pub fn heap(&self) -> &Heap {
        &self.heap
    }

    /// Mutable heap access (the explicit-collection face for hosts
    /// and tests running a cycle between programs).
    pub fn heap_mut(&mut self) -> &mut Heap {
        &mut self.heap
    }

    /// Register a host-held value as a collection root (§19.4 root
    /// class four). The value survives every injected cycle until
    /// the VM is dropped.
    pub fn register_foreign_ref(&mut self, value: Value) {
        self.foreign.push(value);
    }

    /// Snapshot the §19.4 root classes (the collector input face;
    /// values are cloned — a cycle runs between allocations, never
    /// mid-instruction). Handler values ride as the class-2
    /// extension: installed handlers are frame-adjacent state. The
    /// frames' capture areas join the local-slot class for the same
    /// reason (Stage 2.1 LA-3): a frame's captured values are live
    /// frame state a cycle must not reclaim.
    pub fn snapshot_roots(&self) -> Roots {
        let mut stack = Vec::new();
        let mut locals = Vec::new();
        for frame in &self.frames {
            stack.extend(frame.stack.iter().cloned());
            locals.extend(frame.locals.iter().cloned());
            locals.extend(frame.captured.iter().cloned());
        }
        let globals = self.globals.iter().flatten().cloned().collect();
        let handlers = self.handlers.iter().map(|h| h.value.clone()).collect();
        Roots {
            stack,
            locals,
            globals,
            foreign: self.foreign.clone(),
            handlers,
        }
    }

    /// Override the tier census threshold (the policy face, MJ-2 —
    /// settable before the run; the budget-parity guard combines it
    /// with `with_budget`). The production default is
    /// [`METHOD_HOT_THRESHOLD`].
    pub fn set_method_tier_threshold(&mut self, threshold: u32) {
        assert!(
            threshold >= 1,
            "the tier census threshold must be at least 1 (0 has no meaning — the count never equals it)"
        );
        self.method_tier.set_threshold(threshold);
    }

    /// The tier-1 state (the guard observation face — census counts,
    /// compile status, and the canonical chain listings; MJ-4).
    pub fn method_tier(&self) -> &MethodJit {
        &self.method_tier
    }

    /// Drain recorded output lines.
    pub fn take_output(&mut self) -> Vec<String> {
        self.io.take_output()
    }

    /// Run the entry proto to its `halt` (a halt anywhere stops the
    /// machine — verify confines the opcode to the entry proto).
    /// Returns the popped value, or `nil` when the program form
    /// halted at depth 0 (declaration-only products).
    pub fn run(&mut self) -> Result<Value, RuntimeError> {
        // The W-3.7 seam dispatches on observation at run entry,
        // NOT per instruction: `run_dispatch::<false>` monomorphizes
        // the observer arm away entirely (the production path keeps
        // its pre-seam shape — the A/B control measurements in
        // w3.7-jit-window.md §2a pin this), only the census face
        // pays the observe call. The VM never stores the observer:
        // the struct layout is byte-identical with and without the
        // seam.
        self.run_dispatch::<false>(None)
    }

    /// Run with a dispatch observer (the W-3.7 census face): every
    /// executed instruction reports to `observer` at the fetch site,
    /// before its match arm runs. Measurement only — zero semantic
    /// effect (the parity guards pin this); never a timing face.
    pub fn run_observed(&mut self, observer: &mut dyn VmObserver) -> Result<Value, RuntimeError> {
        self.run_dispatch::<true>(Some(observer))
    }

    /// The dispatch loop proper (the `run` doc applies). One source,
    /// two instantiations: `OBSERVE = false` compiles the observer
    /// arm out (zero-cost seam); `OBSERVE = true` reports every
    /// executed instruction to the passed observer.
    fn run_dispatch<const OBSERVE: bool>(
        &mut self,
        mut observer: Option<&mut dyn VmObserver>,
    ) -> Result<Value, RuntimeError> {
        let entry_span = self
            .bc
            .entry()
            .expect("verify rejects an empty func table")
            .debug_info
            .first()
            .copied()
            .expect("verify guarantees debug-info parallelism");
        let entry_name = self.bc.entry().and_then(|p| p.name.clone());
        self.push_frame(0, entry_name, Vec::new(), Rc::new(Vec::new()), entry_span)?;
        loop {
            // MJ-3 (w-jit-method-t1-window.md §7): the engine selection
            // sits at the frame top — every frame-changing arm (a call
            // pushing a frame, a ret popping one) lands here and the
            // loop re-selects for the new top frame. One Option probe
            // per iteration on the interpreted path; blade 2's B-axis
            // measures it (the K129 discipline — no speculative
            // tuning here).
            if let Some(chain) = self
                .method_tier
                .chain_for(self.frames.last().expect("entry frame").func)
            {
                match self.run_compiled_frame::<OBSERVE>(&chain, &mut observer)? {
                    CompFlow::Halted(value) => return Ok(value),
                    CompFlow::CalleePushed | CompFlow::FrameReturned => continue,
                }
            }
            let (func, pc, instr) = self.fetch();
            if OBSERVE {
                if let Some(observer) = observer.as_mut() {
                    observer.observe(instr.op, func, pc);
                }
            }
            // The arm bodies below are the single source both engines
            // share (MJ-1): the tier-1 chain nodes in methodjit.rs call
            // these same `arm_*` helpers and shims, so engine equivalence
            // is a construction, not an argument (the r134 F1 form).
            match instr.op {
                Opcode::PushConst => self.arm_push_const(instr, func, pc)?,
                Opcode::Pop => {
                    self.pop(instr.op, func, pc)?;
                }
                Opcode::Dup => {
                    let top = self.peek(0, instr.op, func, pc)?.clone();
                    self.push(top)?;
                }
                Opcode::Swap => {
                    let x = self.pop(instr.op, func, pc)?;
                    let y = self.pop(instr.op, func, pc)?;
                    self.push(x)?;
                    self.push(y)?;
                }
                Opcode::Call => self.exec_call(instr.a, func, pc)?,
                Opcode::CallGlobal => self.arm_call_global(instr, func, pc)?,
                Opcode::LoadLocalConst => self.arm_load_local_const(instr, func, pc)?,
                Opcode::Ret => self.arm_ret(func, pc)?,
                Opcode::Closure => self.arm_closure(instr, func, pc)?,
                Opcode::Jump => {
                    self.top_frame_mut().pc = instr.a as usize;
                }
                Opcode::JumpIfFalse => self.arm_jump_if_false(instr, func, pc)?,
                Opcode::MakePair => self.arm_make_pair(instr, func, pc)?,
                Opcode::Car => self.arm_car(func, pc)?,
                Opcode::Cdr => self.arm_cdr(func, pc)?,
                Opcode::LoadLocal => {
                    let slot = instr.a as usize;
                    let v = self.top_frame().locals[slot].clone();
                    self.push(v)?;
                }
                Opcode::LoadCaptured => {
                    // Stage 2.1 LA-3: the capture-area read — verify
                    // bounds the operand against the proto's own
                    // descriptor table (the LoadLocal discipline).
                    let idx = instr.a as usize;
                    let v = self.top_frame().captured[idx].clone();
                    self.push(v)?;
                }
                Opcode::StoreLocal => {
                    let value = self.pop(instr.op, func, pc)?;
                    let slot = instr.a as usize;
                    self.top_frame_mut().locals[slot] = value;
                }
                Opcode::LoadGlobal => self.arm_load_global(instr, func, pc)?,
                Opcode::StoreGlobal => {
                    let value = self.pop(instr.op, func, pc)?;
                    self.store_global_slot(instr.a as usize, value);
                }
                Opcode::Add | Opcode::Sub | Opcode::Mul | Opcode::Div => {
                    self.arm_arith(instr, func, pc)?;
                }
                Opcode::PushHandler => self.arm_push_handler(instr, func, pc)?,
                Opcode::PopHandler => self.arm_pop_handler(instr, func, pc)?,
                Opcode::Perform => self.exec_perform(instr, func, pc)?,
                Opcode::Halt => {
                    return self.arm_halt(func, pc);
                }
            }
        }
    }

    /// Run the current top frame's activation through its compiled
    /// chain (the tier-1 driver, MJ-1/MJ-3 — the single source of the
    /// fetch-equivalent +1 advance: `frame.pc = node.pc + 1` happens
    /// here BEFORE the arm runs, and jump arms overwrite it after, so
    /// `frame.pc` is bitwise identical to the interpreter's at every
    /// point control can leave the chain — a call's pushed frame, an
    /// error return, a popped frame). One `dyn Fn` call per step; the
    /// entry map is the interpreter's own addressing minus the double
    /// bounds check and the opcode match (the honest form note,
    /// MJ-1 — blade 2's B-axis measures the composite).
    fn run_compiled_frame<const OBSERVE: bool>(
        &mut self,
        chain: &MethodChain,
        observer: &mut Option<&mut dyn VmObserver>,
    ) -> Result<CompFlow, RuntimeError> {
        let entry_pc = self.frames.last().expect("entry frame").pc;
        let mut node = chain.entry(entry_pc);
        loop {
            if OBSERVE {
                if let Some(obs) = observer.as_deref_mut() {
                    obs.observe(node.op, node.func as usize, node.pc as usize);
                }
            }
            self.frames.last_mut().expect("entry frame").pc = node.pc as usize + 1;
            match (node.step)(self)? {
                Control::Next(pc) => node = chain.entry(pc as usize),
                Control::CalleePushed => return Ok(CompFlow::CalleePushed),
                Control::FrameReturned => return Ok(CompFlow::FrameReturned),
                Control::Halted(value) => return Ok(CompFlow::Halted(value)),
            }
        }
    }

    // ---------- helpers ----------

    /// Fetch the next instruction of the current frame (the +1 rule;
    /// jump/call/ret paths overwrite the pc afterwards).
    #[inline]
    fn fetch(&mut self) -> (usize, usize, Instr) {
        let frame = self.frames.last_mut().expect("entry frame");
        let instr = self.bc.funcs[frame.func].code[frame.pc];
        let at = (frame.func, frame.pc);
        frame.pc += 1;
        (at.0, at.1, instr)
    }

    /// Resolve the source span of `(func, pc)` (§12.1 face). Verify
    /// guarantees debug-info parallelism, so the lookup cannot miss.
    #[inline]
    fn span_at(&self, func: usize, pc: usize) -> Span {
        self.bc
            .span_of(func, pc)
            .expect("verified bytecode maps every pc to a span")
    }

    /// Count one allocation against the budget — the §19.4 safety
    /// point. 0.7 semantics: the LIVE footprint (frames + live heap
    /// cells) is the check; on exhaustion an injected collector runs
    /// one cycle and the charge retries (collect-then-retry, the
    /// 0.6→0.7 evolution written at this point in error.rs); with no
    /// collector the 0.6 fail-closed behavior stands. The public
    /// `allocations` counter stays cumulative (0.6 face).
    fn reserve(&mut self, span: Span) -> Result<(), RuntimeError> {
        if self.live_usage() < self.budget {
            self.allocs += 1;
            return Ok(());
        }
        if self.collector.is_some() {
            let roots = self.snapshot_roots();
            if let Some(collector) = self.collector.as_mut() {
                collector.collect(&mut self.heap, &roots);
            }
            if self.live_usage() < self.budget {
                self.allocs += 1;
                return Ok(());
            }
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    /// Count `n` allocations in one budget check (§9.69.3 EXC-2).
    /// The per-cell loop this replaces performed `n` identical
    /// checks — live usage only moves when `heap.alloc` runs in the
    /// materialization walk that follows, so every iteration saw the
    /// same `live < budget` state. One check under the same
    /// condition is behavior-identical: the accept/reject boundary,
    /// the collect-then-retry retry point, and the success-path
    /// `allocs` total (+= n) all match the loop; only the failure
    /// path stops charging partial cells (the run aborts on the
    /// error either way).
    fn reserve_exact(&mut self, n: u32, span: Span) -> Result<(), RuntimeError> {
        if n == 0 {
            return Ok(());
        }
        if self.live_usage() < self.budget {
            self.allocs += n;
            return Ok(());
        }
        if self.collector.is_some() {
            let roots = self.snapshot_roots();
            if let Some(collector) = self.collector.as_mut() {
                collector.collect(&mut self.heap, &roots);
            }
            if self.live_usage() < self.budget {
                self.allocs += n;
                return Ok(());
            }
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    /// The live resource footprint a reserve checks against: live
    /// frames plus live heap cells (heap cells never shrink without a
    /// collector, so this stays monotonic exactly when 0.6 behavior
    /// is preserved).
    fn live_usage(&self) -> u32 {
        self.frames.len() as u32 + self.heap.live_len() as u32
    }

    pub(crate) fn push(&mut self, value: Value) -> Result<(), RuntimeError> {
        self.frames
            .last_mut()
            .expect("entry frame")
            .stack
            .push(value);
        Ok(())
    }

    pub(crate) fn pop(
        &mut self,
        op: Opcode,
        func: usize,
        pc: usize,
    ) -> Result<Value, RuntimeError> {
        self.frames
            .last_mut()
            .expect("entry frame")
            .stack
            .pop()
            .ok_or(RuntimeError::StackUnderflow {
                op,
                pc,
                span: self.span_at(func, pc),
            })
    }

    pub(crate) fn peek(
        &self,
        n: usize,
        op: Opcode,
        func: usize,
        pc: usize,
    ) -> Result<&Value, RuntimeError> {
        let stack = &self.frames.last().expect("entry frame").stack;
        let len = stack.len();
        if len <= n {
            return Err(RuntimeError::StackUnderflow {
                op,
                pc,
                span: self.span_at(func, pc),
            });
        }
        Ok(&stack[len - 1 - n])
    }

    /// Enter a frame (an allocation: recursion shares the budget
    /// with heap cells, bounding every loop-shaped program). The
    /// callee's captured values install from its closure cell by a
    /// refcount bump (the LA-3 capture area, shared immutable since
    /// the Stage 3.1 env-copy blade; the entry proto enters with
    /// none).
    fn push_frame(
        &mut self,
        func: usize,
        name: Option<Symbol>,
        args: Vec<Value>,
        captured: Rc<Vec<Value>>,
        span: Span,
    ) -> Result<(), RuntimeError> {
        self.reserve(span)?;
        let n_locals = self.bc.funcs[func].n_locals;
        self.frames
            .push(Frame::new(func, name, n_locals, args, captured));
        Ok(())
    }

    /// Materialize a constant (heap-allocating pair shapes). The
    /// cell count is read out first so the reserve borrows and the
    /// constant-pool/heap disjoint-field borrows never overlap.
    fn materialize(&mut self, idx: u32, span: Span) -> Result<Value, RuntimeError> {
        // §9.69.3 EXC-1/EXC-2: the cell count is the single-sourced
        // `LiteralValue::pair_cells` (kerf-core — the meta-circular
        // evaluator budgets against the same method), and the charge
        // is one `reserve_exact` batch instead of a per-cell loop.
        // The count is read out first so the reserve borrow and the
        // constant-pool/heap disjoint-field borrows never overlap.
        let cells = self.bc.consts[idx as usize].pair_cells() as u32;
        self.reserve_exact(cells, span)?;
        let lit = &self.bc.consts[idx as usize];
        Ok(Value::from_literal(lit, &mut self.heap))
    }

    /// Pop `argc` args off the data stack (stack order: arg0 deepest),
    /// returning them in call order.
    fn take_args(
        &mut self,
        op: Opcode,
        argc: u32,
        func: usize,
        pc: usize,
    ) -> Result<Vec<Value>, RuntimeError> {
        // §9.69.3 EXC-3: one stack-window move (`split_off`) replaces
        // the pop-loop + reverse (2×argc value moves per call). The
        // callee sits on top, args in order beneath — the window
        // [len-argc, len) is exactly the arg vector, in order. The
        // underflow arm keeps the same StackUnderflow defense (verify
        // keeps it structurally unreachable).
        let span = self.span_at(func, pc);
        let frame = self.frames.last_mut().expect("entry frame");
        let at = frame
            .stack
            .len()
            .checked_sub(argc as usize)
            .ok_or(RuntimeError::StackUnderflow { op, pc, span })?;
        Ok(frame.stack.split_off(at))
    }

    pub(crate) fn exec_call(
        &mut self,
        argc: u32,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        // §19.3 emission order (the 0.5 compiler, authoritative): args
        // left to right, then the callee — the callee sits ON TOP with
        // the args in order beneath it. (The §19.5 skeleton's `peek(n)`
        // drawing shows the upstream [callee, args] layout; plan-0.5
        // decision 3 "callee on top" is what the compiler emits and
        // what runs here — plan-0.6 §13.1 reconciliation note.)
        let callee = self.pop(Opcode::Call, func, pc)?;
        let args = self.take_args(Opcode::Call, argc, func, pc)?;
        self.invoke(callee, args, func, pc)
    }

    /// Invoke a callable value with already-evaluated args: closures
    /// enter a frame, builtins run in place. Shared by `call` and
    /// `perform`'s handler invocation.
    fn invoke(
        &mut self,
        callee: Value,
        args: Vec<Value>,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        match callee {
            Value::Closure(r) => {
                let data = match self.heap.get(r) {
                    Some(HeapObj::Closure(d)) => d,
                    _ => panic!("heap cell `{r}` must hold a closure (alloc sites type cells)"),
                };
                let proto = data.proto as usize;
                let params = self.bc.funcs[proto].params;
                if args.len() as u32 != params {
                    return Err(RuntimeError::ArityMismatch {
                        // §9.67 NB-5: the proto name is already a pool
                        // entry — the payload carries it directly (no
                        // de-intern/re-intern round trip).
                        func: self.bc.funcs[proto].name.clone(),
                        expected: params,
                        actual: args.len() as u32,
                        span: self.span_at(func, pc),
                    });
                }
                let name = self.bc.funcs[proto].name.clone();
                let span = self.span_at(func, pc);
                // MJ-2 (w-jit-method-t1-window.md §7): the tier census
                // — one u32 add per closure call (not per instruction);
                // on the threshold crossing the chain builds HERE,
                // before this frame is pushed, so the crossing
                // invocation itself runs compiled. Deterministic: the
                // same program crosses at the same invocation. A
                // refused build is permanent fallback (no retry).
                self.method_tier.note_invoke(&self.bc, proto);
                // Stage 2.1 LA-3 + Stage 3.1 W-3.1 blade: the closure
                // cell's env IS the capture area (descriptor order);
                // installing it into the new frame is one refcount
                // bump — the cell and the frame share the same
                // immutable Vec (capture areas are written once at
                // closure creation and never mutated; no
                // store-to-captured opcode exists). The pre-blade
                // O(captured) copy per invocation is retired.
                let captured = Rc::clone(&data.env);
                self.push_frame(proto, name, args, captured, span)?;
                Ok(())
            }
            Value::Builtin(b) => {
                // §9.73 EVL-1/EVL-2: the arity check and the routing
                // live in the single-source `dispatch_builtin` (the
                // evaluator enters the SAME function — a routing drift
                // between the engines is now a type error, not a
                // parity incident).
                let span = self.span_at(func, pc);
                let value = builtin::dispatch_builtin(self, b, args, span)?;
                self.push(value)
            }
            other => Err(type_mismatch(
                "call callee",
                demanded::CALLABLE,
                &other,
                self.span_at(func, pc),
            )),
        }
    }

    /// `perform(effect_idx, argc)`: find the nearest handler installed
    /// for the effect and invoke it as a function with the performed
    /// args; its return value is the perform's value (the body
    /// continues — the installed handler stays until its pop-handler).
    pub(crate) fn exec_perform(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let args = self.take_args(Opcode::Perform, instr.b, func, pc)?;
        match self.handlers.iter().rposition(|h| h.effect == instr.a) {
            Some(idx) => {
                let value = self.handlers[idx].value.clone();
                self.invoke(value, args, func, pc)
            }
            None => Err(RuntimeError::UnhandledEffect {
                effect: self.bc.globals[instr.a as usize].clone(),
                span: self.span_at(func, pc),
            }),
        }
    }

    // ---------- the tier-1 arm faces (MJ-1 — the single source both
    // engines share; the bodies moved here verbatim from the
    // interpreter arms, which now call them; the chain nodes in
    // methodjit.rs call the very same functions) ----------

    /// PushConst.
    pub(crate) fn arm_push_const(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let value = self.materialize(instr.a, span)?;
        self.push(value)
    }

    /// The fused load-global + call (W-VM-SUPERINSTR SI-2/SI-4).
    /// The callee comes straight from the global slot (the args are
    /// already on the stack — §19.3 order preserved: this reads the
    /// slot at exactly the point the unfused load-global would have),
    /// then the shared `invoke` runs the identical call semantics
    /// (frame push for closures, inline dispatch_builtin, the
    /// "call callee" type mismatch). The two error families of the
    /// load-global arm live here verbatim (extern contract + unbound),
    /// with the fused instruction's span — the Apply span, SI-1-1.
    pub(crate) fn arm_call_global(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let idx = instr.a as usize;
        let callee = match &self.globals[idx] {
            Some(v) => v.clone(),
            None => {
                // W-3.2: an extern-declared name reads as the contract
                // it is — the C backend is the one engine with a foreign
                // call face, and the bytecode's extern table names the
                // boundary instead of a generic unbound-global
                // misreport.
                let name = &self.bc.globals[idx];
                if self.bc.externs.iter().any(|e| &e.name == name) {
                    return Err(RuntimeError::ExternCallRequiresBackend {
                        name: name.clone(),
                        span: self.span_at(func, pc),
                    });
                }
                return Err(RuntimeError::UnboundGlobal {
                    name: name.clone(),
                    span: self.span_at(func, pc),
                });
            }
        };
        let args = self.take_args(Opcode::CallGlobal, instr.b, func, pc)?;
        self.invoke(callee, args, func, pc)
    }

    /// The fused copy pair (W-JIT-METHOD-T1 TJ-1 — the load-local +
    /// push-const pair, the K151 classic). Both source arms are pure
    /// data movement with no error face of their own (verify Pass 1
    /// bounds the slot and the constant index), so the fused arm
    /// simply pushes in the original pair's order: the local slot's
    /// value first, then the pooled constant — the stack image after
    /// the fused instruction is bit-identical to the pair's.
    pub(crate) fn arm_load_local_const(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let slot = instr.a as usize;
        let v = self.frames.last().expect("entry frame").locals[slot].clone();
        self.push(v)?;
        let span = self.span_at(func, pc);
        let value = self.materialize(instr.b, span)?;
        self.push(value)
    }

    /// Ret: pop the value, pop the frame; an empty frame stack is the
    /// RetFromEntry boundary (the value goes to the caller's stack).
    pub(crate) fn arm_ret(&mut self, func: usize, pc: usize) -> Result<(), RuntimeError> {
        let value = self.pop(Opcode::Ret, func, pc)?;
        self.frames.pop();
        if self.frames.is_empty() {
            return Err(RuntimeError::RetFromEntry {
                pc,
                span: self.span_at(func, pc),
            });
        }
        self.push(value)
    }

    /// Closure creation (Stage 2.1 LA-3: the closure cell carries
    /// exactly the values its proto's descriptors name, read from THIS
    /// frame — its locals and its own capture area — the flat-capture
    /// discipline (O(captured), not O(n_locals): the dormant
    /// full-frame clone and its double cost retire here, ★1';
    /// K43/K45/K51 + K189/K192). Verify checked every descriptor
    /// against this frame, so the bare indexing is structurally
    /// unreachable (the LoadLocal family discipline).
    pub(crate) fn arm_closure(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let frame = self.frames.last().expect("entry frame");
        let env = Rc::new(
            self.bc.funcs[instr.a as usize]
                .captures
                .iter()
                .map(|source| match *source {
                    CaptureSource::Local(slot) => frame.locals[slot as usize].clone(),
                    CaptureSource::Captured(k) => frame.captured[k as usize].clone(),
                })
                .collect::<Vec<_>>(),
        );
        self.reserve(span)?;
        let r = self.heap.alloc(HeapObj::Closure(ClosureData {
            proto: instr.a,
            env,
        }));
        self.push(Value::Closure(r))
    }

    /// JumpIfFalse: the condition must be a bool; false takes the
    /// jump (frame.pc = target), true falls through.
    pub(crate) fn arm_jump_if_false(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let cond = self.pop(Opcode::JumpIfFalse, func, pc)?;
        match cond {
            Value::Bool(false) => {
                self.frames.last_mut().expect("entry frame").pc = instr.a as usize;
            }
            Value::Bool(true) => {}
            other => {
                return Err(type_mismatch(
                    "jump-if-false condition",
                    demanded::BOOL,
                    &other,
                    self.span_at(func, pc),
                ));
            }
        }
        Ok(())
    }

    /// LoadGlobal (the extern/unbound error families verbatim).
    pub(crate) fn arm_load_global(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let idx = instr.a as usize;
        match &self.globals[idx] {
            Some(v) => self.push(v.clone()),
            None => {
                // W-3.2: an extern-declared name reads as the contract
                // it is — the C backend is the one engine with a foreign
                // call face, and the bytecode's extern table names the
                // boundary instead of a generic unbound-global
                // misreport.
                let name = &self.bc.globals[idx];
                if self.bc.externs.iter().any(|e| &e.name == name) {
                    return Err(RuntimeError::ExternCallRequiresBackend {
                        name: name.clone(),
                        span: self.span_at(func, pc),
                    });
                }
                Err(RuntimeError::UnboundGlobal {
                    name: name.clone(),
                    span: self.span_at(func, pc),
                })
            }
        }
    }

    /// The arithmetic quad (Add/Sub/Mul/Div — the single-source
    /// builtin::arith, the r134 F1 form).
    pub(crate) fn arm_arith(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let b = self.pop(instr.op, func, pc)?;
        let a = self.pop(instr.op, func, pc)?;
        let value = builtin::arith(instr.op, a, b, span)?;
        self.push(value)
    }

    /// MakePair (heap-allocating; the reserve charges first).
    pub(crate) fn arm_make_pair(
        &mut self,
        _instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let b = self.pop(Opcode::MakePair, func, pc)?;
        let a = self.pop(Opcode::MakePair, func, pc)?;
        self.reserve(span)?;
        let r = self.heap.alloc(HeapObj::Pair(a, b));
        self.push(Value::Pair(r))
    }

    /// Car (the pair projection; a non-pair operand is the type
    /// mismatch family).
    pub(crate) fn arm_car(&mut self, func: usize, pc: usize) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let v = self.pop(Opcode::Car, func, pc)?;
        let (a, _) = v
            .as_pair(&self.heap)
            .ok_or_else(|| type_mismatch("car operand", demanded::PAIR, &v, span))?;
        self.push(a.clone())
    }

    /// Cdr (Car's mirror).
    pub(crate) fn arm_cdr(&mut self, func: usize, pc: usize) -> Result<(), RuntimeError> {
        let span = self.span_at(func, pc);
        let v = self.pop(Opcode::Cdr, func, pc)?;
        let (_, d) = v
            .as_pair(&self.heap)
            .ok_or_else(|| type_mismatch("cdr operand", demanded::PAIR, &v, span))?;
        self.push(d.clone())
    }

    /// PushHandler: the handler value moves from the stack into the
    /// handler table.
    pub(crate) fn arm_push_handler(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let value = self.pop(Opcode::PushHandler, func, pc)?;
        self.handlers.push(HandlerEntry {
            effect: instr.a,
            value,
        });
        Ok(())
    }

    /// PopHandler (an underflow here is the fail-closed defense).
    pub(crate) fn arm_pop_handler(
        &mut self,
        instr: Instr,
        func: usize,
        pc: usize,
    ) -> Result<(), RuntimeError> {
        let count = instr.a as usize;
        if self.handlers.len() < count {
            return Err(RuntimeError::StackUnderflow {
                op: Opcode::PopHandler,
                pc,
                span: self.span_at(func, pc),
            });
        }
        self.handlers.truncate(self.handlers.len() - count);
        Ok(())
    }

    /// Halt: an empty operand stack halts as nil (the
    /// declaration-only shape), else the top value.
    pub(crate) fn arm_halt(&mut self, func: usize, pc: usize) -> Result<Value, RuntimeError> {
        let value = if self.frames.last().expect("entry frame").stack.is_empty() {
            Value::Nil
        } else {
            self.pop(Opcode::Halt, func, pc)?
        };
        Ok(value)
    }

    // ---------- the tier-1 mirror shims (MJ-1 — the trivial arms'
    // field access, shared by both engines as identical
    // expressions) ----------

    /// The current frame (the arms' `frames.last()` access).
    pub(crate) fn top_frame(&self) -> &Frame {
        self.frames.last().expect("entry frame")
    }

    /// The current frame, mutably.
    pub(crate) fn top_frame_mut(&mut self) -> &mut Frame {
        self.frames.last_mut().expect("entry frame")
    }

    /// The frame-stack depth (the call nodes' push detection).
    pub(crate) fn frames_len(&self) -> usize {
        self.frames.len()
    }

    /// StoreGlobal's slot write.
    pub(crate) fn store_global_slot(&mut self, idx: usize, value: Value) {
        self.globals[idx] = Some(value);
    }
}

impl BuiltinHost for Vm {
    /// The frame-count + live-cells budget (§19.4 — the VM's safety
    /// point semantics stay engine-local).
    fn charge(&mut self, span: Span) -> Result<(), RuntimeError> {
        self.reserve(span)
    }

    fn io_mut(&mut self) -> &mut dyn VmIo {
        self.io.as_mut()
    }

    fn heap_mut(&mut self) -> &mut Heap {
        &mut self.heap
    }

    fn heap(&self) -> &Heap {
        &self.heap
    }
}

#[cfg(test)]
mod tests {
    //! Interpreter loop tests (FP4) over hand-built bytecode: both
    //! halt forms, closure round-trips, opcode/builtin execution, and
    //! the run-time negative paths verified bytecode can still reach.

    use super::*;
    use kerf_compiler::FuncProto;
    use kerf_core::LiteralValue;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn fix_span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn entry_of(code: Vec<Instr>) -> Bytecode {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = code;
        proto.debug_info = vec![fix_span(0, 4); proto.code.len()];
        let mut bc = Bytecode::default();
        bc.funcs.push(proto);
        bc
    }

    fn push_proto(bc: &mut Bytecode, proto: FuncProto) {
        bc.funcs.push(proto);
    }

    #[test]
    fn halt_returns_nil_at_depth_zero_and_value_at_depth_one() {
        // Declaration-only product shape: entry halts on an empty
        // operand stack.
        let mut vm = Vm::new(entry_of(vec![Instr::new(Opcode::Halt)])).expect("verifies");
        assert_eq!(vm.run().expect("halts"), Value::Nil);

        // Single-expression product shape: one value to pop.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(41));
        let mut vm = Vm::new(bc).expect("verifies");
        assert_eq!(vm.run().expect("halts"), Value::Int(41));
    }

    #[test]
    fn closure_env_is_selective_and_captures_flow_through_frames() {
        // proto0: const 7 -> store-local 0 (n_locals 1) -> closure(1)
        // -> halt. proto1: const 9 -> ret. The Stage 2.1 flat-capture
        // semantics: the closure cell carries exactly the values the
        // proto's descriptors name (the dormant era cloned the whole
        // frame — the §9.51.2 anchor family inverted; ★1' retired).
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::StoreLocal, 0),
            Instr::with_a(Opcode::Closure, 1),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(7));
        bc.funcs[0].n_locals = 1;
        let mut proto1 = FuncProto::new(None, 0, 0);
        proto1.code = vec![Instr::with_a(Opcode::PushConst, 1), Instr::new(Opcode::Ret)];
        proto1.debug_info = vec![fix_span(0, 4), fix_span(0, 4)];
        push_proto(&mut bc, proto1);
        bc.consts.push(LiteralValue::Int(9));

        // Selective face: proto1 captures nothing, so the cell's env
        // is empty even though the defining frame holds a local.
        let mut vm = Vm::new(bc.clone()).expect("verifies");
        let closure = vm.run().expect("closure materializes");
        let data = closure.as_closure(vm.heap()).expect("closure cell");
        assert_eq!(data.proto, 1);
        assert_eq!(*data.env, Vec::<Value>::new());
        assert_eq!(vm.allocations(), 2); // entry frame + closure cell

        // Capture face: with a descriptor and a load-captured body,
        // the captured value flows through the frame round-trip —
        // proto0 stores 7, closure(2) copies it per the descriptor,
        // and the callee returns it plus its own const 2 via add.
        let mut bc2 = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::StoreLocal, 0),
            Instr::with_a(Opcode::Closure, 1),
            Instr::with_a(Opcode::Call, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc2.consts.push(LiteralValue::Int(7));
        bc2.funcs[0].n_locals = 1;
        let mut proto2 = FuncProto::new(None, 0, 0);
        proto2.captures = vec![kerf_compiler::CaptureSource::Local(0)];
        proto2.code = vec![
            Instr::with_a(Opcode::LoadCaptured, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 2),
            Instr::new(Opcode::Ret),
        ];
        proto2.debug_info = vec![fix_span(0, 4); 5];
        push_proto(&mut bc2, proto2);
        bc2.consts.push(LiteralValue::Int(2));
        bc2.globals.push(Symbol::new("+").expect("fixture symbol"));
        let mut vm2 = Vm::new(bc2).expect("verifies");
        assert_eq!(vm2.run().expect("captured value flows"), Value::Int(9));
        assert_eq!(vm2.allocations(), 3); // entry + closure cell + callee frame
    }

    #[test]
    fn opcode_and_builtin_execution_paths_run_in_place() {
        // Builtins execute without a frame: (+ 1 2) -> 3.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 2),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Int(2));
        bc.globals.push(Symbol::new("+").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        assert_eq!(vm.run().expect("add executes"), Value::Int(3));
        assert_eq!(vm.allocations(), 1); // entry frame only — no call frame

        // (< 1 2) -> true (comparison family).
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 2),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Int(2));
        bc.globals.push(Symbol::new("<").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        assert_eq!(vm.run().expect("lt executes"), Value::Bool(true));

        // MakePair executes over heap cells (dormant in 0.5-compiled
        // code — pair literals ride push-const — but the opcode face
        // stays complete per §8.12).
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::MakePair),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Int(2));
        let mut vm = Vm::new(bc).expect("verifies");
        let v = vm.run().expect("make-pair executes");
        let (a, b) = v.as_pair(vm.heap()).expect("pair cell");
        assert_eq!((a, b), (&Value::Int(1), &Value::Int(2)));
        assert_eq!(vm.heap().len(), 1);
    }

    #[test]
    fn closure_arity_mismatch_reports_proto_params() {
        // 0-param closure called with one argument — the emission
        // order puts the arg under the callee (args, then callee).
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::Closure, 1),
            Instr::with_a(Opcode::Call, 1),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(5));
        let mut proto1 = FuncProto::new(None, 0, 0);
        // The body leaves its value before ret (every closure proto
        // nets +1 — a bare ret would underflow its own depth walk).
        proto1.code = vec![Instr::with_a(Opcode::PushConst, 1), Instr::new(Opcode::Ret)];
        proto1.debug_info = vec![fix_span(0, 4), fix_span(0, 4)];
        push_proto(&mut bc, proto1);
        bc.consts.push(LiteralValue::Int(9));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::ArityMismatch {
                expected, actual, ..
            }) => {
                assert_eq!((expected, actual), (0, 1));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn truthy_type_mismatch_rejects_non_bool_conditions() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::JumpIfFalse, 2),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::TypeMismatch { got, .. }) => assert_eq!(got, "int"),
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn arithmetic_type_mismatch_rejects_mixed_kinds() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 2),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Bool(true));
        bc.globals.push(Symbol::new("+").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::TypeMismatch { got, context, .. }) => {
                assert_eq!(got, "bool");
                assert_eq!(context, "add operand");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn load_global_on_never_stored_slot_is_unbound() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc.globals.push(Symbol::new("x").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::UnboundGlobal { name, .. }) => {
                assert_eq!(name.as_str(), "x");
            }
            other => panic!("expected unbound global, got {other:?}"),
        }
    }

    #[test]
    fn ret_in_entry_frame_is_a_structured_error() {
        // Verify accepts a depth-1 ret as a terminator (pops(Ret) = 1
        // needs one value on the stack); only the run time knows the
        // entry frame has no caller to return to.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Ret),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::RetFromEntry { pc, .. }) => assert_eq!(pc, 1),
            other => panic!("expected ret-from-entry, got {other:?}"),
        }
    }

    #[test]
    fn pair_constant_allocation_respects_the_budget() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Pair(
            Box::new(LiteralValue::Int(1)),
            Box::new(LiteralValue::Int(2)),
        ));
        // Budget 2: entry frame + one pair cell — passes.
        let mut vm = Vm::with_budget(bc.clone(), 2).expect("verifies");
        assert!(vm.run().is_ok());
        // Budget 1: the pair cell exceeds it — fail closed.
        let mut vm = Vm::with_budget(bc, 1).expect("verifies");
        match vm.run() {
            Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 1),
            other => panic!("expected budget exceeded, got {other:?}"),
        }
    }

    #[test]
    fn builtin_arity_mismatch_on_a_hand_built_call() {
        // Three arguments against the fixed arity-2 `+` registry row.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::PushConst, 2),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 3),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Int(2));
        bc.consts.push(LiteralValue::Int(3));
        bc.globals.push(Symbol::new("+").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) => {
                // §9.67 NB-5: the payload identity is a pool entry.
                assert_eq!(func.as_ref().map(Symbol::as_str), Some("+"));
                assert_eq!((expected, actual), (2, 3));
            }
            other => panic!("expected builtin arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn comparison_rejects_mixed_kinds() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 2),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::String("a".into()));
        bc.globals.push(Symbol::new("<").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::TypeMismatch { got, context, .. }) => {
                assert_eq!((got, context), ("string", "`<` operand"));
            }
            other => panic!("expected comparison type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn cdr_rejects_non_pair_operands() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 1),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(5));
        bc.globals.push(Symbol::new("cdr").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::TypeMismatch { got, context, .. }) => {
                assert_eq!((got, context), ("int", "cdr operand"));
            }
            other => panic!("expected cdr type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn not_rejects_non_bool_operands() {
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 1),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.globals.push(Symbol::new("not").expect("fixture symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.run() {
            Err(RuntimeError::TypeMismatch { got, context, .. }) => {
                assert_eq!((got, context), ("int", "not operand"));
            }
            other => panic!("expected not type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn pop_handler_beyond_installed_is_stack_underflow() {
        // The handler stack is run-time state verify cannot model:
        // popping more handlers than installed fails closed.
        let mut vm = Vm::new(entry_of(vec![
            Instr::with_a(Opcode::PopHandler, 3),
            Instr::new(Opcode::Halt),
        ]))
        .expect("verifies");
        match vm.run() {
            Err(RuntimeError::StackUnderflow { op, .. }) => assert_eq!(op, Opcode::PopHandler),
            other => panic!("expected handler-stack underflow, got {other:?}"),
        }
    }

    // ---------- 0.7 collector injection face ----------

    /// A test collector: counts calls and sweeps every live cell not
    /// DIRECTLY rooted (sufficient for the hand-built programs below,
    /// whose cells carry no nested references — the full transitive
    /// algorithm lives in kerf-runtime's MarkSweep).
    struct MiniCollector {
        calls: usize,
    }

    impl crate::roots::Collector for MiniCollector {
        fn collect(&mut self, heap: &mut Heap, roots: &crate::roots::Roots) -> u32 {
            self.calls += 1;
            let rooted: std::collections::HashSet<u32> = roots
                .iter_values()
                .filter_map(|v| match v {
                    Value::Pair(r) | Value::Closure(r) => Some(*r),
                    _ => None,
                })
                .collect();
            let mut swept = 0;
            for r in 0..heap.total_slots() as u32 {
                if heap.is_live(r) && !rooted.contains(&r) && heap.free(r) {
                    swept += 1;
                }
            }
            swept
        }
    }

    /// (make-pair; car) x N: each cell dies the moment `car` pops
    /// it — the collect-then-retry face under a tight budget (without
    /// a cycle the dead-but-unreclaimed cells run the live count up).
    fn discarding_chain_bytecode(rounds: usize) -> Bytecode {
        let mut code = Vec::new();
        for _ in 0..rounds {
            code.push(Instr::with_a(Opcode::PushConst, 0)); // int payload
            code.push(Instr::with_a(Opcode::PushConst, 0));
            code.push(Instr::new(Opcode::MakePair));
            code.push(Instr::new(Opcode::Car)); // cell dies here
        }
        // Each round nets +1 (the car result); leave exactly one for
        // the halt (verify: depth <= 1 at the entry terminator).
        for _ in 0..rounds - 1 {
            code.push(Instr::new(Opcode::Pop));
        }
        code.push(Instr::new(Opcode::Halt));
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = code;
        proto.debug_info = vec![fix_span(0, 4); proto.code.len()];
        let mut bc = Bytecode::default();
        bc.consts.push(LiteralValue::Int(7));
        bc.funcs.push(proto);
        bc
    }

    #[test]
    fn injected_collector_collects_then_retries_tight_budget() {
        // Budget 3 with 8 discarding cells: without a cycle the
        // un-reclaimed cells pass the live count past the budget;
        // the injected collector reclaims them and the charge retries.
        let bc = discarding_chain_bytecode(8);
        let mut vm = Vm::with_budget_and_collector(bc, 3, Box::new(MiniCollector { calls: 0 }))
            .expect("verifies");
        vm.run().expect("collect-then-retry keeps the chain alive");
        assert!(
            vm.allocations() > 3,
            "cumulative counter still counts every charge"
        );
    }

    #[test]
    fn without_collector_the_budget_stays_fail_closed() {
        // The same chain, same budget, no collector: the 0.6
        // fail-closed behavior stands (BudgetExceeded, no retry).
        let bc = discarding_chain_bytecode(8);
        let mut vm = Vm::with_budget(bc, 3).expect("verifies");
        match vm.run() {
            Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 3),
            other => panic!("expected budget exceeded, got {other:?}"),
        }
    }

    #[test]
    fn collector_cannot_save_a_fully_live_set() {
        // RETAINED cells (make-pair then store-global): every cell
        // stays reachable through the global table, so collection
        // finds nothing to reclaim and the budget still fails closed
        // — with the collector having actually run.
        let mut code = Vec::new();
        let mut names = Vec::new();
        for i in 0..6u32 {
            code.push(Instr::with_a(Opcode::PushConst, 0));
            code.push(Instr::with_a(Opcode::PushConst, 0));
            code.push(Instr::new(Opcode::MakePair));
            code.push(Instr::with_a(Opcode::StoreGlobal, i));
            names.push(Symbol::new(&format!("g{i}")).expect("fixture symbol"));
        }
        code.push(Instr::new(Opcode::Halt)); // depth 0 (globals hold the cells)
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = code;
        proto.debug_info = vec![fix_span(0, 4); proto.code.len()];
        let mut bc = Bytecode::default();
        bc.consts.push(LiteralValue::Int(7));
        bc.globals = names;
        bc.funcs.push(proto);
        let mut vm = Vm::with_budget_and_collector(bc, 4, Box::new(MiniCollector { calls: 0 }))
            .expect("verifies");
        match vm.run() {
            Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 4),
            other => panic!("expected budget exceeded, got {other:?}"),
        }
    }

    #[test]
    fn snapshot_roots_covers_all_root_classes_and_foreign_refs() {
        // The four §19.4 classes plus handlers: a register_foreign_ref
        // value rides in the snapshot (the host-protection face).
        let bc = entry_of(vec![Instr::new(Opcode::Halt)]);
        let mut vm = Vm::new(bc).expect("verifies");
        let cell = vm
            .heap_mut()
            .alloc(HeapObj::Pair(Value::Int(1), Value::Nil));
        vm.register_foreign_ref(Value::Pair(cell));
        let roots = vm.snapshot_roots();
        assert!(roots.foreign.contains(&Value::Pair(cell)));
        assert!(roots.stack.is_empty()); // no frame pushed outside run
        assert!(roots.locals.is_empty());
        assert!(roots.globals.is_empty()); // no globals in this product
        assert!(roots.handlers.is_empty());
        // The mutable heap face round-trips.
        assert!(vm.heap_mut().get(cell).is_some());
    }

    #[test]
    fn pair_const_materialization_charges_one_exact_batch() {
        // §9.69.3 EXC-2: the pair-const charge is one reserve_exact(n)
        // batch whose accept/reject boundary is the per-cell loop's,
        // pinned from both sides.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::new(Opcode::Halt),
        ]);
        // (1 . (2 . 3)) — two pair cells.
        bc.consts.push(LiteralValue::Pair(
            Box::new(LiteralValue::Int(1)),
            Box::new(LiteralValue::Pair(
                Box::new(LiteralValue::Int(2)),
                Box::new(LiteralValue::Int(3)),
            )),
        ));
        // Budget 2: the entry frame charges 1 (live 0 < 2), the batch
        // of 2 checks live 1 < 2 and passes, the materialization walk
        // then lands live on 3 — the burst overshoot the per-cell loop
        // exhibited too (every loop iteration saw the same live value
        // because heap.alloc only runs in the walk).
        let mut vm = Vm::with_budget(bc.clone(), 2).expect("verifies");
        let v = vm.run().expect("burst passes exactly as the loop did");
        let outer = v.as_pair(vm.heap()).expect("materialized pair");
        assert_eq!(outer.0, &Value::Int(1));
        assert_eq!(vm.allocations(), 3); // entry frame + the two-cell batch
        // Budget 1: the entry frame charges 1 (live 0 < 1), the batch
        // of 2 checks live 1 < 1 and fails closed.
        match Vm::with_budget(bc, 1).expect("verifies").run() {
            Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 1),
            other => panic!("expected budget exhaustion, got {other:?}"),
        }
    }

    #[test]
    fn take_args_moves_the_stack_window_in_call_order() {
        // §9.69.3 EXC-3: split_off hands the args over in call order.
        // proto0: 1, 2, 3, closure(1), call(3), halt. proto1: loads
        // locals 0..2 and folds them into (1 . (2 . 3)) via MakePair,
        // then ret — any order inversion in the window handoff would
        // build a different tree.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::with_a(Opcode::PushConst, 2),
            Instr::with_a(Opcode::Closure, 1),
            Instr::with_a(Opcode::Call, 3),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(1));
        bc.consts.push(LiteralValue::Int(2));
        bc.consts.push(LiteralValue::Int(3));
        let mut proto1 = FuncProto::new(None, 3, 3);
        proto1.code = vec![
            Instr::with_a(Opcode::LoadLocal, 0),
            Instr::with_a(Opcode::LoadLocal, 1),
            Instr::with_a(Opcode::LoadLocal, 2),
            Instr::new(Opcode::MakePair),
            Instr::new(Opcode::MakePair),
            Instr::new(Opcode::Ret),
        ];
        proto1.debug_info = vec![fix_span(0, 4); proto1.code.len()];
        push_proto(&mut bc, proto1);
        let mut vm = Vm::new(bc).expect("verifies");
        let result = vm.run().expect("window handoff runs");
        // (1 . (2 . 3)): the outer pair's car is local 0, its cdr the
        // inner pair (local 1 . local 2).
        let outer = result.as_pair(vm.heap()).expect("outer pair");
        assert_eq!(outer.0, &Value::Int(1));
        let inner = outer.1.as_pair(vm.heap()).expect("inner pair");
        assert_eq!(inner.0, &Value::Int(2));
        assert_eq!(inner.1, &Value::Int(3));
        assert_eq!(vm.allocations(), 5); // entry frame + closure cell + callee frame + 2 pair cells
    }

    #[test]
    fn extern_call_requires_backend_names_the_contract() {
        // W-3.2: an extern-declared global read on the VM names the
        // boundary, not a generic unbound-global misreport — the
        // bytecode's extern table feeds the diagnostic.
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(0, 1), fix_span(0, 1)];
        let bc = Bytecode {
            funcs: vec![proto],
            consts: Vec::new(),
            globals: vec![Symbol::new("add").expect("symbol")],
            externs: vec![kerf_compiler::ExternEntry {
                name: Symbol::new("add").expect("symbol"),
                params: vec![kerf_core::ExternType::Int, kerf_core::ExternType::Int],
                ret: kerf_core::ExternType::Int,
            }],
        };
        let mut vm = Vm::new(bc).expect("the product loads");
        match vm.run() {
            Err(RuntimeError::ExternCallRequiresBackend { name, .. }) => {
                assert_eq!(name.as_str(), "add");
            }
            other => panic!("the extern boundary diagnostic, got {other:?}"),
        }
    }

    #[test]
    fn inject_global_binds_a_slot_the_program_reads() {
        // W-3.12 injection channel: the host binds `data`, the
        // program's load-global reads the materialized pair chain —
        // the steady-state bootstrap chain's data face.
        let bc = entry_of(vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Halt),
        ]);
        let mut bc = bc;
        bc.globals.push(Symbol::new("data").expect("symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        let table = LiteralValue::Pair(
            Box::new(LiteralValue::Int(104)),
            Box::new(LiteralValue::Pair(
                Box::new(LiteralValue::Int(105)),
                Box::new(LiteralValue::Nil),
            )),
        );
        vm.inject_global("data", &table).expect("binds");
        let result = vm.run().expect("halts");
        // Walk the materialized chain: (104, 105) — two pair cells.
        let (a, b) = result
            .as_pair(vm.heap())
            .expect("the injected table's outer pair");
        assert_eq!(a, &Value::Int(104));
        let (c, d) = b.as_pair(vm.heap()).expect("the inner pair");
        assert_eq!(c, &Value::Int(105));
        assert_eq!(d, &Value::Nil);
        // The two pair cells charged the budget through the same
        // reserve path const materialization uses (plus the entry
        // frame).
        assert_eq!(vm.allocations(), 3);
    }

    #[test]
    fn inject_global_unknown_name_fails_closed() {
        // The channel rides an existing slot and never mints one: a
        // name outside the compiler's collected reference set is a
        // definite rejection, and the message names the miss (R8).
        let bc = entry_of(vec![Instr::new(Opcode::Halt)]);
        let mut bc = bc;
        bc.globals.push(Symbol::new("data").expect("symbol"));
        let mut vm = Vm::new(bc).expect("verifies");
        match vm.inject_global("missing", &LiteralValue::Int(1)) {
            Err(RuntimeError::InjectGlobalUnknown { name, span }) => {
                assert_eq!(name, "missing");
                assert_eq!(span, Span::host());
            }
            other => panic!("the inject-name miss must fail closed, got {other:?}"),
        }
        // The single-source message form (R8 family).
        assert_eq!(
            RuntimeError::InjectGlobalUnknown {
                name: "missing".to_string(),
                span: Span::host(),
            }
            .to_string(),
            "inject-global name `missing` is not referenced by the program"
        );
    }

    #[test]
    fn inject_global_charges_the_budget_and_fails_closed_on_exhaustion() {
        // Injected data is live heap, never free: the §19.4 safety
        // point checks live usage at every charge site, so a second
        // bind past the budget is the definite rejection — the first
        // bind's cells are live and counted (the same reserve
        // semantics const materialization rides).
        let bc = entry_of(vec![Instr::new(Opcode::Halt)]);
        let mut bc = bc;
        bc.globals.push(Symbol::new("data").expect("symbol"));
        let mut vm = Vm::with_budget(bc, 1).expect("verifies");
        let table = LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(LiteralValue::Nil));
        vm.inject_global("data", &table)
            .expect("the first bind charges past-capacity like any single site");
        assert!(matches!(
            vm.inject_global("data", &table),
            Err(RuntimeError::BudgetExceeded { .. })
        ));
        // The failed bind left no partial state: on a fresh VM the
        // never-bound slot reports the ordinary unbound read.
        let mut bc2 = entry_of(vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc2.globals.push(Symbol::new("data").expect("symbol"));
        let mut vm2 = Vm::with_budget(bc2, 4).expect("verifies");
        assert!(matches!(vm2.run(), Err(RuntimeError::UnboundGlobal { .. })));
    }

    #[test]
    fn inject_global_yields_to_a_program_define_and_rebinds_between_runs() {
        // The documented contract: a program-side define of the
        // same name overwrites the bound slot at run time (the
        // steady-state program's no-define discipline is the
        // assembling driver's duty), and a later host bind on a
        // fresh VM takes the slot back.
        let mut bc = entry_of(vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::StoreGlobal, 0),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Halt),
        ]);
        bc.consts.push(LiteralValue::Int(5));
        bc.globals.push(Symbol::new("data").expect("symbol"));
        let mut vm = Vm::new(bc.clone()).expect("verifies");
        vm.inject_global("data", &LiteralValue::Int(7))
            .expect("binds");
        assert_eq!(vm.run().expect("halts"), Value::Int(5));

        // The fresh-VM rebind face (the steady-state chain's per-read
        // shape): same compiled product, new binding, new run.
        let mut vm2 = Vm::new(bc).expect("verifies");
        vm2.inject_global("data", &LiteralValue::Int(9))
            .expect("rebinds");
        assert_eq!(vm2.run().expect("halts"), Value::Int(5));
    }
}
